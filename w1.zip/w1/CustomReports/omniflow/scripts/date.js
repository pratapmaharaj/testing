/*

		File            :       date.js
		Purpose         :       Functions related to Date Format

		Change History  :
		Date                Name				Comments

                06 Aug 2008       Arup Sharma             BUG ID PRM_8.0_014 (For Time Zone)
                07 Apr 2015       Ashutosh Pandey         BUG ID 54836 If click on Date tab in search window, error "Invalid request is made" is generating

*/

function isValidTime(tm,sep1,ampm)
{
	var sep=new String(sep1);
	if (sep.length!=1)
		return false;
	var ele=tm.split(sep);
	if (ele.length!=2)
		return false;
	var temp=ele[0];
	if (temp.charAt(0)=='0' && temp.length==2)
		temp=temp.charAt(1)
	var h=parseInt(temp);
	temp=ele[1];
	if (temp.charAt(0)=='0' && temp.length==2)
		temp=temp.charAt(1)
	var m=parseInt(temp);
	if (isNaN(h) || isNaN(m) || h<0 || m<0 || m>59)
		return false;
	if(ampm.toLowerCase()=="am" && h>11)
		return false;
	else if (ampm.toLowerCase()=="pm" && h>23)
		return false;
	return true;
}

function isValidDate(dt,sep1)
{
	var sep=new String(sep1);
	if (sep.length!=1)
		return false;
	var ele=dt.split(sep);
	if (ele.length!=3)
		return false;
	var d=ele[0], m=ele[1], y=ele[2];
	if ( isNaN(d) || isNaN(m) || isNaN(y)) 
		return false;
	if ( d<1 || d>31)
		return false;
	if ( m<1 || m>12)
		return false;
	if ( y<1900 || y>3000)
		return 2;
	if ((m==2 || m==4 || m==6 || m==9 || m==11) && d>30)
		return false;
	if (y%100 == 0)
		y = parseInt(y/100);
	if (y%4 != 0)
	{
		if (m==2 && d>28)
			return false;
	}
	return true		
}

function compareDates(fromD,toD,sep1)
{
	var sep=new String(sep1);
	if (sep.length!=1)
		return false;

	var fEle=fromD.split(sep);
	if (fEle.length!=3)
		return false;

	var fD=fEle[0], fM=fEle[1], fY=fEle[2];
	if (isNaN(fD) || isNaN(fM) || isNaN(fY)) 
		return false;

	var tEle=toD.split(sep);
	if (tEle.length!=3)
		return false;

	var tD=tEle[0], tM=tEle[1], tY=tEle[2];
	if (isNaN(tD) || isNaN(tM) || isNaN(tY)) 
		return false;

	if (tY>fY)
		return true;
	else if ((tY==fY) && (tM>fM))
		return true;
	else if ((tY==fY) && (tM==fM) && (tD>=fD))
		return true;
	else 
		return false;
}


function getSizeInKB(docSize)
{
	var strDocSize = docSize;
	var lSize = parseInt(strDocSize);
	if (lSize == 0)
		strDocSize = "0KB";
	else
	{
		var lTempSize = Math.ceil(lSize / 1024);
		strDocSize = lTempSize + " KB";
	}
	return strDocSize;
}

function replaceplus(Str)
{
	var	RetStr;
	var Pos	= FindPos(Str,"+");
	while(Pos != -1)
	{
		var RetStr	= Str.substring(0,Pos);
		Str	= Str.substring(Pos + 1,Str.length);
		Str=RetStr.concat(" ") + Str;
		Pos	= FindPos(Str,"+");
	}
	return Str;
}


function FindPos(Str,SearchStr)
{
	len = Str.length;
	var ii;
	for(ii=0; ii<len; ++ii)
	{
		if(Str.charAt(ii) == SearchStr)
			return ii;
	}
	return -1;
}

function TrimLeft(val)
{
	var len = val.length;
	if(len==1 && val == " ")
	{
		val = "";
		return val;
	}
	if(len != 0)
	{
		while(1)
		{
			if(val.charAt(0) != " ")
				return val;
			else
				val = val.substr(1);
		}
	}
	return val;
}

function TrimRight(val)
{
	var len = val.length;
	if(len==1 && val == " ")
	{
		val = "";
		return val;
	}
	if(len != 0)
	{
		while(1)
		{
			if(val.charAt(len - 1) != " ")
			{
				return val;
			}
			else
			{
				len -= 1;
				val = val.substr(0,len);
			}
		}
	}
	return val;
}

// function to get the short name of required size as specified by the user .
function getShortNameSize(Name,size)
{
	if (Name.length > size + 5)
	{
		Name1 = Name.substring(0, size) + "...&nbsp;<img align=absbottom border=0 src=\"/omniflow/images/arrow1.gif\" alt=\"" + Name + "\">";
		return Name1;
	}
	return Name;
}

function getShortName(Name)
{
	if (Name.length > 22)
	{
		Name1 = Name.substring(0, 17) + "...&nbsp;<img align=absbottom border=0 src=\"/omniflow/images/arrow1.gif\" alt=\"" + Name + "\">";
		return Name1;
	}
	return Name;
}

function getShortName1(Name)
{
	if (Name.length > 40)
	{
		Name1 = Name.substring(0, 38) + "...&nbsp;<img align=absbottom border=0 src=\"/omniflow/images/arrow1.gif\" alt='" + Name + "'>";
		return Name1;
	}
	return Name;
}


function ReplaceSpace(Str)
{
	var	RetStr;
	var Pos	= FindPos(Str," ");
	while(Pos != -1)
	{
		RetStr	= Str.substring(0,Pos);
		Str	= Str.substring(Pos + 1,Str.length);
		Str=RetStr.concat("+") + Str;
		Pos	= FindPos(Str," ");
	}
	return Str;
}


function getShortDownloadName(Name)
{
	if (Name.length > 20)
	{
		Name1 = Name.substring(0, 18) + "~1";
		return Name1;
	}
	return Name;
}

function getShortNameWithoutImage(Name)
{
	if (Name.length > 20)
	{
		Name1 = Name.substring(0, 18) + "...";
		return Name1;
	}
	return Name;
}

function getShortNameWithoutImage1(Name)
{
	if (Name.length > 16)
	{
		Name1 = Name.substring(0, 14) + "...";
		return Name1;
	}
	return Name;
}

function getProperDate(dateIn1)
{
	var dateOut;
	var dateIn = unescape(dateIn1);
	dateOut = dateIn.substring(8,10)+"-"+dateIn.substring(5,7)+"-"+dateIn.substring(0,4)+" "+dateIn.substring(11,dateIn.length-3);
	return dateOut;
}

function moreText()
{
	var url="/doccab/more.jsp";
	w= window.open(url,'MoreInformation','scrollbars=no,resizable=no,status=yes,top='+(windowX+10)+',left='+(windowY+10)+',width='+windowW+',height='+windowH);
	return w;
}

function MakeUniqueNumber()
{
	var tm = new Date();
	var milisecs = Date.parse(tm.toGMTString());
	return milisecs;
}

function Trim(val)
{
    // BUG ID 54836
    if(typeof val == 'number') {
        return val;
    }
	var len = val.length;
	if(len != 0)
	{
		while(1)
		{
			if(val.charAt(0) != " ")
				break;
			else
				val = val.substr(1);
		}
	}

	len = val.length;
	if(len != 0)
	{
		while(1)
		{
			if(val.charAt(len - 1) != " ")
				return val;
			else
			{
				len -= 1;
				val = val.substr(0,len);
			}
		}
	}
	return val;
}

function deletewindow()
{
	var ii;
	for(ii=0;ii<handle.length;ii++)
	{
		var v = handle[ii];
		if (typeof v != 'undefined' && v != null && !v.closed)
			v.close();
	}
}


function DBToLocal(sDbDate,sDateFormat)
{	
        if(bEnableTimeZone == 'true')
        {
            try
            {
                var timeDiff = (iClientTimeDiff-0)-(iServerTimeDiff-0);
                sDbDate = addMinutesToDBDate(sDbDate,timeDiff);
            }
            catch(e)
            {}
        }
	var sDateSeparator=DATESEPARATOR;
	if(sDbDate=='')
		return ' ';
	var nBegIndex=sDbDate.indexOf("-");
	//Gets the value of the date from DB
	var strYear = sDbDate.substring(0,sDbDate.indexOf("-"));
	var strMonth = sDbDate.substring(nBegIndex+1,sDbDate.lastIndexOf("-"));
	var strDay;
	var strTime="";
	if (sDbDate.indexOf(" ")!=-1)
	{
		strDay = sDbDate.substring(sDbDate.lastIndexOf("-")+1,sDbDate.indexOf(" "));
		var strtimetemp=sDbDate.substring(sDbDate.indexOf(" ")+1,sDbDate.length);
		var index=strtimetemp.indexOf(":");
		var lastIndex=strtimetemp.lastIndexOf(":");

		if(index==lastIndex)
			strTime=strtimetemp;
		else
			strTime = sDbDate.substring(sDbDate.indexOf(" ")+1,sDbDate.lastIndexOf(":")+3);//gets the seconds as well

		if (strTime=="00:00:00")
			strTime="";
	}
	else
		strDay = sDbDate.substring(sDbDate.lastIndexOf("-")+1,sDbDate.length);

	var strtemp1="";
	var strtemp2="";
	var strtemp3="";
	var strResult="";
	var tempDay="";
	var tempMon="";

	// gets the characters from the set date format
	var strChar1=sDateFormat.substring(0,sDateFormat.indexOf("/"));
	var strChar2=sDateFormat.substring(sDateFormat.indexOf("/")+1,sDateFormat.lastIndexOf("/"));
	var strChar3=sDateFormat.substring(sDateFormat.lastIndexOf("/")+1,sDateFormat.length);

	strChar1=strChar1.toUpperCase();
	strChar2=strChar2.toUpperCase();
	strChar3=strChar3.toUpperCase();

	if ((strChar1=="D")||(strChar1=="DD"))
	{
		tempDay=parseInt(strDay,10);
		if ((strChar1=="D")&& (tempDay<10))
			strtemp1=strDay.substring(1,2); //getting the last value like 03 ->3
		else
			strtemp1=strDay;
	}
	else if((strChar1=="M")||(strChar1=="MM"))
	{
		tempMon=parseInt(strMonth,10);
		if ((strChar1=="M")&& (tempMon <10))
			strtemp1=strMonth.substring(1,2); //getting the last value like 03 ->3
		else
			strtemp1=strMonth;
	}
	else
	{
		if ((strChar1=="YY")||(strChar1=="YYYY"))
		{
			if (strChar1=="YY")
				strtemp1=strYear.substring(2,strYear.length);//getting the last two
			else
				strtemp1=strYear;
		}
	}

	if ((strChar2=="D")||(strChar2=="DD"))
	{
		tempDay=parseInt(strDay,10);
		if ((strChar2=="D")&& (tempDay <10))
			strtemp2=strDay.substring(1,2); //getting the last value like 03 ->3
		else
			strtemp2=strDay;
	}
	else if((strChar2=="MM")||(strChar2=="MMM"))
	{
		if (strChar2=="MMM")
		{
			switch(parseInt(strMonth,10))
			{
				case 1:
					strtemp2=JAN;
					break;
				case 2:
					strtemp2=FEB;
					break;
				case 3:
					strtemp2=MAR;
					break;
				case 4:
					strtemp2=APR;
					break;
				case 5:
					strtemp2=MAY;
					break;
				case 6:
					strtemp2=JUN;
					break;
				case 7:
					strtemp2=JUL;
					break;
				case 8:
					strtemp2=AUG;
					break;
				case 9:
					strtemp2=SEP;
					break;
				case 10:
					strtemp2=OCT;
					break;
				case 11:
					strtemp2=NOV;
					break;
				case 12:
					strtemp2=DEC;
					break;
			}
		}
			else
				strtemp2=strMonth;
	}


	if((strChar3=="D")||(strChar3=="DD"))
	{
		tempDay=parseInt(strDay,10);
		if ((strChar3=="D") && (tempDay < 10))
			strtemp3=strDay.substring(1,2); //getting the last value like 03 ->3
		else
			strtemp3=strDay;
	}
	else
	{
		if ((strChar3=="YY")||(strChar3=="YYYY"))
		{
			if (strChar3=="YY")
				strtemp3=strYear.substring(2,strYear.length);//getting the last two
			else
				strtemp3=strYear;
		}
	}
	if ((strtemp1=='')&&(strtemp2==''))
		return strtemp3+" "+strTime;
	else if ((strtemp3=='')&&(strtemp2==''))
		return strtemp1+" "+strTime;
	else if ((strtemp3=='')&&(strtemp1==''))
		return strtemp2+" "+strTime;
	else if (strtemp1=='')
		return strtemp2+sDateSeparator+strtemp3+" "+strTime;
	else if (strtemp2=='')
		return strtemp1+sDateSeparator+strtemp3+" "+strTime;
	else if (strtemp3=='') 
		return strtemp1+sDateSeparator+strtemp2+" "+strTime;

	strResult=strtemp1+sDateSeparator+strtemp2+sDateSeparator+strtemp3+" "+strTime;
	return strResult;
 }

function LocalToDB(sLocalDate,sDateFormat)
{
	if(Trim(sLocalDate)== '')
		return '';
	var sDateSeparator=DATESEPARATOR;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	//Gets the value of the date from local
	var temp;
	var strtemp1 = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	var strtemp2 = sLocalDate.substring(nBegIndex+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strtemp3;
	var strTime;

	if (sLocalDate.indexOf(" ")!=-1)
	{
		strtemp3 = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.indexOf(" "));
		strTime = sLocalDate.substring(sLocalDate.indexOf(" "),sLocalDate.length);
	}
	else
	{
		strtemp3 = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
		strTime = "00:00:00";
	}

	var strResult="";
	var strYear = "";
	var strMonth = "";
	var strDay = "";

	// gets the characters from the set date format
	var strChar1=sDateFormat.substring(0,sDateFormat.indexOf(sDateSeparator));
	var strChar2=sDateFormat.substring(sDateFormat.indexOf(sDateSeparator)+1,sDateFormat.lastIndexOf(sDateSeparator));
	var strChar3=sDateFormat.substring(sDateFormat.lastIndexOf(sDateSeparator)+1,sDateFormat.length);

	strChar1=strChar1.toUpperCase();
	strChar2=strChar2.toUpperCase();
	strChar3=strChar3.toUpperCase();

	if ((strChar1=="D")||(strChar1=="DD"))
	{
		temp=parseInt(strtemp1,10);
		if ((strChar1=="D")&& (temp<10))
			strDay="0"+strtemp1; 
		else
			strDay=strtemp1;
	}
	else if((strChar1=="M")||(strChar1=="MM"))
	{
		temp=parseInt(strtemp1,10);
		if ((strChar1=="M")&& (temp<10))
			strMonth="0"+strtemp1;
		else
			strMonth=strtemp1;
	}
	else 
	{
		strYear=strtemp1;
	}

	if ((strChar2=="D")||(strChar2=="DD"))
	{
		temp=parseInt(strtemp2,10);
		if ((strChar2=="D")&& (temp<10))
			strDay="0"+strtemp2; 
		else
			strDay=strtemp2;
	}
	else if((strChar2=="MM")||(strChar2=="MMM"))
	{
		if (strChar2=="MMM")
		{
			strtemp2=strtemp2.toUpperCase();
			if(strtemp2==JAN1)
				strMonth="01";
			else if(strtemp2==FEB1)
				strMonth="02";
			else if(strtemp2==MAR1)
				strMonth="03";
			else if(strtemp2==APR1)
				strMonth="04";
			else if(strtemp2==MAY1)
				strMonth="05";
			else if(strtemp2==JUN1)
				strMonth="06";
			else if(strtemp2==JUL1)
				strMonth="07";
			else if(strtemp2==AUG1)
				strMonth="08";
			else if(strtemp2==SEP1)
				strMonth="09";
			else if(strtemp2==OCT1)
				strMonth="10";
			else if(strtemp2==NOV1)
				strMonth="11";
			else if(strtemp2==DEC1)
				strMonth="12";
			}
			else
				strMonth=strtemp2;
	}

	if((strChar3=="D")||(strChar3=="DD"))
	{
		temp=parseInt(strtemp3,10);
		if ((strChar3=="D")&& (temp<10))
			strDay="0"+strtemp3; 
		else
			strDay=strtemp3;
	}
	else
		strYear=strtemp3;

	strResult=strYear+"-"+strMonth+"-"+strDay+" "+strTime;
        
        if(bEnableTimeZone == 'true')
        {
            try
            {
                var timeDiff = (iServerTimeDiff-0)-(iClientTimeDiff-0);
                strResult = addMinutesToDBDate(strResult,timeDiff);
            }
            catch(e)
            {}
        }
        return strResult;
}


function ValidateDateFormat(val,sDateFormat)
{
	var Day;
	var Month;
	var Year;
	var Pos;
	var Pos1;
	val=Trim(val);
	if (sDateFormat=='')
	{
		sDateFormat='YYYY/MM/DD';
	}

	Pos = FindPos(val, "/");
	if(Pos == -1)
	{
		alert(INVALID_FORMAT +sDateFormat); //Date should be in proper format given in 
		return 0;
	}
	
	// gets the characters from the set date format
	var strChar1=sDateFormat.substring(0,sDateFormat.indexOf("/"));

	Pos1=val.lastIndexOf("/")
	if(Pos1==-1)
	{
		alert(INVALID_FORMAT1);//"Invalid Date Format."
		return 0;
	}

	var strChar2=sDateFormat.substring(sDateFormat.indexOf("/")+1,sDateFormat.lastIndexOf("/"));
	var strChar3=sDateFormat.substring(sDateFormat.lastIndexOf("/")+1,sDateFormat.length);

	strChar1=strChar1.toUpperCase();
	strChar2=strChar2.toUpperCase();
	strChar3=strChar3.toUpperCase();

	if(val != "0/0/0")
	{
		if ((strChar1=="D")||(strChar1=="DD"))
		{
			Day = val.substring(0,Pos);
			if(!IsNumericVal(Day))
			{
				alert(NON_NUMERIC_DAY);//'Day should be numeric'
				return 0;
			}
		}
		else if((strChar1=="M")||(strChar1=="MM"))
		{
			Month	= val.substring(0,Pos);
			if(!IsNumericVal(Month)) 
			{
				alert(NON_NUMERIC_MONTH);//'Month should be numeric'
				return 0;
			}
		}
		else 
		{
			Year	= val.substring(0,Pos);
			if(Year<1900 || Year.length > 4)
			{
				alert(ALERT_YEAR_LENGTH_FORMAT);//'Year should be greater than 1900 and in YYYY format'
				return 0;
			}
			if(!IsNumericVal(Year))
			{
				alert(NON_NUMERIC_YEAR);//'Year should be numeric'
				return 0;
			}
		}

		val = val.substring(Pos + 1,val.length);
		Pos = FindPos(val, "/");
		if(Pos == -1)
		{
			alert(INVALID_FORMAT +sDateFormat);//"Date should be in proper format given in "
			return 0;
		}
	
		if ((strChar2=="D")||(strChar2=="DD"))
		{
			Day = val.substring(0,Pos);
			if(!IsNumericVal(Day))
			{
				alert(NON_NUMERIC_DAY);//'Day should be numeric'
				return 0;
			}
		}
		else if((strChar2=="MM")||(strChar2=="MMM"))
		{
			Month = val.substring(0,Pos);
			
			if (strChar2=="MMM")
			{
				Month=Month.toUpperCase();
				if(Month==JAN1)
					Month="01";
				else if(Month==FEB1)
					Month="02";
				else if(Month==MAR1)
					Month="03";
				else if(Month==APR1)
					Month="04";
				else if(Month==MAY1)
					Month="05";
				else if(Month==JUN1)
					Month="06";
				else if(Month==JUL1)
					Month="07";
				else if(Month==AUG1)
					Month="08";
				else if(Month==SEP1)
					Month="09";
				else if(Month==OCT1)
					Month="10";
				else if(Month==NOV1)
					Month="11";
				else if(Month==DEC1)
					Month="12";
				else 
				{
					alert(INVALID_MONTH_STRING+INVALID_FORMAT+sDateFormat);
					return 0;
				}
			}
			if(!IsNumericVal(Month)) 
			{
				alert(NON_NUMERIC_MONTH);//'Month should be numeric'
				return 0;
			}
		}

		var temptime="";
		if(val.indexOf(" ")!=-1)
		{
			temptime=val.substring(val.indexOf(" "),val.length);
			temptime=Trim(temptime);
			if (temptime.indexOf(":")==-1)
			{	
				alert(INVALID_TIME);//TIME should be correct format
				return 0;
			}
			var temphr=temptime.substring(0,temptime.indexOf(":"));
			if(!IsNumericVal(temphr)||temphr>24 ||temphr<0)
			{
				alert(NON_NUMERIC_HOUR);//'HOUR should be numeric'
				return 0;
			}

			var tempmin;
			temptime=temptime.substring(temptime.indexOf(":")+1,temptime.length);

			if (temptime.indexOf(":")!=-1)
			{
				tempmin=temptime.substring(0,temptime.indexOf(":"));
				var tempsec=temptime.substring(temptime.indexOf(":")+1,temptime.length);
				if(!IsNumericVal(tempsec)||tempsec>=60 ||tempsec<0)
				{
					alert(NON_NUMERIC_SEC);//'SEC should be numeric'
					return 0;
				}

			}
			else
				tempmin=temptime.substring(0,temptime.length);

			if(!IsNumericVal(tempmin)||tempmin>=60 ||tempmin<0)
			{
				alert(NON_NUMERIC_MIN);//'MIN should be numeric'
				return 0;
			}

			val = val.substring(Pos + 1,val.indexOf(" "));
		}
		else
			val = val.substring(Pos + 1,val.length);
			
		Pos=val.length;

		if((strChar3=="D")||(strChar3=="DD"))
		{
			Day = val.substring(0,Pos);
			if(!IsNumericVal(Day))
			{
				alert(NON_NUMERIC_DAY);//'Day should be numeric'
				return 0;
			}
		}
		else
		{
			Year	= val.substring(0,Pos);
			if(Year<1900 || Year.length > 4)
			{
				alert(ALERT_YEAR_LENGTH_FORMAT);//'Year should be greater than 1900 and in YYYY format'
				return 0;
			}
			if(!IsNumericVal(Year))
			{
				alert(NON_NUMERIC_YEAR);//'Year should be numeric'
				return 0;
			}
		
		}
	}

	// Validate For Leap Year
	switch(parseInt(Month,10))
	{
		case 1 :
		case 3 :
		case 5 :
		case 7 :
		case 8 :
		case 10:
		case 12:
			if(Day > 31 || Day < 1)
			{
				alert(ALERT_VALID_DATE_31);//"Please enter valid day.\nDay should be greater than 0 and less than or equal to 31."
				return 0;
			}
			break;

		case 4 :
		case 6 :
		case 9 :
		case 11:
			if(Day > 30 || Day < 1)
			{
				alert(ALERT_VALID_DATE_30);//Please enter valid day.\nDay should be greater than 0 and less than or equal to 30.
				return 0;
			}
			break;

		case 2 :
			if((Year % 100) == 0)
				Year = parseInt(Year / 100);

			if((Year % 4) == 0)
				{
					if(Day > 29 || Day < 1)
					{
						alert(ALERT_VALID_DATE_29);//Please enter valid day.\nDay should be greater than 0 and less than or equal to 29.
						return 0;
					}
				}
			else
				{
					if(Day > 28 || Day < 1)
					{
						alert(ALERT_VALID_DATE_28);//Please enter valid day.\nDay should be greater than 0 and less than or equal to 28
						return 0;
					}
				}
				break;
			default :
				{
					alert(INVALID_DATE_MONTH);
					return 0;
				}
		}
	return 1;
}

function addMinutesToDBDate(sDbDate,iMinutes)
{
    if(sDbDate=='')
        return ' ';
    var nBegIndex=sDbDate.indexOf("-");
    //Gets the value of the date from DB
    var strYear = sDbDate.substring(0,sDbDate.indexOf("-"));
    var strMonth = sDbDate.substring(nBegIndex+1,sDbDate.lastIndexOf("-"))-1;
    var strDay;
    var strTime="";
    if (sDbDate.indexOf(" ")!=-1)
    {
        strDay = sDbDate.substring(sDbDate.lastIndexOf("-")+1,sDbDate.indexOf(" "));
        var strtimetemp=sDbDate.substring(sDbDate.indexOf(" ")+1,sDbDate.length);
        var index=strtimetemp.indexOf(":");
        var lastIndex=strtimetemp.lastIndexOf(":");

        if(index==lastIndex)
            strTime=strtimetemp;
        else
            strTime = sDbDate.substring(sDbDate.indexOf(" ")+1,sDbDate.lastIndexOf(":")+3);//gets the seconds as well

        if (strTime=="00:00:00")
            strTime="";
    }
    else
        strDay = sDbDate.substring(sDbDate.lastIndexOf("-")+1,sDbDate.length);

    var Hour = 0;
    var Min = 0;
    var Sec = 0;

    if(strTime.length>0)
    {
        Hour=strTime.substring(0,strTime.indexOf(":"));
        strTime=strTime.substring(strTime.indexOf(":")+1,strTime.length);

        Min=strTime.substring(0,strTime.indexOf(":"));
        Sec=strTime.substring(strTime.indexOf(":")+1,strTime.length);
    }

    var date=new Date(strYear,strMonth,strDay,Hour,Min,Sec);
    var dateMillis = date.valueOf();

    var MillisToAdd = (iMinutes-0)*60*1000;

    var newDateMillis = dateMillis+MillisToAdd;
    var newDate = new Date(newDateMillis);

    var newday = newDate.getDate();
    if (newday <10)
        newday= "0"+newday;

    var newmonth = newDate.getMonth() +1;
    if (newmonth <10) newmonth= "0"+newmonth;

    var newhr = newDate.getHours();
    if (newhr <10) newhr= "0"+newhr;

    var newmin = newDate.getMinutes();
    if (newmin <10) newmin= "0"+newmin;

    var nwsec = newDate.getSeconds();
    if (nwsec <10) nwsec= "0"+nwsec;

    var newDBDate = newDate.getFullYear()+ "-" + newmonth  + "-"+ newday +" " + newhr +":" +newmin +":" + nwsec ;

    return newDBDate;
}



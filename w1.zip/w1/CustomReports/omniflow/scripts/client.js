/*
		Product         :       OmniFlow
		Application     :       OmniFlow Processmanager
		Module          :       WorkList Window
		File            :       client.js
		Purpose         :       Contains the functions used for custom coding

		Change History  :

		Problem No        Correction Date	   Comments
		-----------       ----------------      ----------                
              05/12/2011              Dinesh Sharma        Bug 29774 - Hook to be provided in set diversion (in webdesktop) to get custom user list
              17/03/2015                                   Bug 54570 - Required to configure custom lin/SUb Custom link according to user/Group in processmanager
*/
function customUserList(strUname){
    /*
         strUname         :   Current Logged in Username
         userPersonalName :   User's personal name (to whom workitems to be reassigned)
         userName         :   User's name (to whom workitems to be reassigned) 
         userIndex        :   User's index (to whom workitems to be reassigned)
         return           :   false

         Usage:
              window.document.getElementById('diversions:txtUserName').value=userPersonalName;
              window.document.getElementById('diversions:hidUserName').value=userName;
              window.document.getElementById('diversions:hidUserId').value=userIndex;
  */   
return true;
}

function showMainSubMenu(parentId,linkId,linkName,strUserName){
 /* parentId : Id of the parent link
 *  linkId   : Id of the child/Sub link
 *  linkName : Name of the  child/Sub link
    strUserName : UserName of the logged-In user
*/   
 return true;
}

function showMainMenu(linkId,linkName,strUserName){ 
/*  linkId   : Id of the link
 *  linkName : Name of the link
    strUserName : UserName of the logged-In user
*/  
       return true; 
}

/*-----------------------------------------------------------------------------------------------------

File Name			: queueprocessauth.js
Author                          : Vijay Kumar
Date written (DD/MM/YYYY)       : 17/Nov/2008
Description			: This file contains the methods for handling the events from Queue Process Authorization.
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date(DD/MM/YYYY)		Change By               Change Description (Bug No. (If Any))
----------------------------------------------------------------------------------------------------
PRM_8.0_037       27/01/2010    Puneet Pahuja                   window.open changed to openNewWindow to open new window using HTTP POST
----------------------------------------------------------------------------------------------------*/

function SelectTabAuth(iSelTab)
{
     document.getElementById("queueprocessauth:hidSelTab").value=iSelTab;
     clickLink('queueprocessauth:cmdbtn_submit');
}

function showCommentDiv()
{
    var promptDiv = document.getElementById("divComment");
    try
    {
        document.getElementById("queueprocessauth:textcomment").value="";
     }catch(ex){}   
    var ParentDocWidth = document.body.clientWidth;
    var ParentDocHeight = document.body.clientHeight;

    var promptDivTop=ParentDocHeight/2-35;
    var promptDivLeft=ParentDocWidth/2-150;

    promptDiv.style.display="inline";
    promptDiv.style.left = promptDivLeft+"px";
    promptDiv.style.top = promptDivTop+"px";
    try
    {
        document.getElementById("queueprocessauth:textcomment").focus();;
     }catch(ex){} 
}

function AuthorizationOnClick(Operation)
{
    var tableID="queueprocessauth:dtAction";
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;    
    var AuthorizationIDs="";
    document.getElementById("queueprocessauth:hidSelectedOperation").value=Operation;
    try
    {
        var rowCount=document.getElementById(tableID).rows.length ;
        for (var iCount=0;iCount < (rowCount-1) ;iCount++)
        {
            var currentChkBoxID=tableID+":" + iCount +chkboxName ;
            var hidAuthorizationIDId=tableID+":" + iCount +":hidAuthorizationID";
            try 
            {
                if(document.getElementById(currentChkBoxID).checked)
                {
                    noOfSelectedRows++;
                    AuthorizationIDs=AuthorizationIDs+document.getElementById(hidAuthorizationIDId).value+",";
                }
            }
            catch(e)
            {}
        }
         if(noOfSelectedRows<=0)
        {
            alert("Please select some Entity");
        }
       AuthorizationIDs=AuthorizationIDs.substring(0,AuthorizationIDs.length-1);
       document.getElementById("queueprocessauth:hidSelectedAuthorizationIDs").value=AuthorizationIDs;
       showCommentDiv();
    }
    catch(e){}
   return false;
}

function AuthorizationAction(ref)
{
    //NewSubmit(ref);
   ClickAnotherLink(ref,'cmdbtn_AuthAction');
  //  ClickAnotherLink(ref,'cmdbtn_submit');
    hideCommentDiv();
    return false;
}

function hideCommentDiv()
{
    var promptDiv = document.getElementById("divComment");
    promptDiv.style.display="none";             
    return false;
}

function SelectDeselectAllAuthCheckBox(ref)
{
    var formid=ref.form.id;
    var tableid=formid+':dtAction';
    try 
    {
        var noofrows = document.getElementById(tableid).rows.length;
        var flag=0;
        for (var i=0;i< noofrows-1 ;i++)
        {
            var id=tableid+':'+i+':chkBox';
            document.getElementById(id).checked=ref.checked;
        }
    }
    catch(e){}
    UpdateAuthOperationsOnCheckBoxClick(ref);
    return false;
}

function UpdateAuthOperationsOnCheckBoxClick(ref)
{
    var tableID="queueprocessauth:dtAction";
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;    
    var operationFlag="";
    var selectedTab=document.getElementById("queueprocessauth:hidSelTab").value;
    try
    {
        var rowCount=document.getElementById(tableID).rows.length ;
        for (var iCount=0;iCount < (rowCount-1) ;iCount++)
        {
            var currentChkBoxID=tableID+":" + iCount +chkboxName ;
            var operationFlagID=tableID+":" + iCount +":hidOperationFlag";
            try 
            {
                if(document.getElementById(currentChkBoxID).checked)
                {
                    noOfSelectedRows++;
                    if(operationFlag=="")
                    {
                        operationFlag=document.getElementById(operationFlagID).value;
                    }    
                    else if(operationFlag!=document.getElementById(operationFlagID).value)
                    {
                        operationFlag="000";
                    }    
                }
            }
            catch(e)
            {}
        }
        
       if(selectedTab=="1")
       {
            var cmdApproveImg=document.getElementById("queueprocessauth:cmdApprove");
            var cmdRejectImg=document.getElementById("queueprocessauth:cmdReject");
            var cmdDismissImg=document.getElementById("queueprocessauth:cmdDismiss");
            if(operationFlag=="110")
            {
                cmdApproveImg.src='../omniflow/'+localizedPath+'images/approve.gif';
                cmdApproveImg.disabled=false;
                cmdRejectImg.src='../omniflow/'+localizedPath+'images/reject.gif';
                cmdRejectImg.disabled=false;
                cmdDismissImg.src='../omniflow/'+localizedPath+'images/dismiss_dis.gif';
                cmdDismissImg.disabled=true;
            }
            else if(operationFlag=="001")
            {
                cmdApproveImg.src='../omniflow/'+localizedPath+'images/approve_dis.gif';
                cmdApproveImg.disabled=true;
                cmdRejectImg.src='../omniflow/'+localizedPath+'images/reject_dis.gif';
                cmdRejectImg.disabled=true;
                cmdDismissImg.src='../omniflow/'+localizedPath+'images/dismiss.gif';
                cmdDismissImg.disabled=false;
            }
            else
            {
                cmdApproveImg.src='../omniflow/'+localizedPath+'images/approve_dis.gif';
                cmdApproveImg.disabled=true;
                cmdRejectImg.src='../omniflow/'+localizedPath+'images/reject_dis.gif';
                cmdRejectImg.disabled=true;
                cmdDismissImg.src='../omniflow/'+localizedPath+'images/dismiss_dis.gif';
                cmdDismissImg.disabled=true;
            }
      }
      else if(selectedTab=="2")
      {
        var cmdReinitiateImg=document.getElementById("queueprocessauth:cmdReinitiate");
        var cmdDiscardImg=document.getElementById("queueprocessauth:cmdDiscard");
        if(noOfSelectedRows>0)
         {
            cmdReinitiateImg.src='../omniflow/'+localizedPath+'images/reinitiate.gif';
            cmdReinitiateImg.disabled=false;
            cmdDiscardImg.src='../omniflow/'+localizedPath+'images/discard.gif';
            cmdDiscardImg.disabled=false;
         }
        else
        {
            cmdReinitiateImg.src='../omniflow/'+localizedPath+'images/reinitiate_dis.gif';
            cmdReinitiateImg.disabled=true;
            cmdDiscardImg.src='../omniflow/'+localizedPath+'images/discard_dis.gif';
            cmdDiscardImg.disabled=true;
        }
      }
    }
    catch(e){}
   return false;
}

function ShowActionDetail(AuthorizationId)
 {
    var selectedTab = document.getElementById("queueprocessauth:hidSelTab").value;   
    
   var url="../authorization/showauthdetails.faces";
    var WindowHeight=windowH+40;
    var WindowWidth=windowW+30;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    url = appendUrlSession(url);
    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=auto,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("AuthorizationID",encode_ParamValue(AuthorizationId)));
    listParam.push(new Array("SelectedTab",encode_ParamValue(selectedTab)));

    var win = openNewWindow(url,'actionDetail_'+AuthorizationId+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
	addWindows(win);
    }
    catch(e)
    {}

 }

function DisableQueueControls() {
    if(ActiveTab == 'QPG') {
        try{
        document.forms["QueueProperties_General"]["QueueProperties_General:optFifofetch"][0].disabled=true;
        }catch(e){}
        try{
        document.forms["QueueProperties_General"]["QueueProperties_General:optFifofetch"][1].disabled=true;
        }catch(e){}
        try{
        document.forms["QueueProperties_General"]["QueueProperties_General:optWipfetch1"].disabled=true;
        }catch(e){}
        try{
        document.forms["QueueProperties_General"]["QueueProperties_General:optWipfetch2"].disabled=true;
        }catch(e){}
        try{
        document.forms["QueueProperties_General"]["QueueProperties_General:optWipfetch3"].disabled=true;
        }catch(e){}
        try{
        document.getElementById("QueueProperties_General:chkAllowReassignment").disabled=true;
        }catch(e){}
        try{
        document.forms["QueueProperties_General"]["QueueProperties_General:optWorkitem_All"].disabled=true;
        }catch(e){}
        try{
        document.forms["QueueProperties_General"]["QueueProperties_General:optWorkitem_Equal"].disabled=true;
        }catch(e){}
        try{
        document.forms["QueueProperties_General"]["QueueProperties_General:optWorkitem_NotEqual"].disabled=true;
        }catch(e){}
        try{
        document.forms["QueueProperties_General"]["QueueProperties_General:queuefilter"].disabled=true;
        }catch(e){}
        try{
        document.getElementById("QueueProperties_General:cmbEqualTo").disabled=true;
        }catch(e){}
        try{
        document.getElementById("QueueProperties_General:cmbNotEqualTo").disabled=true;        
        }catch(e){}
        try{
        document.forms["QueueProperties_General"]["QueueProperties_General:optFifo"].disabled=true;        
        }catch(e){}
        try{
        document.forms["QueueProperties_General"]["QueueProperties_General:optWip"].disabled=true;        
        }catch(e){}
        try{
        document.getElementById("QueueProperties_General:txtQueueName").disabled=true;        
        }catch(e){}
        try{
        document.getElementById("QueueProperties_General:txtDescription").disabled=true;        
        }catch(e){}
        try{
        document.forms["QueueProperties_General"]["QueueProperties_General:optFifofetch"][0].disabled=true;        
        }catch(e){}
        try{
        document.forms["QueueProperties_General"]["QueueProperties_General:optFifofetch"][1].disabled=true;
        }catch(e){}
    }
    else if(ActiveTab == 'QPU') {
        
        try{
            document.getElementById("QueueProperties_User:cmdRemove").disabled=true;
            document.getElementById("QueueProperties_User:cmdRemove").src="../omniflow/"+localizedPath+"images/removedis.gif";
        }catch(e){}        
        try{
            document.getElementById("QueueProperties_User:cmdSetFilter").disabled=true;
            document.getElementById("QueueProperties_User:cmdSetFilter").src="../omniflow/"+localizedPath+"images/setfilterdis.gif";
        }catch(e){}    
        try{
            document.forms["QueueProperties_User"]["QueueProperties_User:optGroup"].disabled=true;            
        }catch(e){}   
        try{
            document.forms["QueueProperties_User"]["QueueProperties_User:optUser"].disabled=true;            
        }catch(e){}   
        try{
            document.getElementById("QueueProperties_User:cmdAdd").disabled=true;
            document.getElementById("QueueProperties_User:cmdAdd").src="../omniflow/"+localizedPath+"images/add_btndis.gif";
        }catch(e){}   
        try{
            document.getElementById("QueueProperties_User:cmdPicklist_Group").disabled=true;            
        }catch(e){}   
        try{
            document.getElementById("QueueProperties_User:cmdPicklist_User").disabled=true;            
        }catch(e){}   
    }
    
    else if(ActiveTab == 'QPS') {
        
        try{
            document.getElementById("QueueProperties_Stream:cmdRemove").disabled=true;
            document.getElementById("QueueProperties_Stream:cmdRemove").src="../omniflow/"+localizedPath+"images/removedis.gif";
        }catch(e){}   
        
        try{
            document.getElementById("QueueProperties_Stream:cmdAdd").disabled=true;
            document.getElementById("QueueProperties_Stream:cmdAdd").src="../omniflow/"+localizedPath+"images/add_btndis.gif";
        }catch(e){}   
        
        try{
            document.getElementById("QueueProperties_Stream:cmdPicklist_Queue").disabled=true;            
        }catch(e){} 
        
        
        }
}

function QueuepropertiesOnLoad()
{
   var pendingActions="";
   var arrPendingActions;
   try
    {
        pendingActions=document.getElementById("PendingActions").value;
    }catch(ex){}  
    
    if(pendingActions != "" && pendingActions.length>0)
     {
            var arrPendingActions = pendingActions.split(",");
            if(ActiveTab=='QPG')
            {
                for(var iCount=0;iCount<arrPendingActions.length;iCount++)
                {
                    if(arrPendingActions[iCount]=='51')
                        {
                            DisableQueueControls();
                            break;
                        }    
                }
            }
            else if(ActiveTab=='QPU')
            {
              for(var iCount=0;iCount<arrPendingActions.length;iCount++)
                {
                    if(arrPendingActions[iCount]=='60' ||arrPendingActions[iCount]=='61' ||arrPendingActions[iCount]=='77')
                        {
                            DisableQueueControls();
                            break;
                        }    
                }  
            }
            else if(ActiveTab=='QPS')
            {
               for(var iCount=0;iCount<arrPendingActions.length;iCount++)
                {
                    if(arrPendingActions[iCount]=='62' || arrPendingActions[iCount]=='63')
                        {
                            DisableQueueControls();
                            break;
                        }    
                } 
            }
    }
}
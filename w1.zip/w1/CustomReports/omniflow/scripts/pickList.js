/*-----------------------------------------------------------------------------------------------------

File Name			: pickList.js
Author                          : Vijay Kumar
Date written (DD/MM/YYYY)       : 26/Oct/2007
Description			: This file contains the methods for handling the events of picklist windows
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date(DD/MM/YYYY)		Change By               Change Description (Bug No. (If Any))
----------------------------------------------------------------------------------------------------
07/09/2016      		Ashutosh Pandey         Bug 64243 - Not able to click on filter textbox of picklist in processmanager in IE

----------------------------------------------------------------------------------------------------*/


/*----------------------------------------------------------------------------------------------------
//Function Name:		createIFrame
//Date Written 	:		27,oct 2007
//Author	:		Vijay Kumar
//Input Parameters:             event ,component id
//Output Parameters:            none
//Return Values	: 
//Description:			this function is used to handle enter
----------------------------------------------------------------------------------------------------*/
 function handlePickListEnter(e,id)
     {       
        var browser=navigator.appName;
        if(browser=="Netscape")
        {

            if(e.which == 13)
            {       
                try
                {
                    if(id != undefined)
                    {
                        window.document.getElementById(id).focus();
                    }
                    else
                    setValue();
                }
                catch(e){}
            }
        }
        else
        {      
            e=window.event;
            if(e.keyCode == 13)
            {
                try
                {
                    if(id != undefined)
                    {
                       window.document.getElementById(id).focus();
                    }
                    else
                    setValue();
                }
                catch(e){}
            }
        }
     }


function setPicklistFocus()
{
    try
    {
        parent.document.getElementById(CurrentPickListId).focus();
        if (isIE()) {
            try {
                var inputElement = parent.document.createElement("input");
                parent.pickListButtonObj.form.appendChild(inputElement);
                inputElement.focus();
                parent.pickListButtonObj.form.removeChild(inputElement);
            } catch (exc) {
            }
        }
    }
    catch(e){}
}
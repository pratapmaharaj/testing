/**************************************************************************************************************

		File            :       purge_criteria.js
		Purpose         :       Contains the functions for purge criteria.

		Change History  :

		Problem No        Correction Date	 Changed By		Comments
		-----------       ----------------   ----------    -----------------
                         26/02/2015       Ashutosh Pandey   Bug 53764 - Optimization at CS, ofservices and utility end to reduce the user level configuration and usage of single system utility user to perform each user level operation
*/
function setThenclick(ref,toClick)
{
    //saving the currently selected varable value
    var selId = document.getElementById("textForm:d:cmbEvariables").selectedIndex; 
    var val = document.getElementById("textForm:d:cmbEvariables").options[selId].value;
    document.getElementById("textForm:hidSelQueryVar").value = val;
 
    var rowcount = document.getElementById("textForm:d:advFilterTable").rows.length;
    
    if(rowcount==1)
        document.getElementById("textForm:hidJoinCondition").value = "N";
    else if(rowcount>1)
        document.getElementById("textForm:hidJoinCondition").value = "Y";

    
    selId = document.getElementById("textForm:cmbworkstep").selectedIndex;
    val = document.getElementById("textForm:cmbworkstep").options[selId].value;
    document.getElementById("textForm:hidSelActivity").value=val;
 
    
    
    var selectedtab=document.getElementById("textForm:hidSelTab").value;    
     document.getElementById("textForm:d:hidSelTab").value=selectedtab;
    createTempDataXML();
  clickLink("textForm:addQuery1");
 
}

//added by Jaseem

function searchOnFile(ref,toClick)
{
    
   if(!validateserach())
       return false;
    //Saving the value of filename
     document.getElementById("textForm:hidfilename").value=document.getElementById("textForm:txtfilename").value;

    //Saving the value of operator
    var selId = document.getElementById("textForm:cmboperator").selectedIndex;
    var val = document.getElementById("textForm:cmboperator").options[selId].value;
    document.getElementById("textForm:hidcmboperator").value = val;
     selId = document.getElementById("textForm:cmbworkstep").selectedIndex;
     val = document.getElementById("textForm:cmbworkstep").options[selId].value;
    document.getElementById("textForm:hidSelActivity").value=val;

    //Saving the Exported Date time

    document.getElementById("textForm:hidExpDateTime").value=document.getElementById("textForm:txtExpDateTime").value;
    document.getElementById("textForm:hidActivityId").value=document.getElementById("textForm:cmbworkstep").selectedIndex;

    document.getElementById("textForm:hidSearch").value="Y";
    document.getElementById("textForm:hidSelSubTab").value=1;
    clickLink("textForm:cmd_searchOnFile");
}
function validateserach(){
    if(document.getElementById("textForm:txtfilename").value.length==0)
    {
        if(document.getElementById("textForm:cmboperator").selectedIndex==0){
            alert(ENTER_FILE_NAME);
            return false;
        }
        else{
            var val=document.getElementById("textForm:txtExpDateTime").value;
           
           
             var ret = ValidateDateFormat(val,DateFormat);
             
             if(ret==0){
               document.getElementById("textForm:txtExpDateTime").focus() ;
               return false;
            }
    }

}
else if(document.getElementById("textForm:txtfilename").value.length > 0)
    {
        if(document.getElementById("textForm:cmboperator").selectedIndex>0) {
             val=document.getElementById("textForm:txtExpDateTime").value;
              ret = ValidateDateFormat(val,DateFormat);
             if(ret==0){
               document.getElementById("textForm:txtExpDateTime").focus() ;
               return false;
            }
    }
}
return true;
}
function SelectSubTab(val)
{
    //Saving the value of subtab
    if(val==2){
         var noofrows = document.getElementById("textForm:fileNameTab").rows.length;
         var count=0;
         var selId;
        genrateFileXml();
          for (var i=0;i< noofrows-1 ;i++)
        {

            var id="textForm:fileNameTab"+':'+i+':chkfile';
            if(document.getElementById(id).checked)
                {
                    count++;
                    selId = "textForm:fileNameTab"+':'+i+':fileNames';
                   
                    
                }
        }
        if(count==0){
            alert(PLEASE_SELECT_A_FILE_TO_VIEW_RECORDS);
            return false;
        }
        else if(count>1){
            alert(PLEASE_SELECT_SINGLE_FILE);
            return false;
        }
        else
        var selfilename=document.getElementById(selId).innerHTML;

        document.getElementById("textForm:hidSelFileName").value=selfilename;
        document.getElementById("textForm:hidSelSubTab").value=val;
        clickLink("textForm:cmd_subtab");
    }
    if(val==1){
         document.getElementById("textForm:hidSelSubTab").value=val;
         clickLink("textForm:cmd_subtab");
    }
    
}


function prevClick(){
 clickLink("textForm:cmd_prev");
}
function nextClick(){
  clickLink("textForm:cmd_next");
}
function reGenerateRecord(){
    var selectetab=document.getElementById("textForm:hidSelTab").value;
    if(selectetab==1){
        var noofrows=document.getElementById("textForm:fileNameTab").rows.length;
        var strXml="";
         var count=0;
         var selId;
          for (var i=0;i< noofrows-1 ;i++)
        {

            var id="textForm:fileNameTab"+':'+i+':chkfile';

            if(document.getElementById(id).checked)
                {
                    count++;
                    selId = "textForm:fileNameTab"+':'+i+':fileNames';
                    var selfilename=document.getElementById(selId).innerHTML;
                    strXml=strXml+"<File>"+selfilename+"</File>";


                }
        }
        if(count==0){
            alert(PLEASE_SELECT_A_FILE_TO_REGENRATE_RECORDS);
            return false;
        }
       
    }

    if(selectetab==2){
        var noofrows=document.getElementById("textForm:pidTable").rows.length;
        var strXml="";
         var count=0;
         var selId;
          for (var i=0;i< noofrows-1 ;i++)
        {

            var id="textForm:pidTable"+':'+i+':chkrecord';

            if(document.getElementById(id).checked)
                {
                    count++;
                    selId = "textForm:pidTable"+':'+i+':pid';
                    var processInstanceId=document.getElementById(selId).innerHTML;
                    strXml=strXml+"<Record>"+processInstanceId+"</Record>";


                }
        }
        if(count==0){
            alert(PLEASE_SELECT_A_FILE_TO_REGENRATE_RECORDS);
            return false;
        }
        
    }
    if(confirm(DO_YOU_WISH_TO_REGENERATE_RECORD)){
     document.getElementById("textForm:hidxml").value=strXml;
    clickLink("textForm:cmd_regenrateRecord");
    }
    else
        return false;
}
function purgeData(){
    var selectetab=document.getElementById("textForm:hidSelTab").value;
    if(selectetab==1){
        var noofrows=document.getElementById("textForm:fileNameTab").rows.length;
        var strXml="";
         var count=0;
         var selId;
          for (var i=0;i< noofrows-1 ;i++)
        {

            var id="textForm:fileNameTab"+':'+i+':chkfile';

            if(document.getElementById(id).checked)
                {
                    count++;
                    selId = "textForm:fileNameTab"+':'+i+':fileNames';
                    var selfilename=document.getElementById(selId).innerHTML;
                    strXml=strXml+"<File>"+selfilename+"</File>";


                }
        }
        if(count==0){
            alert(PLEASE_SELECT_A_FILE_TO_PURGE_DATA);
            return false;
        }

      //  alert("strXml = "+strXml);
    }

    if(selectetab==2){
        var noofrows=document.getElementById("textForm:pidTable").rows.length;
        var strXml="";
         var count=0;
         var selId;
          for (var i=0;i< noofrows-1 ;i++)
        {

            var id="textForm:pidTable"+':'+i+':chkrecord';

            if(document.getElementById(id).checked)
                {
                    count++;
                    selId = "textForm:pidTable"+':'+i+':pid';
                    var processInstanceId=document.getElementById(selId).innerHTML;
                    strXml=strXml+"<Record>"+processInstanceId+"</Record>";


                }
        }
        if(count==0){
            alert(PLEASE_SELECT_A_FILE_TO_PURGE_DATA);
            return false;
        }
        
    }
     if(confirm(DO_YOU_WISH_TO_PURGE_DATA)){
            document.getElementById("textForm:hidxml").value=strXml;
            clickLink("textForm:cmd_purgeData");
     }
      else
        return false;
}

function SelectCheckBoxes(ref)
{
    var formid=ref.form.id;
    var tableid=formid+':d:advFilterTable';
    try
    {
        var noofrows = document.getElementById(tableid).rows.length;

        var flag=0;
        for (var i=0;i< noofrows-1 ;i++)
        {

            var id=tableid+':'+i+':chkFilter';
            document.getElementById(id).checked=ref.checked;
        }

        return '';
    }
    catch(e)
    {
        //alert(e);
        return "";
    }
}
function SelectCheckBoxesPurgeList(ref)
{
    var formid=ref.form.id;
    var tableid=formid+':purgeLists';

    try
    {
        var noofrows = document.getElementById(tableid).rows.length;

        var flag=0;
        for (var i=0;i< noofrows-1 ;i++)
        {

            var id=tableid+':'+i+':chkBox';
            document.getElementById(id).checked=ref.checked;
        }

        return '';
    }
    catch(e)
    {
        //alert(e);
        return "";
    }
}
function checkRowData(ref,toClick)
{

   
    var tableID = 'textForm:d:advFilterTable';
    var table = document.getElementById(tableID);

    var rowCount = 0;
    var chkBoxID=tableID+":";
    var currentChkBoxID="";
    var noOfSelectedRows=0;
    var selectedIndexes="";
    var submitFlag = false;
    rowCount = table.rows.length;

    if(rowCount <= 1)
    {
        submitFlag = false;
        return false;
    }
    else
    {

        for (var iCount=0;iCount < (rowCount-1) ;iCount++)
        {
                currentChkBoxID=chkBoxID + iCount +":chkFilter" ;
                try
                {
                        if(document.getElementById(currentChkBoxID).checked)
                        {
                                noOfSelectedRows++;
                                if(selectedIndexes.length > 0)
                                        selectedIndexes=selectedIndexes + ":"+ iCount ;
                                else
                                        selectedIndexes = iCount +"";

                         }


                }
                catch(e)
                {
                    selectedIndexes ="";
                    noOfSelectedRows=0;
                }
        }
    }

    if(noOfSelectedRows == 0)
    {
        alert(SEL_FIELD_TO_DELETE);
        submitFlag = false;
        return false;
    }
    else
    {
        submitFlag = true;
        
        document.getElementById("textForm:hidSelvarList").value = selectedIndexes;
    }
    if(submitFlag == true)
      clickLink("textForm:remQuery");

}

function GetTitles(thisEle,Type)//checked
{
	var strTitle;
	var strType = Type;
	switch(strType)
	{
		case "10":
			strTitle = INSERT_STR_VAL;
			break;
		case "B":
			strTitle = INSERT_BOOL_VAL;
			break;
		case "8":
			tempDteFormat = DateFormat;
			strTitle = INSERT_DATE_VAL+" '"+DateFormat+"'";
			break;
		case "3":
			strTitle = INSERT_INT_VAL;
			break;
		case "6":
			strTitle = INSERT_DEC_VAL;
			break;
		case "T":
			strTitle = INSERT_RAW_VAL;
			break;
		case "4":
			strTitle = INSERT_INT_VAL;
			break;
		default:
	}
		thisEle.title = strTitle;
var indx = parseInt(thisEle.name.lastIndexOf(':'));
//var tempstr1 = thisEle.name.substring(0,indx)+":assignOperator";
//var tempstr2 = thisEle.name.substring(0,indx)+":dateTypeVariables";
//var operator1 =  document.getElementById(tempstr1).selectedIndex;
//var varvalue1 =  document.getElementById(tempstr2).selectedIndex;
//if(operator1 != "0" || varvalue1 != "0") thisEle.title = "Please INSERT Integer Values";
}

function clickCommandLink()
    {
        
  var ref = document.getElementById("textForm");
  if(document.getElementById("textForm:pid").value.length==0){
            if(CheckDataAndCreateXMLs(ref)){
                
                    if(document.getElementById("textForm:hidDataXML").value.length==0)
                        {
                         alert(ENTER_PROCESSINSTANCE_ID);
                         return false;
                        }
                        else
                            {
                                var selId = document.getElementById("textForm:cmbworkstep").selectedIndex;
                                var val = document.getElementById("textForm:cmbworkstep").options[selId].value;
                                document.getElementById("textForm:hidSelActivity").value=val;
                               document.getElementById("textForm:hidActivityId").value=document.getElementById("textForm:cmbworkstep").selectedIndex;
                               document.getElementById("textForm:hidPid").value=document.getElementById("textForm:pid").value;
                               clickLink("textForm:cmd_searchOnFile");
                               return true;
                            }
            }

            else
                return false;
  }
    else{
           if(CheckDataAndCreateXMLs(ref))
                {
                                var selId = document.getElementById("textForm:cmbworkstep").selectedIndex;
                                var val = document.getElementById("textForm:cmbworkstep").options[selId].value;
                                document.getElementById("textForm:hidSelActivity").value=val;

                        document.getElementById("textForm:hidActivityId").value=document.getElementById("textForm:cmbworkstep").selectedIndex;
                        document.getElementById("textForm:hidPid").value=document.getElementById("textForm:pid").value;
                        clickLink("textForm:cmd_searchOnFile");
                    return true;
        }
        else
            return false;
    }
                    
            
   

}
function CheckDataAndCreateXMLs(ref)
{
   
      //validate inputs for Purge data
        if(!ValidateProcessData())
            return false;

        if(!createDataXML())
			return false;
    return true;
}
function createDataXML()
{
    var tmpFieldList = "";
    var strTempXml = "";
    var strData ="";

    var prefix ="textForm:d:";
    var txtForm = document.getElementById("textForm");
    var stradvsearch="N";
    var tablePrefix="";
    var entryFlag=false;
     stradvsearch="Y";
     tablePrefix = prefix+"advFilterTable";
    var rowCount = -1;
    rowCount = document.getElementById(tablePrefix).rows.length;

 
    if(rowCount > 1)
    {
        var iCount=0;

        var varvalue="";
        for(iCount=0 ; iCount < (rowCount-1) ; iCount++)
        {
            var varname = document.getElementById(tablePrefix+":"+iCount+":VarName").innerHTML;
            var vartype = document.getElementById(tablePrefix+":"+iCount+":VarType").value;
            var varlength = document.getElementById(tablePrefix+":"+iCount+":VarLength").value;
            var varoperator="";
            var varoperator1="";
            var vartype1="10";
            var varjoincond="";
            var varopenparenthesis="";
            var varcloseparenthesis="";
            var selIndex = -1;
            var strXML ="";

                varvalue = document.getElementById(tablePrefix+":"+iCount+":procfilterData").value;
                

                selIndex = document.getElementById(tablePrefix+":"+iCount+":advCmbOperator").selectedIndex;
                varoperator = document.getElementById(tablePrefix+":"+iCount+":advCmbOperator").options[selIndex].value;

               if(document.getElementById(tablePrefix+":"+iCount+":procfilterData").value=="")
                {
                    alert(BLANK_FIELD_VALUE);
					 return false;
                }
              
                selIndex = document.getElementById(tablePrefix+":"+iCount+":advCmbOperator").selectedIndex;
                varoperator = document.getElementById(tablePrefix+":"+iCount+":advCmbOperator").options[selIndex].value;
                if(iCount!=0)
                {
                    selIndex = document.getElementById(tablePrefix+":"+iCount+":advCmbJoin").selectedIndex;
                    varjoincond = document.getElementById(tablePrefix+":"+iCount+":advCmbJoin").options[selIndex].value;
                 }
                selIndex = document.getElementById(tablePrefix+":"+iCount+":openparaenthesis").selectedIndex;
                varopenparenthesis = document.getElementById(tablePrefix+":"+iCount+":openparaenthesis").options[selIndex].value;
                selIndex = document.getElementById(tablePrefix+":"+iCount+":closeparaenthesis").selectedIndex;
                varcloseparenthesis = document.getElementById(tablePrefix+":"+iCount+":closeparaenthesis").options[selIndex].value;
                if(Trim(varvalue)=='')
                    entryFlag = true;

            if(vartype == '8' )
            {
                varvalue = LocalToDB(varvalue,DateFormat);

            }

               if(varopenparenthesis=="Y")
               strXML = strXML + appendTagAndValue("OpenBracket","Y");
               else
               strXML = strXML + appendTagAndValue("OpenBracket","N");

                strXML = strXML + appendTagAndValue(VarName,varname);
                strXML = strXML + appendTagAndValue(VarType,vartype);
                strXML = strXML + appendTagAndValue(Length,varlength);
                strXML = strXML + appendTagAndValue(VarValue,varvalue);
                strXML = strXML + appendTagAndValue(Operator,varoperator);
                
                if(varcloseparenthesis=="Y")
                strXML = strXML + appendTagAndValue("CloseBracket","Y");
                else
                strXML = strXML + appendTagAndValue("CloseBracket","N");
                if(iCount!=0)
                strXML = strXML + appendTagAndValue(JoinCondition,varjoincond);

                 tmpFieldList += appendTagAndValue("Field",strXML);
         }
         if(tmpFieldList != "")
		strData = tmpFieldList
        }
     
    
     document.getElementById("textForm:hidDataXML").value=strData;
    
     document.getElementById("textForm:hidProcessName").value=document.getElementById("textForm:txtProcessName").value;
     

	return true;
    }

function appendTagAndValue(tagName,tagValue)
{
    var tagAndValue="";
    if(tagValue != "")
        tagAndValue = "<" + tagName + ">" + tagValue + "</" + tagName + ">";
    return tagAndValue;
}
function ValidateProcessData()
{
     
    var prefix ="textForm:d:";
    var tablePrefix="";
    var criCount="";
    tablePrefix = prefix+"advFilterTable";
    var rowCount = -1;
    rowCount = document.getElementById(tablePrefix).rows.length;
   
    var elementId="";
    var varvalue="";
    var varvalue1="";
    if(rowCount > 1)
    {
        var iCount=0;
        for(iCount=0 ; iCount < (rowCount-1) ; iCount++)
        {
            var varname = document.getElementById(tablePrefix+":"+iCount+":VarName").innerHTML;
            
            var vartype = document.getElementById(tablePrefix+":"+iCount+":VarType").value;
           
            var varlength = document.getElementById(tablePrefix+":"+iCount+":VarLength").value;
           
               varvalue = document.getElementById(tablePrefix+":"+iCount+":procfilterData").value;
               
               elementId = tablePrefix+":"+iCount+":procfilterData";
              

            if(Trim(varvalue)!='')
              {
                  if(vartype == '3')
                   {
                       if(!IsNumericVal(varvalue))
                         {
                            alert(INVALID_NUMERIC_VALUE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                         }
                        else if (varvalue<-Math.pow(2,31) || varvalue>(Math.pow(2,31)-1))
                        {
                            alert(INDEX_VALUE_OUT_OF_RANGE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                        }
                    }
                else if(vartype == '4')
                {
                    if(!IsNumericVal(varvalue))
                    {
                            alert(INVALID_NUMERIC_VALUE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
                    else if (varvalue<-Math.pow(2,31) || varvalue>(Math.pow(2,31)-1))
                    {
                            alert(INDEX_VALUE_OUT_OF_RANGE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
                }
                else if(vartype == '6')
                {
                    if(isNaN(varvalue))
                    {
                            alert(INVALID_NUMERIC_VALUE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
                    else if (varvalue< parseFloat("-1.79e+308") || varvalue> parseFloat("+1.79e+308"))
                    {
                            alert(INDEX_VALUE_OUT_OF_RANGE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
                }
               else if(vartype == '8' && varvalue != '')
                {
                    var ret = ValidateDateFormat(varvalue,DateFormat);
                    if(ret==0)
                    {
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
               }
           
            else if(vartype == '10')
            {
                    if ( (varvalue.indexOf('\u00ff') != -1) || (varvalue.indexOf('\u00fc') != -1) ||(varvalue.indexOf('\u00b5') != -1) || (varvalue.indexOf('<') != -1) || (varvalue.indexOf('>') != -1) )
                    {
                            alert(INVALID_STRING);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
            }
          } // if Trim
      } // for loop ends
    } //rowCount > 1

    return true;

}//fucn ends

function setPurgeWiOption()
{
	if(document.getElementById("textForm:chkPurgeWiData").checked)
	{

		if(document.getElementById("textForm:chkExport").checked)
			document.getElementById("textForm:chkExportWiData").disabled=false;

	}
	else
	{
		document.getElementById("textForm:chkExportWiData").checked = false;
		document.getElementById("textForm:chkExportWiData").disabled=true;

	}
}

function setPurgeDocOption()
{
	if(document.getElementById("textForm:chkPurgeDocData").checked)
	{
		if(document.getElementById("textForm:chkExport").checked)
			document.getElementById("textForm:chkExportDocData").disabled=false;
	}
	else
	{
		if(!ISExport)
                {
                    document.getElementById("textForm:chkExportDocData").checked = false;
                    document.getElementById("textForm:chkExportDocData").disabled= true;
                }
        }
}


function setExportOptions()
{

	if(document.getElementById("textForm:chkExport").checked)
	{
               document.getElementById("textForm:chkExportWiData").disabled = false;
	       document.getElementById("textForm:chkExportExtData").disabled = true;
		if(document.getElementById("textForm:chkExportWiData").checked)
		{
			document.getElementById("textForm:chkExportWiData").disabled = false;
			document.getElementById("textForm:chkExportWiData").checked = true;
			document.getElementById("textForm:chkExportExtData").disabled = false;
			document.getElementById("textForm:chkExportExtData").checked = true;
		}
		if(document.getElementById("textForm:chkExportDocData").checked || ISExport)
                {
			document.getElementById("textForm:chkExportDocData").disabled = false;
                        document.getElementById("textForm:chkExportDocData").checked = true;
                 }
	}
	else
	{
		document.getElementById("textForm:chkExportWiData").checked = false;
		document.getElementById("textForm:chkExportWiData").disabled = true;
        document.getElementById("textForm:chkExportExtData").checked = false;
		document.getElementById("textForm:chkExportExtData").disabled = true;
		document.getElementById("textForm:chkExportDocData").checked = false;
		document.getElementById("textForm:chkExportDocData").disabled = true;
	}
}

function viewPurgeCriteria(ProcessDefId, ProcessName, Version, CriteriaName)
{

    var Url="../processmgmt/purgecriteria.faces";
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("operation",encode_ParamValue("U")));
    listParam.push(new Array("processdefid",encode_ParamValue(ProcessDefId)));
    listParam.push(new Array("procName",encode_ParamValue(ProcessName)));
    listParam.push(new Array("version",encode_ParamValue(Version)));
    listParam.push(new Array("criteriaName",encode_ParamValue(CriteriaName)));

    var win = openNewWindow(Url,"purgecriteria"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
            addWindows(win);
    }
    catch(e)
    {}
}
function AddPurgeCriteria()
{
    var formID="purgemgt";
    var pidlist= new Array();
    var tableID=formID+":"+"purgeLists";
   
    var noOfSelectedRows=0;
    var processID="";
    var processName="";
    try
    {
        var rowCount=document.getElementById(tableID).rows.length ;
        var processIDId;
        var processNameId;
        var name;
        for (var iCount=0;iCount < (rowCount-1) ;iCount++)
        {
                //currentChkBoxID=tableID+":" + iCount +chkboxName ;
                processIDId=tableID+":" + iCount +":ProcessDefId";
                name = tableID+":" + iCount +":ProcessDefId";
                //processNameId=tableID+":" + iCount +":procName";
                pidlist +=document.getElementById(processIDId).value+",";
        }
     }
     catch(e)
     {
                 //alert("Error in=="+iCount);
      }
     var Url="../processmgmt/purgecriteria.faces";
     Url = appendUrlSession(Url);
     var ScreenHeight=screen.height;
     var ScreenWidth=screen.width;
     var WindowHeight=window1H;
     var WindowWidth=window1W;
     var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
     var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

     var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

     var listParam=new Array();
     listParam.push(new Array("operation",encode_ParamValue("I")));
     listParam.push(new Array("pidList",encode_ParamValue(pidlist)));

     var win = openNewWindow(Url,"purgecriteria"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
     try
     {
        addWindows(win);
     }
     catch(e)
     {}
}
function DeletePurgeCriteria(ref, toClick)
{
    var formID="purgemgt";
    var sPidList='' ;

    var tableID=formID+":"+"purgeLists";
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;
    var processID="";
    var processName="";

    try
    {
    var rowCount=document.getElementById(tableID).rows.length ;
    var processIDId;
    var processNameId;
    var operation;
    var name;

    for (var iCount=0;iCount < (rowCount-1) ;iCount++)
    {
            currentChkBoxID=tableID+":" + iCount +chkboxName ;
            processIDId=tableID+":" + iCount +":ProcessDefId";
            operation = tableID+":" + iCount +":Operation";
            if(document.getElementById(currentChkBoxID).checked)
            {
            sPidList +=document.getElementById(processIDId).value+",";

            document.getElementById("purgemgt:hidOperation").value="D";
            }

    }
    }
    catch(e)
            {
                            //alert("Error in=="+iCount);
            }

    if(sPidList == "")
    {
            alert(SELECT_CRITERIA_TO_DELETE);
            return false;
    }

    var bConfirm = confirm(CONFIRM_PURGE_DELETE);
    if(!bConfirm)
            return false;

    sPidList = sPidList.substring(0,sPidList.length -1);
    document.getElementById("purgemgt:pidList").value=sPidList;
    document.getElementById("purgemgt:hidOperation").value = "D";
    ClickAnotherLink(ref,toClick);

}
function setExpDataOption()
{

	if(document.getElementById("textForm:chkExportWiData").checked)
        {

          document.getElementById("textForm:chkExportExtData").disabled=false;
        }
        else
        {
          document.getElementById("textForm:chkExportExtData").checked = false;
          document.getElementById("textForm:chkExportExtData").disabled=true;
        }
}
function genrateFileXml(){
    var noofrows = document.getElementById("textForm:fileNameTab").rows.length;
    var fileXml='<?xml version="1.0"?><Files>';
           for (var i=0;i< noofrows-1 ;i++)
        {

            var id= "textForm:fileNameTab"+':'+i+':fileNames';
            var value=document.getElementById(id).innerHTML;
            fileXml=fileXml+appendTagAndValue("File",value);
            if(i==0){
               var firstvalue=value;
            }
            if(i==(noofrows-2)){
                var lastvalue=value;
            }

        }
        fileXml=fileXml+'</Files>';
        if(prev=='true')
             fileXml=fileXml+appendTagAndValue("Prev","Y");
         else
             fileXml=fileXml+appendTagAndValue("Prev","N");
         if(next=='true')
             fileXml=fileXml+appendTagAndValue("Next","Y");
         else  
             fileXml=fileXml+appendTagAndValue("Next","N");

             fileXml=fileXml+appendTagAndValue("FirstValue",firstvalue);
             fileXml=fileXml+appendTagAndValue("LastValue",lastvalue);
          // alert("fileXml = "+fileXml);
        document.getElementById("textForm:hidfilexml").value=fileXml;
}
function createTempDataXML()
{
    var tmpFieldList = "";
    var strTempXml = "";
    var strData ="";

    var prefix ="textForm:d:";
    var txtForm = document.getElementById("textForm");
    var stradvsearch="N";
    var tablePrefix="";
    var entryFlag=false;
     stradvsearch="Y";
     tablePrefix = prefix+"advFilterTable";
    var rowCount = -1;
    rowCount = document.getElementById(tablePrefix).rows.length;

    if(rowCount > 1)
    {
        var iCount=0;

        var varvalue="";
        for(iCount=0 ; iCount < (rowCount-1) ; iCount++)
        {
            var varname = document.getElementById(tablePrefix+":"+iCount+":VarName").innerHTML;
            var vartype = document.getElementById(tablePrefix+":"+iCount+":VarType").value;
            var varlength = document.getElementById(tablePrefix+":"+iCount+":VarLength").value;
            var varoperator="";
            var varoperator1="";
            var vartype1="10";
            var varjoincond="";
            var varopenparenthesis="";
            var varcloseparenthesis="";
            var selIndex = -1;
            var strXML ="";

                varvalue = document.getElementById(tablePrefix+":"+iCount+":procfilterData").value;
                 selIndex = document.getElementById(tablePrefix+":"+iCount+":advCmbOperator").selectedIndex;
                varoperator = document.getElementById(tablePrefix+":"+iCount+":advCmbOperator").options[selIndex].value;
               
            
                selIndex = document.getElementById(tablePrefix+":"+iCount+":advCmbOperator").selectedIndex;
                varoperator = document.getElementById(tablePrefix+":"+iCount+":advCmbOperator").options[selIndex].value;
                if(iCount!=0)
                {
                    selIndex = document.getElementById(tablePrefix+":"+iCount+":advCmbJoin").selectedIndex;
                    varjoincond = document.getElementById(tablePrefix+":"+iCount+":advCmbJoin").options[selIndex].value;
                 }
                selIndex = document.getElementById(tablePrefix+":"+iCount+":openparaenthesis").selectedIndex;
                varopenparenthesis = document.getElementById(tablePrefix+":"+iCount+":openparaenthesis").options[selIndex].value;
                
                selIndex = document.getElementById(tablePrefix+":"+iCount+":closeparaenthesis").selectedIndex;
                varcloseparenthesis = document.getElementById(tablePrefix+":"+iCount+":closeparaenthesis").options[selIndex].value;
                if(Trim(varvalue)=='')
                    entryFlag = true;


               if(varopenparenthesis=="Y")
               strXML = strXML + appendTagAndValue("OpenBracket","Y");
               else
               strXML = strXML + appendTagAndValue("OpenBracket","N");

                strXML = strXML + appendTagAndValue(VarName,varname);
                strXML = strXML + appendTagAndValue(VarType,vartype);
                strXML = strXML + appendTagAndValue(Length,varlength);
                strXML = strXML + appendTagAndValue(VarValue,varvalue);
                strXML = strXML + appendTagAndValue(Operator,varoperator);
                if(varcloseparenthesis=="Y")
                strXML = strXML + appendTagAndValue("CloseBracket","Y");
                else
                strXML = strXML + appendTagAndValue("CloseBracket","N");
                if(iCount!=0)
                strXML = strXML + appendTagAndValue(JoinCondition,varjoincond);

                 tmpFieldList += appendTagAndValue("Field",strXML);
         }
         if(tmpFieldList != "")
		strData = tmpFieldList
        }
     document.getElementById("textForm:hidDataXML").value=strData;
  
     document.getElementById("textForm:hidProcessName").value=document.getElementById("textForm:txtProcessName").value;
     

	return true;
    }
  /*
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : WNS-GMAC
Module : SBR
File Name : Common.js
Author :   Tarit kumar gupta
Date written (DD/MM/YYYY) :
Description : 
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date			Change By		Change Description (Bug No. (If Any))
(DD/MM/YYYY)

27/06/2008		Bhawna Gupta	Res_6
11/07/2008		Product Team	Res_15
----------------------------------------------------------------------------------------------------
 Bug No:SBR_3:If zero is the prefix of any amount then its value get changed on blur in hexadecimal value.
 Bug No:SBR_7:Reconcilation From date and Reconcilation To date should not be future date.
 Change No:SBR_8 : Future dates to be disabled in calender.
*/ 

document.onkeydown = KeyDownHandler;
function KeyDownHandler(evt)
{
	//alert(window.event.keyCode);
	if(window.event.keyCode==27)
	{
		return false;
	}
}

function ShowCalendar(obj)
{	
	//Commented by Santosh : 5/7/2012
	/*alert(obj);
	alert(wdesk.obj);
	wdesk.all[obj].value =  "";	*/

	document.getElementById(obj).value="";
	

	
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";
	sDate	= window.showModalDialog('/webdesktop/webtop/GMAC/Calendar/Calendar.htm',document.getElementById(obj).value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');
	if(sDate!="")
	{

	tempdate=convertdate(sDate);
	document.getElementById(obj).value = tempdate;
	//alert(dataform.all[obj].value);
	
	}
	
}

//Added for SBR_8 by Bhawna
function ShowCalendar_Validate(obj)
{
	
	//alert("ssshow calendarrr..");
	
	//alert(obj);
	//dataform.obj.value =  "";	
	dataform=document.getElementById(obj).value="";
	//alert("till here.."+dataform);
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";
	sDate	= window.showModalDialog('/webdesktop/webtop/GMAC/Calendar/Calendar_Validate.htm',dataform+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');
	//alert();
	if(sDate!="")
	{
//alert("sDate"+sDate);
	tempdate=convertdate(sDate);
	document.getElementById(obj).value= tempdate;
	//alert(dataform.all[obj].value);
	
	}
	
}

function ShowCalendar_PastValidate(obj)
{	
	
	document.getElementById(obj).value="";

	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";

	
	sDate = window.showModalDialog('/webdesktop/webtop/GMAC/Calendar/Calendar_PastValidate.htm',document.getElementById(obj).value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');
	
	if(sDate!="")
	{

		tempdate=convertdate(sDate);
		document.getElementById(obj).value = tempdate;
	}
	
}

function RegExChk(objControl,cat)
{
	switch(cat)
	{
		case "alpha":re = /[^a-zA-Z]/g;break;
		case "float":re = /[^0-9.]/g;break;
		case "alphanumeric":re = /[^a-zA-Z0-9\n\r\s(-),.'"]/g;break;
		case "integer":re = /[^0-9]/g;break;
	}
	if(re.test(objControl.value))
	{
		objControl.value = objControl.value.replace(re, "");
		objControl.focus;
	}

}

function trim(str) 
{ 
	//alert("Error:This is not an alert!!!!");
	var i=0;
	var j=0;
	for (i=0;i < str.length;i++) 
	{  //alert(str.charAt(i));
		if (str.charAt(i) != ' ') 
			break; 
	} 

	for (j=str.length - 1;j>= 0; j--) 
	{ 
		if (str.charAt(j) != ' ') 
		break; 
	}

	if (j < i) j = i-1; str = str.substring(i, j+1); 
	//alert(str);
		return str; 
} 

/*function validateKeys(e,act)
{
	switch(act) 
	{
	   case "alpha":re = /[^a-z]+/i;break;
	   case "numeric":re = /[^0-9]+/i;break;
	   case "alphanumeric":re = /[^a-z0-9]+/i;break;
   }
	if(re.test(e.value))
	  e.value = e.value.replace(re, "")
	e.focus()
}
*/
function validateKeys(e,act)
{
	
 var keynum = e.keyCode;
// alert(keynum);
var	keychar = String.fromCharCode(keynum);
//alert(keychar);
	switch(act) 
	{
	   case "alpha":re = /[^a-z]+/i;break;
	   case "numeric":re = /[^0-9]+/i;break;
	   case "alphanumeric":re = /[^a-z0-9]+/i;break;
	   case "alphanumeric3":re = /[^a-z0-9-]+/i;break;
	   case "float":re= /[^0-9.]+/i;break;
	   case "EmailChek":re= /[^a-z0-9.@_]+/i;break;
	   case "floatnegative":re= /[^0-9.-]+/i;break;
	   

   }

   //alert(re.test(keychar));
   return (!re.test(keychar));
	//if(re.test(e.value))
	//  e.value = e.value.replace(re, "")
	//e.focus()
}

function validateKeys_OnBlur(e,act)
{ 
	
	var sFinalString="";
	//alert(e.value);
	var btypemismatch=false;
	if(e.value!=undefined)
	{
		for(var i=0;i<e.value.length;i++)
		{
			var	keychar = e.value.charAt(i);
			
			switch(act) 
			{
			   case "alpha":re = /[^a-z]+/i;break;
			   case "numeric":re = /[^0-9]+/i;break;
			   case "alphanumeric":re = /[^a-z0-9]+/i;break;
			   case "alphanumeric3":re = /[^a-z0-9-]+/i;break;
			   case "alphanumeric4":re = /[^a-z0-9-,]+/i;break;
			   case "float":re= /[^0-9.]+/i;break;
			   case "floatwithcomma":re = /[^0-9.,]+/i;break;
			   case "floatnegative":re= /[^0-9.-]+/i;break;
			   case "floatnegcomma":re= /[^0-9.,-]+/i;break;
		   }
		   
		  if(!(re.test(keychar)) && keychar != "")
			sFinalString+=keychar;
		}
   e.value=sFinalString;
	}
}

/*function validateKeys_OnBlur(e,act)
{ 

	
	if (e.value != "")
		{
		switch(act) 
			{
			case "alpha":re = /[^a-zA-Z. ]+/i;break;
			case "numeric":re = /[^0-9]+/i;break;
			case "float":re= /[^0-9.]+/i;break;
			case "alphanumeric":re = /[^a-z0-9 ]+/i;break;
			case "alphanumeric1":re = /[^0-9-, ]+/i;break;
			case "alphanumeric2":re = /[^a-z0-9.,+#-\/ ]+/i;break;
			case "alphanumeric3":re = /[^a-z0-9-]+/i;break;
			case "alphanumeric4":re = /[^a-z0-9-,]+/i;break;
			
			}
		if(re.test(e.value))
			{
			e.value = e.value.replace(re, "");

			e.focus();
			//e.select();
			return false;
			}
		}
	return true;
}*/


function validate_toupper(e)
{  
    var i=0;
	for(i=0;i<e.value.length;i++)
	{
		e.value=e.value.toUpperCase();
		
	}
	
	return true;
}


function imposeMaxLength(Object, MaxLen)
{
	//alert("stage01"+Object.value.length);
  return (Object.value.length < MaxLen);
}



function txtarea_onblur(obj) {
/*Validate textarea length before submitting the form*/

var maxChar = 255
if (obj.value.length > maxChar) {
diff=obj.value.length - maxChar;
if (diff>1)
diff = diff + " characters";
else
diff = diff + " character";

alert("This field is limited to " + maxChar + " characters\n" + "Please reduce the text by " + diff);
obj.focus();
return (false);
}
}


//Parameter
//	1. Objcontrol	: The field(Object) on the form for which this function is called
// Function validates the function is float and only spcific numbr of digits can be enetred before and after decimal point 
//----------------------------------------------------------------------------------------------------
//Function Name                    : floattest(object,number,number)
//Date Written (DD/MM/YYYY)        : 05-NOV-2007
//Author                           : Vishal Sardana
//Return Values                    : string(returns true or false)
//Description                      : returns string.
//----------------------------------------------------------------------------------------------------

function floattest(objControl,beforedecimal,afterdecimal)
{
var objafterdec;
var objbeforedec;
var i;
var count=0;
for (i=0;i<=objControl.value.length;i++)
{
 m=objControl.value.charAt(i);
//alert(m);
if(objControl.value.charAt(i)=='.')
{
 count ++;
}
}
if(count >1)
{
alert("This field is float enter only one decimal point");
objControl.focus();
  objControl.select();
	return false;
}

if(objControl.value.indexOf(".")!=-1)
{
	objafterdec=objControl.value.substring(objControl.value.indexOf(".")+1,objControl.value.length);
	objbeforedec=objControl.value.substring(0,objControl.value.indexOf("."));
	//alert("objbeforedec"+objbeforedec);
	if(objafterdec.length >afterdecimal)
	{
	  alert("Only " +afterdecimal + " digit allowed after decimal");
	  objControl.focus();
	  objControl.select();
		return false;		
	}/*else if(objafterdec.length==0)
			{
				//alert(objafterdec.length);	
				objControl.value=objControl.value+"00";
			}
	else if(objafterdec.length==1)
			{
				//alert(objafterdec.length);	
				objControl.value=objControl.value+"0";
			}*/

	if(objbeforedec.length>beforedecimal)
	{
	  alert("Only " + beforedecimal + " digit allowed before decimal");
	  objControl.focus();
	  objControl.select();
		return false;		
	}
}
else
{
if(objControl.value.length > beforedecimal)
	{
		alert("Only " + beforedecimal + " digit allowed before decimal");
		objControl.focus();
		objControl.select();
		return false;	
	}


}

return true;
}




function floattestwithcoma(objControl,beforedecimal,afterdecimal)
{
var objafterdec;
var objbeforedec;
var i;
var count=0;
for (i=0;i<=objControl.value.length;i++)
{
 m=objControl.value.charAt(i);
//alert(m);
if(objControl.value.charAt(i)=='.')
{
 count ++;
}
}
if(count >1)
{
alert("This field is float enter only one decimal point");
objControl.focus();
  objControl.select();
	return false;
}

if(objControl.value.indexOf(".")!=-1)
{
	objafterdec=objControl.value.substring(objControl.value.indexOf(".")+1,objControl.value.length);
	objbeforedec=objControl.value.substring(0,objControl.value.indexOf("."));
	//alert("objbeforedec"+objbeforedec);
	if(objafterdec.length >afterdecimal)
	{
	  alert("Only " +afterdecimal + " digit allowed after decimal");
	  objControl.focus();
	  objControl.select();
		return false;		
	}/*else if(objafterdec.length==0)
			{
				//alert(objafterdec.length);	
				objControl.value=objControl.value+"00";
			}
	else if(objafterdec.length==1)
			{
				//alert(objafterdec.length);	
				objControl.value=objControl.value+"0";
			}*/

	if(objbeforedec.length>beforedecimal)
	{
	  alert("Only " + beforedecimal + " digit allowed before decimal");
	  objControl.focus();
	  objControl.select();
		return false;		
	}
}
else
{
if(objControl.value.length > beforedecimal)
	{
		alert("Only " + beforedecimal + " digit allowed before decimal");
		objControl.focus();
		objControl.select();
		return false;	
	}


}

return true;
}

//Parameter
//	1. sLocalDate	: Date to be passed as input parameter in  format dd/mm/yyyy where mm in numeric
// Function returns date in dd/mmm/yyyy format
//----------------------------------------------------------------------------------------------------
//Function Name                    : convertdate(string)
//Date Written (DD/MM/YYYY)        : 05-NOV-2007
//Author                           : Vishal Sardana
//Input Parameters                 : String
//Output Parameters                : String
//Return Values                    : string
//Description                      : returns string.
//----------------------------------------------------------------------------------------------------
function convertdateold(sLocalDate)
{
	//alert("sLocalDate"+sLocalDate);
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	//alert(nBegIndex);
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	//alert("strtempdate"+strtempdate);
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	//alert("strdate"+strdate);
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	//alert("stryear"+stryear);
	//alert(strdate);
	var strMonth="";
	
		if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	strResult=strdate+"/"+strMonth+"/"+stryear;
	alert(strResult);
	return strResult;
}

//Parameter
//	1. sLocalDate	: Date to be passed as input parameter in  format yyyy-mm-dd 00:00:00 where mm in numeric
// Function returns date in dd/mmm/yyyy format
//----------------------------------------------------------------------------------------------------
//Function Name                    : convertdate(string)
//Date Written (DD/MM/YYYY)        : 06-NOV-2007
//Author                           : Vishal Sardana
//Input Parameters                 : String
//Output Parameters                : String
//Return Values                    : string
//Description                      : returns string.
//----------------------------------------------------------------------------------------------------
function convertdatenew(sLocalDate)
{  
	//alert(sLocalDate);
	var sDateSeparator="-";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	var strMonth = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	//var strdate = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.indexOf("00:00")-1);
	var strdate = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator)+3);
	//alert(strdate);
	var stryear = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
//	alert("strMonth:"+strMonth);
	//alert("strdate:"+strdate);
	//alert("stryear:"+stryear);
	//var strMonth="";
	//strMonth=strtempdate;

	/*	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";*/

	
	strResult=strMonth+"/"+strdate+"/"+stryear;
	return strResult;


}
function convertdatenew_Mig(sLocalDate)
{  
	//alert(sLocalDate);
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	var strMonth = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	//var strdate = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.indexOf("00:00")-1);
	var strdate = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator)+3);
	//alert(strdate);
	var stryear = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
//	alert("strMonth:"+strMonth);
	//alert("strdate:"+strdate);
	//alert("stryear:"+stryear);
	//var strMonth="";
	//strMonth=strtempdate;

	/*	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";*/

	
	strResult=strMonth+"/"+strdate+"/"+stryear;
	return strResult;


}
function isModified(oldVal,newVal)
{
	
	if(oldVal.value!=newVal)
	{
		oldVal.value=newVal;
		oldVal.modified_flag=true;
	}
}


function combos(objWI_objwi,objDataForm)
{ 
	alert('In Combo');
	try
	 {
	
		for ( i=0; i < objDataForm.elements.length ; i++)
		{	
				
				var InputName=objDataForm.elements[i].name;
		
				if(objDataForm.elements[i].type=="select-one" )
				{	
					
					var FieldName=InputName;
					
					var value=objDataForm.elements[i].value;
					
					
					isModified(objWI_objwi.attribute_list[FieldName],value);
				}
				else if(objDataForm.elements[i].type=="radio")
				{          
					var FieldName=InputName;
					var value=objDataForm.elements[i].value;
					if(objDataForm.elements[i].checked)
					{
						isModified(objWI_objwi.attribute_list[FieldName],value);
					}
					
							
				}
				else if(objDataForm.elements[i].type=="textarea")
				{
					
					var FieldName=InputName;
					var value=objDataForm.elements[i].value;
					
					isModified(objWI_objwi.attribute_list[FieldName],value);
					
				}
			
		}
		
		return true;
	}
	catch(e)
	{		
			alert(e.message);
			return false;
	}
	
}

function fClear(obj)
{ 
	if (navigator.appName.indexOf("Netscape")>-1)
		code = event.which;
	else if((navigator.appName.indexOf("Microsoft")>-1) || (navigator.appName.indexOf("MSIE")>-1))
		code = event.keyCode;

	if (code==46)
		{	
		if(obj.readonly==false)
		document.forms[0].all[obj].value="";
		}
	else if(code==8)
		{
		event.returnValue =false;
		}	
}

function ExceptionCleared()
{
var objWI_Obj=window.top.wi_object;
var objDataForm=window.parent.frames['left'].document.forms["wdesk"];
var test = objWI_Obj.exception_list;
var len =  test.length;
	for(var i=0;i<len;++i)
	{//alert("hfgh: "+objDataForm.RejectWI.value);
		  if (test[i].type == 'VC' && test[i].status == 'R' && objDataForm.RejectWI.value!='Yes')
		  {
			  alert ("Clear all the raised exceptions.");
			  return false; 
		  }
	}
return true;
}

/// the ajax code to insert data at the time when QC fails

function ServerRequest(url,sData)
{	
	
	iAjaxMainCode ="" ;
	sAjaxReturnValue = "";
	// Create the XML request 
    xmlReq = null;
    if(window.XMLHttpRequest) xmlReq = new XMLHttpRequest();
    else if(window.ActiveXObject) xmlReq = new ActiveXObject("Microsoft.XMLHTTP");
    if(xmlReq==null) 
	{
		alert("Browser is not supported");
		return;
	} 	
    xmlReq.onreadystatechange = function()
    {
		if (xmlReq.readyState == 4) 
		{
		
			if (xmlReq.status == 200) 
			{
				
			//xmlReq.responseXML.loadXML(xmlReq.responseText.substring(xmlReq.responseText.indexOf("<"),xmlReq.responseText.length));
				//alert("iAjaxMainCode : "+iAjaxMainCode);
				iAjaxMainCode = xmlReq.responseXML.getElementsByTagName('MainCode')[0].firstChild.data;
				
	
				if (xmlReq.responseXML.getElementsByTagName('ReturnValue')[0].firstChild!=null)
				{
					
					sAjaxReturnValue = xmlReq.responseXML.getElementsByTagName('ReturnValue')[0].firstChild.data;
			
					//alert("Data Returned : "+xmlReq.responseXML.getElementsByTagName('ReturnValue')[0].firstChild);
				}
				
			}
		}
    }
	// Make the request
	//alert("VS1");
	xmlReq.open ('POST', url, false);
	xmlReq.setRequestHeader('Content-Type','application/x-www-form-urlencoded');	
	xmlReq.send(sData); 
}

function ServerRequest1(URL,sData)
{
	//alert("New value");
	iAjaxMainCode="";
	sAjaxReturnValue="" ;	
	var xmlReq = null;
	if (window.XMLHttpRequest)
	{
		xmlReq = new XMLHttpRequest();
	}
	else if(window.ActiveXObject)
	{
		xmlReq = new ActiveXObject("Microsoft.XMLHTTP");	
	}
	if(xmlReq==null) 
	{
		alert("Browser is not supported");
		return;
	} 
	//alert("xmlReq : "+xmlReq);
	xmlReq.onreadystatechange = function()
    {
		if (xmlReq.readyState == 4) 
		{
			if (xmlReq.status == 200) 
			{
				var xmldoc = null;
				if ( window.ActiveXObject )
				 {   
						xmldoc = xmlReq.responseText;
						xmlHTTPResponse = xmldoc;
				}
				else
				{
						var parser = new DOMParser();
						xmldoc = parser.parseFromString( xmlReq.responseXML, "text/xml" );
				}
				if( sData != null && sData != undefined )
				{
						
						var ReturnValue = RetriveData(xmldoc) ;
						
						var ReturnValueArr = ReturnValue.split(',');
						if(ReturnValueArr[0] == '0')
						{
							sAjaxReturnValue = ReturnValueArr[1];
						}
						else
						{
							alert("Unable to retrive the value !!!\nClose the browser and delete cookies by pressing CTRL + F5 !!!\nIf problem persists then your browser does not support the application !!!");
							sAjaxReturnValue = "Unsuccess";
						}
				} 
				else
				{
						alert('NO Data');
				}
			}
		}
    }
	xmlReq.open ('POST', URL, false);
	xmlReq.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	xmlReq.send(sData);
	//return sAjaxReturnValue;
}

function dollarAmount(field)
{ 

	
Num = "" + field.value;


dec = Num.indexOf("."); 
end = ((dec > -1) ? "" + Num.substring(dec,Num.length) : ".00");

Num = "" + parseInt(Num);



if (checkNum(Num) == 0) {

} 
else {
if (end.length > 2) end=end.substring(0,3); 
if (end.length == 2) end += "0"; 
if (end.length == 1) end += "00"; 
if (end == "") end += ".00";

field.value=Num + end; 
 return field.value;
   } 

   
}



function checkNum(data) {      // checks if all characters
var valid = "0123456789.";     // are valid numbers or a "."
var ok = 1; var checktemp;
for (var i=0; i<data.length; i++) {
checktemp = "" + data.substring(i, i+1);
if (valid.indexOf(checktemp) == "-1") return 0; }
return 1;
}

function checkNumOnly(data) {      // checks if all characters
var valid = "0123456789";     // are valid numbers 
var ok = 1; var checktemp;
for (var i=0; i<data.length; i++) {
checktemp = "" + data.substring(i, i+1);
if (valid.indexOf(checktemp) == "-1") return 0; }
return 1;
}

function AnnotateDate()
{
	objApplet=window.top.frames[0].frames[3].frames["doctypes_bottom"].document.IVApplet;
	if(objApplet!=undefined)
		objApplet.showDynamicTextStamp("",.5,.5,"TimesRoman",1,18,6633,0,false,true,true,true);
		//objApplet.showTextStamp(0,.5, .5, true, false, true);
}

function Check_Mandatory_Doctype()
{
	

	try
	{ 
	 var length=window.parent.frames['right'].document.frames['doctypes_center'].document.forms["textForm"].doctype;//Change No:Res_15
	 var objwi=window.top.wi_object;
     //alert(window.parent.frames['right'].document.frames['doctypes_center'].document.forms["textForm"].doctype);
	  if(window.parent.frames['right'].document.frames['doctypes_center'].document.forms["textForm"].doctype==undefined)
		{
		  	alert("No Document is associated with the Workitem.");
			return false;

		}
	return true;	
	}
	catch(e)
    {}
}

/*..............................................................*/

function dollarAmount_comma(field)
{ 

/*.........For Removing Comma From The string(BY DILIP).........*/
 var sNet_Cost=field.value;
 var sAmount="";
 for (var i=0; i<sNet_Cost.length; i++)
  {
   if(sNet_Cost.substring(i,i+1)!=",")
    sAmount =sAmount + sNet_Cost.substring(i, i+1);
  }

 
/*..................Comma is removed..........................*/

Num = "" + sAmount;


dec = Num.indexOf("."); 

//if(Num.substring(0,dec))
//end = ((dec >-1) ? "" + Num.substring(dec,Num.length) : ".000");
 if(dec>-1)
	{
	end="" + Num.substring(dec,Num.length);
	//alert("end:"+end);
	}
 else if(Num.length=="")
	{
	end="";
 
	}
	else
		end=".000";

//Num = "" + parseInt(Num);
if(dec > -1)
	Num=Num.substring(0,Num.indexOf("."));

//alert(Num);




var temp1 = ""; 
var temp2 = "";

if (checkNum(Num) == 0) {

} 
else {
	
if (end.length > 3) end=end.substring(0,4); 
if (end.length == 3) end += "0"; 
if (end.length == 2) end += "00"; 
if (end.length == 1) end += "000";


if (Num.length!="" && end =="") end += ".000";
var count = 0; 
for (var k = Num.length-1; k >= 0; k--) { 
	
var oneChar = Num.charAt(k); 
if (count == 3) { 
temp1 += ","; 
temp1 += oneChar; 
count = 1; 
continue; 
} 
else { 
temp1 += oneChar; 
count ++; 
   } 
}

for (var k = temp1.length-1; k >= 0; k--) { 
var oneChar = temp1.charAt(k); 
temp2 += oneChar; 
} 
temp2 = temp2 + end; 
//alert("temp2--" + temp2); 
field.value=temp2; 


 return field.value;
   } 

   
}
function dollarAmount_comma_SBR(field)
{ 

/*.........For Removing Comma From The string(BY DILIP).........*/
 var sNet_Cost=field.value;
 var sAmount="";
 for (var i=0; i<sNet_Cost.length; i++)
  {
   if(sNet_Cost.substring(i,i+1)!=",")
    sAmount =sAmount + sNet_Cost.substring(i, i+1);
  }
 
/*..................Comma is removed..........................*/

Num = "" + sAmount;


dec = Num.indexOf("."); 
end = ((dec > -1) ? "" + Num.substring(dec,Num.length) : ".00");
Num = "" + parseInt(Num);


var temp1 = ""; 
var temp2 = "";

if (checkNum(Num) == 0) {

} 
else {
if (end.length > 2) end=end.substring(0,3); 
if (end.length == 2) end += "0"; 
if (end.length == 1) end += "00"; 
if (end == "") end += ".00";

var count = 0; 
for (var k = Num.length-1; k >= 0; k--) { 
var oneChar = Num.charAt(k); 
if (count == 3) { 
temp1 += ","; 
temp1 += oneChar; 
count = 1; 
continue; 
} 
else { 
temp1 += oneChar; 
count ++; 
   } 
}

for (var k = temp1.length-1; k >= 0; k--) { 
var oneChar = temp1.charAt(k); 
temp2 += oneChar; 
} 
temp2 = temp2 + end; 
//alert("temp2--" + temp2); 
field.value=temp2; 

 return field.value;
   } 

   
}
/*......................................end of Function...........................*/

function floattest_comma(objControl,beforedecimal,afterdecimal)//Change:Res_6
{
//alert("afterdecimal");
var objafterdec;
var objbeforedec;
var i;
var count=0;


/*.........For Removing Comma From The string(BY DILIP).........*/
var sNet_Cost=objControl.value;
  var sAmount="";
 for (var i=0; i<sNet_Cost.length; i++)
  {
   if(sNet_Cost.substring(i,i+1)!=",")
    sAmount =sAmount + sNet_Cost.substring(i, i+1);
  }
 
/*..................Comma is removed..........................*/
objControl.value=sAmount;
//alert("objControl.value"+objControl.value);




for (i=0;i<=objControl.value.length;i++)
{
	 m=objControl.value.charAt(i);
	//alert(m);
	if(objControl.value.charAt(i)=='.')
	{
	 count ++;
	}
	

}
if(count >1)
{
	alert("This field is float enter only one decimal point");
	objControl.focus();
  objControl.select();
	return false;
}

if(count==1 && objControl.value.length==1)
{
	alert("Only decimal is not allowed.");
	objControl.focus();
	objControl.select();
	return false;

}
if(objControl.value.indexOf(".")!=-1)
{
	objafterdec=objControl.value.substring(objControl.value.indexOf(".")+1,objControl.value.length);
	//alert("objafterdec"+objafterdec);
	objbeforedec=objControl.value.substring(0,objControl.value.indexOf("."));
	//alert("objbeforedec"+objbeforedec);
	//alert("objbeforedec"+objbeforedec);
	if(objafterdec.length >afterdecimal)
	{
	  alert("Only " +afterdecimal + " digit allowed after decimal");
	  objControl.focus();
	  objControl.select();
		return false;		
	}/*else if(objafterdec.length==0)
			{
				//alert(objafterdec.length);	
				objControl.value=objControl.value+"00";
			}
	else if(objafterdec.length==1)
			{
				//alert(objafterdec.length);	
				objControl.value=objControl.value+"0";
			}*/

	if(objbeforedec.length>beforedecimal)
	{
	  alert("Only " + beforedecimal + " digit allowed before decimal");
	  objControl.focus();
	  objControl.select();
		return false;		
	}
}
else
{
if(objControl.value.length > beforedecimal)
	{
		alert("Only " + beforedecimal + " digit allowed before decimal");
		objControl.focus();
		objControl.select();
		return false;	
	}


}

return true;
}

function checknegative(field)
{  // alert("Indid"+field.value.length);
var count=0;
var str=field.value;
	for (var i=0;i<field.value.length ;i++ )
		{	
			if (str.charAt(i) == '-')
			{	//alert("count"+count);
				if(count!="0")
					{
						alert("Please enter a valid negative value");
						field.focus();
						field.select();
						return false;
					}
				else
					{
						//alert(str.indexOf(str.charAt(i)));
						if(str.indexOf(str.charAt(i))=='0')
						count++;
						else
						{
						alert("Please enter a valid negative value");
						field.focus();
						field.select();
						return false;
						}
					}
			}
		}
return true;	

}

function RemoveComma(objFld)
{

		sNewValue="";
		for (var i=0; i<objFld.value.length; i++)
		{
			if(objFld.value.substring(i,i+1)!=",")
				sNewValue=sNewValue+ objFld.value.substring(i, i+1);
		}
		//alert(sAmount);	
		objFld.value=sNewValue;
		return sNewValue;
}
function RemoveComma_SBR(objFld)
{
	//alert("tarit");
	//alert("dd "+objFld);
		
		sNewValue="";
		for (var i=0; i<objFld.length; i++)
		{
			if(objFld.substring(i,i+1)!=",")
				sNewValue=sNewValue+ objFld.substring(i, i+1);
		}
		//alert(sAmount);	
		//objFld=sNewValue;
		return sNewValue;
}

function checkzero(obj)
{
	if(obj.value!="")
	{
		if(obj.value.substring(0,1)==0)
		{
			alert("First digit cannot be zero");
			obj.focus();
			obj.select();
			return false;
		}
	}

}

function DollarAmount_commaNeg(field)
{ 

/*.........For Removing Comma From The string(BY DILIP).........*/
 var sNet_Cost=field.value;
 var sAmount="";
var bIsNegative=sNet_Cost.substring(0,1)=='-'?true:false;
if(bIsNegative)
	sNet_Cost=sNet_Cost.substring(1,sNet_Cost.length);
 for (var i=0; i<sNet_Cost.length; i++)
  {
   if(sNet_Cost.substring(i,i+1)!=",")
    sAmount =sAmount + sNet_Cost.substring(i, i+1);
  }
 
/*..................Comma is removed..........................*/

Num = "" + sAmount;


dec = Num.indexOf("."); 
end = ((dec > -1) ? "" + Num.substring(dec,Num.length) : ".00");
Num = "" + parseInt(Num);


var temp1 = ""; 
var temp2 = "";

if (checkNum(Num) == 0) {

} 
else {
if (end.length > 2) end=end.substring(0,3); 
if (end.length == 2) end += "0"; 
if (end.length == 1) end += "00"; 
if (end == "") end += ".00";

var count = 0; 
for (var k = Num.length-1; k >= 0; k--) { 
var oneChar = Num.charAt(k); 
if (count == 3) { 
temp1 += ","; 
temp1 += oneChar; 
count = 1; 
continue; 
} 
else { 
temp1 += oneChar; 
count ++; 
   } 
}

for (var k = temp1.length-1; k >= 0; k--) { 
var oneChar = temp1.charAt(k); 
temp2 += oneChar; 
} 
temp2 = temp2 + end; 
if(bIsNegative)
	temp2="-"+temp2;
//alert("temp2--" + temp2); 
field.value=temp2; 
 return field.value;
   } 

   
}



function floattest_commaNeg(objControl,beforedecimal,afterdecimal)
{
var objafterdec;
var objbeforedec;
var i;
var count=0;


/*.........For Removing Comma From The string(BY DILIP).........*/
var sNet_Cost=objControl.value;
var bIsNegative=sNet_Cost.substring(0,1)=='-'?true:false;
if(bIsNegative)
	sNet_Cost=sNet_Cost.substring(1,sNet_Cost.length);
  var sAmount="";
 for (var i=0; i<sNet_Cost.length; i++)
  {
   if(sNet_Cost.substring(i,i+1)!=",")
    sAmount =sAmount + sNet_Cost.substring(i, i+1);
  }
 

/*..................Comma is removed..........................*/
objControl.value=sAmount;
//alert("objControl.value"+objControl.value);




for (i=0;i<=objControl.value.length;i++)
{
	 m=objControl.value.charAt(i);
	//alert(m);
	if(objControl.value.charAt(i)=='.')
	{
	 count ++;
	}
	
}
if(count >1)
{
	if(bIsNegative)
		sAmount="-"+sAmount;
	objControl.value=sAmount;
	alert("This field is float enter only one decimal point");
	
	objControl.focus();
  objControl.select();
	return false;
}


if(count==1 && objControl.value.length==1)
{
	if(bIsNegative)
		sAmount="-"+sAmount;

	objControl.value=sAmount;
	alert("Only decimal is not allowed.");
	
	objControl.focus();
	objControl.select();
	return false;

}
if(objControl.value.indexOf(".")!=-1)
{
	objafterdec=objControl.value.substring(objControl.value.indexOf(".")+1,objControl.value.length);
	objbeforedec=objControl.value.substring(0,objControl.value.indexOf("."));
	//alert("objbeforedec"+objbeforedec);
	if(objafterdec.length >afterdecimal)
	{
	  if(bIsNegative)
		sAmount="-"+sAmount;
	  objControl.value=sAmount;
	  alert("Only " +afterdecimal + " digit allowed after decimal");
	  objControl.focus();
	  objControl.select();
		return false;		
	}/*else if(objafterdec.length==0)
			{
				//alert(objafterdec.length);	
				objControl.value=objControl.value+"00";
			}
	else if(objafterdec.length==1)
			{
				//alert(objafterdec.length);	
				objControl.value=objControl.value+"0";
			}*/

	if(objbeforedec.length>beforedecimal)
	{
	  if(bIsNegative)
		sAmount="-"+sAmount;
	  objControl.value=sAmount;
	   alert("Only " + beforedecimal + " digit allowed before decimal");
	 
	  objControl.focus();
	  objControl.select();
	 
		return false;		
	}
}
else
{
if(objControl.value.length > beforedecimal)
	{
		if(bIsNegative)
		sAmount="-"+sAmount;
		objControl.value=sAmount;
		alert("Only " + beforedecimal + " digit allowed before decimal");
		objControl.focus();
		objControl.select();
		return false;	
	}


}
if(bIsNegative)
		sAmount="-"+sAmount;
objControl.value=sAmount;
return true;
}


//Parameter
//	1. sLocalDate	: Date to be passed as input parameter in  format dd/mm/yyyy where mm in numeric
// Function returns date in mm/dd/yyyy format
//----------------------------------------------------------------------------------------------------
//Function Name                    : convertdate(string)
//Date Written (DD/MM/YYYY)        : 05-NOV-2007
//Author                           : Vishal Sardana
//Input Parameters                 : String
//Output Parameters                : String
//Return Values                    : string
//Description                      : returns string.
//----------------------------------------------------------------------------------------------------
function convertdate(sLocalDate)
{
	//alert("sLocalDate"+sLocalDate);
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	//alert(nBegIndex);
	 
	var strMonth = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	//alert("strtempdate"+strtempdate);
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	//alert("strdate"+strdate);
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	//alert("stryear"+stryear);
	//alert(strdate);
	//var strMonth=strtempdate;
	//alert(strtempdate);
	
		
	

	strResult=strMonth+"/"+strdate+"/"+stryear;
	return strResult;
}



function trim_Start_Zero(obj)//Added as on 06/06/2008 to resolve the Bug No:SBR_3:If zero is the prefix of any amount then its value get changed on blur in hexadecimal value.
{
var temp=obj.value;
if((parseFloat(obj.value))!=0)
	{
		//alert("nonzero");
		while(temp.charAt(0)=="0")
		{
			temp=temp.substring(1,temp.length);

		}
		
	}
	if(temp.charAt(0)==".")
		{
			temp="0"+temp;

		}

		obj.value=temp;
	}
function ChkFutureDate(FormDate,dateField)//Bug No:SBR_7
{
	
	var Form_Date=FormDate.value;
	//alert(FormDate);
	var CurrDate=new Date();
	var date=CurrDate.getDate();
	var month=CurrDate.getMonth()+1;
	var year=CurrDate.getYear();
	
	
	
	var Form_Date_month=Number(Form_Date.substring(Form_Date.indexOf("0"),Form_Date.indexOf("/")));	
	
	var Form_Date_date=Number(Form_Date.substring(Form_Date.indexOf("/")+1,Form_Date.lastIndexOf("/")));
	
	
	var Form_Date_year=Number(Form_Date.substring(Form_Date.lastIndexOf("/")+1,Form_Date.length));
	
	

	if(year<Form_Date_year)
	{
		alert(dateField+" can not be future Date.");
		FormDate.select();
		return false;
	}
	else if(year>=Form_Date_year)
	{
		if(Form_Date_month>month)
		{
			alert(dateField+" can not be future Date.");
		FormDate.select();
		return false;
		}
		else if(Form_Date_month==month)
		{
			if(date<Form_Date_date)
			{
				alert(dateField+" can not be future Date.");
		FormDate.select();
		
		return false;
			}
		}
	}
	
return true;



}

function openCMReport(folderName,jspName)
{	
	
	//alert("QueueRep new");
 	var sFeatures = "dialogHeight:850px; dialogWidth:850px; status:no; dialogHide:no;"; 
	//var sFeatures = 'height=255,width=250,toolbar=no,directories=no,status=no,continued from previous linemenubar=no,scrollbars=no,resizable=no,modal=yes';

	//var sReturnInfo= window.showModalDialog("\\webdesktop\\CustomForms\\reports\\CustomReports\\TACMQueueStatusReport\\TACMQueueStatusReport.jsp",sFeatures);
	//alert(jspName);
	//var sReturnInfo= window.showModalDialog("\\webdesktop\\CustomReports\\reports\\CustomReports\\"+folderName+"\\"+jspName,sFeatures);
	window.open("\\webdesktop\\CustomReports\\reports\\CustomReports\\"+folderName+"\\"+jspName, "_blank", "toolbar=no,scrollbars=yes,resizable=no,top=25px,left=250px,width=850px,height=650px");
	
//var url = sContextPath+ '/faces/CustomForms/reports/CustomReports/TACM_ApprovalReport/TACMApprovalReport.jsp?browser='+browser+'&browserVersion='+browserVersion+'&processRightsFlag='+'Y'+'&isSearch='+'Y'+'&WD_UID='+wd_uid;
}
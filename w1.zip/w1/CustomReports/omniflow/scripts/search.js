/*-----------------------------------------------------------------------------------------------------

File Name			: search.js
Author                          : Sachin Agrawal
Date written (DD/MM/YYYY)       : 9/Feb/2007
Description			: This file contains the methods used by the search pages.
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date(DD/MM/YYYY)		Change By               Change Description (Bug No. (If Any))
----------------------------------------------------------------------------------------------------
21/04/2007                  Arup Sharma                 BUG 550 (session id appended in all the window.open url's by calling method :appendUrlSession())
23/04/2007                  Arup Sharma                 BUG 608 (SaveResult())
30/04/2007                  Arup Sharma                 BUG 606 RE (value from hidden used instead of innerHTML)
26/02/2008                  Puneet Pahuja               bug id-3719    
03/10/2008                  Vijay kumar                 Bug Id PRM_7.1_001
03/11/2008                  Vijay Kumar                 PRM_7.1_002
07 Aug 2008                 Arup Sharma                 BUG ID BAM_007 (For Time Zone)
03/10/2011                  Mohd Jaseem                 To route the completed workitem in flow(Bug 28560)
20/10/2015                                              Bug 57474 - "Locked By" is enabled if "Locked Status" is selected as "No" in Process Manager[Search] window 
02/17/2016                                              Bug 59204 - Refer WIs should not be reassigned from ProcessManager.
03/08/2016                  Jaseem Ansari               Bug 63471   In processmanager,It is required to replace the WFSearch call with WMFetchWorklist call on queue search in advanced search window
----------------------------------------------------------------------------------------------------*/
var SelectedSearchWi="";        //bug id-3719

function SelectTab(tabid,ref)
{
    //get the current selected tab and call the respective method

    var curTabid = document.getElementById('search:SelTab').value;
    if(curTabid==1)
    {
        if(!checkDataValidity(ref))  //validate for all process and all queue.Bug Id PRM_7.1_001
           return false; 
        //validate inputs for gen tab
        createGeneralXML();
        //alert(document.getElementById("search:hidGeneralXML").value);
    }
    else if(curTabid==2)
    {
        //validate inoputs for date tab
        if(!VerifyDates(ref))
            return false;
    }
    else if(curTabid==3)
    {
        //validate inputs for data tab
      if(!ValidateProcessData())
      return false;

      createDataXML();
        
    }
    
  /*  if(tabid==3)
    {
        if(!checkDataValidity(ref))
           return false; 
    }*/
    
    //now simply call the respective method.
    document.getElementById('search:PrevSelTab').value = document.getElementById('search:SelTab').value;
    document.getElementById('search:SelTab').value=tabid;
    ClickAnotherLink(ref,'selectTab');
}

function checkDataValidity(ref)
{
    try 
      {
        var val=document.getElementById('search:g:hidProcessID').value ;
        var val2 = document.getElementById('search:g:hidQueueId').value;
        val=val-0;
        val2=val2-0;
        if(val<= 0 && val2 <=0)
            {
                alert(SEL_QUEUE_PROCESS_DATA);
                return false;
            }
      }
      catch(e)
      {
        alert(SEL_QUEUE_PROCESS_DATA);
        return false;
      }

      return true;
}

function EnableDisableWorkstepButtonSearch()
{
    //clear the data xml
    document.getElementById("search:hidDataXML").value="";
    document.getElementById("search:hidDataFilterXML").value="";

    if(document.getElementById('search:g:hidProcessID').value > 0 )
    {
        document.getElementById('search:g:cmdPicklist_workstep').disabled=false;
    }
    else
    {
        document.getElementById('search:g:cmdPicklist_workstep').disabled=true;
    }

    document.getElementById('search:g:hidWorkstepID').value=' ';
    document.getElementById('search:g:hidWorkstepName').value=document.getElementById('search:g:hidInitialWorkstep').innerHTML;
    document.getElementById('search:g:txtWorkstepName').value=document.getElementById('search:g:hidInitialWorkstep').innerHTML;
    EnableDisableSearchOnPrevChkBox();
}

function SelectQuery(ref,id)
{
    ClickAnotherLink(ref,id);
}

function InitializeDate(prefix)
{
    var val=document.getElementById("search:t:dateOption").value;
	
	
	ApplyDateValues();
	SetDateOption(' ',val);
}

function EnableDisableCreatedDate(prefix,value)
{
    document.getElementById(prefix+':'+'cmbFromDay').disabled = value;
    document.getElementById(prefix+':'+'cmbFromMonth').disabled = value;
    document.getElementById(prefix+':'+'cmbFromYear').disabled = value;

    document.getElementById(prefix+':'+'cmbDayTo').disabled = value;
    document.getElementById(prefix+':'+'cmbMonthTo').disabled = value;
    document.getElementById(prefix+':'+'cmbYearTo').disabled = value;
}

function EnableDisableCompletedDate(prefix,value)
{
    document.getElementById(prefix+':'+'cmbCFromDay').disabled = value;
    document.getElementById(prefix+':'+'cmbCFromMonth').disabled = value;
    document.getElementById(prefix+':'+'cmbCFromYear').disabled = value;

    document.getElementById(prefix+':'+'cmbCDayTo').disabled = value;
    document.getElementById(prefix+':'+'cmbCMonthTo').disabled = value;
    document.getElementById(prefix+':'+'cmbCYearTo').disabled = value;
}

//this function is called when the search button is called
function VerifyInputs(ref)
{
    if(!bDateLink)
        return VerifyDates(ref);
    
    
}

function ApplyDateValues()
{
	var day=document.getElementById("search:t:day").value;
	var month=document.getElementById("search:t:month").value;
	var year=document.getElementById("search:t:year").value;
	var prefix='search:t';
	document.getElementById(prefix+':'+'cmbFromDay').value = day;
    document.getElementById(prefix+':'+'cmbFromMonth').value = month;
    document.getElementById(prefix+':'+'cmbFromYear').value = year;

	document.getElementById(prefix+':'+'cmbCFromDay').value = day;
    document.getElementById(prefix+':'+'cmbCFromMonth').value = month;
    document.getElementById(prefix+':'+'cmbCFromYear').value = year;

	var dayTo=document.getElementById("search:t:dayTo").value;
	var monthTo=document.getElementById("search:t:monthTo").value;
	var yearTo=document.getElementById("search:t:yearTo").value;

	document.getElementById(prefix+':'+'cmbDayTo').value = dayTo;
    document.getElementById(prefix+':'+'cmbMonthTo').value = monthTo;
    document.getElementById(prefix+':'+'cmbYearTo').value = yearTo;	

	document.getElementById(prefix+':'+'cmbCDayTo').value = dayTo;
    document.getElementById(prefix+':'+'cmbCMonthTo').value = monthTo;
    document.getElementById(prefix+':'+'cmbCYearTo').value = yearTo;	
}

function SetDateOption(ref,value)
{
	var prefix='search:t';

	if(value==0)
	{
		document.forms['search']['search:t:option'].checked = true;		
		document.forms['search']['search:t:options'].checked = false;
		document.forms['search']['search:t:optionss'].checked = false;
		document.forms['search']['search:t:optionsss'].checked = false;
		EnableDisableCreatedDate(prefix,true);
		EnableDisableCompletedDate(prefix,true);
	}

	if(value==1)
	{
		document.forms['search']['search:t:option'].checked = false;
		document.forms['search']['search:t:options'].checked = true;			
		document.forms['search']['search:t:optionss'].checked = false;
		document.forms['search']['search:t:optionsss'].checked = false;
		EnableDisableCreatedDate(prefix,true);
		EnableDisableCompletedDate(prefix,true);
	}

	if(value==2)
	{
		document.forms['search']['search:t:options'].checked = false;
		document.forms['search']['search:t:option'].checked = false;
		document.forms['search']['search:t:optionss'].checked = true;		
		document.forms['search']['search:t:optionsss'].checked = false;
		EnableDisableCreatedDate(prefix,false);
		EnableDisableCompletedDate(prefix,true);		
	}

	if(value==3)
	{
		document.forms['search']['search:t:options'].checked = false;
		document.forms['search']['search:t:optionss'].checked = false;
		document.forms['search']['search:t:option'].checked = false;
		document.forms['search']['search:t:optionsss'].checked = true;		
		EnableDisableCreatedDate(prefix,true);
		EnableDisableCompletedDate(prefix,false);	
	}
}

function VerifyDates(ref)
{
    var FromDay=null;
    var FromMonth=null;
    var FromYear = null;
    var ToDay = null;
    var ToMonth = null;
    var ToYear = null;
    
    if(document.forms['search']['search:t:optionss'].checked)
    {
		
                FromDay = document.getElementById("search:t:cmbFromDay").options[document.getElementById("search:t:cmbFromDay").selectedIndex].value;		
		FromMonth = document.getElementById("search:t:cmbFromMonth").options[document.getElementById("search:t:cmbFromMonth").selectedIndex].value;
		FromYear = document.getElementById("search:t:cmbFromYear").options[document.getElementById("search:t:cmbFromYear").selectedIndex].value;		
		ToDay = document.getElementById("search:t:cmbDayTo").options[document.getElementById("search:t:cmbDayTo").selectedIndex].value;		
		ToMonth = document.getElementById("search:t:cmbMonthTo").options[document.getElementById("search:t:cmbMonthTo").selectedIndex].value;
		ToYear = document.getElementById("search:t:cmbYearTo").options[document.getElementById("search:t:cmbYearTo").selectedIndex].value;
    }

    if(document.forms['search']['search:t:optionsss'].checked)
    {
		FromDay = document.getElementById("search:t:cmbCFromDay").options[document.getElementById("search:t:cmbCFromDay").selectedIndex].value;
		FromMonth = document.getElementById("search:t:cmbCFromMonth").options[document.getElementById("search:t:cmbCFromMonth").selectedIndex].value;
		FromYear = document.getElementById("search:t:cmbCFromYear").options[document.getElementById("search:t:cmbCFromYear").selectedIndex].value;
		ToDay = document.getElementById("search:t:cmbCDayTo").options[document.getElementById("search:t:cmbCDayTo").selectedIndex].value;
		ToMonth = document.getElementById("search:t:cmbCMonthTo").options[document.getElementById("search:t:cmbCMonthTo").selectedIndex].value;
		ToYear = document.getElementById("search:t:cmbCYearTo").options[document.getElementById("search:t:cmbCYearTo").selectedIndex].value;
    }
   
    if(document.forms['search']['search:t:optionss'].checked || document.forms['search']['search:t:optionsss'].checked)
    {
        if(!VerifyDate(FromYear,FromMonth,FromDay))
        {
            alert(INVALID_FROM_DATE);
            return false;
        }
           
        if(!VerifyDate(ToYear,ToMonth,ToDay))
        {
            alert(INVALID_TO_DATE);
            return false ;    
        }
            
		if(new Date(FromYear,FromMonth-1,FromDay) > new Date())
		{
				alert(DATE_VALIDATION_MSG_1);		
				return false;
		}
			
		else if(new Date(ToYear,ToMonth-1,ToDay) > new Date())
		{	
				alert(DATE_VALIDATION_MSG_2);		
				return false;
			
		}
		else if(new Date(FromYear,FromMonth-1,FromDay) > new Date(ToYear,ToMonth-1,ToDay))
		{	
				alert(DATE_VALIDATION_MSG_3);		
				return false;
		}
    }

	if(document.forms['search']['search:t:optionss'].checked)
	{
		value='2';
		document.getElementById("search:t:day").value=FromDay;
		document.getElementById("search:t:month").value=FromMonth;
		document.getElementById("search:t:year").value=FromYear;
	}
	else if(document.forms['search']['search:t:options'].checked)
		value='1';
	else if(document.forms['search']['search:t:optionsss'].checked)
	{
		value='3';
		document.getElementById("search:t:dayTo").value=ToDay;
		document.getElementById("search:t:monthTo").value=ToMonth;
		document.getElementById("search:t:yearTo").value=ToYear;
	}
	else if(document.forms['search']['search:t:option'].checked)
		value='0';

	document.getElementById("search:t:dateOption").value=value;

        createDateXML(FromDay,FromMonth,FromYear,ToDay,ToMonth,ToYear,value);
        
        return true;
}

function GetTitles(thisEle,Type)//checked
{   
	var strTitle;
	//var strType = Type.substring(2);
        var strType = Type;

	switch(strType)
	{
		case "10":
			strTitle = INSERT_STR_VAL;
			break;
		case "B":
			strTitle = INSERT_BOOL_VAL;
			break;
		case "8":
			tempDteFormat = DateFormat;
			strTitle = INSERT_DATE_VAL+" '"+DateFormat+"'";
			break;
		case "3":
			strTitle = INSERT_INT_VAL;
			break;
		case "6":
			strTitle = INSERT_DEC_VAL;
			break;
		case "T":
			strTitle = INSERT_RAW_VAL;
			break;
		case "4":
			strTitle = INSERT_INT_VAL;
			break;
                case "12":
			strTitle = INSERT_BOOL_VAL;
			break;
                case "16":
			strTitle = INSERT_TIME_VAL;
			break;
                case "15":
			tempDteFormat = DateFormat;
			strTitle = INSERT_DATE_VAL+" '"+DateFormat+"'";
			break;
               
		default:
	}

		thisEle.title = strTitle;
}

function ShowProcessList(ref,queuenamectrl,queueidctrl)
{
    var formId = ref.form.id;
    var queueId  = document.getElementById(formId+":"+queueidctrl).value;
    var queueName  = document.getElementById(formId+":"+queuenamectrl).value;
   
    ShowPickList(ref,'WFProcessList','g:txtProcessName','g:hidProcessID','g:hidProcessName','5','','1','EnableDisableWorkstepButtonSearch',queueName,queueId);
}	

function ClearProcessData()
{
    //clear the data xml
	document.getElementById("search:hidDataXML").value="";
        document.getElementById("search:hidDataFilterXML").value="";
    document.getElementById('search:g:hidProcessID').value=' ';
    document.getElementById('search:g:hidProcessName').value=document.getElementById('search:g:hidInitialProcess').innerHTML;
    document.getElementById('search:g:txtProcessName').value=document.getElementById('search:g:hidInitialProcess').innerHTML;
    document.getElementById('search:g:hidWorkstepID').value=' ';
    document.getElementById('search:g:hidWorkstepName').value=document.getElementById('search:g:hidInitialWorkstep').innerHTML;
    document.getElementById('search:g:txtWorkstepName').value=document.getElementById('search:g:hidInitialWorkstep').innerHTML;
}

function InitializeData(prefix)
{

    var val=document.getElementById(prefix+":hidAdvancedSearch").value;
    document.getElementById(prefix+":chkData").value = val;

    if(val == 'true')
	document.getElementById(prefix+":chkData").checked = true;
    else
	document.getElementById(prefix+":chkData").checked = false;
    
    document.getElementById("search:hidPrevQueueID").value = document.getElementById("search:g:hidQueueId").value ;
    document.getElementById("search:hidPrevProcessID").value = document.getElementById("search:g:hidProcessID").value ;
}

function SetThenClickAnotherLink(ref,toClick)
{

    var val = document.getElementById("search:d:chkData").checked;
    document.getElementById("search:d:hidAdvancedSearch").value = val;

    ClickAnotherLink(ref,toClick);
}

function setThenclick(ref,toClick)
{
    var selId = document.getElementById("search:d:cmbPvariables").selectedIndex;
    var val = document.getElementById("search:d:cmbPvariables").options[selId].value;
 
    document.getElementById("search:d:hidSelQueryVar").value = val;

    //setting the prev selected tab value = current tab value
    document.getElementById('search:PrevSelTab').value = document.getElementById('search:SelTab').value;

    ClickAnotherLink(ref,toClick);
}

function FindIdShowList(ref,picklisttype,attribute,varType)
{
        
    var index = ref.id.lastIndexOf(':');
    var arr=ref.id.split(":");
    var iArrLength = arr.length;
    var iSelIndex = arr[iArrLength-2];
    var idPrefix = "d:advFilterTable";
    var textFieldId = idPrefix+":"+iSelIndex+":procfilterData";
    var textFieldValueId = idPrefix+":"+iSelIndex+":procfilterDataValue";
    var textHiddenFieldId="";
    var processId = document.getElementById("search:g:hidProcessID").value;
    var queueId = document.getElementById("search:g:hidQueueId").value;
    var attributeName = attribute;
    var fieldType = varType;
    if(fieldType=='12')
            var textFieldId = idPrefix+":"+iSelIndex+":procfilterMenu";
    var tempPrefix = document.getElementById("search:"+textFieldId).value;
    
    if (fieldType != NG_VAR_STRING)
	tempPrefix="";
    else
	tempPrefix=tempPrefix+"*";

    ShowPickList(ref,picklisttype,textFieldId,textFieldValueId,'','','0','0','',processId,attributeName,fieldType,tempPrefix,queueId);    
}

function checkRowData(ref,toClick)
{

    var tableID = 'search:d:advFilterTable';
    var table = document.getElementById(tableID);
    
    var rowCount = 0;
    var chkBoxID=tableID+":";
    var currentChkBoxID="";
    var noOfSelectedRows=0;
    var selectedIndexes="";
    var submitFlag = false;
    rowCount = table.rows.length;
        
    if(rowCount <= 1)
    {
        submitFlag = false;
        return false;
    }
    else
    {
        
        for (var iCount=0;iCount < (rowCount-1) ;iCount++)
        {
                currentChkBoxID=chkBoxID + iCount +":chkFilter" ;
                try 
                {
                        if(document.getElementById(currentChkBoxID).checked)
                        {
                                noOfSelectedRows++;
                                if(selectedIndexes.length > 0)
                                        selectedIndexes=selectedIndexes + ":"+ iCount ;
                                else
                                        selectedIndexes = iCount +"";

                         }

                }
                catch(e)
                {
                    selectedIndexes ="";
                    noOfSelectedRows=0;
                }
        }
    }
    
    if(noOfSelectedRows == 0)
    {   
        alert(SEL_FIELD_TO_DELETE);
        submitFlag = false;
        return false;
    }
    else
    {
        submitFlag = true;
        document.getElementById("search:d:hidSelAdvRows").value = selectedIndexes;
    }
    if(submitFlag == true)
        ClickAnotherLink(ref,toClick);
   
}

function createGeneralXML()
{
           
    var prefix = "search:g:";
    
    var strXML = "";
           
    var quueuename = document.getElementById(prefix+"hidQueueName").value;
    var queueid = document.getElementById(prefix+"hidQueueId").value;
    var processname = document.getElementById(prefix+"hidProcessName").value;
    var processid = document.getElementById(prefix+"hidProcessID").value;
    var workstepname =document.getElementById(prefix+"hidWorkstepName").value;
    var workstepid=document.getElementById(prefix+"hidWorkstepID").value;
    var lockedbyname = document.getElementById(prefix+"hidLockedByName").value;
    var lockedbyid = document.getElementById(prefix+"hidLockedByID").value;
    var assignedtoname = document.getElementById(prefix+"hidAssignedToName").value;
    var assignedtoid = document.getElementById(prefix+"hidAssignedByID").value;
    var introducedbyname =document.getElementById(prefix+"hidIntroducedByName").value;
    var introducedbyid=document.getElementById(prefix+"hidIntroducedByID").value;
    var referredbyname=document.getElementById(prefix+"hidReferredByName").value;
    var refferedbyid =document.getElementById(prefix+"hidReferredByID").value;
    var piname =document.getElementById(prefix+"txtRegNum").value;
    var bprevversion = document.getElementById(prefix+"prevVersion").checked;
    var bsortversion = document.getElementById(prefix+"sortVersions").checked;
   
    var strprevversion ="";
    var strsortversion="";

    if(bprevversion == true)
        strprevversion ="Y";
    else
        strprevversion ="N";
    if(bsortversion == true)
        strsortversion = "Y";
    else
        strsortversion ="N"; 
    var selIndex = -1;
    selIndex = document.getElementById(prefix+"cmbPriority").selectedIndex;
    var priority = document.getElementById(prefix+"cmbPriority").options[selIndex].value;

    selIndex = document.getElementById(prefix+"cmbLockedStatus").selectedIndex;
    var lockedstatus = document.getElementById(prefix+"cmbLockedStatus").options[selIndex].value;

    selIndex = document.getElementById(prefix+"cmbException").selectedIndex;
    var exception = document.getElementById(prefix+"cmbException").options[selIndex].value;


    //for Bug Id 3025
    var dateXML = document.getElementById("search:hidDateXML").value;

    var parser = new PMParser(dateXML);
    var iState= parser.getIntValueOf(State,0,true);
    
    if(iState == 6)
    {
        
        var generalXML = document.getElementById("search:hidGeneralXML").value;
        parser = new PMParser(generalXML);
        
        var  iPrevQueueId = parser.getIntValueOf(QueueId,0,true);
        var iPrevWorkstepId =parser.getIntValueOf(ActivityId,0,true);
        
        if((iPrevQueueId ==0 && queueid > 0) || (iPrevWorkstepId ==0 && workstepid > 0))
        {
            document.getElementById("search:hidDateXML").value = "";
        }
        
    }
    //Bug 3025 End
    //Generate The xml    
    if(queueid != 0 && queueid != "")
    {
        strXML = strXML + appendTagAndValue(TAG_QueueName,quueuename);
        strXML = strXML + appendTagAndValue(QueueId,queueid);
         strXML = strXML + appendTagAndValue(Type,"256");
        document.getElementById("search:hidAdvanceSearchOnQueue").value="Y";
    }
    else
        document.getElementById("search:hidAdvanceSearchOnQueue").value="N";
     
    if(processid != 0 && processid != "")
    {
        strXML = strXML + appendTagAndValue(ProcessName,processname);
        strXML = strXML + appendTagAndValue(ProcessDefinitionID,processid);
    }
    if(workstepid != 0 && workstepid != "")
    {
        strXML = strXML + appendTagAndValue(ActivityId,workstepid);
        strXML = strXML + appendTagAndValue(ActivityName,workstepname);
    }
    strXML = strXML + appendTagAndValue(SearchPreviousVersion,strprevversion);
    strXML = strXML + appendTagAndValue(SortOnVersion,strsortversion);
    strXML = strXML + appendTagAndValue(ProcessInstanceName,piname);
    
    if(priority != "-1")
        strXML = strXML + appendTagAndValue(Priority,priority);
    if(lockedstatus != "-1")    
        strXML = strXML + appendTagAndValue(LockStatus,lockedstatus);
    if(exception != "-1")    
        strXML = strXML + appendTagAndValue(ExceptionStatus,exception);
    if(lockedbyid != "-1" && lockedbyid != "" && lockedstatus != "N")
    {
        strXML = strXML + appendTagAndValue(LockedByUserId,lockedbyid);
        strXML = strXML + appendTagAndValue(LockedByUser,lockedbyname);
    }
    if(assignedtoid != "-1" && assignedtoid != "")
    {
        strXML = strXML + appendTagAndValue(AssignedToUserId,assignedtoid);
        strXML = strXML + appendTagAndValue(AssignedToUser,assignedtoname);
    }
    if(introducedbyid != "-1" && introducedbyid != "")
    {
        strXML = strXML + appendTagAndValue(IntroducedByUserId,introducedbyid);
        strXML = strXML + appendTagAndValue(IntroducedByUser,introducedbyname);
    }
    if(refferedbyid != "-1" && refferedbyid != "")
    {
        strXML = strXML + appendTagAndValue(ReferBy,refferedbyid);
        strXML = strXML + appendTagAndValue(ReferByName,referredbyname);
    }

    if(document.getElementById("search:t:dateOption").value==1)
    createDateXML('','','','','','',1);
    document.getElementById("search:hidGeneralXML").value=strXML;
 }

function createDateXML(FromDay,FromMonth,FromYear,ToDay,ToMonth,ToYear,value)
{
    var strXML ="";
    if(value == 0)
       strXML = appendTagAndValue(State,"0");
    if(value == 1)
      strXML = appendTagAndValue(State,"2");
    if(value == 2)
      strXML = appendTagAndValue(State,"1");
    if(value == 3)
      strXML = appendTagAndValue(State,"6");

    if(value == 2 || value == 3)
    {
        var ToDate = ToYear + "-" + ToMonth +"-"+ToDay + " 23:59:59";
	var FromDate = FromYear + "-" + FromMonth +"-"+FromDay + " 00:00:00";
        
        if(bEnableTimeZone == 'true')
        {
            try
            {
                var timeDiff = (iServerTimeDiff-0)-(iClientTimeDiff-0);
                ToDate = addMinutesToDBDate(ToDate,timeDiff);
                FromDate = addMinutesToDBDate(FromDate,timeDiff);
            }
            catch(e)
            {}
        }
        var DateRange = "'"+FromDate+"' , '"+ToDate+"'";
        
        strXML = strXML + appendTagAndValue(StateDateRange,DateRange);
    }
   
    document.getElementById("search:hidDateXML").value=strXML;
    
}

function createDataXML()
{
    var strXML="";
    var strFilterXML="";
    var prefix ="search:d:";
    var badvsearch = document.getElementById(prefix+"hidAdvancedSearch").value;
    var stradvsearch="N";
    var tablePrefix="";
    var entryFlag=false;
    if(badvsearch == 'true')
    {
        stradvsearch="Y";
        tablePrefix = prefix+"advFilterTable";
    }
    else
    {
        stradvsearch="N";
        tablePrefix =prefix+"simpleFilterTable";
    }
    var rowCount = -1;
    rowCount = document.getElementById(tablePrefix).rows.length;

           
    strXML = "<QueryList>";
    strFilterXML = "<QueryList>";

    strXML = strXML + appendTagAndValue(AdvanceSearch,stradvsearch);
    strFilterXML = strFilterXML + appendTagAndValue(AdvanceSearch,stradvsearch);
    
    if(rowCount > 1)
    {
        var iCount=0;
        
        
        for(iCount=0 ; iCount < (rowCount-1) ; iCount++)
        {
            var varname = document.getElementById(tablePrefix+":"+iCount+":VarName").innerHTML;
            var vartype = document.getElementById(tablePrefix+":"+iCount+":VarType").value;
            var varlength = document.getElementById(tablePrefix+":"+iCount+":VarLength").value;
            if(varlength=='0'){
             varlength = "";
            }
            var varvalue="";
            var varoperator="";
            var varjoincond="";
            var selIndex = -1;
            

            if(badvsearch == 'true')
            {   
                if(vartype!='12')
                    varvalue = document.getElementById(tablePrefix+":"+iCount+":procfilterData").value;
                else
                    varvalue = document.getElementById(tablePrefix+":"+iCount+":procfilterMenu").value;
                selIndex = document.getElementById(tablePrefix+":"+iCount+":advCmbOperator").selectedIndex;
                varoperator = document.getElementById(tablePrefix+":"+iCount+":advCmbOperator").options[selIndex].value;
                selIndex = document.getElementById(tablePrefix+":"+iCount+":advCmbJoin").selectedIndex;
                varjoincond = document.getElementById(tablePrefix+":"+iCount+":advCmbJoin").options[selIndex].value;

                if(Trim(varvalue)=='')
                    entryFlag = true;
            }
            else if(badvsearch == 'false')
            {
                if(vartype!=12)
                    varvalue = document.getElementById(tablePrefix+":"+iCount+":VarValue").value;
                else
                     varvalue = document.getElementById(tablePrefix+":"+iCount+":VarMenu").value;

                  
                varoperator = "3";
                varjoincond = "AND"; 
               if(vartype == '10' && varvalue.length !=0 && varvalue.indexOf('\u002A') != -1)
                {
                   varoperator = "7";          //if * is present in search operator is like whose value is 7. bug id-3900
                }
            }

            if((vartype == '8' || vartype=='15') && varvalue != '')
            {
                varvalue = LocalToDB(varvalue,DateFormat);
                if(vartype=='15')
                    varvalue=varvalue.substring(0,varvalue.indexOf(" "));

              
            }
            strXML = strXML + "<QueryInfo>";
                strXML = strXML + appendTagAndValue(VarName,varname);
                strXML = strXML + appendTagAndValue(VarType,vartype);
                strXML = strXML + appendTagAndValue(Length,varlength);
                strXML = strXML + appendTagAndValue(VarValue,varvalue);
                strXML = strXML + appendTagAndValue(Operator,varoperator);
                strXML = strXML + appendTagAndValue(JoinCondition,varjoincond);
            strXML = strXML + "</QueryInfo>";

            if(varvalue != '')
             {
                strFilterXML = strFilterXML + "<QueryInfo>";
                    strFilterXML  = strFilterXML + appendTagAndValue(VarName,varname);
                    strFilterXML  = strFilterXML + appendTagAndValue(VarType,vartype);
                    strFilterXML  = strFilterXML  + appendTagAndValue(Length,varlength);
                    strFilterXML  = strFilterXML  + appendTagAndValue(VarValue,varvalue);
                    strFilterXML  = strFilterXML  + appendTagAndValue(Operator,varoperator);
                    strFilterXML  = strFilterXML  + appendTagAndValue(JoinCondition,varjoincond);
                strFilterXML  = strFilterXML  + "</QueryInfo>";
             }
        }
    }
    if(badvsearch == 'true')
	{
            if(entryFlag)
                {
                    strXML = strXML + appendTagAndValue(EntrySetting,"Y");
                    strFilterXML  = strFilterXML  + appendTagAndValue(EntrySetting,"Y");
                }
            else
                {
                    strXML = strXML + appendTagAndValue(EntrySetting,"N");
                    strFilterXML   = strFilterXML  + appendTagAndValue(EntrySetting,"N");
                }
        }
    strXML = strXML +"</QueryList>";
    strFilterXML = strFilterXML +"</QueryList>";
   
    document.getElementById("search:hidDataXML").value=strXML;
    document.getElementById("search:hidDataFilterXML").value=strFilterXML ;
   
   
}
function appendTagAndValue(tagName,tagValue)
{
    var tagAndValue="";
	tagValue=tagValue.toString();
    tagValue=tagValue.replace(/\n|\r/g, "");
    if(tagValue != "")
        tagAndValue = "<" + tagName + ">" + Trim(tagValue) + "</" + tagName + ">";
    return tagAndValue;
}

function CheckDataAndCreateXMLs(ref)
{
    var curTabid = document.getElementById('search:SelTab').value;
    if(curTabid==1)
    {
         if(!checkDataValidity(ref))  //validate for all process and all queue .Bug Id PRM_7.1_001
           return false; 
        //validate inputs for gen tab
        createGeneralXML();
        
    }
    else if(curTabid==2)
    {
        //validate inoputs for date tab
        if(!VerifyDates(ref))
            return false;
    }
    else if(curTabid==3)
    {
        //validate inputs for data tab
        if(!ValidateProcessData())
            return false;
        createDataXML();
       
    }
    return true;
}

function DeleteQuery(ref)
{
    
    var queryID = document.getElementById("search:hidQueryID").value; 
    if(queryID == "0" || queryID == "-1" || queryID == "")
    {
		alert(SEL_QUERY_TO_DELETE);
		return false;
    }
    var confirmFlag = confirm(CONFIRM_QUERY_DELETE);
    if(confirmFlag)
    {
        ClickAnotherLink(ref,'deleteQuery');
    }
    else
	return false;
}
function WorkItemHistory(ref)
{
	var ProcInsID="";
        ProcInsID =ref.innerHTML;
        
        var Url="../workitem/workitemhistory.faces";
        Url = appendUrlSession(Url);
        var ScreenHeight=screen.height;
	var ScreenWidth=screen.width;
	var WindowHeight=windowH+100;
	var WindowWidth=windowW + 155;
	var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
	var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
        WindowHeight = screen.height - 10;
        WindowWidth = screen.width - 10;
        var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=0,top=5,left=5';

        var listParam=new Array();
        listParam.push(new Array("Action",encode_ParamValue("1")));
        listParam.push(new Array("RegistrationID",encode_ParamValue(ProcInsID)));

	var win = openNewWindow(Url,'',wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
        try
        {
            addWindows(win);
        }
        catch(e)
        {}
        
}

function SelectCheckBoxes(ref)
{
    var formid=ref.form.id;
    var tableid=formid+':d:advFilterTable';
    try 
    {
        var noofrows = document.getElementById(tableid).rows.length;
        var flag=0;
        for (var i=0;i< noofrows-1 ;i++)
        {
            
            var id=tableid+':'+i+':chkFilter';
            document.getElementById(id).checked=ref.checked;
        }
        
        return '';
    }
    catch(e)
    {
        //alert(e);
        return "";
    }
}

function EnableDisableSearchOnPrevChkBox()
{
    if(document.getElementById('search:g:hidProcessID').value > 0 )
    {
        document.getElementById('search:g:prevVersion').disabled=false;
    }
    else
    {
        document.getElementById('search:g:prevVersion').disabled=true;
        document.getElementById('search:g:prevVersion').checked = false;
        EnableDisableSortOnVersionsChkBox();
    }

}

function EnableDisableSortOnVersionsChkBox()
{
    if(document.getElementById('search:g:prevVersion').checked == true)
    {
        document.getElementById('search:g:sortVersions').disabled=false;
    }
    else
    {
        document.getElementById('search:g:sortVersions').disabled=true;
        document.getElementById('search:g:sortVersions').checked = false;
    }

}

function SortByField(index)
{
    document.getElementById('search:hidOrderBy').value = index;
    ClickAnotherLink('','cmdlink_Sort');
}


function ReassignWorkItem()     //bug id-3719
{
    try
    {
    var fromid = document.getElementById("from").value;
    }
    catch(e)
    {}
    var Url="../workitem/reassignworkitem.faces";
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=windowH;
    var WindowWidth=windowW;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("Op",encode_ParamValue("R")));
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("WI",encode_ParamValue(SelectedSearchWi)));
    listParam.push(new Array("from",encode_ParamValue(fromid)));

    var win = openNewWindow(Url,"reassignWorkitem",wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
}

function ChangePriority()       //bug id-3719
{   
    try
    {
    var fromid = document.getElementById("from").value;
    }
    catch(e)
    {}
    var Url="../workitem/changepriority.faces";
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=windowH;
    var WindowWidth=windowW;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;


    var listParam=new Array();
    listParam.push(new Array("Op",encode_ParamValue("C")));
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("WI",encode_ParamValue(SelectedSearchWi)));
    listParam.push(new Array("from",encode_ParamValue(fromid)));

    var win = openNewWindow(Url,"changePriority",wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
}



function AdHocRouting()     //bug id-3719
{
    try
    {
    var fromid = document.getElementById("from").value;
    }
    catch(e)
    {}
    var Url="../workitem/adhocrouting.faces";
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=windowH;
    var WindowWidth=windowW;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("Op",encode_ParamValue("A")));
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("WI",encode_ParamValue(SelectedSearchWi)));
    listParam.push(new Array("from",encode_ParamValue(fromid)));

    var win = openNewWindow(Url,"changePriority",wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
}

function UnlockItem()   //bug id-3719
{
    try
    {
    var fromid = document.getElementById("from").value;
    }
    catch(e)
    {}
    var Url="../workitem/unlockworkitem.faces";
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=windowH;
    var WindowWidth=windowW;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("Op",encode_ParamValue("U")));
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("from",encode_ParamValue(fromid)));
    listParam.push(new Array("WI",encode_ParamValue(SelectedSearchWi)));

    var win = openNewWindow(Url,"changePriority",wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);

    try
    {
        addWindows(win);
    }
    catch(e)
    {}
}

function SaveResult(ref)
{   
    //BUG ID 608
    //ClickAnotherLink(document,'cmdlink_save'); 
    clickLink(ref); 
    //END
}

function selectAllCheckbox(ref,totalItems)      //bug id-3719
{
    var iCount=0;
    for(iCount=0;iCount < totalItems;iCount++)
        {
            var ctrlName= "search:pnlResult_" + iCount +"_checkBox";            
            document.getElementById(ctrlName).checked=ref.checked;
        }
        CheckBoxClicked(ref,totalItems);    
}

function CheckBoxClicked(ref,totalItems)    //bug id-3719
{
    var iCount=0;
    SelectedSearchWi="";    
    var tempReassignStatus=1;
    var tempPriorityStatus=1;
    var tempAdhocStatus=1;
    var tempLockStatus=1;
    var EffReassignStatus=1;    
    var EffPriorityStatus=1;
    var EffAdhocStatus=1;
    var EffLockStatus=1;
    var refId = ref.id;
    var checkedstatus=0;
    var checkedcount=0;
    var prevpDefId = "";
    var currpDefId = "";
    
 
        var HeaderCheckBox = document.getElementById("search:pnlResultHeadercheckBox");
        var ReassignImg = document.getElementById("search:ReassignImg");
        var PriorityImg = document.getElementById("search:PriorityImg");
        var AdHocRoutingImg = document.getElementById("search:AdHocRoutingImg");
        var UnlockImg = document.getElementById("search:UnlockImg");

        try
    {
        for(iCount=0;iCount < totalItems;iCount++)
        {
            var ctrlName= "search:pnlResult_" + iCount +"_checkBox";
            
            if((document.getElementById(ctrlName)).checked==true)
            {                
                resetBottom(iCount);
                
                if(SelectedSearchWi == '')
                {                
                    SelectedSearchWi = iCount+"";
                }
                else
                {                
                SelectedSearchWi = SelectedSearchWi+":"+iCount;
                }
                
                checkedstatus=1;
                
                checkedcount++;
                prevpDefId=currpDefId;
        
            }
        }
        
    }
    catch(ex)
    {
            checkedstatus=0;            
            EffReassignStatus=0;
            EffPriorityStatus=0;
            EffAdhocStatus=0;
            EffLockStatus=0;
    }
    
        if(checkedcount == totalItems)
        {
        HeaderCheckBox.checked = true;
        }
        else
        {
        HeaderCheckBox.checked = false;
        }
       
        if(checkedstatus==0)
        {    
            EffReassignStatus=0;
            EffPriorityStatus=0;
            EffAdhocStatus=0;
            EffLockStatus=0;
        }
        
        if(EffReassignStatus==0 && tempReassignStatus==1)
        {
        EffReassignStatus==0;
        }
        else
        {
        EffReassignStatus=tempReassignStatus;
        }

        if(EffPriorityStatus==0 && tempPriorityStatus==1)
        {
        EffPriorityStatus==0;
        }
        else
        {
        EffPriorityStatus=tempPriorityStatus;
        }

        if(EffAdhocStatus==0 && tempAdhocStatus==1)
        {
        EffAdhocStatus==0;
        }
        else
        {
        EffAdhocStatus=tempAdhocStatus;
        }

        if(EffLockStatus==0 && tempLockStatus==1)
        {
        EffLockStatus==0;
        }
        else
        {
        EffLockStatus=tempLockStatus;
        }

        
        
        if(EffReassignStatus==1)
       {       
       ReassignImg.src='../omniflow/'+localizedPath+'images/reassign.gif';
       ReassignImg.disabled=false;
       }
       else
       {       
       ReassignImg.src='../omniflow/'+localizedPath+'images/reassigndis.gif';
       ReassignImg.disabled=true;
       }
       if(EffPriorityStatus==1)
       {              
       PriorityImg.src='../omniflow/'+localizedPath+'images/changepriority.gif';
       PriorityImg.disabled=false;
       }
       else
       {       
       PriorityImg.src='../omniflow/'+localizedPath+'images/changeprioritydis.gif';
       PriorityImg.disabled=true;
       }
       if(EffAdhocStatus==1)
       {              
       AdHocRoutingImg.src='../omniflow/'+localizedPath+'images/adhocrouting.gif';
       AdHocRoutingImg.disabled=false;
       }
       else
       {
       AdHocRoutingImg.src='../omniflow/'+localizedPath+'images/adhocroutingdis.gif';
       AdHocRoutingImg.disabled=true;
       }
       if(EffLockStatus==1)
       {       
       UnlockImg.src='../omniflow/'+localizedPath+'images/unlock.gif';
       UnlockImg.disabled=false;
       }
       else
       {       
       UnlockImg.src='../omniflow/'+localizedPath+'images/unlockdis.gif';
       UnlockImg.disabled=true;
       }

    function resetBottom(iCount)
    {
    
            var lockingStatus ="";
            var piStatus="";
            var workitemStatus="";
            var procDefId="";
            var queueType="";
            var assignmentType="";

            lockingStatus = document.getElementById("search:pnlResult_"+iCount+"_lockStatusValue").value;
            piStatus = document.getElementById("search:pnlResult_"+iCount+"_piState").value;
            workitemStatus = document.getElementById("search:pnlResult_"+iCount+"_workitemStateId").value;
            procDefId = document.getElementById("search:pnlResult_"+iCount+"_procDefId").value;
            currpDefId=procDefId;
            queueType = document.getElementById("search:pnlResult_"+iCount+"_queueType").value;
            assignmentType = document.getElementById("search:pnlResult_"+iCount+"_assignmentType").value;
            loggedinUser=(document.getElementById("search:hidloggedinuser").value).toUpperCase();
            try{
            assignedUser=(document.getElementById("search:pnlResult_"+iCount+"_assignToname").value).toUpperCase();
            assignedUser=Trim(assignedUser);
            
            }
            catch(e){}
            if(assignedUser.length>0)
            {
            if(assignedUser==loggedinUser)
            tempPriorityStatus=1;
            else
            tempPriorityStatus=0;
            }
            if(lockingStatus == "Y")
            {
                    tempReassignStatus=0;
                    tempPriorityStatus=0;
                    tempAdhocStatus=0;
                    if(workitemStatus == 3) 
                    {                        
                        tempLockStatus=0;
                    }
            }
            else 
            {
                    tempLockStatus=0;
                    if(piStatus != 2)
                    {
                             tempAdhocStatus=0;
                            //tempReassignStatus=0;                    //Changed for Bug Id 3306
                            if(piStatus != 1)
                            {       
                                    tempPriorityStatus=0;
                                    tempAdhocStatus=0;
                            }
                    }
                    else if(workitemStatus == 6 || workitemStatus == 5 || workitemStatus == 4 || workitemStatus == 3) 
                    {
                            tempReassignStatus=0;
                            tempAdhocStatus=0;
                            tempPriorityStatus=0;
                    }

                    if(queueType == 'I' || assignmentType =='E')
                            tempReassignStatus=0;
            }
            
            
            if(prevpDefId!=currpDefId && prevpDefId != '')
            {
            tempAdhocStatus=0;            
            }
            
            if((piStatus==6 && isAdhocAtExit=='Y') || (piStatus==5 && workitemStatus == 5))
                 tempAdhocStatus=1;
            
    }
}

 function openNewPage(ref)
            {
                if(document.getElementById("search:hidQueryID").value == "0")
                {
                    var OptionsUrl = "../search/savequery.faces";
                    OptionsUrl = appendUrlSession(OptionsUrl);
                    var ScreenHeight=screen.height;
                    var ScreenWidth=screen.width;
                    var WindowHeight=windowH;
                    var WindowWidth=windowW;
                    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
                    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

                    var win = window.open(OptionsUrl,"saveQuery"+UniqueUserId,'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=1,top='+WindowTop+',left='+WindowLeft);
                    try
                    {
                        addWindows(win);
                    }
                    catch(e)
                    {}
                }
                else
                {
                    clickCommandLink();
                    return true;
                }
            }

function saveQueryLinkClick(ref)
            {
                if(document.getElementById("search:hidQueryID").value == "0")
                {                 
                    var ref = document.getElementById("search");
		    if(CheckDataAndCreateXMLs(ref))              // its in search.js
                    {
                        ClickAnotherLink(ref,'viewsavequery');
                        return true;
                    }
                    else
                        return false;
                }
                else
                {                    
                    clickCommandLink();
                    //return true;
                }
            }

    function clickCommandLink()
    {

        var ref = document.getElementById("search");
        if(CheckDataAndCreateXMLs(ref)) // its in search.js
        {
            ClickAnotherLink(ref,'saveQuery');
            return true;
        }
        else
            return false;
            
    }

var PIDflag=true;
var lastPIDVal='';


function ValidateProcessData()
{
    var prefix ="search:d:";
    var badvsearch = document.getElementById(prefix+"hidAdvancedSearch").value;
    var tablePrefix="";
   
    if(badvsearch == 'true')
    {
        tablePrefix = prefix+"advFilterTable";
    }
    else
    {
       tablePrefix =prefix+"simpleFilterTable";
    }
    
    var rowCount = -1;
    rowCount = document.getElementById(tablePrefix).rows.length;
    var elementId="";
    if(rowCount > 1)
    {
        var iCount=0;
        for(iCount=0 ; iCount < (rowCount-1) ; iCount++)
        {
            var varname = document.getElementById(tablePrefix+":"+iCount+":VarName").innerHTML;
            var vartype = document.getElementById(tablePrefix+":"+iCount+":VarType").value;
            var varlength = document.getElementById(tablePrefix+":"+iCount+":VarLength").value;
            var varvalue="";

            if(badvsearch == 'true')
            {
               if(vartype!='12'){
                    varvalue = document.getElementById(tablePrefix+":"+iCount+":procfilterData").value;
                    elementId = tablePrefix+":"+iCount+":procfilterData";
                }
                else
                {
                      varvalue = document.getElementById(tablePrefix+":"+iCount+":procfilterMenu").value;
                      elementId = tablePrefix+":"+iCount+":procfilterMenu";
                }
            }
            else if(badvsearch == 'false' && vartype!='12')  
            {
           
              varvalue = document.getElementById(tablePrefix+":"+iCount+":VarValue").value;
              elementId = tablePrefix+":"+iCount+":VarValue";
            }
	
            if(Trim(varvalue)!='')
              {
                  if(vartype == '3')
                   {
                       if(!IsNumericVal(varvalue))
                         {
                            alert(INVALID_NUMERIC_VALUE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                         }
                        else if (varvalue<-Math.pow(2,31) || varvalue>(Math.pow(2,31)-1))
                        {
                            alert(INDEX_VALUE_OUT_OF_RANGE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                        }
                    }
                else if(vartype == '4')
                {
                    if(!IsNumericVal(varvalue))
                    {
                            alert(INVALID_NUMERIC_VALUE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
                    else if (varvalue<-Math.pow(2,31) || varvalue>(Math.pow(2,31)-1))
                    {
                            alert(INDEX_VALUE_OUT_OF_RANGE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
                }
                else if(vartype == '6')
                {
                    if(isNaN(varvalue))
                    {
                            alert(INVALID_NUMERIC_VALUE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
                    else if (varvalue< parseFloat("-1.79e+308") || varvalue> parseFloat("+1.79e+308"))
                    {
                            alert(INDEX_VALUE_OUT_OF_RANGE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
                }   
                else if(vartype == '8' && varvalue != '')
                {
                    var ret = ValidateDateFormat(varvalue,DateFormat);
                    if(ret==0)
                    {
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
               }
            else if(vartype == '10')
            {
                    if ( (varvalue.indexOf('\u00ff') != -1) || (varvalue.indexOf('\u00fc') != -1) ||(varvalue.indexOf('\u00b5') != -1) || (varvalue.indexOf('<') != -1) || (varvalue.indexOf('>') != -1) )
                    {
                            alert(INVALID_STRING);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
            }
            else if(vartype == '15')
            {
                   varvalue=Trim(varvalue);
                   var ret = ValidateDateFormat(varvalue,DateFormat);
                   if(ret==0 || varvalue.indexOf(" ")!=-1){
                       
                       if(ret!=0)
                            alert("Date");
                       document.getElementById(elementId).focus();
                       document.getElementById(elementId).select();
                       return false;
                    }   

            }
            else if(vartype == '16')
            {
                   varvalue=Trim(varvalue);
                   var ret = ValidateTime(varvalue);
                   if(ret==0 || varvalue.indexOf(" ")!=-1){
                       
                       document.getElementById(elementId).focus();
                       document.getElementById(elementId).select();
                       return false;
            }   

            }
          } // if Trim
      } // for loop ends
    } //rowCount > 1

    return true;

}//fucn ends
 

            function saveQuery()
            {
                    var QueryCombo = document.getElementById('search:selQuery');
                    //alert(QueryCombo);
                    var newQueryName = document.getElementById("search:txtQueryName").value.toLowerCase();
                    newQueryName=Trim(newQueryName);
                    var ComboSize = QueryCombo.options.length;
                    
                    if(Trim(newQueryName) == '')
                    {
                            alert(ALERT_NO_QUERY_NAME);
                            setFocus();
                            return false;
                    }

                    for(var i=1 ; i < ComboSize ; i++)
                    {
                     
                            if(QueryCombo.options[i].text.toLowerCase() == newQueryName)
                            {
                                    alert(ALERT_QUERY_ALREADY_EXISTS);
                                    setFocus();
                                    return false;
                            }
                    }
                    try
                    {
                        var parentQueryNameComp = document.getElementById("search:hidQueryName");
                        parentQueryNameComp.value = document.getElementById("search:txtQueryName").value;
                        
                        clickCommandLink();
                            
                        
                    }catch(ex){}
            }
            
           function setFocus()
            {   
                document.getElementById("search:txtQueryName").focus();
            }
            function updateOnLockStatusChange()
            {
             if(document.getElementById("search:g:cmbLockedStatus").value == "N")
             {
                document.getElementById("search:g:txtLockedBy").value="";
                document.getElementById("search:g:cmdPicklist_LockedBy").disabled=true;
                document.getElementById("search:g:txtLockedBy").disabled=true;
             }
             else
             {
                document.getElementById("search:g:cmdPicklist_LockedBy").disabled=false;
                document.getElementById("search:g:txtLockedBy").disabled=false;     
             }
            }
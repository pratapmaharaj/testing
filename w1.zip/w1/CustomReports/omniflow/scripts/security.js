/*
    TCS code strip_tags function
    This function is used to strip all the html tags from a string and returns the sanitized string 
	This function is written to tackle the Fortify OpenRedirect Secuirity vulerability 
	First parameter is the input string
	Second Parameter allowed is the string if you want to allow some tages
	Example Usage:-    strOut = strip_tags("Hello test<javascript>hack()</javascript>this<BR>","<BR>")
	   strOut will be - "Hello Testthis<BR>"
*/
function strip_tags(input, allowed) {
  allowed = (((allowed || '') + '')
    .toLowerCase()
    .match(/<[a-z][a-z0-9]*>/g) || [])
    .join(''); // making sure the allowed arg is a string containing only tags in lowercase (<a><b><c>)

  var tags = /<\/?([a-z][a-z0-9]*)\b[^>]*>/gi,
      commentsAndPhpTags = /<!--[\s\S]*?-->|<\?(?:php)?[\s\S]*?\?>/gi;

  return input.replace(commentsAndPhpTags, '')
      .replace(tags, function($0, $1) {
          return allowed.indexOf('<' + $1.toLowerCase() + '>') > -1 ? $0 : '';
      });
}

function isGoodForRedirect(strUrl) {
  var omniDomains = ["https://omniflowsit.us.aegon.com","https://omniflowuat.us.aegon.com"];
  isInList=false;
  for(i=0;i<omniDomains.length && isInList==false;i++) {
	if(strUrl.startsWith(omniDomains[i])) {
		isInList = true;
	}
  }
  return isInList;
}
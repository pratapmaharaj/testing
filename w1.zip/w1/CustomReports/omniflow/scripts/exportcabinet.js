/**************************************************************************************************************

 File            :       exportcabinet.js
 Purpose         :       Contains the functions for setting export cabinet.
 
 Change History  :
 
 Problem No     Correction Date	 Changed By		Comments
 -----------    ---------------   ----------    -----------------
 Bug 12250  	   05/04/2010    Mohit Sharma
 Bug 27745         25/07/2011    Jaseem Ansari        (When user wants to purge the data then export cabinet information shoud not be needed )
 Bug 42644       25/11/2013          Jaseem Ansari       Need to provide an option in advanced search window to search on Export cabinet.
 Bug 72327		 06/10/2017			 Saquib Islam		 Following vulnerabilities reported in processmanager:
															1. Password type input with auto-complete enabled
															2. Unauthorized Read Access
 */

function connectFunc(ref, toClick) {
    //var thisFrm = window.document.forms["textForm"];
    var ip = document.getElementById("cabform:txtIp").value;
    var port = document.getElementById("cabform:txtPort").value;
    

    if(ip == "" ) {
        alert(SPECIFY_WFS_IP);
        document.getElementById("cabform:txtIp").focus();
        return false;
    }

    if( !( isValidIPAddress( ip ) ) ){
        alert( INVALID_WFS_IP );
        document.getElementById("cabform:txtIp").focus();
        return false;
    }
    if (port == "" ) {
        alert(SPECIFY_WFS_PORT);
         document.getElementById("cabform:txtPort").focus( );
        return false;
    }
    if( !( isValidPort( port ) )){
        alert(INVALID_PORT_NUMBER);
        document.getElementById("cabform:txtPort").focus( );
        return false;
    }

    
    document.getElementById("cabform:hidServerIp").value = ip;
    document.getElementById("cabform:hidServerPort").value = port;
    document.getElementById("cabform:hidTempOperation").value ="S";
    if(document.getElementById("cabform:cmbcabname") != null)
        document.getElementById("cabform:cmbcabname").value="";
   if(document.getElementById("cabform:keepSourceIS"))
    {
        if(document.getElementById("cabform:keepSourceIS").checked)
            document.getElementById("cabform:hidKeepSourceIS").value="Y";
        else
            document.getElementById("cabform:hidKeepSourceIS").value="N";
    }
    
    if(bPwdEncrypt == 'Y') {
        var refHidSourceDBPassword = document.getElementById("cabform:hidSourceDBPassword");
        var refHidTargetDBPassword = document.getElementById("cabform:hidTargetDBPassword");
        var refTxtPasswordSource = document.getElementById("cabform:txtPasswordSource");
        var refTxtPasswordTarget = document.getElementById("cabform:txtPasswordTarget");
        
        var bf = new Blowfish('DES');
        var encHidSourceDBPassword = bf.encryptx(refHidSourceDBPassword.value, eToken);
        var encHidTargetDBPassword = bf.encryptx(refHidTargetDBPassword.value, eToken);
        var encTxtPasswordSource = bf.encryptx(refTxtPasswordSource.value, eToken);
        var encTxtPasswordTarget = bf.encryptx(refTxtPasswordTarget.value, eToken);
        
        refHidSourceDBPassword.value = encode_utf8(encHidSourceDBPassword);
        refHidTargetDBPassword.value = encode_utf8(encHidTargetDBPassword);
        refTxtPasswordSource.value = encode_utf8(encTxtPasswordSource);
        refTxtPasswordTarget.value = encode_utf8(encTxtPasswordTarget);
    }
    
    ClickAnotherLink(ref,toClick);
    //clickLink("cabform:connectCabinet");
    
    
}

function isValidPort( port ){

    if(isNaN(port) ){
        return false;
    }

    if( parseInt( port ) > 65535 ) {
        return false;
    }
    return true;
}

function isValidIPAddress(ipaddr) {
   var re = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
   if (re.test(ipaddr)) {
      var parts = ipaddr.split(".");
      if (parseInt(parseFloat(parts[0])) == 0) {return false;}
      for (var i=0; i<parts.length; i++) {
         if (parseInt(parseFloat(parts[i])) > 255) {return false;}
      }
      return true;
   } else {
      return false;
   }
}


function setISOption(ref , toClick) {
    //var thisFrm = window.document.forms["textForm"];
    var ip = Trim(document.getElementById("cabform:txtIp").value);
    var port = Trim(document.getElementById("cabform:txtPort").value);
    
    if(ip == "" || port == "")
        return;
    
    if(document.getElementById("cabform:keepSourceIS"))
    {
    if(document.getElementById("cabform:keepSourceIS").checked) {
        document.getElementById("cabform:keepSourceIS").value =true;
        document.getElementById("cabform:hidKeepSourceIS").value ="Y";
        //alert("Using Source Image Server Support Not provided");
        
        
     }
    else {
        document.getElementById("cabform:keepSourceIS").value =false;
        document.getElementById("cabform:hidKeepSourceIS").value ="N";
    }
    }
    ClickAnotherLink(ref,toClick);
}

function setSiteVol(ref,toClick) {
    
    var val = document.getElementById("cabform:cmbcabname").value;
   if(document.getElementById("cabform:keepSourceIS") && document.getElementById("cabform:keepSourceIS").checked)
    {
      //    document.getElementById("siteTable").style.diplay="none";
    
    }
    else{
       // document.getElementById("siteTable").style.diplay="inline";
        document.getElementById("cabform:hidSelCabName").value = val;
        document.getElementById("cabform:hidTempOperation").value ="S";
        ClickAnotherLink(ref,toClick);
    }
   
}
function setVol(ref,toClick) {
    
    var val = document.getElementById("cabform:cmbcabname").value;
    
    document.getElementById("cabform:hidSelCabName").value = val;
    document.getElementById("cabform:hidSitename").value = document.getElementById("cabform:cmbsitename").value;
    document.getElementById("cabform:hidTempOperation").value ="S";
    ClickAnotherLink(ref,toClick);
}

function setExportInfo(referrer) {

    if(document.getElementById("cabform:DbUserSource").value == "") {
        alert(SPECIFY_SOURCE_DB_USERNAME);
        document.getElementById("cabform:DbUserSource").focus( );
        return false;
    }
    

    var webIp = document.getElementById("cabform:WebServerIP").value;
    var webPort = document.getElementById("cabform:WebServerPort").value;

 if(document.getElementById("cabform:DbUserTarget").value== ""&&(webIp !="" || webPort!="" || document.getElementById("cabform:txtIp").value != "" || document.getElementById("cabform:txtPort").value != "" )) {
        alert(SPECIFY_TARGET_DB_USERNAME);
        document.getElementById("cabform:DbUserTarget").focus( );
        return false;
    }
 if(document.getElementById("cabform:DbUserTarget").value!=""){
 if( webIp =="" ){
        alert(SPECIFY_WEB_IP);
        document.getElementById("cabform:WebServerIP").focus();
        return false;
    }

    if( !isValidIPAddress( webIp ) ){
        alert( INVALID_WEB_IP );
        document.getElementById("cabform:WebServerIP").focus();
        return false;
    }
    if (webPort == "" ) {
        alert(SPECIFY_WEB_PORT);
        document.getElementById("cabform:WebServerPort").focus();
        return false;
    }

    if( !( isValidPort( webPort ) ) ){
        alert(INVALID_PORT_NUMBER);
        document.getElementById("cabform:WebServerPort").focus();
        return false;
    }

    if(document.getElementById("cabform:txtIp").value == "" || ( !isValidIPAddress( document.getElementById("cabform:txtIp").value ))) {
        alert(SPECIFY_TARGET_WFSIP);
        document.getElementById("cabform:txtIp").focus( );
        return false;
    }

    if(document.getElementById("cabform:txtPort").value == "" || document.getElementById("cabform:txtPort").value > 65535 ) {
        alert(SPECIFY_TARGET_WFSPORT);
        document.getElementById("cabform:txtPort").focus( );
        return false;
    }
    

    document.getElementById("cabform:hidSelCabName").value=document.getElementById("cabform:cmbcabname").value;
    document.getElementById("cabform:hidServerIp").value=document.getElementById("cabform:txtIp").value;
    document.getElementById("cabform:hidServerPort").value=document.getElementById("cabform:txtPort").value;
    document.getElementById("cabform:hidTargetDBUser").value=document.getElementById("cabform:DbUserTarget").value;
    document.getElementById("cabform:hidTargetDBPassword").value=document.getElementById("cabform:txtPasswordTarget").value;
    document.getElementById("cabform:hidWebServerIp").value=document.getElementById("cabform:WebServerIP").value;
    document.getElementById("cabform:hidWebServerPort").value=document.getElementById("cabform:WebServerPort").value;
    
    if(document.getElementById("cabform:cmbsitename")!=null)
        document.getElementById("cabform:hidSitename").value=document.getElementById("cabform:cmbsitename").value;
    
    if(document.getElementById("cabform:cmbvolname")!=null)
        document.getElementById("cabform:hidVolname").value=document.getElementById("cabform:cmbvolname").value;
    
    document.getElementById("cabform:hidTempOperation").value ="S";
    
      
}
else{

    
   document.getElementById("cabform:hidSourceDBUser").value=document.getElementById("cabform:DbUserSource").value;
    
    document.getElementById("cabform:hidSourceDBPassword").value=document.getElementById("cabform:txtPasswordSource").value;
     
     document.getElementById("cabform:hidSelCabName").value="";
    document.getElementById("cabform:hidServerIp").value="";
    document.getElementById("cabform:hidServerPort").value="";
    document.getElementById("cabform:hidTargetDBUser").value="";
    document.getElementById("cabform:hidTargetDBPassword").value="";
    document.getElementById("cabform:hidWebServerIp").value="";
    document.getElementById("cabform:hidWebServerPort").value="";
}

    if(document.getElementById("cabform:txtTargetUserName").value == "") {
        alert(SPECIFY_USER_NAME);
        document.getElementById("cabform:txtTargetUserName").focus();
        return false;
    }
    
    if(document.getElementById("cabform:txtTargetUserPassword").value == "") {
        alert(SPECIFY_USER_PASSWORD);
        document.getElementById("cabform:txtTargetUserPassword").focus();
        return false;
    }
    document.getElementById("cabform:hidTargetUserName").value=document.getElementById("cabform:txtTargetUserName").value;
    document.getElementById("cabform:hidTargetUserPassword").value=document.getElementById("cabform:txtTargetUserPassword").value;
      
    if(document.getElementById("cabform:hidOperation").value!="U")
     document.getElementById("cabform:hidOperation").value="I";
    
    if(document.getElementById("cabform:keepSourceIS"))
    {
        if(document.getElementById("cabform:keepSourceIS").checked)
            document.getElementById("cabform:hidKeepSourceIS").value="Y";
        else
            document.getElementById("cabform:hidKeepSourceIS").value="N"; 
    } 
    
    if(bPwdEncrypt == 'Y') {
        var refHidSourceDBPassword = document.getElementById("cabform:hidSourceDBPassword");
        var refHidTargetDBPassword = document.getElementById("cabform:hidTargetDBPassword");
        var refTxtPasswordSource = document.getElementById("cabform:txtPasswordSource");
        var refTxtPasswordTarget = document.getElementById("cabform:txtPasswordTarget");
        var refHidTargetUserPassword = document.getElementById("cabform:hidTargetUserPassword");
        var refTxtTargetUserPassword = document.getElementById("cabform:txtTargetUserPassword");
        
        var bf = new Blowfish('DES');
        var encHidSourceDBPassword = bf.encryptx(refHidSourceDBPassword.value, eToken);
        var encHidTargetDBPassword = bf.encryptx(refHidTargetDBPassword.value, eToken);
        var encTxtPasswordSource = bf.encryptx(refTxtPasswordSource.value, eToken);
        var encTxtPasswordTarget = bf.encryptx(refTxtPasswordTarget.value, eToken);
        var encHidTargetUserPassword = bf.encryptx(refHidTargetUserPassword.value, eToken);
        var encTxtTargetUserPassword = bf.encryptx(refTxtTargetUserPassword.value, eToken);
        
        refHidSourceDBPassword.value = encode_utf8(encHidSourceDBPassword);
        refHidTargetDBPassword.value = encode_utf8(encHidTargetDBPassword);
        refTxtPasswordSource.value = encode_utf8(encTxtPasswordSource);
        refTxtPasswordTarget.value = encode_utf8(encTxtPasswordTarget);
        refHidTargetUserPassword.value = encode_utf8(encHidTargetUserPassword);
        refTxtTargetUserPassword.value = encode_utf8(encTxtTargetUserPassword);
    }
    NewSubmit(referrer);// document.getElementById("cabform").submit();
}


function deleteExportInfo(referer) {
    var bConfirm = confirm(CONFIRM_EXPORT_INFO_DELETE);
    if(!bConfirm)
        return false;
    
   
    if(document.getElementById("cabform:DbUserTarget").value!="") {

    if(Trim(document.getElementById("cabform:txtIp").value) == "") {
        alert(SPECIFY_TARGET_WFSIP);
        return false;
    }
    
    if(Trim(document.getElementById("cabform:txtIp").value) == "") {
        alert(SPECIFY_TARGET_WFSPORT);
        return false;
    }
    


    document.getElementById("cabform:hidSelCabName").value=document.getElementById("cabform:cmbcabname").value;
    document.getElementById("cabform:hidServerIp").value=document.getElementById("cabform:txtIp").value;
    document.getElementById("cabform:hidServerPort").value=document.getElementById("cabform:txtPort").value;
    document.getElementById("cabform:hidTargetDBUser").value=document.getElementById("cabform:DbUserTarget").value;
    document.getElementById("cabform:hidTargetDBPassword").value=document.getElementById("cabform:txtPasswordTarget").value;
    document.getElementById("cabform:hidWebServerIp").value=document.getElementById("cabform:WebServerIP").value;
    document.getElementById("cabform:hidWebServerPort").value=document.getElementById("cabform:WebServerPort").value;
    if(document.getElementById("cabform:hidSitename").value != "")
        document.getElementById("cabform:hidSitename").value=document.getElementById("cabform:cmbsitename").value;
    
    if(document.getElementById("cabform:hidVolname").value != "")
        document.getElementById("cabform:hidVolname").value=document.getElementById("cabform:cmbvolname").value;
      
  
 }   
else {    
    
    
    
    document.getElementById("cabform:hidSelCabName").value="";
    document.getElementById("cabform:hidServerIp").value="";
    document.getElementById("cabform:hidServerPort").value="";
    
    document.getElementById("cabform:hidSourceDBUser").value=document.getElementById("cabform:DbUserSource").value;
    document.getElementById("cabform:hidSourceDBPassword").value=document.getElementById("cabform:txtPasswordSource").value;
    document.getElementById("cabform:hidTargetDBUser").value="";
    document.getElementById("cabform:hidTargetDBPassword").value="";
    document.getElementById("cabform:hidWebServerIp").value="";
    document.getElementById("cabform:hidWebServerPort").value="";
    
    }
 
    if(document.getElementById("cabform:txtTargetUserName").value == "") {
        alert(SPECIFY_USER_NAME);
        document.getElementById("cabform:txtTargetUserName").focus();
        return false;
    }
    
    if(document.getElementById("cabform:txtTargetUserPassword").value == "") {
        alert(SPECIFY_USER_PASSWORD);
        document.getElementById("cabform:txtTargetUserPassword").focus();
        return false;
    }
    document.getElementById("cabform:hidTargetUserName").value=document.getElementById("cabform:txtTargetUserName").value;
    document.getElementById("cabform:hidTargetUserPassword").value=document.getElementById("cabform:txtTargetUserPassword").value;
    
    if(document.getElementById("cabform:keepSourceIS"))
    {
        if(document.getElementById("cabform:keepSourceIS").checked)
            document.getElementById("cabform:hidKeepSourceIS").value="Y";
        else
            document.getElementById("cabform:hidKeepSourceIS").value="N";
    }
    document.getElementById("cabform:hidOperation").value="D";
    //document.getElementById("cabform").submit();    
    NewSubmit(referer);
}


function cablist_init() {
    var thisForm = window.document.forms["textForm"];
    var txtForm = window.parent.frames["export_button"].document.forms["textForm"];
    
    if(thisForm.cabinetList.length > 0)
        txtForm.btnSave.disabled = false;
    else
        txtForm.btnSave.disabled = true;
}
function keepSameISclick(){

      if(document.getElementById("cabform:keepSourceIS"))
    {
        if(document.getElementById("cabform:keepSourceIS").checked){
            document.getElementById("cabform:hidKeepSourceIS").value="Y";
            if(document.getElementById("cabform:siteTable"))
             document.getElementById("cabform:siteTable").style.display="none";
        }
        else{
             if(document.getElementById("cabform:siteTable"))
             document.getElementById("cabform:siteTable").style.display="inline";
             document.getElementById("cabform:hidKeepSourceIS").value="N";
        }

    }
    
}
 /*-----------------------------------------------------------------------------------------------------

File Name			: reportsgeneral.js
Author                          : Shruti Mishra
Date written (DD/MM/YYYY)       : 03/May/2007
Description			: This file contains the methods for dispaling Reprts filter.
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date(DD/MM/YYYY)		Change By               Change Description (Bug No. (If Any))
----------------------------------------------------------------------------------------------------
16/05/2007                      Shruti Mishra           Bug ID 786
08/07/2009                      Bhupesh Kumar           PRM_8.0_011(In case Exception details Reports if try to generate  report without  selecting any process name than "No exception Associated to the selected Process" comes)
06 Aug 2008                     Arup Sharma             BUG ID PRM_8.0_014 (For BAM Reports integration)
 PRM_8.0_037       27/01/2010    Puneet Pahuja                   window.open changed to openNewWindow to open new window using HTTP POST
06/02/2011                       Sri Prakash            PRM_9.0_003  Support for Custom reports in Process Manager
 * 23/08/2011      Anushree Jain	Bug 27971 Security issue
 * Bug 46906       10/07/2014      Jaseem Ansari              - All the request in omniflow containing wd_uid as a parameter should be sent as a post request
 * Bug 54157       27/02/2015    Sri Prakash            Issue in User Performance Report
 ----------------------------------------------------------------------------------------------------*/
var temphtml="";
var myBoolean=0;

function getReportsfilter(strUrl,linkid,docId,reportName)
{
    if(bBAMReports != 'true')        // if PM reports
    {
        var lastIndexSlas=strUrl.lastIndexOf("/");
        var startIndex=strUrl.lastIndexOf(".");
        var tempurl=strUrl.substring(lastIndexSlas+1,startIndex);
        var callbackfunction="callback_"+tempurl+"()";
        var orgUrl="../reports/"+tempurl+".faces?action=1&SelectedIndex="+docId+"&PM_UID="+pm_uid;
        makeAjaxCall(orgUrl,"ResultContainer",'report',callbackfunction);
    }
    else                    // If BAM reports
    {
        var ScreenHeight=screen.height;
        var ScreenWidth=screen.width;   
        var WindowHeight=460;
        var WindowWidth=690;
        var WindowLeft=parseInt(ScreenWidth/2)-330;
        var WindowTop=parseInt(ScreenHeight/2)-270;
            
        try
        {
            
            var table1=document.createElement("table");
            table1.id="tab1";
            table1.border=0;
            table1.style.width='98%';
            var tmpRow = null;
            var tmpCell = null;
            tmpRow=table1.insertRow(0);
            tmpCell=tmpRow.insertCell(0);
            tmpCell.className="PMWIDTH60LEFT";
            
            tmpCell.innerHTML = "<label id='PgHeading' class='PMLabelboldGrey' style='width: 100%;'>"+reportName+"</label>";
            
            tmpRow=table1.insertRow(1);
            tmpCell=tmpRow.insertCell(0);
            tmpCell.innerHTML = "<hr style='width: 100%;'/>";
            
            document.getElementById("ResultContainer").innerHTML = "";
            document.getElementById("ResultContainer").appendChild(table1);
            
            var framURL = "/bam/generation/generatereport.faces?ResizeWidth=Y&ReportIndex="+docId+"&EmbeddedView=0111100";
            
            framURL = appendUrlSessionAjax(framURL);
            ifrm = document.createElement("IFRAME");    
            ifrm.setAttribute("src",framURL); 
            ifrm.setAttribute("name", "ReportFrame"); 
            ifrm.setAttribute("id", "ReportFrame"); 
            ifrm.style.width = mRightPaneWidth;

            var hHeight = minPageHeight.substring(0,minPageHeight.indexOf('p'));
            var hframeHeight = hHeight-50;
            
            ifrm.style.height = hframeHeight+"px"; 
            ifrm.style.visibility="visible";
            ifrm.frameBorder="0"; 
            ifrm.style.frameBorder="0"; 
            
            //document.getElementById("ResultContainer").innerHTML = "";
            document.getElementById("ResultContainer").appendChild(ifrm); 
            
            return ifrm;
        }catch(reportframecatch)
        {}    
        
    }
}
function OpenCustomReports()
{

 var ScreenHeight=screen.height;
        var ScreenWidth=screen.width;   
        var WindowHeight=460;
        var WindowWidth=690;
        var WindowLeft=parseInt(ScreenWidth/2)-330;
        var WindowTop=parseInt(ScreenHeight/2)-270;
            
        
            
            var table1=document.createElement("table");
            table1.id="tab1";
            table1.border=0;
            table1.style.width='98%';
            var tmpRow = null;
            var tmpCell = null;
            tmpRow=table1.insertRow(0);
            tmpCell=tmpRow.insertCell(0);
            tmpCell.className="PMWIDTH60LEFT";
            
            tmpCell.innerHTML = "<label id='PgHeading' class='PMLabelboldGrey' style='width: 100%;'>More Reports</label>";
            
            tmpRow=table1.insertRow(1);
            tmpCell=tmpRow.insertCell(0);
            tmpCell.innerHTML = "<hr style='width: 100%;'/>";
            
            document.getElementById("ResultContainer").innerHTML = "";
            document.getElementById("ResultContainer").appendChild(table1);
            
            var framURL = "/processmanager/reports/morereports.faces?Action=1&Length=1&LinkId=-1&PM_UID="+pm_uid;
            
            framURL = appendUrlSessionAjax(framURL);
            ifrm = document.createElement("IFRAME");    
            ifrm.setAttribute("src",framURL); 
            ifrm.setAttribute("name", "ReportFrame"); 
            ifrm.setAttribute("id", "ReportFrame"); 
            ifrm.style.width = mRightPaneWidth;

            var hHeight = minPageHeight.substring(0,minPageHeight.indexOf('p'));
            var hframeHeight = hHeight-50;
            
            ifrm.style.height = hframeHeight+"px"; 
            ifrm.style.visibility="visible";
            ifrm.frameBorder="0"; 
            ifrm.style.frameBorder="0"; 
            
            //document.getElementById("ResultContainer").innerHTML = "";
            document.getElementById("ResultContainer").appendChild(ifrm); 
            
            return ifrm;
        

}
function callback_process_history_frameset()
{
   changeReportType('procframeset');
}
function callback_user_performance_frameset()
{
    changeReportType('userperformframeset');
}
function callback_userperf_compare_frameset()
{
    setInitialValueuser();
}
function callback_avg_process_time_frameset()
{
    setInitialValue('averageprocesstime');
}

function callback_pat_frameset()
{
   setInitialValue('partcipentavgtime'); 
}
function callback_partproc_frameset()
{
    setInitialValue('partprocreport');
}
function callback_delay_frameset()
{
    changeReportType('delayframeset');
}
function callback_tat_frameset()
{
    changeReportType('tatframeset');
}
function callback_process_def_summary_frameset()
{
    
}
function callback_exception_details_frameset()
{
    changeReportType('exceptiondetails');
}
function callback_expiry_frameset()
{
    changeReportType('expirydetails');
}
function callback_diversion_frameset()
{
    
}
function callback_queueassign_frameset()
{
    
}

//Original reportgeneral.js
function verifyReportDate(fromYear,fromMonth,fromDay,fromHours,toYear,toMonth,toDay,toHours)
{
    
    if(!VerifyDate(fromYear,fromMonth,fromDay))
            {
                alert(INVALID_FROM_DATE);
                return false;
            }
           
        if(!VerifyDate(toYear,toMonth,toDay))
            {
                alert(INVALID_TO_DATE);
                return false ;    
            }
 
        var f_date = new Date(fromYear,fromMonth-1,fromDay,fromHours);
        var t_date = new Date(toYear,toMonth-1,toDay,toHours);
             if(f_date>=t_date)
                {
                    alert(FROMDATE_GREATERTHAN_TODATE);
                    return false;
                }
 
         
             if(new Date(toYear,toMonth-1,toDay,toHours-1) > new Date())
                 {
                    alert(TODATE_GREATERTHAN_CURRDATE);
                    return false;
                 }
 
return true;
}

 function enableButtons(ref,radioType,otherRadioId,durationhandel,fromdayhandle,frommonthhandle,fromYearhandle,fromhourhandle,toDayhandle,toMonthhandle,toYearhandle,tohourhandle)  
                        {
                          
                          
			 var formId=ref.form.id;
			 
                          if(formId=="averageprocesstime" || formId=="partcipentavgtime" || formId=="partprocreport" || formId=="usercompareframeset")
                           {
							
                            enableButtonswithoutreporttype(ref,radioType,otherRadioId,durationhandel,fromdayhandle,frommonthhandle,fromYearhandle,fromhourhandle,toDayhandle,toMonthhandle,toYearhandle,tohourhandle)  
                             return;
                            
                            }
                          changeReportType(formId);
                          var radioID=ref.name;
                          
                          
                          
                          document.forms[0].elements[otherRadioId].checked=false;
                          if(radioType=='selduration')
                            {
                                    //Changes added for fixing bug no 
				    var opReportDuration = document.getElementById(formId+":opDuration");
                                    
                                    var temp=opReportDuration.selectedIndex;
                                    opReportDuration.remove(0);
                                    opReportDuration.options[0] = new Option(REPORT_TODAY,"Today");
                                    opReportDuration.options[1] = new Option(REPORT_LAST_DAY,"Day");
                                    opReportDuration.options[2] = new Option(REPORT_LAST_WEEK,"Week");
                                    opReportDuration.options[3] = new Option(REPORT_LAST_MONTH,"Month");
                                    opReportDuration.options[4] = new Option(REPORT_LAST_QUARTER,"Quarter");
                                    opReportDuration.options[5] = new Option(REPORT_LAST_YEAR,"Year");
									
                                    //Changes End
                                    document.getElementById(formId+":opType").disabled=false;
                                    document.getElementById(durationhandel).disabled=false;
                                    document.getElementById(fromdayhandle).disabled=true;
                                    document.getElementById(frommonthhandle).disabled=true;
                                    document.getElementById(fromYearhandle).disabled=true;
                                    document.getElementById(fromhourhandle).disabled=true;
                                    document.getElementById(toDayhandle).disabled=true;
                                    document.getElementById(toMonthhandle).disabled=true;
                                    document.getElementById(toYearhandle).disabled=true;
                                    document.getElementById(tohourhandle).disabled=true;
                                    document.getElementById(formId+":radiooption").value="0";
                            }
                          else if(radioType=='selbetween')  
                             {
                                   document.getElementById(formId+":duration").value="";
                                    document.getElementById(formId+":durationType").value="";   
                                   var opReportType = document.getElementById(formId+":opType");
                                    
                                    var temp=opReportType.selectedIndex;
                                    opReportType.remove(0);
                                    opReportType.options[0] = new Option(REPORT_DAY,"D");
                                    opReportType.options[0].selected=true;
				  //Changes added for seeting report duration default value 'Last Week' when between is //selected
                                     var opReportDuration = document.getElementById(formId+":opDuration");
                                    
                                    var temp=opReportDuration.selectedIndex;
                                    opReportDuration.remove(0);
                                    opReportDuration.options[0] = new Option(REPORT_LAST_WEEK,"Week");
                                    opReportDuration.options[0].selected=true;
				//Changes ende
                                    document.getElementById(formId+":opType").disabled=true;
                                    document.getElementById(durationhandel).disabled=true;
                                    document.getElementById(fromdayhandle).disabled=false;
                                    document.getElementById(frommonthhandle).disabled=false;
                                    document.getElementById(fromYearhandle).disabled=false;
                                    document.getElementById(fromhourhandle).disabled=false;
                                    document.getElementById(toDayhandle).disabled=false;
                                    document.getElementById(toMonthhandle).disabled=false;
                                    document.getElementById(toYearhandle).disabled=false;
                                    document.getElementById(tohourhandle).disabled=false;
                                    document.getElementById(formId+":radiooption").value="1";
                             }
                        
                        }


    function changeReportType(formId)
            {
                   
                    try{
                    if(formId=='exceptiondetails')
                    {
                    try{
                            var hiddenval=document.getElementById("exceptiondetails:hidval").value;
                            
                                   if(hiddenval=='2')
                                {
                                   
                                    setfieldvalue('exceptiondetails');
                                    document.getElementById("exceptiondetails:hidval").value='';
                                    return;
                                   }    
                                }
                                catch(ee){}
                    }//For back button on Exceptiondetal report
                       
                     var index = document.getElementById(formId+":opDuration").selectedIndex;
                     document.getElementById(formId+":hidReportduration").value="Today";
                     document.getElementById(formId+":hidReportType").value="H";
                     if(formId=='exceptiondetails')
                        {	
                            var radioval=document.getElementById(formId+":radiooption").value;
                           
                            if(radioval==1)
                            {
                               
                               
                                //document.getElementById(formId+":durationType").checked=false;
                                document.getElementById(formId+":opDuration").disabled=true;
                                document.getElementById(formId+":between").checked=true;
                                document.getElementById(formId+":radiooption").value="1";
                                document.getElementById(formId+":cmbFromDay").disabled=false;
                                document.getElementById(formId+":cmbFromMonth").disabled=false;
                                document.getElementById(formId+":cmbFromYear").disabled=false;
                                document.getElementById(formId+":cmbFromhours").disabled=false;
                                document.getElementById(formId+":cmbToDay").disabled=false;
                                document.getElementById(formId+":cmbToMonth").disabled=false;
                                document.getElementById(formId+":cmbToYear").disabled=false;
                                document.getElementById(formId+":cmbTohours").disabled=false;

                                var opReportType = document.getElementById(formId+":opType");

                                var temp=opReportType.selectedIndex;
                                opReportType.remove(0);
                                opReportType.options[0] = new Option(REPORT_DAY,"D");
                                opReportType.options[0].selected=true;
                                //Changes added for seeting report duration default value 'Last Week' when between is //selected
                                var opReportDuration = document.getElementById(formId+":opDuration");

                                var temp=opReportDuration.selectedIndex;
                                opReportDuration.remove(0);
                                opReportDuration.options[0] = new Option(REPORT_LAST_WEEK,"Week");
                                opReportDuration.options[0].selected=true;
                                document.getElementById(formId+":opType").disabled=true;
                                
                            }
                            else if(radioval=='selbetween')
                            {
                                 document.getElementById(formId+":opDuration").disabled=true;
                                document.getElementById(formId+":between").checked=true;
                                document.getElementById(formId+":radiooption").value="1";
                                document.getElementById(formId+":cmbFromDay").disabled=false;
                                document.getElementById(formId+":cmbFromMonth").disabled=false;
                                document.getElementById(formId+":cmbFromYear").disabled=false;
                                document.getElementById(formId+":cmbFromhours").disabled=false;
                                document.getElementById(formId+":cmbToDay").disabled=false;
                                document.getElementById(formId+":cmbToMonth").disabled=false;
                                document.getElementById(formId+":cmbToYear").disabled=false;
                                document.getElementById(formId+":cmbTohours").disabled=false;

                                var opReportType = document.getElementById(formId+":opType");

                                var temp=opReportType.selectedIndex;
                                opReportType.remove(0);
                                opReportType.options[0] = new Option(REPORT_DAY,"D");
                                opReportType.options[0].selected=true;
                                //Changes added for seeting report duration default value 'Last Week' when between is //selected
                                var opReportDuration = document.getElementById(formId+":opDuration");

                                var temp=opReportDuration.selectedIndex;
                                opReportDuration.remove(0);
                                opReportDuration.options[0] = new Option(REPORT_LAST_WEEK,"Week");
                                opReportDuration.options[0].selected=true;
                                document.getElementById(formId+":opType").disabled=true;

                            }    
                            else
                            {
                               
                                document.forms[0][formId+":durationType"].checked=true;
                                document.getElementById(formId+":radiooption").value="0";
                                document.getElementById(formId+":cmbFromDay").disabled=true;
                                document.getElementById(formId+":cmbFromMonth").disabled=true;
                                document.getElementById(formId+":cmbFromYear").disabled=true;
                                document.getElementById(formId+":cmbFromhours").disabled=true;
                                document.getElementById(formId+":cmbToDay").disabled=true;
                                document.getElementById(formId+":cmbToMonth").disabled=true;
                                document.getElementById(formId+":cmbToYear").disabled=true;
                                document.getElementById(formId+":cmbTohours").disabled=true;
                                var durationindex=document.getElementById(formId+":opDuration").selectedIndex;
                                var typeindex=document.getElementById(formId+":opType").selectedIndex;
                                val=document.getElementById(formId+":opDuration").options[durationindex].value;
                                valReportType=document.getElementById(formId+":opType").options[typeindex].value
                                
                                document.getElementById(formId+":hidReportduration").value=val;
                                
                            }
                    }
                    else
                    {
                        
                        document.forms[0][formId+":durationType"].checked=true;
                        document.getElementById(formId+":radiooption").value="0";
                        document.getElementById(formId+":cmbFromDay").disabled=true;
                        document.getElementById(formId+":cmbFromMonth").disabled=true;
                        document.getElementById(formId+":cmbFromYear").disabled=true;
                        document.getElementById(formId+":cmbFromhours").disabled=true;
                        document.getElementById(formId+":cmbToDay").disabled=true;
                        document.getElementById(formId+":cmbToMonth").disabled=true;
                        document.getElementById(formId+":cmbToYear").disabled=true;
                        document.getElementById(formId+":cmbTohours").disabled=true;
                         
                    }
                    var opReportType = document.getElementById(formId+":opType");
                    var opLength = opReportType.length;
                    var iCount;
                   
                    for(iCount=(opLength-1);iCount >= 0 ; iCount--)			
                    {
                            opReportType.remove(iCount);
                    }

                    if(index == 0 || index == 1)
                            {
                                    opReportType.options[0] = new Option(REPORT_HOUR,"H");
                            }
                    if(index == 2)
                            {
                                    opReportType.options[0] = new Option(REPORT_DAY,"D");
                            }
                    if(index == 3)
                            {
                                    opReportType.options[0] = new Option(REPORT_DAY,"D");
                                    opReportType.options[1] = new Option(REPORT_WEEK,"W");
                            }
                    if(index == 4)
                            {
                                    opReportType.options[0] = new Option(REPORT_DAY,"D");
                                    opReportType.options[1] = new Option(REPORT_WEEK,"W");
                                    opReportType.options[2] = new Option(REPORT_MONTH,"M");
                            }
                            if(index == 5)
                            {
                                    opReportType.options[0] = new Option(REPORT_DAY,"D");
                                    opReportType.options[1] = new Option(REPORT_WEEK,"W");
                                    opReportType.options[2] = new Option(REPORT_MONTH,"M");
                                    opReportType.options[3] = new Option(QUARTER,"Q");
                            }

                            var selValue = document.getElementById(formId+":hidReportType").value;

                            for(iCount = 0 ; iCount < opReportType.length ; iCount++)
                            {
                                    if(opReportType.options[iCount].value == selValue)
                                    {
                                            opReportType.options[iCount].selected = true;
                                            break;
                                    }
                            }	
                            }
                            catch(ex)
                            {}
            }   

    function setreportduration(formId)
    {
     
     if(formId=="averageprocesstime" || formId=="partcipentavgtime" ||formId=="partprocreport" || formId=="usercompareframeset")
     {
		
        setreportdurationwithoutreporttype(formId);
        return;
     }
     changeReportType(formId);
    var index = document.getElementById(formId+":opDuration").selectedIndex;
    if(index==0)
    document.getElementById(formId+":hidReportduration").value="Today";
    else if(index==1) 
     document.getElementById(formId+":hidReportduration").value="Day";
    else if(index==2)
      document.getElementById(formId+":hidReportduration").value="Week";
    else if(index==3)
      document.getElementById(formId+":hidReportduration").value="Month";
    else if(index==4)
      document.getElementById(formId+":hidReportduration").value="Quarter";
    else if(index==5)
      document.getElementById(formId+":hidReportduration").value="Year";   
    }
    function setreporttype(formId)
    {
    var index = document.getElementById(formId+":opType").selectedIndex;
    if(index==0)
    document.getElementById(formId+":hidReportType").value="D";
    else if(index==1) 
     document.getElementById(formId+":hidReportType").value="W";
    else if(index==2)
      document.getElementById(formId+":hidReportType").value="M";
    else if(index==3)
      document.getElementById(formId+":hidReportType").value="Q";

    }

function EnableDisableWorkstepButton(formId)
{

        
        if(document.getElementById(formId+":hidProcessID").value > 0 )
        {
            document.getElementById(formId+":cmdPicklist_workstep").disabled=false;



        }
        else
        {
            document.getElementById(formId+":cmdPicklist_workstep").disabled=true;

        }

        document.getElementById(formId+":hidWorkstepID").value=' ';
        if(formId=='partprocreport')
        {
           
            document.getElementById(formId+":hidWorkstepName").value=REPORT_SELECT_WORKSTEPS;
            document.getElementById(formId+":txtWorkstepName").value=REPORT_SELECT_WORKSTEPS;
        }
        else
        {
           
            document.getElementById(formId+":hidWorkstepName").value=REPORT_ALL_WORKSTEPS;
            document.getElementById(formId+":txtWorkstepName").value=REPORT_ALL_WORKSTEPS;
        }
       
}
                
 function ShowWorkstepListforreport(ref,hidProcessName,hidProcessID,txtWorkstepName,hidWorkstepID,hidWorkstepName,mode)
{
	
    var formid=ref.form.id;
	

    var procID= document.getElementById(formid+":"+hidProcessID).value;
    var procName= document.getElementById(formid+":"+hidProcessName).value;
    ShowPickList(ref,'WFWorkstepList',txtWorkstepName,hidWorkstepID,hidWorkstepName,'2','','1','',procID,procName,mode);
}

function setInitialValue(formId)
{
    window.self.focus();

    document.getElementById(formId+":hidReportduration").value="Week";

    document.forms[0][formId+":durationType"].checked=true;
    document.getElementById(formId+":radiooption").value="0";
    //Changes added by shruti for Bug Id 607
    document.getElementById(formId+":cmbFromDay").disabled=true;
    document.getElementById(formId+":cmbFromMonth").disabled=true;
    document.getElementById(formId+":cmbFromYear").disabled=true;
    document.getElementById(formId+":cmbFromhours").disabled=true;
    document.getElementById(formId+":cmbToDay").disabled=true;
    document.getElementById(formId+":cmbToMonth").disabled=true;
    document.getElementById(formId+":cmbToYear").disabled=true;
    document.getElementById(formId+":cmbTohours").disabled=true;
    //chnages End
} 

function enableButtonswithoutreporttype(ref,radioType,otherRadioId,durationhandel,fromdayhandle,frommonthhandle,fromYearhandle,fromhourhandle,toDayhandle,toMonthhandle,toYearhandle,tohourhandle)  
{
  var formId=ref.form.id;
  var radioID=ref.name;
  document.forms[0].elements[otherRadioId].checked=false;
  if(radioType=='selduration')
    {

            document.getElementById(formId+":durationType").checked=true;
            document.getElementById(formId+":between").checked=false;

            document.getElementById(durationhandel).disabled=false;
            document.getElementById(fromdayhandle).disabled=true;
            document.getElementById(frommonthhandle).disabled=true;
            document.getElementById(fromYearhandle).disabled=true;
            document.getElementById(fromhourhandle).disabled=true;
            document.getElementById(toDayhandle).disabled=true;
            document.getElementById(toMonthhandle).disabled=true;
            document.getElementById(toYearhandle).disabled=true;
            document.getElementById(tohourhandle).disabled=true;
            document.getElementById(formId+":radiooption").value="0";
    }
  else if(radioType=='selbetween')  
     {
            document.getElementById(formId+":duration").value="";
            document.getElementById(formId+":durationType").value="";    
            document.getElementById(formId+":durationType").checked=false;
            document.getElementById(formId+":between").checked=true;
            document.getElementById(durationhandel).disabled=true;
            document.getElementById(fromdayhandle).disabled=false;
            document.getElementById(frommonthhandle).disabled=false;
            document.getElementById(fromYearhandle).disabled=false;
            document.getElementById(fromhourhandle).disabled=false;
            document.getElementById(toDayhandle).disabled=false;
            document.getElementById(toMonthhandle).disabled=false;
            document.getElementById(toYearhandle).disabled=false;
            document.getElementById(tohourhandle).disabled=false;
            document.getElementById(formId+":radiooption").value="1";
     }
	 if(formId=='usercompareframeset')
	{
	 var pre=document.getElementById("usercompareframeset:radiooption").value;
	document.getElementById("usercompareframeset:setradiooption").value=document.getElementById("usercompareframeset:radiooption").value;
	}

}
function setreportdurationwithoutreporttype(formId)
{

var index = document.getElementById(formId+":opDuration").selectedIndex;

if(index==0)
  document.getElementById(formId+":hidReportduration").value="Week";
else if(index==1)
  document.getElementById(formId+":hidReportduration").value="Month";
else if(index==2)
  document.getElementById(formId+":hidReportduration").value="Quarter";
else if(index==3)
  document.getElementById(formId+":hidReportduration").value="Year";   
}

function displayreportprocesshistory(ref)
{
 if(document.getElementById('procframeset:hidProcessId').value <= 0 )
 {
    alert(SELECT_SINGLE_PROCESS);
    return false;
 } 

var url=ref.form.action;
var strFormval = getFormValues(ref,"validate"); 

var selradio=(document.getElementById('procframeset:radiooption').value);
var startDate="";
var endDate="";   
var endTime="";
var startTime="";
var introFlag="";
var complete="";
var abort="";
var processed="";
var expired="";
var enterinact="";
//Changes Done by Shruti for Bug id 559
if(document.getElementById('procframeset:hidProcessId').value >0 )
{

var actVal=document.getElementById('procframeset:hidWorkstepId').value;
actVal=Trim(actVal);
if(actVal.length==0)
    {
        introFlag=document.getElementById("procframeset:intro").checked;
        complete=document.getElementById("procframeset:complete").checked;
        abort=document.getElementById("procframeset:abort").checked;
        processed=false;
        expired=false;
        enterinact=false;

    }
  else
{
    processed=document.getElementById("procframeset:processed").checked;
    expired=document.getElementById("procframeset:expired").checked;
    enterinact=document.getElementById("procframeset:enterinwkstep").checked;
    introFlag=false;
    complete=false;
    abort=false;
}  
}

//Changes End

if( selradio=="0" && (document.getElementById("procframeset:opType").options[0].value=="H" ||document.getElementById("procframeset:opType").options[0].value=="D" ||document.getElementById("procframeset:opType").options[0].value=="W" ||document.getElementById("procframeset:opType").options[0].value=="M" || document.getElementById("procframeset:opType").options[0].value=="Q" ))
      {
        
        var date = new Date();
        var mins=date.getMinutes();
        var hrs=date.getHours();
        if(hrs<10)
                hrs=format(hrs);
       if (mins<10) 
               mins=format(mins);
        var reportDurationval = document.getElementById('procframeset:hidReportduration').value;
        
        var startTime=" 00"+SYMBOL_3+"00"+SYMBOL_3+"00";
        if(reportDurationval == "Day")
                 endTime=" 23"+SYMBOL_3+"59"+ SYMBOL_3+"59";
        else
                 endTime=" "+hrs+SYMBOL_3+mins+SYMBOL_3+"00";

        endDate = date.getYear()+'-'+date.getMonth()+'-'+date.getDate();

        document.getElementById('procframeset:hidenenddate').value = endDate;
        document.getElementById('procframeset:hidenendtime').value= endTime;
        document.getElementById('procframeset:hidenstarttime').value = startTime;
        //document.getElementById('procframeset:hidReportType').value="H";
         

      }
    else
       {
        
         var fromYear = document.getElementById("procframeset:cmbFromYear").value;
         var fromMonth = document.getElementById("procframeset:cmbFromMonth").value;
         var fromDay = document.getElementById("procframeset:cmbFromDay").value;
         var fromHours = document.getElementById("procframeset:cmbFromhours").value;
         var fromMins = 0;

         var toYear =document.getElementById("procframeset:cmbToYear").value;
         var toMonth =document.getElementById("procframeset:cmbToMonth").value;
        var toDay = document.getElementById("procframeset:cmbToDay").value;
        var toHours = document.getElementById("procframeset:cmbTohours").value;

        var toMins = 0;
        var date = new Date();
        var cYear = date.getYear();
        var cMonth = (date.getMonth()+1);
        var cDay = date.getDate();
        var cHour = date.getHours();
        var cMins = date.getMinutes();
         fromYear = eval(fromYear);
         fromMonth = eval(fromMonth);
         fromDay = eval(fromDay);
         fromHours = eval(fromHours);
         toYear = eval(toYear);
         toMonth = eval(toMonth);
         toDay = eval(toDay);
         toHours = eval(toHours);
         
        if(!verifyReportDate(fromYear,fromMonth,fromDay,fromHours,toYear,toMonth,toDay,toHours))
            return false;
         
         
        var month = parseInt(fromMonth);
        if(month <10)
                month = format(month);

        var day = parseInt(fromDay);
        if(day <10)
                day = format(day);

        var hours=parseInt(fromHours);

        if(hours<10)
                hours=format(hours);



        var mins=parseInt(fromMins);
        //if(mins<10) 
                mins=format(mins);

         startTime=" "+hours+SYMBOL_3+mins+SYMBOL_3+"00";
         startDate = fromYear+SYMBOL_2+month+SYMBOL_2+day;

         month = parseInt(toMonth);
        if(month <10)
                month =format(month);

        day = parseInt(toDay);
        if(day <10)
                day = format(day);

        hours=parseInt(toHours);

        if(hours<10)
                hours=format(hours);


        mins=parseInt(toMins);

        if(mins<10) 
        mins=format(mins);

        endTime=" "+hours+SYMBOL_3+mins+SYMBOL_3+"00";
        endDate = toYear+SYMBOL_2+month+SYMBOL_2+day;

        document.getElementById('procframeset:hidReportduration').value = document.getElementById('procframeset:opDuration').value;
        document.getElementById('procframeset:hidenenddate').value = endDate;
        document.getElementById('procframeset:hidenstartdate').value = startDate;
        document.getElementById('procframeset:hidenstarttime').value=startTime;
        document.getElementById('procframeset:hidenendtime').value=endTime;


       }

    var activityname=(document.getElementById('procframeset:hidWorkstepName').value);
    var procname=(document.getElementById('procframeset:hidProcessName').value);
    var procdefid=(document.getElementById('procframeset:hidProcessId').value);
    var actid=(document.getElementById('procframeset:hidWorkstepId').value);
    var reporttype=(document.getElementById('procframeset:hidReportType').value);
    var reprtduration=(document.getElementById('procframeset:hidReportduration').value);
    var startdate=(document.getElementById('procframeset:hidenfromdate').value);
    var selradio=(document.getElementById('procframeset:radiooption').value);
    //changes By Shruti Mishra for bug Id 590

    if(reprtduration=="Week" && reporttype=="H")
    reporttype="D";
    else if(reprtduration=="Month" && reporttype=="H")
    reporttype="D";
    else if(reprtduration=="Quarter" && reporttype=="H")
    reporttype="D";
    else if(reprtduration=="Year" && reporttype=="H")
    reporttype="D";
   //Changes End
   if(reprtduration=="Day" || reprtduration=="Today")
   reporttype="H";
  
   // makeAjaxCall(url,"ResultContainer",'hcffd','');

document.getElementById('activityname').value=activityname;
document.getElementById('procname').value=procname;
document.getElementById('procdefid').value=procdefid;
document.getElementById('actid').value=actid;
document.getElementById('reporttype').value=reporttype;
document.getElementById('reprtduration').value=reprtduration;
document.getElementById('endTime').value=endTime;
document.getElementById('endDate').value=endDate;
document.getElementById('startDate').value=startDate;
document.getElementById('startTime').value=startTime;
document.getElementById('selradio').value=selradio;
document.getElementById('introFlag').value=introFlag;
document.getElementById('complete').value=complete;
document.getElementById('abort').value=abort;
document.getElementById('processed').value=processed;
document.getElementById('expired').value=expired;

document.getElementById('enterinact').value=enterinact;
var url="../reports/processhistorydisplay.faces?activityname="+encode_utf8(activityname)+"&procname="+encode_utf8(procname)+"&procdefid="+procdefid+"&actid="+actid+"&reporttype="+reporttype+"&reprtduration="+encode_utf8(reprtduration)+"&endTime="+encode_utf8(endTime)+"&startDate="+encode_utf8(startDate)+"&endDate="+endDate+"&startTime="+encode_utf8(startTime)+"&selradio="+selradio+"&introFlag="+introFlag+"&complete="+complete+"&abort="+abort+"&processed="+processed+"&expired="+expired+"&enterinact="+enterinact+"&PM_UID="+pm_uid;

   NewSubmit(ref);
}

 
function displayreportaverageprocesstime(ref)
    {
    var startDate="";
    var endDate="";   
    var endTime="";
    var startTime="";
    var browser=navigator.appName
    var selradio=(document.getElementById('averageprocesstime:radiooption').value);
    
    if((document.forms[0]['averageprocesstime:durationType'].checked)&&selradio=="0")
      {
        var date = new Date();
        var mins=date.getMinutes();
        var hrs=date.getHours();
        if(hrs<10)
                hrs=format(hrs);
       if (mins<10) 
               mins=format(mins);
        var reportDurationval = document.getElementById('averageprocesstime:hidReportduration').value;

         startTime=" "+date.getHours()+SYMBOL_3+ "00"+SYMBOL_3+ "00";
         endTime=" "+date.getHours()+SYMBOL_3+mins+SYMBOL_3+ "00";
         //Changes done by Shruti for Bug Id-625
            if(browser=='Netscape')
               endDate = (date.getYear()+1900)+'-'+date.getMonth()+'-'+date.getDate();
           else if(browser=='Microsoft Internet Explorer')
                endDate = date.getYear()+'-'+date.getMonth()+'-'+date.getDate();
    //Changes end


        document.getElementById('averageprocesstime:hidenenddate').value = endDate;
        document.getElementById('averageprocesstime:hidenendtime').value= endTime;
        document.getElementById('averageprocesstime:hidenstarttime').value = startTime;


      }
    else
       {
       
         var fromYear = document.getElementById("averageprocesstime:cmbFromYear").value;
         var fromMonth = document.getElementById("averageprocesstime:cmbFromMonth").value;
         var fromDay = document.getElementById("averageprocesstime:cmbFromDay").value;
         var fromHours = document.getElementById("averageprocesstime:cmbFromhours").value;
         var fromMins = 0;

         var toYear =document.getElementById("averageprocesstime:cmbToYear").value;
         var toMonth =document.getElementById("averageprocesstime:cmbToMonth").value;
        var toDay = document.getElementById("averageprocesstime:cmbToDay").value;
        var toHours = document.getElementById("averageprocesstime:cmbTohours").value;

         fromYear = eval(fromYear);
         fromMonth = eval(fromMonth);
         fromDay = eval(fromDay);
         fromHours = eval(fromHours);
         toYear = eval(toYear);
         toMonth = eval(toMonth);
         toDay = eval(toDay);
         toHours = eval(toHours);
         
        var toMins = 0;
        var date = new Date();
        var cYear = date.getYear();
        var cMonth = (date.getMonth()+1);
        var cDay = date.getDate();
        var cHour = date.getHours();
        var cMins = date.getMinutes();
         if(!verifyReportDate(fromYear,fromMonth,fromDay,fromHours,toYear,toMonth,toDay,toHours))
            return false;
            
        var month = parseInt(fromMonth);
        if(month <10)
                month = format(month);

        var day = parseInt(fromDay);
        if(day <10)
                day = format(day);

        var hours=parseInt(fromHours);

        if(hours<10)
                hours=format(hours);



        var mins=parseInt(fromMins);
        //if(mins<10) 
                mins=format(mins);

         startTime=" "+hours+SYMBOL_3+mins+SYMBOL_3+"00";
         startDate = fromYear+SYMBOL_2+month+SYMBOL_2+day;

         month = parseInt(toMonth);
        if(month <10)
                month =format(month);

        day = parseInt(toDay);
        if(day <10)
                day = format(day);

        hours=parseInt(toHours);

        if(hours<10)
                hours=format(hours);


        mins=parseInt(toMins);

        if(mins<10) 
        mins=format(mins);

        endTime=" "+hours+SYMBOL_3+mins+SYMBOL_3+"00";
        endDate = toYear+SYMBOL_2+month+SYMBOL_2+day;

        document.getElementById('averageprocesstime:hidReportduration').value = document.getElementById('averageprocesstime:opDuration').value;
        document.getElementById('averageprocesstime:hidenenddate').value = endDate;
        document.getElementById('averageprocesstime:hidenstartdate').value = startDate;
        document.getElementById('averageprocesstime:hidenstarttime').value=startTime;
        document.getElementById('averageprocesstime:hidenendtime').value=endTime;
        //return true;

       }

       
    var procname=(document.getElementById('averageprocesstime:hidProcessName').value);
    var procdefid=(document.getElementById('averageprocesstime:hidProcessID').value);
    var reprtduration=(document.getElementById('averageprocesstime:hidReportduration').value);
    var startdate=(document.getElementById('averageprocesstime:hidenfromdate').value);
    var selradio=(document.getElementById('averageprocesstime:radiooption').value);
    var url="../reports/avgproctimedisplay.faces?procname="+encode_utf8(procname)+"&procdefid="+procdefid+"&reprtduration="+encode_utf8(reprtduration)+"&endTime="+encode_utf8(endTime)+"&startDate="+encode_utf8(startDate)+"&endDate="+endDate+"&startTime="+encode_utf8(startTime)+"&selradio="+selradio+"&PM_UID="+pm_uid;
    document.getElementById('procname').value=procname;
    document.getElementById('procdefid').value=procdefid;
    document.getElementById('reprtduration').value=reprtduration;
    document.getElementById('endTime').value=endTime;
    document.getElementById('endDate').value=endDate;
    document.getElementById('startDate').value=startDate;
    document.getElementById('startTime').value=startTime;
    document.getElementById('selradio').value=selradio;
    NewSubmit(ref);
   //makeAjaxCall(url,"ResultContainer",'avg','');
    
}
function displayreportpartcipentavgtime(ref)
{
     var selradio=(document.getElementById('partcipentavgtime:radiooption').value);
     if(document.getElementById('partcipentavgtime:hidProcessID').value <= 0 )
         {
            alert(SELECT_SINGLE_PROCESS);
            return false;
         } 
      if(document.getElementById('partcipentavgtime:ItemID').value <= 0 )
         {
            alert(SELECT_USER);
            return false;
         }    

     var startDate="";
     var endDate="";   
     var endTime="";
     var startTime="";
     var browser=navigator.appName
    if(
        (document.forms[0]['partcipentavgtime:durationType'].checked)&&selradio=="0" )
          {
            var date = new Date();
            var mins=date.getMinutes();
            var hrs=date.getHours();
            if(hrs<10)
                    hrs=format(hrs);
           if (mins<10) 
                   mins=format(mins);
            var reportDurationval = document.getElementById('partcipentavgtime:hidReportduration').value;
            startTime=" "+date.getHours()+SYMBOL_3+ "00"+SYMBOL_3+ "00";
            endTime=" "+date.getHours()+SYMBOL_3+mins+SYMBOL_3+ "00";
            //Changes done by Shruti for Bug Id-625
                if(browser=='Netscape')
                   endDate = (date.getYear()+1900)+'-'+date.getMonth()+'-'+date.getDate();
               else if(browser=='Microsoft Internet Explorer')
                    endDate = date.getYear()+'-'+date.getMonth()+'-'+date.getDate();
        //Changes end

            document.getElementById('partcipentavgtime:hidenenddate').value = endDate;
            document.getElementById('partcipentavgtime:hidenendtime').value= endTime;
            document.getElementById('partcipentavgtime:hidenstarttime').value = startTime;
          }
        else
           {
             var fromYear = document.getElementById("partcipentavgtime:cmbFromYear").value;
             var fromMonth = document.getElementById("partcipentavgtime:cmbFromMonth").value;
             var fromDay = document.getElementById("partcipentavgtime:cmbFromDay").value;
             var fromHours = document.getElementById("partcipentavgtime:cmbFromhours").value;
             var fromMins = 0;

             var toYear =document.getElementById("partcipentavgtime:cmbToYear").value;
             var toMonth =document.getElementById("partcipentavgtime:cmbToMonth").value;
            var toDay = document.getElementById("partcipentavgtime:cmbToDay").value;
            var toHours = document.getElementById("partcipentavgtime:cmbTohours").value;

            fromYear = eval(fromYear);
            fromMonth = eval(fromMonth);
            fromDay = eval(fromDay);
            fromHours = eval(fromHours);
            toYear = eval(toYear);
            toMonth = eval(toMonth);
            toDay = eval(toDay);
            toHours = eval(toHours);
         
            var toMins = 0;
            var date = new Date();
            var cYear = date.getYear();
            var cMonth = (date.getMonth()+1);
            var cDay = date.getDate();
            var cHour = date.getHours();
            var cMins = date.getMinutes();
            if(!verifyReportDate(fromYear,fromMonth,fromDay,fromHours,toYear,toMonth,toDay,toHours))
            return false;
            var month = parseInt(fromMonth);
            if(month <10)
                    month = format(month);

            var day = parseInt(fromDay);
            if(day <10)
                    day = format(day);

            var hours=parseInt(fromHours);

            if(hours<10)
                    hours=format(hours);
           var mins=parseInt(fromMins);
            //if(mins<10) 
                    mins=format(mins);

             startTime=" "+hours+SYMBOL_3+mins+SYMBOL_3+"00";
             startDate = fromYear+SYMBOL_2+month+SYMBOL_2+day;

             month = parseInt(toMonth);
            if(month <10)
                    month =format(month);

            day = parseInt(toDay);
            if(day <10)
                    day = format(day);

            hours=parseInt(toHours);

            if(hours<10)
                    hours=format(hours);


            mins=parseInt(toMins);

            if(mins<10) 
            mins=format(mins);

            endTime=" "+hours+SYMBOL_3+mins+SYMBOL_3+"00";
            endDate = toYear+SYMBOL_2+month+SYMBOL_2+day;

            document.getElementById('partcipentavgtime:hidReportduration').value = document.getElementById('partcipentavgtime:opDuration').value;
            document.getElementById('partcipentavgtime:hidenenddate').value = endDate;
            document.getElementById('partcipentavgtime:hidenstartdate').value = startDate;
            document.getElementById('partcipentavgtime:hidenstarttime').value=startTime;
            document.getElementById('partcipentavgtime:hidenendtime').value=endTime;


           }


        var procname=(document.getElementById('partcipentavgtime:hidProcessName').value);
        var procdefid=(document.getElementById('partcipentavgtime:hidProcessID').value);
        var username=(document.getElementById('partcipentavgtime:HidItemName').value);
        var usergroupid=(document.getElementById('partcipentavgtime:ItemID').value);
        var activityname=(document.getElementById('partcipentavgtime:hidWorkstepName').value);
        var actid=(document.getElementById('partcipentavgtime:hidWorkstepID').value);
        var reprtduration=(document.getElementById('partcipentavgtime:hidReportduration').value);
        var startdate=(document.getElementById('partcipentavgtime:hidenfromdate').value);
        var selradio=(document.getElementById('partcipentavgtime:radiooption').value); 
        
	document.getElementById('procname').value=procname;
        document.getElementById('procdefid').value=procdefid;
        document.getElementById('activityname').value=activityname;
        document.getElementById('actid').value=actid;
         document.getElementById('username').value=username;
        document.getElementById('usergroupid').value=usergroupid;
        document.getElementById('reprtduration').value=reprtduration;
        document.getElementById('endTime').value=endTime;
        document.getElementById('endDate').value=endDate;
        document.getElementById('startDate').value=startDate;
        document.getElementById('startTime').value=startTime;
        document.getElementById('selradio').value=selradio;	
        //makeAjaxCall(url,"ResultContainer",'partavg','');
                NewSubmit(ref);
        
}

 function displayreportpartprocreport(ref)
{
     var selradio=(document.getElementById('partprocreport:radiooption').value);
     if(document.getElementById('partprocreport:hidProcessID').value <= 0 )
         {
            alert(SELECT_SINGLE_PROCESS);
            return false;
         } 
     if(document.getElementById('partprocreport:hidWorkstepID').value <= 0 )
         {
            alert(SELECT_WORKSTEP);
            return false;
         } 
     var startDate="";
     var endDate="";   
     var endTime="";
     var startTime="";
     var browser=navigator.appName
    if((document.forms[0]['partprocreport:durationType'].checked)&&selradio=="0")
          {
            var date = new Date();
            var mins=date.getMinutes();
            var hrs=date.getHours();
            if(hrs<10)
                    hrs=format(hrs);
           if (mins<10) 
                   mins=format(mins);
            var reportDurationval = document.getElementById('partprocreport:hidReportduration').value;
            startTime=" "+date.getHours()+SYMBOL_3+ "00"+SYMBOL_3+ "00";
            endTime=" "+date.getHours()+SYMBOL_3+mins+SYMBOL_3+ "00";
            //Changes done by Shruti for Bug Id-625
                if(browser=='Netscape')
                   endDate = (date.getYear()+1900)+'-'+date.getMonth()+'-'+date.getDate();
               else if(browser=='Microsoft Internet Explorer')
                    endDate = date.getYear()+'-'+date.getMonth()+'-'+date.getDate();
        //Changes end

            document.getElementById('partprocreport:hidenenddate').value = endDate;
            document.getElementById('partprocreport:hidenendtime').value= endTime;
            document.getElementById('partprocreport:hidenstarttime').value = startTime;
          }
        else
           {
             var fromYear = document.getElementById("partprocreport:cmbFromYear").value;
             var fromMonth = document.getElementById("partprocreport:cmbFromMonth").value;
             var fromDay = document.getElementById("partprocreport:cmbFromDay").value;
             var fromHours = document.getElementById("partprocreport:cmbFromhours").value;
             var fromMins = 0;

             var toYear =document.getElementById("partprocreport:cmbToYear").value;
             var toMonth =document.getElementById("partprocreport:cmbToMonth").value;
            var toDay = document.getElementById("partprocreport:cmbToDay").value;
            var toHours = document.getElementById("partprocreport:cmbTohours").value;

           fromYear = eval(fromYear);
           fromMonth = eval(fromMonth);
           fromDay = eval(fromDay);
           fromHours = eval(fromHours);
           toYear = eval(toYear);
           toMonth = eval(toMonth);
           toDay = eval(toDay);
           toHours = eval(toHours);
           
            var toMins = 0;
            var date = new Date();
            var cYear = date.getYear();
            var cMonth = (date.getMonth()+1);
            var cDay = date.getDate();
            var cHour = date.getHours();
            var cMins = date.getMinutes();
            if(!verifyReportDate(fromYear,fromMonth,fromDay,fromHours,toYear,toMonth,toDay,toHours))
            return false;
            var month = parseInt(fromMonth);
            if(month <10)
                    month = format(month);

            var day = parseInt(fromDay);
            if(day <10)
                    day = format(day);

            var hours=parseInt(fromHours);

            if(hours<10)
                    hours=format(hours);
           var mins=parseInt(fromMins);
            //if(mins<10) 
                    mins=format(mins);

             startTime=" "+hours+SYMBOL_3+mins+SYMBOL_3+"00";
             startDate = fromYear+SYMBOL_2+month+SYMBOL_2+day;

             month = parseInt(toMonth);
            if(month <10)
                    month =format(month);

            day = parseInt(toDay);
            if(day <10)
                    day = format(day);

            hours=parseInt(toHours);

            if(hours<10)
                    hours=format(hours);


            mins=parseInt(toMins);

            if(mins<10) 
            mins=format(mins);

            endTime=" "+hours+SYMBOL_3+mins+SYMBOL_3+"00";
            endDate = toYear+SYMBOL_2+month+SYMBOL_2+day;

            document.getElementById('partprocreport:hidReportduration').value = document.getElementById('partprocreport:opDuration').value;
            document.getElementById('partprocreport:hidenenddate').value = endDate;
            document.getElementById('partprocreport:hidenstartdate').value = startDate;
            document.getElementById('partprocreport:hidenstarttime').value=startTime;
            document.getElementById('partprocreport:hidenendtime').value=endTime;


           }


        var procname=(document.getElementById('partprocreport:hidProcessName').value);
        var procdefid=(document.getElementById('partprocreport:hidProcessID').value);
        var activityname=(document.getElementById('partprocreport:hidWorkstepName').value);
        var actid=(document.getElementById('partprocreport:hidWorkstepID').value);
        var reprtduration=(document.getElementById('partprocreport:hidReportduration').value);
        var startdate=(document.getElementById('partprocreport:hidenfromdate').value);
        var selradio=(document.getElementById('partprocreport:radiooption').value);
        //var url="../reports/&+"&reprtduration="+encode_utf8(reprtduration)+"&endTime="+encode_utf8(endTime)+"&startDate="+encode_utf8(startDate)+"&endDate="+endDate+"&startTime="+encode_utf8(startTime)+"&selradio="+selradio;
        document.getElementById('procname').value=procname;
        document.getElementById('procdefid').value=procdefid;
        document.getElementById('activityname').value=activityname;
        document.getElementById('actid').value=actid;
         
        document.getElementById('reprtduration').value=reprtduration;
        document.getElementById('endTime').value=endTime;
        document.getElementById('endDate').value=endDate;
        document.getElementById('startDate').value=startDate;
        document.getElementById('startTime').value=startTime;
        document.getElementById('selradio').value=selradio;
        document.getElementById('backrenderbutton').value="Y";
        NewSubmit(ref);
	//makeAjaxCall(url,"ResultContainer",'partprocessing','');
      
}

function displaydelayreport(ref)
    {
    if(document.getElementById('delayframeset:hidProcessID').value <= 0 )
    {
    alert(SELECT_SINGLE_PROCESS);
    return false;
    } 
    
    var selradio=(document.getElementById('delayframeset:radiooption').value);
    var startDate="";
    var endDate="";   
    var endTime="";
    var startTime="";

    if( selradio=="0" && (document.getElementById("delayframeset:opType").options[0].value=="H" ||document.getElementById("delayframeset:opType").options[0].value=="D" ||document.getElementById("delayframeset:opType").options[0].value=="W" ||document.getElementById("delayframeset:opType").options[0].value=="M" || document.getElementById("delayframeset:opType").options[0].value=="Q" ))
      {

        var date = new Date();
        var mins=date.getMinutes();
        var hrs=date.getHours();
        if(hrs<10)
                hrs=format(hrs);
       if (mins<10) 
               mins=format(mins);
        var reportDurationval = document.getElementById('delayframeset:hidReportduration').value;

        var startTime=" 00"+SYMBOL_3+"00"+SYMBOL_3+"00";
        if(reportDurationval == "Day")
                 endTime=" 23"+SYMBOL_3+"59"+ SYMBOL_3+"59";
        else
                 endTime=" "+hrs+SYMBOL_3+mins+SYMBOL_3+"00";

        endDate = date.getYear()+'-'+date.getMonth()+'-'+date.getDate();

        document.getElementById('delayframeset:hidenenddate').value = endDate;
        document.getElementById('delayframeset:hidenendtime').value= endTime;
        document.getElementById('delayframeset:hidenstarttime').value = startTime;
        //document.getElementById('delayframeset:hidReportType').value="H";


      }
    else
       {

         var fromYear = document.getElementById("delayframeset:cmbFromYear").value;
         var fromMonth = document.getElementById("delayframeset:cmbFromMonth").value;
         var fromDay = document.getElementById("delayframeset:cmbFromDay").value;
         var fromHours = document.getElementById("delayframeset:cmbFromhours").value;
         var fromMins = 0;

         var toYear =document.getElementById("delayframeset:cmbToYear").value;
         var toMonth =document.getElementById("delayframeset:cmbToMonth").value;
        var toDay = document.getElementById("delayframeset:cmbToDay").value;
        var toHours = document.getElementById("delayframeset:cmbTohours").value;
        
           fromYear = eval(fromYear);
           fromMonth = eval(fromMonth);
           fromDay = eval(fromDay);
           fromHours = eval(fromHours);
           toYear = eval(toYear);
           toMonth = eval(toMonth);
           toDay = eval(toDay);
           toHours = eval(toHours);
           
        var toMins = 0;
        var date = new Date();
        var cYear = date.getYear();
        var cMonth = (date.getMonth()+1);
        var cDay = date.getDate();
        var cHour = date.getHours();
        var cMins = date.getMinutes();
        if(!verifyReportDate(fromYear,fromMonth,fromDay,fromHours,toYear,toMonth,toDay,toHours))
            return false;
        var month = parseInt(fromMonth);
        if(month <10)
                month = format(month);

        var day = parseInt(fromDay);
        if(day <10)
                day = format(day);

        var hours=parseInt(fromHours);

        if(hours<10)
                hours=format(hours);



        var mins=parseInt(fromMins);
        //if(mins<10) 
                mins=format(mins);

         startTime=" "+hours+SYMBOL_3+mins+SYMBOL_3+"00";
         startDate = fromYear+SYMBOL_2+month+SYMBOL_2+day;

         month = parseInt(toMonth);
        if(month <10)
                month =format(month);

        day = parseInt(toDay);
        if(day <10)
                day = format(day);

        hours=parseInt(toHours);

        if(hours<10)
                hours=format(hours);


        mins=parseInt(toMins);

        if(mins<10) 
        mins=format(mins);

        endTime=" "+hours+SYMBOL_3+mins+SYMBOL_3+"00";
        endDate = toYear+SYMBOL_2+month+SYMBOL_2+day;

        document.getElementById('delayframeset:hidReportduration').value = document.getElementById('delayframeset:opDuration').value;
        document.getElementById('delayframeset:hidenenddate').value = endDate;
        document.getElementById('delayframeset:hidenstartdate').value = startDate;
        document.getElementById('delayframeset:hidenstarttime').value=startTime;
        document.getElementById('delayframeset:hidenendtime').value=endTime;


       }
    var procname=(document.getElementById('delayframeset:hidProcessName').value);
    var procdefid=(document.getElementById('delayframeset:hidProcessID').value);
    var reporttype=(document.getElementById('delayframeset:hidReportType').value);
    var reprtduration=(document.getElementById('delayframeset:hidReportduration').value);
    var startdate=(document.getElementById('delayframeset:hidenfromdate').value);
    var selradio=(document.getElementById('delayframeset:radiooption').value);
    var actlistcallflag="Y";
    var actlistdelayflag="Y";
    var actprocdefid=document.getElementById('delayframeset:hidProcessID').value;
    //changes By Shruti Mishra for bug Id 590
    if(reprtduration=="Week" && reporttype=="H")
    reporttype="D";
    else if(reprtduration=="Month" && reporttype=="H")
    reporttype="D";
    else if(reprtduration=="Quarter" && reporttype=="H")
    reporttype="D";
    else if(reprtduration=="Year" && reporttype=="H")
    reporttype="D";
    if(reprtduration=="Day" || reprtduration=="Today")
   reporttype="H";
    //Changes End
   
  
document.getElementById('procname').value=procname;
document.getElementById('procdefid').value=procdefid;

document.getElementById('reporttype').value=reporttype;
document.getElementById('reprtduration').value=reprtduration;
document.getElementById('endTime').value=endTime;
document.getElementById('endDate').value=endDate;
document.getElementById('startDate').value=startDate;
document.getElementById('startTime').value=startTime;
document.getElementById('selradio').value=selradio;
document.getElementById('actprocdefid').value=actprocdefid;
document.getElementById('actlistcallflag').value=actlistcallflag;
document.getElementById('actlistdelayflag').value=actlistdelayflag;
document.getElementById('ActivityBatchSize').value="N";


    NewSubmit(ref);

    //makeAjaxCall(url,"ResultContainer",'delay','');
	
    }

function displayreportturnaround(ref)
{
 if(document.getElementById('tatframeset:hidProcessID').value <= 0 )
 {
    alert(SELECT_SINGLE_PROCESS);
    return false;
 } 

if((!document.forms[0]['tatframeset:durationType'].checked)&&(!document.forms[0]['tatframeset:between'].checked)){
                                alert(SELECT_REPORT_DURATION);
                            return false;
                        }
var selradio=(document.getElementById('tatframeset:radiooption').value);			
var startDate="";
var endDate="";   
var endTime="";
var startTime="";
if( selradio=="0" && (document.getElementById("tatframeset:opType").options[0].value=="H" ||document.getElementById("tatframeset:opType").options[0].value=="D" ||document.getElementById("tatframeset:opType").options[0].value=="W" ||document.getElementById("tatframeset:opType").options[0].value=="M" || document.getElementById("tatframeset:opType").options[0].value=="Q" ))
      {

        var date = new Date();
        var mins=date.getMinutes();
        var hrs=date.getHours();
        if(hrs<10)
                hrs=format(hrs);
       if (mins<10) 
               mins=format(mins);
        var reportDurationval = document.getElementById('tatframeset:hidReportduration').value;

        var startTime=" 00"+SYMBOL_3+"00"+SYMBOL_3+"00";
        if(reportDurationval == "Day")
                 endTime=" 23"+SYMBOL_3+"59"+ SYMBOL_3+"59";
        else
                 endTime=" "+hrs+SYMBOL_3+mins+SYMBOL_3+"00";

        endDate = date.getYear()+'-'+date.getMonth()+'-'+date.getDate();

        document.getElementById('tatframeset:hidenenddate').value = endDate;
        document.getElementById('tatframeset:hidenendtime').value= endTime;
        document.getElementById('tatframeset:hidenstarttime').value = startTime;
        //document.getElementById('tatframeset:hidReportType').value="H";


      }
    else
       {

         var fromYear = document.getElementById("tatframeset:cmbFromYear").value;
         var fromMonth = document.getElementById("tatframeset:cmbFromMonth").value;
         var fromDay = document.getElementById("tatframeset:cmbFromDay").value;
         var fromHours = document.getElementById("tatframeset:cmbFromhours").value;
         var fromMins = 0;

         var toYear =document.getElementById("tatframeset:cmbToYear").value;
         var toMonth =document.getElementById("tatframeset:cmbToMonth").value;
        var toDay = document.getElementById("tatframeset:cmbToDay").value;
        var toHours = document.getElementById("tatframeset:cmbTohours").value;
        
           fromYear = eval(fromYear);
           fromMonth = eval(fromMonth);
           fromDay = eval(fromDay);
           fromHours = eval(fromHours);
           toYear = eval(toYear);
           toMonth = eval(toMonth);
           toDay = eval(toDay);
           toHours = eval(toHours);
           
        var toMins = 0;
        var date = new Date();
        var cYear = date.getYear();
        var cMonth = (date.getMonth()+1);
        var cDay = date.getDate();
        var cHour = date.getHours();
        var cMins = date.getMinutes();
        if(!verifyReportDate(fromYear,fromMonth,fromDay,fromHours,toYear,toMonth,toDay,toHours))
            return false;
        var month = parseInt(fromMonth);
        if(month <10)
                month = format(month);

        var day = parseInt(fromDay);
        if(day <10)
                day = format(day);

        var hours=parseInt(fromHours);

        if(hours<10)
                hours=format(hours);



        var mins=parseInt(fromMins);
        //if(mins<10) 
                mins=format(mins);

         startTime=" "+hours+SYMBOL_3+mins+SYMBOL_3+"00";
         startDate = fromYear+SYMBOL_2+month+SYMBOL_2+day;

         month = parseInt(toMonth);
        if(month <10)
                month =format(month);

        day = parseInt(toDay);
        if(day <10)
                day = format(day);

        hours=parseInt(toHours);

        if(hours<10)
                hours=format(hours);


        mins=parseInt(toMins);

        if(mins<10) 
        mins=format(mins);

        endTime=" "+hours+SYMBOL_3+mins+SYMBOL_3+"00";
        endDate = toYear+SYMBOL_2+month+SYMBOL_2+day;

        document.getElementById('tatframeset:hidReportduration').value = document.getElementById('tatframeset:opDuration').value;
        document.getElementById('tatframeset:hidenenddate').value = endDate;
        document.getElementById('tatframeset:hidenstartdate').value = startDate;
        document.getElementById('tatframeset:hidenstarttime').value=startTime;
        document.getElementById('tatframeset:hidenendtime').value=endTime;


       }
    var procname=(document.getElementById('tatframeset:hidProcessName').value);
    var procdefid=(document.getElementById('tatframeset:hidProcessID').value);
    var reporttype=(document.getElementById('tatframeset:hidReportType').value);
    var reprtduration=(document.getElementById('tatframeset:hidReportduration').value);
    var startdate=(document.getElementById('tatframeset:hidenfromdate').value);
    var selradio=(document.getElementById('tatframeset:radiooption').value);

    var TurnArndTime=(document.getElementById('tatframeset:hidProcturnaroundtime').value);
    var actprocdefid=document.getElementById('tatframeset:hidProcessID').value;
    //changes By Shruti Mishra for bug Id 590
    if(reprtduration=="Week" && reporttype=="H")
    reporttype="D";
    else if(reprtduration=="Month" && reporttype=="H")
    reporttype="D";
    else if(reprtduration=="Quarter" && reporttype=="H")
    reporttype="D";
    else if(reprtduration=="Year" && reporttype=="H")
    reporttype="D";
    if(reprtduration=="Day" || reprtduration=="Today")
   reporttype="H";
   //Changes End
    
document.getElementById('procname').value=procname;
document.getElementById('procdefid').value=procdefid;

document.getElementById('reporttype').value=reporttype;
document.getElementById('reprtduration').value=reprtduration;
document.getElementById('endTime').value=endTime;
document.getElementById('endDate').value=endDate;
document.getElementById('startDate').value=startDate;
document.getElementById('startTime').value=startTime;
document.getElementById('selradio').value=selradio;
document.getElementById('TurnArndTime').value=TurnArndTime;
var url="../reports/turnaroundtimedisplay.faces?procname="+encode_utf8(procname)+"&procdefid="+procdefid+"&reporttype="+reporttype+"&reprtduration="+encode_utf8(reprtduration)+"&endTime="+encode_utf8(endTime)+"&startDate="+encode_utf8(startDate)+"&endDate="+endDate+"&startTime="+encode_utf8(startTime)+"&selradio="+selradio+"&TurnArndTime="+TurnArndTime+"&PM_UID="+pm_uid;

NewSubmit(ref);	
//makeAjaxCall(url,"ResultContainer",'turnaround','');
	
}



function displayexpiryreport(ref)
{
if(document.getElementById('expirydetails:hidProcessID').value <= 0 )
{
alert(SELECT_SINGLE_PROCESS);
return false;
} 


var startDate="";
var endDate="";   
var endTime="";
var startTime="";
var selradio=(document.getElementById('expirydetails:radiooption').value);

if( selradio=="0" && (document.getElementById("expirydetails:opType").options[0].value=="H" ||document.getElementById("expirydetails:opType").options[0].value=="D" ||document.getElementById("expirydetails:opType").options[0].value=="W" ||document.getElementById("expirydetails:opType").options[0].value=="M" || document.getElementById("expirydetails:opType").options[0].value=="Q" ))
  {

    var date = new Date();
    var mins=date.getMinutes();
    var hrs=date.getHours();
    if(hrs<10)
            hrs=format(hrs);
   if (mins<10) 
           mins=format(mins);
    var reportDurationval = document.getElementById('expirydetails:hidReportduration').value;

    var startTime=" 00"+SYMBOL_3+"00"+SYMBOL_3+"00";
    if(reportDurationval == "Day")
             endTime=" 23"+SYMBOL_3+"59"+ SYMBOL_3+"59";
    else
             endTime=" "+hrs+SYMBOL_3+mins+SYMBOL_3+"00";

    endDate = date.getYear()+'-'+date.getMonth()+'-'+date.getDate();

    document.getElementById('expirydetails:hidenenddate').value = endDate;
    document.getElementById('expirydetails:hidenendtime').value= endTime;
    document.getElementById('expirydetails:hidenstarttime').value = startTime;
    //document.getElementById('expirydetails:hidReportType').value="H";


  }
else
   {

     var fromYear = document.getElementById("expirydetails:cmbFromYear").value;
     var fromMonth = document.getElementById("expirydetails:cmbFromMonth").value;
     var fromDay = document.getElementById("expirydetails:cmbFromDay").value;
     var fromHours = document.getElementById("expirydetails:cmbFromhours").value;
     var fromMins = 0;

     var toYear =document.getElementById("expirydetails:cmbToYear").value;
     var toMonth =document.getElementById("expirydetails:cmbToMonth").value;
    var toDay = document.getElementById("expirydetails:cmbToDay").value;
    var toHours = document.getElementById("expirydetails:cmbTohours").value;

           fromYear = eval(fromYear);
           fromMonth = eval(fromMonth);
           fromDay = eval(fromDay);
           fromHours = eval(fromHours);
           toYear = eval(toYear);
           toMonth = eval(toMonth);
           toDay = eval(toDay);
           toHours = eval(toHours);
           
    var toMins = 0;
    var date = new Date();
    var cYear = date.getYear();
    var cMonth = (date.getMonth()+1);
    var cDay = date.getDate();
    var cHour = date.getHours();
    var cMins = date.getMinutes();
    if(!verifyReportDate(fromYear,fromMonth,fromDay,fromHours,toYear,toMonth,toDay,toHours))
            return false;

    var month = parseInt(fromMonth);
    if(month <10)
            month = format(month);

    var day = parseInt(fromDay);
    if(day <10)
            day = format(day);

    var hours=parseInt(fromHours);

    if(hours<10)
            hours=format(hours);



    var mins=parseInt(fromMins);
    //if(mins<10) 
            mins=format(mins);

     startTime=" "+hours+SYMBOL_3+mins+SYMBOL_3+"00";
     startDate = fromYear+SYMBOL_2+month+SYMBOL_2+day;

     month = parseInt(toMonth);
    if(month <10)
            month =format(month);

    day = parseInt(toDay);
    if(day <10)
            day = format(day);

    hours=parseInt(toHours);

    if(hours<10)
            hours=format(hours);


    mins=parseInt(toMins);

    if(mins<10) 
    mins=format(mins);

    endTime=" "+hours+SYMBOL_3+mins+SYMBOL_3+"00";
    endDate = toYear+SYMBOL_2+month+SYMBOL_2+day;

    document.getElementById('expirydetails:hidReportduration').value = document.getElementById('expirydetails:opDuration').value;
    document.getElementById('expirydetails:hidenenddate').value = endDate;
    document.getElementById('expirydetails:hidenstartdate').value = startDate;
    document.getElementById('expirydetails:hidenstarttime').value=startTime;
    document.getElementById('expirydetails:hidenendtime').value=endTime;


   }


var procname=(document.getElementById('expirydetails:hidProcessName').value);
var procdefid=(document.getElementById('expirydetails:hidProcessID').value); 
var reporttype=(document.getElementById('expirydetails:hidReportType').value);
var reprtduration=(document.getElementById('expirydetails:hidReportduration').value);
var startdate=(document.getElementById('expirydetails:hidenfromdate').value);
var selradio=(document.getElementById('expirydetails:radiooption').value);
//changes By Shruti Mishra for bug Id 590
if(reprtduration=="Week" && reporttype=="H")
reporttype="D";
else if(reprtduration=="Month" && reporttype=="H")
reporttype="D";
else if(reprtduration=="Quarter" && reporttype=="H")
reporttype="D";
else if(reprtduration=="Year" && reporttype=="H")
reporttype="D";
if(reprtduration=="Day" || reprtduration=="Today")
   reporttype="H";
//Changes End


//var tempURL="../reports/processhistorydisplay.faces";
document.getElementById('procname').value=procname;
document.getElementById('procdefid').value=procdefid;

document.getElementById('reporttype').value=reporttype;
document.getElementById('reprtduration').value=reprtduration;
document.getElementById('endTime').value=endTime;
document.getElementById('endDate').value=endDate;
document.getElementById('startDate').value=startDate;
document.getElementById('startTime').value=startTime;
document.getElementById('selradio').value=selradio;
NewSubmit(ref);
//makeAjaxCall(url,"ResultContainer",'expiry','');

}      

function handleEnter(e,formId)
                {                      
                    var browser=navigator.appName;
                    if(browser=="Netscape")
                    {

                               if(e.which == 13)
                               {       

                                    try
                                    {
                                        document.getElementById(formId+':cmdGenerate').focus();
                                    }
                                    catch(e){
                                        try{
                                                document.getElementById(formId+':cmdClose').focus();
                                            }
                                            catch(e){}
                                    }

                               }
                      }

                      else
                         {      
                            e=window.event;
                            if(e.keyCode == 13)
                                {
                                    try
                                    {
                                        document.getElementById(formId+':cmdGenerate').focus();
                                    }
                                    catch(e){
                                        try{
                                                document.getElementById(formId+':cmdClose').focus();
                                            }
                                            catch(e){}
                                    }
                                }

                         }
                }

function displayuserperformancereport(ref)
            {
                if(document.getElementById("userperformframeset:ItemID").value<=0)
                {
                    alert(SELECT_USER);
                    return false;
                }
                var selradio=(document.getElementById('userperformframeset:radiooption').value);
                var startDate="";
                var endDate="";   
                var endTime="";
                var startTime="";
                if( selradio=="0" && (document.getElementById("userperformframeset:opType").options[0].value=="H" ||document.getElementById("userperformframeset:opType").options[0].value=="D" ||document.getElementById("userperformframeset:opType").options[0].value=="W" ||document.getElementById("userperformframeset:opType").options[0].value=="M" || document.getElementById("userperformframeset:opType").options[0].value=="Q" ))
                {

                    var date = new Date();
                    var mins=date.getMinutes();
                    var hrs=date.getHours();
                    if(hrs<10)
                    hrs=format(hrs);
                    if (mins<10) 
                    mins=format(mins);
                    var reportDurationval = document.getElementById('userperformframeset:hidReportduration').value;
                    var startTime=" 00"+SYMBOL_3+"00"+SYMBOL_3+"00";
                    if(reportDurationval == "Day")
                    endTime=" 23"+SYMBOL_3+"59"+ SYMBOL_3+"59";
                    else
                    endTime=" "+hrs+SYMBOL_3+mins+SYMBOL_3+"00";
                    endDate = date.getYear()+'-'+date.getMonth()+'-'+date.getDate();
                    document.getElementById('userperformframeset:hidenenddate').value = endDate;
                    document.getElementById('userperformframeset:hidenendtime').value= endTime;
                    document.getElementById('userperformframeset:hidenstarttime').value = startTime;
                }
                else
                {

                var fromYear = document.getElementById("userperformframeset:cmbFromYear").value;
                var fromMonth = document.getElementById("userperformframeset:cmbFromMonth").value;
                var fromDay = document.getElementById("userperformframeset:cmbFromDay").value;
                var fromHours = document.getElementById("userperformframeset:cmbFromhours").value;
                var fromMins = 0;

                var toYear =document.getElementById("userperformframeset:cmbToYear").value;
                var toMonth =document.getElementById("userperformframeset:cmbToMonth").value;
                var toDay = document.getElementById("userperformframeset:cmbToDay").value;
                var toHours = document.getElementById("userperformframeset:cmbTohours").value;
                fromYear = eval(fromYear);
                fromMonth = eval(fromMonth);
                fromDay = eval(fromDay);
                fromHours = eval(fromHours);
                toYear = eval(toYear);
                toMonth = eval(toMonth);
                toDay = eval(toDay);
                toHours = eval(toHours);
           
                var toMins = 0;
                var date = new Date();
                var cYear = date.getYear();
                var cMonth = (date.getMonth()+1);
                var cDay = date.getDate();
                var cHour = date.getHours();
                var cMins = date.getMinutes();
                if(!verifyReportDate(fromYear,fromMonth,fromDay,fromHours,toYear,toMonth,toDay,toHours))
                return false;
                var month = parseInt(fromMonth);
                if(month <10)
                month = format(month);

                var day = parseInt(fromDay);
                if(day <10)
                day = format(day);

                var hours=parseInt(fromHours);

                if(hours<10)
                hours=format(hours);
                var mins=parseInt(fromMins);
                //if(mins<10) 
                mins=format(mins);

                startTime=" "+hours+SYMBOL_3+mins+SYMBOL_3+"00";
                startDate = fromYear+SYMBOL_2+month+SYMBOL_2+day;

                month = parseInt(toMonth);
                if(month <10)
                month =format(month);

                day = parseInt(toDay);
                if(day <10)
                day = format(day);

                hours=parseInt(toHours);

                if(hours<10)
                hours=format(hours);
                mins=parseInt(toMins);
                if(mins<10) 
                mins=format(mins);
                endTime=" "+hours+SYMBOL_3+mins+SYMBOL_3+"00";
                endDate = toYear+SYMBOL_2+month+SYMBOL_2+day;

                document.getElementById('userperformframeset:hidReportduration').value = document.getElementById('userperformframeset:opDuration').value;
                document.getElementById('userperformframeset:hidenenddate').value = endDate;
                document.getElementById('userperformframeset:hidenstartdate').value = startDate;
                document.getElementById('userperformframeset:hidenstarttime').value=startTime;
                document.getElementById('userperformframeset:hidenendtime').value=endTime;


                }
                var username=(document.getElementById('userperformframeset:HidItemName').value);
                var usergroupid=(document.getElementById('userperformframeset:ItemID').value);
                var activityname=(document.getElementById('userperformframeset:hidWorkstepName').value);
                var procname=(document.getElementById('userperformframeset:hidProcessName').value);
                var procdefid=(document.getElementById('userperformframeset:hidProcessID').value);
                var actid=(document.getElementById('userperformframeset:hidWorkstepID').value);
                var reporttype=(document.getElementById('userperformframeset:hidReportType').value);
                var reprtduration=(document.getElementById('userperformframeset:hidReportduration').value);
                var startdate=(document.getElementById('userperformframeset:hidenfromdate').value);
                var selradio=(document.getElementById('userperformframeset:radiooption').value);
                //changes By Shruti Mishra for bug Id 590
                if(reprtduration=="Week" && reporttype=="H")
                reporttype="D";
                else if(reprtduration=="Month" && reporttype=="H")
                reporttype="D";
                else if(reprtduration=="Quarter" && reporttype=="H")
                reporttype="D";
                else if(reprtduration=="Year" && reporttype=="H")
                reporttype="D";
                if(reprtduration=="Day" || reprtduration=="Today")
                reporttype="H";
                //Changes End
                var url="../reports/userperformancedisplay.faces?activityname="+encode_utf8(activityname)+"&procname="+encode_utf8(procname)+"&procdefid="+procdefid+"&actid="+actid+"&reporttype="+reporttype+"&reprtduration="+encode_utf8(reprtduration)+"&endTime="+encode_utf8(endTime)+"&startDate="+encode_utf8(startDate)+"&endDate="+endDate+"&startTime="+encode_utf8(startTime)+"&selradio="+selradio+"&username="+username+"&usergroupid="+usergroupid+"&PM_UID="+pm_uid;
		
                document.getElementById('activityname').value=activityname;
                document.getElementById('procname').value=procname;
                document.getElementById('procdefid').value=procdefid;
                document.getElementById('actid').value=actid;
                document.getElementById('reporttype').value=reporttype;
                document.getElementById('reprtduration').value=reprtduration;
                document.getElementById('endTime').value=endTime;
                document.getElementById('endDate').value=endDate;
                document.getElementById('startDate').value=startDate;
                document.getElementById('startTime').value=startTime;
                document.getElementById('selradio').value=selradio;	
                document.getElementById('username').value=username;
                document.getElementById('usergroupid').value=usergroupid;
                NewSubmit(ref);
                //makeAjaxCall(url,"ResultContainer",'userperform','');
                
            }
			function EnableDisableWorkstepButtonprochistory()
                {

                        if(document.getElementById('procframeset:hidProcessId').value > 0 )
                        {
                            //changes added for bug
                            var actVal=document.getElementById('procframeset:hidWorkstepId').value;
                            if(actVal=="")
                            {
                                var Node = document.getElementById('controllayoutselprocess');
								
                                Node.style.visibility = 'visible';
								temphtml=Node.innerHTML;
                                
                            }
                           //Chnages end	
                           else if(actVal!="" && myBoolean==1)  
                           {
                                var Node = document.getElementById('controllayoutselprocess');
                                Node.style.visibility = 'visible';
                                Node.innerHTML=temphtml;
                           }
			 document.getElementById('procframeset:cmdPicklist_workstep').disabled=false;
                        }
                        else
                        {
							
                            document.getElementById('procframeset:cmdPicklist_workstep').disabled=true;
                            var Node = document.getElementById('controllayoutselprocess');
							Node.style.visibility = 'hidden';
							
                        }

                        document.getElementById('procframeset:hidWorkstepId').value=' ';
                        document.getElementById('procframeset:hidWorkstepName').value=document.getElementById('procframeset:hidInitialWorkstep').innerHTML;
                       ;
						document.getElementById('procframeset:txtworkstepName').value=document.getElementById('procframeset:hidInitialWorkstep').innerHTML;
                       ;
                }
                
                function ShowWorkstepListforreportprochistory(ref,hidProcessName,hidProcessId,txtworkstepName,hidWorkstepId,hidWorkstepName,mode)
                        {
                            myBoolean=1;
                            var formid=ref.form.id;
                            var procID= document.getElementById(formid+":"+hidProcessId).value;
                            var procName= document.getElementById(formid+":"+hidProcessName).value;
                            
                            ShowPickList(ref,'WFWorkstepList',txtworkstepName,hidWorkstepId,hidWorkstepName,'2','','1','enablelayout',procID,procName,mode);
                            
                       }
                    function enablelayout()
                        {
                          
                          var Nodeproc = document.getElementById('controllayoutselprocess');
                          var Nodeact = document.getElementById('controllayoutselactivity');
                          
                            //Changes begin for bug id 559
                           if(document.getElementById('procframeset:hidWorkstepId').value > 0 )
                                {
                                    
                                    Nodeproc.style.visibility = 'visible';
                                    Nodeproc.innerHTML=Nodeact.innerHTML;
									
                                }
                        else
                                {
                                
                                Nodeproc.style.visibility = 'visible';
                                Nodeproc.innerHTML=temphtml;
                                }
                                 document.getElementById('procframeset:enterinwkstep').checked=true;			  
                           document.getElementById('procframeset:expired').checked=true;
                           document.getElementById('procframeset:processed').checked=true;
                          //Changes End 
                        }
						function doEnableDisableWorkstepButtonuserperformframeset()
                {
                    EnableDisableWorkstepButton('userperformframeset');
                }
				function ProcessWorkStep(PDefId,PName, reprtduration,endTime,startDate,endDate,startTime,selradio)
            {
                   
                      var procname=PName;
                      var procdefid=PDefId;
                      if(selradio=='0')
                      durationType='selduration';
                      else
                      durationType='selbetween';
                      var url="../reports/avgproctimedisplay.faces?procname="+encode_utf8(procname)+"&procdefid="+procdefid+"&reprtduration="+encode_utf8(reprtduration)+"&endTime="+encode_utf8(endTime)+"&startDate="+encode_utf8(startDate)+"&endDate="+endDate+"&startTime="+encode_utf8(startTime)+"&selradio="+selradio+"&durationType="+durationType+"&PM_UID="+pm_uid;
                                makeAjaxCall(url,"ResultContainer",'avgproctime','');
                                
                                
           
            }
			function doEnableDisableWorkstepButtonpatavg()
                {
					
                    EnableDisableWorkstepButton('partcipentavgtime');
                }
   function WorkStepProperty(actId,actname,procname,procdefid,reprtduration,endTime,startDate,endDate,startTime,selradio)
            {
             
             var activityname=actname
             var actid=actId 
            var ScreenHeight=screen.height;
            var ScreenWidth=screen.width;
            var WindowHeight=window1H+100;
            var WindowWidth=window1W+100;
            var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
            var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
             //var url="../reports/participentprocessingdisplay.faces?procname="+encode_utf8(procname)+"&procdefid="+procdefid+"&activityname="+encode_utf8(activityname)+"&actid="+encode_utf8(actid)+"&reprtduration="+encode_utf8(reprtduration)+"&endTime="+encode_utf8(endTime)+"&startDate="+encode_utf8(startDate)+"&endDate="+endDate+"&startTime="+encode_utf8(startTime)+"&selradio="+selradio+"&backrenderbutton="+"N";
             var url="../reports/reportframe.faces";
            url= appendUrlSession(url);
             //makeAjaxCall(url,"ResultContainer",'procdisplaywin','');


             var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

            var listParam=new Array();
            listParam.push(new Array("procname",encode_ParamValue(procname)));
            listParam.push(new Array("procdefid",encode_ParamValue(procdefid)));
            listParam.push(new Array("activityname",encode_ParamValue(activityname)));
            listParam.push(new Array("actid",encode_ParamValue(actid)));
            listParam.push(new Array("reprtduration",encode_ParamValue(reprtduration)));
            listParam.push(new Array("endTime",encode_ParamValue(endTime)));
            listParam.push(new Array("startDate",encode_ParamValue(startDate)));
            listParam.push(new Array("endDate",encode_ParamValue(endDate)));
            listParam.push(new Array("startTime",encode_ParamValue(startTime)));
            listParam.push(new Array("selradio",encode_ParamValue(selradio)));
            listParam.push(new Array("backrenderbutton",encode_ParamValue("N")));
             listParam.push(new Array("PM_UID",encode_ParamValue(pm_uid)));
            listParam.push(new Array("includedPage",encode_ParamValue("../reports/participentprocessingdisplay.jsp")));

             var win = openNewWindow(url,"temp"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
            try
                {
                    addWindows(win);
                }
            catch(e)
                {}
 
        }  
			function doEnableDisableWorkstepButton()
                {
                    EnableDisableWorkstepButton('partprocreport');
                }
				function submit()
            {
               ClickAnotherLink('','cmdlink_Go');
            }
            function displayexceptiondetailreport(item)
            {

			
             var returnval=setexceptionval(item);
             if(document.getElementById("exceptiondetails:txtProcessName").value==SELECT_A_PROCESS)
             {
                  alert(SELECT_SINGLE_PROCESS);
                   return false;
             }
            if(document.getElementById('exceptiondetails:hidexceptionId').value <= 0 )
             {
                alert(NO_EXCEPTION_ASSOCIATED);
                return false;
             }
            var startDate="";
            var endDate="";   
            var endTime="";
            var startTime="";
            var selradio=(document.getElementById('exceptiondetails:radiooption').value);
            //if(document.getElementById("exceptiondetails:durationType").checked)
             if( selradio=="0" && (document.getElementById("exceptiondetails:opType").options[0].value=="H" ||document.getElementById("exceptiondetails:opType").options[0].value=="D" ||document.getElementById("exceptiondetails:opType").options[0].value=="W" ||document.getElementById("exceptiondetails:opType").options[0].value=="M" || document.getElementById("exceptiondetails:opType").options[0].value=="Q" ))
                  {


                                                    var date = new Date();
                    var mins=date.getMinutes();
                    var hrs=date.getHours();
                    if(hrs<10)
                            hrs=format(hrs);
                   if (mins<10) 
                           mins=format(mins);
                    var reportDurationval = document.getElementById('exceptiondetails:hidReportduration').value;

                    var startTime=" 00"+SYMBOL_3+"00"+SYMBOL_3+"00";
                    if(reportDurationval == "Day")
                             endTime=" 23"+SYMBOL_3+"59"+ SYMBOL_3+"59";
                    else
                             endTime=" "+hrs+SYMBOL_3+mins+SYMBOL_3+"00";

                    endDate = date.getYear()+'-'+date.getMonth()+'-'+date.getDate();

                    document.getElementById('exceptiondetails:hidenenddate').value = endDate;
                    document.getElementById('exceptiondetails:hidenendtime').value= endTime;
                    document.getElementById('exceptiondetails:hidenstarttime').value = startTime;
                    //document.getElementById('exceptiondetails:hidReportType').value="H";


                  }
                else
                   {


                     var fromYear = document.getElementById("exceptiondetails:cmbFromYear").value;
                     var fromMonth = document.getElementById("exceptiondetails:cmbFromMonth").value;
                     var fromDay = document.getElementById("exceptiondetails:cmbFromDay").value;
                     var fromHours = document.getElementById("exceptiondetails:cmbFromhours").value;
                     var fromMins = 0;

                     var toYear =document.getElementById("exceptiondetails:cmbToYear").value;
                     var toMonth =document.getElementById("exceptiondetails:cmbToMonth").value;
                    var toDay = document.getElementById("exceptiondetails:cmbToDay").value;
                    var toHours = document.getElementById("exceptiondetails:cmbTohours").value;
                    
                    fromYear = eval(fromYear);
                    fromMonth = eval(fromMonth);
                    fromDay = eval(fromDay);
                    fromHours = eval(fromHours);
                    toYear = eval(toYear);
                    toMonth = eval(toMonth);
                    toDay = eval(toDay);
                    toHours = eval(toHours);
           
                    var toMins = 0;
                    var date = new Date();
                    var cYear = date.getYear();
                    var cMonth = (date.getMonth()+1);
                    var cDay = date.getDate();
                    var cHour = date.getHours();
                    var cMins = date.getMinutes();
                     if(!verifyReportDate(fromYear,fromMonth,fromDay,fromHours,toYear,toMonth,toDay,toHours))
                        return false;

                    var month = parseInt(fromMonth);
                    if(month <10)
                            month = format(month);

                    var day = parseInt(fromDay);
                    if(day <10)
                            day = format(day);

                    var hours=parseInt(fromHours);

                    if(hours<10)
                            hours=format(hours);



                    var mins=parseInt(fromMins);
                    //if(mins<10) 
                            mins=format(mins);

                     startTime=" "+hours+SYMBOL_3+mins+SYMBOL_3+"00";
                     startDate = fromYear+SYMBOL_2+month+SYMBOL_2+day;

                     month = parseInt(toMonth);
                    if(month <10)
                            month =format(month);

                    day = parseInt(toDay);
                    if(day <10)
                            day = format(day);

                    hours=parseInt(toHours);

                    if(hours<10)
                            hours=format(hours);


                    mins=parseInt(toMins);

                    if(mins<10) 
                    mins=format(mins);

                    endTime=" "+hours+SYMBOL_3+mins+SYMBOL_3+"00";
                    endDate = toYear+SYMBOL_2+month+SYMBOL_2+day;

                    document.getElementById('exceptiondetails:hidReportduration').value = document.getElementById('exceptiondetails:opDuration').value;
                    document.getElementById('exceptiondetails:hidenenddate').value = endDate;
                    document.getElementById('exceptiondetails:hidenstartdate').value = startDate;
                    document.getElementById('exceptiondetails:hidenstarttime').value=startTime;
                    document.getElementById('exceptiondetails:hidenendtime').value=endTime;


                   }


                var procname=(document.getElementById('exceptiondetails:hidProcessName').value);
                var procdefid=(document.getElementById('exceptiondetails:hidProcessID').value);
                var reporttype=(document.getElementById('exceptiondetails:hidReportType').value);
                var reprtduration=(document.getElementById('exceptiondetails:hidReportduration').value);
                var startdate=(document.getElementById('exceptiondetails:hidenfromdate').value);
                var selradio=(document.getElementById('exceptiondetails:radiooption').value);
                var exceptionname=(document.getElementById('exceptiondetails:hidexceptionname').value);
                var exceptionId=(document.getElementById('exceptiondetails:hidexceptionId').value);
                //changes By Shruti Mishra for bug Id 590
                if(reprtduration=="Week" && reporttype=="H")
                reporttype="D";
                else if(reprtduration=="Month" && reporttype=="H")
                reporttype="D";
                else if(reprtduration=="Quarter" && reporttype=="H")
                reporttype="D";
                else if(reprtduration=="Year" && reporttype=="H")
                reporttype="D";
                if(reprtduration=="Day" || reprtduration=="Today")
                reporttype="H";
               //Changes End
                //var url="../reports/exceptiondetailsdisplay.faces?procname="+encode_utf8(procname)+"&procdefid="+procdefid+"&reporttype="+reporttype+"&reprtduration="+encode_utf8(reprtduration)+"&endTime="+encode_utf8(endTime)+"&startDate="+encode_utf8(startDate)+"&endDate="+encode_utf8(endDate)+"&startTime="+encode_utf8(startTime)+"&selradio="+selradio+"&exceptionname="+encode_utf8(exceptionname)+"&exceptionId="+encode_utf8(exceptionId);
                
                document.getElementById('procname').value=procname;
                document.getElementById('procdefid').value=procdefid;
                document.getElementById('reporttype').value=reporttype;
                document.getElementById('reprtduration').value=reprtduration;
                document.getElementById('endTime').value=endTime;
                document.getElementById('endDate').value=endDate;
                document.getElementById('startDate').value=startDate;
                document.getElementById('startTime').value=startTime;
                document.getElementById('selradio').value=selradio;	
                document.getElementById('exceptionname').value=exceptionname;
                document.getElementById('exceptionId').value=exceptionId;
                NewSubmit(item);
                //makeAjaxCall(url,"ResultContainer",'exception','');
                
            }

            function setexceptionval(item)
            {


                formID=item.form.id;

                try{
                var selindex=document.getElementById(formID+":cmbexceptiontype").selectedIndex;
                 
                document.getElementById("exceptiondetails:hidexceptionname").value =document.getElementById(formID+":cmbexceptiontype").options[selindex].text ;         
                document.getElementById("exceptiondetails:hidexceptionId").value= document.getElementById(formID+":cmbexceptiontype").options[selindex].value;               
                return true;    
                }
                catch(e)
                    {return false;}


            }
			function EnableDisableWorkstepButtonusercompare()
                {
                        //alert("inside on change");
                        var procname=(document.getElementById('usercompareframeset:hidProcessName').value);
                        document.getElementById('usercompareframeset:hidsetprocname').value=procname;	
								
                        if(document.getElementById('usercompareframeset:hidProcessID').value > 0 )
                        {
                            document.getElementById('usercompareframeset:cmdPicklist_workstep').disabled=false;

							
                            
                        }
                        else
                        {
                            document.getElementById('usercompareframeset:cmdPicklist_workstep').disabled=true;
                            
                        }

                        document.getElementById('usercompareframeset:hidWorkstepID').value=' ';
                        document.getElementById('usercompareframeset:hidWorkstepName').value=document.getElementById('usercompareframeset:hidInitialWorkstep').innerHTML;
                        document.getElementById('usercompareframeset:txtWorkstepName').value=document.getElementById('usercompareframeset:hidInitialWorkstep').innerHTML;
                }
                
                function ShowWorkstepListforreportusercomapre(ref,hidProcessName,hidProcessId,txtWorkstepName,hidWorkstepID,hidWorkstepName,mode)
                        {
                            
			   var formid=ref.form.id;
                            var procID= document.getElementById(formid+":"+hidProcessId).value;
                            var procName= document.getElementById(formid+":"+hidProcessName).value;
                            ShowPickList(ref,'WFWorkstepList',txtWorkstepName,hidWorkstepID,hidWorkstepName,'2','','1','setactivityname',procID,procName,mode);
								
                        }
                 //Changes by Shruti for Bug Id 615       
                function setactivityname()
                {
                        var activityname=(document.getElementById('usercompareframeset:hidWorkstepName').value);
                        document.getElementById('usercompareframeset:hidsetactname').value=activityname;
                }
                function setgroupname()
                {
                var groupname=(document.getElementById('usercompareframeset:hidGroupName').value);

                document.getElementById('usercompareframeset:hidsetgroupname').value=groupname;
                }
                //Changes End
                function setInitialValueuser()
		  {
                  
			var fromback=document.getElementById("usercompareframeset:callbackflag").value;
                        
                        if(fromback=="1")
                        {
                            setfieldvaluewithoutreporttype('usercompareframeset')
                            return;
                        }
                     try{
                     if(document.getElementById("usercompareframeset:userperformdtdisplay")!=null) 
                    document.getElementById("usercompareframeset:userperformdtdisplay:HeadchkBox").checked=false;
                    
                    //Changes Done by Shruti for Bug Id 615
                    var seletedradiooption;
                    initialval=document.getElementById('usercompareframeset:hidparamaction').value;
					
                    if(initialval!=1){
                    var setprocVal=document.getElementById('usercompareframeset:hidsetprocname').value;
                    var setactval=document.getElementById('usercompareframeset:hidsetactname').value;
                    var setgroupname=document.getElementById('usercompareframeset:hidsetgroupname').value;
                    seletedradiooption=document.getElementById('usercompareframeset:setradiooption').value;

                    if(setprocVal=='')
                    {
                    document.getElementById('usercompareframeset:txtProcessName').value=ALL_PROCESSES_1;
                    document.getElementById('usercompareframeset:hidProcessName').value=ALL_PROCESSES_1;
                    }
                    else
                    {
                    document.getElementById('usercompareframeset:txtProcessName').value=setprocVal; 
                    document.getElementById('usercompareframeset:hidProcessName').value=setprocVal;
                    }
                    if(setactval=='')
                            document.getElementById('usercompareframeset:txtWorkstepName').value=ALL_WORKSTEPS;
                    else
                    {
                            document.getElementById('usercompareframeset:txtWorkstepName').value=setactval;
                            document.getElementById('usercompareframeset:cmdPicklist_workstep').disabled=false;

                    }
                    if(setgroupname=='')
                            document.getElementById('usercompareframeset:txtGroupName').value=ALL_GROUPS_1;
                    else
                            document.getElementById('usercompareframeset:txtGroupName').value=setgroupname; 
                    if(seletedradiooption=="0")
                    {	
                     document.forms[0]['usercompareframeset:durationType'].checked=true;;
                    document.getElementById("usercompareframeset:cmbFromDay").disabled=true;
                    document.getElementById("usercompareframeset:cmbFromMonth").disabled=true;
                    document.getElementById("usercompareframeset:cmbFromYear").disabled=true;
                    document.getElementById("usercompareframeset:cmbFromhours").disabled=true;
                    document.getElementById("usercompareframeset:cmbToDay").disabled=true;
                    document.getElementById("usercompareframeset:cmbToMonth").disabled=true;
                    document.getElementById("usercompareframeset:cmbToYear").disabled=true;
                    document.getElementById("usercompareframeset:cmbTohours").disabled=true;
                    }
                else if(seletedradiooption=="1") 
                            {	
                                //bug no-615 begin
                            document.getElementById("usercompareframeset:durationType").checked=false;
                            document.getElementById("usercompareframeset:opDuration").disabled=true;
                            //end
                            document.getElementById("usercompareframeset:between").checked=true;
                            document.getElementById('usercompareframeset:cmbFromDay').disabled=false;
                            document.getElementById('usercompareframeset:cmbFromMonth').disabled=false;
                            document.getElementById('usercompareframeset:cmbFromYear').disabled=false;
                            document.getElementById('usercompareframeset:cmbFromhours').disabled=false;
                            document.getElementById('usercompareframeset:cmbToDay').disabled=false;
                            document.getElementById('usercompareframeset:cmbToMonth').disabled=false;
                            document.getElementById('usercompareframeset:cmbToYear').disabled=false;
                            document.getElementById('usercompareframeset:cmbTohours').disabled=false;
                            }
                           }
                           //Changes End
                     else{
                            document.forms[0]['usercompareframeset:durationType'].checked=true;
                            document.getElementById('usercompareframeset:setradiooption').value="0";
                            document.getElementById("usercompareframeset:cmbFromDay").disabled=true;
                            document.getElementById("usercompareframeset:cmbFromMonth").disabled=true;
                            document.getElementById("usercompareframeset:cmbFromYear").disabled=true;
                            document.getElementById("usercompareframeset:cmbFromhours").disabled=true;
                            document.getElementById("usercompareframeset:cmbToDay").disabled=true;
                            document.getElementById("usercompareframeset:cmbToMonth").disabled=true;
                            document.getElementById("usercompareframeset:cmbToYear").disabled=true;
                            document.getElementById("usercompareframeset:cmbTohours").disabled=true;

                     }

                    document.getElementById('usercompareframeset:hidReportduration').value="Week";
                    document.getElementById("usercompareframeset:radiooption").value="0";
                    
                    }
                    catch(e)
                    {}
         }       
                        
                
                           function SelectAllCheckBox(ref)
                                {
                                    var formid=ref.form.id;
                                    var tableid=formid+':userperformdtdisplay';
                                    try 
                                    {
                                        var noofrows = document.getElementById(tableid).rows.length;
                                        var flag=0;
                                        for (var i=0;i< noofrows-1 ;i++)
                                        {

                                            var id=tableid+':'+i+':chkBox';
                                            document.getElementById(id).checked=ref.checked;
                                        }

                                        return '';
                                    }
                                    catch(e)
                                    {
                                        //alert(e);
                                        return "";
                                    }
                                }
                           function displayreport(item,dt)
                             {
                                if(document.forms[0].elements["usercompareframeset:between"].checked)
                                //if(document.getElementById("usercompareframeset:between").checked)
                                    selradio="1";
                               else
                                     selradio="0";
							   
				//if(noOfSelectedRows<2)
                  //                    {
                    //                      
                      //                      return;
                                            
                        //              }
                                
                               var startDate="";
                                var endDate="";   
                                var endTime="";
                                var startTime="";
                                var browser=navigator.appName
                                
                            if((document.forms[0]['usercompareframeset:durationType'].checked)&&(selradio=="0"))
                                  {
                                    var date = new Date();
                                    var mins=date.getMinutes();
                                    var hrs=date.getHours();
                                    if(hrs<10)
                                            hrs=format(hrs);
                                   if (mins<10) 
                                           mins=format(mins);
                                    var reportDurationval = document.getElementById('usercompareframeset:hidReportduration').value;
                                    
                                    startTime=" 00"+SYMBOL_3+"00"+SYMBOL_3+"00";
                                    endTime=" "+date.getHours()+SYMBOL_3+mins+SYMBOL_3+ "00";
                                    //Changes done by Shruti for Bug Id-620
                                    if(browser=='Netscape')
                                            endDate = (date.getYear()+1900)+'-'+date.getMonth()+'-'+date.getDate();
                                    else if(browser=='Microsoft Internet Explorer')
                                            endDate = date.getYear()+'-'+date.getMonth()+'-'+date.getDate();
                                    //Changes end
                                var selindex=document.getElementById('usercompareframeset:opDuration').selectedIndex;    
                                var selval=document.getElementById('usercompareframeset:opDuration').options[selindex].value;
                                     document.getElementById('usercompareframeset:hidReportduration').value=selval;
                                    document.getElementById('usercompareframeset:hidenenddate').value = endDate;
                                    document.getElementById('usercompareframeset:hidenendtime').value= endTime;
                                    document.getElementById('usercompareframeset:hidenstarttime').value = startTime;
									
                                  }
                                else
                                   {
                                    
                                     var fromYear = document.getElementById("usercompareframeset:cmbFromYear").value;
                                     var fromMonth = document.getElementById("usercompareframeset:cmbFromMonth").value;
                                     var fromDay = document.getElementById("usercompareframeset:cmbFromDay").value;
                                     var fromHours = document.getElementById("usercompareframeset:cmbFromhours").value;
                                     var fromMins = 0;
                                     
                                     var toYear =document.getElementById("usercompareframeset:cmbToYear").value;
                                     var toMonth =document.getElementById("usercompareframeset:cmbToMonth").value;
                                    var toDay = document.getElementById("usercompareframeset:cmbToDay").value;
                                    var toHours = document.getElementById("usercompareframeset:cmbTohours").value;
                                    
                                    fromYear = eval(fromYear);
                                    fromMonth = eval(fromMonth);
                                    fromDay = eval(fromDay);
                                    fromHours = eval(fromHours);
                                    toYear = eval(toYear);
                                    toMonth = eval(toMonth);
                                    toDay = eval(toDay);
                                    toHours = eval(toHours);
           
                                    var toMins = 0;
                                    var date = new Date();
                                    var cYear = date.getYear();
                                    var cMonth = (date.getMonth()+1);
                                    var cDay = date.getDate();
                                    var cHour = date.getHours();
                                    var cMins = date.getMinutes();
                                    if(!verifyReportDate(fromYear,fromMonth,fromDay,fromHours,toYear,toMonth,toDay,toHours))
                                    return false;

                                    var month = parseInt(fromMonth);
                                    if(month <10)
                                            month = format(month);

                                    var day = parseInt(fromDay);
                                    if(day <10)
                                            day = format(day);

                                    var hours=parseInt(fromHours);

                                    if(hours<10)
                                            hours=format(hours);
                                   var mins=parseInt(fromMins);
                                    //if(mins<10) 
                                            mins=format(mins);

                                     startTime=" "+hours+SYMBOL_3+mins+SYMBOL_3+"00";
                                     startDate = fromYear+SYMBOL_2+month+SYMBOL_2+day;
                                     
                                     month = parseInt(toMonth);
                                    if(month <10)
                                            month =format(month);

                                    day = parseInt(toDay);
                                    if(day <10)
                                            day = format(day);

                                    hours=parseInt(toHours);

                                    if(hours<10)
                                            hours=format(hours);


                                    mins=parseInt(toMins);

                                    if(mins<10) 
                                    mins=format(mins);

                                    endTime=" "+hours+SYMBOL_3+mins+SYMBOL_3+"00";
                                    endDate = toYear+SYMBOL_2+month+SYMBOL_2+day;
                                     
                                    document.getElementById('usercompareframeset:hidReportduration').value = document.getElementById('usercompareframeset:opDuration').value;
                                    document.getElementById('usercompareframeset:hidenenddate').value = endDate;
                                    document.getElementById('usercompareframeset:hidenstartdate').value = startDate;
                                    document.getElementById('usercompareframeset:hidenstarttime').value=startTime;
                                    document.getElementById('usercompareframeset:hidenendtime').value=endTime;
                                     

                                   }

								var stridlistcheck=	document.getElementById('usercompareframeset:hidfinalidlist').value

								  if(stridlistcheck.length==0)  //if single user is from current batch
								 {
									preparefinallist(item,dt);

									var useridlist=(document.getElementById('usercompareframeset:hidusergroupidlist').value);

									var arr=useridlist.split(":");
									if(arr.length<2)
									 {
										document.getElementById('usercompareframeset:hidfinalidlist').value="";
										document.getElementById('usercompareframeset:hidfinalnamelist').value="";
										  alert(SELECT_USERS_FOR_COMPARISON);
										return false;
									 }
								 }else    //if single user is from past batch
								 {
										preparefinallist(item,dt);

										var useridlist=(document.getElementById('usercompareframeset:hidusergroupidlist').value);
										var arr=useridlist.split(":");
										if(arr.length<2)
										 {
											  alert(SELECT_USERS_FOR_COMPARISON);
											return false;
										 }

								 }
								// document.getElementById('usercompareframeset:hidfinalidlist').value="";
                                 // document.getElementById('usercompareframeset:hidfinalnamelist').value="";

                                var procname=(document.getElementById('usercompareframeset:txtProcessName').value);
                                var procdefid=(document.getElementById('usercompareframeset:hidProcessID').value);
                                var activityname=(document.getElementById('usercompareframeset:txtWorkstepName').value);
                                var actid=(document.getElementById('usercompareframeset:hidWorkstepID').value);
                              
                                var startdate=(document.getElementById('usercompareframeset:hidenfromdate').value);
                               
                               
                                var usergrpupname=(document.getElementById('usercompareframeset:hidusergroupnamelist').value);
                              
                               
                                 
                                var reprtduration=(document.getElementById('usercompareframeset:hidReportduration').value); 
                                //url="../reports/userperformancecomparedisplay.faces?procname="+encode_utf8(procname)+"&procdefid="+procdefid+"&activityname="+activityname+"&actid="+encode_utf8(actid)+"&reprtduration="+encode_utf8(reprtduration)+"&endTime="+encode_utf8(endTime)+"&startDate="+encode_utf8(startDate)+"&endDate="+encode_utf8(endDate)+"&startTime="+encode_utf8(startTime)+"&selradio="+selradio+"&useridlist="+encode_utf8(useridlist)+"&usergrpupname="+encode_utf8(usergrpupname)+"&option="+"Exact";
                                   
                                 document.getElementById('usercompareframeset:hidProcessName').value=procname;
                                document.getElementById('procname').value=procname;
                                document.getElementById('procdefid').value=procdefid;
                                document.getElementById('activityname').value=activityname;
                                document.getElementById('actid').value=actid;
                                document.getElementById('reprtduration').value=reprtduration;
                                document.getElementById('endTime').value=endTime;
                                document.getElementById('endDate').value=endDate;
                                document.getElementById('startDate').value=startDate;
                                document.getElementById('startTime').value=startTime;
                                document.getElementById('selradio').value=selradio;
                                document.getElementById('useridlist').value=useridlist;
                                document.getElementById('usergrpupname').value=usergrpupname;
                                document.getElementById('option').value="Exact";
                                //url = appendUrlSession(url);
                                NewSubmit(item);
                                //makeAjaxCall(url,"ResultContainer",'usercomarison','');
                                
                               
                             }
                             function ForUpdate(item,dt)
                                {	
                                        if(!item.checked)
                                        {
                                                document.getElementById(item.form.id+':'+dt+':HeadchkBox').checked=false;
                                        }
                                }

                               
  function preparefinallist(item,dt)
  {

    var idlist=document.getElementById("usercompareframeset:hidfinalidlist").value;
    var namelist=document.getElementById("usercompareframeset:hidfinalnamelist").value;

    //  formID=item.form.id;	
    // tableID=formID+":"+dt;
    tableID="usercompareframeset:userperformdtdisplay";

    var chkBoxID=tableID+":";
    var tempUserIdList = "";			
    var tempUserNameList = "";
    var selvel="";
    var rowCount=0;
    try
    {
        rowCount=document.getElementById(tableID).rows.length ;
    }
    catch(e){}

    for (var iCount=0;iCount < (rowCount-1) ;iCount++)
    {
        currentChkBoxID=chkBoxID + iCount +":chkBox" ;
        try 
        {
            if(document.getElementById(currentChkBoxID).checked)
            {
                var selselect=chkBoxID + iCount +":selusergroupid";
                var selselectname=chkBoxID + iCount +":selusername"
                selval=document.getElementById(selselect).value;
                nameval=document.getElementById(selselectname).value;

                if(tempUserIdList=="")
                {
                    tempUserIdList+=selval;
                    tempUserNameList+=nameval;
                }
                else
                {
                    tempUserIdList+=":"+selval;
                    tempUserNameList+=","+nameval;
                }  
            }
        }
        catch(e)
        {
        // alert("Error in=="+iCount);
        }
    }

    if(tempUserIdList=="")
     {
         tempUserIdList=idlist;
         tempUserNameList=namelist;
      }
    else if (idlist != "")
     {
        //Changes on 20 may 
        tempUserIdList=idlist+ ":" +tempUserIdList;
        tempUserNameList=namelist+","+tempUserNameList;
        //Changes End 
        //tempUserIdList=tempUserIdList+ ":" +idlist;
        //tempUserNameList=tempUserNameList+","+namelist;
      }

      document.getElementById('usercompareframeset:hidusergroupidlist').value=tempUserIdList;
      document.getElementById('usercompareframeset:hidusergroupnamelist').value=tempUserNameList;
      document.getElementById('usercompareframeset:hidfinalidlist').value=tempUserIdList;
      document.getElementById('usercompareframeset:hidfinalnamelist').value=tempUserNameList;
  }
function setfieldvalue(formId)
{
    //alert(formId)
   
   if(formId=='procframeset')
   {
    var Nodeproc = document.getElementById('controllayoutselprocess');
    var Nodeact = document.getElementById('controllayoutselactivity');
    if(document.getElementById('procframeset:hidWorkstepId').value > 0 )
    {
    Nodeproc.style.visibility = 'visible';
    Nodeproc.innerHTML=Nodeact.innerHTML;
    }
    else
    {
    Nodeproc.style.visibility = 'visible';
    Nodeproc.innerHTML=Nodeproc.innerHTML;
    }
  }
    //alert("22222");
    var selectval=document.getElementById(formId+":duration").value;
    //alert(selectval)
    if(selectval=='selduration')
    {
    
    changereporttypefromback(formId)
    document.getElementById(formId+":opType").disabled=false;
    document.getElementById(formId+":cmbFromDay").disabled=true;
    document.getElementById(formId+":cmbFromMonth").disabled=true;
    document.getElementById(formId+":cmbFromYear").disabled=true;
    document.getElementById(formId+":cmbFromhours").disabled=true;
    document.getElementById(formId+":cmbToDay").disabled=true;
    document.getElementById(formId+":cmbToMonth").disabled=true;
    document.getElementById(formId+":cmbToYear").disabled=true;
    document.getElementById(formId+":cmbTohours").disabled=true;
    document.getElementById(formId+":radiooption").value="0";
    var selectedIndex=document.getElementById(formId+":opType").selectedIndex;
    
    
}
else 
 {
      
        document.getElementById(formId+":opType").disabled=true;
       
        document.getElementById(formId+":opDuration").disabled=true;
        
        document.getElementById(formId+":radiooption").value="1";
        if(formId=='exceptiondetails')
        {
            var opReportType = document.getElementById(formId+":opType");
            var temp=opReportType.selectedIndex;
            opReportType.remove(0);
            opReportType.options[0] = new Option(REPORT_DAY,"D");
            opReportType.options[0].selected=true;
                                //Changes added for seeting report duration default value 'Last Week' when between is //selected
            var opReportDuration = document.getElementById(formId+":opDuration");
            var temp=opReportDuration.selectedIndex;
             opReportDuration.remove(0);
            opReportDuration.options[0] = new Option(REPORT_LAST_WEEK,"Week");
            opReportDuration.options[0].selected=true;

        }
 }
                        
 
}

function setfieldvaluewithoutreporttype(formId)
{
   
    var selectval=document.getElementById(formId+":duration").value;
    
if(selectval=='selduration')
{
    document.getElementById(formId+":cmbFromDay").disabled=true;
    document.getElementById(formId+":cmbFromMonth").disabled=true;
    document.getElementById(formId+":cmbFromYear").disabled=true;
    document.getElementById(formId+":cmbFromhours").disabled=true;
    document.getElementById(formId+":cmbToDay").disabled=true;
    document.getElementById(formId+":cmbToMonth").disabled=true;
    document.getElementById(formId+":cmbToYear").disabled=true;
    document.getElementById(formId+":cmbTohours").disabled=true;
    document.getElementById(formId+":radiooption").value="0";
}
else 
 {
     
        document.getElementById(formId+":opDuration").disabled=true;
        document.getElementById(formId+":hidReportduration").value="Week";
        document.getElementById(formId+":radiooption").value="1";
 }
                        
 
}
function changereporttypefromback(FormId)
{
var index = document.getElementById(FormId+":opDuration").selectedIndex;
var reporttypeIndex=document.getElementById(FormId+":opType").selectedIndex;
//alert("index=="+index)

var reportval=document.getElementById(FormId+":opType").options[reporttypeIndex].value;
var opReportType = document.getElementById(FormId+":opType");
//alert("opReportType=="+reportval)
var opLength = opReportType.length;
for(iCount=(opLength-1);iCount >= 0 ; iCount--)			
{
        opReportType.remove(iCount);
}
if(index == 0 || index == 1)
{
        opReportType.options[0] = new Option(REPORT_HOUR,"H");
}
if(index == 2)
{
        opReportType.options[0] = new Option(REPORT_DAY,"D");
}
if(index == 3)
{
        opReportType.options[0] = new Option(REPORT_DAY,"D");
        opReportType.options[1] = new Option(REPORT_WEEK,"W");
        if(reportval=='D')
        opReportType.options[0].selected=true;
        else if(reportval=='W')
        opReportType.options[1].selected=true;
}
if(index == 4)
{
        opReportType.options[0] = new Option(REPORT_DAY,"D");
        opReportType.options[1] = new Option(REPORT_WEEK,"W");
        opReportType.options[2] = new Option(REPORT_MONTH,"M");
        if(reportval=='D')
        opReportType.options[0].selected=true;
        else if(reportval=='W')
        opReportType.options[1].selected=true;
        else if(reportval=='M')
        opReportType.options[2].selected=true;
}
if(index == 5)
{
        opReportType.options[0] = new Option(REPORT_DAY,"D");
        opReportType.options[1] = new Option(REPORT_WEEK,"W");
        opReportType.options[2] = new Option(REPORT_MONTH,"M");
        opReportType.options[3] = new Option(QUARTER,"Q");
        if(reportval=='D')
        opReportType.options[0].selected=true;
        else if(reportval=='W')
        opReportType.options[1].selected=true;
        else if(reportval=='M')
        opReportType.options[2].selected=true;
        else if(reportval=='Q')
        opReportType.options[3].selected=true;
}

                    
}
   function backtofilter()
{
    try{
        
       document.getElementById("excepdisplay:chagecallbackflag").value="1"; 
       }
       catch(e){}
       try{
       
       document.getElementById("userperformdisplay:chagecallbackflag").value="1"; 
       document.getElementById("userperformdisplay:hid_mode").value="5";
        
       
    }
    catch(ex){}
     ClickAnotherLink(document,'cmdlink_back'); 
} 

function fetchPrevNextList(action)
{
    var url = "../reports/reportmain.faces?LinkId=-1&Action="+action+"&PM_UID="+pm_uid;
    makeAjaxCall(url,"Reports","reports",'');
    return false;
}

function setButtonImage(ref,pnbutton,mouseaction)
{
    if(pnbutton == '1')
    {        
        if(mouseaction == 'H')
          {
            ref.src = "../omniflow/images/next_hover.gif";
          }
        else if(mouseaction == 'O') 
            ref.src = "../omniflow/images/next.gif";
    }
    else if (pnbutton == '2')
    {
        if(mouseaction == 'H')
            ref.src = "../omniflow/images/prev_hover.gif";
        else if(mouseaction == 'O')     
            ref.src = "../omniflow/images/prev.gif";
    }
}
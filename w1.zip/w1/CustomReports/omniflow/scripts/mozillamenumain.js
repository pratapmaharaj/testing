/*
		Product         :       OmniFlow
		Application     :       OmniFlow Web Desktop
		Module          :       Workdesk
		File            :       mozillamenu.js
		Purpose         :       Contains the functions used for menu on the workdesk
		Change History  :

		Problem No        Correction Date	Comments
		-----------       ----------------      ----------
                3092              28/Dec/2007          The options in the were not getting shown properly
                4035              31/03/2008           there was no option for hiding custom link at run time.
                WCL_7.1_229       20/04/2010           Need to provide the option for displaying  more than one custom link on main page of webdesktop.
                WCL_7.1_236       21/05/2010           Custom Link submenu Names does not accept Spaces. A javascript error occurrs at page saying Invalid Arguement.
                WCL_9.0_023       07/01/2011           Need to provide the option for displaying more than one custom link on main page of webdesktop
		WCL_9.0_046       04/02/2011           Support for opening  custom link in one click (not as a submenu)
                Bug 39008         22/04/2013           Requirement of Multiple custom link in Process manager
                Bug 54570         17/03/2015           Required to configure custom lin/SUb Custom link according to user/Group in processmanager
*/
 
/*
Tabs Menu (mouseover)- By Dynamic Drive
For full source code and more DHTML scripts, visit http://www.dynamicdrive.com
This credit MUST stay intact for use
*/

var submenu=new Array()

//Set submenu contents. Expand as needed. For each content, make sure everything exists on ONE LINE. Otherwise, there will be JS errors.
 
//Set delay before submenu disappears after mouse moves out of it (in milliseconds)
var delay_hide=500

/////No need to edit beyond here



function showit(which){
    
clear_delayhide()

thecontent=(which==-1)? "" : submenu[which]

thecontent="<table><tr>"+thecontent+"</tr></table>"

if(which=='nothing')
    thecontent="";
if (document.getElementById||document.all)
menuobj.innerHTML=thecontent
else if (document.layers){
menuobj.document.write(thecontent)

menuobj.document.close()
}

}

function resetit(e){
if (document.all&&!menuobj.contains(e.toElement))
delayhide=setTimeout("showit(-1)",delay_hide)
else if (document.getElementById&&e.currentTarget!= e.relatedTarget&& !contains_ns6(e.currentTarget, e.relatedTarget))
delayhide=setTimeout("showit(-1)",delay_hide)
}

function clear_delayhide(){
if (window.delayhide)
clearTimeout(delayhide)
}

function contains_ns6(a, b) {
while (b.parentNode)
if ((b = b.parentNode) == a)
return true;
return false;
}
 
 function convertIT(divID){
 var mainMenuString="";
 var custom; 
 //alert(document.getElementById('myMenuID'))
  
  mainMenuString+="<table><tr>"
 for(var i=0;i<myMenu.length;i++){  
	if(myMenu[i].length==5){
            if(showMainMenu(myMenu[i][3],decode_utf8(myMenu[i][3]),userName)){ 
		mainMenuString+="<td><a class=PMLTGreen1  style='position : relative;top :2px;WHITE-SPACE :nowrap;' onMouseover=showit('nothing') id='"+myMenu[i][3]+"'  onClick=\""+myMenu[i][2]+"\">"+decode_utf8(myMenu[i][1])+"</a></td>" ;
            }
	}
	else{
	     if(showMainMenu(myMenu[i][3],decode_utf8(myMenu[i][3]),userName)){
		mainMenuString+="<td><a  class=PMLTGreen1 style='position : relative;top :1px;' id='"+myMenu[i][3]+"'  onMouseover="+"showit("+i+")"+">"+decode_utf8(myMenu[i][1])+" </a></td>"; 
              }
                var subString=''
		for(var j=5;j<myMenu[i].length;j++){
                    if(showMainSubMenu(myMenu[i][3],myMenu[i][j][3],decode_utf8(myMenu[i][j][1]),userName)){
			subString+="<td nowrap><a style='position : relative;top :20px;FONT: 8pt verdana;CURSOR: pointer ; padding:2px ;' id='"+myMenu[i][j][3]+"' onClick=\""+myMenu[i][j][2]+"\">"+decode_utf8(myMenu[i][j][1])+" |</a></td>" 
                    }
		} 
		submenu[i]=subString+"";

		} 
 }

    var menudiv=document.getElementById(divID);
    mainMenuString+="</tr></table>"

    menudiv.innerHTML=mainMenuString;

 }



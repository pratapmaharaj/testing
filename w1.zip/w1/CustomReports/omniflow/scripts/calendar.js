/*-----------------------------------------------------------------------------------------------------

File Name			: calendar.js
Author                          : Puneet Pahuja
Date written (DD/MM/YYYY)       : 19/May/2007
Description			: This file contains the methods for handling the calendar display page.
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date(DD/MM/YYYY)		Change By               Change Description (Bug No. (If Any))
----------------------------------------------------------------------------------------------------
 * 23/08/2011      Anushree Jain	Bug 27971 Security issue
 * 29/07/2015	   Dinkar Kad		Bug 55876 - Showing error while checkin and check out out route in Process Modeler, after upgrading from Omniflow 8 to newer versions like OF 9 and OF 10
----------------------------------------------------------------------------------------------------*/

	   
    function selectradio(iselected)
    {
        if(iselected==1)
        {
                document.forms["calendar"]["calendar:radio1"].checked=true;
                document.forms["calendar"]["calendar:radio2"].checked=false;
                document.forms["calendar"]["calendar:radio3"].checked=false;
                document.getElementById("calendar:hidworkingmode").value='1';
                copyDefHourRange();
        }

       else if(iselected==2)
        {
                document.forms["calendar"]["calendar:radio2"].checked=true;
                document.forms["calendar"]["calendar:radio1"].checked=false;
                document.forms["calendar"]["calendar:radio3"].checked=false;
                document.getElementById("calendar:hidworkingmode").value='2';
        }
        else if(iselected==3)
        {
                document.forms["calendar"]["calendar:radio3"].checked=true;
                document.forms["calendar"]["calendar:radio1"].checked=false;
                document.forms["calendar"]["calendar:radio2"].checked=false;
                document.getElementById("calendar:hidworkingmode").value='3';
        }
        else
        {
                document.forms["calendar"]["calendar:radio3"].checked=false;
                document.forms["calendar"]["calendar:radio1"].checked=false;
                document.forms["calendar"]["calendar:radio2"].checked=false;
                document.getElementById("calendar:hidworkingmode").value='-1';

        }

    }

    function setradonload()
    {
        //setstyleArray();
        if(strSuccess=='success')
            {
            alert(CHANGES_DONE_SUCCESSFULLY);
            self.close();
            }
        else
        {
                    try
                    {
                    if(document.getElementById("calendar:hidworkingmode").value=='1')
                    {
                        selectradio(1);
                    }

                   else if(document.getElementById("calendar:hidworkingmode").value=='2')
                    {
                            selectradio(2);
                    }

                     else if(document.getElementById("calendar:hidworkingmode").value=='3')
                    {
                            selectradio(3);
                    }
                    else if(document.getElementById("calendar:hidworkingmode").value=='-1')
                        {
                            selectradio(0);
                            if(!defaultcal)
                                {
                                document.forms["calendar"]["calendar:radio3"].disabled=false;
                                document.forms["calendar"]["calendar:radio1"].disabled=false;
                                document.forms["calendar"]["calendar:radio2"].disabled=false;
                                }
                        }
                    else
                    {
                            selectradio(0);
                            document.forms["calendar"]["calendar:radio3"].disabled=true;
                            document.forms["calendar"]["calendar:radio1"].disabled=true;
                            document.forms["calendar"]["calendar:radio2"].disabled=true;

                    }
                    if(document.getElementById("calendar:hidSelected_week").value!='0')
                        {
                            document.forms["calendar"]["calendar:radio2"].disabled=true;
                        }

                    }
                    catch(e){}
               if(strSuccess=='newCreated')
               {
                alert(NEW_CALENDAR_CREATED_SUCCESSFULLY);
               }
        }

    }

    function selectedDate(idate)
    {
            document.getElementById("calendar:hidselected_date").value=idate;
            document.getElementById("calendar:hidSelected_week").value='0';
            if(validatehourrange())
            {
                clickLink('calendar:updateChangesInBean');
            }

    }

    function selectedWeek(iweek)
    {
            document.getElementById("calendar:hidselected_date").value='0';
            document.getElementById("calendar:hidSelected_week").value=iweek;
            if(validatehourrange())
            {
                clickLink('calendar:updateChangesInBean');
            }
    }


    function validatehourrange()
    {
      var tableID="calendar:hourdef";
      for(icount=0;icount<5;icount++)
      {
      var StartTimeBoxID=tableID+":"+icount+":starttime";
      var EndTimeBoxID=tableID+":"+icount+":endtime";
      var StartTimeBoxValue=Trim(document.getElementById(StartTimeBoxID).value);
      var EndTimeBoxValue=Trim(document.getElementById(EndTimeBoxID).value);
      var PrevEndTimeValue;
        var StartTimeFirstBoxID = tableID+":"+0+":starttime";
        var EndTimeFirstBoxID=tableID+":"+0+":endtime";
        var StartTimeFirstBoxValue=Trim(document.getElementById(StartTimeFirstBoxID).value);
        var EndTimeFirstBoxValue=Trim(document.getElementById(EndTimeFirstBoxID).value);
        if(EndTimeFirstBoxValue=="" && StartTimeFirstBoxValue=="" && document.getElementById("calendar:hidworkingmode").value == '1')
              {
                alert(SPECIFY_FROM_TIME_AND_TO_TIME);
                document.getElementById(StartTimeFirstBoxID).focus();
                document.getElementById(StartTimeFirstBoxID).select();
                return false;
             }
      if(StartTimeBoxValue!="")
        {   
            if(!AlphanumericCheck(StartTimeBoxValue))
                    {
                        alert(NOT_CORRECT_TIME);
                        document.getElementById(StartTimeBoxID).focus();
                        document.getElementById(StartTimeBoxID).select();
                        return false;						
                     }
                    if(!reformattime(StartTimeBoxID,StartTimeBoxValue))
                        {
                            alert(NOT_CORRECT_TIME);
                            return false;
                        }

                        var firstpart=StartTimeBoxValue.substr(0,2);
                        var secondpart=StartTimeBoxValue.substr(2,2);

                    if((firstpart-0)>24)
                        {
                            alert(NOT_CORRECT_TIME);
                            document.getElementById(StartTimeBoxID).focus();
                            document.getElementById(StartTimeBoxID).select();
                            return false;
                        }
                    if((secondpart-0)>59)
                        {
                            alert(NOT_CORRECT_TIME);
                            document.getElementById(StartTimeBoxID).focus();
                            document.getElementById(StartTimeBoxID).select();
                            return false;
                        }
                        if((firstpart-0)==24)
                        {
                            if((secondpart-0)>0)
                            {
                                alert(NOT_CORRECT_TIME);
                                document.getElementById(StartTimeBoxID).focus();
                                document.getElementById(StartTimeBoxID).select();
                                return false;
                            }
                        }

                    if(EndTimeBoxValue=="")
                    {
                            alert(SPECIFY_TO_TIME);
                            document.getElementById(EndTimeBoxID).focus();
                            document.getElementById(EndTimeBoxID).select();
                            return false;
                    }
        }

        if(EndTimeBoxValue!="")
            {
                    if(!AlphanumericCheck(EndTimeBoxValue))
                    {
                        alert(NOT_CORRECT_TIME);
                        document.getElementById(EndTimeBoxID).focus();
                        document.getElementById(EndTimeBoxID).select();
                        return false;						
                     }

                    if(!reformattime(EndTimeBoxID,EndTimeBoxValue))
                        {
                        alert(NOT_CORRECT_TIME);
                        return false;
                        }

                        var firstpart=EndTimeBoxValue.substr(0,2);
                        var secondpart=EndTimeBoxValue.substr(2,2);

                    if((firstpart-0)>24)
                        {
                            alert(NOT_CORRECT_TIME);
                            document.getElementById(EndTimeBoxID).focus();
                            document.getElementById(EndTimeBoxID).select();
                            return false;
                        }
                    if((secondpart-0)>59)
                        {
                            alert(NOT_CORRECT_TIME);
                            document.getElementById(EndTimeBoxID).focus();
                            document.getElementById(EndTimeBoxID).select();
                            return false;
                        }

                        if((firstpart-0)==24)
                        {
                            if((secondpart-0)>0)
                            {
                                alert(NOT_CORRECT_TIME);
                                document.getElementById(EndTimeBoxID).focus();
                                document.getElementById(EndTimeBoxID).select();
                                return false;
                            }
                        }

                    if(StartTimeBoxValue=="")
                        {
                            alert(SPECIFY_FROM_TIME);
                            document.getElementById(StartTimeBoxID).focus();
                            document.getElementById(StartTimeBoxID).select();
                            return false;
                        }
            }

                    var StartTimeBoxValuemod=Trim(document.getElementById(StartTimeBoxID).value);
                    var EndTimeBoxValuemod=Trim(document.getElementById(EndTimeBoxID).value);
			
						
                    if((EndTimeBoxValuemod-0)<=(StartTimeBoxValuemod-0) &&(StartTimeBoxValuemod.length !=0)&&(EndTimeBoxValuemod.length !=0) )
                        {
							
                            alert(TO_TIME_GREATER_THAN_FROM_TIME);
                            document.getElementById(EndTimeBoxID).focus();
                            document.getElementById(EndTimeBoxID).select();
                            return false;
                        }
      }
      return true;

    }

    function AlphanumericCheck(textToCheck)
    {
        for(var j=0;j < textToCheck.length; j++)
         {
            var alphaa = textToCheck.charAt(j);
             var code = alphaa.charCodeAt(0);
             if(code > 47 && code < 58) 
                {
                }
             else
                {
                     return false;
                 }
          }
        return true;
     }


     function reformattime(timeid,timevalue)
        {
            var timelength=timevalue.length;
            if(timelength!=4)
            {
                if(timelength>4)
                {
                    document.getElementById(timeid).focus();
                    document.getElementById(timeid).select();
                    return false;
                }
                else if((timelength)<4)
                    {
                        if((timelength)==1)
                        {
                            timevalue='0'+timevalue+'00';
                        }
                        if((timelength)==2)
                        {
                            timevalue=timevalue+'00';
                        }
                        if((timelength)==3)
                        {
                            timevalue=timevalue+'0';
                        }

                     document.getElementById(timeid).value=timevalue;
                     return true;
                    }
             }
             else
             {
                return true;
             }

        }


        function next()
        {
            if(validatehourrange())
            {
                clickLink('calendar:nextmonth');
            }
        }


        function previous()
        {
            if(validatehourrange())
            {
                clickLink('calendar:previousmonth');
            }
        }

        function getSelectedCal()
        {
            var index=document.getElementById("selectitems:cmbcalendar").selectedIndex;
            var calid=document.getElementById("selectitems:cmbcalendar").options[index].value;
            document.getElementById("calendar:hidSelectedCalValue").value=calid;
            document.getElementById("calendar:hidselectedoption").value=calid;
            clickLink('calendar:hidselectedcal');
        }
        
        function clearHourDef()
        {
            var tableID="calendar:hourdef";
            for(icount=0;icount<5;icount++)
            {
                var StartTimeBoxID=tableID+":"+icount+":starttime";
                var EndTimeBoxID=tableID+":"+icount+":endtime";
                document.getElementById(StartTimeBoxID).value = "";
                document.getElementById(EndTimeBoxID).value = "";
            }
        }
         
        function copyDefHourRange()
        {
              var tableID="calendar:hourdef";
              var defhourtableID="calendar:defhourdef";
              for(icount=0;icount<5;icount++)
              {
                  var StartTimeBoxID=tableID+":"+icount+":starttime";
                  var EndTimeBoxID=tableID+":"+icount+":endtime";
                  var defStartTimeBoxID=defhourtableID+":"+icount+":defstarttime";
                  var defEndTimeBoxID=defhourtableID+":"+icount+":defendtime";
                  document.getElementById(StartTimeBoxID).value = document.getElementById(defStartTimeBoxID).value;
                  document.getElementById(EndTimeBoxID).value = document.getElementById(defEndTimeBoxID).value;
              }
        }

  
        function newCalendarOkClick()
        {
            if(ValidateCalendarName() && validateCalenderComments())
            {
                try{
                 window.parent.document.getElementById("calendar:hidcalName").value=document.getElementById("newcalendar:calendarName").value;
                }catch(ex){} 
                
                try{
                 window.parent.document.getElementById("calendar:hidNewCalType").value=document.getElementById("newcalendar:hidNewCalType").value;
                  }catch(ex){}
                  
                try{
                 window.parent.document.getElementById("calendar:cmbcalendar").value=document.getElementById("newcalendar:ListExtCal").value;
                  }catch(ex){} 
                  
                 try{
                 window.parent.document.getElementById("calendar:hidActionComments").value=document.getElementById("newcalendar:calendarComments").value;
                  }catch(ex){}
                
                try{
                 window.parent.clickLink("calendar:cmdlink_RefreshCal");
                  }catch(ex){} 

                 removeIFrame(CurrentPickListId);
             }
             return false;
        }
        
        function validateCalenderComments()
        {
           var comments = Trim(document.getElementById("newcalendar:calendarComments").value);
            if(comments=="")
            {
                alert(COMMENTS_MADATORY);
                document.getElementById("newcalendar:calendarComments").focus();
                return false;
             }
             return true;
        }
            
    function ValidateCalendarName()
    {
        var name = Trim(document.getElementById("newcalendar:calendarName").value);
        if(name=="")
        {
            alert(CALENDAR_NAME_CANNOT_BE_BLANK);
            document.getElementById("newcalendar:calendarName").focus();
            return false;
         }
         else
         {
            var list=window.parent.document.getElementById("calendar:cmbcalendar");
            if(list!=undefined)
            {
                var i;
                for(i=0; i< list.options.length; ++i)
                {
                    if(name==list.options[i].text)
                    break;
                }
                if(i < list.options.length)
                {
                    alert(CALENDAR_WITH_SAME_NAME_ALREADY_EXISTS);
                    document.getElementById("newcalendar:calendarName").select();
                    return false;
                }
            }
         }
        return true;
    }
    function calenderTypeRadioOnClick(option)
    {
       if(option=='1')
       {
        document.forms[0].elements["newcalendar:radioCopyCal"].checked=false;
        document.getElementById("newcalendar:ListExtCal").disabled=true;
        document.getElementById("newcalendar:hidNewCalType").value="newBaseCal";
       }
       else
       {
        document.forms[0].elements["newcalendar:radioNewBaseCal"].checked=false;
        document.getElementById("newcalendar:ListExtCal").disabled=false;
        document.getElementById("newcalendar:hidNewCalType").value="copyCal";
       }
       
    }
    function NewCalOnLoadInit()
    {
        var list =document.getElementById("newcalendar:ListExtCal");
        if(list.options.length>0)
        {
            list.options[0].selected=true;
        }
        document.forms[0].elements["newcalendar:radioNewBaseCal"].checked=true;
        calenderTypeRadioOnClick('1');
    }
    
    function openNewCalendar()
    {
        var Url = "../calendar/newcalendar.faces?PM_UID="+pm_uid;
        Url = appendUrlSession(Url);
        createPopUpIFrame('newcalendar',Url,'250',400);
    }
    
    function SaveCalChanges()
    {
        try
        {
            clickLink('calendar:btnSaveCalChanges');
        }catch(e){}
        return false;
    }
/**********************************************************************************************************************************
		
		File            :       wfgeneral.js
		Purpose         :       General Functions

		Change History  :
		Problem No        Correction Date				Comments
                BUG ID 564        16/04/2007   (Arup Sharma)                  function ShowQueueProp()
                BUG ID 628        18/04/2007   (Arup Sharma)                  QueueID added in picklist of worksteps
                BUG ID 549        20/04/2007   (Arup Sharma)                  FindPos function added
                BUG 550           21/04/2007   (Arup Sharma)                 (appendUrlSession() added , session id appended in all the window.open url's by calling method :appendUrlSession())
                BUG ID 634        21/04/2007   (Arup Sharma)                    ShowWorkDistproc()
                BUG ID 650        26/04/2007   (Arup Sharma) 
                Bug Id  7089      02/12/2008   (Vijay Kumar)
                PRM_8.0_006       19 May 2009      Vijay Kumar/Puneet Satija
                PRM_8.0_009       24 June2009  (Vijay Kumar)                    (Security Issue)
                BUG ID PRM_8.0_01406 Aug 2008  Arup Sharma                      (For BAM Reports integration)
                PRM_8.0_030       04/12/09      Indraneel                       Support for Export Purge Utility.
                PRM_8.0_036       19/01/2010    Indraneel                    Option for adding rule definition on Queue Aliases to display in different color/images in worklist
                PRM_8.0_035       15/01/2010    Bhupesh Kumar                   Unable Adhoc route any workitem at Exit or Discard workstep because these workstep are not coming in the list.
                PRM_8.0_037       27/01/2010    Puneet Pahuja                   window.open changed to openNewWindow to open new window using HTTP POST
                Bug 12805         13/05/2010    Puneet Pahuja                   context menu handled
                Bug 12819         14/05/2010      Himshikha                 problem in generatePostrequeest method in mozilla.
                PRM_9.0_004       18/02/2011      Sri Prakash               User link coming disabled in Process Manager's Statistics section 
			    PRM_9.0_006       11/05/2011       Sri prakash             (Non supervisor user is not able to generate report because list of process is not displayed)
                Bug 27971          23/08/2011      Anushree Jain	 Security issue
                Bug 28348         14/09/2011     Anushree Jain	      Provide external queue variable mapping
                01/11/2012    Jaseem Ansari                PRM_8.0_056|(Need to change the color code of processmanager)
				15/07/2013      Dinkar Kad	 Bug 41354 - 'Set diversion' function and 'Audit log configuration function' in process Manager can be accessed by an user who is not a member of any group.
				14/08/2013            Dinkar         Bug 41790 - Screen for specifying names of processes,queues,activities,variables, aliases in multiple locales for multilingual functionality.
				01/10/2013         Dinkar         		Bug 41790 - Screen for specifying names of processes,queues,activities,variables, aliases in multiple locales for multilingual functionality.
                13/11/2013      Sandeep Tonger          Bug 42561 - IE10 support for process manager.
                13/06/1992      Dinesh Verma            Bug 46653 - Support of IE11 in ProcessManager
                01/07/2014      Jaseem Ansari           Bug 46906   - All the request in omniflow containing wd_uid as a parameter should be sent as a post request
                15/10/2014      Jaseem Ansari           Bug 50790 - Wrong iframes are getting opened in process variable mapping
				31/12/2014      Sri Prakash             Bug 52427 -  Window truncation issue is observed 
				02/02/2015      Dinesh Verma            Bug 53085 - Bottom border is not showing in Group picklist while showing proper in User Picklist
				26/02/2015		Ashutosh Pandey			Bug 53764 - Optimization at CS, ofservices and utility end to reduce the user level configuration and usage of single system utility user to perform each user level operation
                01/04/2015      Dinesh Verma      Bug 54809 -Copying,Pasting,Cut of data in the login and password fields should not be allowed
                17/04/2015      Ashutosh Pandey     Bug 54922 If no record is showing on selection of Variable & Activity entity type in Multilingual Definition
                21/07/2015      Ashutosh Pandey     Bug 55957 - Removing the system constants from constant.js and adding in wfgeneral.js
				23/09/2015                          Bug 56875 - New QueueType "T" is Introduced . No worksteps can be added to this type of queue.
				30/11/2015      Saquibul Islam      Bug 58037 - Changes required in processmanager for handling specific changes made corresponding to 		actionId 75 in Omniflow 10
				23/02/2016							Bug 59304 - An Indicator is required to identify the referred workitems in search result
               08/06/2016       Bug 62109  
                07/09/2016      Ashutosh Pandey     Bug 64243 - Not able to click on filter textbox of picklist in processmanager in IE
****************************************************************************************************************************************/

var windowH = 360;
var windowW = 480;
var windowX = (window.screen.availHeight - windowH)/2;
var windowY = (window.screen.availWidth - windowW)/2;

var window1H = 480;
var window1W = 640;
var window1X = (window.screen.availHeight - window1H)/2-30;
var window1Y = (window.screen.availWidth - window1W)/2;

var window2H = 260;
var window2W = 250;
var window2X = (window.screen.availHeight - window2H)/2;
var window2Y = (window.screen.availWidth - window2W)/2;

var window3H = 490;
var window3W = 640;
var window3X = (window.screen.availHeight - window3H)/2-30;
var window3Y = (window.screen.availWidth - window3W)/2;

var window4H = 160;
var window4W = 210;
var window4X = (window.screen.availHeight - window4H)/2;
var window4Y = (window.screen.availWidth - window4W)/2;

var window5H = 500;
var window5W = 760;
var window5X = (window.screen.availHeight - window5H)/2 - 10;
var window5Y = (window.screen.availWidth - window5W)/2 - 5;

var window6H = 530;
var window6W = 640;
var window6X = (window.screen.availHeight - window6H)/2-30;
var window6Y = (window.screen.availWidth - window6W)/2;

var window7H = 384;
var window7W = 512;
var window7X = (window.screen.availHeight - window7H)/2-30;
var window7Y = (window.screen.availWidth - window7W)/2;

var hexArr = new Array('0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F');

var ScreenHeight=screen.height;
var ScreenWidth=screen.width;

var SEPERATOR1='\u00b5';
var SEPERATOR2='#';
var SEPERATOR3=';';
var SEPERATOR4='\u00b5';
var SEPERATOR5='=';
var SEPARATOR6='\u00df';
var SEPARATOR7='$';
var SEPERATOR8='\u00b6';
var SEPERATOR9='\u00fc';
var DATESEPARATOR="/";
var ABSBOTTOM="absbottom"; 
var SYMBOL_1='--';
var SYMBOL_2="-";
var SYMBOL_HYPHEN="-";
var SYMBOL_3=":";
var DATESEP="/"; 
var VAR_INT1="VAR_INT1";
var VAR_INT2="VAR_INT2";
var VAR_INT3="VAR_INT3";
var VAR_INT4="VAR_INT4";
var VAR_INT5="VAR_INT5";
var VAR_INT6="VAR_INT6";
var VAR_INT7="VAR_INT7";
var VAR_INT8="VAR_INT8";
var VAR_FLOAT1="VAR_FLOAT1";
var VAR_FLOAT2="VAR_FLOAT2";
var VAR_DATE1="VAR_DATE1";
var VAR_DATE2="VAR_DATE2";
var VAR_DATE3="VAR_DATE3";
var VAR_DATE4="VAR_DATE4";
var VAR_LONG1="VAR_LONG1";
var VAR_LONG2="VAR_LONG2";
var VAR_LONG3="VAR_LONG3";
var VAR_LONG4="VAR_LONG4";
var VAR_STR1="VAR_STR1";
var VAR_STR2="VAR_STR2";
var VAR_STR3="VAR_STR3";
var VAR_STR4="VAR_STR4";
var VAR_STR5="VAR_STR5";
var VAR_STR6="VAR_STR6";
var VAR_STR7="VAR_STR7";
var VAR_STR8="VAR_STR8";
var ProcessInstanceState="ProcessInstanceState";

var NG_VAR_INT = 3;
var NG_VAR_LONG = 4;
var NG_VAR_FLOAT = 6;
var NG_VAR_DATE = 8;
var NG_VAR_STRING = 10;

var OP_LESSTHAN = 1;
var OP_LESSTHANEQUALTO = 2;
var OP_EQUALTO = 3;
var OP_NOTEQUALTO = 4;
var OP_GREATERTHAN = 5;
var OP_GREATERTHANEQUALTO = 6 ;
var OP_LIKE = 7;
var OP_NOTLIKE = 8;
var OP_NULL = 9;
var OP_NOTNULL = 10;
var PROCESSLIST="ProcessList";
var PROCESSINFO="ProcessInfo";
var ID="ID";
var STATE="State";
//xml tags of the search module
//general tab

var QueueName ="QueueName";
var QueueId ="QueueId";
var ProcessName ="ProcessName";
var ProcessDefinitionID ="ProcessDefinitionID";
var ActivityId ="ActivityId";
var ActivityName ="ActivityName";
var SearchPreviousVersion ="SearchPreviousVersion";
var SortOnVersion ="SortOnVersion";
var ProcessInstanceName ="ProcessInstanceName";
var Priority ="Priority";
var LockStatus ="LockStatus";
var ExceptionStatus ="ExceptionStatus";
var LockedByUserId ="LockedByUserId";
var LockedByUser ="LockedByUser";
var AssignedToUserId ="AssignedToUserId";
var AssignedToUser ="AssignedToUser";
var IntroducedByUserId ="IntroducedByUserId";
var IntroducedByUser ="IntroducedByUser";
var ReferBy ="ReferBy";
var ReferByName ="ReferByName";

//date tab
var State ="State";
var StateDateRange = "StateDateRange";

//data tab
var QueryList ="QueryList";
var EntrySetting ="EntrySetting";
var AdvanceSearch ="AdvanceSearch";
var QueryInfo ="QueryInfo";
var VarName ="VarName";
var VarType="VarType";
var Length="Length";
var VarValue="VarValue";
var Operator="Operator";
var JoinCondition="JoinCondition";

var SORT_ON_IMAGE="1";
var SORT_ON_PINAME="2";
var SORT_ON_QUEUENAME="14";
var SORT_ON_PROCNAME="15";
var SORT_ON_WORKSTEP="3";
var SORT_ON_STATE="9";
var SORT_ON_CHECKLIST="7";
var SORT_ON_ASSIGNEDTO="16";
var SORT_ON_INTRODUCEDON="13";
var SORT_ON_INTRODUCEDBY="5";
var SORT_ON_VALIDTILL="11";
var SORT_ON_PENDINGSINCE="10";

var SystemAssignedToUser="SystemAssignedToUser";
var FixedAssignedToUser="FixedAssignedToUser";

var ProcessedDateRange="ProcessedDateRange";
var AssignedToUser="AssignedToUser";
var StateTag="State";
var DelayFlag="DelayFlag";
var TAG_WorkListConfigFields = 'WorkListConfigFields';
var TAG_Variable = 'Variable';
var TAG_VariableId = 'VariableId';
var TAG_VariableType = 'VariableType';
var TAG_VariableName = 'VariableName';
var TAG_DisplayName = 'DisplayName';
var TAG_MobileDisplay = 'MobileDisplay';
var TAG_QueueName="QueueName";
var TAG_Description="Description";
var TAG_QueueType="QueueType";
var TAG_FilterOption="FilterOption";
var TAG_QueueFilter="QueueFilter";
var RAG_FilterValue="FilterValue";
var TAG_OrderBy="OrderBy";
var TAG_OrderByName="OrderByName";
var TAG_AllowReassignment="AllowReassignment";
var TAG_QueueID="QueueID";
var TAG_QPROCESSNAME="QProcessName";
var TAG_RefreshInterval="RefreshInterval";
var TAG_SortOrder="SortOrder";

var pickListButtonObj;
/**************************************** Restricted Events Starts********************************************/
//document.oncontextmenu = checkContextMenu; //Disable Right Click
function checkContextMenu(e)
{
    var element='';
    if (typeof window.event != 'undefined')
    {
        element= event.srcElement;
    }
    else
    {
        element=e.target;
    }
    return isInvaildKeyForElement(element);
}
if (typeof window.event != 'undefined'){ // IE
    document.onkeydown = function(e) // IE
    {
        var t=event.srcElement.type;
        var kc=event.keyCode;
        if (kc == 116) {
            window.event.keyCode = 0;
            return false;
        }
        else
            return ((kc != 8 ) || isInvaildKeyForElement(event.srcElement))
    }
}
else{
    document.onkeypress = function(e)  // FireFox/Others
    {
        var t=e.target.type;
        var kc=e.keyCode;
        if(kc == 116 && navigator.userAgent.toLowerCase().indexOf("firefox") > -1) {
            e.cancelBubble = true;
            return false;
        }
        else if ((kc != 8) || isInvaildKeyForElement(e.target))
            return true;
        else
            return false;
    }
}
function isInvaildKeyForElement(element)
{
    var type=element.type;
    if( type == 'submit')
    {
        return true;
    }
    else if(( type == 'text' ) || (type == 'textarea') || (type == 'password'))
    {
        if(element.readOnly)
            return false;
        else
            return true;
    }else
    {
        return false;
    }
}
/************************************ Restricted Events Ends************************************************/



function addWindows(newWin)
{
	var flag=false;
	var len = allWindows.length;
	for(x=0; x<len;x++)
	{
			if ((allWindows[x] == null) || (allWindows[x].closed == true))
			{
				allWindows[x] = newWin;
				flag = true;
				break;
			}
	}
	if (flag == false)
		allWindows[len] = newWin;
}

function closeWindows()
{
	var len = allWindows.length;
	for(x=0; x<len;x++)
	{
		if ((allWindows[x] != null) && (allWindows[x].closed == false))
			allWindows[x].close();
	}
}

function addLaunchWindows(newWin)   //Bug Id  7089 to close LauchWindows only in case of main unload
{
	var flag=false;
	var len = launchWindows.length;
	for(x=0; x<len;x++)
	{
			if ((launchWindows[x] == null) || (launchWindows[x].closed == true))
			{
				launchWindows[x] = newWin;
				flag = true;
				break;
			}
	}
	if (flag == false)
		launchWindows[len] = newWin;
}

function closeLaunchWindows() //Bug Id  7089 to close LauchWindows only in case of main unload
{
	var len = launchWindows.length;
	for(x=0; x<len;x++)
	{
		if ((launchWindows[x] != null) && (launchWindows[x].closed == false))
			launchWindows[x].close();
	}
}

function Trim(val)
{
	var len = val.length;

	if(len != 0)
	{
		while(1)
		{
			if(val.charAt(0) != " ")
			{
				break;
			}
			else
			{
				val = val.substr(1);
			}
		}
	}

	len = val.length;
	if(len != 0)
	{
		while(1)
		{
			if(val.charAt(len - 1) != " ")
			{
				return val;
			}
			else
			{
				len -= 1;
				val = val.substr(0,len);
			}
		}
	}

	return val;
}

function replace(str, oldStr, newStr)
{
	var iPos = 0;
	var iOldStrLen = oldStr.length;
	while ((iPos = str.indexOf(oldStr)) != -1)
      {
    		var i = iPos;
		var temp = str.substring(0, iPos) + newStr +str.substring(iPos + iOldStrLen);
		str = temp;
	}
	return str;
}

function encode_utf8(ch)
{
	var i,bytes;
	var utf8 = new String();
	var temp;
        if(ch==undefined)
            return ' ';

	for(i=0, bytes = 0; i<ch.length; i++)
	{
		temp = ch.charCodeAt(i);
		if(temp < 0x80)
		{
			utf8 += String.fromCharCode(temp);
		}
		else if (temp < 0x0800)
		{
			utf8 += String.fromCharCode((temp>> 6 | 0xC0));
			utf8 += String.fromCharCode((temp & 0x3F | 0x80));			
		}
		else
		{
			utf8 += String.fromCharCode((temp>> 12 | 0xE0));
			utf8 += String.fromCharCode((temp>> 6 & 0x3F | 0x80));
			utf8 += String.fromCharCode((temp & 0x3F | 0x80));
		}
	}

	if (navigator.appName.indexOf("Netscape") == -1)
	{
		return escape(utf8);
	}
	var esc = new String();
	for(l=0;l<utf8.length;l++)
	{
		if(utf8.charCodeAt(l)<128)
			esc += escape(utf8[l]);
		else
		{	
			esc += "%";
			esc += hexArr[utf8.charCodeAt(l)>>4];
			esc += hexArr[utf8.charCodeAt(l) & 0xf];
		}
	}
	return esc;
}


function decode_utf8(utftextBytes)
{
	var utftext = unescape(utftextBytes);
	var plaintext = "",temp; 
	
	var i=c1=c2=c3=c4=0;
	 
	while(i<utftext.length)
	{
		c1 = utftext.charCodeAt(i);
		temp = '?';

		if (c1<0x80)
		{
			temp = String.fromCharCode(c1);
			i++;
		}
		else if( (c1>>5) ==	6) //2 bytes
		{
			c2 = utftext.charCodeAt(i+1);
			
			if( !((c2^0x80)&0xC0))
				temp = String.fromCharCode(((c1&0x1F)<<6) | (c2&0x3F));
			i+=2;
		}
		else if( (c1>>4) == 0xE)  //3 bytes
		{
			c2 = utftext.charCodeAt(i+1); c3 = utftext.charCodeAt(i+2);

			if( !(((c2^0x80)|(c3^0x80))&0xC0) )
				temp = String.fromCharCode(((c1&0xF)<<12) | ((c2&0x3F)<<6) | (c3&0x3F));				
			i+=3;
		}
		else
			i++;
		plaintext += temp;
	}
	return plaintext;
}
//BUG ID 628 (queueID added in worksteplist request)
function ShowPickList(reference,type,nameCtrl,iDCtrl,hidNameCtrl,NoneType,NoneID,ReturnNoneText,FunctionName,Extra1,Extra2,Extra3,Extra4,Extra5,Extra6,Extra7,parentFlag,CustomRightsFlag)
{
	pickListButtonObj = reference;
        var url;
	var ScreenHeight=screen.height;
	var ScreenWidth=screen.width;
	var WindowHeight=300;
	var WindowWidth=300;
	var iframeHeight=240;
	var formid=reference.form.id;
        var pickListID="PickList";
        var callBack="";
        if(Trim(FunctionName).length>0)
        {
            callBack="&CallBack=" + Trim(FunctionName);
        }
	if(type=='WFQueueList')
	{
                var queueType = "";
                if(Extra1 != undefined)
                    queueType = Extra1;
 
                var queueAssociation="2";

                if((Extra2 != undefined) && (Extra2 != ""))
                    queueAssociation = Extra2; 
                if(Extra4==undefined)
                {
                    Extra4="";
                }
		url="../application/queuepicklist.faces?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&ReturnNoneValue=" +ReturnNoneText + "&NoneType=" + NoneType + "&NoneValue=" +NoneID +"&QueueType=" +queueType + "&QueueAssociation="+queueAssociation+"&strFormFieldTypeHidden="+Extra3+"&hidQProcessName="+Extra4+"&PM_UID="+pm_uid;
                var pickListID="QueuePickList";
                iframeHeight=250;
	}

        else if(type=='WFPurgeProcessList')
	{
                var queueName="";
                var queueId="0";
                var stateflag="B"; 
                var tat="";
                var usecal="";
                if(Extra1 != undefined)
                    queueName = Extra1;

                if(Extra2 != undefined)
                    queueId = Extra2;
                
                if(Extra3!= undefined)
                    stateflag=Extra3

                if(Extra4!= undefined)
                    tat=Extra4
                if(Extra5!=undefined) 
                    usecal=Extra5;
		url="../processmgmt/purgeprocesspicklist.faces?Action=1&strFormID=" + formid + "&pidList="+Extra1+"&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&ReturnNoneValue=" +ReturnNoneText + "&NoneType=" + NoneType + "&NoneValue=" +NoneID +"&QueueName="+queueName+"&QueueId="+queueId+"&stateflag="+stateflag+"&tat="+tat+"&usecal="+usecal+"&PM_UID="+pm_uid;
               
                var pickListID="WFPurgeProcessList";                
                iframeHeight=250;
	}
           else if(type=='WFExportProcessList')
	{
               // alert("WFExportProcessList");
                 var queueName="";
                var queueId="0";
                var stateflag="B";
                var tat="";
                var usecal="";
                if(Extra1 != undefined)
                    queueName = Extra1;

                if(Extra2 != undefined)
                    queueId = Extra2;

                if(Extra3!= undefined)
                    stateflag=Extra3

                if(Extra4!= undefined)
                    tat=Extra4
                if(Extra5!=undefined)
                    usecal=Extra5;

		url="../processmgmt/exportprocesspicklist.faces?Action=1&strFormID=" + formid + "&pidList=11111&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&ReturnNoneValue=" +ReturnNoneText + "&NoneType=" + NoneType + "&NoneValue=" +NoneID +"&QueueName="+queueName+"&QueueId="+queueId+"&stateflag="+stateflag+"&tat="+tat+"&usecal="+usecal+"&PM_UID="+pm_uid;

                var pickListID="WFExportProcessList";
                iframeHeight=250;
	}
	else if(type=='WFProcessList')
	{
                var queueName="";
                var queueId="0";
                var stateflag="B"; 
                var tat="";
                var usecal="";
                var latestversionFlag="";
                var processprefix="";
                var CustomRights = "N";
                if(Extra1 != undefined)
                    queueName = Extra1;
                if(Extra2 != undefined)
                    queueId = Extra2;
                if(Extra3!= undefined)
                    stateflag=Extra3
                if(Extra4!= undefined)
                    tat=Extra4
                if(Extra5!=undefined) 
                    usecal=Extra5;

                if(Extra6!=undefined) 
                    latestversionFlag=Extra6;  
                if(Extra7!=undefined && Extra7!=''){
                    var Extra7=document.getElementById('QueueProperties_Stream:hidQProcessName').value;
                    processprefix=Extra7;
                    }
                if(CustomRightsFlag!=undefined) 
                   CustomRights=CustomRightsFlag;

		//  url="../application/processpicklist.faces?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&ReturnNoneValue=" +ReturnNoneText + "&NoneType=" + NoneType + "&NoneValue=" +NoneID +"&QueueName="+queueName+"&QueueId="+queueId+"&stateflag="+stateflag+"&tat="+tat+"&usecal="+usecal;
                  url="../application/processpicklist.faces?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&ReturnNoneValue=" +ReturnNoneText + "&NoneType=" + NoneType + "&NoneValue=" +NoneID +"&QueueName="+queueName+"&QueueId="+queueId+"&stateflag="+stateflag+"&tat="+tat+"&usecal="+usecal+"&latestversionFlag="+latestversionFlag+"&processprefix="+processprefix+"&CustomRights="+CustomRights+"&PM_UID="+pm_uid;
                var pickListID="ProcessPickList";
                try
                {
                    removeIFrame("WorkstepPickList"); //so that workstep list if open closed
                }
                catch(e){}  
                iframeHeight=250;
	}
	else if(type=='WFUserList')
	{
		url="../application/userpicklist.faces?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&ReturnNoneValue=" +ReturnNoneText + "&NoneType=" + NoneType + "&NoneValue=" +NoneID+"&PM_UID="+pm_uid;
                var pickListID="UserPickList";
                //WindowHeight=370;
                iframeHeight=275;
	}
	else if(type=='WFGroupList')
	{
		url="../application/grouppicklist.faces?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&ReturnNoneValue=" +ReturnNoneText + "&NoneType=" + NoneType + "&NoneValue=" +NoneID+"&PM_UID="+pm_uid;
                var pickListID="GroupPickList";
                iframeHeight=275;
	}
        else if(type=='WFWorkstepList')
	{
              var isAdhoc=""; 
              if(Extra4 != undefined && Extra4 != "" && Extra4=="Adhoc")
                isAdhoc = Extra4;
		url="../application/worksteppicklist.faces?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&ReturnNoneValue=" +ReturnNoneText + "&NoneType=" + NoneType + "&NoneValue=" +NoneID+ "&ProcessDefID=" +Extra1+ "&ProcessName=" +encode_utf8(Extra2)+ "&Mode=" +encode_utf8(Extra3)+"&QueueID=0&PM_UID="+pm_uid;
                if(isAdhoc!="")
                       url=url+"&IsAdhoc=Y"; 
                var pickListID="WorkstepPickList";
                iframeHeight=250;
	}
       else if(type=='WFProcVariablelist')
	{             
		url="../application/procvariablelist.faces?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldType=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&ReturnNoneValue=" +ReturnNoneText + "&NoneType=" + NoneType + "&NoneValue=" +NoneID+ "&ProcessDefID=" +Extra1+ "&ProcessName=" +encode_utf8(Extra2)+"&strFormFieldID="+Extra3+"&ShowSysVar="+Extra4+"&PM_UID="+pm_uid;
                var pickListID="ProcVariablePickList";
	}


        else if(type=='WFPickList')
	{
		url="../application/picklist.faces?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&ReturnNoneValue=" +ReturnNoneText + "&NoneType=" + NoneType + "&NoneValue=" +NoneID+ "&ProcessId=" +Extra1+ "&Attribute=" +Extra2+ "&FieldType=" +Extra3+ "&Prefix="+encode_utf8(Extra4)+"&QueueId="+Extra5+"&PM_UID="+pm_uid;
                var pickListID="PickList";
	}
        if(parentFlag != undefined )
        {
            if(parentFlag=="true")
                url=url +"&parentFlag="+parentFlag+"&parentIFrame="+CurrentPickListId;
            else
            {
                parentFlag=="false";
                url=url +"&parentFlag="+parentFlag+"&parentIFrame="+"";
            }
        }
        else
        {
            parentFlag=="false";
            url=url +"&parentFlag="+parentFlag+"&parentIFrame="+"";
        }

	url=url + callBack;
        url = appendUrlSession(url);
        if(parentFlag=="true")
            createIFrame(pickListID,iframeHeight,url,formid+":"+nameCtrl,true);
        else
            createIFrame(pickListID,iframeHeight,url,formid+":"+nameCtrl,false);

	return false;
}


function StyleLink(ref)
{
    //ref.style.textDecoration='underline';
    ref.className="PMOnMouseOver";
}

function StyleLink_RfrdWI_Suspended(ref)
{
    ref.className="PMOnMouseOver_RfrdWI_Suspended";
}

function StyleLink_RfrdWI_Runnig(ref)
{
    ref.className="PMOnMouseOver_RfrdWI_Runnig";
}

function StyleNormal(ref)
{
  //  ref.style.textDecoration='none';
    ref.className="PMOnMouseOut";
}

function StyleNormal_RfrdWI_Suspended(ref)
{
    ref.className="PMOnMouseOut_RfrdWI_Suspended";
}
function StyleNormal_RfrdWI_Runnig(ref)
{
    ref.className="PMOnMouseOut_RfrdWI_Runnig";
}

function StyleLinkRigisterCab(ref)
{
     ref.className = 'RegCabOnMouseOver';
}

function StyleNormalRigisterCab(ref)
{
   ref.className = 'CabinetRegistrationLnk';
}


function ClickAnotherLink(ref,toclick)
{
    var formid="";
    
    try 
    { 
        var formid=ref.form.id;
    }
    catch(e)
    {
        formid=document.forms[0].id;
    }   
    var toclickid=formid+':'+toclick;
    clickLink(toclickid);
}

function clickLink(linkId)
{ 

        if(!linkId)
        {	
                return false;
        }
       
        var fireOnThis = document.getElementById(linkId);
        if (document.createEvent)
        {
            //var evObj = document.createEvent('MouseEvents') ;
            //evObj.initEvent( 'click', true, false ) ;
            //fireOnThis.dispatchEvent(evObj) ;		
            var evObj = document.createEvent('MouseEvents') ;
            evObj.initMouseEvent("click", true, true, window,0, 0, 0, 0, 0, false, false, false, false, 0, null);
            fireOnThis.dispatchEvent(evObj) ;	
        }
        else if (document.createEventObject)
        {
           fireOnThis.click()  ;
        }	

        return true;
}
//BUG ID 628 (hidQueueId is added in the function)
function ShowWorkstepList(ref,hidProcessName,hidProcessId,txtworkstepName,hidworkstepId,hidWorkstepName,mode,hidQueueId)
{
    var formid=ref.form.id;
    try{var procID= document.getElementById(formid+":"+hidProcessId).value;}
    catch(e){var procID= document.getElementById(hidProcessId).value;}
    try{var procName= document.getElementById(formid+":"+hidProcessName).value;}
    catch(e){var procName= document.getElementById(hidProcessName).value};
    var queueID="";
    if(hidQueueId != undefined)
        queueID = document.getElementById(formid+":"+hidQueueId).value;

    ShowPickList(ref,'WFWorkstepList',txtworkstepName,hidworkstepId,hidWorkstepName,'2','','1','',procID,procName,mode,queueID);
}

//noneid added as parameter in order to display all, none, any workstep options
function ShowCustomWorkstepList(ref,hidProcessName,hidProcessId,txtworkstepName,hidworkstepId,hidWorkstepName,mode,NoneId,hidQueueId)
{   
    var formid=ref.form.id;
    try{var procID= document.getElementById(formid+":"+hidProcessId).value;}
    catch(e){var procID= document.getElementById(hidProcessId).value;}
    try{var procName= document.getElementById(formid+":"+hidProcessName).value;}
    catch(e){var procName= document.getElementById(hidProcessName).value};
    var queueID="";
    if(hidQueueId != undefined)
        queueID = document.getElementById(formid+":"+hidQueueId).value;

    ShowPickList(ref,'WFWorkstepList',txtworkstepName,hidworkstepId,hidWorkstepName,NoneId,'','1','',procID,procName,mode,queueID);
}

function ShowUserProp(ref,username,userid)
{
    var url="../usermgmt/showuserprop.faces";

    var WindowHeight=windowH+40;
    var WindowWidth=windowW+30;
    
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    url = appendUrlSession(url);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("Action",encode_ParamValue("q")));
    listParam.push(new Array("username",encode_ParamValue(username)));
    listParam.push(new Array("userid",encode_ParamValue(userid)));

    var win = openNewWindow(url,'user_'+userid+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
	addWindows(win);
    }
    catch(e)
    {}
}

function ShowProcessProp(ref,processname,processid,instances,completedins,descardedins)
{
    var ins  = 0;
    var cins = 0;
    var dins = 0;
    
    if(instances != undefined)
        ins =instances;
    if(completedins != undefined)
        cins =completedins;
    if(descardedins != undefined)
        dins =descardedins;

    var url="../processmgmt/showprocessprop.faces" ;

    var WindowHeight=windowH+40;
    var WindowWidth=windowW+30;
    
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    url = appendUrlSession(url);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("processname",encode_ParamValue(processname)));
    listParam.push(new Array("processid",encode_ParamValue(processid)));
    listParam.push(new Array("instances",encode_ParamValue(ins)));
    listParam.push(new Array("completedins",encode_ParamValue(cins)));
    listParam.push(new Array("descardedins",encode_ParamValue(dins)));


    var win = openNewWindow(url,'process_'+processid+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
	addWindows(win);
    }
    catch(e)
    {}
}
//BUG ID 564 (scrollbars in openwindow set to 1)
function ShowQueueProp(ref,queueid,queuename)
{
    
	var url="../queuemgmt/showqueueprop.faces";
    
    
    var WindowHeight=windowH+40;
    var WindowWidth=windowW+30;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    url = appendUrlSession(url);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=1,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam[0]=new Array("queueid",encode_ParamValue(queueid));
    listParam[1]=new Array("queuename",encode_ParamValue(queuename));

    var win = openNewWindow(url,'queue_'+queueid+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
	addWindows(win);
    }
    catch(e)
    {}
}
function ShowWorkDist(queueid,queuename)
 {
    //BUG ID 650
    var procName = document.getElementById("queueview:hidProcessName").value;  
    var procId = document.getElementById("queueview:hidProcessId").value;  
    
   var url="../queuemgmt/showworksteplist.faces";
   //END
    var WindowHeight=windowH+40;
    var WindowWidth=windowW+30;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    url = appendUrlSession(url);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=auto,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("action",encode_ParamValue("1")));
    listParam.push(new Array("queueid",encode_ParamValue(queueid)));
    listParam.push(new Array("queuename",encode_ParamValue(queuename)));
    listParam.push(new Array("processname",encode_ParamValue(procName)));
    listParam.push(new Array("processid",encode_ParamValue(procId)));    

    var win = openNewWindow(url,'queue_'+queueid+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
	addWindows(win);
    }
    catch(e)
    {}

 }


function ShowProcessLoad(ref,processname,processid)
{
    
    var url="../processview/processviewload.faces";

    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    url = appendUrlSession(url);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("processid",encode_ParamValue(processid)));
    listParam.push(new Array("processname",encode_ParamValue(processname)));

    var win = openNewWindow(url,'processLoad_'+processid+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
	addWindows(win);
    }
    catch(e)
    {}
}
function ShowWorkDistproc(processid,processname)
{
    //BUG ID 634
    var queueName = document.getElementById("processview:hidQueueName").value;  
    var queueId = document.getElementById("processview:hidQueueId").value;  
    //END
    //BUG ID 650
    var url="../processmgmt/showworksteplistforproc.faces" ;
    //END
    //var WindowHeight=ScreenHeight/2;
    //var WindowWidth=ScreenWidth/2;
    var WindowHeight=windowH+40;
    var WindowWidth=windowW+30;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    url = appendUrlSession(url);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("action",encode_ParamValue("1")));
    listParam.push(new Array("processname",encode_ParamValue(processname)));
    listParam.push(new Array("processid",encode_ParamValue(processid)));
    listParam.push(new Array("queuename",encode_ParamValue(queueName)));
    listParam.push(new Array("queueid",encode_ParamValue(queueId)));
    

    var win = openNewWindow(url,'process_'+processid+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
	addWindows(win);
    }
    catch(e)
    {}

 }

function ShowQueueLoad(ref,queuename,queueid)
{
    
    var url="../queueview/queueviewload.faces";
   
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    url = appendUrlSession(url);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam[0]=new Array("queueid",encode_ParamValue(queueid));
    listParam[1]=new Array("queuename",encode_ParamValue(queuename));


    var win = openNewWindow(url,'queueLoad_'+queueid+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
	addWindows(win);
    }
    catch(e)
    {}
}

function VerifyDate(Year,Month,Date)
{
    var bLeap = IsLeap(Year);

    switch(parseInt(Month,10))
    {
        case 1 :
        case 3 :
        case 5 :
        case 7 :
        case 8 :
        case 10:
        case 12:
        if (Date > 31 || Date < 1)
        {
            return false;
        }
        break;
 
        case 4 :
        case 6 :
        case 9 :
        case 11:
            if(Date > 30 || Date < 1)
            {
                return false;
            }
            break;
        case 2:
            if(bLeap)
                {
                    if(Date > 29 || Date <1)
                        return false;
                }
            else 
                {
                    if(Date > 28 || Date <1 )
                        return false;
                }
            break;
        default :
            return false;
    }
     return true;
}

function IsLeap(year)
{
    var leap=false;
    leap=(year % 4 == 0) && ((year % 100 != 0) || (year % 400 == 0));
    return leap;
}

function isInvalid(ch)
{
	if (ch.indexOf(" ") != -1)
		return '1';
	else if (ch.indexOf("'") == -1 && ch.indexOf("\\") == -1 && ch.indexOf("+") == -1 && ch.indexOf("-") == -1 && ch.indexOf("*") == -1 && ch.indexOf("/") == -1 && ch.indexOf('\"') == -1 && ch.indexOf(">") == -1 && ch.indexOf("<") == -1 && ch.indexOf("=") == -1)
		return '2';
	else
		return '3';
}

function TextValidate(text)
{
	var i=0;
	var len = text.length;
	var val=text;
	if(val == "")
	{
		return 1;
	}
	if ( len > 255)
	{
		return (-2);
	}
	while(i != len)
	{
		chr = val.charAt(i);
		chrAscii =val.charCodeAt(i);
		if(chr == "'" || chr == '|' || chr == '"') 
		{
			return (-3);
		}
		i++;
	}
	return 1;
}

function validateAllTypeData(val,strType){
   if(trimByRegularEx(val)=="")
         return 1;
   if(isNaN(val))
        {
            return 0;
        }
   if(strType=="3")
    {
       if(IsNumericVal(val))
       {
           if(val<-32768 || val>32767)
        {
            return 0;
        } 
       }
       else{
           return 0;
       } 
   }else if(strType=="4")
    {
       if(IsNumericVal(val))
       {
          if(val<-2147483648 || val>2147483648)
        {
            return 0;
        }

       }
       else{
           return 0;
       } 
    }else if(strType=="6"){
        if(val<1.4E-45 || val>3.4028235E38)
        {
            return 0;
        }  
   }
 
   return 1; 
}

function format(valuelessten)
{
	if(parseInt(valuelessten) <10)
	{
		switch(parseInt(valuelessten))
		{
			case 0:
				return("00");
			case 1:
				return("01");

			case 2:
				return("02");

			case 3:
				return("03");

		    case 4:
				return("04");

			case 5:
				return("05");

		   case 6:
				return("06");

		  case 7:
				return("07");

		  case 8:
				return("08");

		  case 9:
     	    	return("09");
		}
	}
	else
		return valuelessten;
}

function compareDate(date1,date2)
{
        if(date1 > date2)
                return false;
        else 
                return true;
} 

function IsFloatVal(val)
{
	var len = val.length;
	var i;
	for(i=0; i<=(len - 1);i++)
		if(val.charAt(i)==".")
			return 1;
	return 0;
}

function IsNumericVal(val)
{
	if (isNaN(val) || IsFloatVal(val))
		return 0;
	return 1;
}
//BUG ID 549
function FindPos(Str,SearchStr)
{
	len = Str.length;
	for(i=0;i < len;++i)
	{
		if(Str.charAt(i) == SearchStr)
			return i;
	}
	return -1;
}


var cookie = navigator.cookieEnabled;
var sessionVal="";

function appendUrlSession(url)
{
    return handleJSessionID(url);
}
function appendUrlSessionAjax(url)
{
    return handleJSessionID(url);
}
function handleJSessionID(url)
{
      var cookieFlag = 'Y';

    if(cookie)
        cookieFlag = 'Y';
    else
        cookieFlag = 'N';

   try
   {
    if(cookieFlag == 'N' && SessionVariable!="" )
    {
	    if(url.indexOf('?') != '-1')
            url = url.substring(0,url.indexOf('?'))+SessionVariable+url.substring(url.indexOf('?'));
        else
            url = url + SessionVariable;
    }
   }catch(Ex)
   {
       var frmAction = document.forms[0].action;
        if(sessionVal == "" && frmAction.indexOf(";")!="-1")
            sessionVal = frmAction.substring(frmAction.indexOf(";"));

        if(cookieFlag == 'N' && sessionVal!="" )
        {
            if(url.indexOf('?') != '-1')
                url = url.substring(0,url.indexOf('?'))+sessionVal+url.substring(url.indexOf('?'));
            else
                url = url + sessionVal;
        }
   }
    return url;
}

function showGraph(ref,toClick)
{
        var strincludedPage="";
	if(cookie)
	{
		
                try{
                    strincludedPage= document.getElementById("includedPage").value;
                    if(strincludedPage!="null" && strincludedPage.length>0)
                    document.getElementById("backrenderbutton").value="N";
                }
                catch(Ex){}
                if(strincludedPage!="null" && strincludedPage.length>0)
                return true;
                else
                { 
                try{

                NewSubmit(ref);
                
                }
                catch(e){alert(e)}
                return false;
                }
	}
	else
	{
		alert(GRAPH_CANNOT_BE_SHOWN_AS_NO_COOKIE);
		return false;
	}
}

function showGraphViews(ref,toClick)
{
	if(cookie)
	{
		ClickAnotherLink(ref,toClick);
	}
	else
	{
		alert(GRAPH_CANNOT_BE_SHOWN_AS_NO_COOKIE);
		return false;
	}
}

function CalendarStyleLink(ref)
{
    ref.style.textDecoration='underline';
    ref.className="PMCalenderGreen";
    ref.style.cursor='pointer';
}

function CalendarStyleCurrentNormal(ref)
{
    ref.style.textDecoration='none';
    ref.className="PMCalenderBlack";
}

function CalendarStyleNormal(ref)
{
    ref.style.textDecoration='none';
    ref.className="PMCalenderBlack";
    
    
}
function CalendarStylePartialWorking(ref)
{
    ref.style.textDecoration='underline';
    ref.className="PMCalenderBlack";
    
}
function CalendarStylePartialWorkingCurrent(ref)
{
    ref.style.textDecoration='underline';
    ref.className="PMCalenderBlack";
    
}

function CalendarStyleWeekLink(ref)
{
    ref.style.cursor='pointer';
}

/*----------------------------------------------------------------------------------------------------
//Function Name   : createIndicator
//Date Written (DD/MM/YYYY) : 31/08/2007
//Author   : Arup Sharma
//Input Parameters  :
//Output Parameters  :
//Description   : Creates a  images that acts as an indicator during an ajax call
----------------------------------------------------------------------------------------------------
 
----------------------------------------------------------------------------------------------------*/
 
function createIndicator(indicatorFrameId)
{
  //closePicklists();
try{
  closePicklistWindows();
}
catch(e){}
   var ScreenHeight=screen.height;
   var ScreenWidth=screen.width;   
   var WindowLeft=parseInt(ScreenWidth/2)-53;
   var WindowTop=parseInt(ScreenHeight/2)-20;
 
   try
    {
       
        if(document.getElementById(indicatorFrameId) != null)
            return;
        img = document.createElement("IMG");   
        img.setAttribute("src", "../omniflow/images/progressimg.gif");
        img.setAttribute("name", indicatorFrameId);
        img.setAttribute("id", indicatorFrameId);
        img.style.left = WindowLeft+"px";
        img.style.top = WindowTop+"px";
        img.style.position="absolute";
        img.style.visibility="visible";
        //img.style.width="105px"; 
        //img.style.height="15px";
        document.body.appendChild(img);
             
   }
   catch(ex)
   {
       alert("exception= "+ex);
   }
  document.body.style.cursor='wait';
}
 
/*----------------------------------------------------------------------------------------------------
//Function Name   : removeIndicator
//Date Written (DD/MM/YYYY) : 31/08/2007
//Author   : Arup Sharma
//Input Parameters  :
//Output Parameters  :
//Description   : Removes the image of indicator from the page after the ajax call
----------------------------------------------------------------------------------------------------
 
----------------------------------------------------------------------------------------------------*/
 
function removeIndicator(indicatorFrameId)
{
   try
    {
       var img = document.getElementById(indicatorFrameId);
       document.body.removeChild(img);
    }
    catch(ex)
    {
       
    }
    document.body.style.cursor='auto';
}

function randomString() {
	var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
	var string_length = 8;
	var randomstring = '';
	for (var i=0; i<string_length; i++) {
		var rnum = Math.floor(Math.random() * chars.length);
		randomstring += chars.substring(rnum,rnum+1);
	}
	return randomstring;
}

var resultContainerId='';
function NewSubmit(item,containerId)
{       
    if(document.getElementById('userview:hidProcessName'))
     {
    var txtProcessName = document.getElementById('userview:hidProcessName').value;
    var isSupervisor = document.getElementById('userview:hidIsSupervisor1');
    if((txtProcessName == null || txtProcessName == '' || txtProcessName == 'All Processes') && isSupervisor == null)
        {
            alert(ALERT_SELECT_PROCESSNAME);
            return false;
        }
     }
     if(document.getElementById('isSupervisor'))
      {
     if(document.getElementById('isSupervisor').value == "false")
         {           
            if(!document.getElementById('auditconfig11:cmdlink_Cabinet') && item.value != 'go')                 
          {
              alert(NOT_AUTHORIZED_TO_USE_THE_OPERATION);
              return false;
          }     
        }
       }
        resultContainerId='';

	if(containerId != undefined)
        {
            resultContainerId = containerId;
        }

	sub(item);
	return false;

}


function sub(item) 
{ 
	
   var xmlReq = null;
   var file = item.form.action;
   var time=new Date();
   var tempurl;

   if(file.indexOf("?")>0)
	{
		tempurl=file + "&time="+ time.getTime();
	}
	else
	{
		tempurl=file + "?time="+ time.getTime();
	}

	file=tempurl;
        if(file.indexOf("userviewlist.faces")!=-1) {
        tempurl = file + "&userType=s";
        file = tempurl;
        }
    var str = getFormValues(item,"validate"); 
 	
   xmlReq = getXML(file,str); 
}  

var doc = null ; 
function getXML(file,str) 
{   
    var time=new Date();
    //var indid = randomString();
   if (typeof window.ActiveXObject != 'undefined' ) 
   { 
       doc = new ActiveXObject("Microsoft.XMLHTTP"); 
       doc.onreadystatechange = displayState; 
   } 
   else 
   { 
       doc = new XMLHttpRequest(); 
       doc.onload = displayState; 
   } 
createIndicator('NewSubmitInd');
   try
	{
	   doc.open( "POST", file, true); 
           doc.setRequestHeader("Content-Type","application/x-www-form-urlencoded"); 
	   doc.send(str); 
	}
	catch(e)
	{
//		alert("from getxml==");
	}
	   return doc; 




function displayState()
{
		var outputxml=null;
		
		if (doc.readyState!=null && doc.readyState==4)
		{
			if (doc.status==200)
			{
                               
				try
				{
					outputxml=doc.responseText;
                                        
					//alert("displayState");
					//To check whether the page is errorpage or not.
					//If it is errorpage remove the logo and ok button(ie. only add the content of div to the innerhtml)
					//For BUG ID:205
					var error = "PM_ERROR_PAGE_12345_DIV";
                                        if(outputxml.indexOf(error)>0)
                                        {
                                            try{
                                                var errorMsg=outputxml.substring(outputxml.indexOf(error) + error.length,outputxml.length);
                                               errorMsg=errorMsg.substring(errorMsg.indexOf(">")+1,errorMsg.indexOf("</Div>"));
                                                if(errorMsg.length>0)
                                                    alert(errorMsg);
                                                else
                                                    alert(SESSION_TIMEDOUT);
                                                
                                            }catch(ex) {
                                                alert(SESSION_TIMEDOUT);
                                            }
                                        }
                                        else
                                        {
                                            try
                                            {
                                                if(resultContainerId != '')
                                                {
                                                    document.getElementById(resultContainerId).innerHTML=outputxml;	
                                                    doc=null;
                                                }
                                                else
                                                {
                                                    document.getElementById("ResultContainer").innerHTML=outputxml;	
                                                    doc=null;
                                                }
                                            }
                                            catch(ee)
                                            {
                                   
                                                window.opener.document.getElementById("ResultContainer").innerHTML=outputxml;
                                                window.opener.focus();
                                                doc=null;
                                            } 
                                        }
				}
				catch (e)
				{
					//alert("Exception "+e.toString());
                                        try
                                        {
                                            document.getElementById("ResultContainer").innerText=outputxml ;	
                                        }
                                        catch(eee)
                                        {
                                            window.opener.document.getElementById("ResultContainer").innerText=outputxml;	
                                            window.opener.focus();
                                        }
				}
			
			}
		  else
			{
			  //alert(doc.responseText);
			   alert(ERROR_FETCHING_DATA);
			}
                        removeIndicator('NewSubmitInd');
                        try{

                        if((document.getElementById("callbackfunction").value).length>0)
                            {
                                    var callbackfunction=document.getElementById("callbackfunction").value;
                                    //alert("Inside Eval callbackfunction=="+callbackfunction);
                                    eval(callbackfunction);
                            }
                        }
                        catch(e){

                        }

		}	  
}
}
function getFormValues(item,valFunc) 
{ 
		
   var str = ""; 
   var valueArr = null; 
   var val = ""; 
   var cmd = ""; 
   var fobj = item.form;
   var formid=fobj.id;	
   
   for(var i = 0;i < fobj.elements.length;i++) 
   { 
	   //alert('Type of elt: '+fobj.elements[i].type+" name:  "+fobj.elements[i].name);
		
	   switch(fobj.elements[i].type) 
       { 
		 case "hidden":
			 
			var stateName = "com.sun.faces.VIEW";
			if(fobj.elements[i].name== stateName)
      {                    
  var stateValue = null;
  var params = "";
  
  stateValue = fobj.elements[i].value;
  var encodedValue = encodeURI(stateValue);
  var re = new RegExp("\\+", "g");
  var encodedPlusValue = encodedValue.replace(re, "\%2B");
  params = stateName + "=" + encodedPlusValue + "&";
  
  str += params;
     }
     else
     { 
    str += encode_utf8(fobj.elements[i].name) +  "=" + encode_utf8(fobj.elements[i].value) + "&";
     }
     break;
     case "textarea":
     case "text": 
                   case "password":
                str += encode_utf8(fobj.elements[i].name) +  "=" + encode_utf8(fobj.elements[i].value) + "&"; 
                break; 
 

           case "select-one": 
			   
                if(fobj.elements[i].selectedIndex!=-1)
                str += encode_utf8(fobj.elements[i].name) + "=" + encode_utf8(fobj.elements[i].options[fobj.elements[i].selectedIndex].value) + "&"; 
                break;
            case "select-multiple":
		formElement=fobj.elements[i];
                len=document.getElementById(fobj.elements[i].name).length;
                for(var x=0; x < len; x++) 
                {
                if(formElement[x].selected == true)
                str += encode_utf8(fobj.elements[i].name) + "=" + formElement[x].value + "&"; 
                }
                break;

           case "checkbox":
                   if(fobj.elements[i].checked)
                        {
                           str += encode_utf8(fobj.elements[i].name) + "=" +(fobj.elements[i].value) + "&"; 
                        }
                break;
		   case "radio":	
			   if(fobj.elements[i].checked)
				{
					str += encode_utf8(fobj.elements[i].name) + "=" +(fobj.elements[i].value) + "&"; 
				}
                break;

			
       }
	}
 
   if(item.name == undefined)
	{
	  	//alert('item name undefined');
	}
	else
	{
            //alert(item.name);
                if(item.type=="image")
                 {                                       
                    str+=encode_utf8(item.name+'.x') + "="+encode_utf8(item.value)+"&";
                    str+=encode_utf8(item.name+'.y') + "="+encode_utf8(item.value);
                    }
                 else       
                {                    
                if(item.value.length==0)
                {
                //alert('in length eq 0');
                str+=encode_utf8(item.name) + "="+encode_utf8('act');    
                }
                else
                {
                //alert('in else case');
		str+=encode_utf8(item.name) + "="+encode_utf8(item.value);
                }
                }
	}
   str = str.substr(0,(str.length - 1));
   
   return str;
}


/*----------------------------------------------------------------------------------------------------
//Function Name:		createIFrame
//Date Written 	:		10,oct 2007
//Author	:		Vijay Kumar
//Input Parameters:             IFrameId,srcUrl,textboxname
//Output Parameters:            none
//Return Values	: 
//Description:			create a i frme and load url in iframe
----------------------------------------------------------------------------------------------------*/

function createIFrame(IFrameId,height,srcUrl,textboxname,frameFlag,width)
{  
   try
    {   		
        var flag=false;
        var finalWindow=window;
        var frameRelativeLeft =frameRelativeTop=0;

        if(frameFlag)  //if new iframe is outside of all iframes find outside window ref 
        {
            while(1)
            {
                if(finalWindow.frameElement)
                {
                    flag=true;
                    var ctrlOld=finalWindow.frameElement;
                    finalWindow=finalWindow.parent;
                    if (ctrlOld.offsetParent) 
                    {
                        frameRelativeLeft = ctrlOld.offsetLeft
                        frameRelativeTop = ctrlOld.offsetTop
                        while (ctrlOld = ctrlOld.offsetParent) 
                        {
                            frameRelativeLeft += ctrlOld.offsetLeft
                            frameRelativeTop += ctrlOld.offsetTop
                        }
                    }
                }
                else
                break;
            }//end of while
        }

       if(finalWindow.document.getElementById(IFrameId) != null)
           return;
	
        iframe=finalWindow.document.createElement("IFRAME");
		
        iframe.setAttribute("allowtransparency","true");	
        iframe.allowtransparency="true";
        iframe.style.allowtransparency="true";

        iframe.setAttribute("src",srcUrl);
        iframe.setAttribute("name", IFrameId);
        iframe.setAttribute("id", IFrameId);
		
        ctrlname= document.getElementById(textboxname);
        bodyCtrlName=finalWindow.document.body;

        var cdRight=cdLeft=cdTop=cdBottom=0;
        var bodyRight=bodyLeft=bodyTop=bodyBottom=0;
        var picklistTop=pickListLeft=picklistBottom=picklistRight=0;
        var scrollLeft=scrollTop=0;
        var viewportLeft=viewportRight=viewportTop=viewportBottom=0;

        var picklistHeight=height;
        var picklistWidth=225;
        if(typeof width != 'undefined')
            picklistWidth = width;
        var Lmargin=8;
        var Rmargin=8;
        var margin=5;
        var anotherBrowser=false;
/*----------------------------------Absolute top-left position of text box--------------------------------------------------*/
        var absoluteleft = absolutetop = 0;
        var tempCtrlname=ctrlname;

        if (tempCtrlname.offsetParent)
        {
            absoluteleft = tempCtrlname.offsetLeft;
            absolutetop = tempCtrlname.offsetTop;
            while (tempCtrlname = tempCtrlname.offsetParent) 
            {
                absoluteleft += tempCtrlname.offsetLeft;
                absolutetop += tempCtrlname.offsetTop;
            }
        }
        absoluteleft += 2;
        absolutetop += 2;
/*  to find top ,left ,bottom and right of textbox control . Actual top,left is 2 pixel less then calculated*/

        try
        {
            if(ctrlname.getBoundingClientRect)//internet explorer
            {
                rcts = ctrlname.getBoundingClientRect();
                bodyRcts=bodyCtrlName.getBoundingClientRect();

                cdRight = rcts.right ;  //these are relative positions 
                cdLeft = rcts.left;
                cdTop = rcts.top;
                cdBottom = rcts.bottom ;

                bodyRight = bodyRcts.right ;
                bodyLeft = bodyRcts.left;
                bodyTop = bodyRcts.top;
                bodyBottom = bodyRcts.bottom ;

                if(absoluteleft  !=  cdLeft || absolutetop  !=cdTop)   //to change relative to absolute positions
                {
                    absoluteHorizontalDiff=absoluteleft-cdLeft;
                    absoluteVerticalDiff=absolutetop-cdTop;

                    cdTop+=absoluteVerticalDiff;
                    cdBottom+=absoluteVerticalDiff;
                    cdLeft+=absoluteHorizontalDiff;
                    cdRight+=absoluteHorizontalDiff;	
                }
            }
            else if(document.getBoxObjectFor) //mozilla
            {
                rcts = document.getBoxObjectFor(ctrlname);
                bodyRcts=finalWindow.document.getBoxObjectFor(bodyCtrlName);

                cdLeft = rcts.x ;
                cdTop = rcts.y ;
                cdRight = rcts.width+ cdLeft;
                cdBottom = rcts.height+cdTop ;

                bodyLeft = bodyRcts.x ;
                bodyTop =  bodyRcts.y ;
                bodyRight =  bodyRcts.width+ bodyLeft;
                bodyBottom =bodyRcts.height+bodyTop ;
            }
            else
            {

                cdLeft =absoluteleft ;
                cdTop = absolutetop ;
                cdRight = curleft+100;
                cdBottom = curtop+10 ;
            }
        }catch(e){}
/*-------------------------------------to set exact positions-----------------------------------------------------------------*/
        if(cdLeft !=0)
        cdLeft -=2;
        if(cdTop !=0)
        cdTop -=2;
        cdRight -=2;
        cdBottom -=2;

        if(bodyLeft!=0)
          bodyLeft -=2;
        if(bodyTop!=0)
        bodyTop -=2;
        bodyRight -=2;
        bodyBottom -=2;
/*-----------------------------------To find the active view of window-------------------------------------------------------------------*/
        try
        {
            scrollLeft=bodyCtrlName.scrollLeft;
            scrollTop=bodyCtrlName.scrollTop;
        }
        catch(e)
        {
            scrollLeft=0;
            scrollTop=0;
        }
				
        viewportLeft=bodyLeft+scrollLeft;
        viewportRight=bodyRight+scrollLeft;
        viewportTop=bodyTop+scrollTop;
        viewportBottom=bodyBottom+scrollTop;
/*-----------------------------------to set the position of pickList-------------------------------------------------------------------*/


        if(flag)   //if it gose outside  of inner pick list
        {
            width=cdRight-cdLeft;
            height=cdBottom-cdTop;

            cdLeft = cdLeft+frameRelativeLeft ;
            cdTop = cdTop+frameRelativeTop ;
            cdRight = cdLeft+width;
            cdBottom = cdTop+height ;
        }

        pickListLeft=cdRight - picklistWidth+Rmargin;				//to show bottom-right of textbox aligned to top-right of picklist
        picklistTop= cdBottom;
        picklistRight=pickListLeft+picklistWidth;
        picklistBottom=picklistTop+picklistHeight;


        if(pickListLeft<viewportLeft)        //right align with control
        {
            pickListLeft=cdLeft-Lmargin;
            picklistRight=pickListLeft+picklistWidth;

        }
        if(picklistRight>viewportRight)  //again right align ,maximum cases not possible
        {
            tempVar=picklistRight-viewportRight-margin;

            pickListLeft=pickListLeft-tempVar;
            picklistRight=picklistRight-tempVar;
        }
        if(picklistBottom>viewportBottom)  //above the control
        {

            picklistBottom=cdTop;
            picklistTop=picklistBottom-picklistHeight;
        }
        if(picklistTop<viewportTop)
        {
            tempVar=viewportTop-picklistTop+margin;

            picklistTop=picklistTop+tempVar;
            picklistBottom=picklistBottom+tempVar;
        }

        iframe.frameBorder="0"; 
        iframe.style.frameBorder="0"; 

        iframe.scrolling="no";
        iframe.style.scrolling="no"; 

        iframe.style.visibility="visible";
        iframe.style.position="absolute";

        iframe.style.width= picklistWidth+"px"; 
        iframe.style.height=picklistHeight+"px";


        iframe.style.left = pickListLeft;
        iframe.style.top = picklistTop;

        refFrame=finalWindow.document.body.appendChild(iframe);	
		refFrame.parent=finalWindow;
		addPicklistWindows(refFrame);         
   }
   catch(ex)
   {
      //alert("exception= "+ex);
   }

}
 

function createPopUpIFrame(IFrameId,srcUrl,height,width)
{ 
    var ParentDocWidth = document.body.clientWidth;
    var ParentDocHeight = document.body.clientHeight;
    var IFrameTop=ParentDocHeight/2-height/2;
    var IFrameLeft=ParentDocWidth/2-width/2;
   try
    {   		
         var finalWindow=window;
       if(finalWindow.document.getElementById(IFrameId) != null)
           return;
	
        iframe=finalWindow.document.createElement("IFRAME");
		
        iframe.setAttribute("allowtransparency","true");	
        iframe.allowtransparency="true";
        iframe.style.allowtransparency="true";

        iframe.setAttribute("src",srcUrl);
        iframe.setAttribute("name", IFrameId);
        iframe.setAttribute("id", IFrameId);
		
        iframe.frameBorder="0"; 
        iframe.style.frameBorder="0"; 

        iframe.scrolling="no";
        iframe.style.scrolling="no"; 

        iframe.style.visibility="visible";
        iframe.style.position="absolute";

        iframe.style.width= width+"px"; 
        iframe.style.height=height+"px";


        iframe.style.left = IFrameLeft;
        iframe.style.top = IFrameTop;


        refFrame=finalWindow.document.body.appendChild(iframe);	
	refFrame.parent=finalWindow;   
        addPicklistWindows(refFrame);     
   }
   catch(ex)
   {
      //alert("exception= "+ex);
   }

}

function addPicklistWindows(IFrame)
{
    var flag=false;
    var len = allPicklistWindows.length;
    for(x=0; x<len;x++)
    {
        if ((allPicklistWindows[x] == null) )
        {
            allPicklistWindows[x] = IFrame;
            flag = true;
            break;
        }
    }

    if (flag == false)
        allPicklistWindows[len] = IFrame;
}

function closePicklistWindows(IFrameId)
{
    if (IFrameId != undefined ) //if remove child iframe of iframeid
    {
        try
        {
            var  parent = window.parent;
            var iframe= parent.document.getElementById(IFrameId);
            removeChildIFrames(iframe);
        }
        catch(ex){}
    }
    else //remove all child and frame in case of main window
    {
        var len = allPicklistWindows.length;
        for(x=0; x<len;x++)
        {
        if ((allPicklistWindows[x] != null) )
            try
            {
                allPicklistWindows[x].contentWindow.removeChildIFrames(allPicklistWindows[x]); //remove child of picklist by calling its method
                document.body.removeChild(allPicklistWindows[x]); //remove iframe
            }
            catch(e){}
        }	
    }
}

function removeIFrame(IFrameId)
{
   try
    {
        var  parent = window.parent;
        var iframe= parent.document.getElementById(IFrameId);

         removeChildIFrames(iframe);
        parent.document.body.removeChild(iframe);
    }
    catch(ex){ }
   
}

function removeChildIFrames(ref)
{
    try
    {
        var len = ref.contentWindow.allPicklistWindows.length;  //check child of reference frame and remove them
        if(len<=0)
           return;

        for(x=0; x<len;x++)
        {
            if ((ref.contentWindow.allPicklistWindows[x] != null) )
            {
                try
                {
                    ref.contentWindow.removeChildIFrames(ref.contentWindow.allPicklistWindows[x]); //remove child of child frame
                    removeIFrameByRef(ref.contentWindow.allPicklistWindows[x]); //remove child
                }
                catch(e){}
            }
        }
    }catch(e){}
}

function removeIFrameByRef(ref)
{
   try
    { 
        var parent = ref.parent;
        parent.document.body.removeChild(ref);
    }
    catch(ex)
    { }
   
}
function showTabuler(ref)
{
        var strincludedPage="";
	if(cookie)
	{
		try{

                strincludedPage= document.getElementById("includedPage").value;
                if(strincludedPage!="null" && strincludedPage.length>0)
                    document.getElementById("backrenderbutton").value="N";
                }
                catch(Ex){alert("11"+Ex)}
                if(strincludedPage!="null" && strincludedPage.length>0)
                return true;
                else
                { 
                try{

                NewSubmit(ref);
                
                }
                catch(e){alert(e)}
                return false;
                }
	}
	else
	{
		alert(GRAPH_CANNOT_BE_SHOWN_AS_NO_COOKIE);
		return false;
	}
}
function RefreshThisPage()
{
    ClickAnotherLink(document,'cmdlink_Refresh'); 
}

function ValidateTime(val){
    val = Trim(val);
    if (val.indexOf(":")==-1)
    {	
            alert(INVALID_TIME);
            return 0;
    }
    var temphr=val.substring(0,val.indexOf(":"));
    if(temphr=="" || !IsNumericVal(temphr)||temphr>24 ||temphr<0)
    {
            alert(NON_NUMERIC_HOUR);//'HOUR should be numeric'
            return 0;
    }

    var tempmin;
    val=val.substring(val.indexOf(":")+1,val.length);

    if (val.indexOf(":")!=-1)
    {
            tempmin=val.substring(0,val.indexOf(":"));
            var tempsec=val.substring(val.indexOf(":")+1,val.length);

            if(tempsec=="" || (!IsNumericVal(tempsec)) ||tempsec>=60 ||tempsec<0)
            {
                    alert(NON_NUMERIC_SEC);//'SEC should be numeric'
                    return 0;
            }
    }
    else        
            tempmin=val.substring(0,val.length);
    
    if(tempmin=="" || !IsNumericVal(tempmin)||tempmin>=60 ||tempmin<0)
    {
            alert(NON_NUMERIC_MIN);//'MIN should be numeric'
            return 0;
    }
    return 1;
}

function StyleRowLink(ref)
{
    ref=ref.parentNode.parentNode;
    var preClassName=ref.className;
    if(preClassName!='CRSelected')
        ref.className='CRHover';  
}
function StyleRowNormal(ref)
{
    ref=ref.parentNode.parentNode;
    var preClassName=ref.className;
    if(preClassName!='CRSelected')
    ref.className='CRSimple'; 
}
function chartchart1PClick(polycoord)//for image map in reports
{
    return false;
}
function chartchart2PClick(polycoord)//for image map in reports
{
    return false;
}
function chartchart3PClick(polycoord)//for image map in reports
{
    return false;
}
function chartchart4PClick(polycoord)//for image map in reports
{
    return false;
}
function chartchart5PClick(polycoord)//for image map in reports
{
    return false;
}
function chartchart1Click(polycoord)//for image map in reports
{
    return false;
}
function chartchart2Click(polycoord)//for image map in reports
{
    return false;
}
function chartchart3Click(polycoord)//for image map in reports
{
    return false;
}

function openNewWindow(sURL, sName, sFeatures, bReplace,Ext1,Ext2,Ext3,Ext4,listParameters)
{
    var popup = window.open('',sName,sFeatures,bReplace);
    popup.document.write("<HTML><HEAD><TITLE></TITLE></HEAD><BODY>");
    popup.document.write("<form id='postSubmit' method='post' action='"+sURL+"' enctype='application/x-www-form-urlencoded'>");
    for(var iCount=0;iCount<listParameters.length;iCount++)
    {
        var param=listParameters[iCount];
        popup.document.write("<input type='hidden' id='"+param[0]+"' name='"+param[0]+"'/>");
        popup.document.getElementById(param[0]).value=param[1];//handle single quotes etc
    }
    popup.document.write("</FORM></BODY></HTML>");
    popup.document.close();
    popup.document.forms[0].submit();
    return popup;
}
function generatePostRequest(winRef,sURL,listParameters)
{
    var formElement=winRef.document.getElementById("postSubmit");
    if(formElement!= undefined)
        winRef.document.body.removeChild(formElement);
    formElement = winRef.document.createElement("form");
    formElement =winRef.document.body.appendChild(formElement);
    formElement.action=sURL;
    formElement.encoding='application/x-www-form-urlencoded';
    formElement.method="post";
    formElement.id='postSubmit';
    for(var iCount=0;iCount<listParameters.length;iCount++)
    {
        var param=listParameters[iCount];
        var srcInput = winRef.document.createElement("input");
        srcInput.setAttribute("type", "hidden");
        srcInput.setAttribute("name", param[0]);
        srcInput.setAttribute("id", param[0]);
        srcInput.setAttribute("value", param[1]);
        formElement.appendChild(srcInput);
    }
    winRef.document.forms['postSubmit'].submit();
}
function encode_ParamValue(param)
{
        return param;
}
function decode_ParamValue(param)
{
    var tempParam =param.replace(/\+/g,' ');
    tempParam = decodeURIComponent(tempParam);

    return tempParam;
}
function getInputParamListFromURL(sURL)
{
    var ibeginingIndex=sURL.indexOf("?");
    var listParam=new Array();
    if (ibeginingIndex == -1)
        return listParam;
    var tempList=sURL.substring(ibeginingIndex+1,sURL.length);

    if(tempList.length>0)
     {
        var arrValue =tempList.split("&");
        for(var iCount=0;iCount<arrValue.length;iCount++)
        {
            var arrTempParam=arrValue[iCount].split("=");
            try
            {
                listParam.push(new Array(decode_ParamValue(arrTempParam[0]),decode_ParamValue(arrTempParam[1])));
            }catch(ex)
            {

            }
        }
    }
    return listParam;
}
function getActionUrlFromURL(sURL)
{
    var ibeginingIndex=sURL.indexOf("?");
    if (ibeginingIndex == -1)
        return sURL;
    else
        return sURL.substring(0,ibeginingIndex);
 }

function openCommentWindow(CallBack,Validate,commentBoxId,thisObj)
{
    var bOpenWindow=true;
    if(Validate.length>0)
    {
        bOpenWindow=eval(Validate + '(thisObj);');
    }
    if(bOpenWindow)
    {
        var sURL="../application/pmcomment.faces?";
        sURL=sURL+"CallBack="+CallBack+"&Validate="+Validate+"&commentBoxId="+commentBoxId+"&PM_UID="+pm_uid;
        sURL=appendUrlSessionAjax(sURL);
        createPopUpIFrame('CommentWindow',sURL,'190','300');
    }
    return false;
}
function NewSubmit1(item,containerId)
{       
       var  processname = document.getElementById("userview:txtProcessName").value;
       var  b_user = document.getElementById("userview:username").value;
     
       if((processname == "All Processes") && (b_user=="false")) { 
         alert(SELECT_SINGLE_PROCESS); 
         return false;
       } 
      else {
        resultContainerId='';

	if(containerId != undefined)
        {
            resultContainerId = containerId;
        }

	sub(item);
	return false;
}
}


/*window.open overriding function starts*/

window.open_=window.open;


window.open=function(m_url,m_name,m_properties)
{
	if(m_url.indexOf("?")>0)
	{
		m_url=m_url + "&PM_UID="+ pm_uid;
	}
	else
	{
		m_url=m_url + "?PM_UID="+ pm_uid;
	}

    var actionURL=getActionUrlFromURL(m_url);
    var listParam=getInputParamListFromURL(m_url);
    var win = openNewWindow(actionURL, m_name, m_properties, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    return win;
}


function openNewWindow(sURL, sName, sFeatures, bReplace,Ext1,Ext2,Ext3,Ext4,listParameters)
{
  /*  if(sURL.indexOf("?")>0)
	{
		sURL=sURL + "&PM_UID="+ pm_uid;
	}
	else
	{
		sURL=sURL + "?PM_UID="+ pm_uid;
	} */
    var popup = window.open_('',sName,sFeatures,bReplace);
    popup.document.write("<HTML><HEAD><TITLE></TITLE></HEAD><BODY>");
    popup.document.write("<form id='postSubmit' method='post' action='"+sURL+"' enctype='application/x-www-form-urlencoded'>");
    for(var iCount=0;iCount<listParameters.length;iCount++)
    {

        var param=listParameters[iCount];
        popup.document.write("<input type='hidden' id='"+param[0]+"' name='"+param[0]+"'/>");
        popup.document.getElementById(param[0]).value=param[1];//handle single quotes etc
    }
	popup.document.write("<input type='hidden' id='PM_UID' name='PM_UID' value='"+pm_uid+"' />");
    popup.document.write("</FORM></BODY></HTML>");
    popup.document.close();
    popup.document.forms[0].submit();
    return popup;
}

function getActionUrlFromURL(sURL)
{
    var ibeginingIndex=sURL.indexOf("?");
    if (ibeginingIndex == -1)
        return sURL;
    else
        return sURL.substring(0,ibeginingIndex);
 }

 function getInputParamListFromURL(sURL)
{
    var ibeginingIndex=sURL.indexOf("?");
    var listParam=new Array();
    if (ibeginingIndex == -1)
        return listParam;
    var tempList=sURL.substring(ibeginingIndex+1,sURL.length);

    if(tempList.length>0)
     {
        var arrValue =tempList.split("&");
        for(var iCount=0;iCount<arrValue.length;iCount++)
        {
            var arrTempParam=arrValue[iCount].split("=");
            try
            {
                listParam.push(new Array(decode_ParamValue(arrTempParam[0]),decode_ParamValue(arrTempParam[1])));
            }catch(ex)
            {

            }
        }
    }
    return listParam;
}

function decode_ParamValue(param)
{
    var tempParam =param.replace(/\+/g,' ');
    tempParam = decodeURIComponent(tempParam);

    return tempParam;
}
function StyleLinkFeedBack(ref)
{
     ref.className = 'FeedBackOnMouseOver';
}
function StyleNormalFeedBack(ref)
{
   ref.className = 'FeedBackLink';
}


function showPickListMultiLingual(reference,type,nameCtrl,iDCtrl,hidNameCtrl,NoneType,NoneID,ReturnNoneText,FunctionName,Extra1,Extra2,Extra3,Extra4,Extra5,Extra6,Extra7,parentFlag,CustomRightsFlag)
{
    if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '0')
        {
            alert(Please_select_entity_type);
            return false;
        } 
        type = picklist;
        if(type == 'WFQueueList')
            NoneType = 4;    // For displaying My queue in queue pick list.
            NoneID = 0;
ShowPickList(reference,type,nameCtrl,iDCtrl,hidNameCtrl,NoneType,NoneID,ReturnNoneText,FunctionName,Extra1,Extra2,Extra3,Extra4,Extra5,Extra6,Extra7,parentFlag,CustomRightsFlag)
}



function showVariablePickList(reference,type,nameCtrl,iDCtrl,hidNameCtrl,NoneType,NoneID,ReturnNoneText,FunctionName,Extra1,Extra2,Extra3,Extra4,Extra5,Extra6,Extra7,parentFlag,CustomRightsFlag)
{
     var processNameValue= document.getElementById("multilingual:hidProcessName").value;
    var lastIndex = processNameValue.lastIndexOf(" ");
    var processName = processNameValue.substring(0, lastIndex);
     
     if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '3' 
     || document.getElementById("multilingual:entityTypeCombo").selectedIndex == '7')
         
      ShowPickList(reference,'WFWorkstepList','txtVarialeName',iDCtrl,hidNameCtrl,NoneType,NoneID,ReturnNoneText,FunctionName,Extra1,processName,Extra3,Extra4,Extra5,Extra6,Extra7,parentFlag,CustomRightsFlag);
      
      if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '4')
          
      ShowPickList(reference,type,'txtVarialeName','',hidNameCtrl,NoneType,NoneID,ReturnNoneText,FunctionName,Extra1,processName,iDCtrl,Extra4,Extra5,Extra6,Extra7,parentFlag,CustomRightsFlag);
      
      if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '5')
      ShowPickList(reference,'WFProcessList','txtVarialeName',iDCtrl,hidNameCtrl,NoneType,NoneID,ReturnNoneText,FunctionName,Extra1,Extra2,Extra3,Extra4,Extra5,Extra6,Extra7,parentFlag,CustomRightsFlag)  
     // ShowPickList(reference,'WFProcessList','txtVarialeName','',hidNameCtrl,NoneType,NoneID,ReturnNoneText,FunctionName,Extra1,processName,iDCtrl,Extra4,Extra5,Extra6,Extra7,parentFlag,CustomRightsFlag);
   
}


function checkMultiLingualAdd(ref)
    {
        
        if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '0')
        {
            alert(Please_select_entity_type);
            return false;
        } 
        if(document.getElementById("multilingual:EntityName").value == '')
            {
            alert(Please_select_entity_type);
            return false;
        }
        
        if(document.getElementById("multilingual:multilingualName").value == '')
            {
            alert(Please_ENTER_MULTILINGUAL_NAME);
            return false;
        }
        
        if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '3')
        {
            if(document.getElementById("multilingual:txtVarialeName").value == ''){
            alert(Please_select_Activity_Name);
            return false;
            }
            
        }
        
        if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '4')
        {
            if(document.getElementById("multilingual:txtVarialeName").value == ''){
            alert(Please_select_Variable_Name);
            return false;
            }
            
        }
        
        if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '5')
        {
          if(document.getElementById("multilingual:actionTypeCombo"))
           {
            if(document.getElementById("multilingual:actionTypeCombo").selectedIndex == '0'
            || document.getElementById("multilingual:actionTypeCombo").value == ''){
            alert(Please_select_Alias_Name);
            return false;
            }
           }
            
         if(document.getElementById("multilingual:aliasTypeCombo"))
           {
            if(document.getElementById("multilingual:aliasTypeCombo").selectedIndex == '0'
            || document.getElementById("multilingual:aliasTypeCombo").value == ''){
            alert(Please_select_Alias_Name);
            return false;
            }
          }
            
        }
        if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '6')
        {
            if(document.getElementById("multilingual:aliasTypeCombo").selectedIndex == '0'
            || document.getElementById("multilingual:aliasTypeCombo").value == ''){
            alert(Please_select_Document_Type);
            return false;
            }
            
        }
        if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '7')
        {
            if(document.getElementById("multilingual:actionTypeCombo").selectedIndex == '0'
            || document.getElementById("multilingual:actionTypeCombo").value == ''){
            alert(Please_select_Action_Name);
            return false;
            }
            
        }
        if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '8')
        {
            if(document.getElementById("multilingual:aliasTypeCombo").selectedIndex == '0'
             || document.getElementById("multilingual:aliasTypeCombo").value == ''){
            alert(Please_select_Exception_Type);
            return false;
            }
            
        }
        
    var selIndex = document.getElementById("multilingual:localeCombo").selectedIndex;
    var localeVal = document.getElementById("multilingual:localeCombo")[selIndex].value;
    try 
        {
     rowCount=document.getElementById("multilingual:multilingualGrid").rows.length ;
     for (var iCount=0;iCount < (rowCount-1) ;iCount++)
    {
           var localeTxtID="multilingual:multilingualGrid:"+iCount+":txtLocalName";
		   
                    if(Trim(document.getElementById(localeTxtID).innerHTML)==Trim(localeVal))
                    {
                        alert("Record with same locale already exists");
                        return false;
                     }    
    }    
}
catch(e)
            {
}
      return true;
    }
    
    function checkBoxMultiVar(nodeChkBox)
    {
     var rowCount =0;
     rowCount = document.getElementById("multilingual:multilingualGrid").rows.length;		
        var flag = false;
        var iCount = 0 ;
        if(rowCount > 0)
            {
                for(iCount = 0 ; iCount < (rowCount-1) ; iCount++)
                {
                    if(document.getElementById("multilingual:multilingualGrid:"+iCount+":chkBoxMulti").checked)
                    {
                        flag =true;
                        break;
                     }
                }
             }
                
                if(flag == true)
                {
                    document.getElementById("multilingual:hidselIndex").value = iCount;
                }
                else
                {
                    alert(Please_select_row_to_remove);
                    return false;
                }               
                    
                return true;    
               
            }
            
            
             function getMultiLingualMapping()
            {    
              if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '3'
              || document.getElementById("multilingual:entityTypeCombo").selectedIndex == '4'){                  
                 picklist = 'WFProcessList';    
                 if(document.getElementById("multilingual:txtVarialeName"))
                        document.getElementById("multilingual:txtVarialeName").value = '';
              }
              
              else if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '5' 
               && document.getElementById("multilingual:EntityName").value != 'My Queue' ){
                clickLink('multilingual:cmdlink_getAlias');
                } 
                else if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '6'){
                clickLink('multilingual:cmdlink_getDocumentType');
                } 
                else if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '8'){
                clickLink('multilingual:cmdlink_getExceptionList');
                } 
              else if(document.getElementById("multilingual:entityTypeCombo").selectedIndex != '7'){
                clickLink('multilingual:cmdlink_Go');
                }
                
            }
            
            function getMultiLingualVariableMap()
            {
                if(document.getElementById("multilingual:aliasTypeCombo"))
                    {
                        var selectedIndex = document.getElementById("multilingual:aliasTypeCombo").selectedIndex;
                        document.getElementById("multilingual:hidVarProcessName").value =document.getElementById("multilingual:aliasTypeCombo")[selectedIndex].text;
                    }
                if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '7'){
                clickLink('multilingual:cmdlink_getAction');
                }
                else if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '5'){
                clickLink('multilingual:cmdlink_getAlias');
                }
                else
                clickLink('multilingual:cmdlink_Go');
            }
            
            function onChangeCombo()
            {
                if(document.getElementById("multilingual:aliasTypeCombo"))
                    {
                        var selectedIndex = document.getElementById("multilingual:aliasTypeCombo").selectedIndex;
                        document.getElementById("multilingual:hidVarProcessName").value =document.getElementById("multilingual:aliasTypeCombo")[selectedIndex].text;
                    }
                    
                if(document.getElementById("multilingual:actionTypeCombo"))
                    {
                        var selectedIndex = document.getElementById("multilingual:actionTypeCombo").selectedIndex;
                        document.getElementById("multilingual:hidVarProcessName").value =document.getElementById("multilingual:actionTypeCombo")[selectedIndex].text;
                    }
                if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '7'){
                clickLink('multilingual:cmdlink_getAction');
                }
                else
                clickLink('multilingual:cmdlink_Go');
            }



function isIE(){
    var UAString = navigator.userAgent;
    return ((navigator.appName == 'Netscape') & !(UAString.indexOf("Trident") !== -1 && UAString.indexOf("rv:11") !== -1) ? false : true);
}

function getIEVersion()
// Returns the version of Windows Internet Explorer or a -1
// (indicating the use of another browser).
{
   var rv = -1; // Return value assumes failure.
   var UAString = navigator.userAgent;
   if ((navigator.appName == 'Microsoft Internet Explorer') || (UAString.indexOf("Trident") !== -1 && UAString.indexOf("rv:11") !== -1))
   {
      if(navigator.appName == 'Microsoft Internet Explorer'){
      var ua = navigator.userAgent;
      var re  = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
      if (re.exec(ua) != null)
         rv = parseFloat( RegExp.$1 );
      } else
         rv = 11;
   }
   return rv;
}
function disCutCopyPaste(e){
    var keyCode = e.keyCode || e.charCode; 
    if(e.ctrlKey && (keyCode=='67' || keyCode=='86' || keyCode=='88'))
    {
            var evt = e ? e:window.event;
            if (evt.stopPropagation)
            {
                evt.stopPropagation();
                evt.preventDefault();
            }
            if (evt.cancelBubble!=null || evt.cancelBubble!=true)
            {
                evt.cancelBubble = true;
                evt.returnValue = false;
            }
        return false;
    }
} 
            
function openMessageAttributeScreen(fieldId,userName,personalName)
{
    var url = "../workitem/attributeMessage.faces";
    url = appendUrlSession(url);
    
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=250;
    var WindowWidth=400;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

    var listParam=new Array();
    listParam[0]=new Array("FieldId",fieldId);
    listParam[1]=new Array("UserName",userName);
    listParam[2]=new Array("PersonalName",personalName);
    var winName="AttributeDescription"+UniqueUserId;
    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;
    var win = openNewWindow(url,winName,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    win.focus();
    
    try
    {
        addWindows(win);
    }
    catch(e){}
}
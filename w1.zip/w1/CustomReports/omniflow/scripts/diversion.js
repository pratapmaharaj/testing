/*-----------------------------------------------------------------------------------------------------

File Name			: diversion.js
Author                          : Sachin Agrawal
Date written (DD/MM/YYYY)       : 9/Feb/2007
Description			: This file contains the methods for handling the events from diversion page.
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date(DD/MM/YYYY)		Change By               Change Description (Bug No. (If Any))
----------------------------------------------------------------------------------------------------
26/04/2007                      vijay Kumar              Bug no-657(verify function changed)
1/05/2007                       Arup Sharma              BUG ID 675 (VerifyDelete())
----------------------------------------------------------------------------------------------------*/

function Verify(ref,deleteflag,Exuserid)
{	
        var FromDay = document.getElementById("diversions:cmbFromDay").options[document.getElementById("diversions:cmbFromDay").selectedIndex].value;
	var FromMonth = document.getElementById("diversions:cmbFromMonth").options[document.getElementById("diversions:cmbFromMonth").selectedIndex].value;
	var FromYear = document.getElementById("diversions:cmbFromYear").options[document.getElementById("diversions:cmbFromYear").selectedIndex].value;
	var ToDay = document.getElementById("diversions:cmbToDay").options[document.getElementById("diversions:cmbToDay").selectedIndex].value;
	var ToMonth = document.getElementById("diversions:cmbToMonth").options[document.getElementById("diversions:cmbToMonth").selectedIndex].value;
	var ToYear = document.getElementById("diversions:cmbToYear").options[document.getElementById("diversions:cmbToYear").selectedIndex].value;
       //bug no-657 begin
        var currentTime = new Date();
        var month = currentTime.getMonth() + 1;
        var day = currentTime.getDate();
        var year = currentTime.getFullYear();

	if(!VerifyDate(FromYear,FromMonth,FromDay))
            {
                alert(INVALID_FROM_DATE);
                return false;
            }
           
        if(!VerifyDate(ToYear,ToMonth,ToDay))
            {
                alert(INVALID_TO_DATE);
                return false ;    
            }
                

                 var f_date = new Date(FromYear,FromMonth-1,FromDay);
                var t_date = new Date(ToYear,ToMonth-1,ToDay);
             if(f_date>t_date)
                {
                    alert(DATE_VALIDATION_MSG_3);
                    document.getElementById("diversions:cmbToDay").focus();
                    document.getElementById("diversions:cmbToDay").blur();
                    return false;
                }
                else if(new Date(FromYear,FromMonth-1,FromDay) < new Date(year,month-1,day))
                 {
                    alert(DATE_VALIDATION_MSG_4);
                    document.getElementById("diversions:cmbFromDay").focus();
                    document.getElementById("diversions:cmbFromDay").blur();
                    return false;
                 }    
         
            else if(new Date(ToYear,ToMonth-1,ToDay) < Date(year,month-1,day))
                 {
                    alert(DATE_VALIDATION_MSG_5);
                    document.getElementById("diversions:cmbToDay").focus();
                    document.getElementById("diversions:cmbToDay").blur();
                    return false;
                 }

	var ToDate = ToYear + "-" + ToMonth +"-"+ToDay + " 23:59:59";
	var FromDate = FromYear + "-" + FromMonth +"-"+FromDay + " 00:00:00";
        
        var username= document.getElementById('diversions:txtUserName').value;
        if(Trim(username).length <=0)
        {
            alert(SELECT_USER);
            return false;
        }
        
        var userid = document.getElementById('diversions:hidUserId').value;

        if(Trim(userid).length <=0)
        {
            alert(SELECT_USER);
            document.getElementById('diversions:txtUserName').value = "";
            return false;
        }
        
        if(Exuserid==userid)
        {
            alert(SELECT_ANOTHER_USER);
            return false;
        }

        if(deleteflag=='true')
            return confirm(CONFIRM_DIVERSION_DELETE);
            
        return true;
	
}


function VerifyDelete(ref,deleteflag)
{
    //BUG ID 675
     if(deleteflag=='true')
	{
            if(confirm(CONFIRM_DIVERSION_DELETE))
		ClickAnotherLink(ref,'del');
	}
 }




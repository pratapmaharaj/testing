/*-----------------------------------------------------------------------------------------------------

File Name			: report.js
Author                          : vijay Kumar
Date written (DD/MM/YYYY)       : 10/May/2007
Description			: This file contains the method for printing a report.
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date(DD/MM/YYYY)		Change By               Change Description (Bug No. (If Any))
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/
function PrintThisPage()
{
	var WindowHeight=window1H;
	var WindowWidth=window1W + 10;
	var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
	var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
	var WindowHeight=window1H;
	var WindowWidth=window1W + 200;
var popup = window.open('','popup'+UniqueUserId,'resizable=yes,scrollbars=yes,width='+WindowWidth+',height='+WindowHeight+',left='+WindowLeft+',top='+WindowTop);

popup.document.write("<html dir="+HTML_DIR+"><head><title>");
popup.document.write(document.getElementById("titlename").value);
popup.document.write("</title>");
popup.document.write("<link href='../omniflow/"+localizedPath+"css/docstyle.css'"+"rel='stylesheet' type='text/css' >");
popup.document.write("</head><body >");
popup.document.write("<Table align ='center'  width='100%' ><TR><TD  class='PMWIDTH20LEFT'>");

popup.document.write("<img src='../omniflow/"+localizedPath+"images/logo.gif' alt='Process Manager' width='125' />");
popup.document.write("</TD><TD class='PMWIDTH60CENTER'> ");

popup.document.write("<span id='PgHeading1' class='PMLabelGreenBold'>");
popup.document.write(document.getElementById("titlename").value);
popup.document.write("</span>");
popup.document.write("</TD><TD class='PMWIDTH20RIGHT'>");
popup.document.write("&nbsp");
popup.document.write("</TD></TR></TABLE>");
popup.document.write("<Table align ='center' border='0' cellpadding='0' cellspacing='0' width='100%' ><TR><TD align='center' valign='top' width='100%' >");

try{
popup.document.write("<div id='Top_info'>");
popup.document.write(document.getElementById("Top_info").innerHTML);    
popup.document.write("</div>");
popup.document.write("</TD></TR><TR><TD align='left' valign='top' width='100%'  class='PMLabel1'>");
popup.document.write(CRITERIA);
popup.document.write("</TD></TR><TR><TD align='left' valign='top' width='100%'  >");
popup.document.write(" <br>");
popup.document.write("</TD></TR><TR><TD align='center' valign='top' width='100%' >");
}
catch(ex)
	{}

try
{    //in case of audit log
        var selectedTab=document.getElementById("AuditLogFilter:SelTab").value;
        popup.document.write(" <br>");
        popup.document.write("</TD></TR><TR><TD align='center' valign='top' width='100%' >");
        popup.document.write("<Table align ='left'  width='100%' ><TR><TD  class='PMWIDTH100'>");
        popup.document.write("<Table align ='left'  width='100%'>");
        popup.document.write("<TR><TD align='left' valign='top' width='100%'  class='PMLabelGreenBold'>");
        popup.document.write(CRITERIA);
        popup.document.write("</TD></TR></TABLE>");
        popup.document.write("</TD></TR></TABLE>");
        popup.document.write("</TD></TR><TR><TD align='left' valign='top' width='100%'  >");
       
    if(selectedTab==1)
    {
        popup.document.write("<Table align ='left'  width='100%' ><TR><TD  class='PMWIDTH15'>");
        popup.document.write("<Table align ='left'  width='100%'>");
        popup.document.write("<TR><TD align='left' valign='top' width='100%'  class='EWLabel1'>");
        popup.document.write(document.getElementById("AuditLogFilter:lblQueueName").innerHTML+SYMBOL_3);
        popup.document.write("</TD></TR></TABLE>");
        popup.document.write("</TD><TD class='PMWIDTH85'>");
        popup.document.write("<Table align ='left'  width='100%'>");
        popup.document.write("<TR><TD align='left' valign='top' width='100%'  class='PMControlText'>");
        popup.document.write(document.getElementById("AuditLogFilter:QueueName").value);
        popup.document.write("</TD></TR></TABLE>");
        popup.document.write("</TD></TR></TABLE>");
        popup.document.write("</TD></TR><TR><TD align='left' valign='top' width='100%' >");  //main table

    }
    else if(selectedTab==2)
    {
        popup.document.write("<Table align ='left'  width='100%' ><TR><TD  class='PMWIDTH15'>");
        popup.document.write("<Table align ='left'  width='100%'>");
        popup.document.write("<TR><TD align='left' valign='top' width='100%'  class='EWLabel1'>");
        popup.document.write(document.getElementById("AuditLogFilter:lblProcessName").innerHTML+SYMBOL_3);
        popup.document.write("</TD></TR></TABLE>");
        popup.document.write("</TD><TD class='PMWIDTH85'>");
        popup.document.write("<Table align ='left'  width='100%'>");
        popup.document.write("<TR><TD align='left' valign='top' width='100%'  class='PMControlText'>");
        popup.document.write(document.getElementById("AuditLogFilter:ProcessName").value);
        popup.document.write("</TD></TR></TABLE>");
        popup.document.write("</TD></TR></TABLE>");
        popup.document.write("</TD></TR><TR><TD align='center' valign='top' width='100%' >");  //main table
    }
    else if(selectedTab==3)
    {
        popup.document.write("<Table align ='left'  width='100%' ><TR><TD  class='PMWIDTH15'>");
        popup.document.write("<Table align ='left'  width='100%'>");
        popup.document.write("<TR><TD align='left' valign='top' width='100%'  class='EWLabel1'>");
        popup.document.write(document.getElementById("AuditLogFilter:lblUserName").innerHTML+SYMBOL_3);
        popup.document.write("</TD></TR></TABLE>");
        popup.document.write("</TD><TD class='PMWIDTH85'>");
        popup.document.write("<Table align ='left'  width='100%'>");
        popup.document.write("<TR><TD align='left' valign='top' width='100%'  class='PMControlText'>");
        popup.document.write(document.getElementById("AuditLogFilter:UserName").value);
        popup.document.write("</TD></TR></TABLE>");
        popup.document.write("</TD></TR></TABLE>");
        popup.document.write("</TD></TR><TR><TD align='center' valign='top' width='100%' >");  //main table
    }
    else if(selectedTab==4)
    {
        popup.document.write("<Table align ='left'  width='100%' ><TR><TD  class='PMWIDTH15'>");
        popup.document.write("<Table align ='left'  width='100%'>");
        popup.document.write("<TR><TD align='left' valign='top' width='100%'  class='EWLabel1'>");
        popup.document.write(document.getElementById("AuditLogFilter:lblUserNameCab").innerHTML+SYMBOL_3);
        popup.document.write("</TD></TR></TABLE>");
        popup.document.write("</TD><TD class='PMWIDTH85'>");
        popup.document.write("<Table align ='left'  width='100%'>");
        popup.document.write("<TR><TD align='left' valign='top' width='100%'  class='PMControlText'>");
        popup.document.write(document.getElementById("AuditLogFilter:UserName_Cab").value);
        popup.document.write("</TD></TR></TABLE>");
        popup.document.write("</TD></TR></TABLE>");
        popup.document.write("</TD></TR><TR><TD align='center' valign='top' width='100%' >");  //main table
        
    }
  
        popup.document.write("<Table align ='center'  width='100%' ><TR><TD  class='PMWIDTH15'>");
        popup.document.write("<Table align ='left' width='100%'>");
        popup.document.write("<TR><TD align='left' valign='top' width='100%'  class='EWLabel1'>");
        popup.document.write(document.getElementById("AuditLogFilter:lblDateRange").innerHTML+"  "+SYMBOL_3);
        popup.document.write("</TD></TR></TABLE>");
        popup.document.write("</TD><TD class='PMWIDTH85'>");
        popup.document.write("<Table align ='center'  width='100%'>");
        popup.document.write("<TR><TD align='left' valign='top' width='100%'  class='PMControlText'>");
        popup.document.write(document.getElementById("AuditLogFilter:cmbFromDay").value+DATESEPARATOR+document.getElementById("AuditLogFilter:cmbFromMonth").value+DATESEPARATOR+document.getElementById("AuditLogFilter:cmbFromYear").value);
        popup.document.write("     "+document.getElementById("AuditLogFilter:lblTo").innerHTML+"  "+document.getElementById("AuditLogFilter:cmbToDay").value+DATESEPARATOR+document.getElementById("AuditLogFilter:cmbToMonth").value+DATESEPARATOR+document.getElementById("AuditLogFilter:cmbToYear").value);
        popup.document.write("</TD></TR></TABLE>");
        popup.document.write("</TD></TR></TABLE>");
        popup.document.write("</TD></TR><TR><TD align='center' valign='top' width='100%' >");  //main table

        popup.document.write("<Table align ='center'  width='100%' ><TR><TD  class='PMWIDTH15'>");
        popup.document.write("<Table align ='center'  width='100%'>");
        popup.document.write("<TR><TD align='left' valign='top' width='100%'  class='EWLabel1'>");
        popup.document.write(document.getElementById("AuditLogFilter:lblOperation").innerHTML+SYMBOL_3);
        popup.document.write("</TD></TR></TABLE>");
        popup.document.write("<TD class='PMWIDTH85'>");
        popup.document.write("<Table align ='center'  width='100%'>");
        popup.document.write("<TR><TD align='left' valign='top' width='100%'  class='PMControlText'>");
        var typeindex=document.getElementById("AuditLogFilter:cmbOperations").selectedIndex;
        valReportType=document.getElementById("AuditLogFilter:cmbOperations").options[typeindex].text
        popup.document.write(valReportType);
        popup.document.write("</TD></TR></TABLE>");
        popup.document.write("</TD></TR></TABLE>");
        popup.document.write("</TD></TR><TR><TD align='center' valign='top' width='100%' >");  //main table
    
}catch(ex)
{}
try{
popup.document.write("<div id='Middle_info'>");
popup.document.write(document.getElementById("Middle_info").innerHTML);
popup.document.write("</div>");
popup.document.write("</TD></TR><TR><TD align='center' valign='top' width='100%' >");
}
catch(ex)
	{}
popup.document.write("<div id='Bottom_info'>");
popup.document.write(document.getElementById("Bottom_info").innerHTML);
popup.document.write("</div>");
popup.document.write("</TD></TR>");
popup.document.write("</TD></TR></TABLE>");
popup.document.write("</body></html>");
popup.document.close();
popup.print();
popup.close();
}

function handleEnter(e,formId)
                {                      
                    var browser=navigator.appName;
                    if(browser=="Netscape")
                    {

                               if(e.which == 13)
                               {       

                                    try
                                    {
                                        document.getElementById(formId+':cmdClose').focus();
                                    }
                                    catch(e){
                                    }

                               }
                      }

                      else
                         {      
                            e=window.event;
                            if(e.keyCode == 13)
                                {
                                    try
                                    {
                                        document.getElementById(formId+':cmdClose').focus();
                                    }
                                    catch(e){
                                    }
                                }

                         }
                }
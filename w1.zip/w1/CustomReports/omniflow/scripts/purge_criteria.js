/**************************************************************************************************************

		File            :       purge_criteria.js
		Purpose         :       Contains the functions for purge criteria.

		Change History  :

		Problem No              Correction Date   Changed By		Comments
		-----------             ----------------  ----------      -----------------
                PRM_8.0_037             27/01/2010        Puneet Pahuja   window.open changed to openNewWindow to open new window using HTTP POST
                12262                   15/3/2010         Himshikha       Select/deselect header check box if all checkboxex of processes get select/deselect
                Bug 12264               15/3/2010         Himshikha       (Select/deselect header check box if all checkboxex of filters get select/deselect)
                Bug 12264(Reopened)     15/3/2010         Puneet Pahuja   (Select/deselect header check box if all checkboxex of filters get select/deselect)
		Bug 29564               13/12/2011        Sri Prakash     Purge Criteria List Window Issues
                Bug 41528               27/07/2013        Jaseem Ansari   Date Picker required in Export Purge
                Bug 42644       25/11/2013          Jaseem Ansari       Need to provide an option in advanced search window to search on Export cabinet.
                13/10/2014              13/10/2014      Jaseem Ansari           Bug 50833 - If Click on added purge criteria, window is not getting opened while if right click on link, window is getting opened
*/
function setThenclick(ref,toClick)
{
    var selId = document.getElementById("textForm:d:cmbPvariables").selectedIndex;
    var val = document.getElementById("textForm:d:cmbPvariables").options[selId].value;
    document.getElementById("textForm:d:hidSelQueryVar").value = val;
   var rowcount = document.getElementById("textForm:d:advFilterTable").rows.length;


    if(!document.getElementById("textForm:chkWiData").checked){
        document.getElementById("textForm:hidchkWiData").value="N";
        document.getElementById("textForm:hidchkExtData").value="N";
        document.getElementById("textForm:hidchkDocData").value="N";
    }
    else
    {
        document.getElementById("textForm:hidchkWiData").value="Y";
        if(document.getElementById("textForm:chkExtData").checked)
            document.getElementById("textForm:hidchkExtData").value="Y";
        else
            document.getElementById("textForm:hidchkExtData").value="N";

        if(document.getElementById("textForm:chkDocData").checked)
            document.getElementById("textForm:hidchkDocData").value="Y";
        else
            document.getElementById("textForm:hidchkDocData").value="N";
    }






   /* if(!document.getElementById("textForm:chkPurgeWiData").checked)
			document.getElementById("textForm:hidPurgeWiData").value="N";
	if(!document.getElementById("textForm:chkPurgeDocData").checked)
			document.getElementById("textForm:hidPurgeDocData").value="N";
	if(!document.getElementById("textForm:chkExportWiData").checked)
			document.getElementById("textForm:hidExportWiData").value="N";
	if(!document.getElementById("textForm:chkExportDocData").checked)
			document.getElementById("textForm:hidExportDocData").value="N";*/
   if(rowcount==1)
    document.getElementById("textForm:d:hidJoinCondition").value = "N";
   else if(rowcount>1)
    document.getElementById("textForm:d:hidJoinCondition").value = "Y";


  try{
    document.getElementById("textForm:hidCheckedStates").value = "";
    document.getElementById("textForm:hidCheckedStates").value = "chkBoxPurge="+ document.getElementById("textForm:chkBoxPurge").checked + "&chkPurgeWiData="+ document.getElementById("textForm:chkPurgeWiData").checked +"&chkPurgeDocData="+ document.getElementById("textForm:chkPurgeDocData").checked +"&chkExport="+ document.getElementById("textForm:chkExport").checked +"&chkExportWiData="+ document.getElementById("textForm:chkExportWiData").checked +"&chkExportDocData="+ document.getElementById("textForm:chkExportDocData").checked ;
  }catch(ex){;}
    ClickAnotherLink(ref,toClick);
}

function SelectCheckBoxes(ref)
{
    var formid=ref.form.id;
    var tableid=formid+':d:advFilterTable';

    try
    {
        var noofrows = document.getElementById(tableid).rows.length;

        var flag=0;
        for (var i=0;i< noofrows-1 ;i++)
        {

            var id=tableid+':'+i+':chkFilter';
            document.getElementById(id).checked=ref.checked;
        }

        return '';
    }
    catch(e)
    {
        //alert(e);
        return "";
    }
}
function SelectCheckBoxesPurgeList(ref)
{
    var formid=ref.form.id;
    var tableid=formid+':purgeLists';

    try
    {
        var noofrows = document.getElementById(tableid).rows.length;

        var flag=0;
        for (var i=0;i< noofrows-1 ;i++)
        {

            var id=tableid+':'+i+':chkBox';
            document.getElementById(id).checked=ref.checked;
        }

        return '';
    }
    catch(e)
    {
        //alert(e);
        return "";
    }
}
function checkRowData(ref,toClick)
{


  try{
    document.getElementById("textForm:hidCheckedStates").value = "";
    document.getElementById("textForm:hidCheckedStates").value = "chkBoxPurge="+ document.getElementById("textForm:chkBoxPurge").checked + "&chkPurgeWiData="+ document.getElementById("textForm:chkPurgeWiData").checked +"&chkPurgeDocData="+ document.getElementById("textForm:chkPurgeDocData").checked +"&chkExport="+ document.getElementById("textForm:chkExport").checked +"&chkExportWiData="+ document.getElementById("textForm:chkExportWiData").checked +"&chkExportDocData="+ document.getElementById("textForm:chkExportDocData").checked ;

  }catch(ex){;}

    var tableID = 'textForm:d:advFilterTable';
    var table = document.getElementById(tableID);

    var rowCount = 0;
    var chkBoxID=tableID+":";
    var currentChkBoxID="";
    var noOfSelectedRows=0;
    var selectedIndexes="";
    var submitFlag = false;
    rowCount = table.rows.length;


   if(!document.getElementById("textForm:chkWiData").checked){
       document.getElementById("textForm:hidchkWiData").value="N";
       document.getElementById("textForm:hidchkExtData").value="N";
       document.getElementById("textForm:hidchkDocData").value="N";
   }
   else
       {
           document.getElementById("textForm:hidchkWiData").value="Y";
        if(document.getElementById("textForm:chkExtData").checked)
            document.getElementById("textForm:hidchkExtData").value="Y";
        else
            document.getElementById("textForm:hidchkExtData").value="N";

        if(document.getElementById("textForm:chkDocData").checked)
            document.getElementById("textForm:hidchkDocData").value="Y";
        else
            document.getElementById("textForm:hidchkDocData").value="N";
       }
    if(rowCount <= 1)
    {
        submitFlag = false;
        return false;
    }
    else
    {

        for (var iCount=0;iCount < (rowCount-1) ;iCount++)
        {
                currentChkBoxID=chkBoxID + iCount +":chkFilter" ;
                try
                {
                        if(document.getElementById(currentChkBoxID).checked)
                        {
                                noOfSelectedRows++;
                                if(selectedIndexes.length > 0)
                                        selectedIndexes=selectedIndexes + ":"+ iCount ;
                                else
                                        selectedIndexes = iCount +"";

                         }


                }
                catch(e)
                {
                    selectedIndexes ="";
                    noOfSelectedRows=0;
                }
        }
    }

    if(noOfSelectedRows == 0)
    {
        alert(SEL_FIELD_TO_DELETE);
        submitFlag = false;
        return false;
    }
    else
    {
        submitFlag = true;
        document.getElementById("textForm:d:hidSelvarList").value = selectedIndexes;
    }
    if(submitFlag == true)
        ClickAnotherLink(ref,toClick);

}
function GetTitles(thisEle,Type)//checked
{
	var strTitle;
	var strType = Type.substring(2);
	switch(strType)
	{
		case "10":
			strTitle = INSERT_STR_VAL;
			break;
		case "B":
			strTitle = INSERT_BOOL_VAL;
			break;
		case "8":
			tempDteFormat = DateFormat;
			strTitle = INSERT_DATE_VAL+" '"+DateFormat+"'";
			break;
		case "3":
			strTitle = INSERT_INT_VAL;
			break;
		case "6":
			strTitle = INSERT_DEC_VAL;
			break;
		case "T":
			strTitle = INSERT_RAW_VAL;
			break;
		case "4":
			strTitle = INSERT_INT_VAL;
			break;
		default:
	}
		thisEle.title = strTitle;
                if(strType=="8")
                    setDate(thisEle,strType);
}
function setDate(thisEle,Type){
    var strType = Type.substring(2);
    var id = thisEle.id
    var len = id.length;
    var substr1 = id.substring(26,len);
    var ipos = substr1.substring(0,substr1.indexOf(":"));
   var a="#textForm\\:d\\:advFilterTable\\:"+ipos+"\\:procfilterData";
   var dtpickerformat = convertTodatePickerFormat(DateFormat);
   $(a  ).datepicker({ dateFormat: dtpickerformat }).val();
  //$(a).datepicker();
   /*  $(function() {
     $(id2).datepicker();
   }); */
}
function clickCommandLink()
    {
     var i,selectedOperation;
     var isIE=(navigator.appName.indexOf("Microsoft") != -1)?true:false;
    if(isIE){
        for( i=1; i<document.getElementsByName("textForm:chkOperation").length;i++)
            {
                if(document.getElementsByName("textForm:chkOperation")[i].checked)
                    selectedOperation = document.getElementsByName("textForm:chkOperation")[i].value;
            }
    }
    else{
          for( i=0; i<document.getElementsByName("textForm:chkOperation").length;i++)
            {
                if(document.getElementsByName("textForm:chkOperation")[i].checked)
                    selectedOperation = document.getElementsByName("textForm:chkOperation")[i].value;
            }
    }

        if(Trim(document.getElementById("textForm:hidQueryWS").value)=="N" && selectedOperation=="E")
        {
            alert("Query worksterp is not associated to the process")
            return false;
        }
       try{
       document.getElementById("textForm:hidCheckedStates").value = "";
       document.getElementById("textForm:hidCheckedStates").value = "chkBoxPurge="+ document.getElementById("textForm:chkBoxPurge").checked + "&chkPurgeWiData="+ document.getElementById("textForm:chkPurgeWiData").checked +"&chkPurgeDocData="+ document.getElementById("textForm:chkPurgeDocData").checked +"&chkExport="+ document.getElementById("textForm:chkExport").checked +"&chkExportWiData="+ document.getElementById("textForm:chkExportWiData").checked +"&chkExportDocData="+ document.getElementById("textForm:chkExportDocData").checked ;
       } catch(ex){;}
        var ref = document.getElementById("textForm");
        if(CheckDataAndCreateXMLs(ref))
        {
            ClickAnotherLink(ref,'saveQuery');
            return true;
        }
        else
            return false;

    }
function CheckDataAndCreateXMLs(ref)
{

      //validate inputs for Purge data
        if(!ValidateProcessData())
            return false;

        if(!createDataXML())
			return false;
    return true;
}
function createDataXML()
{
    var tmpFieldList = "";
    var strTempXml = "";
    var strData ="";

    var prefix ="textForm:d:";
    var txtForm = document.getElementById("textForm");
    var stradvsearch="N";
    var tablePrefix="";
    var entryFlag=false;
     stradvsearch="Y";
     tablePrefix = prefix+"advFilterTable";
    var rowCount = -1;
    rowCount = document.getElementById(tablePrefix).rows.length;

   /*if(document.getElementById("textForm:chkExport").checked)
	{
                document.getElementById("textForm:hidExportFlag").value="Y";
		strData+= appendTagAndValue("WorkitemData",document.getElementById("textForm:chkExportWiData").checked?"Y" :"N");
		strData+= appendTagAndValue("Documents",document.getElementById("textForm:chkExportDocData").checked?"Y" :"N");
		strData = appendTagAndValue("ExportCriteria",strData);
	}
        else
        {
        document.getElementById("textForm:hidExportFlag").value="N";
        }

    strTempXml += appendTagAndValue("WorkitemData",document.getElementById("textForm:chkPurgeWiData").checked?"Y" :"N");
    strTempXml += appendTagAndValue("Documents",document.getElementById("textForm:chkPurgeDocData").checked?"Y" :"N");*/

        var i,selectedOperation;
     var isIE=(navigator.appName.indexOf("Microsoft") != -1)?true:false;
    if(isIE){
        for( i=1; i<document.getElementsByName("textForm:chkOperation").length;i++)
            {
                if(document.getElementsByName("textForm:chkOperation")[i].checked)
                    selectedOperation = document.getElementsByName("textForm:chkOperation")[i].value;
            }
    }
    else{
          for( i=0; i<document.getElementsByName("textForm:chkOperation").length;i++)
            {
                if(document.getElementsByName("textForm:chkOperation")[i].checked)
                    selectedOperation = document.getElementsByName("textForm:chkOperation")[i].value;
            }
    }

if(selectedOperation=="E" || selectedOperation=="EP")
	 document.getElementById("textForm:hidExportFlag").value="Y";
	 else
	  document.getElementById("textForm:hidExportFlag").value="N";


    strTempXml +=appendTagAndValue("Mode",selectedOperation);

    strTempXml += appendTagAndValue("WorkitemData",document.getElementById("textForm:chkWiData").checked?"Y" :"N");
    strTempXml += appendTagAndValue("ExternalData",document.getElementById("textForm:chkExtData").checked?"Y" :"N");
    strTempXml += appendTagAndValue("Documents",document.getElementById("textForm:chkDocData").checked?"Y" :"N");
    strTempXml =appendTagAndValue("Criteria",strTempXml);;
 

    if(rowCount > 1)
    {
        var iCount=0;

        var varvalue="";
        for(iCount=0 ; iCount < (rowCount-1) ; iCount++)
        {
            var varname = document.getElementById(tablePrefix+":"+iCount+":VarName").innerHTML;
            var vartype = document.getElementById(tablePrefix+":"+iCount+":VarType").value;
            var varlength = document.getElementById(tablePrefix+":"+iCount+":VarLength").value;
            var varoperator="";
            var varjoincond="";
            var varopenparenthesis="";
            var varcloseparenthesis="";
            var selIndex = -1;
            var strXML ="";

                varvalue = document.getElementById(tablePrefix+":"+iCount+":procfilterData").value;
                if(document.getElementById(tablePrefix+":"+iCount+":procfilterData").value=="")
                {
                    alert(BLANK_FIELD_VALUE);
					 return false;
                }
                selIndex = document.getElementById(tablePrefix+":"+iCount+":advCmbOperator").selectedIndex;
                varoperator = document.getElementById(tablePrefix+":"+iCount+":advCmbOperator").options[selIndex].value;
                if(iCount!=0)
                {
                    selIndex = document.getElementById(tablePrefix+":"+iCount+":advCmbJoin").selectedIndex;
                    varjoincond = document.getElementById(tablePrefix+":"+iCount+":advCmbJoin").options[selIndex].value;
                 }
                selIndex = document.getElementById(tablePrefix+":"+iCount+":openparaenthesis").selectedIndex;
                varopenparenthesis = document.getElementById(tablePrefix+":"+iCount+":openparaenthesis").options[selIndex].value;
                 selIndex = document.getElementById(tablePrefix+":"+iCount+":closeparaenthesis").selectedIndex;
                varcloseparenthesis = document.getElementById(tablePrefix+":"+iCount+":closeparaenthesis").options[selIndex].value;
                if(Trim(varvalue)=='')
                    entryFlag = true;

            if(vartype.substring(2, vartype.length) == '8' && varvalue != '')
            {
                varvalue = LocalToDB(varvalue,DateFormat);
            }

               if(varopenparenthesis!="")
               strXML = strXML + appendTagAndValue("OpenBracket","Y");
               else
               strXML = strXML + appendTagAndValue("OpenBracket","N");

                strXML = strXML + appendTagAndValue(VarName,varname);
                strXML = strXML + appendTagAndValue(VarType,vartype);
                strXML = strXML + appendTagAndValue(Length,varlength);
                strXML = strXML + appendTagAndValue(VarValue,varvalue);
                strXML = strXML + appendTagAndValue(Operator,varoperator);
                if(varcloseparenthesis!="")
                strXML = strXML + appendTagAndValue("CloseBracket","Y");
                else
                strXML = strXML + appendTagAndValue("CloseBracket","N");
                if(iCount!=0)
                strXML = strXML + appendTagAndValue(JoinCondition,varjoincond);

                 tmpFieldList += appendTagAndValue("Field",strXML);
         }
         if(tmpFieldList != "")
		strTempXml += appendTagAndValue("Fields",tmpFieldList);
        }
      strData += strTempXml;
   
     document.getElementById("textForm:hidDataXML").value=strData;
     document.getElementById("textForm:hidProcessName").value=document.getElementById("textForm:txtProcessName").value;
     document.getElementById("textForm:hidCriteriaName").value=document.getElementById("textForm:txtCriteriaName").value;

     document.getElementById("textForm:d:hidOperation").value = document.getElementById("textForm:d:hidOperation").value;

	return true;
    }

function appendTagAndValue(tagName,tagValue)
{
    var tagAndValue="";
	tagValue=tagValue.toString();
	tagValue=tagValue.replace(/\n|\r/g, "");
    if(tagValue != "")
        tagAndValue = "<" + tagName + ">" + Trim(tagValue) + "</" + tagName + ">";
    return tagAndValue;
}
function ValidateProcessData()
{
    var prefix ="textForm:d:";
    var tablePrefix="";
    var criCount="";
    if(window.opener.document.getElementById("purgemgt:purgeLists"))
	{
	criCount=window.opener.document.getElementById("purgemgt:purgeLists").rows.length;
	}
	else{
	criCount=0;
	}
    if(criCount>0)
    {
        var iCnt = 0;
        for(iCnt=0;iCnt<criCount-1;iCnt++)
        {
            if(document.getElementById("textForm:txtCriteriaName").value==window.opener.document.getElementById("purgemgt:purgeLists:"+iCnt+":criName").value)
            {
                alert(PURGING_CRITERIA_EXISTS);
                document.getElementById("textForm:txtCriteriaName").value="";
                return false;
            }
        }
    }
    tablePrefix = prefix+"advFilterTable";

      if(document.getElementById("textForm:txtCriteriaName").value == "")
	{
		alert(BLANK_CRITERIA_NAME);
		return false;
	}
      if((ISExport != "true") && !document.getElementById("textForm:chkPurgeWiData").checked && !document.getElementById("textForm:chkPurgeDocData").checked)
        {
		alert(SELECT_ONE_PURGE_OPTION);
		return false;
	}
    var rowCount = -1;
    rowCount = document.getElementById(tablePrefix).rows.length;
    var elementId="";
    var varvalue="";
    if(rowCount > 1)
    {
        var iCount=0;
        for(iCount=0 ; iCount < (rowCount-1) ; iCount++)
        {
            var varname = document.getElementById(tablePrefix+":"+iCount+":VarName").innerHTML;
            var vartype = document.getElementById(tablePrefix+":"+iCount+":VarType").value;
				vartype = vartype.substring(2);
            var varlength = document.getElementById(tablePrefix+":"+iCount+":VarLength").value;
               varvalue = document.getElementById(tablePrefix+":"+iCount+":procfilterData").value;
               elementId = tablePrefix+":"+iCount+":procfilterData";

            if(Trim(varvalue)!='')
              {
                  if(vartype == '3')
                   {
                       if(!IsNumericVal(varvalue))
                         {
                            alert(INVALID_NUMERIC_VALUE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                         }
                        else if (varvalue<-Math.pow(2,31) || varvalue>(Math.pow(2,31)-1))
                        {
                            alert(INDEX_VALUE_OUT_OF_RANGE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                        }
                    }
                else if(vartype == '4')
                {
                    if(!IsNumericVal(varvalue))
                    {
                            alert(INVALID_NUMERIC_VALUE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
                    else if (varvalue<-Math.pow(2,31) || varvalue>(Math.pow(2,31)-1))
                    {
                            alert(INDEX_VALUE_OUT_OF_RANGE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
                }
                else if(vartype == '6')
                {
                    if(isNaN(varvalue))
                    {
                            alert(INVALID_NUMERIC_VALUE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
                    else if (varvalue< parseFloat("-1.79e+308") || varvalue> parseFloat("+1.79e+308"))
                    {
                            alert(INDEX_VALUE_OUT_OF_RANGE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
                }
                else if(vartype == '8' && varvalue != '')
                {
                    var ret = ValidateDateFormat(varvalue,DateFormat);
                    if(ret==0)
                    {
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
               }
            else if(vartype == '10')
            {
                    if ( (varvalue.indexOf('\u00ff') != -1) || (varvalue.indexOf('\u00fc') != -1) ||(varvalue.indexOf('\u00b5') != -1) || (varvalue.indexOf('<') != -1) || (varvalue.indexOf('>') != -1) )
                    {
                            alert(INVALID_STRING);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
            }
          } // if Trim
      } // for loop ends
    } //rowCount > 1

    return true;

}//fucn ends

function setPurgeWiOption()
{
	if(document.getElementById("textForm:chkPurgeWiData").checked)
	{

		if(document.getElementById("textForm:chkExport").checked)
			document.getElementById("textForm:chkExportWiData").disabled=false;

	}
	else
	{
		document.getElementById("textForm:chkExportWiData").checked = false;
		document.getElementById("textForm:chkExportWiData").disabled=true;

	}
}

function setPurgeDocOption()
{
	if(document.getElementById("textForm:chkPurgeDocData").checked)
	{
		if(document.getElementById("textForm:chkExport").checked)
			document.getElementById("textForm:chkExportDocData").disabled=false;
	}
	else
	{
		if(!ISExport)
                {
                    document.getElementById("textForm:chkExportDocData").checked = false;
                    document.getElementById("textForm:chkExportDocData").disabled= true;
                }
        }
}


function setExportOptions()
{

	if(document.getElementById("textForm:chkExport").checked)
	{
	    document.getElementById("textForm:chkExportWiData").checked = true;
		document.getElementById("textForm:chkExportWiData").disabled = true;

	/*	if(document.getElementById("textForm:chkPurgeWiData").checked)
		{
			document.getElementById("textForm:chkExportWiData").disabled = false;
			document.getElementById("textForm:chkExportWiData").checked = true;
		}
		*/
		if(document.getElementById("textForm:chkPurgeDocData").checked || ISExport)
                {
			document.getElementById("textForm:chkExportDocData").disabled = false;
                        document.getElementById("textForm:chkExportDocData").checked = true;
                 }
	}
	else
	{
		document.getElementById("textForm:chkExportWiData").checked = false;
		document.getElementById("textForm:chkExportWiData").disabled = true;

		document.getElementById("textForm:chkExportDocData").checked = false;
		document.getElementById("textForm:chkExportDocData").disabled = true;
	}
}
function chkPurge()
{
     if(!document.getElementById("textForm:chkBoxPurge").checked){
        document.getElementById("textForm:hidPurgeWiData").value="N";
        document.getElementById("textForm:chkPurgeWiData").checked=false;
        document.getElementById("textForm:chkPurgeWiData").disabled=true;
        document.getElementById("textForm:hidPurgeDocData").value="N";
        document.getElementById("textForm:chkPurgeDocData").checked=false;
        document.getElementById("textForm:chkPurgeDocData").disabled=true;
        }
     else
     {
        document.getElementById("textForm:hidPurgeWiData").value="Y";
        document.getElementById("textForm:chkPurgeWiData").checked=true;
        document.getElementById("textForm:chkPurgeWiData").disabled=true;
        document.getElementById("textForm:chkPurgeDocData").checked=true;
        document.getElementById("textForm:chkPurgeDocData").disabled=false;
     }
}
function viewPurgeCriteria(ProcessDefId, ProcessName, Version, CriteriaName)
{

    var Url="../processmgmt/purgecriteria.faces";
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("operation",encode_ParamValue("U")));
    listParam.push(new Array("processdefid",encode_ParamValue(ProcessDefId)));
    listParam.push(new Array("procName",encode_ParamValue(ProcessName)));
    listParam.push(new Array("version",encode_ParamValue(Version)));
    listParam.push(new Array("criteriaName",encode_ParamValue(CriteriaName)));

    var win = openNewWindow(Url,"purgecriteria"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
            addWindows(win);
    }
    catch(e)
    {}
    return false;
}
function AddPurgeCriteria()
{
    var formID="purgemgt";
    var pidlist= new Array();
    var tableID=formID+":"+"purgeLists";
    //var chkboxName=":chkBox";
    var noOfSelectedRows=0;
    var processID="";
    var processName="";
    try
    {
        var rowCount=document.getElementById(tableID).rows.length ;
        var processIDId;
        var processNameId;
        var name;
        for (var iCount=0;iCount < (rowCount-1) ;iCount++)
        {
                //currentChkBoxID=tableID+":" + iCount +chkboxName ;
                processIDId=tableID+":" + iCount +":ProcessDefId";
                name = tableID+":" + iCount +":ProcessDefId";
                //processNameId=tableID+":" + iCount +":procName";
                pidlist +=document.getElementById(processIDId).value+",";
        }
     }
     catch(e)
     {
                 //alert("Error in=="+iCount);
      }
     var Url="../processmgmt/purgecriteria.faces";
     Url = appendUrlSession(Url);
     var ScreenHeight=screen.height;
     var ScreenWidth=screen.width;
     var WindowHeight=window1H;
     var WindowWidth=window1W;
     var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
     var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

     var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

     var listParam=new Array();
     listParam.push(new Array("operation",encode_ParamValue("I")));
     listParam.push(new Array("pidList",encode_ParamValue(pidlist)));

     var win = openNewWindow(Url,"purgecriteria"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
     try
     {
        addWindows(win);
     }
     catch(e)
     {}
}
function DeletePurgeCriteria(ref, toClick)
{
    var formID="purgemgt";
    var sPidList='' ;

    var tableID=formID+":"+"purgeLists";
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;
    var processID="";
    var processName="";

    try
    {
    var rowCount=document.getElementById(tableID).rows.length ;
    var processIDId;
    var processNameId;
    var operation;
    var name;

    for (var iCount=0;iCount < (rowCount-1) ;iCount++)
    {
            currentChkBoxID=tableID+":" + iCount +chkboxName ;
            processIDId=tableID+":" + iCount +":ProcessDefId";
            operation = tableID+":" + iCount +":Operation";
            if(document.getElementById(currentChkBoxID).checked)
            {
            sPidList +=document.getElementById(processIDId).value+",";

            document.getElementById("purgemgt:hidOperation").value="D";
            }

    }
    }
    catch(e)
            {
                            //alert("Error in=="+iCount);
            }

    if(sPidList == "")
    {
            alert(SELECT_CRITERIA_TO_DELETE);
            return false;
    }

    var bConfirm = confirm(CONFIRM_PURGE_DELETE);
    if(!bConfirm)
            return false;

    sPidList = sPidList.substring(0,sPidList.length -1);
    document.getElementById("purgemgt:pidList").value=sPidList;
    document.getElementById("purgemgt:hidOperation").value = "D";
    ClickAnotherLink(ref,toClick);

}

function clickPurgeChk(){
    var tableID = "purgemgt:purgeLists";
    var chkboxName=":chkBox";
    var chkCount = 0;
    try{
	var rowCount=document.getElementById(tableID).rows.length ;
        for (var iCount=0;iCount < (rowCount-1) ;iCount++)
        {
            currentChkBoxID=tableID+":" + iCount +chkboxName ;
            if(document.getElementById(currentChkBoxID).checked)
                chkCount++;
        }

        if(chkCount < rowCount-1)
            document.getElementById("purgemgt:purgeLists:headerChk").checked = false;
        else if(chkCount == rowCount-1)
            document.getElementById("purgemgt:purgeLists:headerChk").checked = true;
    }catch(e){}
}

function clickFilterHeadrChk(){
    var tableID = 'textForm:d:advFilterTable';
    var chkboxName=":chkFilter";
    var chkCount = 0;
    try{
	var rowCount=document.getElementById(tableID).rows.length ;
        for (var iCount=0;iCount < (rowCount-1) ;iCount++)
        {
            currentChkBoxID=tableID+":" + iCount +chkboxName ;
            if(document.getElementById(currentChkBoxID).checked)
                chkCount++;
        }

        if(chkCount < rowCount-1)
            document.getElementById("textForm:d:advFilterTable:chkHdrFilter").checked = false;
        else if(chkCount == rowCount-1)
            document.getElementById("textForm:d:advFilterTable:chkHdrFilter").checked = true;
    }catch(e){}
}
function setExpDataOption()
{

	if(document.getElementById("textForm:chkWiData").checked)
        {

          document.getElementById("textForm:chkExtData").disabled=false;
          document.getElementById("textForm:chkDocData").disabled=false;
        }
        else
        {
        document.getElementById("textForm:chkDocData").checked=false;
        document.getElementById("textForm:chkExtData").checked=false;
        document.getElementById("textForm:chkExtData").disabled = true;

        document.getElementById("textForm:chkDocData").disabled=true;
    }
}
function convertTodatePickerFormat(sDateFormat){
        var sDateSeparator=DATESEPARATOR;
        var strChar1=sDateFormat.substring(0,sDateFormat.indexOf(sDateSeparator));
	var strChar2=sDateFormat.substring(sDateFormat.indexOf(sDateSeparator)+1,sDateFormat.lastIndexOf(sDateSeparator));
	var strChar3=sDateFormat.substring(sDateFormat.lastIndexOf(sDateSeparator)+1,sDateFormat.length);


        strChar1=strChar1.toUpperCase();
	strChar2=strChar2.toUpperCase();
	strChar3=strChar3.toUpperCase();
        var strtemp1;
        var strtemp2;
        var strtemp3;
        var strResult;


        if ((strChar1=="D")||(strChar1=="DD"))
	{
		strtemp1='d';
	}
	else if((strChar1=="M")||(strChar1=="MM"))
	{
		strtemp1='m'
	}
	else
	{
		strtemp1='yy';
	}

	if ((strChar2=="D")||(strChar2=="DD"))
	{
		strtemp2='d';
	}
	else if((strChar2=="MM")||(strChar2=="MMM"))
	{
		if (strChar2=="MMM")

            strtemp2='M';
        else
            strtemp2='m';
	}

	if((strChar3=="D")||(strChar3=="DD"))
	{
		strtemp3='d'
	}
	else
		strtemp3='yy';
        strResult=strtemp1+sDateSeparator+strtemp2+sDateSeparator+strtemp3;
       return  strResult;
}
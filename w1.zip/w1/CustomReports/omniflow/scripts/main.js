/*-----------------------------------------------------------------------------------------------------

File Name			: main.js
Author                          : Puneet Pahuja
Date written (DD/MM/YYYY)       : 08/Oct/2007
Description			: This file contains the methods for handling the main page.
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date(DD/MM/YYYY)		Change By               Change Description (Bug No. (If Any))
26/02/2008                      Puneet Pahuja           bug id-3719
09/07/2008                      Puneet Satija           bug id-5683
13/01/2009                      Vijay Kumar             Bug Id-7634
24/06/2009                      Vijay Kumar             PRM_8.0_009(Security Issue)
06 Aug 2008                     Arup Sharma             BUG ID PRM_8.0_014 (For BAM Reports integration)
25/01/2010                      Vijay Kumar             PRM_8.0_037  back refresh attack.
18/02/2011                      Sri Prakash             PRM_9.0_004  User link coming disabled in Process Manager's Statistics section
15/06/2011                      Sri Prakash             Bug 27251   Required SetDiversion option in webdesktop  
 * 23/08/2011      Anushree Jain	Bug 27971 Security issue
22/04/2013                      Prince Kumar            Bug 39008    Requirement of Multiple custom link in Process manager
14/08/2013            			Dinkar         			Bug 41790 - Screen for specifying names of processes,queues,activities,variables, aliases in multiple locales for multilingual functionality.
01/10/2013            			Dinkar         			Bug 41790 - Screen for specifying names of processes,queues,activities,variables, aliases in multiple locales for multilingual functionality.
Bug 46906       10/07/2014      Jaseem Ansari              - All the request in omniflow containing wd_uid as a parameter should be sent as a post request

----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------*/


/*************************function returns xmlHttp object***********************************/
function createXMLHttpRequest() {
   try { return new ActiveXObject("Msxml2.XMLHTTP"); } catch (e) {}
   try { return new ActiveXObject("Microsoft.XMLHTTP"); } catch (e) {}
   try { return new XMLHttpRequest(); } catch(e) {}
   alert("XMLHttpRequest not supported");
   return null;
 }



/*************************function for making ajax call***********************************/

function makeAjaxCall(url,target,indicatorid,onloadfunction)
{
    //bug id-3719
    try
     {
     closeWindows();
     }
     catch(e){}
     //bug id-3719
    var url=appendUrlSessionAjax(url);
    var param = "";
    if(url.indexOf("?")>0)
	{
		url=url + "&sid="+ Math.random();
                var firstIndes=url.lastIndexOf("?");         
                param=url.substring(firstIndes+1,url.length);
                url= url.substring(0,firstIndes);

	}
	else
	{
		//url=url + "?sid="+ Math.random();
                param="sid="+ Math.random();
	}
     var xhReq = createXMLHttpRequest();
     createIndicator(indicatorid);
    xhReq.open("POST", url, false);
    xhReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhReq.onreadystatechange = onResponse;
     xhReq.send(param);
  

    function onResponse()
        {
        if (xhReq.readyState==4)
            {
                if (xhReq.status==200)
                    { 
                        var returnxml=xhReq.responseText;
                        var error = "PM_ERROR_PAGE_12345_DIV";
                        if(returnxml.indexOf(error)>0)
                        {
                            try{
                                var errorMsg=returnxml.substring(returnxml.indexOf(error) + error.length,returnxml.length);
                                errorMsg=errorMsg.substring(errorMsg.indexOf(">")+1,errorMsg.indexOf("</Div>"));
                                if(errorMsg.length>0)
                                    alert(errorMsg);
                                else
                                    alert(SESSION_TIMEDOUT);
                                
                            }catch(ex) {
                                alert(SESSION_TIMEDOUT);
                            }
                        }
                        else
                        {
                        document.getElementById(target).innerHTML=returnxml;
                        if(onloadfunction.length>0)
                            {
                                try
                                {
                                eval(onloadfunction);
                                }
                                catch(e){
                                }
                            }
                        }

                    }
                    else
                    {
                        alert(ERROR_FETCHING_DATA);
                    }
                    removeIndicator(indicatorid);
                }   
            }
}
 
function mainOnLoad()
{
    makeAjaxCall("../application/statistics.faces?Opt=0&PM_UID="+pm_uid,"Statistics","stats",'');
    makeAjaxCall("../admin/adminmain.faces?PM_UID="+pm_uid,"AdminOptions","admoptn",'');
   
    if(typeof bBAMReports!='undefined' && bBAMReports == 'true')
    {
        var launchCustomReportsUrl = "/bam/login/login.jsp?CalledFrom=EXT&AjaxRequest=Y&UserId="+encode_utf8(userName)+"&UserIndex="+userIndex+"&SessionId="+sessionId+"&ServerIP="+encode_utf8(serverIp)+"&ServerPort="+encode_utf8(serverPort)+"&ServerType="+encode_utf8(serverType)+"&CabinetName="+encode_utf8(cabinetName)+"&CabType="+encode_utf8(cabinetType)+"&Encoding="+encode_utf8(encoding)+"&PM_UID="+pm_uid;
        if(bEnableTimeZone == 'true')
            launchCustomReportsUrl = launchCustomReportsUrl + "&ClientTZDiff="+iClientTimeDiff;
         
        var BAMSession = new net.ContentLoader(launchCustomReportsUrl,BAMSessionCallBack,null,"GET","",'',true);
    }
    else
    {
        makeAjaxCall("../reports/reportmain.faces?LinkId=-1&Action=1&PM_UID="+pm_uid,"Reports","reports",'');
    }
    statistics('q');
    var menuobj=document.getElementById? document.getElementById("describe") : document.all? document.all.describe : document.layers? document.dep1.document.dep2 : ""
     //alert("menuobj="+menuobj);
     convertIT('myMenuID');
}

function BAMSessionCallBack()
{
    var returnxml=this.req.responseText;                        
    var error = "PM_ERROR_PAGE_12345_DIV";
    
    if(returnxml.indexOf(error)>0)
    {
        try
        {
            var errorMsg=returnxml.substring(returnxml.indexOf(error) + error.length,returnxml.length);
            errorMsg=errorMsg.substring(errorMsg.indexOf(">")+1,errorMsg.indexOf("</Div>"));
            if(errorMsg.length>0)
                alert(errorMsg);
            else
                alert(SESSION_TIMEDOUT);

        }catch(ex) 
        {
            alert(SESSION_TIMEDOUT);
        }
    }
    else
    {
        if(returnxml.toUpperCase() == "SUCCESS")
        {
            makeAjaxCall("../reports/reportmain.faces?LinkId=-1&Action=0&PM_UID="+pm_uid,"Reports","reports",'');
        }
        else if(returnxml.toUpperCase() == "FAILED")
        {   
            // do not load the Report List
        }
    }
}

function statistics(view)
{
    if(view=='q')
    {
        var Url= "../queueview/queueviewlist.faces?Action=q&PM_UID="+pm_uid;
        makeAjaxCall(Url,"ResultContainer","resultind",'');
    }
    if(view=='p')
    {
        var Url= "../processview/processviewlist.faces?Action=p&PM_UID="+pm_uid;
        makeAjaxCall(Url,"ResultContainer","resultind",'');
    }
    if(view=='u' || view=='u1')
    { 
        if(view=='u')
        var Url= "../userview/userviewlist.faces?Action=u&userType=s&PM_UID="+pm_uid;
        else
        var Url= "../userview/userviewlist.faces?Action=u&userType=n&PM_UID="+pm_uid;
        makeAjaxCall(Url,"ResultContainer","resultind",'');
    }
}


var strQSGeneralXML="";
var strQSDataXML="";
var bInvalid=false;
function getQuickSearchResult()
{
    var xml = createQuickSearchXML();

    if(bInvalid)
    {
        return false;
    }
    var Url= "../search/quicksearchresult.faces?from=quicksearch&GeneralXML="+encode_utf8(strQSGeneralXML)+"&DataXML="+encode_utf8(strQSDataXML)+"&Action=1&PM_UID="+pm_uid;
    //alert("xml "+Url);    
    makeAjaxCall(Url,"ResultContainer","resultind",'FetchQuickSearchResult()');
}

function createQuickSearchXML()
{
    var strXML="";
    var aliaseValue=document.getElementById("txtVariableValue").value;
    var selId = document.getElementById("cmbAliases").selectedIndex;
    
    if(selId > -1 )
    {
        
        var selValues = document.getElementById("cmbAliases").options[selId].value;
        
        var arr = selValues.split(":");
        
        //varify the data
        if(verifyQuickSearchData(aliaseValue,arr[4]))
        {
            bInvalid = false;
            strXML = strXML + appendTagAndValue(ProcessDefinitionID,arr[0]);
            strXML = strXML + appendTagAndValue(State,2);
            strXML = strXML + appendTagAndValue(ProcessName,arr[1]);

            strQSGeneralXML = strXML;

            strXML = "";

            strXML = strXML + "<QueryList>";
                strXML = strXML + appendTagAndValue(AdvanceSearch,'N');

                strXML = strXML + "<QueryInfo>";
                    strXML = strXML + appendTagAndValue(VarName,arr[2]);
                    strXML = strXML + appendTagAndValue(Length,arr[3]);
                    strXML = strXML + appendTagAndValue(VarType,arr[4]);
                    if(arr[4]=='8' || arr[4]=='15'){
                        aliaseValue=LocalToDB(aliaseValue,DateFormat)
                        if(arr[4]=='15')
                            aliaseValue=aliaseValue.substring(0,aliaseValue.indexOf(" "));
                      }

                        strXML = strXML + appendTagAndValue(VarValue,aliaseValue);
                    var strVarType=arr[4];
                    var strOperator="3";
                    if(strVarType == '10' && aliaseValue.length !=0 && aliaseValue.indexOf('\u002A') != -1)
                    {
                        strOperator = "7";          //if * is present in search operator is like whose value is 7. bug id-3900
                    }
                    strXML = strXML + appendTagAndValue(Operator,strOperator);
                    strXML = strXML + appendTagAndValue(JoinCondition,'AND');
                strXML = strXML + "</QueryInfo>";

            strXML = strXML +"</QueryList>";

            strQSDataXML = strXML;
        }
        else
        {
            document.getElementById("txtVariableValue").focus();
            document.getElementById("txtVariableValue").select();
            bInvalid = true;
        }

    }
    
}

 function FetchQuickSearchResult()
    {
      ClickAnotherLink('','cmdlink_FetchFirst');
      return false;
    }

function FetchAgain()
{
	ClickAnotherLink('','cmdlink_FetchAgain');
}


function verifyQuickSearchData(varvalue,vartype)
{
                
        if(Trim(varvalue)!='')
          {
              if(vartype == '3')
               {
                   if(!IsNumericVal(varvalue))
                     {
                        alert(INVALID_NUMERIC_VALUE);
                        return false;
                     }
                    else if (varvalue<-Math.pow(2,31) || varvalue>(Math.pow(2,31)-1))
                    {
                        alert(INDEX_VALUE_OUT_OF_RANGE);
                        return false;
                    }
                }
            else if(vartype == '4')
            {
                if(!IsNumericVal(varvalue))
                {
                        alert(INVALID_NUMERIC_VALUE);
                        return false;
                }
                else if (varvalue<-Math.pow(2,31) || varvalue>(Math.pow(2,31)-1))
                {
                        alert(INDEX_VALUE_OUT_OF_RANGE);
                        return false;
                }
            }
            else if(vartype == '6')
            {
                if(isNaN(varvalue))
                {
                        alert(INVALID_NUMERIC_VALUE);
                        return false;
                }
                else if (varvalue< parseFloat("-1.79e+308") || varvalue> parseFloat("+1.79e+308"))
                {
                        alert(INDEX_VALUE_OUT_OF_RANGE);
                        return false;
                }
            }   
            else if(vartype == '8' && varvalue != '')
            {
                var ret = ValidateDateFormat(varvalue,DateFormat);
                if(ret==0)
                {
                        return false;
                }
           }
          else if(vartype == '10')
          {
                if ( (varvalue.indexOf('\u00ff') != -1) || (varvalue.indexOf('\u00fc') != -1) ||(varvalue.indexOf('\u00b5') != -1) || (varvalue.indexOf('<') != -1) || (varvalue.indexOf('>') != -1) )
                {
                        alert(INVALID_STRING);
                        return false;
                }
         }
    
         if(vartype=='12')
          { 
                var ret="false";
                if(!(varvalue.toLowerCase()=="true" || varvalue.toLowerCase()=="false"))
                    ret="true";
                 if(ret=="true")
                 {
                     alert(INSERT_BOOL_VAL);
                     return false;
                  }
            }
         if(vartype=='15')
          { 
                var ret="false";
                varvalue = Trim(varvalue);
                if(varvalue.indexOf(" ") != -1){
                    alert(INVALID_DATE);
                    return 0;
                 }
                else
                    return ValidateDateFormat(varvalue,DateFormat);
               if(ret!="1")
                 {

                     return false;
                 }
        }
        if(vartype=='16')
          { 
               var ret="false";
               ret= ValidateTime(varvalue);
               if(ret!="1")
                 {

                     return false;
                 }
        }
    }
    return true;
}

/*----------------------------------------------------------------------------------------------------
//Function Name:		refreshQSVList
//Date Written 	:		18,jan 2008
//Author	:		Vijay Kumar
//Input Parameters:             none
//Output Parameters:            none
//Return Values	: 
//Description:			refresh the Quick search variable list on main page
----------------------------------------------------------------------------------------------------*/
function refreshQSVList()
{
  try            
    {
       if(document.getElementById("quicksearch:hidRefreshQSVList").value=="true")
         {
            var cmbQSVList = document.getElementById("cmbAliases");
            var opLength = cmbQSVList.length;
            for(iCount=(opLength-1);iCount >= 0 ; iCount--)			
            {
                    cmbQSVList.remove(iCount);
            }

            var rowCount;
            try
            {
                rowCount=document.getElementById("quicksearch:qsearch").rows.length ;
            }
            catch(e)
            {
                rowCount=0;
            }
            if(rowCount>0)
            {
                for (var iCount=0;iCount <(rowCount-1) ;iCount++)
                {
                  try 
                    {
                       var LabelId="quicksearch:qsearch:"+ iCount +":hidQSValiasName";
                       var  ValueId="quicksearch:qsearch:"+ iCount +":hidQSVComplexId";
                       var  opName=document.getElementById(LabelId).value;
                       var  opValue=document.getElementById(ValueId).value;

                       cmbQSVList.options[iCount] = new Option(opName,opValue);
                    }
                    catch(e)
                    {
                        // alert("Error in=="+iCount);
                    }
                }
                try 
                {
                    cmbQSVList.options[0].selected=true;
                    document.getElementById('cmdGo').disabled=false;
                    document.getElementById('txtVariableValue').disabled=false;
                }
                catch(e){}
             }
             else
             {
                try
                {
                    cmbQSVList.options[0] = new Option(QS_NO_ALIAS_FOUND,"a");
                    document.getElementById('cmdGo').disabled=true;
                    document.getElementById('txtVariableValue').value="";
                    document.getElementById('txtVariableValue').disabled=true;
                }
                catch(e){}
             }
        }
   }catch(e){}
}

function checkSession()
{
        var Url = "../WFGetSessionTimeout";
        var handlar = new net.ContentLoader(Url,getResult,null,"GET","");
        function getResult()
        {
            var returnxml=this.req.responseText;
            if(returnxml.length>0)
            {
                if((returnxml-0)>0)
                {
                    clearTimeout(SessionCheckTimer);
                    SessionCheckTimer= setTimeout("checkSession()",((returnxml-0)*1000));
                }
                else if((returnxml-0)==0)
                {
                     //window.location.reload();
                     window.location.href=window.top.location.href;
                }
            }
        }
}
function statisticsDiversion(view) {
    if(view=='q') {
        var Url= "../queueview/queueviewlist.faces?Action=q&PM_UID="+pm_uid;
        makeAjaxCall(Url,"ResultContainer","resultind",'');
    }
    if(view=='p') {
        var Url= "../processview/processviewlist.faces?Action=p&PM_UID="+pm_uid;
        makeAjaxCall(Url,"ResultContainer","resultind",'');
    }
    if(view=='u') {
        var Url= "../userview/usersetdiversion.faces?Action=u&fromAdmin=Y&PM_UID="+pm_uid;
        makeAjaxCall(Url,"ResultContainer","resultind",'');
    }
}
function OpenUrl(url,name,displayName)
{
    //if(!customClick(decode_utf8(displayName)))
    
     //   return;
     //alert("url = "+url);
      // alert("name = "+name);
       //  alert("displayName = "+displayName);
    //url = url.replace('\\','\\\\');
    var src = url;
    //theChildCount++;
   // alert("url = "+url);
    //  alert("src = "+src);
    url = getActionUrlFromURL(src);
    url = appendUrlSession(url);

    var wFeatures = 'resizable=yes,scrollbars=yes,width='+(window1W)+',height=320,left='+window1Y+',top='+window1X;

    var listParam=new Array();
    listParam = getInputParamListFromURL(src);
    openNewWindow(url,name,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);


//url = appendUrlSession(url);
//theChild[theChildCount] = window.open(url,name,'resizable=yes,scrollbars=yes,width='+window1W+',height=320,left='+window1Y+',top='+window1X);

}

 function onEntityTypeChange(){
//            if(document.getElementById("multilingual:aliasTypeCombo"))
//                {
//                        document.getElementById("multilingual:aliasTypeCombo").selectedIndex = '0';
//                }
            clickLink('multilingual:cmdlink_comboChange');
          if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '1')
              {
              picklist = 'WFProcessList';
              }
          else if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '2')
              {
              picklist = 'WFQueueList';
              }
          else if((document.getElementById("multilingual:entityTypeCombo").selectedIndex == '4')
          ||(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '3'))
              {
             //   document.getElementById("multilingual:lblEntityName").innerHTML = 'Process Name';
              picklist = 'WFProcessList';
              }
            else if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '5')
                {
             //       document.getElementById("multilingual:lblEntityName").innerHTML = 'Queue Name';
              picklist = 'WFQueueList';
                }
                else if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '6')
                {
             //       document.getElementById("multilingual:lblEntityName").innerHTML = 'Queue Name';
              picklist = 'WFProcessList';
                }
                else if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '7')
                {
             //       document.getElementById("multilingual:lblEntityName").innerHTML = 'Queue Name';
              picklist = 'WFProcessList';
                }
                 else if(document.getElementById("multilingual:entityTypeCombo").selectedIndex == '8')
                {
             //       document.getElementById("multilingual:lblEntityName").innerHTML = 'Queue Name';
              picklist = 'WFProcessList';
                }
              
             // document.getElementById("multilingual:EntityName").value = '';
       }
       
            
       function refreshMultiLingualList()
       {
           clickLink('multilingual:cmdlink_Refresh');
       }
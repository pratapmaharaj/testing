/*-----------------------------------------------------------------------------------------------------

File Name			: view.js
Author                          : Sachin Agrawal
Date written (DD/MM/YYYY)       : 15/Jan/2007
Description			: This file contains the methods for handling the events from views (queue,process and user).
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date(DD/MM/YYYY)		Change By               Change Description (Bug No. (If Any))
----------------------------------------------------------------------------------------------------
21/04/2007                  Arup Sharma                 BUG 550 (session id appended in all the window.open url's by calling method :appendUrlSession())
27/04/2007                  Arup Sharma                 BUGG 654 (ShowSearchFromUserView() )
26/02/2008                  Puneet Pahuja               bug id-3719
18/03/2009                  Bhupesh Kumar               PRM_8.0_001 Need to add a Custom Link in ProcessManager and call custom jsp files for maintaining master Interfaces.
PRM_8.0_037       27/01/2010    Puneet Pahuja                   window.open changed to openNewWindow to open new window using HTTP POST
22/04/2013		    Prince Kumar		Bug 39008	Requirement of Multiple custom link in Process manager
06/01/2015                  Dinesh Verma                Bug 58531 - Unable to open JSP through Custom Link
----------------------------------------------------------------------------------------------------*/
function SelectTab(iTabIndex)
{
    var hidAction = '';
    if(iTabIndex=='1')
    {
        hidAction = 'q';
        document.getElementById("ViewTabs:q:hid_selectedqueue").value='1';
        document.getElementById("ViewTabs:q:hidProcessId").value='';
        document.getElementById("ViewTabs:q:hidProcessName").value=AllProcesses;
    }
    else if(iTabIndex=='2')
    {
        hidAction = 'p';
        document.getElementById("ViewTabs:p:hidQueueId").value='0';
        document.getElementById("ViewTabs:p:hidQueueName").value=AllQueues;
    }
    else if(iTabIndex=='3')
    {
        hidAction = 'u';
        document.getElementById("ViewTabs:u:hidProcessID").value='';
        document.getElementById("ViewTabs:u:hidProcessName").value=AllProcesses;

        document.getElementById("ViewTabs:u:hidWorkstepID").value='';
        document.getElementById("ViewTabs:u:hidWorkstepName").value=AllWorksteps;

        document.getElementById("ViewTabs:u:hidGroupID").value='';
        document.getElementById("ViewTabs:u:hidGroupName").value=AllGroups;
    }
    document.getElementById("hidAction").value=hidAction;
    
    try
    {
        document.getElementById("ViewTabs:SelTab").value=iTabIndex;
    }
    catch(e){}
    
	document.forms["ViewTabs"].submit();
}

var ScreenHeight=screen.height;
var ScreenWidth=screen.width;


//purpose : function is called when the header chkBox is selected to check all the check boxes
function SelectAllCheckBoxUserView(ref)
{
    var formid=ref.form.id;
    var tableid=formid+':'+'userLists';
    try 
    {
        var noofrows = document.getElementById(tableid).rows.length;
        var flag=0;
        for (var i=0;i< noofrows-1 ;i++)
        {
            
            var id=tableid+':'+i+':chkUser';
            document.getElementById(id).checked=ref.checked;
        }
        
        return '';
    }
    catch(e)
    {
        //alert(e);
        return "";
    }
}

function EnableDisableWorkstepButtonUserView()
{
     
    //alert("inside on change");
    if(document.getElementById('userview:hidProcessID').value > 0 )
    {
        document.getElementById('userview:cmdPicklist_workstep').disabled=false;
    }
    else
    {
        document.getElementById('userview:cmdPicklist_workstep').disabled=true;
    }

    document.getElementById('userview:hidWorkstepID').value=' ';
    document.getElementById('userview:hidWorkstepName').value=document.getElementById('userview:hidInitialWorkstep').innerHTML;
    document.getElementById('userview:txtWorkstepName').value=document.getElementById('userview:hidInitialWorkstep').innerHTML;
}

function SetWorkAudit(ref,id,addurl)
{
    var url='../usermgmt/setworkaudit.faces';
    url = appendUrlSession(url);

    var listParam=new Array();
    listParam=getSelected(ref);

    if(listParam.length==0)
    {
        alert(INVALID_SELECTION_MORE);
        return ;
    }
    
    var WindowHeight= window7H+10;
    var WindowWidth=  window7W;
    
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    
    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var win = openNewWindow(url,"swa"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
	addWindows(win);
    }
    catch(e)
    {}
}

function ViewWorkAudit(ref,addurl)
{
    url='../usermgmt/viewworkauditdetails.faces';
    url = appendUrlSession(url);
    
    var listParam=new Array();
    listParam=getSelected(ref);

    if(listParam.length==0)
    {
        alert(INVALID_SELECTION_MORE);
        return ;
    }


    var WindowHeight=window1H;
    var WindowWidth=window1W;
    
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);


    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var win = openNewWindow(url,'atq'+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
}


function AddToQueue(ref,addurl)
{
    url='../usermgmt/addusertoqueue.faces';
    url = appendUrlSession(url);

    var listParam=new Array();
    listParam=getSelected(ref);

    if(listParam.length==0)
    {
        alert(INVALID_SELECTION_MORE);
        return ;
    }

    
    var WindowHeight= window7H;
    var WindowWidth=  window7W;
    
    //var WindowHeight=270;
    //var WindowWidth=400;
    
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);


    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=auto,top='+WindowTop+',left='+WindowLeft;

    var win = openNewWindow(url,'atq'+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
	addWindows(win);
    }
    catch(e)
    {}
    
}

function SetDiversions(ref,id,addurl)
{
    url='../usermgmt/setdiversion.faces';
    url = appendUrlSession(url);
    
    var listParam=new Array();
    listParam=getSelected(ref);

    if(listParam.length==0)
    {
        alert(INVALID_SELECTION_MORE);
        return ;
    }
    
   //var WindowHeight=320;
    //var WindowWidth=410;
    
    var WindowHeight= window7H;
    var WindowWidth=  window7W;
    
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var win = openNewWindow(url,'sdvr'+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
	addWindows(win);
    }
    catch(e)
    {}
}

function getSelected(ref)
{
    var formid='userview';
    var tableid=formid+':'+'userLists';
    var userid="";
    var listParam=new Array();
    var username="";
    try {
        var noofrows = document.getElementById(tableid).rows.length;
        var flag=0;
        for (var i=0;i< noofrows-1 ;i++)
        {
            
            var id=tableid+':'+i+':chkUser';
            if(document.getElementById(id).checked)
            {
                if(flag!=0)
		{
                    userid+=",";
                    username+=",";                    
		}
		userid+=document.getElementById(tableid+':'+i+':usrID').value;
                username+=document.getElementById(tableid+':'+i+':usrName').value;
                flag++;
            }                
        }
        
        if(flag==0)
            return listParam;

        listParam.push(new Array("userid",encode_ParamValue(userid)));
        listParam.push(new Array("username",encode_ParamValue(username)));

        return listParam;
    }
    catch(e)
    {
        //alert(e);
        return listParam;
    }
}

function ShowSearchFromQueueView(queueID,queueName,delayflag)   //bug id-3719
{
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    
    var priority = "-1";
    var procId  = "";
    var procName = "";

    procId  = document.getElementById("queueview:hidProcessId").value;   
    procName = document.getElementById("queueview:hidProcessName").value;   
    
    var Url="../search/searchfromviews.faces";
    Url = appendUrlSession(Url);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=1,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("from",encode_ParamValue("Queueview")));
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("QueueName",encode_ParamValue(queueName)));
    listParam.push(new Array("ProcessId",encode_ParamValue(procId)));
    listParam.push(new Array("ProcessName",encode_ParamValue(procName)));
    listParam.push(new Array("Priority",encode_ParamValue(priority)));
    listParam.push(new Array("QueueId",encode_ParamValue(queueID)));
    listParam.push(new Array("delayflag",encode_ParamValue(delayflag)));
    
    var win = openNewWindow(Url,'SearchFromViews'+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }catch(e){}
}


function ShowSearchFromProcessView(procId,procName,state)           //bug id-3719
{
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    
    var priority = "-1";
    var queueId="";
    var queueName="";
    var procInsState="";
    
    queueId  = document.getElementById("processview:hidQueueId").value;   
    queueName = document.getElementById("processview:hidQueueName").value;   
    
    if(state == 'Enabled')
        procInsState="2";
    else
        procInsState="1";

    var Url="../search/searchfromviews.faces";
    Url = appendUrlSession(Url);

    var listParam=new Array();
    listParam.push(new Array("from",encode_ParamValue("Processview")));
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("QueueName",encode_ParamValue(queueName)));
    listParam.push(new Array("ProcessId",encode_ParamValue(procId)));
    listParam.push(new Array("ProcessName",encode_ParamValue(procName)));
    listParam.push(new Array("Priority",encode_ParamValue(priority)));
    listParam.push(new Array("QueueId",encode_ParamValue(queueId)));
    listParam.push(new Array("ProcInstanceState",encode_ParamValue(procInsState)));

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=1,top='+WindowTop+',left='+WindowLeft;

    var win = openNewWindow(Url,'SearchFromViews'+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);

    try
    {
        addWindows(win);
    }catch(e){}
}


function ShowSearchFromUserView(userName,from)              //bug id-3719
{
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    
    var priority = "-1";
    var procId="";
    var procName="";
    var actId="";
    var actName="";
    var userParam="";
    procId  = document.getElementById("userview:hidProcessID").value;   
    procName = document.getElementById("userview:hidProcessName").value;   
    
    actId  = document.getElementById("userview:hidWorkstepID").value;   
    actName = document.getElementById("userview:hidWorkstepName").value;   
    //BUG ID 654
    if(from == 'F')
        userParam = "FixedAssignedToUser";
    else if(from == 'S')
        userParam = "SystemAssignedToUser";
    else if(from == 'P')
    {
        userParam = "AssignedToUser";
    }
    var Url="../search/searchfromviews.faces";

    Url = appendUrlSession(Url);

    var listParam=new Array();
    listParam.push(new Array("from",encode_ParamValue("Userview")));
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("ProcessId",encode_ParamValue(procId)));
    listParam.push(new Array("ProcessName",encode_ParamValue(procName)));
    listParam.push(new Array("Priority",encode_ParamValue(priority)));
    listParam.push(new Array("ActivityId",encode_ParamValue(actId)));
    listParam.push(new Array("ActivityName",encode_ParamValue(actName)));
    listParam.push(new Array(userParam,encode_ParamValue(userName)));

    if(from == 'P')
        {        
        listParam.push(new Array("state",encode_ParamValue("6")));
        listParam.push(new Array("ProcessWorkitemDate",encode_ParamValue("Y")));
        }    
    //END    
    

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=1,top='+WindowTop+',left='+WindowLeft;

    var win = openNewWindow(Url,'SearchFromViews'+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }catch(e){}
}
function OpenCustomURl(Url,name,displayName)
{

    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    if(Url.indexOf('?')>-1){
        Url=Url+"&PM_UID="+pm_uid;
    }else{
         Url=Url+"?PM_UID="+pm_uid;
    }
    var win = window.open(Url,'CustomWindow'+UniqueUserId,'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=1,top='+WindowTop+',left='+WindowLeft);
    try
    {
        addWindows(win);
    }catch(e){}
    return false;
}
/*-----------------------------------------------------------------------------------------------------

File Name			: toolbar.js
Author                          : Ajith Jacob
Date written (DD/MM/YYYY)       : 09/Jan/2007
Description			: This file contains the methods for handling the buttons on the toolbar.
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date(DD/MM/YYYY)		Change By               Change Description (Bug No. (If Any))
----------------------------------------------------------------------------------------------------
18 April 2007               Puneet Pahuja               Bug id 543 (refresh function modified)
21/04/2007                  Arup Sharma                 BUG 550 (session id appended in all the window.open url's by calling method :appendUrlSession())
21/04/2007                  Arup Sharma                 BUG 542 (launchclient() window open)
2/05/2007                   Arup Sharma                 BUG 542 RE (launchLCient opened in center of screen)
24/05/2007                  Shruti Mishra               BUG ID 906
02/12/2008                  Vijay Kumar                 Bug Id  7089
25/01/2010                  Vijay Kumar                 PRM_8.0_037  back refresh attack.
PRM_8.0_037       27/01/2010    Puneet Pahuja                   window.open changed to openNewWindow to open new window using HTTP POST
23/08/2011      			Anushree Jain	  			Bug 27971 Security issue
08/12/2011                  Anushree Jain  				Bug 29509 - Provide Launch Bam link
28/01/2014                  Jaseem Ansari               Bug 42953  CSRF attack possible on logout page
03/02/2014                  Dinesh Verma                Bug 42992 - BAM and Process client are not opening concurrently
Bug 46906       10/07/2014      Jaseem Ansari              - All the request in omniflow containing wd_uid as a parameter should be sent as a post request
01/07/2014      Jaseem Ansari           Bug 46906   - All the request in omniflow containing wd_uid as a parameter should be sent as a post request
Bug 58800        27/01/2016         Wildfly +OF 10.3 SP-1 >> error "HTTP method POST is not supported by this URL" is showing in help window.
----------------------------------------------------------------------------------------------------*/
function LaunchClient()
{
       
        var ScreenHeight=screen.height;
	var ScreenWidth=screen.width;
	var WindowHeight=window1H;
	var WindowWidth=window1W;
	var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
	var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
        var launchClientUrl = getActionUrlFromURL(launchServerUrl);
        launchClientUrl = appendUrlSessionAjax(launchClientUrl);
        var listParam = getInputParamListFromURL(launchServerUrl);
        //BUG ID 542
        try{
            if(dcWebWindow!=null)
              {  
                dcWebWindow.close();
               }
           }
        catch(e)
        {}

        var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=0,scrollbars=1,top='+WindowTop+',left='+WindowLeft;

        var win = openNewWindow(launchClientUrl,"web"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
       	dcWebWindow=win;
	try
        {
            addLaunchWindows(win);
        }
        catch(e)
        {}
}

function LaunchBam()
{

        var ScreenHeight=screen.height;
	var ScreenWidth=screen.width;
	var WindowHeight=window1H;
	var WindowWidth=window1W;
	var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
	var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
        var launchBamWebUrl = getActionUrlFromURL(launchBamUrl);
        launchBamWebUrl = appendUrlSessionAjax(launchBamWebUrl);
        var listParam = getInputParamListFromURL(launchBamUrl);
        //BUG ID 542
        try{
            if(dcBamWindow!=null)
              {
                dcBamWindow.close();
               }
           }
        catch(e)
        {}

        var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=0,scrollbars=1,top='+WindowTop+',left='+WindowLeft;

        var win = openNewWindow(launchBamWebUrl,"bam"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
       	dcBamWindow=win;
	try
        {
            addLaunchWindows(win);
        }
        catch(e)
        {}
}

function LaunchCustomReportDesigner()
{
       
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=450;
    var WindowWidth=700;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    var launchCustomReportURL = getActionUrlFromURL(launchCustomReportsUrl); 
    launchCustomReportURL = appendUrlSessionAjax(launchCustomReportURL);
    
    //BUG ID 542
    try{
        if(dcWindow!=null)
          {  
            dcWindow.close();
           }
       }
    catch(e)
    {}

    var listParam = getInputParamListFromURL(launchCustomReportsUrl);
    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=0,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var win = openNewWindow(launchCustomReportURL,"crd"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    dcWindow=win;
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
}

function RefreshPage()
{
	//mainOnLoad();
	//window.document.location.reload();
	 var popup = window.open("", "_self");
    popup.document.write("<HTML><HEAD><TITLE></TITLE></HEAD><BODY>");
    popup.document.write("<form id='postSubmit' method='post' action='"+window.top.location+"' enctype='application/x-www-form-urlencoded'>");
	popup.document.write("<input type='hidden' id='PM_UID' name='PM_UID' value='"+pm_uid+"' />");
    popup.document.write("</FORM></BODY></HTML>");
    popup.document.close();
    popup.document.forms[0].submit();
   //window.location.href=window.top.location.href;
}

function AuditLog()
{
	var AuditLogUrl = "../auditlog/auditlogfilter.faces?Action=1&PM_UID="+pm_uid;
        AuditLogUrl = appendUrlSessionAjax(AuditLogUrl);	
        makeAjaxCall(AuditLogUrl,"ResultContainer","AuditLog",'');
}



function SearchWorkitems()
{       
        var Url = "../search/searchworkitem.faces";
        
        Url = appendUrlSessionAjax(Url);
	var ScreenHeight=screen.height;
	var ScreenWidth=screen.width;
	var WindowHeight=windowH+10; 
	var WindowWidth=windowW + 150;
	var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
	var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
        var winName="Search"+UniqueUserId;
        
        var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

        var listParam=new Array();
        listParam[0]=new Array("from",encode_ParamValue("toolbar"));
        listParam[1]=new Array("clearObject",encode_ParamValue("1"));

	var win = openNewWindow(Url,winName,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
        win.focus();
        try
        {
            addWindows(win);
        }
        catch(e)
        {}
        
        
}

function ShowHelp()
{
        var HelpUrl = "../omniflow/" + localizedPath + "help/webhelp/monitoring_dektop.htm";
	ShowHelpWindow(HelpUrl);
}

function ShowHelpFromPage(reference,control)
{
        var formid=reference.id.substring(0,reference.id.indexOf(":"));
        var controlName=formid + ":" + control;
        if(formid.length==0)
            controlName=control;
        var HelpUrl = document.getElementById(controlName).value;
	ShowHelpWindow(HelpUrl);
}

function ShowHelpWindow(url)
{
	var ScreenHeight=screen.height;
	var ScreenWidth=screen.width;
	var WindowHeight=ScreenHeight-170;
	var WindowWidth=ScreenWidth-50;
	var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
	var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
        var HelpUrl = url;
	var win = window.open_(HelpUrl,"",'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=1,top='+WindowTop+',left='+WindowLeft);
        try
        {
            addWindows(win);
        }
        catch(e)
        {}
}

function Logout()
{
        //BUG 550
        var Url = "../login/logout.faces";
	Url = appendUrlSessionAjax(Url);
        closeWindows();
        var listParam=new Array();
        listParam.push(new Array("DisconnectFlag",encode_ParamValue("true")));
        listParam.push(new Array("PM_UID",encode_ParamValue(pm_uid)));
        generatePostRequest(window,Url,listParam);

}



/*-----------------------------------------------------------------------------------------------------

File Name			: adminoptions.js
Author                          : Ajith Jacob
Date written (DD/MM/YYYY)       : 11/Jan/2007
Description			: This file contains the methods for handling the links on the admin options page.
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date(DD/MM/YYYY)		Change By               Change Description (Bug No. (If Any))
----------------------------------------------------------------------------------------------------
18/04/2007                  Arup Sharma                 BUG 592 (ChangeQueueProperty())
21/04/2007                  Arup Sharma                 BUG 550 (session id appended in all the window.open url's by calling method :appendUrlSession())
23/04/2007                  Arup Sharma                 BUG 557 (CabinetManagement()) , BUG 558 (DocumentManagement())
24/07/2008                  Puneet Satija               Bug 5852( Special character restriction removed in change password functionality)
15/12/2008                  Vijay Kumar                 Bug 7289
04/12/2009                  Indraneel                   PRM_8.0_030 (Support for Export Purge Utility)
11/12/2009                  Bhupesh/Indraneel           WCL_8.0_159 Provision for  creating  alias on myqueue for different processes.
19/01/2010                  Indraneel                   PRM_8.0_036 Option for adding rule defination on queue Aliases to display the row color of workitem list  in webdesktop
PRM_8.0_037       27/01/2010    Puneet Pahuja                   window.open changed to openNewWindow to open new window using HTTP POST
04/03/2010                  Himshikha                   Bug 12193 without selecting any process, clicking on 'change state' button display comments window
23/08/2011                   Anushree Jain	                       Bug 27971 Security issue
14/09/2011                   Anushree Jain	                        Bug 28348 - Provide external queue variable mapping
 * 03/03/2012      Dinesh Sharma   Replicated PRM_8.0_051 Web services url change and authentication provision in processmanager
* 03/04/2012      Ajit/Puneet      Bug 30992 - Omniflow integration with sharepoint
* 04/06/2013      Jaseem Ansari           Bug 39929 Change in the architecture of integration with omnidocs due to security issues 
* 15/07/2013      Dinkar Kad	 Bug 41354 - 'Set diversion' function and 'Audit log configuration function' in process Manager can be accessed by an user who is not a member of any group.
14/08/2013            Dinkar         Bug 41790 - Screen for specifying names of processes,queues,activities,variables, aliases in multiple locales for multilingual functionality.
19/06/2014             Jaseem Ansari      Bug 46779  An unauthorized user is able to access the link for which he is not authorized.Set EXport Info and Audit log configuration link should be accessed only by admin user.
18/02/2015            Dinesh Verma           Bug 53850 - Need to configure external variables in MyQueue 
26/02/2015             Ashutosh Pandey    Bug 53764 - Optimization at CS, ofservices and utility end to reduce the user level configuration and usage of single system utility user to perform each user level operation
26/05/2015        Ashutosh Pandey         Bug 55285 - Change the logic to get the process name for variable pick list
30/06/2015        Ashutosh Pandey         Bug 55299 - Provided the feature for set context for a process
05/06/2015        Ashutosh Pandey         Bug 55321 - Open the OmniDocs, on click of Document Management link, in maximize mode window
27/07/2015                                Bug 56042 - Unable to define alias on MyQueue & Also unable to see the external Variable In QueueManagement
05/10/2015        Saquib                  Bug 57000 - External variables are not showing while defining aliases
16/10/2015                                Bug 57303 - Creation of alias on external table variables on myqueue should be restricted at front end
21/10/2015                                Bug 57530 - Admin Options [Quick Search Management] window gets distorted on click of Variable Name pick list
28/01/2016        Ashutosh Pandey         Bug 58796 - Need to change the color of workitem on hour basis
17/02/2016                                Bug 59212 - Multiple User/Group removal from queue in Process Manager by searching not working
Bug 63982
----------------------------------------------------------------------------------------------------*/

var RefreshLink=null; 

 function RefreshAdminOption()
	{   
            if(RefreshLink !=null)
                {
                    //NewSubmit(RefreshLink);
                    // RefreshLink=null;
                     //return false;
                     ClickAnotherLink(RefreshLink,'cmdlink_go');
                }        
	}

function Refreshmodifyprocstatus()
    {
        try
        {
             clickLink('modifyProcState:cmdlink_go');
        }catch(e){}
    }
function queueManagement()
{
       var Url="../queuemgmt/queuemanagement.faces?Action=1&mode=1&Opt=1&PM_UID="+pm_uid;
       makeAjaxCall(Url,"ResultContainer","resultind","");    
}

function processManagement()
{
    var Url="../processmgmt/modifyprocstatus.faces?Action=1&Opt=2&PM_UID="+pm_uid;
    makeAjaxCall(Url,"ResultContainer","resultind","");
   
}
function queueProcessAuthorization()
{
    var Url="../authorization/queueprocessauth.faces?Action=1&Opt=12&PM_UID="+pm_uid;
    makeAjaxCall(Url,"ResultContainer","resultind","");
   
}
function manageProcess(ref)
{
    var formID=ref.form.id;
    var tableID=formID+":"+"dtprocess";
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;
    var processID="";
    var processName="";
    try
    {
    var rowCount=document.getElementById(tableID).rows.length ;
    var processIDId;
    var processNameId;
    
    for (var iCount=0;iCount < (rowCount-1) ;iCount++)
    {
        currentChkBoxID=tableID+":" + iCount +chkboxName ;
        processIDId=tableID+":" + iCount +":procId";
        processNameId=tableID+":" + iCount +":procName";
        try 
        {
            if(document.getElementById(currentChkBoxID).checked)
            {
                noOfSelectedRows++;
                processID=document.getElementById(processIDId).value;
                processName=document.getElementById(processNameId).value;
             }

         }
        catch(e)
        {
                //alert("Error in=="+iCount);
        }
    }
    }
        catch(e)
        {
                //alert("Error in=="+iCount);
        }
    if(noOfSelectedRows>1)
    {
       alert(INVALID_SELECTION_MULTIPLE);
       return false;
    }  
        
    var Url="../processmgmt/processmanagement.faces";
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("Opt",encode_ParamValue("2")));
    listParam.push(new Array("procName",encode_ParamValue(processName)));
    listParam.push(new Array("procId",encode_ParamValue(processID)));

    var win = openNewWindow(Url,"processmanagement"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
    // window.location.href=Url;   
}

function purgeCriteria(ref)
{
    var formID=ref.form.id;
    var tableID=formID+":"+"dtprocess";
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;
    var processID="";
    var processName="";
    try
    {
    var rowCount=document.getElementById(tableID).rows.length ;
    var processIDId;
    var processNameId;
    
   /* for (var iCount=0;iCount < (rowCount-1) ;iCount++)
    {
        currentChkBoxID=tableID+":" + iCount +chkboxName ;
        processIDId=tableID+":" + iCount +":procId";
        processNameId=tableID+":" + iCount +":procName";
        try 
        {
            if(document.getElementById(currentChkBoxID).checked)
            {
                noOfSelectedRows++;
                processID=document.getElementById(processIDId).value;
                processName=document.getElementById(processNameId).value;
             }

         }
        catch(e)
        {
                //alert("Error in=="+iCount);
        }
    }
    }
        
    if(noOfSelectedRows>1)
    {
       alert(INVALID_SELECTION_MULTIPLE);
       return false;
    }  
        */
	}
		catch(e)
        {
                //alert("Error in=="+iCount);
        }
    var Url="../processmgmt/purgemanagement.faces";
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);


    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("Opt",encode_ParamValue("2")));
    listParam.push(new Array("procName",encode_ParamValue(processName)));
    listParam.push(new Array("procId",encode_ParamValue(processID)));

    var win = openNewWindow(Url,"processmanagement"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
    // window.location.href=Url;   
}

function addtoexistingqueue()
{
    var SID="";
    var WSID="";
    var WSName="";
    var ProcID="";
    var ProcName="";
    var iCount=0;
    try
    {
        for(iCount=0;;iCount++)
        {
            var ctrlName= "processmgmt11:streamLists:" + iCount +":chkBox";
            if((document.getElementById(ctrlName)).checked==true)
            {
                ctrlName="processmgmt11:streamLists:" + iCount +":WID";
                WSID=(document.getElementById(ctrlName)).value;
                ctrlName="processmgmt11:streamLists:" + iCount +":WName";
                WSName=(document.getElementById(ctrlName)).value;
                ctrlName="processmgmt11:streamLists:" + iCount +":SID";
                SID=(document.getElementById(ctrlName)).value;
                ProcID=(document.getElementById("processmgmt11:hidProcessId")).value;
                ProcName=(document.getElementById("processmgmt11:hidProcessName")).value;
                break;
            }
        }
    }
    catch(ex)
    {
        alert(SELECT_WORKSTEP);
        return;
    }
    var QueueID="-1";
    var Url="../queuemgmt/addtoexistingqueue.faces";
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("mode",encode_ParamValue("1")));
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("QueueID",encode_ParamValue(QueueID)));
    listParam.push(new Array("SID",encode_ParamValue(SID)));
    listParam.push(new Array("WSID",encode_ParamValue(WSID)));
    listParam.push(new Array("WSName",encode_ParamValue(WSName)));
    listParam.push(new Array("ProcID",encode_ParamValue(ProcID)));
    listParam.push(new Array("ProcName",encode_ParamValue(ProcName)));
    listParam.push(new Array("StreamDefined",encode_ParamValue("Y")));

    var win = openNewWindow(Url,"existingqueue"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
}

function addtonewqueue()
{
    var SID="";
    var WSID="";
    var WSName="";
    var ProcID="";
    var ProcName="";
    var iCount=0;
    try
    {
        for(iCount=0;;iCount++)
        {
            var ctrlName= "processmgmt11:streamLists:" + iCount +":chkBox";
            if((document.getElementById(ctrlName)).checked==true)
            {
                ctrlName="processmgmt11:streamLists:" + iCount +":WID";
                WSID=(document.getElementById(ctrlName)).value;
                ctrlName="processmgmt11:streamLists:" + iCount +":WName";
                WSName=(document.getElementById(ctrlName)).value;
                ctrlName="processmgmt11:streamLists:" + iCount +":SID";
                SID=(document.getElementById(ctrlName)).value;
                ProcID=(document.getElementById("processmgmt11:hidProcessId")).value;
                ProcName=(document.getElementById("processmgmt11:hidProcessName")).value;
                break;
            }
        }
    }
    catch(ex)
    {
        alert(SELECT_WORKSTEP);
        return;
    }
    var QueueID="123";
    var Url="../queuemgmt/queueproperties.faces";
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window6H+85;
    var WindowWidth=window6W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("Mode",encode_ParamValue("1")));
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("QueueID",encode_ParamValue(QueueID)));
    listParam.push(new Array("SID",encode_ParamValue(SID)));
    listParam.push(new Array("WSID",encode_ParamValue(WSID)));
    listParam.push(new Array("WSName",encode_ParamValue(WSName)));
    listParam.push(new Array("ProcID",encode_ParamValue(ProcID)));
    listParam.push(new Array("ProcName",encode_ParamValue(ProcName)));
    listParam.push(new Array("StreamDefined",encode_ParamValue("Y")));
    listParam.push(new Array("showTab",encode_ParamValue("1")));

    var win = openNewWindow(Url,"newqueue"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}

}

function defineturnaroundtime(ref)
{

    var formID=ref.form.id;
    var tableID=formID+":"+"dtprocess";
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;    
    var processIDId;
    var processID="";
    var processNameId;
    var processName="";
    var turnAroundTimeId;
    var turnAroundTime="";
    var processCalFlagId;
    var processCalFlag="";
    try
    {
    var rowCount=document.getElementById(tableID).rows.length ;
    for (var iCount=0;iCount < (rowCount-1) ;iCount++)
    {
        currentChkBoxID=tableID+":" + iCount +chkboxName ;
        processIDId=tableID+":" + iCount +":procId";
        processNameId=tableID+":" + iCount +":procName";
        turnAroundTimeId=tableID+":" + iCount +":procTat";
        processCalFlagId=tableID+":" + iCount +":procCalFlag";
        try 
        {
            if(document.getElementById(currentChkBoxID).checked)
            {
                noOfSelectedRows++;
                processID=document.getElementById(processIDId).value;
                processName=document.getElementById(processNameId).value;
                turnAroundTime=document.getElementById(turnAroundTimeId).value;
                processCalFlag=document.getElementById(processCalFlagId).value;
             }

         }
        catch(e)
        {
                //alert("Error in=="+iCount);
        }
    }
    }
        catch(e)
        {
                //alert("Error in=="+iCount);
        }
    if(noOfSelectedRows>1)
    {
       alert(INVALID_SELECTION_MULTIPLE);
       return false;
    }  
        var Url="../processmgmt/procturnaroundtime.faces";
        Url = appendUrlSession(Url);
        var ScreenHeight=screen.height;
	var ScreenWidth=screen.width;
	var WindowHeight=window1H;
	var WindowWidth=window1W;
	var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
	var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
        var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

        var listParam=new Array();
        listParam.push(new Array("Action",encode_ParamValue("1")));
        listParam.push(new Array("procName",encode_ParamValue(processName)));
        listParam.push(new Array("procId",encode_ParamValue(processID)));
        listParam.push(new Array("tat",encode_ParamValue(turnAroundTime)));
        listParam.push(new Array("calFlag",encode_ParamValue(processCalFlag)));
    
	var win = openNewWindow(Url,"procturnaroundtime"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
        try
        {
            addWindows(win);
        }
        catch(e)
        {}
}
function processVarMapping()
{
	var Url="../processmgmt/procvarmapping.faces?newPage=true&Opt=3&PM_UID="+pm_uid;
         makeAjaxCall(Url,"ResultContainer","procvarresultind","disabledAliasCheck()");           
}

function setExportCabinet()
{
        if(isAdmin=='true'){
	var Url="../export/exportmanagement.faces?PM_UID="+pm_uid;
        makeAjaxCall(Url,"ResultContainer","resultind","");
    }
}

function dynamicConstants(ref)
{
    var formID=ref.form.id;
    var tableID=formID+":"+"dtprocess";
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;    
    var processIDId;
    var processNameId;
    var processID="";
    var processName="";
    try
    {
    var rowCount=document.getElementById(tableID).rows.length ;
    for (var iCount=0;iCount < (rowCount-1) ;iCount++)
    {
        currentChkBoxID=tableID+":" + iCount +chkboxName ;
        processIDId=tableID+":" + iCount +":procId";
        processNameId=tableID+":" + iCount +":procName";
        try 
        {
            if(document.getElementById(currentChkBoxID).checked)
            {
                noOfSelectedRows++;
                processID=document.getElementById(processIDId).value;
                processName=document.getElementById(processNameId).value;
             }

         }
        catch(e)
        {
                //alert("Error in=="+iCount);
        }
    }
    }
    catch(e)
        {
                //alert("Error in=="+iCount);
        }
    if(noOfSelectedRows>1)
    {
       alert(INVALID_SELECTION_MULTIPLE);
       return false;
    }  
        
   var Url="../processmgmt/dynamicconstants.faces";
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;
    
    var listParam=new Array();
    listParam.push(new Array("newPage",encode_ParamValue("true")));
    listParam.push(new Array("Opt",encode_ParamValue("4")));
    listParam.push(new Array("procName",encode_ParamValue(processName)));
    listParam.push(new Array("procId",encode_ParamValue(processID)));

    var win = openNewWindow(Url,"dynamicConstants"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
}

function disabledAliasCheck(){ 
    document.getElementById("aliaslistDiv").style.height = (window.screen.height - 640);
   for(j=0;j<5;j++){   
        document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleVar").disabled=true;   
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleVar1").disabled=true;   
   }
    
}

function checkOtherRule(ref){  
    if(ref.checked==true){ 
      document.getElementById("frmProcVarMapping:OtherRlueButton").disabled=false;
    }else{
        var radioIndex;  
        var isIE=(navigator.appName.indexOf("Microsoft") != -1)?true:false;
        if(isIE)
          radioIndex=1;
        else
           radioIndex=0;  
        document.getElementsByName("frmProcVarMapping:otherRadioCI")[radioIndex].checked="true";
        document.getElementById("frmProcVarMapping:otherBgcolortxtbox").className="PMbgcolorWhite";
        document.getElementById("frmProcVarMapping:otherImage").src="../omniflow/aliasimages/transparent.gif";
        document.getElementById("frmProcVarMapping:otherHidbgcolortxtbox").value=""; 
        document.getElementById("frmProcVarMapping:OtherRlueButton").disabled=true;
    }
}

function userPrefefences()
{
        var Url="../usermgmt/userpreferences.faces?Action=1&Opt=5&PM_UID="+pm_uid;
        makeAjaxCall(Url,"ResultContainer","resultinduserpref","");
}

function changePassword()
{
    sContextPath = sContextPath.substring(sContextPath.lastIndexOf("/"));

    var url=sContextPath+'/application/OdIntegration.faces';
    url=appendUrlSessionAjax(url);
    var wFeatures = 'resizable=1,scrollbars=1,width='+window1W+',height='+window1H+',left='+window1Y+',top='+window1X;
    var listParam=new Array();
    win = openNewWindow(url,'ODadmin'+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);

    addWindows(win);
  //  var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;



}

function auditLogConfiguration()
{
    if(isAdmin=='true'){
        var Url="../auditlog/auditlogconfig.faces?Action=1&Opt=7&PM_UID="+pm_uid;
        makeAjaxCall(Url,"ResultContainer","auditlogresultind","");
    }
	
}

function changeWorkingTime()
{
	var Url="../calendar/changeworkingtime.faces?Action=5&Opt=10&PM_UID="+pm_uid;
         makeAjaxCall(Url,"ResultContainer","calendermain",""); 
}

function SelectTabAlC(iTabIndex)
{
   try
    {
        document.getElementById("auditconfig11:SelTab").value=iTabIndex;
    }
    catch(e){}
	 ClickAnotherLink('','cmdbutton_go');
}

function cabinetManagement()
{
        //BUG 557 //BUG 557 RE
        
        sContextPath = sContextPath.substring(sContextPath.lastIndexOf("/"));
        
        var url=sContextPath+'/application/odadmin.faces';
        
        url=appendUrlSessionAjax(url);
       
        var wFeatures = 'resizable=1,scrollbars=1,width='+window1W+',height='+window1H+',left='+window1Y+',top='+window1X;
        var listParam=new Array();
        win = openNewWindow(url,'ODadmin'+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
	
	addWindows(win);
        }

function documentManagement()
{
        //BUG 558 //BUG 558 RE
        sContextPath = sContextPath.substring(sContextPath.lastIndexOf("/"));
       
        var url=sContextPath+'/application/odweb.faces';
       
        url=appendUrlSessionAjax(url);

        var winWidth = screen.width;
        var winHeight = screen.height;
        var wFeatures = 'resizable=1,scrollbars=1,width='+winWidth+',height='+winHeight+',left=0,top=0';
        var listParam=new Array();

	win = openNewWindow(url,'ODweb'+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
	addWindows(win);
}

function newQueue(ref)
{
        clearQueueUGInfoMap();
        RefreshLink=ref;
        var QueueID="123";
        var Url="../queuemgmt/queueproperties.faces";
        Url = appendUrlSession(Url);
        var ScreenHeight=screen.height;
	var ScreenWidth=screen.width;
	var WindowHeight=window6H+85;
	var WindowWidth=window6W;
	var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
	var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
        var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=1,top='+WindowTop+',left='+WindowLeft;

        var listParam=new Array();
        listParam.push(new Array("Action",encode_ParamValue("1")));
        listParam.push(new Array("Mode",encode_ParamValue("1")));
        listParam.push(new Array("showTab",encode_ParamValue("1")));
        listParam.push(new Array("QueueID",encode_ParamValue(QueueID)));
        
	var win = openNewWindow(Url,"newqueue"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
        try
        {
            addWindows(win);
        }
        catch(e)
        {}
}

function setPreferredQueue()
{
        var Url="../queuemgmt/setpreferredqueue.faces";
        Url = appendUrlSession(Url);
        var ScreenHeight=screen.height;
	var ScreenWidth=screen.width;
	var WindowHeight=window6H;
	var WindowWidth=window6W;
	var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
	var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
        var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;
        
        var listParam=new Array();
        listParam.push(new Array("Action",encode_ParamValue("1")));
        listParam.push(new Array("Fetch",encode_ParamValue("1")));
        listParam.push(new Array("mode",encode_ParamValue("1")));
        listParam.push(new Array("Clean",encode_ParamValue("1")));
        
	var win = openNewWindow(Url,"preferredqueue"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
        try
        {
            addWindows(win);
        }
        catch(e)
        {}
}

function validateAliasList(ref, objId){
 
    var variableType=document.getElementById("frmProcVarMapping:selectedVarType").value;
    var strValue="";
    var strValue1="";
     if(variableType!="8"){
         var compareValue=""; 
         var compareValue1="";
         for(j=0;j<5;j++){
               compareValue=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").value;
               compareValue1=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").value;
               
            if(variableType!=10){
                 if(validateAllTypeData(compareValue,variableType))
                 {

                 }
                 else
                 {
                    alert(VALUE_IS_NOT_VALID); 
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").select();
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").focus();
                    return false;
                 }
            }
            if(variableType!=10){
                 if(validateAllTypeData(compareValue1,variableType))
                 {

                 }
                 else
                 {
                    alert(VALUE_IS_NOT_VALID); 
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").select();
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").focus();
                    return false;
                 }
            }

          }
     } 
     else{
        for(j=0;j<5;j++){
               strValue=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").value;
               strValue1=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").value;
               if(strValue){
                    if(validateAllTypeData(strValue,'3'))
                 {

                 }
                 else
                 {
                    alert(VALUE_IS_NOT_VALID); 
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").select();
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").focus();
                    return false;
                 }
               }

               if(strValue1){
                    if(validateAllTypeData(strValue1,'3'))
                 {

                 }
                 else
                 {
                    alert(VALUE_IS_NOT_VALID); 
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").select();
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").focus();
                    return false;
                 }
               }
            }
        }
    selectOnechkBoxClick(ref);
    clickLink(objId);
    callOnUnchecked(ref); 
}

function validateAliasListOnNew(){
    var variableType=document.getElementById("frmProcVarMapping:selectedVarType").value;
    var strValue="";
    var strValue1="";
     if(variableType!="8"){
         var compareValue=""; 
         var compareValue1="";
         for(j=0;j<5;j++){
               compareValue=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").value; 
               compareValue1=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").value;
            if(variableType!=10){
                 if(validateAllTypeData(compareValue,variableType))
                 {

                 }
                 else
                 {
                    
                    alert(VALUE_IS_NOT_VALID); 
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").select();
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").focus();
                    return false;
                 }
            } 
            if(variableType!=10){
                 if(validateAllTypeData(compareValue1,variableType))
                 {

                 }
                 else
                 {
                    
                    alert(VALUE_IS_NOT_VALID); 
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").select();
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").focus();
                    return false;
                 }
            }

          }
     } 
     else{
        var ruleSelected;
        for(j=0;j<5;j++){
               strValue=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").value;
               strValue1=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").value;
               ruleSelected = document.getElementById("frmProcVarMapping:rulelist:"+j+":chkAliasRule").checked;
               if(strValue){
                    if(validateAllTypeData(strValue,'3'))
                 {
                    if(ruleSelected && trimByRegularEx(strValue) != "") {
                        if(trimByRegularEx(document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator").value) == "") {
                            alert(VALUE_IS_NOT_VALID);
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator").focus();
                            return false;
                        }
                        if(trimByRegularEx(document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").value) == "") {
                            alert(VALUE_IS_NOT_VALID);
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").focus();
                            return false;
                        }
                    }
                 }
                 else
                 {
                    alert(VALUE_IS_NOT_VALID); 
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").select();
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").focus();
                    return false;
                 }
               }

               if(strValue1){
                    if(validateAllTypeData(strValue1,'3'))
                 {
                    if(ruleSelected && trimByRegularEx(strValue1) != "") {
                        if(trimByRegularEx(document.getElementById("frmProcVarMapping:rulelist:"+j+":logicalOperator").value) == "") {
                            alert(VALUE_IS_NOT_VALID);
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":logicalOperator").focus();
                            return false;
                        }
                        if(trimByRegularEx(document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator1").value) == "") {
                            alert(VALUE_IS_NOT_VALID);
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator1").focus();
                            return false;
                        }
                        if(trimByRegularEx(document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").value) == "") {
                            alert(VALUE_IS_NOT_VALID);
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").focus();
                            return false;
                        }
                    }
                 }
                 else
                 {
                    alert(VALUE_IS_NOT_VALID); 
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").select();
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").focus();
                    return false;
                 }
               }
            }
     }
  return true;
}

function callOnUnchecked(ref){ 
     if(!ref.checked)
      { 
         clickLink('frmProcVarMapping:cmdHideRule');
      }
}
function checkAliasRule(ref){
  var strId=ref.id;
  strId=strId.substring(0,strId.lastIndexOf(":")+1);  
  var selectedVarType= document.getElementById("frmProcVarMapping:selectedVarType").value;
  if(ref.checked==true){ 
        document.getElementById(strId+"rlueButton").disabled=false;
    }else{
        var radioIndex;  
        var isIE=(navigator.appName.indexOf("Microsoft") != -1)?true:false;
        if(isIE)
          radioIndex=1;
        else
         radioIndex=0;  
        if(selectedVarType!="8"){
           document.getElementById(strId+"ruleValue").value="";
           document.getElementById(strId+"relOperator").selectedIndex=0;
           document.getElementById(strId+"relOperator1").selectedIndex=0;
           document.getElementById(strId+"assignOperator").selectedIndex=0;
           document.getElementById(strId+"assignOperator1").selectedIndex=0;
           document.getElementById(strId+"logicalOperator").selectedIndex=0;
           document.getElementById(strId+"ruleValue1").value="";
           }
        else
        {
           document.getElementById(strId+"relOperator").selectedIndex=0;
           document.getElementById(strId+"relOperator1").selectedIndex=0;
           document.getElementById(strId+"assignOperator").selectedIndex=0;
           document.getElementById(strId+"assignOperator1").selectedIndex=0;
           document.getElementById(strId+"logicalOperator").selectedIndex=0;
           document.getElementById(strId+"ruleTempVar").value="";
           document.getElementById(strId+"ruleTempVar1").value="";
           document.getElementById(strId+"ruleTempVarType").value="";
           document.getElementById(strId+"ruleTempVarType1").value="";
        }
        document.getElementsByName(strId+"radioCI")[radioIndex].checked="true";
        document.getElementById(strId+"bgcolortxtbox").className="PMbgcolorWhite";
        document.getElementById(strId+"selImage").src="../omniflow/aliasimages/transparent.gif";
        document.getElementById(strId+"hidbgcolortxtbox").value=""; 
        document.getElementById(strId+"rlueButton").disabled=true;
    }
}

function delQueue()
{
    var QueueID="-1";
    var iCount=0;
    try
    {
        for(iCount=0;;iCount++)
        {
            var ctrlName= "QueueMgmt:queueLists:" + iCount +":chkBoxQueue";
            if((document.getElementById(ctrlName)).checked==true)
            {
                ctrlName="QueueMgmt:queueLists:" + iCount +":queueID";
                QueueID=(document.getElementById(ctrlName)).value;
                ctrlName="QueueMgmt:queueLists:" + iCount +":queueType";
                if(document.getElementById(ctrlName).value=="I" || document.getElementById(ctrlName).value=="Q" || document.getElementById(ctrlName).value=="E")
                {
                    alert(QUEUE_CAN_NOT_BE_DELETED);
                    document.getElementById("QueueMgmt:m_strQueueID").value="";
                    return false;
                }
                else
                {
                    document.getElementById("QueueMgmt:m_strQueueID").value=QueueID;
                    return true;                    
                }
            }
        }
    }
    catch(ex)
    {
        document.getElementById("QueueMgmt:m_strQueueID").value="";
        alert(NO_QUEUE_SELECTED);
        return false;;
    }
    return false;
}

function delQueueConfirm()
{
    NewSubmit(document.getElementById("QueueMgmt:btnConfirmDelete"));
}

function deleteQueueAction()
{
    try
    {
        var toclickid='QueueMgmt:cmdlink_Delete';
        clickLink(toclickid);
    }
    catch(e)
    {
    }
}



function getCalendar()
{
    var ProcessID="-1";
    var ProcessName="";
    var WorkstepID="-1";
    var WorkstepName="";
    var iCount=0;
    
    var Url="../calendar/calendardisplay.faces";
    Url = appendUrlSession(Url);    
    var listParam=new Array();
    
    var strSelectedTab=document.getElementById("changeworkingtime:SelTab").value;
    if(strSelectedTab==1)
        {

        try
       {
        for(iCount=0;;iCount++)
        {
            var ctrlName= "changeworkingtime:sv1:processlist:" + iCount +":chkBoxProcess";
            if((document.getElementById(ctrlName)).checked==true)
            {
                ctrlName="changeworkingtime:sv1:processlist:" + iCount +":processId";
                ProcessID=(document.getElementById(ctrlName)).value;
                ctrlName="changeworkingtime:sv1:processlist:" + iCount +":processName";
                ProcessName=(document.getElementById(ctrlName)).value;
                break;
            }
        }
    }
    catch(ex)
    {
        alert(NO_PROCESS_SELECTED);
        return;
    }

    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("Launch",encode_ParamValue("1")));
    listParam.push(new Array("ProcessID",encode_ParamValue(ProcessID)));
    listParam.push(new Array("ProcessName",encode_ParamValue(ProcessName)));
   
    }
    else
    {
        try
        {
            ProcessID=(document.getElementById("changeworkingtime:hidProcessId")).value;
            ProcessName=(document.getElementById("changeworkingtime:hidProcessName")).value;
            if(ProcessID=="")
            {
                alert(NO_PROCESS_SELECTED);
                return;
            }
        }
        catch(ex) {}
        try
        {
            for(iCount=0;;iCount++)
            {
                var ctrlName= "changeworkingtime:sv2:streamLists:" + iCount +":chkBox";
                if((document.getElementById(ctrlName)).checked==true)
                {
                    ctrlName="changeworkingtime:sv2:streamLists:" + iCount +":WID";
                    WorkstepID=(document.getElementById(ctrlName)).value;
                    ctrlName="changeworkingtime:sv2:streamLists:" + iCount +":WName";
                    WorkstepName=(document.getElementById(ctrlName)).value;

                    break;
                }
            }
        }
        catch(ex)
        {
            alert(NO_ACTIVITY_SELECTED);
            return;
        }
    
        listParam.push(new Array("Action",encode_ParamValue("2")));
        listParam.push(new Array("Launch",encode_ParamValue("1")));
        listParam.push(new Array("ProcessID",encode_ParamValue(ProcessID)));
        listParam.push(new Array("ProcessName",encode_ParamValue(ProcessName)));
        listParam.push(new Array("WorkstepID",encode_ParamValue(WorkstepID)));
        listParam.push(new Array("WorkstepName",encode_ParamValue(WorkstepName)));
    

    }
        
        var ScreenWidth=screen.width;
        var WindowHeight=window1H+20;
	var WindowWidth=window1W-100;
        var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
        var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

        var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=auto,top='+WindowTop+',left='+WindowLeft;

        var win = openNewWindow(Url,"getcalendar"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
        try
            {
                addWindows(win);
            }
        catch(e)
            {}
}

function updateQueue(ref)
{
        clearQueueUGInfoMap();
        RefreshLink=ref;
        var QueueID="-1";
        var iCount=0;
        var pendingActions="";
        try
        {
            for(iCount=0;;iCount++)
            {
                var ctrlName= "QueueMgmt:queueLists:" + iCount +":chkBoxQueue";
                //BUG ID 592
                var ctrlName2 ="QueueMgmt:queueLists:" + iCount +":queueType";
                //END
                if((document.getElementById(ctrlName)).checked==true)
                {
                    //BUG ID 592
                    if(document.getElementById(ctrlName2).value=="I")    
                    {
                        //alert(INVALID_OPERATION);
                        //return;
                    }
                    //END
                    ctrlName="QueueMgmt:queueLists:" + iCount +":queueID";
                    QueueID=(document.getElementById(ctrlName)).value;
                    try
                    {
                        pendingActions=document.getElementById("QueueMgmt:queueLists:"+ iCount +":PendingActions").value;
                     }catch(ex){}   
                    break;
                }
            }
        }
        catch(ex)
        {
            alert(NO_QUEUE_SELECTED);
            return;
        }

        
        var Url="../queuemgmt/queueproperties.faces";
        Url = appendUrlSession(Url);
        
        var ScreenHeight=screen.height;
	var ScreenWidth=screen.width;
	var WindowHeight=window6H+85;
	var WindowWidth=window6W;
	var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
	var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

        var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=1,top='+WindowTop+',left='+WindowLeft;

        var listParam=new Array();
        listParam.push(new Array("Action",encode_ParamValue("1")));
        listParam.push(new Array("Mode",encode_ParamValue("2")));
        listParam.push(new Array("showTab",encode_ParamValue("1")));
        listParam.push(new Array("QueueID",encode_ParamValue(QueueID)));
        listParam.push(new Array("PendingActions",encode_ParamValue(pendingActions)));

	var win = openNewWindow(Url,"changequeue"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
        try
        {
            addWindows(win);
        }
        catch(e)
        {}
}

function selectOnechkBoxClick(nodeChkBox)
{
     var iCount;
     var index = nodeChkBox.id.lastIndexOf(':');
     var arr=nodeChkBox.id.split(":");
     var iArrLength = arr.length ;
     var strName="";
     for (var count=0; count < arr.length-2 ; count++ )
     {
         if(count==0)
            strName = arr[count] ;
         else
         {
            strName=strName + ":" + arr[count] ;
         }
     }
     var rowCount = nodeChkBox.parentNode.parentNode.parentNode.rows.length;
     if(nodeChkBox.checked == true)
     {
         for(iCount = 0; iCount < rowCount;iCount++)
         {

            if(iCount != arr[iArrLength-2])
             {
                var el=document.getElementById(strName+":"+iCount +":"+arr[iArrLength-1]);
                el.checked=false;
             }
         }		
     }
}

function quciksearch()
{
    var Url="../search/quickSearch.faces?Action=1&Opt=11&PM_UID="+pm_uid;
    makeAjaxCall(Url,"ResultContainer","quicksearchresult","refreshQSVList()");
           
}

function multilingualDefinition()
{
    var Url="../search/multilingualDefinitin.faces?PM_UID="+pm_uid;
    makeAjaxCall(Url,"ResultContainer","multilingualdefinition",'refreshMultiLingualList()');
}


function appendTagAndValue(tagName,tagValue)
{
    var tagAndValue="";
    if(tagValue != "")
        tagAndValue = "<" + tagName + ">" + Trim(tagValue) + "</" + tagName + ">";
    return tagAndValue;
}
            
function appendTagOnly(tagName,flag)
{
    var Tag="";
    if(flag==true)
        Tag="<" + tagName + ">";
    else if(flag==false)
        Tag="</" + tagName + ">";
    return Tag;
}
             
function changeProcessState()
{
     var item=document.getElementById("modifyProcState:btnCnfChangeState");
     var formID=item.form.id;
     var tableID=formID+":"+"dtprocess";
     var chkboxName=":chkBox";
     var noOfSelectedRows=0;
     var selectedProcessXML="";
     try
     {
     var rowCount=document.getElementById(tableID).rows.length ;
     var processIDId;
     var processStateId;
     for (var iCount=0;iCount < (rowCount-1) ;iCount++)
     {
        currentChkBoxID=tableID+":" + iCount +chkboxName ;
        processIDId=tableID+":" + iCount +":procId";
        processStateId=tableID+":" + iCount +":procState";
        try 
        {
            if(document.getElementById(currentChkBoxID).checked)
            {
                noOfSelectedRows++;
                var processID=document.getElementById(processIDId).value;
                var processState=document.getElementById(processStateId).value;
                if(noOfSelectedRows==1)
                {
                   selectedProcessXML=appendTagOnly(PROCESSLIST,true);
                }  
                selectedProcessXML += appendTagOnly(PROCESSINFO,true);
                selectedProcessXML += appendTagAndValue(ID,processID);
                selectedProcessXML += appendTagAndValue(STATE,processState)
                selectedProcessXML += appendTagOnly(PROCESSINFO,false);  
             }

         }
        catch(e)
        {
                //alert("Error in=="+iCount);
        }
    }
    }
        catch(e)
        {
                //alert("Error in=="+iCount);
        }
    if(noOfSelectedRows>0)
    {
        selectedProcessXML += appendTagOnly(PROCESSLIST,false);
        document.getElementById(formID+":hid_ProcessListXML").value=selectedProcessXML;
        NewSubmit(item);
    }
    else
    {       
            document.getElementById(formID+":hid_ProcessListXML").value="";
         //   alert(INVALID_SELECTION_MORE);   //Bug Id 7191
            return false;
    }            
    return false;
}

/**************************************************change password*********************************/

    function chkPassword()
    {
	var txtOldPwd=document.getElementById("ChangePassword:txtOldPassword");
        var txtPwd=document.getElementById("ChangePassword:txtPassword");
        var txtConPwd=document.getElementById("ChangePassword:txtConfirmPassword");

        if(Trim(txtOldPwd.value)=="")
        {
            alert(EMPTY_PASSWORD_NOT_ALLOWED);
            txtOldPwd.focus();
            return false;
        }
        if(Trim(txtPwd.value)=="")
        {
            alert(EMPTY_PASSWORD_NOT_ALLOWED);
            txtPwd.focus();
            return false;
        }
        if(Trim(txtConPwd.value)=="")
        {
            alert(EMPTY_PASSWORD_NOT_ALLOWED);
            txtConPwd.focus();
            return false;
        }
        if(txtOldPwd.value!="")
        {
            if(((Trim(txtOldPwd.value)) != txtOldPwd.value) && (txtOldPwd.value.length != 0))
            {
                alert(NO_SPACE_IN_PASSWORD);
                txtOldPwd.select();
                txtOldPwd.focus();
                return false;
            }
        }
        if(txtPwd.value!="" ||txtConPwd.value!="")
	{
          /*  if((Trim(txtPwd.value)).indexOf('#') != -1 || (Trim(txtPwd.value)).indexOf(',') != -1 || (Trim(txtPwd.value)).indexOf('<') != -1 || (Trim(txtPwd.value)).indexOf('>') != -1)
            {
                alert(NO_SYMBOL_CHAR_IN_PASSWORD);
                txtPwd.focus();
                return false;
            }
            if((Trim(txtConPwd.value)).indexOf('#') != -1 || (Trim(txtConPwd.value)).indexOf(',') != -1 || (Trim(txtConPwd.value)).indexOf('<') != -1 || (Trim(txtConPwd.value)).indexOf('>') != -1)
            {
                alert(NO_SYMBOL_CHAR_IN_PASSWORD);
                txtConPwd.focus();
                return false;
            }
            */
            if( ((Trim(txtPwd.value)) != txtPwd.value) && (txtPwd.value.length != 0))
            {
                alert(NO_SPACE_IN_PASSWORD);
                txtPwd.select();
                txtPwd.focus();
                return false;
            }
            if( ((Trim(txtConPwd.value)) != txtConPwd.value) && (txtConPwd.value.length != 0))
            {
                alert(NO_SPACE_IN_PASSWORD);
                txtConPwd.select();
                txtConPwd.focus();
                return false;
            }
            else if (ConformPassword(Trim(txtPwd.value),Trim(txtConPwd.value)) == '1')
            {
                alert(NO_MATCH_PASSWD_CONFIRMPASSWD);
                txtConPwd.select();
                txtConPwd.focus();
                return false;
            }
        }
    return true;
}

function ConformPassword(var1,var2)
{
    if (var1.toLowerCase() != var2.toLowerCase())
        return 1;
    else
        return 0;
}

/***********************************************************************************************/            

/****************************************************Process variable mapping********************/

function checkData()
            {
                //set the selected var name
                var varName = document.getElementById("frmProcVarMapping:selectedVarName").value;
                var variableType=document.getElementById("frmProcVarMapping:selectedVarType").value;
                document.getElementById("frmProcVarMapping:selectedVarName").value = Trim(varName);
                
                //check if queue name is selected or not
                
                if(document.getElementById("frmProcVarMapping:hidQueueId").value == "-1" && document.getElementById("frmProcVarMapping:hidQueueName").value == "")
                {
                    alert(NO_QUEUE_SELECTED);
                    return false;
                }

                if(varName=='')
                {
                    alert("No Variable is Selected");
                    return false;
                }
                //check for blank name and other conditions
                
                var aliasBox = document.getElementById("frmProcVarMapping:txtAliasName");
                if(aliasBox.value == "")
                {
                    alert(ALIAS_NO_SPECIFY_VALUE);
                    aliasBox.focus();
                    return false;
                }
                else
                {
                    //check for invalid characters in name
                    
                    var tempVal = isInvalid(aliasBox.value);
                    if (tempVal =='3')
                    {
                            alert(ALIAS_NO_SYMBOL_CHAR);
                            aliasBox.focus();
                            return false;
                    }
                    else if (tempVal=='1')
                    {
                            alert(ALIAS_NO_SPACE_CHAR);
                            aliasBox.focus();
                            return false;
                    }
                    
                    //check for numeric value in name
                    
                    if(!isNaN(Trim(aliasBox.value)))
                    {
			alert(ALIAS_NO_NUMERICNAME);
                        aliasBox.focus();
			return false;
                    }
                    else if(!isNaN(Trim(aliasBox.value).substring(0,1)))
                    {
			alert(ALIAS_NO_START_NUMERIC_CHAR);
                        aliasBox.focus();
			return false;
                    }
                    
                     //Check that alias name must not be same as system variable names bug id-3582

                    try
                    {
                        var cmbQSVList = document.getElementById("frmProcVarMapping:opVariableNameList");
                        var opLength = cmbQSVList.length;
                        for(iCount=(opLength-1);iCount >= 0 ; iCount--)			
                        {
                            if(Trim(cmbQSVList.options[iCount].text).toUpperCase() ==Trim(aliasBox.value).toUpperCase())
                                {
                                    alert(ALIAS_NAME_NOT_AS_SYSTEM_VARIABLE_NAME);
                                    aliasBox.focus();
                                    return false;
                                }
                        }
                    }
                    catch(e)
                    {
                    }

                    //check for same alias name
                    var rowCount = 0;
                    try
                    {
                        rowCount = document.getElementById("frmProcVarMapping:dtVarList").rows.length;
                    }catch(ex)
			{
                            rowCount =0;
			}
                    if(rowCount > 1)
                    {
                        
                        for(var iCount = 0 ; iCount < (rowCount-1) ; iCount++)
                        {
                            
                            if(Trim(document.getElementById("frmProcVarMapping:dtVarList:"+iCount+":aliasname").innerHTML).toUpperCase() == Trim(aliasBox.value).toUpperCase())
                            {
                                alert(ALIAS_NAME_ALREADY_EXIST);
                                if(aliasBox.disabled == false)
                                    aliasBox.focus();  
				return false;
                            }
                             //check if alias exsit for the variable
                            if(Trim(document.getElementById("frmProcVarMapping:dtVarList:"+iCount+":varname").innerHTML).toUpperCase() == Trim(varName).toUpperCase())
                            {
                                alert(ALIAS_EXIST_FOR_VARIABLE);
                                aliasBox.focus();
				return false;
                            }
                        }
                    }
 
                }

                 if(variableType!="8"){
                     var compareValue=""; 
                     var compareValue1=""; 
                     for(j=0;j<5;j++){
                           compareValue=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").value;
                           compareValue1=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").value; 
                        if(variableType!=10){
                             if(validateAllTypeData(compareValue,variableType))
                             {
                                  
                             }
                             else
                             {
                                alert(VALUE_IS_NOT_VALID); 
                                document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").select();
                                document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").focus();
                                return false;
                             }
                        } 
                        if(variableType!=10){
                             if(validateAllTypeData(compareValue1,variableType))
                             {
                                  
                             }
                             else
                             {
                                alert(VALUE_IS_NOT_VALID); 
                                document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").select();
                                document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").focus();
                                return false;
                             }
                        }
                        
                      }
                 }
                if(variableType == "8") {
                    var ruleTempVar = "";
                    var ruleTempVar1 = "";
                    var ruleSelected;
                    for(j = 0; j < 5; j++) {
                        ruleSelected = document.getElementById("frmProcVarMapping:rulelist:"+j+":chkAliasRule").checked;
                        if(ruleSelected) {
                            ruleTempVar = document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").value;
                            ruleTempVar1 = document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").value;
                            if(validateAllTypeData(ruleTempVar, "3")) {
                                if(trimByRegularEx(ruleTempVar) != "") {
                                    if(trimByRegularEx(document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator").value) == "") {
                                        alert(VALUE_IS_NOT_VALID);
                                        document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator").focus();
                                        return false;
                                    }
                                    if(trimByRegularEx(document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").value) == "") {
                                        alert(VALUE_IS_NOT_VALID);
                                        document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").focus();
                                        return false;
                                    }
                                }
                            } else {
                                alert(VALUE_IS_NOT_VALID);
                                document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").select();
                                document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").focus();
                                return false;
                            }
                            if(validateAllTypeData(ruleTempVar1, "3")) {
                                if(trimByRegularEx(ruleTempVar1) != "") {
                                    if(trimByRegularEx(document.getElementById("frmProcVarMapping:rulelist:"+j+":logicalOperator").value) == "") {
                                        alert(VALUE_IS_NOT_VALID);
                                        document.getElementById("frmProcVarMapping:rulelist:"+j+":logicalOperator").focus();
                                        return false;
                                    }
                                    if(trimByRegularEx(document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator1").value) == "") {
                                        alert(VALUE_IS_NOT_VALID);
                                        document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator1").focus();
                                        return false;
                                    }
                                    if(trimByRegularEx(document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").value) == "") {
                                        alert(VALUE_IS_NOT_VALID);
                                        document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").focus();
                                        return false;
                                    }
                                }
                            } else {
                                alert(VALUE_IS_NOT_VALID);
                                document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").select();
                                document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").focus();
                                return false;
                            }
                        }
                    }
                }
                return true;
            }
            
            function Verify(ctrl)
            {

                var rowCount =0;
				try
				{
					rowCount = document.getElementById("frmProcVarMapping:dtVarList").rows.length;
				}catch(ex)
				{
					rowCount = 0;
				}
                var flag = false;
                var iCount = 0 ;
                          
                
                
                if(rowCount > 1)
                    {
                        
                        for(iCount = 0 ; iCount < (rowCount-1) ; iCount++)
                        {
                            if(document.getElementById("frmProcVarMapping:dtVarList:"+iCount+":chkUser").checked == true)
                            {
                                flag =true;
                                break;
                             }
                        }
                     }
                
                if(flag == true)
                {
                    document.getElementById("frmProcVarMapping:selectedRow").value = iCount;
                }
                else
                {
                    return false;
                }
                
                if((ctrl == 'UP') && (iCount == 0))
                    return false;
                if((ctrl == 'DOWN') && (iCount ==(rowCount-2)))
                    return false;
                    
                return true;    
               
            }
            function checkBoxSelect()
            {
                document.getElementById("aliaslistDiv").style.height = (window.screen.height - 640);
                var selectedVarType= document.getElementById("frmProcVarMapping:selectedVarType").value;
                if(selectedVarType==""){
                    var radioIndex;  
                    var isIE=(navigator.appName.indexOf("Microsoft") != -1)?true:false;
                    if(isIE)
                     radioIndex=1;
                    else
                     radioIndex=0;
                    for(j=0;j<5;j++){
                        document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleVar").value=""; 
                        document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").value=""; 
                        document.getElementsByName("frmProcVarMapping:rulelist:"+j+":radioCI")[radioIndex].checked="true";
                        document.getElementById("frmProcVarMapping:rulelist:"+j+":bgcolortxtbox").className="PMbgcolorWhite";
                        document.getElementById("frmProcVarMapping:rulelist:"+j+":selImage").src="../omniflow/aliasimages/transparent.gif";
                        document.getElementById("frmProcVarMapping:rulelist:"+j+":hidbgcolortxtbox").value="";
                        document.getElementById("frmProcVarMapping:rulelist:"+j+":rlueButton").disabled=true;
                        document.getElementById("frmProcVarMapping:rulelist:"+j+":chkAliasRule").checked=false;
                        document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").disabled=false;
                        document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleVar1").value=""; 
                    }
                }
               if(document.getElementById("frmProcVarMapping:selectedVarName")){
                    var strSelectedText=document.getElementById("frmProcVarMapping:selectedVarName").value;
                    if(strSelectedText!=""){ 
                        if(selectedVarType=='8'){
                                document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue").value=REPORT_TODAY;
                                document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue1").value=REPORT_TODAY;
                                document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue").disabled=true;
                                document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue1").disabled=true;
                                 for(j=1;j<5;j++){
                                   //document.getElementById("frmProcVarMapping:rulelist:"+j+":chkAliasRule").disabled=true;  
                                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").disabled=true;
                                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").disabled=true;
                                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").value=REPORT_TODAY;
                                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").value=REPORT_TODAY;
                                 }
                               }
                             else if(selectedVarType=='10'){
                                   document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator").disabled=true;
                                   document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator1").disabled=true;
                                   document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator").disabled=true; 
                                   document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar").disabled=true; 
                                   document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator1").disabled=true;
                                   document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar1").disabled=true;
                                   document.getElementById("frmProcVarMapping:rulelist:"+0+":chkAliasRule").disabled=false;
                                   document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType").disabled=true;
                                   document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType1").disabled=true;
                                   for(j=1;j<5;j++){
                                       document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator").disabled=true;
                                       document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator1").disabled=true;
                                       document.getElementById("frmProcVarMapping:rulelist:"+j+":chkAliasRule").disabled=false;
                                       document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator").disabled=true; 
                                       document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").disabled=true; 
                                       document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator1").disabled=true;
                                       document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").disabled=true;
                                       document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").disabled=true;
                                       document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").disabled=true;
                                   }  
                               }
                             else{
                                   document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator").disabled=true; 
                                   document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar").disabled=true; 
                                   document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator1").disabled=true;
                                   document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar1").disabled=true;
                                   document.getElementById("frmProcVarMapping:rulelist:"+0+":chkAliasRule").disabled=false;
                                   document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType").disabled=true;
                                   document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType1").disabled=true;
                                   for(j=1;j<5;j++){
                                       document.getElementById("frmProcVarMapping:rulelist:"+j+":chkAliasRule").disabled=false;
                                       document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator").disabled=true; 
                                       document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").disabled=true; 
                                       document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator1").disabled=true;
                                       document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").disabled=true;
                                       document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").disabled=true;
                                       document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").disabled=true;
                                   }  
                               }
                              

                         document.getElementById("frmProcVarMapping:cmd_ProcVarList").disabled=true;
                         document.getElementById("frmProcVarMapping:txtAliasName").disabled=true;
                         document.getElementById("frmProcVarMapping:cmdNew").style.display="inline";
                         document.getElementById("frmProcVarMapping:cmdAdd").style.display="none"; 
                    }
                 for(i=0;i<5;i++){
                   document.getElementById("frmProcVarMapping:rulelist:"+i+":ruleVar").disabled=true;
                   document.getElementById("frmProcVarMapping:rulelist:"+i+":ruleVar1").disabled=true;
                }
              } 
                var rowCount =0;
				try
				{
					rowCount = document.getElementById("frmProcVarMapping:dtVarList").rows.length;
				}catch(ex)
				{
					rowCount =0;
				}
                var selRow = document.getElementById("frmProcVarMapping:selectedRow").value;
                
                if(rowCount > 1)
                {
                    if(selRow > -1)
                    {
                        document.getElementById("frmProcVarMapping:dtVarList:"+selRow+":chkUser").checked = true;    
                    }
                }
                if(document.getElementById("frmProcVarMapping:hidQueueId").value=="0"){
                    document.getElementById("frmProcVarMapping:pgProcessName").style.display="inline";
                }
                else{
                    document.getElementById("frmProcVarMapping:pgProcessName").style.display="none";
                    document.getElementById("frmProcVarMapping:hidProcessName").value="";   
                    document.getElementById("frmProcVarMapping:hidProcessId").value="-1";   
                }
            }
            
            function submitForm()
            {
                ClickAnotherLink('','cmdlink_Go');
            }
            function procVarQSelect()
            {
                try{

                 if(window.parent.document.getElementById("frmProcVarMapping:hidProcessName")){
                    window.parent.document.getElementById("frmProcVarMapping:hidProcessName").value="";
                    window.parent.document.getElementById("frmProcVarMapping:hidProcessName").value="";
                    window.parent.document.getElementById("frmProcVarMapping:hidProcessId").value="-1";
                }
                if(window.parent.document.getElementById("frmProcVarMapping:rulelist"))
                {
                    for(j=0;j<5;j++){
                         window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue1").value="";
                         window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue").value="";
                         window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").value="";
                          window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator").selectedIndex=0;
                             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator1").selectedIndex=0;
                             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator").selectedIndex=0;
                             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator1").selectedIndex=0;
                             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":chkAliasRule").disabled=false;
                             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator").selectedIndex=0;
                             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator1").selectedIndex=0;
                             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar").value="";
                             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar1").value="";
                             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator").selectedIndex=0;
                             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator1").selectedIndex=0;
                             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").value="";
                             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").value="";
                             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleVar1").value="";
                             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleVar1").value="";
                             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":logicalOperator").selectedIndex=0;
                             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":logicalOperator").selectedIndex=0;
                             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType").value="";
                             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").value="";
                             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType1").value="";
                             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").value="";
                    }
                }
                }catch(ex)
                {}
                submitForm();
            }
            function checkQueue()
            {
		if(document.getElementById("frmProcVarMapping:hidQueueId").value == "-1" && document.getElementById("frmProcVarMapping:hidQueueName").value == "")
                {
                    alert(NO_QUEUE_SELECTED);
                    return false;
                }
                 var variableType=document.getElementById("frmProcVarMapping:selectedVarType").value;
                 if(variableType!="8"){
                     var compareValue=""; 
                     for(j=0;j<5;j++){
                           compareValue=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").value;  
                        if(variableType!=10){
                             if(validateAllTypeData(compareValue,variableType))
                             {
                                  
                             }
                             else
                             {
                                alert(VALUE_IS_NOT_VALID); 
                                document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").select();
                                document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").focus();
                                return false;
                             }
                        } 
                        
                      }
                 }
                return true;
            }
            
            function setProcVarMapping()
            {
                try
                {
                    clickLink('frmProcVarMapping:btnSetMapping');
                }catch(e){}
                return false;
            }
            
            function setAuditLogConfig()
            {
                try
                {
                    clickLink('auditconfig11:btnSetConfig');
                }catch(e){}
                return false;
            }
            
            function saveQuickSearchVars()
            {
                try
                {
                    clickLink('quicksearch:btnSaveQSV');
                }catch(e){}
                return false;
            }            
                   
/*********************************************for Calender*********************************************************/

 function SelectTabCalender(iTabIndex)
     {
        try
        {
            document.getElementById("changeworkingtime:SelTab").value=iTabIndex;
        }
        catch(e){                   
        }

        if(iTabIndex==1)
        {
            document.getElementById("changeworkingtime:hidProcessName").value="";
            document.getElementById("changeworkingtime:hidProcessId").value="";
            clickLink('changeworkingtime:cmdlink_GoProcess');
        }
        if(iTabIndex==2)
        {
            var ProcessID="-1";
            var ProcessName="";                   
            var iCount=0;
               try
               {
                    for(iCount=0;;iCount++)
                    {
                        var ctrlName= "changeworkingtime:sv1:processlist:" + iCount +":chkBoxProcess";
                        if((document.getElementById(ctrlName)).checked==true)
                        {
                            ctrlName="changeworkingtime:sv1:processlist:" + iCount +":processId";
                            ProcessID=(document.getElementById(ctrlName)).value;
                            ctrlName="changeworkingtime:sv1:processlist:" + iCount +":processName";
                            ProcessName=(document.getElementById(ctrlName)).value;
                            document.getElementById("changeworkingtime:hidProcessId").value=ProcessID;
                            document.getElementById("changeworkingtime:hidProcessName").value=ProcessName;
                            clickLink('changeworkingtime:cmdlink_Go');
                            break;
                        }
                    }
                }

                catch(ex)
                {
                    clickLink('changeworkingtime:cmdlink_TempForRefresh');
                }  
            }
        }

        function getWorkstepforprocess()
        {
            clickLink('changeworkingtime:cmdlink_Go');
        }
        
        function getWorkstepforfilter()
        {
            if((Trim(document.getElementById("changeworkingtime:hidProcessId").value)).length>0)
            {
            clickLink('changeworkingtime:cmdlink_Go');
            }            
        }
/*********************************************for Calender end*********************************************************/            
/*********************************************for AUDITlOG CONFIGURATION*********************************************************/  
function submit()
            {
               ClickAnotherLink('','cmdlink_Go');
            }
            
            
         function chkSelected(listType)
            {
                    
					
                    var len;
                    var name;
                    var id;
                    var selValue="";
                    if(listType == TS_ENABLEITEM)
                    {
                            //selValue=document.getElementById("auditconfig11:availableItems").value;
							
                            len=document.getElementById("auditconfig11:availableItems").length;
                            for(i=0;i<len;i++)
                               {

                                  if(document.getElementById("auditconfig11:availableItems").options[i].selected)
                                  {
									
                                    name=document.getElementById("auditconfig11:availableItems").options[i].text;
                                    id=document.getElementById("auditconfig11:availableItems").options[i].value;
                                    if(i==len-1)
                                    selValue+=name;
                                    else
                                    selValue+=name+",";
                           
                                    }
                                }

                    }
                    else if(listType == TS_DISABLEITEM)
                    {
                            //selValue=document.getElementById("auditconfig11:selectedItems").value;
                            len=document.getElementById("auditconfig11:selectedItems").length;
                            for(i=0;i<len;i++)
                               {

                                  if(document.getElementById("auditconfig11:selectedItems").options[i].selected)
                                  {

                                    name=document.getElementById("auditconfig11:selectedItems").options[i].text;
                                    id=document.getElementById("auditconfig11:selectedItems").options[i].value;
                                    if(i==len-1)
                                    selValue+=name;
                                    else
                                    selValue+=name+",";

                                    }
                            }
                            
                    }
                    if(selValue =="")
                    {                        
                        if(document.getElementById('isSupervisor'))
                          {
                         if(document.getElementById('isSupervisor').value == "false")
                             {                                     
                                if(!document.getElementById('auditconfig11:cmdlink_Cabinet'))                 
                              {
                                  alert(NOT_AUTHORIZED_TO_USE_THE_OPERATION);
                                  return false;
                              }     
                            }
                           }
                            alert(SELECT_AN_ITEM_FROM_THE_LIST);
                            return false;
                    }
                    else
                    {
                            document.getElementById("selectedValue").value = selValue;
							
							return true;

                    }
	}
        
        function chkSelectedattribute(listType)
            {
                   
                    var selValue=""; 
                    var len;
                    var name;
                    var id;
                    var selValue="";
                    if(listType == TS_ENABLEATTRIBUTE)
                    {
                           len=document.getElementById("auditconfig11:disableItems2").length;
                            for(i=0;i<len;i++)
                               {

                                  if(document.getElementById("auditconfig11:disableItems2").options[i].selected)
                                  {

                                    name=document.getElementById("auditconfig11:disableItems2").options[i].text;
                                    id=document.getElementById("auditconfig11:disableItems2").options[i].value;
                                    if(i==len-1)
                                    selValue+=name;
                                    else
                                    selValue+=name+",";
                           //selValue=document.getElementById("auditconfig11:disableItems2").value;
                                    }
                                }
                       }             
                    else if(listType == TS_DISABLATTRIBUTE)
                    {
                            //selValue=document.getElementById("auditconfig11:selectedItems2").value;
                            len=document.getElementById("auditconfig11:selectedItems2").length;
                            for(i=0;i<len;i++)
                               {

                                  if(document.getElementById("auditconfig11:selectedItems2").options[i].selected)
                                  {

                                    name=document.getElementById("auditconfig11:selectedItems2").options[i].text;
                                    id=document.getElementById("auditconfig11:selectedItems2").options[i].value;
                                    if(i==len-1)
                                    selValue+=name;
                                    else
                                    selValue+=name+",";

                                    }
                            }
                    }
                    
                    if(selValue =="")
                    {
                            alert(SELECT_AN_ITEM_FROM_THE_LIST);
                            return false;
                    }
                    else
                    {
                            document.getElementById("selectedAttribute").value = selValue;
							return true;
                    }
	}
	
        function handleEnter(e)
                {       
                    var browser=navigator.appName;
                    if(browser=="Netscape")
                    {

                               if(e.which == 13)
                               {       

                                    try
                                    {
                                        document.getElementById('auditconfig11:cmdRef').focus();
                                    }
                                    catch(e){
                                    }

                               }
                      }

                      else
                         {      
                            e=window.event;
                            if(e.keyCode == 13)
                                {
                                    try
                                    {                                    
                                        document.getElementById('auditconfig11:cmdRef').focus();
                                    }
                                    catch(e){
                                    }
                                }

                         }
                }
				function newfunc()
				{
			
				//document.forms["auditconfig11"].submit();
				}        

function submitforquicksearch()
            {
               
               document.getElementById("quicksearch:txtProcessVarName").value="";
               EnableDisableProcVarListButton("quicksearch");
            }
            function ShowProcVarList(ref,hidProcessName,hidProcessId,txtProcessVarName,hidProcVartype,hidProcVarName,txtProcessVarID,sysVarFlag,callBackFunction)
                        {
                        var formid=ref.form.id;
                        var procID="-1";
                        var procName="";
                        var tempSysVarFlag="N";
                        var tempTxtProcessVarID="";
                        if(sysVarFlag!=undefined)
                        {   //Change for Bug 56042 Starts here                          
                            procName= document.getElementById(formid+":"+hidProcessName).value;
                            tempSysVarFlag=sysVarFlag;
                        }else
                        {
                            procID= document.getElementById(formid+":"+hidProcessId).value;
                            procName= document.getElementById(formid+":"+hidProcessName).value;
                        }
                        var lastIndex = procName.lastIndexOf(" ");
                        if(lastIndex > 0) {
                            var versionValue = procName.substring(lastIndex + 1, procName.length);
                            if(versionValue.search("\\D") < 0) {
                                procName = procName.substring(0, lastIndex);
                            }
                        }
                        if(txtProcessVarID!=undefined)
                        {
                            tempTxtProcessVarID=txtProcessVarID;
                        }
                        if(callBackFunction== undefined)
                            {
                                callBackFunction='';
                            }
                        ShowPickList(ref,'WFProcVariablelist',txtProcessVarName,hidProcVartype,hidProcVarName,'0','-1','0',callBackFunction,procID,procName,tempTxtProcessVarID,tempSysVarFlag);

                   }
            function EnableDisableProcVarListButton(formId)
            {

                if(document.getElementById(formId+":hidProcessId").value > 0 )
                {
                    document.getElementById(formId+":cmdPicklist_ProcessVar").disabled=false;
                }
                else
                {
                    document.getElementById(formId+":cmdPicklist_ProcessVar").disabled=true;
                 }
            }       
           
    function removeqsv(ref)
    {

    var formId=ref.form.id;
    tableID=formId+":"+"qsearch";
    chkboxName=":chkBoxQsv";
    var chkBoxID=tableID+":";
    var jCount=0;
    rowCount=document.getElementById(tableID).rows.length ;
     for (var iCount=0;iCount < (rowCount-1) ;iCount++)
    {
       currentChkBoxID=chkBoxID + iCount +chkboxName ;
            try 
            {
                    if(document.getElementById(currentChkBoxID).checked)
                    {
                        jCount++;
                        document.getElementById("quicksearch:hiddeletedindex").value=iCount	
                        break;	
                     }

               }
            catch(e)
            {
                    //alert("Error in=="+iCount);
            }
            
    }

    if(jCount==0)
            {
                alert(SELECT_VARIABLE_TOREMOVE);
                return false;
            }
            return true;
    }
    function checkAdd(ref)
    {
      var txtVal=document.getElementById("quicksearch:txtProcessVarName").value;
      var txtaliasVal=document.getElementById("quicksearch:txtProcessVaraliasName").value;
     if(Trim(txtVal).length==0)
	  {
		alert(SELECT_PROC_VAR);
		return false;
	  }
      if(Trim(txtaliasVal).length==0)
      {
        alert(ALIAS_NO_SPECIFY_VALUE);
		return false;
      }
    try 
        {
     rowCount=document.getElementById("quicksearch:qsearch").rows.length ;
	 
     for (var iCount=0;iCount < (rowCount-1) ;iCount++)
    {
           var aliasTxtID="quicksearch:qsearch:"+iCount+":txtqsvalias";
		   
            try 
            {
                    if(Trim(document.getElementById(aliasTxtID).innerHTML)==Trim(txtaliasVal))
                    {
                        alert(ALIAS_NAME_ALREADY_EXIST);
                        return false;
                     }

               }
            catch(e)
            {
                    //alert("Error in=="+iCount);
            }
    }    
}
catch(e)
            {
}
      return true;
    }
	


function setUserPreferences(ref)
{
    var batchSize="";
    batchSize=document.getElementById("UserPref:BatchSize").value;

    if(isNaN(batchSize) || IsFloatVal(batchSize))
    {
        document.getElementById("UserPref:BatchSize").select();
        alert(VALID_INTEGER);
    }
    else
        NewSubmit(ref);

    return false;
} 

function EnableDisButtonProcessMgmt(ref)
{
    var formID=ref.form.id;
    var tableID=formID+":"+"dtprocess";
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;
    var EnableChangeStateButton="";
    var PendingActions="";
    try
    {
        var rowCount=document.getElementById(tableID).rows.length ;

        for (var iCount=0;iCount < (rowCount-1) ;iCount++)
        {
            currentChkBoxID=tableID+":" + iCount +chkboxName ;
            processIDId=tableID+":" + iCount +":procId";
            processNameId=tableID+":" + iCount +":procName";
            var PendingActionsID=tableID+":" + iCount +":hidPendingActions";
            try 
            {
                if(document.getElementById(currentChkBoxID).checked)
                {
                    noOfSelectedRows++;
                    PendingActions=document.getElementById(PendingActionsID).value
                    if(PendingActions.length>0 && PendingActions!="null" && PendingActions=="21")
                    {
                       EnableChangeStateButton="0" 
                    }
                    else if(EnableChangeStateButton!="0")
                    {
                        EnableChangeStateButton="1";
                    }
                 }

             }
            catch(e){}
        }

        var cmdchangeState=document.getElementById(formID+":cmdChangeProcessState");
        var cmdmanageProcess=document.getElementById(formID+":cmdManageProcess");
        var cmddefineTAT=document.getElementById(formID+":cmdDefineturnaroundtime");
        var cmddynamicConstants=document.getElementById(formID+":cmdDynamicConstants");
        var cmdContextName = document.getElementById(formID+":cmdContextName");
        if(EnableChangeStateButton=="1")
        {
            cmdchangeState.src='../omniflow/'+localizedPath+'images/changeState.gif';
            cmdchangeState.style.cursor = "pointer";
            cmdchangeState.disabled=false; 
        }
        else
        {
            cmdchangeState.src='../omniflow/'+localizedPath+'images/changeState_dis.gif';
            cmdchangeState.style.cursor = "none";
            cmdchangeState.disabled=true;
        }
        
        if(noOfSelectedRows<=1)
        {
            cmdmanageProcess.src='../omniflow/'+localizedPath+'images/manageProcess.gif';
            cmdmanageProcess.disabled=false; 
            cmddefineTAT.src='../omniflow/'+localizedPath+'images/defineTAT.gif';
            cmddefineTAT.disabled=false; 
            cmddynamicConstants.src='../omniflow/'+localizedPath+'images/dynamicConstants.gif';
            cmddynamicConstants.disabled=false; 
        }
        else
        {
            cmdmanageProcess.src='../omniflow/'+localizedPath+'images/manageProcess_dis.gif';
            cmdmanageProcess.disabled=true;
            cmddefineTAT.src='../omniflow/'+localizedPath+'images/defineTAT_dis.gif';
            cmddefineTAT.disabled=true;
            cmddynamicConstants.src='../omniflow/'+localizedPath+'images/dynamicConstants_dis.gif';
            cmddynamicConstants.disabled=true;
        }

        if(noOfSelectedRows == 1) {
            cmdContextName.src = '../omniflow/' + localizedPath + 'images/managecontextname.png';
            cmdContextName.disabled = false;
        } else {
            cmdContextName.src = '../omniflow/' + localizedPath + 'images/managecontextname_dis.png';
            cmdContextName.disabled = true;
        }
    }
        catch(e)
        {
                //alert("Error in=="+e);
        }  
}

//custom changes
function portalmanager()
{
    var Url="../portal/mainportal.faces?Action=1&Opt=11&PM_UID="+pm_uid;
    makeAjaxCall(Url,"ResultContainer","quicksearchresult","refreshQSVList()");
}	
function openwsdetails(ref)
{
    var formID=ref.form.id;
    var tableID=formID+":"+"dtprocess";
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;    
    var processIDId;
    var processNameId;
    var processID="";
    var processName="";
    try
    {
    var rowCount=document.getElementById(tableID).rows.length ;
    for (var iCount=0;iCount < (rowCount-1) ;iCount++)
    {
        currentChkBoxID=tableID+":" + iCount +chkboxName ;
        processIDId=tableID+":" + iCount +":procId";
        processNameId=tableID+":" + iCount +":procName";
        try 
        {
            if(document.getElementById(currentChkBoxID).checked)
            {
                noOfSelectedRows++;
                processID=document.getElementById(processIDId).value;
                processName=document.getElementById(processNameId).value;
             }

         }
        catch(e)
        {
                //alert("Error in=="+iCount);
        }
    }
    }
    catch(e)
        {
                //alert("Error in=="+iCount);
        }
    if(noOfSelectedRows>1)
    {
       alert(INVALID_SELECTION_MULTIPLE);
       return false;
    }  
        
   var Url="../processmgmt/wsdetails.faces?newPage=true&Opt=4"+"&procName="+encode_utf8(processName)+"&procId="+encode_utf8(processID);
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    var win = window.open(Url,"wsdetails"+UniqueUserId,'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
}

/**
 *  This function is used to open Share Point Document Library info window
 */
function openDocLibinfo() {
    var Url="../spdms/spdoclibinfo.faces";
    Url = appendUrlSession(Url);
    
    var WindowHeight=window1H;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(screen.width/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(screen.height/2)-parseInt(WindowHeight/2);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("Action",encode_ParamValue("1")));
    
    var win = openNewWindow(Url,"doclibinfo"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
}

//custom code changes starts
function APChecklistportal()
{
    var Url="../portal/APCheckListMaster/Checklist.faces?Action=1&Opt=11&PM_UID="+pm_uid;
	window.open("..//portal//APCheckListMaster//Checklist.jsp","APCHECKLISTMASTER","location=0,toolbar=0,menubar=0,resizable=0,width=670,height=520");
}
//custom code changes ends
function SharePoint()
{
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    var listParam=new Array();
    listParam.push(new Array("Action","1"));
    var Url= "/processmanager/spdms/spinfo.faces";
    var wFeatures = 'height='+(WindowHeight-90)+',width='+(WindowWidth-150)+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var win = openNewWindow(Url,"Sharepoint",wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addLaunchWindows(win);
    }
        catch(e)
        {}
}

        function saveMultiLingualVars()
            {
                try
                {
                   // alert('saveMultiLingualVars ');
                  //  if(document.getElementById('multilingual:btnApply'))
                 //   alert('element '+(document.getElementById('multilingual:btnApply')));
                    clickLink('multilingual:btnApply');
                    
                  //   alert('saveMultiLingualVars again');
                }catch(e){}
                return false;
            } 
function openProcessCombo()
{
   
    var formID="purgemgt";
    var pidlist= new Array();
    var tableID=formID+":"+"purgeLists";
    try
    {
        var rowCount=document.getElementById(tableID).rows.length ;
        var processIDId;
        var name;
     
        for (var iCount=0;iCount < (rowCount-1) ;iCount++)
        {
               
                processIDId=tableID+":" + iCount +":ProcessDefId";
                name = tableID+":" + iCount +":ProcessDefId";
                
                pidlist +=document.getElementById(processIDId).value+",";
        }
     }
     catch(e)
     {
                 //alert("Error in=="+iCount);
      }
     var Url="../processmgmt/exportcriteria.faces";
     Url = appendUrlSession(Url);
     var ScreenHeight=screen.height;
     var ScreenWidth=screen.width;
     var WindowHeight=window1H+125;
     var WindowWidth=window1W;
     var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);

     var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
        WindowTop=WindowTop/2;

     var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;


     var listParam=new Array();
     listParam.push(new Array("operation",encode_ParamValue("I")));
     listParam.push(new Array("pidList",encode_ParamValue(pidlist)));

     var win = openNewWindow(Url,"exportcriteria"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
     try
     {
        addWindows(win);
     }
     catch(e)
     {}
}

function openSetContextWin(ref) {
    var formID = ref.form.id;
    var tableID = formID + ":" + "dtprocess";
    var chkboxName = ":chkBox";
    var noOfSelectedRows = 0;
    var processID = "";
    var processName = "";
    var processContext = "";
    try {
        var rowCount = document.getElementById(tableID).rows.length ;
        var processIDId;
        var processNameId;
        var processContextId;
        for (var iCount = 0; iCount < (rowCount-1); iCount++) {
            currentChkBoxID = tableID + ":" + iCount + chkboxName ;
            processIDId = tableID + ":" + iCount + ":procId";
            processNameId = tableID + ":" + iCount + ":procName";
            processContextId = tableID + ":" + iCount + ":procContext";
            try {
                if(document.getElementById(currentChkBoxID).checked) {
                    noOfSelectedRows++;
                    processID = document.getElementById(processIDId).value;
                    processName = document.getElementById(processNameId).value;
                    processContext = document.getElementById(processContextId).value;
                }
            } catch(e) {
            }
        }
    } catch(e) {
    }
    if(noOfSelectedRows > 1) {
        alert(INVALID_SELECTION_MULTIPLE);
        return false;
    }

    var Url = "../processmgmt/processcontext.faces";
    Url = appendUrlSession(Url);
    var ScreenHeight = screen.height;
    var ScreenWidth = screen.width;
    var WindowHeight = window1H;
    var WindowWidth = window1W;
    var WindowLeft = parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop = parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

    var wFeatures = 'height=' + WindowHeight + ',width=' + WindowWidth + ',resizable=0,status=1,scrollbars=0,top=' + WindowTop + ',left=' + WindowLeft;

    var listParam = new Array();
    listParam.push(new Array("procName", encode_ParamValue(processName)));
    listParam.push(new Array("procId", encode_ParamValue(processID)));
    listParam.push(new Array("procContext", encode_ParamValue(processContext)));

    var win = openNewWindow(Url, "processmanagement" + UniqueUserId, wFeatures, true, "Ext1", "Ext2", "Ext3", "Ext4", listParam);
    try {
        addWindows(win);
    } catch(e) {
    }
}

function clearQueueUGInfoMap() {
    try {
        var url = "../queuemgmt/clearUGInfoMap.faces?PM_UID="+pm_uid;
        var xhttp;
        if (window.XMLHttpRequest) {
            xhttp = new XMLHttpRequest();
        } else {
            xhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xhttp.open("GET", url, false);
        xhttp.send();
    } catch(exc) {
    }
}

//custom code changes starts
function VSChecklistportal()
{
    var Url="../portal/VSCheckListMaster/Checklist.faces?Action=1&Opt=11&PM_UID="+pm_uid;
	window.open("..//portal//VSCheckListMaster//Checklist.jsp","VSCHECKLISTMASTER","location=0,toolbar=0,menubar=0,resizable=0,width=670,height=520");
}
//custom code changes ends

function ESChecklistportal()
{
    var Url="../portal/ESCheckListMaster/Checklist.faces?Action=1&Opt=11&PM_UID="+pm_uid;
	window.open("..//portal//ESCheckListMaster//Checklist.jsp","ESCHECKLISTMASTER","location=0,toolbar=0,menubar=0,resizable=0,width=670,height=520");
}
//custom code changes ends
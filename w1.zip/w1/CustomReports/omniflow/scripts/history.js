/*-----------------------------------------------------------------------------------------------------

File Name			: history.js
Author                          : Ajith Jacob
Date written (DD/MM/YYYY)       : 11/Jan/2007
Description			: This file contains the methods for handling the events from Audit Log.
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date(DD/MM/YYYY)		Change By               Change Description (Bug No. (If Any))
----------------------------------------------------------------------------------------------------
21/04/2007                  Arup Sharma                 BUG 550 (session id appended in all the window.open url's by calling method :appendUrlSession())
30/04/2014                  Sandeep Tonger              Bug 45001 - Add new action ids, handle also at front end configuration screen and history generation functionality.

----------------------------------------------------------------------------------------------------*/
function SelectTabAl(iTabIndex)
{
    try
    {
        document.getElementById("AuditLogFilter:SelTab").value=iTabIndex;
        document.getElementById("AuditLogFilter:HidItemName").value="";
        document.getElementById("AuditLogFilter:ItemID").value=0;
        document.getElementById("AuditLogFilter:cmbOperations").selectedIndex=0;
        document.getElementById("AuditLogFilter:hid_strAction").value="0"; 
        document.getElementById("AuditLogFilter:HidOperation").value="";
        clickLink('AuditLogFilter:cmdbtn_resetDateFilter');  
    }
    catch(e){}
    //window.document.location=url;
   // document.forms["AuditLogFilter"].submit();
}

function generateLog()
{	
        var FromDay = document.getElementById("AuditLogFilter:cmbFromDay").options[document.getElementById("AuditLogFilter:cmbFromDay").selectedIndex].value;
	var FromMonth = document.getElementById("AuditLogFilter:cmbFromMonth").options[document.getElementById("AuditLogFilter:cmbFromMonth").selectedIndex].value;
	var FromYear = document.getElementById("AuditLogFilter:cmbFromYear").options[document.getElementById("AuditLogFilter:cmbFromYear").selectedIndex].value;
	var ToDay = document.getElementById("AuditLogFilter:cmbToDay").options[document.getElementById("AuditLogFilter:cmbToDay").selectedIndex].value;
	var ToMonth = document.getElementById("AuditLogFilter:cmbToMonth").options[document.getElementById("AuditLogFilter:cmbToMonth").selectedIndex].value;
	var ToYear = document.getElementById("AuditLogFilter:cmbToYear").options[document.getElementById("AuditLogFilter:cmbToYear").selectedIndex].value;

        if(!VerifyDate(FromYear,FromMonth,FromDay))
            {
                alert(INVALID_FROM_DATE);
                return false;
            }
           
        if(!VerifyDate(ToYear,ToMonth,ToDay))
            {
                alert(INVALID_TO_DATE);
                return false ;    
            }
            
	if(new Date(FromYear,FromMonth-1,FromDay) > new Date())
	{
		alert(DATE_VALIDATION_MSG_1);
		document.getElementById("AuditLogFilter:cmbFromDay").focus();
		document.getElementById("AuditLogFilter:cmbFromDay").blur();
		return false;
	}
        
	else if(new Date(ToYear,ToMonth-1,ToDay) > new Date())
	{	
		alert(DATE_VALIDATION_MSG_2);
		document.getElementById("AuditLogFilter:cmbToDay").focus();
		document.getElementById("AuditLogFilter:cmbToDay").blur();
		return false;
		
	}
	else if(new Date(FromYear,FromMonth-1,FromDay) > new Date(ToYear,ToMonth-1,ToDay))
	{	
		alert(DATE_VALIDATION_MSG_3);
		document.getElementById("AuditLogFilter:cmbToDay").focus();
		document.getElementById("AuditLogFilter:cmbToDay").blur();
		return false;
	}

	var ToDate = ToYear + "-" + ToMonth +"-"+ToDay + " 23:59:59";
	var FromDate = FromYear + "-" + FromMonth +"-"+FromDay + " 00:00:00";
	var Tab="Q";
	
	var OptionIndex=document.getElementById("AuditLogFilter:ItemID").value;
	var OptionValue=document.getElementById("AuditLogFilter:HidItemName").value;
	var operationId=document.getElementById("AuditLogFilter:cmbOperations").options[document.getElementById("AuditLogFilter:cmbOperations").selectedIndex].value;

        if(OptionIndex==0)
        {            
            if(document.getElementById("AuditLogFilter:SelTab").value=="1" ) //Q
            {                
                alert(NO_QUEUE_SELECTED);
            }
            else if(document.getElementById("AuditLogFilter:SelTab").value=="2")//P
            {
                alert(NO_PROCESS_SELECTED);
            }
            else if(document.getElementById("AuditLogFilter:SelTab").value=="3")//U
            {
                alert(NO_USER_SELECTED);
            }
            else if(document.getElementById("AuditLogFilter:SelTab").value=="4")//C
            {
                alert(NO_USER_SELECTED);
            }
            return false;
        }

        
	if(document.getElementById("AuditLogFilter:SelTab").value=="1" ) //Q
	{	
		Tab="Q";
	}
	else if(document.getElementById("AuditLogFilter:SelTab").value=="2")//P
	{	
		Tab="P";
	}

	else if(document.getElementById("AuditLogFilter:SelTab").value=="3")//U
	{
		Tab="U";
	}
	else if(document.getElementById("AuditLogFilter:SelTab").value=="4")//C
	{
		Tab="C";
	}
	
	
        document.getElementById("AuditLogFilter:hid_strAction").value="1";
        document.getElementById("AuditLogFilter:hid_Option").value=Tab;
        document.getElementById("AuditLogFilter:hid_OptionIndex").value=OptionIndex;
        document.getElementById("AuditLogFilter:hid_OptionValue").value=OptionValue;
        document.getElementById("AuditLogFilter:hid_FromDate").value=FromDate;
        document.getElementById("AuditLogFilter:hid_ToDate").value=ToDate;
        document.getElementById("AuditLogFilter:hid_OperationID").value=operationId;
        document.getElementById("AuditLogFilter:HidOperation").value=operationId;
        //document.forms["AuditLogFilter"].submit();
        return true;
}


function SaveThisPage()
{
   ClickAnotherLink(document,'cmdlink_save');  
}

function SaveAuditLog()
{
    var ctrlname= document.getElementById("WithSavePrint:cmdlink_TitleSave");
    var posLeft = ctrlname.offsetLeft+525;
    var posTop = ctrlname.offsetTop+110;    
    var MenuDivCtrl = document.getElementById("historySaveOpt");            
    
    MenuDivCtrl.style.visibility = 'visible';
    MenuDivCtrl.style.left = posLeft;
    MenuDivCtrl.style.top = posTop;
}

function hideHistorySaveOpt()
 {
     document.getElementById("historySaveOpt").style.visibility = 'hidden';
     
}

function nextPreviousBatch()
      {
        document.getElementById("AuditLogFilter:hid_strAction").value="False";
      }
      
      function setOperation()
      {
            var selectedOperation=document.getElementById("AuditLogFilter:HidOperation").value;
            if(selectedOperation.length!=0)
            document.getElementById("AuditLogFilter:cmbOperations").value = document.getElementById("AuditLogFilter:HidOperation").value;
      }


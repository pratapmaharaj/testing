/*


		File            :       net.js
		Purpose         :       Contains the functions related to Ajax Calls

		Change History  :

		Problem No        Correction Date	Comments
		-----------       ----------------	----------
		12514               20/Apr/2010         Processmanager progress bar is displayed continously after logging in  
*/
/*
url-loading object and a request queue built on top of it
*/

/* namespacing object */
var net=new Object();

net.READY_STATE_UNINITIALIZED=0;
net.READY_STATE_LOADING=1;
net.READY_STATE_LOADED=2;
net.READY_STATE_INTERACTIVE=3;
net.READY_STATE_COMPLETE=4;
net.INDICATORID='handlerCall';

/*--- content loader object for cross-browser requests ---*/
net.ContentLoader=function(url,onload,onerror,method,params,indicatorId,async,contentType){
    url = appendUrlSessionAjax(url);

    if(url.indexOf("?")>0)
	{
		url=url + "&sid="+ Math.random();
	}
	else
	{
		url=url + "?sid="+ Math.random();
	}
    var ret=null;

    if(indicatorId == null || indicatorId == undefined || indicatorId == '')
    {
        net.INDICATORID='handlerCall';
        createIndicator("handlerCall");
    }
    else
    {
        net.INDICATORID=indicatorId;
        createIndicator(indicatorId);
    }
    this.req=null;
    this.onload=onload;
    this.onerror=(onerror) ? onerror : this.defaultError;
    this.loadXMLDoc(url,method,params,async,contentType);
}

net.ContentLoader.prototype.loadXMLDoc=function(url,method,params,async,contentType)
{
  if (!method)
    {
        method="GET";
    }
  if (!contentType && method=="POST")
    {
        contentType='application/x-www-form-urlencoded';
    }
  if (window.XMLHttpRequest)
    {
        this.req=new XMLHttpRequest();
    } 
    else if (window.ActiveXObject)
    {
        this.req=new ActiveXObject("Microsoft.XMLHTTP");
    }
    if (this.req)
    {
   	try
        {
            var loader=this;
            this.req.onreadystatechange=function()
            {
                net.ContentLoader.onReadyState.call(loader);
            }
            if(async == null)
                async = true;
            this.req.open(method,url,async);
            if (contentType)
            {
                this.req.setRequestHeader('Content-Type', contentType);
            }
            this.req.send(params);
        }catch (err)
        {
          this.onerror.call(this);
        }
    }

}

net.ContentLoader.onReadyState=function()
{
  try
    {
        var req=this.req;
        var ready=req.readyState;
        if (ready==net.READY_STATE_COMPLETE)
        {
            var httpStatus=req.status;
            if (httpStatus==200 || httpStatus==0)
            {
                this.onload.call(this);
            }else
            {        
                this.onerror.call(this);     
            }
            removeIndicator(net.INDICATORID);
        }
    }
    catch(e)
    {
    }
}

net.ContentLoader.prototype.defaultError=function(){
    removeIndicator(net.INDICATORID);
if(this.req.status==250)
{       
   // generateErrorAjaxCalls(this.req.getResponseHeader("ErrorMsg"));
}        
else
{
   
    alert(ERROR_DATA);    
}
}






/*-----------------------------------------------------------------------------------------------------

File Name			: view.js
Author                          : Sachin Agrawal
Date written (DD/MM/YYYY)       : 30/Jan/2007
Description			: This file contains the methods for handling the events from workaudit.
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date(DD/MM/YYYY)    Change By               Change Description (Bug No. (If Any))
----------------------------------------------------------------------------------------------------
21/04/2007          Arup Sharma             BUG 550 (session id appended in all the window.open url's by calling method :appendUrlSession())
27/01/2010          Puneet Pahuja           (PRM_8.0_037) window.open changed to openNewWindow to open new window using HTTP POST
29/04/2010          Himshikha               (12605) first value is selected in %age audit combo, when modify the audit set.
21/10/2014          Jaseem Ansari            Bug 51389 - username,auditorname activityname required in WFSetUserWorkAudit call. (edit)
----------------------------------------------------------------------------------------------------*/

function EnableDisableWorkstepButton()
{
     
    //alert("inside on change");
    if(document.getElementById('addModifyaudit:hidProcessId').value > 0 )
    {
        document.getElementById('addModifyaudit:cmdPicklist_workstep').disabled=false;
    }
    else
    {
        document.getElementById('addModifyaudit:cmdPicklist_workstep').disabled=true;
    }

    document.getElementById('addModifyaudit:hidWorkstepID').value=' ';
    document.getElementById('addModifyaudit:hidWorkstepName').value=' ';
    document.getElementById('addModifyaudit:txtWorkstepName').value=' ';
}

//purpose to open a window that will enable the user to add a audit
function AddAudit(ref,userid,username)
{
    var procActidlist=getProcActList(ref);
    var url="../usermgmt/addworkaudit.faces";

    var WindowHeight=300;
    var WindowWidth=ScreenWidth/2;
    
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    
    url = appendUrlSession(url);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=auto,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("userid",encode_ParamValue(userid)));
    listParam.push(new Array("username",encode_ParamValue(username)));
    listParam.push(new Array("constraints",encode_ParamValue(procActidlist)));

    var win = openNewWindow(url,'workaudit_add'+userid+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
	addWindows(win);
    }
    catch(e)
    {}    
}

//enumerates the constraints list for add audit
function getProcActList(ref)
{
    var tableid="workaudits"+":audits";
    var list='';
    try 
    {
        var noofrows = document.getElementById(tableid).rows.length;
        for (var i=0;i< noofrows-1 ;i++)
        {
            var procid = tableid+':'+i+':procid';
            var actid = tableid+':'+i+':actid';
            
            if(i!=0)
                list+=";";

            //list+=document.getElementById(procid).value;
            //list+=":"+document.getElementById(actid).value;
            list+=MakeProcActList(document.getElementById(procid).value,document.getElementById(actid).value);
            
        }

        return list;
    }
    catch(e)
    {
        
        return "";
    }

}


function CloseAddWorkAudit(ref)
{
    //need to refresh the parent window
    try  {
        window.opener.Refresh(window.opener.document);
    }
    catch(e)
    {}
    window.close();
}

function CloseModifyWorkAudit(ref)
{
    //need to refresh the parent window
    try  {
        window.opener.Refresh(window.opener.document);
    }
    catch(e)
    {}
    window.close();
}

function Refresh(ref)
{
    ref.forms[0].submit();
}

//called from modify constraints
function VerifyModification(ref)
{
    var audid=document.getElementById('addModifyaudit:hidAuditorId').value;
    try
    { 
        if(audid <= 0 ) 
        {
            alert(SELECT_AUDITOR);
            return false;
        }
    }
    catch(e)
    {
        alert(SELECT_AUDITOR);
        return false;
    }

    return true;
}

//does opposite of the getProcActList and
//verify the current processid and actid is already selected called from addconstraint
function VerifyConstraints(ref)
{
    var actid=document.getElementById('addModifyaudit:hidWorkstepID').value;
    var procid=document.getElementById('addModifyaudit:hidProcessId').value;
    var audid=document.getElementById('addModifyaudit:hidAuditorId').value;
    try 
    {
        if(procid<=0)
            {
                alert(SELECT_PROCESS);
                return false;
            }
    }
    catch(e)
    {
            alert(SELECT_PROCESS);
            return false;
    }

    try
    { 
        if(actid <= 0 ) 
        {
            alert(SELECT_WORKSTEP);
            return false;
        }
    }
    catch(e)
    {
        alert(SELECT_WORKSTEP);
        return false;
    }

    try
    { 
        if(audid <= 0 ) 
        {
            alert(SELECT_AUDITOR);
            return false;
        }
    }
    catch(e)
    {
        alert(SELECT_AUDITOR);
        return false;
    }
    
    var constraints= document.getElementById("constraints").value;
    
    if(Trim(constraints).length ==0)
    {
        //modify the current constraint list 
         constraints=MakeProcActList(procid,actid); 
        document.getElementById("constraints").value = constraints;
        return true;
    }
        
    var list = constraints.split(';');
    
    var iConstLength = list.length;
    var curprocid=-1;
    var curactid=-1;
    
    for(var count=0; count < iConstLength ; count++)
    {
        var curConst= list[count].split(':');
        curprocid= curConst[0];
        curactid = curConst[1];
        if(curprocid == procid && curactid==actid)
            {
                alert(INVALID_WORKSTEP_PROCESS_COMBO);
                return false;
            }
    }
    
    
    constraints+=';'+MakeProcActList(procid,actid);
    document.getElementById("constraints").value = constraints;
    return true;
}

//to make the proc act list constraint
function MakeProcActList(procid,Actid)
{
    return procid+':'+Actid;
}

//called from
function RemoveLastConstraint(ref)
{
    var constraints= document.getElementById("constraints").value;
    var list = constraints.split(';');
    var index = constraints.lastIndexOf(';');
    
    if(index > 0)
    {
        contraints=constraints.substring(0,index);
    }
    else
    {
        constraints='';
    }
    document.getElementById("constraints").value = constraints; 
}


//purpose to open a window that will enable a user to modify an audit
function ModifyAudit(ref,userid,username)
{
    var formid='workaudits';
    var index=GetSelected(ref);
    if(index < 0) //in case of invalid selection or multiple selection
      {
        return "";
      }
    
    var   procid=document.getElementById(  formid+':audits:'+index+':procid').value;
    var    actid=document.getElementById(   formid+':audits:'+index+':actid').value; 
    var procname=Trim(document.getElementById(formid+':audits:'+index+':procname').innerHTML);
    var  actname=Trim(document.getElementById( formid+':audits:'+index+':actname').innerHTML);

    var  audname=Trim(document.getElementById( formid+':audits:'+index+':audname').innerHTML);
    var    audid=document.getElementById(   formid+':audits:'+index+':audid').value;
    var   audper=Trim(document.getElementById(formid+':audits:'+index+':peraudit').innerHTML);    

    var url="../usermgmt/modifyworkaudit.faces";

    //alert(url);
    var WindowHeight=300;
    var WindowWidth=ScreenWidth/2;
    
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    url = appendUrlSession(url);

    var listParam=new Array();    
    listParam.push(new Array("userid",encode_ParamValue(userid)));
    listParam.push(new Array("username",encode_ParamValue(username)));
    listParam.push(new Array("processname",encode_ParamValue(procname)));
    listParam.push(new Array("processid",encode_ParamValue(procid)));
    listParam.push(new Array("activityname",encode_ParamValue(actname)));
    listParam.push(new Array("activityid",encode_ParamValue(actid)));
    listParam.push(new Array("auditorid",encode_ParamValue(audid)));
    listParam.push(new Array("auditorname",encode_ParamValue(audname)));
    listParam.push(new Array("percentageaudit",encode_ParamValue(audper)));

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=auto,top='+WindowTop+',left='+WindowLeft;

    var win = openNewWindow(url,'workaudit_mod'+userid+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
	addWindows(win);
    }
    catch(e)
    {}
}
//call to delete an audit
function DeleteAudit(ref,link,addurl)
{
   //adding parameters to list
   var index=GetSelected(ref);
   
   if(index < 0) //in case of invalid selection or multiple selection
    {
      return "";
    }
    
   var formid='workaudits';
   var   procid=document.getElementById(  formid+':audits:'+index+':procid').value;
   var    actid=document.getElementById(   formid+':audits:'+index+':actid').value;
   var  actname=Trim(document.getElementById( formid+':audits:'+index+':actname').innerHTML);

   document.getElementById(formid+':deleteProcIndex').value=procid;
   document.getElementById(formid+':deleteActIndex').value=actid;
    document.getElementById(formid+':deleteActivityName').value=actname;

   ClickAnotherLink(ref,link);
}

function GetSelected(ref)
{
    var formid='workaudits';
    var tableid=formid+':audits';    
    try 
    {
        var noofrows = document.getElementById(tableid).rows.length;
        var flag=0;
        var iNum=0;
        var iSelIndex=-1;
        
        
        for (var i=0;i< noofrows-1 ;i++)
        {
            var id=tableid+':'+i+':chkBox';
            var curElement=document.getElementById(id);
            if(curElement.checked)
              {
                iNum++ ;
                iSelIndex=i;
              }
        }
        
        if(iNum ==1)
            return iSelIndex;
        else
            {
                if(iNum < 1)
                    alert(INVALID_SELECTION_NONE);
                else
                    alert(INVALID_SELECTION_MULTIPLE);
                return -1;
            }   
    }
    catch(e)
    {
        //alert(e);
        return -1;
    }

}
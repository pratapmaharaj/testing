/*-----------------------------------------------------------------------------------------------------

File Name			: addusertoqueue.js
Author                          : Sachin Agrawal
Date written (DD/MM/YYYY)       : 16/Feb/2007
Description			: This file contains the methods for handling the events of addusertoqueue window
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date(DD/MM/YYYY)		Change By               Change Description (Bug No. (If Any))
----------------------------------------------------------------------------------------------------
17/04/2006                  Puneet Pahuja              BUG ID 614 (alert removed)
----------------------------------------------------------------------------------------------------*/

function EnableDisableFilter()
{
    var queType=document.getElementById('addqueue:hidQueueType').value;
    if(queType=='F' || queType=='N' || queType=='I' || queType=='Q')
    {
       document.getElementById('addqueue:txtFilter').disabled=false;     
    }
    else
    {
        document.getElementById('addqueue:txtFilter').disabled=true;
    }    
}

function EnableDisableDatePicker(formid,comp1,comp2,comp3,value)
{
	if(value==1)
        {
            document.getElementById(formid+":"+comp1).disabled=false;
            document.getElementById(formid+":"+comp2).disabled=false;
            document.getElementById(formid+":"+comp3).disabled=false;
        }
       else
        {
            document.getElementById(formid+":"+comp1).disabled=true;
            document.getElementById(formid+":"+comp2).disabled=true;
            document.getElementById(formid+":"+comp3).disabled=true;
        }
}

function Verify(ref)
{
    
    var val = document.forms['addqueue']['addqueue:assType'][0].checked;
    var val2 = document.getElementById('addqueue:hidQueueId').value;
	    
    try {        
        if(val2<=0)
         { 
            alert(NO_QUEUE_SELECTED);
            return false;
         }        
    }catch(e)
    {   
        alert(NO_QUEUE_SELECTED);    
        return false;
    }

    if(!val)
    {
        var FromDay = document.getElementById("addqueue:daypicker").options[document.getElementById("addqueue:daypicker").selectedIndex].value;		
        var FromMonth = document.getElementById("addqueue:monthpicker").options[document.getElementById("addqueue:monthpicker").selectedIndex].value;
        var FromYear = document.getElementById("addqueue:yearpicker").options[document.getElementById("addqueue:yearpicker").selectedIndex].value;   

        if(!VerifyDate(FromYear,FromMonth,FromDay))
        {
            alert(INVALID_FROM_DATE);
            return false;
        }
       date1 = new Date(FromYear,FromMonth-1,FromDay);
       date2 = new Date();
        if(date1 < date2)
        {
                if(!((date1.getDate()==date2.getDate())&&(date1.getMonth()==date2.getMonth())&&(date1.getYear()==date2.getYear())))
                {
                         alert(DATE_VALIDATION_MSG_6);		
                        return false;
                }
        }
        /*if(new Date(FromYear,FromMonth-1,FromDay-1) < new Date())
        {
            alert(DATE_VALIDATION_MSG_5);		
            return false;
        }*/
    }    
    
    return true;
}
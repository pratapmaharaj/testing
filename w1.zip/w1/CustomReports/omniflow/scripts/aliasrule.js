/*-----------------------------------------------------------------------------------------------------

File Name			: aliasrule.js
Author                          : Indraneel Dasgupta
Date written (DD/MM/YYYY)       : 19/01/2010
Description			: This file is used for defining alias rule.
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date(DD/MM/YYYY)		Change By               Change Description (Bug No. (If Any))
----------------------------------------------------------------------------------------------------
19/01/2010                  Indraneel                   PRM_8.0_036 Option for adding rule defination on queue Aliases to display the row color of workitem list  in webdesktop
23/08/2011                Anushree Jain	            Bug 27971 Security issue
14/09/2011                Anushree Jain	            Bug 28348-Provide external queue variable mapping
15/10/2014                  Jaseem Ansari           Bug 50790 - Wrong iframes are getting opened in process variable mapping
28/01/2016                  Ashutosh Pandey         Bug 58796 - Need to change the color of workitem on hour basis
----------------------------------------------------------------------------------------------------*/
 
function openColorPicklist(ref)
          { 
  
            var strId=ref.id;
            strId=strId.substring(0,strId.lastIndexOf(":")+1); 
            var targetDispId="";
            var targetHidId="";
            var radioId=strId+"radioCI";
            var isIE=(navigator.appName.indexOf("Microsoft") != -1)?true:false;
            var radioIndex;  
            if(isIE ){
        if(getIEVersion()==10 )
            radioIndex=0;
        else
            radioIndex=1;
    }
            else
                 radioIndex=0; 
           if(document.getElementsByName(radioId)[radioIndex].checked==true){
                 targetDispId=strId+"bgcolortxtbox";
                 targetHidId=strId+"hidbgcolortxtbox";
                 var Url = "../application/colorpicklist.faces?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&PM_UID="+pm_uid;
                 createIFrame('ColorPicklist','230',Url,targetDispId,true,230);   
           }else{  
                 targetDispId=strId+"selImage";
                 targetHidId=strId+"hidbgcolortxtbox";
                 var Url = "../application/imagepicklist.faces?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&PM_UID="+pm_uid;
                 createIFrame('ImagePickList','200',Url,targetDispId,true,150);   
           }
          }
function dataTableSelectOneRadio(radio) { 
        var id = radio.name.substring(radio.name.lastIndexOf(':')); 
         try
            {
            window.parent.document.getElementById(TargetHidId).value=radio.value;  
            }catch(e){}
            try
            { 
            window.parent.document.getElementById(TargetDispId).src="../omniflow/aliasimages/"+radio.value;
            }catch(e){} 
      
        var el = radio.form.elements; 
           
        for (var i = 0; i < el.length; i++) { 
                el[i].checked = false; 
        } 
        radio.checked = true;
        removeIFrame(CurrentPickListId);
       //document.getElementById('cab_form:hiddenVar').value=radio.value;
    }
function setInputValue(){
    var radioIndex;  
    var isIE=(navigator.appName.indexOf("Microsoft") != -1)?true:false;
    if(isIE)
     radioIndex=1;
    else
     radioIndex=0;
    for(j=0;j<5;j++){
     document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleVar").value=""; 
     document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").value="";
     
     document.getElementsByName("frmProcVarMapping:rulelist:"+j+":radioCI")[radioIndex].checked="true";
     document.getElementById("frmProcVarMapping:rulelist:"+j+":bgcolortxtbox").className="PMbgcolorWhite";
     document.getElementById("frmProcVarMapping:rulelist:"+j+":selImage").src="../omniflow/aliasimages/transparent.gif";
     document.getElementById("frmProcVarMapping:rulelist:"+j+":hidbgcolortxtbox").value="";
     document.getElementById("frmProcVarMapping:rulelist:"+j+":rlueButton").disabled=true;
     document.getElementById("frmProcVarMapping:rulelist:"+j+":chkAliasRule").checked=false;
     document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").disabled=false;
     document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleVar1").value="";
     document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").value="";
     document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").value="";
     document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").value="";
     
   }
    document.getElementsByName("frmProcVarMapping:otherRadioCI")[radioIndex].checked="true";
    document.getElementById("frmProcVarMapping:otherBgcolortxtbox").className="PMbgcolorWhite";
    document.getElementById("frmProcVarMapping:otherImage").src="../omniflow/aliasimages/transparent.gif";
    document.getElementById("frmProcVarMapping:otherHidbgcolortxtbox").value=""; 
    document.getElementById("frmProcVarMapping:OtherRlueButton").disabled=true;
   document.getElementById("frmProcVarMapping:chkOtherRule").checked=false;
   var selectedVarName= document.getElementById("frmProcVarMapping:selectedVarName").value;
   var selectedVarType= document.getElementById("frmProcVarMapping:selectedVarType").value;
    for(j=1;j<5;j++){
       if(selectedVarType=='8'){
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue").value=REPORT_TODAY;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").value=REPORT_TODAY;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue1").value=REPORT_TODAY;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").value=REPORT_TODAY;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue1").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator1").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator1").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator1").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator1").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar1").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType1").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").disabled=false;
       }
       else if(selectedVarType=='10'){
         document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator1").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator1").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":chkAliasRule").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator1").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator1").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue1").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar1").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType1").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").disabled=true;
       }
        else{ 
            document.getElementById("frmProcVarMapping:rulelist:"+j+":chkAliasRule").disabled=false;
            document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator1").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator1").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar1").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator").disabled=false;
            document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator1").disabled=false;
            document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator").disabled=false;
            document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator1").disabled=false;
            document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue1").disabled=false;
            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").disabled=false;
            document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType1").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").disabled=true;
       }
     }
    
   if(selectedVarName.indexOf("VAR_")==-1){
     
    }
        for(i=0;i<5;i++)
        {
      document.getElementById("frmProcVarMapping:rulelist:"+i+":ruleVar").value= selectedVarName;
      document.getElementById("frmProcVarMapping:rulelist:"+i+":ruleVar1").value= selectedVarName;
        }
   }

function changeCIRadio(ref){  
    var strId=ref.name;
    strId=strId.substring(0,strId.lastIndexOf(":")+1);  
    var colorGrid=strId+"bgcolortxtbox";
    var imageGrid=strId+"selImageGrid";
    document.getElementById(colorGrid).className="PMbgcolorWhite";
    document.getElementById(strId+"selImage").src="../omniflow/aliasimages/transparent.gif";
    document.getElementById(strId+"hidbgcolortxtbox").value="";
   if(ref.value==1){
     document.getElementById(imageGrid).style.display="none";
     document.getElementById(colorGrid).style.display="inline";  
  }
else{
     document.getElementById(colorGrid).style.display="none";
     document.getElementById(imageGrid).style.display="inline";
}
   
}

 function openOtherColorPicklist(ref)
          {  
             
    var targetDispId="";
    var targetHidId="";
    var radioId=ref;
    var isIE=(navigator.appName.indexOf("Microsoft") != -1)?true:false;
    var radioIndex;
    if(isIE ){
        if(getIEVersion()==10 )
            radioIndex=0;
        else
            radioIndex=1;
    }
    else
        radioIndex=0;
           if(document.getElementsByName(radioId)[radioIndex].checked==true){
                 targetDispId="frmProcVarMapping:otherBgcolortxtbox";
                 targetHidId="frmProcVarMapping:otherHidbgcolortxtbox";
                 var Url = "../application/colorpicklist.faces?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&PM_UID="+pm_uid;
                 createIFrame('ColorPicklist','230',Url,targetDispId,true,230);   
           }else{  
                 targetDispId="frmProcVarMapping:otherImage";
                 targetHidId="frmProcVarMapping:otherHidbgcolortxtbox";
                 var Url = "../application/imagepicklist.faces?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&PM_UID="+pm_uid;
                 createIFrame('ImagePickList','200',Url,targetDispId,true,150);   
           }
          }
function changeOtherCIRadio(ref){   
    var colorGrid="frmProcVarMapping:otherBgcolortxtbox";
    var imageGrid="frmProcVarMapping:otherImageGrid";
    document.getElementById("frmProcVarMapping:otherBgcolortxtbox").className="PMbgcolorWhite";
    document.getElementById("frmProcVarMapping:otherImage").src="../omniflow/aliasimages/transparent.gif";
    document.getElementById("frmProcVarMapping:otherHidbgcolortxtbox").value=""; 
   if(ref.value==1){
     document.getElementById(imageGrid).style.display="none";
     document.getElementById(colorGrid).style.display="inline";  
  }
else{
     document.getElementById(colorGrid).style.display="none";
     document.getElementById(imageGrid).style.display="inline";
}
}
function trimByRegularEx(value) {
   var temp = value;
   var obj = /^(\s*)([\W\w]*)(\b\s*$)/;
   if (obj.test(temp)) { temp = temp.replace(obj, '$2'); }
   var obj = / +/g;
   temp = temp.replace(obj, " ");
   if (temp == " ") { temp = ""; }
   return temp;
}

/*-----------------------------------------------------------------------------------------------------

File Name			: constants.js
Author                          : Ajith Jacob
Date written (DD/MM/YYYY)       : 12/Jan/2007
Description			: This file contains the constants used by other javascript files.
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date(DD/MM/YYYY)		Change By               Change Description (Bug No. (If Any))
----------------------------------------------------------------------------------------------------
16/04/2007                      Puneet Pahuja           Bug Id -   624 (DATE_VALIDATION_MSG_4 string changed)
08/07/2009                      Bhupesh kumar           Bug Id -   PRM_8.0_011(SELECT_A_PROCESS string is added)
04/12/2009                      Indraneel               PRM_8.0_030 Export Purge Utility
19/01/2010                      Indraneel               PRM_8.0_036 Option for adding rule defination on queue Aliases to display the row color of workitem list  in webdesktop
05/04/2010                      Mohit Sharma            Bug 12250
15/07/2013      			    Dinkar Kad	 			Bug 41354 - 'Set diversion' function and 'Audit log configuration function' in process Manager can be accessed by an user who is not a member of any group.
01/10/2013            			Dinkar         			Bug 41790 - Screen for specifying names of processes,queues,activities,variables, aliases in multiple locales for multilingual functionality.
26/02/2015				Ashutosh Pandey			Bug 53764 - Optimization at CS, ofservices and utility end to reduce the user level configuration and usage of single system utility user to perform each user level operation
30/06/2015                      Ashutosh Pandey         Bug 55299 - Provided the feature for set context for a process
21/07/2015                      Ashutosh Pandey         Bug 55957 - Removing the system constants from constant.js and adding in wfgeneral.js
29/07/2015				Dinkar Kad				Bug 55876 - Showing error while checkin and check out out route in Process Modeler, after upgrading from Omniflow 8 to newer versions like OF 9 and OF 10
08/06/2016                                              Bug 62109 -  
03/08/2016                      Jaseem Ansari           Bug 63471   In processmanager,It is required to replace the WFSearch call with WMFetchWorklist call on queue search in advanced search window
----------------------------------------------------------------------------------------------------*/

/*Not to be changed----------------------------------------------------------Start*/
 var PATH="en_us/";  
/*Not to be changed----------------------------------------------------------End*/

var CENTER="center";
var STATUS="Status";
var REGNO="Registeration No.";
var COMMENTS="Comments.";
var BUTTON_CLOSE="Close";
var SPECIFY_QUEUE_NAME='Please enter the queue name.';
var QUEUE_NAME_END_MYQUEUE="Queue's name can't end with 'MyQueue'.";
var SEL_WORKSTEP_TO_REMOVE='Please select some workstep(s) to remove.';
var SEL_USER_GROUP_TO_REMOVE='Please select some User(s)/Group(s) to disassociate.';
var SPECIFY_VALID_DATE="Please enter valid date.";
var SPECIFY_QUEUE_TO_DELETE='Please select some queue(s) to delete.';
var SPECIFY_OTHER_VALUE_FOR_BATCH_SIZE='Specify a value for batch size other than the existing value.';
var SELECT_BATCH_SIZE_VALUE ="Batch size should lie between 1 to  250.";
var INVALID_CHAR_IN_BATCH_SIZE_FIELD = "Only Digits are allowed in batch size field.";
var SELECT_REFRESH_TIME  ="Please select a valid value for refresh time." ;
var SELECT_REFRESH_TIME_POSITIVE_VALUE ="Please select a valid positive value for refresh time.";
var SELECT_REFRESH_TIME_GREATER_THAN ="Refresh Time value should be greater than 5 min.";    
var NO_SPACE_IN_PASSWORD="No spaces are allowed in the beginning or end of password.";
var EMPTY_PASSWORD_NOT_ALLOWED="Empty password not allowed.";
var NO_SYMBOL_CHAR_IN_PASSWORD ="Characters  < , > , # and , are not allowed in password.";
var NO_MATCH_PASSWD_CONFIRMPASSWD="Password and Confirm password not matching.";
var ALIAS_NO_SPECIFY_VALUE="No value is specified for Alias.";
var ALIAS_NO_SYMBOL_CHAR='Alias name cannot contain following characters : \r\n  + , - , * , / , \\ , " , > , <, = ,\'';
var ALIAS_NO_SPACE_CHAR='Alias name cannot contain space character.' ;
var ALIAS_NAME_ALREADY_EXIST= "Alias with the same name already exists.";
var ALIAS_NO_NUMERICNAME= 'Alias name cannot be a numeric value.';
var ALIAS_NO_START_NUMERIC_CHAR = 'Alias name cannot start with a numeric character.';
var ALIAS_NO_VARNAME= 'Alias name cannot be same as a Variable name';
var ALIAS_NAME_NOT_AS_SYSTEM_VARIABLE_NAME='Alias name cannot be same as System defined variable name';
var INCOMPATIBLE_DATATYPE =  'Data types of the expression are incompatible.';
var NO_MULTIPLE_ITEM ='You cannot move multiple items together.';

var SELECT_WORKSTEP_AUDIT="Please select some workstep for auditing.";
var SELECT_AUDITOR="Please select some Auditor.";
var ALERT_AUDITOR_AUDITEE_SAME="Auditor and Auditee can't be same. Please select different user.";
var SELECT_USER="Please select some user.";
var SELECT_MODIFY_AUDIT="Please select some Audit to modify.";
var SELECT_DELETE_AUDIT="Please select some Audit to delete.";
var INVALID_DATE_RANGE="Invalid date range specified.";
var START_DATE_GREATER_CURR_DATE="Start date should be greater than current date.";
var SAME_USER_DIVERSION="Diversion for the same user can't be set.";
var INVALID_LOGIN_INFO="Invalid Login Information";

//PMJ_2.1.5.004 -- start
var INVALID_NUMBER = "Invalid number specified.";
var INVALID_NUMBER_RANGE = "Numeric value out of range.";
var INVALID_STRING_LENGTH = "Value exceeds max noumber of permitted characters :";
var INVALID_STRING_CHAR= "Invalid character in";
var INVALID_FLOAT_NUMBER = "Invalid Float Number.";
var INVALID_DATE="Invalid date specified.";
var INVALID_DATE_2=".";
var INVALID_DATE_YEAR = "Invalid date year specified.";
var INVALID_DATE_MONTH= "Invalid date month specified.";
var INVALID_DATE_RANGE = "Invalid date range specified.";
var INVALID_LONG = "Invalid long number specified.";
var INVALID_LONG_RANGE = "Long value out of range.";
//PMJ_2.1.5.004 -- end
var NO_EXT_INTERFACES_ASSOC="No external intefaces associated.";
var SELECT_PROCESS_FOR_INTERFACE_LIST="Select a process to get its interface list.";
var SELECT_PROCESS_FOR_DATA="Select a process to get its data.";
var SELECT_PROCESS="Please select some process to change the state.";
var SELECT_SOME_PROCESS="Please select some process";
var SELECT_WORKSTEPS='Please select some Workstep(s).';
var VALID_INTEGER="Enter some integer value for this field.";
var VALID_PROCESS_TURN_ARND_TIME="Enter some value for Process Turn Around Time.";
var POSITIVE_PROCESS_TURN_ARND_TIME="Enter only positive value for Process Turn Around Time.";
var INT_TURN_ARND_TIME="Enter some integer value for Turn Around Time.";
var POSITIVE_TURN_ARND_TIME="Enter positive value for Turn Around Time.";
var LARGE_VALUE="Value entered is too large.";
var LARGE_PROCESS_TURN_ARND="Process Turn Around Time is too large.";
var FROMDATE_GREATERTHAN_TODATE = "'From Date' should be lesser than 'To Date'.";
var TODATE_GREATERTHAN_CURRDATE = "'To Date' should be lesser than 'Current Date'.";
var PLEASE_SELECT_SINGLE_CABINET = "Please select some cabinet.";
var SELECT_PROCESS = "Please select some process.";
var NO_PROCESS_SELECTED = "No process selected.";
var NO_EXCEPTION_ASSOCIATED = "No exception associated to the selected process!";
var SELECT_SINGLE_PROCESS = "Please select a process.";
var SELECT_WORKSTEP ='Please select some workstep.';
var SELECT_CRITERIA = "Please select some criteria.";
var SELECT_USERS_FOR_COMPARISON = 'Please select at least two users for comparison.';

var SELECT_OTHER_WORKSTEP= "Please select some other workstep as this workitem is already lying in this workstep.";
var SELECT_WORKITEM= "Please select some workitem.";
var	FORCEFULLY_LOGIN_MSG= "The specified user is already logged in on some other machine. Do you want to disconnect and login again.";
var CAB_ALREADY_REGISTERED="Cabinet with the same name already registered.";
var SELECT_WFS_TO_UNREGISTER="Please select a WFS to unregister.";
var SPECIFY_WFS_IP="Enter a value for AppServer IP.";
var INVALID_PORT_NUMBER="The value for AppServer Port is not a valid number.";
var SPECIFY_WFS_PORT="Specify AppServer Port.";
var SPECIFY_WEB_IP = "Enter value for WebServer IP.";
var SPECIFY_WEB_PORT = "Specify WebServer Port.";
var INVALID_WEB_IP = "Invalid IP for WebServer";
var INVALID_WEB_PORT = "Invalid Port for WebServer";
var INVALID_WFS_IP = "Invalid IP for AppServer";

var ExpiryDateTime="ExpiryDateTime";
var CreatedDateTime="CreatedDateTime";
var EntryDateTime="EntryDateTime";
var ValidTill="ValidTill";
var ProcessInstanceName="ProcessInstanceName";
var CreatedByName="CreatedByName";
var PreviousStage="PreviousStage";
var SaveStage="SaveStage";
var CurrentDateTime="CurrentDateTime";
var IntroductionDateTime="IntroductionDateTime";
var IntroducedBy="IntroducedBy";
var InstrumentStatus="InstrumentStatus";
var PriorityLevel="PriorityLevel";
var HoldStatus="HoldStatus";
var WorkItemState="WorkItemState";
var Status="Status";
var ActivityId="ActivityId";
var QueueType="QueueType";
var QueueName="QueueName";
var LockedByName="LockedByName";
var LockedTime="LockedTime";
var LockStatus="LockStatus";
var ActivityName="ActivityName";
var CheckListCompleteFlag="CheckListCompleteFlag";
var AssignmentType="AssignmentType";

var NO_ALIAS_CREATED="No Alias is created . Do you wish to continue?";
var FORCEFULLY_LOGIN="The specified user is already logged in on some other machine. Do you want to disconnect and login again.";
var CONFIRM_DIVERSION_DELETE="Do you want to delete the already set Diversion ?";
var CONFIRM_DESCRIPTION_TRUNCATED="The description contains more than 255 characters so your description will be truncated after 255 characters. Do you want to continue? ";

var HOUR="Hour";
var DAY="Day";
var WEEK="Week";
var MONTH="Month";
var QUARTER="Quarter";
var STATUS_AS_ON="Status as on:";

var JAN="Jan";
var FEB="Feb";
var MAR="Mar";
var APR="Apr";
var MAY="May";
var JUN="Jun";
var JUL="Jul";
var AUG="Aug";
var SEP="Sep";
var OCT="Oct";
var NOV="Nov";
var DEC="Dec";

var JAN1="JAN";
var FEB1="FEB";
var MAR1="MAR";
var APR1="APR";
var MAY1="MAY";
var JUN1="JUN";
var JUL1="JUL";
var AUG1="AUG";
var SEP1="SEP";
var OCT1="OCT";
var NOV1="NOV";
var DEC1="DEC";
var INVALID_FORMAT="Date should be in proper format as ";
var INVALID_FORMAT1="Invalid Date Format.";
var NON_NUMERIC_DAY="Day should be numeric.";
var NON_NUMERIC_MONTH="Month should be numeric.";
var NON_NUMERIC_YEAR="Year should be numeric.";
var ALERT_YEAR_LENGTH_FORMAT="Year should be greater than 1900 and in YYYY format.";
var INVALID_MONTH_STRING="Incorrect month specified. ";
var ALERT_VALID_DATE_31="Please enter valid day.\nDay should be greater than 0 and less than or equal to 31.";
var ALERT_VALID_DATE_30="Please enter valid day.\nDay should be greater than 0 and less than or equal to 30.";
var ALERT_VALID_DATE_29="Please enter valid day.\nDay should be greater than 0 and less than or equal to 29.";
var ALERT_VALID_DATE_28="Please enter valid day.\nDay should be greater than 0 and less than or equal to 28.";
var ALERT_WRONG_YEAR="The year for the reminder is prior to the current year.\n Please re-enter the year and then click Add.";
var ALERT_WRONG_MONTH="The month for the reminder is prior to the current month.\n Please re-enter the month and then click Add.";

var EXCEPTIONS="Exceptions";
var TODOLIST="ToDoList";
var DOCUMENT="Document";

var TABULAR_VIEW="Tabular View";
var GRAPHICAL_VIEW="Graphical View";
var BAR_CHART_VIEW="Bar Chart View";
var PIE_CHART_VIEW="Pie Chart view";

var LEFT="left";
var RIGHT="right";
var TOP="top";
var BOTTOM="bottom";
var CENTER="center";
var MIDDLE="middle";

var PREVIOUS_BATCH_2="Previous Batch";
var NEXT_BATCH_2="Next Batch";
var ALERT_SAME_USER='Workitem cannot be assigned to same user.';

var QUEUE_TYPE_FIFO='FIFO';
var QUEUE_TEXT_ENTRY_DATE_TIME='(Fetched in order of Entry Date Time)';
var QUEUE_TEXT_INTRO_DATE_TIME='(Fetched in order of Introduction Date Time)';
var QUEUE_TYPE_DYNAMIC='Dynamic';
var QUEUE_TYPE_USER_QUEUE='User-Queue';
var QUEUE_TYPE_PERMANENT='Permanent';
var QUEUE_TYPE_NOASSIGNMENT='No Assignment';
var QUEUE_TYPE_INTRODUCTION='Introduction';
var SHOW_ALL='Show All';
var LOGGED_IN_INDEX_EQUAL_TO='Show Workitems where logged-in index is equal to';
var LOGGED_IN_INDEX_NOT_EQUAL_TO='Show Workitems where logged-in index is not equal to';
var YES='Yes';
var NO='No';
var QUEUE_NAME_COLON='Queue Name: ';
var QUEUE_TYPE_COLON='Queue Type: ';
var QUEUE_DESC_COLON='Queue Description: ';
var REASSIGN_ALLOWED_COLON='Reassignment Allowed: ';
var WORKITEM_CRITERIA_COLON='Workitem Criteria: ';
var ASSOCIATED_WORKSTEPS_COLON='Associated Workstep(s):';
var WORKSTEP_NAME='Workstep Name';
var ASSOCIATED_USERS_GROUPS="Associated User(s) / Group(s):";
var USER_GROUP_NAME="User / Group Name";
var ADD_USER_GROUP_TO_QUEUE="Add User(s) / Group(s) to Queue";
var SINGLE_QUOTE="'";
var QUEUE_DEFINITION_OF='Queue Definition of';
var GENERAL='General';
var LABEL_USER_MYQUEUE="'s MyQueue";
var MYQUEUE="MyQueue";
var WORKITEM="Workitem";
var NOT_ROUTED="could not be routed. The reason for the failure is";
var QUEUE_ASSIGN_DATE_GREATER_CURR_DATE="Assignment date should be greater than current date.";

var DATE_VALIDATION_MSG_1="From Date cannot be greater than current Date.";
var DATE_VALIDATION_MSG_2="To Date cannot be greater than current Date.";
var DATE_VALIDATION_MSG_3="From Date cannot be greater than To Date.";
var DATE_VALIDATION_MSG_4="From Date cannot be less than current Date.";
var DATE_VALIDATION_MSG_5="To Date cannot be less than current Date.";
var DATE_VALIDATION_MSG_6="Assignment date should be greater than current date.";

var SEL_QUEUE_PROCESS_DATA="Please select a queue or process.";
var SEL_QUERY_TO_DELETE="Please select a Query to delete.";
var CONFIRM_QUERY_DELETE="Do you want to delete the selected Query ?";
var QUEUE_NAME="Queue Name";

var ALL="--All--";
var ADD_Queue="Add Queue";
var ADD_USER="Add User";
var ADD_WORKSTEP="Add Workstep";
var CHANGE_QUEUE="Change Queue";
var CHANGE_AUDIT_PREF="Change Audit Log Preferences";
var DELETE_ALIAS="Delete Alias";
var DELETE_QUEUE="Delete Queue";
var DELETE_USER="Delete User";
var MAP_ALIAS="Map Alias";
var DELETE_WORKSTEP="Delete Workstep";
var CHANGE_PROCESS_STATE="Change Process State";
var SET_ACTIVITY_TURN_AROUND_TIME="Set Activity Turn Around Time";
var SET_PROCESS_TURN_AROUND_TIME="Set Process Turn Around Time";
var MODIFY_DYNAMIC_CONSTANT="Modify Dynamic Constant";

var REGISTER_PROCESS="Register Process";
var UNREGISTER_PROCESS="Un-register Process";
var CHECKOUT_PROCESS="Checkout Process";
var CHECKIN_PROCESS="Checkin Process";
var UNDO_CHECKOUT_PROCESS="Undo-Checkout Process";

var ACCEPT_WORK="Accept Work";
var ADD_DOCUMENT_TYPE="Add Document Type";
var ADD_PREFERREDQUEUE="Add PreferredQueue";
var CLEAR_EXCEPTION="Clear Exception";
var CREATE_PROCESS_INSTANCE="Create Process Instance";
var DELETE_DIVERSION="Delete Diversion";
var DELETE_LOG="Delete Log";
var DELETE_PREFERREDQUEUE="Delete PreferredQueue";
var DELETE_REMINDER="Delete Reminder";
var DELINK_WORKITEMS="Delink WorkItem";
var LINK_WORKITEM="Link WorkItem";
var LOCK_WORKITEM="Lock Workitem";
var LOGIN="Login";
var LOGOUT="Logout";
var MODIFY_TODOITEM_STATUS="Modify ToDoItem Status";
var PERFORM_ACTION="Perform Action";
var RAISE_EXCEPTION="Raise Exception";
var REASSIGN_WORKITEM="Reassign WorkItem";
var REFER_WORKITEM="Refer WorkItem";
var REINITIATE_WORKITEM="Reinitiate WorkItem";
var REJECT_WORK="Reject Work";
var ROUTE_ADHOC="Route AdHoc";
var REVOKE_WORKITEM="Revoke WorkItem";
var SET_ATTRIBUTE="Set Attribute";
var SET_AUDIT="Set Audit";
var SET_DIVERSION="Set Diversion";
var START_PROCESS_INSTANCE="Start Process Instance";
var SET_REMINDER="Set Reminder";
var TERMINATE_PROCESS_INSTANCE="Terminate Process Instance";
var UNLOCK_WORKITEM="Unlock Workitem";
var WORK_COMPLETED="Work Completed";
var NO_QUEUE_SELECTED="No Queue selected.";
var NO_USER_SPECIFIED="No user specified.";
var NO_USER_SELECTED="No User selected.";
var NO_GROUP_SELECTED="No Group selected.";
var USER_NAME="User Name";
var NO_ACTIVITY_SELECTED="No Activity Selected";



var INSERT_STR_VAL="Please Insert STRING Values";
var INSERT_BOOL_VAL="Please Insert BOOLEAN Values";
var INSERT_DATE_VAL="Please Insert DATE Values in Date Format ";
var INSERT_INT_VAL="Please Insert INTEGER Values";
var INSERT_DEC_VAL="Please Insert DECIMAL Values";
var INSERT_TIME_VAL="Please Insert TIME Values";

var INSERT_RAW_VAL="RAW DATA";


var INVALID_NUMERIC_VALUE="The value for numeric field does not seem to be valid. Please correct and try again.";
var INDEX_VALUE_OUT_OF_RANGE="Index Value entered is out of range";
var SEL_FIELD_TO_DELETE="Please select a field to remove.";
var INVALID_STRING="Invalid string value in search criteria";
var ALERT_QUERY_ALREADY_EXISTS = 'A query with the specified name already exists. Please change it and try again.';
var ALERT_NO_QUERY_NAME = 'Please specify some name for the query.';
var INVALID_CONSTANT_VALUE="Invalid characters '  | \" in Dynamic constant value.";
var BATCH_SIZE_MAX_VALUE="Batch size cannot be greater than";
var SPECIFY_USER_NAME="Specify User Name.";
var SPECIFY_USER_PASSWORD="Specify Password.";
var NO_WORKSTEP_SELECTED="No Workstep selected.";
var USER_ADDED_SUCCESSFULLY = "User successfully added to the queue.";
var INVALID_SELECTION_NONE = 'Unable to perform operation. Please select single item.';
var INVALID_SELECTION_MULTIPLE = 'Unable to perform operation. Please select single item.';
var INVALID_SELECTION_MORE = 'Unable to perform operation. Please select any item(s).';
var INVALID_WORKSTEP_PROCESS_COMBO ='Unable to perform operation. As audit for particular workstep is already been set.';
var INVALID_FROM_DATE ="From Date is invalid or does not exist.";
var INVALID_TO_DATE ="To Date is invalid or does not exist.";
var SELECT_ANOTHER_USER = 'Please select some other user. As the diversion is set for the diverted user';
var ALIAS_EXIST_FOR_VARIABLE ='Alias already exist for this variable';
var ENTER_SOME_VALUE_PROCESS_TURN_AROUND_TIME='Enter Some value for Process Turn around Time';
var TS_ENABLEITEM="EnableItem";
var TS_DISABLEITEM="DisableItem";
var TS_ENABLEATTRIBUTE="EnableAttribute";
var TS_DISABLATTRIBUTE="DisableAttribute";
var SELECT_AN_ITEM_FROM_THE_LIST='Select an Item from the list';
var CONFIRM_DELETE_QUEUE="Do you want to delete the selected Queue?";
var QUEUE_CAN_NOT_BE_DELETED="The selected Queue cannot be deleted.";
var SELECT_REPORT_DURATION="Select Report Duration";
var INVALID_OPERATION = "Operation not allowed";
var ENTER_SOME_INTEGER_VALUE_FOR_THIS_FIELD="Enter some integer value for this field.";
var GRAPH_CANNOT_BE_SHOWN_AS_NO_COOKIE="Graphical View cannot be shown as session cookies are disabled on your browser."
var REPORT_HOUR="Hour";
var REPORT_DAY="Day";
var REPORT_WEEK="Week";
var REPORT_MONTH="Month";
var REPORT_QUARTER="Quarter";
var REPORT_ALL_WORKSTEPS="All Worksteps";
var REPORT_TODAY="Today";
var REPORT_LAST_DAY="Last Day";
var REPORT_LAST_WEEK="Last Week";
var REPORT_LAST_MONTH="Last Month";
var REPORT_LAST_QUARTER="Last Quarter";
var REPORT_LAST_YEAR="Last Year";
var NOT_CORRECT_TIME="Entered time is not correct";
var SPECIFY_TO_TIME="Please specify TO time for this field";
var SPECIFY_FROM_TIME="Please specify FROM time for this field";
var SPECIFY_FROM_TIME_AND_TO_TIME="FROM time and TO time cannot be left blank for Deafult Working Day(s)";
var TO_TIME_GREATER_THAN_FROM_TIME="TO time should be greater than FROM time";
var FROM_TIME_GREATER_THAN_TO_TIME_FOR_NEXT_HOUR_RANGE="FROM time should be greater than TO time of previous hour range";
var CHANGES_DONE_SUCCESSFULLY="Changes Saved";
var SESSION_TIMEDOUT="Session Timedout. Please relogin."; 
var SELECT_PROC_VAR="No value is specified for Process Variable.";
var ERROR_FETCHING_DATA="There is some error in fetching data.";
var ALL_PROCESSES_1="All Processes";
var ALL_WORKSTEPS="All Worksteps";
var ALL_GROUPS_1="All Groups";
var CRITERIA="Criteria";
var SELECT_VARIABLE_TOREMOVE='Please select a Queue Variable to remove.'; 
var REPORT_SELECT_WORKSTEPS='--Select a WorkStep--';
var AJAX_TIMEOUT='Request Timed Out. Please make sure you are connected with the server and try again in a few moments.';
var MSG_TAT_PLEASE_ENTER_INTEGER_VALUE_BETWEEN_1_AND_500_FOR_THIS_FIELD="Please Enter Integer Value between 1 and 500 for This Field.";
var QS_NO_ALIAS_FOUND='No alias found';
var LAST_SUCCESS_LOGIN = 'Time of last successful login : ';
var LAST_FAILED_LOGIN = 'Time of last failed login attempt : ';
var FAILED_LOGIN_COUNT = 'Failed login attempt count : ';
var NON_NUMERIC_SEC="Seconds should be numeric and less than 60.";
var NON_NUMERIC_HOUR="Hours should be numeric and less than 24.";
var NON_NUMERIC_MIN="Minutes should be numeric and less than 60.";
var INVALID_TIME="Time should be correct format.";
var YOUR_PASSWORD_WILL_EXPIRE='Your password will expire in ';
var DAYS_DO_YOU_WANT_TO_CHANGE=' days, Do you want to change it now?';
var SELECT_A_PROCESS='--Select a Process--'; 
var NEW_CALENDAR_CREATED_SUCCESSFULLY='New Calender Created Successfully.';
var CALENDAR_NAME_CANNOT_BE_BLANK='Please enter the Calendar name.';
var CALENDAR_WITH_SAME_NAME_ALREADY_EXISTS='Calendar with same name already exists.'; 
var TEXT_ALREADY_ADDED="Already Added";
var PURGING_CRITERIA_EXISTS="Purging Criteria Already Exists";
var NO_PURGE_CRITERIA="No criteria exists.";
var BLANK_CRITERIA_NAME="Criteria name cannot be blank.";
var CONFIRM_MODIFY_CRITERIA="Do you want to modify the existing criteria for the same process?";
var SELECT_ONE_PURGE_OPTION="Select at least one Purge Option to proceed.";
var BLANK_FIELD_VALUE="Value cannot be blank.";
var INVALID_DATA="Invalid value specified.";
var CONFIRM_PURGE_DELETE="Do you want to delete the selectd criteria?";
var SPECIFY_SOURCE_DB_USERNAME="Specify source cabinet database user name.";
var SPECIFY_TARGET_DB_USERNAME="Specify target cabinet database user name.";
var SPECIFY_WEBSERVER_INFO="Specify Webserver Information.";
var SPECIFY_TARGET_WFSIP="Specify target cabinet AppServer IP.";
var SPECIFY_TARGET_WFSPORT="Specify target cabinet AppServer port.";
var CONFIRM_EXPORT_INFO_DELETE="Do you want to delete the Export cabinet information?";
var SELECT_CRITERIA_TO_DELETE="Select some criteria to delete.";
var VALUE_IS_NOT_VALID="Value is not valid";
var COMMENTS_MADATORY="Please Enter some comments";
var CALENDAR_DELETED_SUCCESSFULLY="Calendar deleted successfully";
var ALERT_SELECT_PROCESSNAME="Please select process name";
var ALERT_WORKSTEP_SHOULD_BE_PROCESSSPECIFIC="worksteps should be process specific and needs to be deleted first";
var PRIORITY_LEVEL="PriorityLevel";
var EMPTY_LIB_NAME="Please Enter Document Library Name";
var EMPTY_DOMAIN_NAME="Please Enter Domain Name";
var EMPTY_SITE_NAME="Please Enter Site";
var INVALID_SERVICE_URL="Invalid Service Url";
var INVALID_PROXY_IP="Invalid Proxy IP";
var INVALID_PROXY_PORT="Invalid Proxy Port";
var INVALID_PROXY_NAME="Invalid Proxy User";
var INVALID_PASSWORD="Invalid Proxy Password";
var INVALID_SHARE_POINT_URL="Invalid Share Point web url";
var EMPTY_LIBRARY_URL="Please Enter Library URL";
var EMPTY_USER_NAME="Please Enter User Name";
var EMPTY_PASSWORD="Please Enter Password";
var NOT_AUTHORIZED_TO_USE_THE_OPERATION='Not authorized to use the opeartion.';
var Please_select_entity_type='Please select entity type';
var Please_ENTER_MULTILINGUAL_NAME='Please enter Multilingual Name';
var Please_select_Activity_Name='Please select Activity Name';
var Please_select_Variable_Name='Please select Variable Name';
var Please_select_Alias_Name='Please select Alias Name';
var Please_select_Document_Type='Please select Document Type';
var Please_select_Action_Name='Please select Action Name';
var Please_select_Exception_Type='Please select Exception Type';
var Please_select_row_to_remove='Please select row to remove';
var ALL_QUEUES="All Queues";
var ENTER_FILE_NAME="Enter File Name OR Exported File Date Time";
var PLEASE_SELECT_A_FILE_TO_VIEW_RECORDS="Please Select a File to view Records";
var PLEASE_SELECT_SINGLE_FILE="Please Select Single File";
var PLEASE_SELECT_A_FILE_TO_REGENRATE_RECORDS="Please Select a File to Regenrate Record";
var DO_YOU_WISH_TO_REGENERATE_RECORD="Do You wish to Regenerate Records";
var PLEASE_SELECT_A_FILE_TO_PURGE_DATA="Please Select a File to Purge Data";
var DO_YOU_WISH_TO_PURGE_DATA="Do You wish to Purge Data";
var ENTER_PROCESSINSTANCE_ID="Enter  ProcessInstanceId OR some seaerch criteria";
var INVALID_SESSION='Invalid session';
var VARIABLES_LIMIT_EXCEEDED='Maximum 6 variables can be selected';
var INVALID_DISPLAY_NAME='Invalid display name';
var NO_SLASH_IN_CONTEXT_NAME = 'Enter context name without any slash';
var WORKSTEP_CAN_NOT_BE_ADDED_FOR_SEARCH_QUEUE = 'Workstep can not be added in Search Queue';
var NOT_AUTHORIZED = "You are not authorized to search for selected process.";
var Type= "Type";
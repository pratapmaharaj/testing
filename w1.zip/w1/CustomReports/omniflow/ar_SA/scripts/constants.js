﻿/*-----------------------------------------------------------------------------------------------------

File Name			: constants.js
Author                          : Ajith Jacob
Date written (DD/MM/YYYY)       : 12/Jan/2007
Description			: This file contains the constants used by other javascript files.
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date(DD/MM/YYYY)		Change By               Change Description (Bug No. (If Any))
----------------------------------------------------------------------------------------------------
16/04/2007                      Puneet Pahuja           Bug Id -   624 (DATE_VALIDATION_MSG_4 string changed)
26/02/2015				Ashutosh Pandey			Bug 53764 - Optimization at CS, ofservices and utility end to reduce the user level configuration and usage of single system utility user to perform each user level operation
03/06/2015                      Ashutosh Pandey         Bug 55299 - Provided the feature for set context for a process
21/07/2015                      Ashutosh Pandey         Bug 55957 - Removing the system constants from constant.js and adding in wfgeneral.js
29/07/2015				Dinkar Kad				Bug 55876 - Showing error while checkin and check out out route in Process Modeler, after upgrading from Omniflow 8 to newer versions like OF 9 and OF 10
08/06/2016                                              Bug 62109 -  
03/08/2016                      Jaseem Ansari           Bug 63471   In processmanager,It is required to replace the WFSearch call with WMFetchWorklist call on queue search in advanced search window
----------------------------------------------------------------------------------------------------*/

/*Not to be changed----------------------------------------------------------Start*/
var PATH="ar_SA/"; 
/*Not to be changed----------------------------------------------------------End*/

var CENTER="center"
var MIDDLE="middle";
var STATUS="الحالة";
var REGNO="رقم التسجيل";
var COMMENTS="ملاحظات";
var BUTTON_CLOSE="إغلاق";
var SPECIFY_QUEUE_NAME="الرجاء إدخال إسم الصف";
var QUEUE_NAME_END_MYQUEUE="لا يمكن لإسم الصف ينتهي بأسم صفي";
var SEL_WORKSTEP_TO_REMOVE="الرجاء إختيار بعض خطوات العمل للإلغاء";
var SEL_USER_GROUP_TO_REMOVE="الرجاء إختيار أسماء أو مجموعة لفصلهم  ";
var SPECIFY_VALID_DATE="الرجاء إدخال التاريخ";
var SPECIFY_QUEUE_TO_DELETE='الرجاء إختيار بعض الصفوف للإلغاء';
var SPECIFY_OTHER_VALUE_FOR_BATCH_SIZE='حدد قيمة حجم الدفعة غير القيمه الحالية';
var SELECT_BATCH_SIZE_VALUE ="ينبغي ان تقع حجم الدفعة بين 1 الى 250";
var INVALID_CHAR_IN_BATCH_SIZE_FIELD ="يسمح لإدخال الرقام فقط في ميدان الحجم";
var SELECT_REFRESH_TIME  ="الرجاء إختيار قيمة لإنعاش الوقت" ;
var SELECT_REFRESH_TIME_POSITIVE_VALUE ="يرجى اختيار قيمه ايجابية لانعاش الوقت";
var SELECT_REFRESH_TIME_GREATER_THAN =  "يجب أن يكون إنعاش الوقت أكبر من 5 دقائق";    
var MISMATCH_PASSWORD= "الرقم السري الجديد وتأكيده لم يتفقان";
var SPECIFY_OLD_PASSWORD= "حدد الرقم السري القديم"; 
var PASSWORD_SAME_OLDPASSWORD="لا يمكن أن يكون الرقم السري الجديد هو نفس الرقم السري القديم";
var ALIAS_NO_SPECIFY_VALUE= "لا قيمة حددت للإسم المستعار";
var ALIAS_NO_SYMBOL_CHAR='لا يمكن أن يتكون إسم المستعار من + , - , * , / , \\ , " , > , <, = ,\\u0627لرموز ';
var ALIAS_NO_SPACE_CHAR= 'لا يمكن أن يكون الإسم المستعار أي مسافات  ';
var ALIAS_NAME_ALREADY_EXIST=  "نفس الإسم المستعار موجود"
var ALIAS_NO_NUMERICNAME= "لا يمكن أن يكون الإسم المستعار قيمة عددية";
var ALIAS_NO_START_NUMERIC_CHAR ="لا يمكن أن يبدأ الإسم المستعار ب;رقم"
var ALIAS_NO_VARNAME=  "لا يمكن أن يبدأ الإسم المستعار بإسم متغيير";
var INCOMPATIBLE_DATATYPE =  "نوع البيانات للجملة غير متوافقة";
var NO_MULTIPLE_ITEM = "لا يمكن أن تحرك بنود متعددة مع بعض";

var SELECT_WORKSTEP_AUDIT="الرجاء إختيار بعض خطوات العمل للمرجعة";
var SELECT_AUDITOR="الرجاء إختيار المراجع";
var ALERT_AUDITOR_AUDITEE_SAME="المراجع والمراجع عليه لا يمكن أن يكونا نفس المستخدم. الرجاء إختيار مستخدم اخر";
var SELECT_USER="الرجاء إختير مستخدم";
var SELECT_MODIFY_AUDIT= "الرجاء إختيار بعض المراجعات للتغيير ";
var SELECT_DELETE_AUDIT= "الرجاء إختيار بعض المراجعات للإلغاء ";
var INVALID_DATE_RANGE= "نطاف التاريخ المحدد خاطئ";
var START_DATE_GREATER_CURR_DATE="تاريخ البدء ينبغي ان يكون أكبر من التاريخ الحالي";
var SAME_USER_DIVERSION="تحويل لنفس المستخدم لا يمكن تحديده;ا"
var INVALID_LOGIN_INFO= "معلومات الدخول خاطئة";

var INVALID_NUMBER =  "الرقم المحدد خاطئ";
var INVALID_NUMBER_RANGE = "القسمة الرقمية خارجة عن النطاق";
var INVALID_STRING_LENGTH = "القيمة الرمزية تخطت العدد المسموح للرموز";
var INVALID_STRING_CHAR=  "الرمز المدخول خاطئ";
var INVALID_FLOAT_NUMBER = "الرقم العشري خاطئ";
var INVALID_DATE= "التاريخ المحدد خاطئ";
var INVALID_DATE_2="."; 
var INVALID_DATE_YEAR = "التاريخ السنوي خاطئ";
var INVALID_DATE_MONTH= "التاريخ الشهري خاطئ";

var INVALID_LONG =  "الرقم العدد الطويل خاطئ";
var INVALID_LONG_RANGE = "الرقم الطويا خارج النطاق";

var NO_EXT_INTERFACES_ASSOC= "لا يرتبط بالوصلات الخارجية";
var SELECT_PROCESS_FOR_INTERFACE_LIST="اختيار عملية الحصول على قائمة الوصلات";
var SELECT_PROCESS_FOR_DATA="اختيار عملية للحصول على بياناتها";
var SELECT_PROCESS="اختيار عملية للتغيير الحالة ";
var SELECT_WORKSTEPS="الرجاء إختيار بعض الخطوات";
var VALID_INTEGER="إدخال العدد الرقمي في الحقل";
var VALID_PROCESS_TURN_ARND_TIME="إدخول بعض القيم لعملية وقت الدورة الكاملة  ";
var POSITIVE_PROCESS_TURN_ARND_TIME="أدخل فقط القيمة الإيجابية لعملية وقت الد;ورة"
var INT_TURN_ARND_TIME="أدخل رقم عدد لعملية وقت الدورة ";
var POSITIVE_TURN_ARND_TIME="أدخل رقم عدد ايجابي لعملية وقت الدورة ";
var LARGE_VALUE= "الرقم المدخول كبير جدا";
var LARGE_PROCESS_TURN_ARND="عملية وقت الدورة كبيرة جدا ";
var FROMDATE_GREATERTHAN_TODATE = "التاريخ من يجب أن يكون أصغر من الناريخ الحالي";
var TODATE_GREATERTHAN_CURRDATE = "التاريخ إلى يجب أت يكون أصغر من التاريخ الحالي;"


var NO_PROCESS_SELECTED = "لم يتم اختيار عملية";
var NO_EXCEPTION_ASSOCIATED = "لا استثناءات للعملية المختارة";
var SELECT_SINGLE_PROCESS =  "الرجاء إختيار عملية" ;
var SELECT_WORKSTEP = 'الرجاء اختيار بعض خطوات العم;ل'
var SELECT_CRITERIA = "الرجاء اختيار بعض المعايير";
var SELECT_USERS_FOR_COMPARISON = "الرجاء اختيار شخصين على الأقل للمقارنة";

var SELECT_OTHER_WORKSTEP= "الرجاء اختيار بعضخطولت العمل كما أن هذا بند العمل ملقى على خطوة عمل";
var SELECT_WORKITEM=  "الرجاء اختيار بعض بنود العمل";
var FORCEFULLY_LOGIN_MSG=  "المستخدم المحدد سجل دخوله في بعض الأجهزة الأخرى. هل تريد أن تسجا الخروج ومن ثم الدخول مرة أخرى؟";
var CAB_ALREADY_REGISTERED="إسم كبينة قاعدة البيانات مسجلة من قبل ";
var SELECT_WFS_TO_UNREGISTER= "الرجاء إختيار الدبليو إف إس لتسجيل الخروج ";
var SPECIFY_WFS_IP= "الرجاء ادخال قيمة الإنترنت بروتوكول للخادم" ;
var INVALID_PORT_NUMBER="قيمة منفذ الخادم خاطئ";
var SPECIFY_WFS_PORT= "الرجاء تحديد منفذ الخادم";


var ExpiryDateTime= "تاريخ ووقت الإنتهاء";
var CreatedDateTime= "إنشاء الوقت والتاريخ";
var EntryDateTime= "إدخال التاريخ والوقت";
var ValidTill="ValidTill"; 

var CreatedByName= "أنشأت بواسطة " ;
var PreviousStage= "المرحلة السابقة";
var SaveStage= "حفظ المرحلة";
var CurrentDateTime="التاريخ الوقت الحالي";
var IntroductionDateTime="IntroductionDateTime";
var IntroducedBy= "عرفت بواسطة";
var InstrumentStatus= "حالة الجهاز";
var PriorityLevel="طبقة الأولوية";
var HoldStatus= "حالة التجميد";

var WorkItemState="حالة بند العمل";
var Status= "الحالة";

var QueueType="نوع الصف";

var LockedByName="أقفلت بواسطة إسم";
var LockedTime= "وقت الإقفال";


var CheckListCompleteFlag="CheckListCompleteFlag";
var AssignmentType= "نوع الإحالة";

var NO_ALIAS_CREATED= "لا وجود لإسم مستعار. هل تريد الإستمرار؟";
var FORCEFULLY_LOGIN= "المستخدم المحدد مسجل في أجهزة أخرى. هل تريد الخروج وتسجيل الدخول مرة أخرى؟";
var CONFIRM_DIVERSION_DELETE="هل تريد إلغاء مجطموعة التحويل؟ ";
var CONFIRM_DESCRIPTION_TRUNCATED= "الوصف يتضمن اكثر من 255 رمز";

var HOUR="ساعة";
var DAY= "يوم";
var WEEK= "أسبوع";
var MONTH= "شهر";

var STATUS_AS_ON="Status as on:";

var JAN="كانون ثاني/يناير";
var FEB="شباط/فبراير";
var MAR="آذار/مارس";
var APR="نيسان/أبريل";
var MAY="أيار/ مايو";
var JUN="حزيران/يونيو";
var JUL="تموز/ يوليو";
var AUG="آب/ أغسطس";
var SEP="أيلول/ سبتمبر";
var OCT="تشرين أول/ أكتوبر";
var NOV="تشرين ثاني/ نوفمبر";
var DEC="كأنون أول/ ديسمبر";

var JAN1="كانون ثاني/يناير";
var FEB1="شباط/فبراير";
var MAR1="آذار/مارس";
var APR1="نيسان/أبريل";
var MAY1="أيار/ مايو";
var JUN1="حزيران/يونيو";
var JUL1="تموز/ يوليو";
var AUG1="آب/ أغسطس";
var SEP1="أيلول/ سبتمبر";
var OCT1="تشرين أول/ أكتوبر";
var NOV1="تشرين ثاني/ نوفمبر";
var DEC1="كأنون أول/ ديسمبر";
var INVALID_FORMAT= "يجب أن يكون التاريخ في  الصحيح؟";
var INVALID_FORMAT1="صيغة التاريخ غير صحيحة";
var NON_NUMERIC_DAY="صيغة الوقت رقمية";
var NON_NUMERIC_MONTH= "يجب أن يكون الشهر رقمي";
var NON_NUMERIC_YEAR= "يجب أن يكون السنة رقمي";
var ALERT_YEAR_LENGTH_FORMAT="يجب أن تكون صيغة السنة أكبر من 1900 و بصيفة س س س س ؟";
var INVALID_MONTH_STRING="الشهر المحدد خاطئ" ;
var ALERT_VALID_DATE_31= "الرجاء إدخال يوم صحيح. يجب أن يكون أكبر من 0 و أصغر أو يساوي إلى 31";
var ALERT_VALID_DATE_30= "الرجاء إدخال يوم صحيح. يجب أن يكون أكبر من 0 و أصغر أو يساوي إلى 30";
var ALERT_VALID_DATE_29= "الرجاء إدخال يوم صحيح. يجب أن يكون أكبر من 0 و أصغر أو يساوي إلى 29";
var ALERT_VALID_DATE_28= "الرجاء إدخال يوم صحيح. يجب أن يكون أكبر من 0 و أصغر أو يساوي إلى 28";
var ALERT_WRONG_YEAR= "سنة التذكير قبل السنة الحالية. الرجاء أعد إدخال السنة وأنقر إضافة";
var ALERT_WRONG_MONTH= "شهر التذكير قبل الشهر الحالي. الرجاء أعد إدخال الشهر وأنقر إضافة";

var EXCEPTIONS= "إستثناءات";
var TODOLIST= "قائمة الأعمال";
var DOCUMENT= "الوثيقة";

var TABULAR_VIEW="منظر مجدول";
var GRAPHICAL_VIEW="منظر رسمي";
var BAR_CHART_VIEW="منظر مخطط بياني";
var PIE_CHART_VIEW=" منظر مخطط بياني دائري";

var PREVIOUS_BATCH_2= "المجموعة السابقة";
var NEXT_BATCH_2= "المجموعة التالية";
var ALERT_SAME_USER= 'لا يمكن إحالة بند العمل إلى نفس المستخدم'; 

var QUEUE_TYPE_FIFO= 'الأول يدخل والأول يخرج'; 
var QUEUE_TEXT_ENTRY_DATE_TIME=' المعطى على ترتيب التريخ والوقت المدخل'; 
var QUEUE_TEXT_INTRO_DATE_TIME=' المعطى على ترتيب التريخ والوقت البدائي';
var QUEUE_TYPE_DYNAMIC='ديناميكي'; 
var QUEUE_TYPE_USER_QUEUE= 'صف المستخدم'; 
var QUEUE_TYPE_PERMANENT= 'دائم'; 
var QUEUE_TYPE_NOASSIGNMENT=  'لا إحالة'; 
var QUEUE_TYPE_INTRODUCTION= 'البداية';
var SHOW_ALL= 'عرض الكل';
var LOGGED_IN_INDEX_EQUAL_TO= 'عرض بنود العمل التي سجلت في الفهرس يساوي';
var LOGGED_IN_INDEX_NOT_EQUAL_TO=  'عرض بنود العمل التي سجلت في الفهرس ولا يساوي';
var YES= 'نعم';
var NO= 'لا';
var QUEUE_NAME_COLON= 'اسم الصف';
var QUEUE_TYPE_COLON= 'نوع الصف';
var QUEUE_DESC_COLON= 'الوصف';
var REASSIGN_ALLOWED_COLON= 'إمكانية إعادة الإحالة';
var WORKITEM_CRITERIA_COLON='معايير بند العمل';
var ASSOCIATED_WORKSTEPS_COLON='الخطوات المرتبطة';
var WORKSTEP_NAME='اسم خطوة العمل';
var ASSOCIATED_USERS_GROUPS='المستخدمين/المجموعات المرتبطة';
var USER_GROUP_NAME='المستخدم/المجموعه المرتبطة';
var ADD_USER_GROUP_TO_QUEUE='إضافة المستخدم/المجموعة إلى الصف';
var SINGLE_QUOTE="'";
var QUEUE_DEFINITION_OF='تعريف الصف هو';
var GENERAL='عام';
var LABEL_USER_MYQUEUE="صفي";
var MYQUEUE="صفي";
var WORKITEM="بند العمل"
var NOT_ROUTED="لا يمكن تحويله. سبب الفشل هو";
var QUEUE_ASSIGN_DATE_GREATER_CURR_DATE=" يجب أن يكون تاريخ الإحالة أكبر من التاريخ الحالي ";

var DATE_VALIDATION_MSG_1="الناريخ من يجب أن تكون أكبر من التاريخ الحالي";
var DATE_VALIDATION_MSG_2= "التاريخ إلى يجب أن يكون أكبر من التاريخ الحالي";
var DATE_VALIDATION_MSG_3="التاريخ إلى يجب أن يكون أكبر من التاريخ إلى";
var SEL_QUEUE_PROCESS_DATA="الرجاء اختيار صف أو عملية لإستخراج بياناتها";
var SEL_QUERY_TO_DELETE="الرجاء استخراج صف للإلغاء";
var CONFIRM_QUERY_DELETE= "هل تريد إلغاء الصف المختار؟";
var QUEUE_NAME="إسم الصف";

var ALL= "--الكل--";
var ADD_Queue= "أضافة صف";
var ADD_USER="إضافة إسم";
var ADD_WORKSTEP= "إضافة خطوة عمل";
var CHANGE_QUEUE="تغيير صف";
var CHANGE_AUDIT_PREF="تغيير دفتر تفضيلات المراجع";
var DELETE_ALIAS= "إلغاء حذف إسم مستعار";
var DELETE_QUEUE= "حذف صف";
var DELETE_USER="حذف مستخدم";
var MAP_ALIAS="حدد إسم مستعار";
var DELETE_WORKSTEP= "حذف خطوة العمل";
var CHANGE_PROCESS_STATE= "تغيير حالة العملية";
var SET_ACTIVITY_TURN_AROUND_TIME= "حدد وقت نشاط الدورة";
var SET_PROCESS_TURN_AROUND_TIME="حدد وقت عملية الدورة";
var MODIFY_DYNAMIC_CONSTANT= "تعديل ديناميكيه مستمرة ";

var REGISTER_PROCESS= "تسجيل العملية";
var UNREGISTER_PROCESS="تغيير تسجيل العملية";
var CHECKOUT_PROCESS= "إستخراج العملية";
var CHECKIN_PROCESS="إدخال العملية";
var UNDO_CHECKOUT_PROCESS="الغاء عملية الإستخراج";

var ACCEPT_WORK= "قبول العمل";
var ADD_DOCUMENT_TYPE="إضافة نوع الملف";
var ADD_PREFERREDQUEUE= "إضافة صف مفضل ";
var CLEAR_EXCEPTION= "مسح الإستثناء";
var CREATE_PROCESS_INSTANCE="إنشاء عملية مماثلة";
var DELETE_DIVERSION= "حذف التحويل";
var DELETE_LOG= "حذف السجل";
var DELETE_PREFERREDQUEUE= "حذف صف مفضل ";
var DELETE_REMINDER= "حذف التذكير";
var DELINK_WORKITEMS= "إلغاء رابط بند العمل";
var LINK_WORKITEM= "رابط بند العمل";
var LOCK_WORKITEM="إقفال بند العمل";
var LOGIN= "التسجيل";
var LOGOUT="الخروج";
var MODIFY_TODOITEM_STATUS= "تعديل حالة الأعمال التي يجب القيام بها";
var PERFORM_ACTION= "تأدية الحدث";
var RAISE_EXCEPTION= "رفع إستثناء";
var REASSIGN_WORKITEM= "إعادة إحالة بند العمل";
var REFER_WORKITEM= "بند العمل المشار";
var REINITIATE_WORKITEM= "استئناف بند العمل";
var REJECT_WORK="رفض العمل";
var ROUTE_ADHOC= "طريق مخصص";
var REVOKE_WORKITEM= "إلغاء بند العمل";
var SET_ATTRIBUTE= "حدد الصفة";
var SET_AUDIT="حدد المراجعة";
var SET_DIVERSION= "حدد التحويل";
var START_PROCESS_INSTANCE= "حدد مثل العملية";
var SET_REMINDER= "حدد التذكير";
var TERMINATE_PROCESS_INSTANCE= "أحذف مثل العملية";
var UNLOCK_WORKITEM= "فتح العملية";
var WORK_COMPLETED= "إكتمال العمل";
var NO_QUEUE_SELECTED=" صف غير مختار";
var NO_USER_SPECIFIED=" صف غير محدد";
var USER_NAME= "إسم المستخدم";


var INSERT_STR_VAL= "الرجاء أدخل قيمة الجملة";
var INSERT_BOOL_VAL="الرجاء أدخل قيمة المنطقية";
var INSERT_DATE_VAL="الرجاء أدخل التاريخ وبصيفة التاريخ";
var INSERT_INT_VAL= "الرجاء أدخل قيمة العددية";
var INSERT_DEC_VAL="الرجاء أدخل قيمة العشرية";
var INSERT_RAW_VAL= "بيانات حديثة";
var INSERT_TIME_VAL="Please Insert TIME Values";

var INVALID_NUMERIC_VALUE="القيمه العدديه للحقل لا تبدو انها صحيحة. يرجى تصحيح والمحاولة مرة أخرى ";
var INDEX_VALUE_OUT_OF_RANGE= "قيمة الفهرس خارجة عن النطاق";
var SEL_FIELD_TO_DELETE= "الرجاء إختيار الحقل للإلغاء";
var INVALID_STRING="قيمة سلسلة الجملة غير صحيح";
var ALERT_QUERY_ALREADY_EXISTS = 'الإستفسار عن اسم محدد موجود من قبل. يرجى تغييرها ، والمحاولة مرة ثانية ';
var ALERT_NO_QUERY_NAME = 'يرجى تحديد اسم الصف';
var INVALID_CONSTANT_VALUE="الرموز ' | / لها قيمة ديناميكية ثابتة";
var BATCH_SIZE_MAX_VALUE= "لا يمكن أن يكون حجم المجموعة أكبر من";
var SPECIFY_USER_NAME= "حدد إسم المستخدم";
var SPECIFY_USER_PASSWORD= "حدد الرقم السري";
var USER= "المستخدم";

/*****************************/

var AJAX_TIMEOUT="اطلب من أصل موقوت. الرجاء التأكد من أنك مرتبط مع موفرالخدمة والمحاولة مرة أخرى في غضون لحظات. ";
var ALIAS_EXIST_FOR_VARIABLE ="المستعارموجود بالفعل لهذا المتغير";
var ALIAS_NAME_NOT_AS_SYSTEM_VARIABLE_NAME="'الاسم المستعار لا يمكن أن يكون نفس الاسم المتغيرتم تحديده بالنظام ";
var ALL_GROUPS_1="جميع الفئات";
var ALL_PROCESSES_1="جميع العمليات";
var ALL_WORKSTEPS="جميع خطوات العمل";


var BOTTOM="أسفل";

var CHANGES_DONE_SUCCESSFULLY="التغييرات المحفوظة";



var CONFIRM_DELETE_QUEUE="هل تريد حذف الصف المختار؟";




var CRITERIA="المعايير";

var DATE_VALIDATION_MSG_4="لا يمكن أن يكون تاريخ من أقل من التاريخ الحالي.";
var DATE_VALIDATION_MSG_5="لا يمكن أن يكون تاريخ الي أقل من التاريخ الحالي.";
var DATE_VALIDATION_MSG_6="يجب أن يكون تاريخ الاحالة أكبر من التاريخ الحالي.";

var DAYS_DO_YOU_WANT_TO_CHANGE="أيام ، هل تريد أن تغير ذلك الآن؟";
var EMPTY_PASSWORD_NOT_ALLOWED="كلمة السر الفارغة غير مسموح بها. ";
var ENTER_SOME_INTEGER_VALUE_FOR_THIS_FIELD="ادخل بعض قيمة لهذا المجال";
var ENTER_SOME_VALUE_PROCESS_TURN_AROUND_TIME="أدخل بعض قيمة لعملية تغيير مسار الزمن ";
var ERROR_FETCHING_DATA="هناك بعض الأخطاء في جلب البيانات.";

var FAILED_LOGIN_COUNT ="فشل محاولة تسجيل الدخول:"; 
var FROM_TIME_GREATER_THAN_TO_TIME_FOR_NEXT_HOUR_RANGE="يجب أن يكون وقت من أكبر من وقت الي من نطاق الساعة السابقة";
var GRAPH_CANNOT_BE_SHOWN_AS_NO_COOKIE="عرض الرسوم البيانية لا يمكن أن تظهر لأن دورة الكوكيز معطلة على متصفحك.";

var INVALID_FROM_DATE ="تاريخ من غير صحيح أو غير موجود";
var INVALID_OPERATION ="عملية غير مسموحة"; 
var INVALID_SELECTION_MORE ="غير قادر على أداء هذه العملية. الرجاء اختيار أي بند (بنود)."; 
var INVALID_TIME="يجب أن يكون شكل الوقت صحيحا.";
var INVALID_TO_DATE ="تاريخ إلى غير صحيح أو غير موجود";
var INVALID_WORKSTEP_PROCESS_COMBO ="غير قادر على أداء هذه العملية. لأن مراجعة الحسابات لخطوة العمل الخاصة تم تعيينها بالفعل.";



var LEFT="يسار";

var MSG_TAT_PLEASE_ENTER_INTEGER_VALUE_BETWEEN_1_AND_500_FOR_THIS_FIELD="الرجاء إدخال قيمة بين 1 و 500 لهذا المجال";
var NON_NUMERIC_HOUR="يجب أن تكون الساعة رقمية و أقل من 24";
var NON_NUMERIC_MIN="يجب أن تكون الدقيقة رقمية  وأقل من 60";
var NON_NUMERIC_SEC="يجب أن تكون الثانية رقمية وأقل من 60";
var NOT_CORRECT_TIME="الوقت الذي دخل غير صحيح";
var NO_ACTIVITY_SELECTED="لا نشاط مختار";
var NO_GROUP_SELECTED="لا مجموعة مختارة";
var NO_MATCH_PASSWD_CONFIRMPASSWD="لاتطابق كلمة السر و تأكيدها.";

var NO_SPACE_IN_PASSWORD="لا يسمح بوجود أي مسافات في بداية أو نهاية كلمة السر";
var NO_SYMBOL_CHAR_IN_PASSWORD ="الحروف <،> ، و# ، لا يسمح في كلمة السر.";
var NO_WORKSTEP_SELECTED="لا خطوة العمل مختارة";

var PLEASE_SELECT_SINGLE_CABINET ="الرجاء تحديد بعض المرحاض.";

var QS_NO_ALIAS_FOUND="لا يوجد أي الاسم المستعار";
var QUARTER="ربع";
var QUEUE_CAN_NOT_BE_DELETED="الصف المختار لا يمكن حذفه.";
var Quarter="ربع";
var REPORT_ALL_WORKSTEPS="جميع خطوات العمل";
var REPORT_DAY="اليوم";
var REPORT_HOUR="ساعة";
var REPORT_LAST_DAY="اليوم الاخير";
var REPORT_LAST_MONTH="الشهر الماضي";
var REPORT_LAST_QUARTER="الربع الأخير";
var REPORT_LAST_WEEK="الأسبوع الماضي";
var REPORT_LAST_YEAR="العام الماضي";
var REPORT_MONTH="شهر";
var REPORT_QUARTER="ربع";
var REPORT_SELECT_WORKSTEPS="-- اختر خطوة العمل --";
var REPORT_TODAY="اليوم";
var REPORT_WEEK="أسبوع";
var RIGHT="يمين";

var SELECT_ANOTHER_USER ="الرجاء اختيار بعض المستخدمين الآخرين. لأن التحويل تم تعيينه للمستخدمين المحولين";
var SELECT_AN_ITEM_FROM_THE_LIST="اختر بندا من القائمة";



var SELECT_PROC_VAR="لم يحدد أية قيمة لعملية المتغير";
var SELECT_REPORT_DURATION="اختيار مدة التقرير";
var SELECT_SOME_PROCESS="يرجى اختيار بعض العملية. ";
var SELECT_VARIABLE_TOREMOVE="الرجاء اختيار صف متغير للإزالة";

var SESSION_TIMEDOUT="انتهي مدة الدورة. يرجى اعادة تسجيل الدخول.";
var SPECIFY_FROM_TIME="يرجى تحديد موعد من لهذا الميدان";
var SPECIFY_FROM_TIME_AND_TO_TIME="FROM time and TO time cannot be left blank for Deafult Working Day(s)";

var SPECIFY_TO_TIME="يرجى تحديد موعد الي لهذا الميدان";

var TOP="أعلى";
var TO_TIME_GREATER_THAN_FROM_TIME="يجب أن يكون وقت الي أكبر من وقت من";
var TS_DISABLATTRIBUTE="تعطيل السمة";
var TS_DISABLEITEM="تعطيل البند";
var TS_ENABLEATTRIBUTE="تمكين السمة";
var TS_ENABLEITEM="تمكين البند";

var USER_ADDED_SUCCESSFULLY ="المستخدم تم اضافته بنجاح إلى الصف";

var YOUR_PASSWORD_WILL_EXPIRE="كلمة السر وسوف تنتهي في";

/**********************************/

var NO_USER_SELECTED="No User selected.";
var INVALID_SELECTION_NONE = 'Unable to perform operation. Please select single item.';
var INVALID_SELECTION_MULTIPLE = 'Unable to perform operation. Please select single item.';
var LAST_SUCCESS_LOGIN = 'Time of last successful login : ';
var LAST_FAILED_LOGIN = 'Time of last failed login attempt : ';
var SELECT_A_PROCESS='--Select a Process--';
var NEW_CALENDAR_CREATED_SUCCESSFULLY='New Calender Created Successfully.';
var CALENDAR_NAME_CANNOT_BE_BLANK='Please enter the Calendar name.';
var CALENDAR_WITH_SAME_NAME_ALREADY_EXISTS='Calendar with same name already exists.';
var TAG_SortOrder="SortOrder";
var TEXT_ALREADY_ADDED="Already Added";
var PURGING_CRITERIA_EXISTS="Purging Criteria Already Exists";
var NO_PURGE_CRITERIA="No criteria exists.";
var BLANK_CRITERIA_NAME="Criteria name cannot be blank.";
var CONFIRM_MODIFY_CRITERIA="Do you want to modify the existing criteria for the same process?";
var SELECT_ONE_PURGE_OPTION="Select at least one Purge Option to proceed.";
var BLANK_FIELD_VALUE="Value cannot be blank.";
var INVALID_DATA="Invalid value specified.";
var CONFIRM_PURGE_DELETE="Do you want to delete the selectd criteria?";
var SPECIFY_SOURCE_DB_USERNAME="Specify source cabinet database user name.";
var SPECIFY_TARGET_DB_USERNAME="Specify target cabinet database user name.";
var SPECIFY_WEBSERVER_INFO="Specify Webserver Information.";
var SPECIFY_TARGET_WFSIP="Specify target cabinet AppServer IP.";
var SPECIFY_TARGET_WFSPORT="Specify target cabinet AppServer port.";
var CONFIRM_EXPORT_INFO_DELETE="Do you want to delete the Export cabinet information?";
var SELECT_CRITERIA_TO_DELETE="Select some criteria to delete.";
var VALUE_IS_NOT_VALID="Value is not valid";
var ALL_QUEUES="All Queues";
var ENTER_FILE_NAME="Enter File Name OR Exported File Date Time";
var PLEASE_SELECT_A_FILE_TO_VIEW_RECORDS="Please Select a File to view Records";
var PLEASE_SELECT_SINGLE_FILE="Please Select Single File";
var PLEASE_SELECT_A_FILE_TO_REGENRATE_RECORDS="Please Select a File to Regenrate Record";
var DO_YOU_WISH_TO_REGENERATE_RECORD="Do You wish to Regenerate Records";
var PLEASE_SELECT_A_FILE_TO_PURGE_DATA="Please Select a File to Purge Data";
var DO_YOU_WISH_TO_PURGE_DATA="Do You wish to Purge Data";
var ENTER_PROCESSINSTANCE_ID="Enter  ProcessInstanceId OR some seaerch criteria";
var INVALID_SESSION='Invalid session';
var VARIABLES_LIMIT_EXCEEDED = 'Maximum 6 variables can be selected';
var INVALID_DISPLAY_NAME = 'Invalid display name';
var NO_SLASH_IN_CONTEXT_NAME = 'Enter context name without any slash';
var WORKSTEP_CAN_NOT_BE_ADDED_FOR_SEARCH_QUEUE = 'Workstep can not be added in Search Queue';
var NOT_AUTHORIZED = "You are not authorized to search for selected process.";
var Type= "Type";
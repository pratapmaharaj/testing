<!-- 
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-TA_CM
Module : GMAC-TACM
File Name : TAEPMOVEMENTREPORTGenerate.jsp
Author :  
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
 -->
<%@ include file="customized.process" %> 
<%@ page import="java.io.*" %>
<%@ page import="java.util.*" %>
<%@ page import="javax.servlet.*"%>
<%@ page import="java.text.DateFormat"%>
<%@ page import="java.text.SimpleDateFormat"%>
<%@ page import="javax.servlet.http.*"%>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>
<%@ page import="java.sql.DriverManager,java.sql.Connection,java.sql.PreparedStatement,java.sql.CallableStatement,java.sql.ResultSet,java.sql.SQLException"%>

<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<HTML>
<HEAD>
<TITLE>TACM Movement Report</TITLE>
</HEAD>
<link href="/processmanager/omniflow/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>

<script>


</script>

<body topmargin="0" leftmargin="5" >

<%
	WriteLog("TAEP_MOVEMENT REPORT","Initial");								
	int sProcessDefId      =1;
	String sProcedureName     ="";
	String sColumnHeaders     ="";
	String sReportName        ="";
	String sFileName          ="";
	String sNumberOfColumns   ="";
	String sProcedureNameKey  ="";
	String sColumnHeadersKey  ="";
	String sFileNameKey       ="";
	String sNumberOfColumnsKey="";
	String sHeaderKey         ="";
	String sHeaderPresentKey  ="";
	String sDBMappedColsKey   ="";
	String sHeaderValue       ="";
	String sHeaderPresentValue="";
	String sCabinetName       ="";	
	String sDBMappedCols      ="";
	String sFieldValuesKey    ="";
	String sFieldValues       ="";
	String sUserMailID        ="";
	String sFromDate          =null;
	String sToDate            =null;
	String sFilePath          = "" ;

    sFromDate = request.getParameter("FromDate");
	sToDate = request.getParameter("ToDate");
	String Queue=request.getParameter("sQueue");

	sReportName	  =request.getParameter("ReportName");
	sUserMailID   =request.getParameter("UserEmailID");
	
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAEPMovementReport.ini";
	WriteLog("TAEP_MOVEMENT REPORT","sRootPathini="+sRootPathini+",sReportName="+sReportName);								
	
	Properties ini = new Properties();
	
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("TAEP_MOVEMENT Report","Unable to read TAEP_MOVEMENT Report.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("TAEP_MOVEMENT Report","Unable to close the TAEP_MOVEMENT Report.ini file");
						}
					}
				}

	sProcessDefId=1;
	sCabinetName="omnicab";

	 sProcedureName=sReportName+"_PROCEDURENAME";

	 sFilePath = sReportName+"_FILEPATH";
     sFileNameKey        =sReportName+"_FILENAME";
     sNumberOfColumnsKey =sReportName+"_NUMBEROFCOLUMNS";
	 sFieldValuesKey     =sReportName+"_FIELDVALUES";

    sFieldValues=ini.getProperty(sFieldValuesKey);
	sFieldValues=sFieldValues.replaceAll("#",",");
	
	sFilePath = ini.getProperty(sFilePath) ;
    sFileName        =ini.getProperty(sFileNameKey);
	sNumberOfColumns =ini.getProperty(sNumberOfColumnsKey);
	sProcedureName = ini.getProperty(sProcedureName) ;
		
	String sCabname             = null;
	String sSessionId           = null;
	String sJtsIp               = null;
	String sUserName            = null;
	String sReportProcedureName =null;
	String sReportTableName=null;

	WriteLog("TAEP_MOVEMENT REPORT","sFilePath="+sFilePath);	
	
	Date CurrDate     =new Date();
	DateFormat dt     = new SimpleDateFormat("dd-MMM-yyyy");
	String sCurrdate  =dt.format(CurrDate);

	String sOutputXML   ="";
	String sInputXML    ="";
	String maincode     ="";
	String Totalrec     ="0";
	String sStr_ServerType = null;
	String url = "";
	String Status="";
	double fPercentage=0;
	String sRowXml="";
	
	int iJtsPort = 0;
	
	
	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("TAEP_MOVEMENT REPORT","sRootPathDBini="+sRootPathDBini);								
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("TAEP_MOVEMENT Report","Unable to read TAEP_MOVEMENT Report.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("TAEP_MOVEMENT Report","Unable to close the TAEP_MOVEMENT Report.ini file");
						}
					}
				}
	
	
	String conString = null;
	String driverName = null;
	driverName=ini.getProperty("DRIVERNAME");
	conString=ini.getProperty("CONNECTIONSTRING");
	WriteLog("TAEP_MOVEMENT REPORT","driverName="+driverName+",conString="+conString);								
	
	boolean bError=false;
	
	Connection conn = null;
	CallableStatement cs = null;
	ResultSet resultset = null;
	try
	{
		Class.forName(driverName);	
		conn = DriverManager.getConnection(conString);
		
		cs = conn.prepareCall("{?=call "+sProcedureName+"(?,?,?,?,?,?)}"); 
		
		WriteLog("TAEP_MOVEMENT REPORT","cs.toString()="+cs.toString());	
		cs.registerOutParameter(1, java.sql.Types.VARCHAR);
		
		cs.setString(2,Queue);
		cs.setString(3,sFromDate);
		cs.setString(4,sToDate);
		cs.setString(5,sFieldValues);
		cs.setString(6,sUserMailID);
		cs.setString(7,sFilePath);
		
		WriteLog("TAEP_MOVEMENT REPORT","variables="+cs+"---Queue="+Queue+","+sFieldValues+","+sFromDate+","+sToDate+","+sUserMailID+","+sFilePath);	
	
		resultset = cs.executeQuery();
		WriteLog("TAEP_MOVEMENT REPORT","resultset="+resultset);	
		
		while( resultset.next() )
		{
              WriteLog("TAEP_MOVEMENT REPORT","output="+resultset.getString( 1 ));	
			  sOutputXML = resultset.getString(1);
        }
		

	}
	catch(SQLException ignore)
	{	
		
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp->161->"+ignore.toString()+"</b></font>");
		WriteLog("TAEP_MOVEMENT REPORT",ignore.toString());	
		bError= true;
	}
	finally {
    
    if (resultset != null) {
        try {
            resultset.close();
        } catch (SQLException e) {  }
    }
	if (cs != null) {
        try {
            cs.close();
        } catch (SQLException e) {  }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) {  }
    }
}
	
	
	if(!bError)
	{
		try
		{
		   if(sOutputXML.equals("NORECORD"))
		   {
			WriteLog("TAEP_MOVEMENT REPORT","no record ");
			bError= true;
			
			%>
			<script>alert("No Records found for the Current Request Criteria.");</script>
			<%
		   }
			else if(sOutputXML.equals("SUCCESS"))
			{
				WriteLog("TAEP_MOVEMENT REPORT","found record");

				%>
				<script>alert("The Report will be delivered to your mailbox shortly");</script>
				<%

			}
			else 
			{
				WriteLog("TAEP_MOVEMENT REPORT","Technical error");

				%>
				<script>alert("Internal Server error. Please logout and try again.\nIf problem persists then contact to the support team.");</script>
				<%

			}

		}
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			WriteLog("TAEP_MOVEMENT REPORT",exp.toString());	
			bError= true;
		}
	
	}
	else
	{
	%>
			<script>alert("Internal Server Error.");</script>
	<%
	}
%>	

<FORM name="textForm">
</form>	

</body>

</html>

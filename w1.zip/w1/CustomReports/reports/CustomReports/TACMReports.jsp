<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<html>
<head>
<TITLE>TA Reports</TITLE>
<script language="JavaScript" src="/processmanager/reports/CustomReports/SupportiveFiles/Scripts/Common.js"></script>
<script type="text/javascript" language="javascript" >

<!-- 
function hide_menu(node_id,menu_type)
{
var node_prefix="";
	switch(menu_type)
	{
	case 1:{
		node_prefix="node_";
			}break;
	case 2:{
	node_prefix="main_node_";
		}break;
			case 3:{
	node_prefix="main_node_";
		}break;
	}

	var node=document.getElementById(node_prefix+node_id);
	var node_status=document.getElementById(node_prefix+node_id+"_status");
	var node_text=document.getElementById(node_prefix+node_id+"_title");
	
	if(node_status.value=="1")
	{
		node.style.display = "none"; 
	}
	else
	{
		node.style.display = ""; 
	}
	if(node_status.value=="1")
	{
		node_status.value="0";
		node_text.innerHTML="&#9658";
	}
	else
	{
		node_status.value="1";
		node_text.innerHTML="&#9660";
	}
	return false;
}


-->

</script>
<style type="text/css">
.node_content
{
	padding-left:30px; 
}

.node_title
{
vertical-align:top;
}

.link_text
{
font-family:Verdana, Arial, Helvetica, sans-serif;
font-size:10px;
text-decoration:none;
}

.link_text:hover
{
text-shadow:#FFCC00;
font-weight:bold;
}

.node_title
{
font-family:Verdana, Arial, Helvetica, sans-serif;
font-size:12px;
font-weight:bold;
text-decoration:none;
color:green;
}

.reportlink
{font-size: 12px;padding-bottom: 10px;font-weight: bold;font-weight: normal;color: #D2242B}
</style>
</HEAD>

<body topmargin="2" leftmargin="6" bgcolor="908D8D">

			<form name='textForm' method=post>
			<table border="0" >
			<div id="node_title_1"><a href="javascript:void(0);" onclick="javascript:hide_menu('1',1);" class="link_text">
			
			<span class="node_title" id="node_1_title">&#9660;</span><span class="node_title"> TA AP Reports </span></a>
			<div id="node_1">
				<ul >
					<li >
						<a class="reportlink" href="#">Queue Status Report</a>
					</li>
					<li >
					   <a class="reportlink" href="#" >Exception Report</a>
					</li>
					<li >
						<a class="reportlink" href="#">Approval Report</a>
					</li>
					<li >
						<a class="reportlink" href="#">Workitem Movement Report</a>
					</li>
					<li >
						<a class="reportlink" href="#">Productivity Report</a>
					</li>
					<li >
						<a class="reportlink" href="#">Aging Report</a>
					</li>
					
				</ul>
				
			</div><input type="hidden" id="node_1_status" name="node_1_status" value="1" />
			</div>
				
				
			<div id="node_title_2"><a href="javascript:void(0);" onclick="javascript:hide_menu('2',1);" class="link_text">
			
			<span class="node_title" id="node_2_title">&#9660;</span><span class="node_title"> TA CM Reports </span></a>
			<div id="node_2">
					<UL>
					<li >
						<a class="reportlink"  href="javascript:openCMReport('TACMQueueStatusReport','TACMQueueStatusMain.jsp')">Queue Status Report1</a>
					</li>
					<li >
					   <a class="reportlink" href="javascript:openCMReport('TACM_ApprovalReport','TACMApprovalRepMain.jsp')" >Approval Report</a>
					</li>
					<li >
						<a class="reportlink" href="javascript:openCMReport('TACMAgingReport','TACMAgingReportMain.jsp')">Aging Report</a>
					</li>
					<li >
						<a class="reportlink" href="javascript:openCMReport('TACMMovementReport','TACMMovementReportMain.jsp')">Workitem Movement Report</a>
					</li>
					<li >
						<a class="reportlink" href="javascript:openCMReport('TACMProductivityReport','TACMProductivityReportMain.jsp')">Productivity Report</a>
					</li>
					<li >
						<a class="reportlink" href="javascript:openCMReport('TACMVolumeReport','TACMVolumeReportMain.jsp')">Volume Report</a>
					</li>
					<li >
						<a class="reportlink" href="javascript:openCMReport('TACMUserInfoReport1','TACMUserInfoMain.jsp')">User Info 1 Report</a>
					</li>
					<li >
						<a class="reportlink" href="javascript:openCMReport('TACMUserInfoReport2','TACMUserInfoGenerate.jsp')">User Info 2 Report</a>
					</li>
					</UL>
				
			</div><input type="hidden" id="node_2_status" name="node_2_status" value="1" />
			</div>
			<div id="node_title_3"><a href="javascript:void(0);" onclick="javascript:hide_menu('3',1);" class="link_text">
			
			<span class="node_title" id="node_3_title">&#9660;</span><span class="node_title"> TA EP Reports </span></a>
			<div id="node_3">
					<UL>
					<li >
						<a class="reportlink"  href="javascript:openCMReport('TAEPQueueStatus','EPQueueStatusMain.jsp')">Queue Status Report</a>
					</li>
					<li >
					   <a class="reportlink" href="javascript:openCMReport('TAEP_ApprovalReport','TAEPApprovalRepMain.jsp')" >Approval Report</a>
					</li>
					<li >
						<a class="reportlink" href="javascript:openCMReport('TAEPAgingReport','TACMAgingReportMain.jsp')">Aging Report</a>
					</li>
					<li >
						<a class="reportlink" href="javascript:openCMReport('TAEPMovementReport','TACMMovementReportMain.jsp')">Workitem Movement Report</a>
					</li>
					<li >
						<a class="reportlink" href="javascript:openCMReport('TAEPProductivityReport','EPProductivityReportMain.jsp')">Productivity Report</a>
					</li>
					<li >
						<a class="reportlink" href="javascript:openCMReport('TAEPVolumeReport','TACMVolumeReportMain.jsp')">Volume Report</a>
					</li>
					<li >
						<a class="reportlink" href="javascript:openCMReport('TAEPUserInfoReport1','TAEPUserInfoMain.jsp')">User Info 1 Report</a>
					</li>
					<li >
						<a class="reportlink" href="javascript:openCMReport('TAEPUserInfoReport2','TACMUserInfoGenerate.jsp')">User Info 2 Report</a>
					</li>
					</UL>
				
			</div><input type="hidden" id="node_3_status" name="node_3_status" value="1" />
			</div>
				
			</table>
			</form>
</body>
</Html>
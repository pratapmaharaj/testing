

<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="java.lang.String.*"%>
<%@ page import="java.lang.Object"%>
<%@ page import="java.lang.Exception"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<HTML>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<HEAD>
<TITLE>TA GA Report</TITLE>
</HEAD>
<%
String req=request.getParameter("name");
%>
<FRAMESET ROWS="100%,0%" >
	<FRAME SRC="GAReport.jsp.jsp?ReportName=<%=req%>" NAME="frmHeader" frameborder=no noresize scrolling=Yes>
	<FRAME SRC="" NAME="<%=req%>" frameborder=no scrolling=no>
	
</FRAMESET>
</html>


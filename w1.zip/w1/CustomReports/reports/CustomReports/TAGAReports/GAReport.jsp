

<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>

<%@ include file="customized.process" %>


<HTML>
<HEAD>
<TITLE>AP Aging Report</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>
<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
}
</style>

<script>
	$(document).ready(function(){$('#From_Date_disp').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date_disp').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	
	});
	var FromDate = new Date();
	var type = '';
	var allWindows = new Array();
	var win; // new window object
/*functions echeck,ValidateForm*/
/*functions echeck,ValidateForm*/
	function echeck(str) 
	{
		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}

function ValidateForm(emailID)
{
	//	var emailID=document.frmSample.txtEmail
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }


function DateComparator(Date_To,Date_From)
{	

	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));	
	var Date_From_month=Date_From.substring(Date_From.indexOf("/")+1,Date_From.lastIndexOf("/"));

	/*converting ToDate month to number */
	if(Date_To_month=="JAN")
			Date_To_month="01";
		else if(Date_To_month=="FEB")
			Date_To_month="02";
		else if(Date_To_month=="MAR")
			Date_To_month="03";
		else if(Date_To_month=="APR")
			Date_To_month="04";
		else if(Date_To_month=="MAY")
			Date_To_month="05";
		else if(Date_To_month=="JUN")
			Date_To_month="06";
		else if(Date_To_month=="JUL")
			Date_To_month="07";
		else if(Date_To_month=="AUG")
			Date_To_month="08";
		else if(Date_To_month=="SEP")
			Date_To_month="09";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";


	/*converting FromDate month to number */
		if(Date_From_month=="JAN")
			Date_From_month="01";
		else if(Date_From_month=="FEB")
			Date_From_month="02";
		else if(Date_From_month=="MAR")
			Date_From_month="03";
		else if(Date_From_month=="APR")
			Date_From_month="04";
		else if(Date_From_month=="MAY")
			Date_From_month="05";
		else if(Date_From_month=="JUN")
			Date_From_month="06";
		else if(Date_From_month=="JUL")
			Date_From_month="07";
		else if(Date_From_month=="AUG")
			Date_From_month="08";
		else if(Date_From_month=="SEP")
			Date_From_month="09";
		else if(Date_From_month=="OCT")
			Date_From_month="10";
		else if(Date_From_month=="NOV")
			Date_From_month="11";
		else if(Date_From_month=="DEC")
			Date_From_month="12";
	
	var Date_To_date=Number(Date_To.substring(0,Date_To.indexOf("/")));	
	var Date_From_date=Number(Date_From.substring(0,Date_From.indexOf("/")));

		
	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));
	var Date_From_year=Number(Date_From.substring(Date_From.lastIndexOf("/")+1,Date_From.length));
			
		
		

	if(Date_To_year < Date_From_year)
	{
	
		alert("To Date cannot be less than From  Date.");
		return false;
	}


	else if(Date_To_year > Date_From_year)
	{

			

		//if(Date_From_month>Date_To_month)
		//{
		//alert("To Date can not be less than From Date.");
		//return false;
		//}
		 if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{

				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}


	else if(Date_To_year==Date_From_year)
	{

		
		if(Date_From_month>Date_To_month)
		{
		alert("To Date can not be less than From Date.");
		return false;
		}
		else if(Date_From_month==Date_To_month)
		{
		
			if(Date_To_date < Date_From_date)
			{
		

				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}
	var toDate = new Date(Date_To_month+"/"+Date_To_date+"/"+Date_To_year);
	var fromDate = new Date(Date_From_month+"/"+Date_From_date+"/"+Date_From_year);
	var oneDay=1000*60*60*24;

	var dateDiff=Math.ceil((toDate.getTime()-fromDate.getTime())/oneDay);
	if(dateDiff>92)
	{
		alert('Date Range can not be greater than 92 days.');
		return false;
	}
return true;
}


function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";
	sDate	= window.showModalDialog('/processmanager/reports/GMACReports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');
	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
	

}
function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	strResult=strdate+"/"+strMonth+"/"+stryear;
	return strResult;
}


	
	
function openreport()
{	//changed by megha
	//var From_Date = document.forms["textForm"].From_Date.value;
	var From_Date = document.getElementById('From_Date_disp').value;
	//var To_Date   = document.forms["textForm"].To_Date.value;
	var To_Date   = document.getElementById('To_Date_disp').value;
	var fromHH = document.getElementById('FHours').value ;
	var toHH   = document.getElementById('THours').value ;
	var fromMM = document.getElementById('FMins').value ;
	var toMM   = document.getElementById('TMins').value ;	
	var UserEmailID=document.getElementById('EMail-ID').value;
	
	if(From_Date == "")
		{
			alert("Please select an appropriate From Date");
			return false;
		}
		else if(To_Date == "")
		{
			alert("Please select an appropriate To Date");
			return false;
		}
		else if(!DateComparator(To_Date,From_Date))
		{
			return false;
		}

		if (From_Date ==To_Date)
		{
			if ((fromHH == toHH)&&(fromMM == toMM))
			{
				alert("From time and To time is equal for the same date.Kindly select proper Date/Time.");
				return false;
			}
			else if ((fromHH == toHH)&&((fromMM > toMM)))
			{
				//alert("FMins "+document.getElementById('FMins').value+" TMins "+document.getElementById('TMins').value);
				alert("From time is greater than To time for the same date.Kindly select proper Date/Time.");
				return false;
			}
			else if (fromHH > toHH)
			{
				alert("From time is greater than To time for the same date.Kindly select proper Date/Time.");
				return false;
			}
		}
		
		//------------------------------------Manish UserEmail Validation start--------------------------------	
		
		if(UserEmailID=='')
		{
			alert("Kindly enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
				//Date 01-Jan-2015 Manish bug fix for invalid email id 
				return false;
			}
		}
		
		
		/* if(UserEmailID!='')
			{	
			window.top.TAAPAgingReport.location.href="TAGAGenerate.jsp?Document_Category="+Document_Category+"&Coder_code="+Coder_code+"&Vendor_Name="+Vendor_Name+"&Vendor_Number="+Vendor_Number+"&Cost_centre="+Cost_centre+"&Account="+Account+"&Company_code="+Company_code+"&From_Date_Intro="+From_Date_Intro+"&To_Date_Intro="+To_Date_Intro+"&From_Date_Q="+From_Date_Q+"&To_Date_Q="+To_Date_Q+"&ReportName=<%=request.getParameter("ReportName")%>&UserEmailID="+UserEmailID;
			}*/
			
		//------------------------------------ Manish UserEmail Validation End--------------------------------
			
		
		var DateRangeFrom = convertdateBnL(From_Date);
		var DateRangeTo   = convertdateBnL(To_Date);
	
	

		var FTime=document.getElementById("FHours").value+":"+document.getElementById("FMins").value;
		var TTime=document.getElementById("THours").value+":"+document.getElementById("TMins").value;
		

		//OpenRedict-Fix
    //window.top.GAREPORT.location.href="TAGAGenerate.jsp?FromDates="+From_Date+"&ToDate="+To_Date+"&FHours="+document.getElementById("FHours").value+"&FMins="+document.getElementById("FMins").value+"&THours="+document.getElementById("THours").value+"&TMins="+document.getElementById("TMins").value+"&ReportName=<%=request.getParameter("ReportName")%>&UserEmailID="+UserEmailID;
	var URI = "TAGAGenerate.jsp?FromDates="+From_Date+"&ToDate="+To_Date+"&FHours="+document.getElementById("FHours").value+"&FMins="+document.getElementById("FMins").value+"&THours="+document.getElementById("THours").value+"&TMins="+document.getElementById("TMins").value+"&ReportName=<%=request.getParameter("ReportName")%>&UserEmailID="+UserEmailID;
	var StrOpenWin=strip_tags(URI,"");
	window.top.GAREPORT.location.href=StrOpenWin;
		
}


	function convertdateBnL(sLocalDate)
	{
		var sDateSeparator="-";
		var strResult;
		var nBegIndex   =sLocalDate.indexOf(sDateSeparator);
		var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
		var strdate     = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
		var stryear     = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
		var strMonth    ="";
		if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";
		strResult = strdate+"/"+strMonth+"/"+stryear;
		return strResult;
	}

	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}

 
 	
function copyValue(obj,obj1)
{
	if(obj.value=='')
	{
		return "" ;
	}
	obj1.value = obj.value ;
}

</script>

<body  leftmargin="5"  onunload="UnloadReportWindow();" >

			<form name='textForm' method=post>
			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
				<%
				String name=request.getParameter("ReportName");
				if(name.equals("approver_rejection"))
				{
				%>
					<td class="EWSubHeader" colspan="2">TA GA Approver Rejection Report</td>
					
				<%
				}
				else if(name.equals("automaintenance")){
				%>
					<td class="EWSubHeader" colspan="2">TA GA Automaintenance Report</td>
					
				<%
				}
				else if(name.equals("gl_request")){
				%>
					<td class="EWSubHeader" colspan="2">TA GA GL Request Feed Report</td>
					
				<%
				}
				else if(name.equals("je_request")){
				%>
					<td class="EWSubHeader" colspan="2">TA GA JE Request Feed Report</td>
					
				<%
				}
				else if(name.equals("interface_total")){
				%>
					<td class="EWSubHeader" colspan="2">TA GA Interface Total Report</td>
					
				<%
				}
				else if(name.equals("pending_jegl")){
				%>
					<td class="EWSubHeader" colspan="2">TA GA Pending JE GL Approval Report</td>
					
				<%
				}
				else{
				%>
				<td class="EWSubHeader" colspan="2">TA GA REPORT</td>
				<%
				}%>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr>
				<tr>
					<td class="EWLabel1">Select the requisite date range for generating the report for the same.</td>
				</tr>
				

				<tr>
	

	
		<td style="color: red; font-size: 10pt">Note:  * fields are mandatory.</td>

		</tr>
		</table>
		
		<table>
		<tr>&nbsp;</tr>
				<tr>
		<tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>Date Range<font color="RED">*</font></b><br> 
					</td>
					
					<td class="EWLabel1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					&nbsp;<b>HH</b>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>MM</b></td>
					</tr>
					<tr><td class="EWLabel1" align="left" width='20%'>
					<b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date"  type="hidden"  id="From_Date">
					<input class='TextFieldColorDate' name="From_Date_disp"  type="text" readonly id="From_Date_disp">
					
					<!--id given by megha-->
					<select name="FHours" id="FHours">
					<option value="00">00</option>
					<option value="01">01</option>
					<option value="02">02</option>
					<option value="03">03</option>
					<option value="04">04</option>
					<option value="05">05</option>
					<option value="06">06</option>
					<option value="07">07</option>
					<option value="08">08</option>
					<option value="09">09</option>
					<option value="10">10</option>
					<option value="11">11</option>
					<option value="12">12</option>
					<option value="13">13</option>
					<option value="14">14</option>
					<option value="15">15</option>
					<option value="16">16</option>
					<option value="17">17</option>
					<option value="18">18 </option>
					<option value="19">19</option>
					<option value="20">20</option>
					<option value="21">21</option>
					<option value="22">22</option>
					<option value="23">23</option>
 					</select>
				 <!-- id given by megha-->
				 <select name="FMins" id="FMins">
				<%
					for(int i=0;i<60;i++)
					{
					%>
					<option value='<%=i%>'><%= i %></option>
					<%} 
				%>
					</tr>
					</select></td>
				 
					
					<tr>
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date"  type="hidden"  id="To_Date" >
					<input class='TextFieldColorDate' name="To_Date_disp"  type="text" readonly id="To_Date_disp" >
					
					<!-- id given by megha-->
					<select name="THours" id="THours">
					<option value="00">00</option>
					<option value="01">01</option>
					<option value="02">02</option>
					<option value="03">03</option>
					<option value="04">04</option>
					<option value="05">05</option>
					<option value="06">06</option>
					<option value="07">07</option>
					<option value="08">08</option>
					<option value="09">09</option>
					<option value="10">10</option>
					<option value="11">11</option>
					<option value="12">12</option>
					<option value="13">13</option>
					<option value="14">14</option>
    				<option value="15">15</option>
					<option value="16">16</option>
					<option value="17">17</option>
					<option value="18">18</option>
					<option value="19">19</option>
					<option value="20">20</option>
					<option value="21">21</option>
					<option value="22">22</option>
					<option value="23">23</option>
 					</select>
				 
				 <select name="TMins" id="TMins">
				 <%
					for(int j=0;j<60;j++)
					{
					%>
					<option value='<%=j%>'><%=j%></option>
					<%} %>
					</tr>
					</select>
					</td>
					
						</td>
					
				</tr>
			
				
			</table>			
			<br>
			<table>
			<tr>
			
			<td class="EWLabel1" align="left" width='38%'><b>Enter Email address:</b><br> 
					</td>
			
				<!-- <input class='TextFieldColorDate' name="Email_id" readonly type="text"  id="Email_id" ></td> -->
				
				<td >
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<input type='text' name='Email_id' style='width:136' id='EMail-ID'>
					</td>
			</tr>
			</table>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>
	
			
			</form>
</body>
</Html>	 




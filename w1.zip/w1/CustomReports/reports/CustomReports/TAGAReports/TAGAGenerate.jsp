<%@ include file="customized.process" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.sql.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>

<HTML>
<HEAD>
<TITLE>AP Aging Report</TITLE>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
</script>

<body >
<%
WriteLog("TA_GA_Report","sOutputXML ::> sOutputXML : IN TAGAREPORT") ;
	String fromDate="";
	String toDate="";
	String fromDateMinute="";
	String fromDateHour="";
	String toDateMinute="";
	String toDateHour="";
	String reportName="";
	String sProcedureNameKey="";
	String sProcedureName="";
	String sCabinetName="";
	String UserEmailID="";
	
	reportName	=request.getParameter("ReportName");
	fromDate=request.getParameter("FromDates");
	toDate=request.getParameter("ToDate");
	fromDateMinute=request.getParameter("FMins");
	fromDateHour=request.getParameter("FHours");
	toDateMinute=request.getParameter("TMins");
	toDateHour=request.getParameter("THours");
    UserEmailID=request.getParameter("UserEmailID");;
	reportName	=reportName.toUpperCase();
	WriteLog("TA_GA_Report","sReportName : "+reportName) ;
	sProcedureNameKey=reportName+"_PROCEDURENAME" ;
	WriteLog("TA_GA_Report","sProcedureNameKey : "+sProcedureNameKey) ;
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAGAReport.ini";
	Properties ini = new Properties();
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("TA_GA_Report","Unable to read TA_GA_Report.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("TA_GA_Report","Unable to close the TA_GA_Report.ini file");
						}
					}
				}
	
	sCabinetName=ini.getProperty("CABINETNAME");
	sProcedureName=ini.getProperty(sProcedureNameKey);
	
	String sCabname=null;
	String sSessionId = null;
	String sJtsIp = null;
	String sUserName = null;
	String sReportProcedureName=null;
	String sReportTableName=null;
	String sOutputXML="";
	String sInputXML = "";
	String maincode = "";
	String Totalrec = "0";
	String url = "";
	String Status="";
	String sStr_ServerType="";
	String sInputXml="";
	double fPercentage=0;
	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("TA_GA_Report","sRootPathDBini="+sRootPathDBini);
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("TA_GA_Report","Unable to read TA_GA_Report.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("TA_GA_Report","Unable to close the TA_GA_Report.ini file");
						}
					}
				}
	
	String driverName = null;

	String connectionUrl=ini.getProperty("CONNECTIONSTRING");
	driverName = ini.getProperty("DRIVERNAME");

	
	WriteLog("TA_GA_Report","TAGAGenerate.jsp?FromDates="+fromDate+"&ToDate="+toDate+"&FHours="+fromDateHour+"&FMins="+fromDateMinute+"&THours="+toDateHour+"&TMins="+toDateMinute+"&ReportName="+reportName);
	String sRowXml="";
	int iJtsPort = 0;
	boolean bError=false;
	CallableStatement callableStatement = null;
	Connection conn=null;	
	String getDBUSERByUserIdSql = "{call "+sProcedureName+"(?,?,?,?,?,?,?,?)}";

	String output = "" ;
	WriteLog("TA_GA_Report",sProcedureName);
			
	try{
			Class.forName(driverName);
			conn = DriverManager.getConnection(connectionUrl);
			callableStatement = conn.prepareCall(getDBUSERByUserIdSql);
			callableStatement.setString(1, fromDate);
			callableStatement.setString(2, toDate);
			callableStatement.setString(3, fromDateHour);
			callableStatement.setString(4, fromDateMinute);
			callableStatement.setString(5, toDateHour);
			callableStatement.setString(6, toDateMinute);
			callableStatement.setString(7, UserEmailID);
			callableStatement.registerOutParameter(8, java.sql.Types.VARCHAR);
			callableStatement.execute();

			output = callableStatement.getString(8);
			WriteLog("TA_GA_Report"," output "+output);
			
	}
	catch(SQLException ignore)
	{
		%>
									<script>alert("Some Error please check logs");</script>
									<%
		WriteLog("TA_GA_Report"," WFSession Data Fetch Exception:::::: "+ignore.toString());
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		bError= true;
		System.out.println(ignore);
	}
	finally {
 
	if (callableStatement != null) {
        try {
            callableStatement.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
	}
	if(!bError)
	{

		WriteLog("TA_GA_Report"," output:::::: "+output);
		try
		{

			if(output.equals(""))
			{
				bError= true;
					%>
					<script>alert("Error in Executing Procedure:");</script>
					<%
				//maincode=sOutputXML.substring(sOutputXML.indexOf("<MainCode>")+10 , sOutputXML.indexOf("</MainCode>"));
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+output+"</b></font><center>");
				
				
			}
			else
			{
				
					try
							{
								 if(Integer.parseInt(output) == 0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("Report Generated successfully");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
							log("TA_GA_Report "+ig.toString());
							
							%>
									<script>alert("Some Error please check logs");</script>
									<%
								out.println(ig.toString());
								
												
							}
			}
		}
		
		catch(Exception exp)
		{
			%>
									<script>alert("Some Error please check logs");</script>
									<%
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
			log("TA_GA_Report "+exp.toString());
			
		}
		
	}


%>
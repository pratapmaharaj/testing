        
/*          
      
    
      
WNS_TA_USER_INFO_REPORT2 'yog1@qq.com','//10.33.192.139/XLS-File/Yogesh/UserInfReport2','APVS_UserInfoReport2','All~',''    
      
WNS_TA_USER_INFO_REPORT2  'as@1234.com','//10.33.192.139/XLS-File/Yogesh/UserInfReport2','AP_UserInfoReport2','Introduction~','',''  
*/          
CREATE PROCEDURE WNS_TA_USER_INFO_REPORT2       
(          
@EmailID  nvarchar(200) ,      
@FilePath nvarchar(300),      
@fileName nvarchar(300),      
@QueueName nvarchar(300),      
@GroupName nvarchar(300),    
@RowCount varchar(200) OUTPUT      
)      
AS      
SET NOCOUNT ON        
BEGIN      
DECLARE                      
@DataBaseName     nvarchar(255),        
@sStatus          nvarchar(20),          
@suserName        nvarchar(100),      
@spersonalName    nvarchar(100),           
@sfamilyName      nvarchar(100),       
@sGroupName       nvarchar(100),          
@sQueueName       nvarchar(100),        
@sConcatQueueName nvarchar(500) ,        
@Query            nvarchar(500) ,        
@GroupNameReport  nvarchar(600),      
@QueueNameReport  nvarchar(600),      
@WhereQuery    varchar(2000),       
@lastInd int  ,      
@Uquery nvarchar(550)       
      
set @WhereQuery='select distinct b.username,b.PersonalName,b.FamilyName,c.groupname,e.queuename           
 into TA_TEMP_TABLE_USER_INFO2             
 from pdbgroupmember a,pdbuser b,pdbgroup c , QUEUEUSERTABLE d ,QUEUEDEFTABLE e            
 where '      
set @Uquery=''      
set @GroupNameReport = ''      
set @QueueNameReport = ''      
set @RowCount ='0'      
-- Temp Table for keeping all user with group and queue          
     
      
if Object_ID ('TA_TEMP_TABLE_USER_INFO2') is not null        
BEGIN        
 exec('drop table TA_TEMP_TABLE_USER_INFO2')           
print 'drop'      
END        
   
      
 set @FileName=@FilePath+'/'+@EmailID+'_'+@fileName+'_'+convert(varchar,getdate(),104)+'.xls'          
 SET @DataBaseName = DB_name()          
      
 if(@GroupName<>'')      
 BEGIN      
  if(rtrim(ltrim(@GroupName))<>'All~')       
  BEGIN       
   --Added to Check for only 1 parameter       
   if(len(@GroupName)=charindex('~',@GroupName))       
   BEGIN       
    print '11'      
    set @GroupNameReport=ltrim(rtrim(substring(@GroupName,0,len(@GroupName))))       
    set @WhereQuery=@WhereQuery+' c.groupname='''+@GroupNameReport+''''       
   END       
      
   --Added to Check for only 1 parameter         
   else       
   BEGIN       
    -----While loop ends       
    print '22'      
    while (charindex('~',@GroupName)>1)       
    BEGIN       
     print '25'      
     set @GroupNameReport = @GroupNameReport + ''''+ltrim(rtrim(SUBSTRING(@GroupName,1,Charindex('~',@GroupName)-1)))+''''+','       
     set @GroupName=ltrim(rtrim(Substring(@GroupName,Charindex('~',@GroupName)+len('~'),len(@GroupName))))       
     print @GroupNameReport      
    END       
    print '23'      
      
    set @GroupNameReport=substring(@GroupNameReport,0,len(@GroupNameReport))       
    set @WhereQuery= @WhereQuery + ' c.groupname in('+@GroupNameReport+') and a.groupindex=c.groupindex'      
   END       
  END       
  else      
  BEGIN      
   set @WhereQuery = @WhereQuery + ' c.groupname in(select distinct GroupName from pdbgroup where groupname like ''%VS%'') '      
  END      
  print '24'      
  set @WhereQuery = @WhereQuery + ' and e.queuename like ''TA_APVS_%'' '      
  print @WhereQuery      
 END      
      
 if(@QueueName<>'')      
 BEGIN      
  print @Uquery      
  if(rtrim(ltrim(@QueueName))<>'All~')       
  BEGIN       
   print '33'      
   --Added to Check for only 1 parameter       
   if(len(@QueueName)=charindex('~',@QueueName))       
   BEGIN       
    print '44'      
    set @QueueNameReport=ltrim(rtrim(substring(@QueueName,0,len(@QueueName))))       
    set @WhereQuery=@WhereQuery+'  e.queuename like ''TA_APVS_'+@QueueNameReport+''''       
  END       
   --Added to Check for only 1 parameter         
   else       
   BEGIN       
    print '55'      
    -----While loop ends       
    while (charindex('~',@QueueName)>1)       
    BEGIN       
     set @QueueNameReport = @QueueNameReport + '''TA_APVS_'+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+''''+','       
     set @QueueName=ltrim(rtrim(Substring(@QueueName,Charindex('~',@QueueName)+len('~'),len(@QueueName))))       
    END       
      
    set @QueueNameReport=substring(@QueueNameReport,0,len(@QueueNameReport))       
    set @WhereQuery=@WhereQuery+'  e.queuename in('+@QueueNameReport+') '      
   END       
  END      
  ELSE      
  BEGIN      
    set @WhereQuery=@WhereQuery+'e.queuename like ''TA_APVS_%'' '      
  END      
  set @WhereQuery=@WhereQuery+' and  c.groupname in(select distinct GroupName from pdbgroup where groupname like ''%TA%'')'      
 END      
      
       
 set @WhereQuery = @WhereQuery+' and a.userindex=b.userindex      
 and a.userindex=d.userid      
  and a.userindex<>1           
group by b.username,b.PersonalName,b.FamilyName,c.groupname,e.queuename       
order by b.username'      
  
       
 print @WhereQuery      
 exec(@WhereQuery)      
       
 select @RowCount=count(*) from TA_TEMP_TABLE_USER_INFO2 with(nolock)       
 print @RowCount      
 if(@RowCount=0)      
 Begin      
  print '1'                  
  drop table TA_TEMP_TABLE_USER_INFO2      
 End      
                
 else      
 Begin      
  if Object_ID ('TA_USERINFO2_TEMP_AUTOMAIL') is not null             
  BEGIN      
   exec('drop table TA_USERINFO2_TEMP_AUTOMAIL')             
  END      
      
  Exec('Create table TA_USERINFO2_TEMP_AUTOMAIL (Header varchar(8000))')                   
  print 'FileName='  + @FileName                   
  Exec('Insert into TA_USERINFO2_TEMP_AUTOMAIL       
  Select ''<html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>                 
  <table border=1>        
  <tr align="left"><td colspan=16 class=headerbold>TA USER INFO2 REPORT</td></tr>        
  </table><br>                   
  <table border=1><tr>''+            
  ''<td class=headerbold>User Name</td>''+                  
  ''<td class=headerbold>First Name</td>''+             
  ''<td class=headerbold>Last Name</td>''+                  
  ''<td class=headerbold>Group Name</td>''+                  
  ''<td class=headerbold>Queue Name</td>''                 
  +''</tr></font>''        
  UNION ALL             
  Select distinct ''<tr><td align=left style=mso-number-format:\\@>''+ISNULL([username],'''')+''</td>''+                  
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([PersonalName],'''')+''</td>''+      
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([FamilyName],'''')+''</td>'' +              
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([groupname],'''')+''</td>'' +              
  ''<td align=left style=mso-number-format:\\@>''+ISNULL(queuename,'''')+''</td></tr>''      
  from TA_TEMP_TABLE_USER_INFO2')      
        
  update TA_USERINFO2_TEMP_AUTOMAIL set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yy>&nbsp</td>')              
  SET @Query = 'Master..xp_Cmdshell ''bcp "select Header FROM '+@DataBaseName+'..TA_USERINFO2_TEMP_AUTOMAIL " queryout "'+@FileName+'" -c -T'' '              
       
  SET @Query='Master..xp_Cmdshell ''bcp "select * FROM '+@DataBaseName+'..TA_USERINFO2_TEMP_AUTOMAIL" queryout "'+@FileName+'" -c -T'',No_output'           
  print @Query                  
  exec(@Query)          
  insert into NG_AutoMail_Status values('TA UserInfo2 Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL)       
      
  declare @query1 nvarchar(1000)            
      
 -- exec(@query1)         
      
  drop table TA_TEMP_TABLE_USER_INFO2             
  drop table TA_USERINFO2_TEMP_AUTOMAIL                  
 END      
 Select @RowCount      
END 
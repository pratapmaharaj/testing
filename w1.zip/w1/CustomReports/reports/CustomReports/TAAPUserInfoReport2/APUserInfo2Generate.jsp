<%@ include file="customized.process" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="java.sql.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>

<HTML>
<HEAD>
<TITLE>AP User Info Report 2</TITLE>
</HEAD>

<link href="/webdesktop/CustomForms/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>


<body >
<%!

 public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }
%>

<%
WriteLog("2_APUSERINFO","sOutputXML ::> sOutputXML : here") ;

	Connection conn = null;
	Statement st;
	String connectionUrl =""; 
	boolean empty=true;

	String sProcessDefId=null;
	String sProcedureName=null;
	String sColumnHeaders=null;
	String sReportName=null;
	String sFileName=null;
	String sNumberOfColumns=null;
	String sProcedureNameKey=null;
	String sColumnHeadersKey=null;
	String sFileNameKey=null;
	String sNumberOfColumnsKey=null;
	String sHeaderKey=null;
	String sHeaderPresentKey=null;
	String sDBMappedColsKey=null;
	String sHeaderValue=null;
	String sHeaderPresentValue=null;
	String sCabinetName=null;	
	String sDBMappedCols=null;
	String sFieldValuesKey=null;
	String sFieldValues=null;
	String sFieldValuesReport="";
	String sUserMailID=null;
	String sFilePath=null;
	String sFilePathKey=null;
	String GroupName = "" ;

	sReportName	=request.getParameter("ReportName");

	sUserMailID=request.getParameter("UserEmailID");
	sReportName	=sReportName.toUpperCase();
	GroupName = request.getParameter("GroupName");

	String QueueName=request.getParameter("QueueName");
	WriteLog("2_APUSERINFO","sOutputXML ::> sReportName : "+sReportName) ;
	WriteLog("2_APUSERINFO","sOutputXML ::> sUserMailID : "+sUserMailID) ;

	sProcedureNameKey=sReportName +"_PROCEDURENAME" ;
	WriteLog("2_APUSERINFO","sOutputXML ::> sProcedureNameKey : "+sProcedureNameKey) ;
	sColumnHeadersKey=sReportName+"_COLUMNHEADERS";
	WriteLog("2_APUSERINFO","sOutputXML ::> sColumnHeadersKey : "+sColumnHeadersKey) ;
	sFileNameKey=sReportName+"_FILENAME";

	WriteLog("2_APUSERINFO","sOutputXML ::> sFileNameKey : "+sFileNameKey) ;

	sNumberOfColumnsKey=sReportName+"_NUMBEROFCOLUMNS";

	WriteLog("2_APUSERINFO","sOutputXML ::> sNumberOfColumnsKey : "+sNumberOfColumnsKey) ;

	sHeaderPresentKey=sReportName+"_HEADERPRESENT";

	WriteLog("2_APUSERINFO","sOutputXML ::> sHeaderPresentKey : "+sHeaderPresentKey) ;
	
	sHeaderKey=sReportName+"_HEADER";

	WriteLog("2_APUSERINFO","sOutputXML ::> sHeaderKey : "+sHeaderKey) ;
	sDBMappedColsKey=sReportName+"_DBMAPPEDCOLS";
	WriteLog("2_APUSERINFO","sOutputXML ::> sDBMappedColsKey : "+sDBMappedColsKey) ;
	sFieldValuesKey=sReportName+"_FIELDVALUES";

	WriteLog("2_APUSERINFO","sOutputXML ::> sFieldValuesKey : "+sFieldValuesKey) ;
	
	sFilePathKey=sReportName+"_FILEPATH";
	

	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAAPUserInfoReport2.ini";

	Properties ini = new Properties();
	
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("2_APUSERINFO","Unable to read 2_APUSERINFO.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("2_APUSERINFO","Unable to close the 2_APUSERINFO.ini file");
						}
					}
				}
	

	String pathName = "" ;
	pathName = ini.getProperty(sReportName +"_FILEPATH");

	sProcedureName=ini.getProperty(sProcedureNameKey);

	sColumnHeaders=ini.getProperty(sColumnHeadersKey);

	sFileName=ini.getProperty(sFileNameKey);

	sDBMappedCols=ini.getProperty(sDBMappedColsKey);
	
	sFieldValues=ini.getProperty(sFieldValuesKey);
	
	sFilePath=ini.getProperty(sFilePathKey);
	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("2_APUSERINFO","sRootPathDBini="+sRootPathDBini);
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("2_APUSERINFO","Unable to read 2_APUSERINFO.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("2_APUSERINFO","Unable to close the 2_APUSERINFO.ini file");
						}
					}
				}
	

	String conString = null;
	String driverName = null;
	driverName=ini.getProperty("DRIVERNAME");
	connectionUrl=ini.getProperty("CONNECTIONSTRING");
	WriteLog("2_APUSERINFO","driverName="+driverName+",connectionUrl="+connectionUrl);

	CallableStatement callableStatement = null;

	String sCabname=null;
	String sSessionId = null;
	String sJtsIp = null;
	String sUserName = null;
	String sReportProcedureName=null;
	String sReportTableName=null;
	

	String sToDate=request.getParameter("ToDate");
	String sOutputXML="";
	String sInputXML = "";
	String maincode = "";
	String Totalrec = "0";

	String url = "";
	String Status="";
	String sStr_ServerType="";
	String sInputXml="";

	//Aging Implementation
	
	int iJtsPort = 0;
	boolean bError=false;
	String getDBUSERByUserIdSql = "{call "+sProcedureName+"(?,?,?,?,?,?)}";
	String output = "" ;
	try
	{
			WriteLog("2_APUSERINFO"," QueueName "+QueueName);
			WriteLog("2_APUSERINFO"," GroupName "+GroupName);

			Class.forName(driverName);
			conn = DriverManager.getConnection(connectionUrl);
			callableStatement = conn.prepareCall(getDBUSERByUserIdSql);
			callableStatement.setString(1, sUserMailID);
			callableStatement.setString(2, sFilePath);
			callableStatement.setString(3, sFileName);
			callableStatement.setString(4, QueueName);
			callableStatement.setString(5, GroupName);
			callableStatement.registerOutParameter(6, java.sql.Types.VARCHAR);
			callableStatement.execute();

			output = callableStatement.getString(6);
			WriteLog("2_APUSERINFO"," output "+output);
	}
	catch(SQLException ignore)
	{
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		bError= true;
		WriteLog("2_APUSERINFO"," WFSession Data Fetch Exception:::::: "+ignore.toString());
	}
	finally {
 
	if (callableStatement != null) {
        try {
            callableStatement.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
	}
	if(!bError)
	{

		WriteLog("2_APUSERINFO"," output:::::: "+output);
		try
		{

			if(output.equals(""))
			{
				bError= true;
				//maincode=sOutputXML.substring(sOutputXML.indexOf("<MainCode>")+10 , sOutputXML.indexOf("</MainCode>"));
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+output+"</b></font><center>");
			}
			else
			{
				
					try
							{
								 if(Integer.parseInt(output) == 0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
								out.println(ig.toString());
												
							}
			}
		}
		
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
			log("2_APUSERINFO "+exp.toString());
		}
		
	}
%>
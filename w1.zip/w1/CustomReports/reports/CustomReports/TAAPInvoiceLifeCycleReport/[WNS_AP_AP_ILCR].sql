/*  
WNS_AP_AP_ILCR '01/JAN/2014','25/FEB/2014','All~','','','26/FEB/2014','All~','asdas@asdsa.com',  
'malkeet','//10.33.192.139/XLS-File/kalsi',''  
  
*/  
  
CREATE procedure [dbo].[WNS_AP_AP_ILCR]  
(  
@From_Date_Reg varchar(200),  
@To_Date_Reg varchar(200),  
@Document_Category varchar(200),  
@Vendor_Name varchar(200),  
@Vendor_Number varchar(200),  
@Transferred_date varchar(200),  
@QC_Decision varchar(200),  
@Email_Id varchar(200),  
@FileName varchar(200),     
@Path varchar(50),  
@RowCount varchar(50) out                           
)    
as   
declare   
@WhereQuery varchar(2000),                          
@Query varchar(max),                                                       
@Tables varchar(200),                          
@OrderBy varchar(300),  
@sDocument_Category varchar(400),  
@sQC_Decision varchar(300)  
                          
begin  
Set nocount on     
 set @FileName=@Path+'/'+@Email_Id+'_'+@FileName+'_'+convert(varchar,getdate(),104)+'.xls'    
 --set @FileName='//10.33.192.139/XLS-File/ProcessManager/reports/Gmac report/AP/'+@Email_Id+'maklkeet'+convert(varchar,getdate(),104)+'.xls'                                                 
 set @WhereQuery=' WHERE a.wi_name=b.wi_name '    
 set @Tables=' WNS_TA_AP_EXT_Table a with(nolock),WNS_TA_AP_EntryExitTable B with(nolock)'   
 set @OrderBy=' order by a.wi_name,b.activityname'      
 set @sDocument_Category=''    
 set @sQC_Decision=''  
print @WhereQuery  
Create table #AP_ILCR_Temp  
(  
Workitem_Name varchar(100),  
Queue_Name varchar(100),  
Document_Category varchar(100),  
Payment_terms varchar(100),  
Vendor_ID varchar(100),  
Vendor_Name varchar(100),  
ACH varchar(100),  
Check1 varchar(100),  
Invoice_Number varchar(100),  
Invoice_Date varchar(100),  
Invoice_Amount varchar(100),  
Qc_Decision varchar(100),  
QC_reason varchar(100),  
Transferred_date varchar(100),  
Payment_Date varchar(100),  
Check_Amount varchar(100),  
check_number varchar(100),  
Entry_Date varchar(100),  
Exit_Date varchar(100),  
)   
  
 if(rtrim(ltrim(@Document_Category))<>'All~')    
  BEGIN    
    if(len(@Document_Category)=charindex('~',@Document_Category))    
     BEGIN                   
       set @sDocument_Category=ltrim(rtrim(substring(@Document_Category,0,len(@Document_Category))))    
       print @sDocument_Category    
       set @WhereQuery=@WhereQuery+' and Document_Category='''+@Document_Category+''''    
     End    
    else    
     BEGIN             
       while (charindex('~',@Document_Category)>1)    
      BEGIN    
      set @sDocument_Category = @sDocument_Category + ''''+ltrim(rtrim(SUBSTRING(@Document_Category,1,Charindex('~',@Document_Category)-1)))+''''+','    
      set @Document_Category=ltrim(rtrim(Substring(@Document_Category,Charindex('~',@Document_Category)+len('~'),len(@Document_Category))))    
      END                               
      set @sDocument_Category=SUBSTRING(@sDocument_Category,0,len(@sDocument_Category))     
      set @WhereQuery=@WhereQuery+' and Document_Category in('+@sDocument_Category+')'       
    END    
 End  
 if(rtrim(ltrim(@QC_Decision))<>'All~')    
  BEGIN    
    if(len(@QC_Decision)=charindex('~',@QC_Decision))    
     BEGIN                   
       set @sQC_Decision=ltrim(rtrim(substring(@QC_Decision,0,len(@QC_Decision))))    
       print @sQC_Decision    
       set @WhereQuery=@WhereQuery+' and QC_Decision ='''+@QC_Decision+''''    
     End    
    else    
     BEGIN             
       while (charindex('~',@QC_Decision)>1)    
      BEGIN    
      set @sQC_Decision = @sQC_Decision + ''''+ltrim(rtrim(SUBSTRING(@QC_Decision,1,Charindex('~',@QC_Decision)-1)))+''''+','    
      set @QC_Decision=ltrim(rtrim(Substring(@QC_Decision,Charindex('~',@QC_Decision)+len('~'),len(@QC_Decision))))    
      END                               
      set @sQC_Decision=SUBSTRING(@sQC_Decision,0,len(@sQC_Decision))     
      set @WhereQuery=@WhereQuery+' and QC_Decision in('+@sQC_Decision+')'       
    END    
  
 end  
if(rtrim(ltrim(@From_Date_Reg))<>'')    
  SET @From_Date_Reg = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@From_Date_Reg,121)))))                           
    
 if(rtrim(ltrim(@To_Date_Reg))<>'')    
  SET @To_Date_Reg = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@To_Date_Reg,121)))))                      
    
 if(rtrim(ltrim(@From_Date_Reg)) != '' and rtrim(ltrim(@To_Date_Reg)) != '')                 
 BEGIN    
  set @WhereQuery = @WhereQuery+' and Entry_Time BETWEEN '''+@From_Date_Reg+''' AND '''+@To_Date_Reg+''''    
 END    
  
if(rtrim(ltrim(@Transferred_date))<>'')  
begin  
 SET @Transferred_date = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@Transferred_date,121)))))   
 select @Transferred_date= CAST(FLOOR(CAST(cast(@Transferred_date as datetime) AS FLOAT)) AS DATETIME)  
 print @Transferred_date  
 set @WhereQuery = @WhereQuery+' and CAST(FLOOR(CAST(Transferred_Date AS FLOAT)) AS DATETIME) ='''+@Transferred_date+''''  
end  
  
if(rtrim(ltrim(@Vendor_Number))<>'')  
Begin  
set @WhereQuery = @WhereQuery+' and Vendor_Number='''+@Vendor_Number+''''  
End  
  
if(rtrim(ltrim(@Vendor_Name))<>'')  
Begin  
set @WhereQuery = @WhereQuery+' and Vendor_Name='''+@Vendor_Name+''''  
End  
  
print @WhereQuery  
end  
set @Query=''  
set @Query='insert into #AP_ILCR_Temp select a.WI_Name,b.activityname,Document_Category,Payment_Term,Vendor_Number,Vendor_Name,ACH,AP_Check,Invoice_Number,Invoice_Date,Approved_Invoice_Amount,QC_Decision,Reason_For_Return_Check,Transferred_Date,Payment_Da
te,Check_Amount,Check_Number,b.Wi_EntryTime,b.Wi_ExitTime from '+@Tables+ @WhereQuery+@OrderBy  
  
print @Query  
  
exec (@Query)  
  
--select * from #AP_ILCR_Temp  
select @RowCount=count(*) from #AP_ILCR_Temp                        
 if(@RowCount=0)                          
  Begin                          
  drop table #AP_ILCR_Temp                          
  End                                  
else                         
 Begin                                                  
                               
if Object_ID ('NG_TEMP_AUTOMAIL') is not null                             
          BEGIN                             
          exec('drop table NG_TEMP_AUTOMAIL')                             
          END   
Create table NG_TEMP_AUTOMAIL (Header varchar(8000),Row_Index int IDENTITY(1,1) PRIMARY KEY )  
  
--select * from  NG_TEMP_AUTOMAIL                        
Exec('Insert into NG_TEMP_AUTOMAIL                                 
                Select ''<html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>                           
  
      
<table border=1><tr><td class=headerbold>Workitem Name</td>''+                                
''<td class=headerbold>Queue Name</td>''+                                                     
''<td class=headerbold>Document Category</td>''+                        
''<td class=headerbold>Payment Terms</td>''+               
''<td class=headerbold>Vendor ID</td>''+   
''<td class=headerbold>Vendor_Name</td>''+                   
''<td class=headerbold>ACH</td>''+                              
''<td class=headerbold>Check</td>''+                              
''<td class=headerbold>Invoice Number</td>'' +                        
''<td class=headerbold>Invoice Date</td>''+                      
''<td class=headerbold>Invoice Amount</td>''+   
''<td class=headerbold>Qc Decision</td>''+   
''<td class=headerbold>QC reason</td>''+   
''<td class=headerbold>Transferred Date</td>''+   
''<td class=headerbold>Payment Datet</td>''+   
''<td class=headerbold>Check Amount</td>''+   
''<td class=headerbold>Check Number</td>''+   
''<td class=headerbold>Entry Date</td>''+                      
''<td class=headerbold>Exit Date</td>'' +                           
''</tr></font>''                                 
UNION ALL                                 
Select ''<tr><td align=left style=mso-number-format:\\@>''+ISNULL([Workitem_Name],'''')+''</td>''+                                 
''<td align=left style=mso-number-format:\\@>''+ISNULL([Queue_Name],'''')+''</td>''+                        
''<td align=left style=mso-number-format:\\@>''+ISNULL([Document_Category],'''')+''</td>''+                       
''<td align=left style=mso-number-format:\\@>''+ISNULL([Payment_terms],'''')+''</td>''+                        
''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_ID],'''')+''</td>''+     
''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Name],'''')+''</td>''+     
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([ACH],'''')+''</td>''+     
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Check1],'''')+''</td>''+    
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Invoice_Number],'''')+''</td>''+  
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Invoice_Date],'''')+''</td>''+  
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Invoice_Amount],'''')+''</td>''+  
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Qc_Decision],'''')+''</td>''+  
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([QC_reason],'''')+''</td>''+  
 ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Transferred_date],''''),120)+''</td>''+  
 ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Payment_Date],''''),120)+''</td>''+  
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Check_Amount],'''')+''</td>''+  
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([check_number],'''')+''</td>''+  
''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Entry_Date],''''),120)+''</td>''+               
''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Exit_Date],''''),120)+''</td>''                           
from #AP_ILCR_Temp')                         
     
     
   --select * from NG_TEMP_AUTOMAIL     
     
   print @FileName               
update NG_TEMP_AUTOMAIL set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yy>&nbsp</td>')                          
SET @Query='Master..xp_Cmdshell ''bcp "select Header FROM GMAC..NG_TEMP_AUTOMAIL" queryout "'+@FileName+'" -c -T'',No_output'                               
--print @Query                        
exec(@Query)                              
insert into NG_AutoMail_Status values('GMAC Invoice Life Cycle Report',''+@FileName+'',''+@Email_Id+'',0,getdate(),NULL)                           
                             
drop table #AP_ILCR_Temp                              
drop table NG_TEMP_AUTOMAIL                                      
                                 
 End                             
select @RowCount                        
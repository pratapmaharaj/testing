<%@ include file="customized.process" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.sql.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="com.tcsta.util.PathUtil" %>

<HTML>
<HEAD>
<TITLE>AP Invoice Life Cycle Report</TITLE>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="/../../../omniflow/scripts/wfgeneral.js">
</script>

<body >
<%!

 public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }
%>

<%
WriteLog("AP_InvoiceLife_cycle_report","sOutputXML ::> sOutputXML : IN APAgingGenerate") ;

	String sProcessDefId=null;
	String sProcedureName=null;
	String sColumnHeaders=null;
	String sReportName=null;
	String sFileName=null;
	String sNumberOfColumns=null;
	String sProcedureNameKey=null;
	String sColumnHeadersKey=null;
	String sFileNameKey=null;
	String sNumberOfColumnsKey=null;
	String sHeaderKey=null;
	String sHeaderPresentKey=null;
	String sDBMappedColsKey=null;
	String sHeaderValue=null;
	String sHeaderPresentValue=null;
	String sCabinetName=null;	
	String sDBMappedCols=null;
	String sFieldValuesKey=null;
	String sFieldValues=null;
	String sFieldValuesReport="";
	String sUserMailID=null;
	String sFilePath=null;
	String sFilePathKey=null;
	String UserNames = "" ;
	
	sReportName	=request.getParameter("ReportName");
	sUserMailID=request.getParameter("UserEmailID");
	sReportName	=sReportName.toUpperCase();
	
	WriteLog("AP_InvoiceLife_cycle_report","sReportName : "+sReportName) ;
	WriteLog("AP_InvoiceLife_cycle_report","sUserMailID : "+sUserMailID) ;

	sProcedureNameKey=sReportName +"_PROCEDURENAME" ;
	WriteLog("AP_InvoiceLife_cycle_report","sProcedureNameKey : "+sProcedureNameKey) ;
	
	sColumnHeadersKey=sReportName+"_COLUMNHEADERS";
	
	WriteLog("AP_InvoiceLife_cycle_report","sColumnHeadersKey : "+sColumnHeadersKey) ;
	sFileNameKey=sReportName+"_FILENAME";

	WriteLog("AP_InvoiceLife_cycle_report","sFileNameKey : "+sFileNameKey) ;

	sNumberOfColumnsKey=sReportName+"_NUMBEROFCOLUMNS";

	WriteLog("AP_InvoiceLife_cycle_report","sNumberOfColumnsKey : "+sNumberOfColumnsKey) ;

	sHeaderPresentKey=sReportName+"_HEADERPRESENT";

	WriteLog("AP_InvoiceLife_cycle_report","sHeaderPresentKey : "+sHeaderPresentKey) ;
	
	sHeaderKey=sReportName+"_HEADER";

	WriteLog("AP_InvoiceLife_cycle_report","sHeaderKey : "+sHeaderKey) ;
	
	sDBMappedColsKey=sReportName+"_DBMAPPEDCOLS";
	WriteLog("AP_InvoiceLife_cycle_report","sDBMappedColsKey : "+sDBMappedColsKey) ;
	sFieldValuesKey=sReportName+"_FIELDVALUES";

	WriteLog("AP_InvoiceLife_cycle_report","sFieldValuesKey : "+sFieldValuesKey) ;
	
	sFilePathKey=sReportName+"_PATH";
	
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAAPInvoiceLifeCycleReport.ini";
	//String sRootPathini=application.getRealPath("")+File.separator+"reports"+File.separator+"GMACReports"+File.separator+"ApprovalProcessInvoiceLifeCycleReport" + File.separator + "reports.ini";
	Properties ini = new Properties();
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("AP_InvoiceLife_cycle_report","Unable to read AP_InvoiceLife_cycle_report.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("AP_InvoiceLife_cycle_report","Unable to close the AP_InvoiceLife_cycle_report.ini file");
						}
					}
				}
	
	

	String pathName = "" ;
	pathName = ini.getProperty(sReportName +"_PATH");
	sProcessDefId=ini.getProperty("PROCESSDEFID");
	
	sCabinetName=ini.getProperty("CABINETNAME");
	sProcedureName=ini.getProperty(sProcedureNameKey);
	
	sColumnHeaders=ini.getProperty(sColumnHeadersKey);
	
	sFileName=ini.getProperty(sFileNameKey);
	
	sNumberOfColumns=ini.getProperty(sNumberOfColumnsKey);
	
	sHeaderPresentValue=ini.getProperty(sHeaderPresentKey);
	
	sDBMappedCols=ini.getProperty(sDBMappedColsKey);
	
	sFieldValues=ini.getProperty(sFieldValuesKey);
	
	sFilePath=ini.getProperty(sFilePathKey);
	WriteLog("AP_InvoiceLife_cycle_report",sHeaderPresentValue);

	if(sHeaderPresentValue.equals("YES")) 
	{
		sHeaderValue=ini.getProperty(sHeaderKey);
	}

	String sOutputXML="";

	String maincode = "";
	String Totalrec = "0";
	String url = "";
	String Status="";

	String sColumnNamesArr[]=split(sColumnHeaders,',');
	String sDBMappedColsArr[]=split(sDBMappedCols,',');
	String sFinalColumns[]=split(sColumnHeaders,',');
	
	for(int i=0;i<sColumnNamesArr.length;i++)
	{
		if(sColumnNamesArr[i].indexOf("~D")!=-1)
			sFinalColumns[i]=sColumnNamesArr[i].substring(0,sColumnNamesArr[i].length()-2);

	}

	String sFieldNamesDB[]=split(sFieldValues,'#');

	for(int i=0;i<sFieldNamesDB.length;i++)
	{
		sFieldValuesReport=sFieldValuesReport+sFieldNamesDB[i]+',';
	}
	sFieldValuesReport=sFieldValuesReport.substring(0,sFieldValuesReport.length()-1);


	String From_Date_Reg=request.getParameter("From_Date_Reg");
	String To_Date_Reg=request.getParameter("To_Date_Reg");
	String Document_Category=request.getParameter("Document_Category");
	String Vendor_Name=request.getParameter("Vendor_Name");
	String Vendor_Number=request.getParameter("Vendor_Number");
	//String Transferred_date=request.getParameter("Transferred_date");
	String QC_Decision=request.getParameter("QC_Decision");
	String returnCheck=request.getParameter("returnCheck");
	String From_Date=request.getParameter("From_Date");
	String To_Date=request.getParameter("To_Date");
	String Queue=request.getParameter("Queue");
	String From_Date_pay=request.getParameter("From_Date_pay");
	String To_Date_pay=request.getParameter("To_Date_pay");

	WriteLog("AP_InvoiceLife_cycle_report","APILCRGenerate.jsp?From_Date_Reg="+From_Date_Reg+"&To_Date_Reg="+To_Date_Reg+"&Document_Category="+Document_Category+"&Vendor_Name="+Vendor_Name+"&Vendor_Number="+Vendor_Number+"&From_Date="+From_Date+"&To_Date="+To_Date+"&QC_Decision="+QC_Decision+"&returnCheck="+returnCheck+"mailid-->"+sUserMailID+"filename-->"+sFileName+"patrh--->"+sFilePath);

	boolean bError=false;
	//connectionUrl = connectionUrl+";"+"databaseName="+sCabinetName+";user="+dbuserName+";password="+dbpass;
	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("AP_InvoiceLife_cycle_report","Unable to read AP_InvoiceLife_cycle_report.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("AP_InvoiceLife_cycle_report","Unable to close the AP_InvoiceLife_cycle_report.ini file");
						}
					}
				}
				
	WriteLog("AP_InvoiceLife_cycle_report","sRootPathDBini="+sRootPathDBini);
	String driverName = null;

	String connectionUrl=ini.getProperty("CONNECTIONSTRING");
	driverName = ini.getProperty("DRIVERNAME");
	CallableStatement callableStatement = null;
	Connection conn=null;
	String getDBUSERByUserIdSql = "{call "+sProcedureName+"(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";

	String output = "" ;
	String params = "'"+From_Date_Reg+"','"+To_Date_Reg+"','"+Document_Category+"','"+Vendor_Name+"','"+Vendor_Number+"','"+From_Date+"','"+To_Date+"','"+QC_Decision+"','"+returnCheck+"','"+Queue+"','"+From_Date_pay+"','"+To_Date_pay+"','"+sUserMailID+"','"+sFileName+"','"+sFilePath+"'" ;
	WriteLog("AP_InvoiceLife_cycle_report",sProcedureName+" "+params);

	try{
			Class.forName(driverName);
			conn = DriverManager.getConnection(connectionUrl);
			callableStatement = conn.prepareCall(getDBUSERByUserIdSql);
			callableStatement.setString(1, From_Date_Reg);
			callableStatement.setString(2, To_Date_Reg);
			callableStatement.setString(3, Document_Category);
			callableStatement.setString(4, Vendor_Name);
			callableStatement.setString(5, Vendor_Number);
			callableStatement.setString(6, From_Date);
			callableStatement.setString(7, To_Date);
			callableStatement.setString(8, QC_Decision);
			callableStatement.setString(9, returnCheck);
			callableStatement.setString(10, Queue);
			callableStatement.setString(11, From_Date_pay);
			callableStatement.setString(12, To_Date_pay);
			callableStatement.setString(13, sUserMailID);
			callableStatement.setString(14, sFileName);
			callableStatement.setString(15, sFilePath);
			callableStatement.registerOutParameter(16, java.sql.Types.VARCHAR);
			callableStatement.execute();

			output = callableStatement.getString(16);
			WriteLog("AP_InvoiceLife_cycle_report"," output :: "+output);
	}
	catch(SQLException ignore)
	{
		%>
									<script>alert("Some Error please check logs");</script>
									<%
		WriteLog("AP_InvoiceLife_cycle_report"," WFSession Data Fetch Exception:::::: "+ignore.toString());
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		bError= true;
		WriteLog("AP_InvoiceLife_cycle_report"," bError:::::: "+bError);
	}
	finally {
 
	if (callableStatement != null) {
        try {
            callableStatement.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
	}
	
	WriteLog("AP_InvoiceLife_cycle_report"," bError:::::: "+bError);
	if(!bError)
	{

		WriteLog("AP_InvoiceLife_cycle_report"," output:::::: "+output);
		try
		{

			if(output.equals(""))
			{
				bError= true;
					%>
					<script>alert("Error in Executing Procedure:");</script>
					<%
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+output+"</b></font><center>");
				
				
			}
			else
			{
					try
							{
								 if(Integer.parseInt(output) == 0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%
								}
								
							}
							catch(Exception ig)
							{ 
							log("AP_InvoiceLife_cycle_report"+ig.toString());
							%>
									<script>alert("Some Error please check logs");</script>
									<%
								out.println(ig.toString());
							}
			}
		}
		
		catch(Exception exp)
		{
			%>
									<script>alert("Some Error please check logs");</script>
									<%
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
			log("AP_ILCR "+exp.toString());
		}
		
	}


%>
 <%@ include file="customized.process" %>

<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>

<HTML>
<HEAD>
<TITLE>Returned To Business Unit Report</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>
<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
}
</style>
<script>
	$(document).ready(function(){$('#From_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", 
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", 
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#E_From_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", 
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#E_To_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", 
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	});
	var allWindows = new Array();
	var win; // new window object
	/*functions echeck,ValidateForm added by nilesh*/
	function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}

function ValidateForm(emailID){
//	var emailID=document.frmSample.txtEmail
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }


/*added by nilesh for comparision of Dates*/

function DateComparator(Date_To,Date_From)
	{	
			if (Date_From == "" && Date_To == "")
			{
				return true;
			}

			var FromDay = Date_From.split("/")[0];
			var FromMonth = convertMonth(Date_From.split("/")[1]);
			var FromYear = Date_From.split("/")[2];
			
			//alert("From:::Day::"+FromDay+"  Month::"+FromMonth+"	Year::"+FromYear);
			
			var ToDay = Date_To.split("/")[0];
			var ToMonth = convertMonth(Date_To.split("/")[1]);
			var ToYear = Date_To.split("/")[2];
			
			//alert("To:::Day::"+ToDay+"  Month::"+ToMonth+"	Year::"+ToYear);
			
			var CurrentDate=new Date();
			var CurrentDay = CurrentDate.getDate();
			var CurrentMonth = CurrentDate.getMonth();
			var CurrentYear = CurrentDate.getFullYear();
			//alert("Current:::Day::"+CurrentDay+"  Month::"+CurrentMonth+"	Year::"+CurrentYear);

			var toDate = (new Date(ToYear,ToMonth,ToDay)).getTime();
			var fromDate = (new Date(FromYear,FromMonth,FromDay)).getTime();
			var CurrentDate = (new Date(CurrentYear,CurrentMonth,CurrentDay)).getTime();
			
			//alert("FromDate::"+fromDate+"  ToDate::"+toDate+"	Current::"+CurrentDate);

			//alert("Fr : "+new Date(fromDate)+"\nTo : "+new Date(toDate)+"\nCu : "+new Date(CurrentDate));
			if(fromDate > toDate)
			{
				alert("To Date cannot be less than From Date.");
				return false;
			}
			else if(fromDate > CurrentDate)
			{
				alert("From Date cannot be future date.");
				return false;
			}
			else if(toDate > CurrentDate)
			{
				alert("To Date cannot be future date.");
				return false;
			}
			//alert("BAzooka111111!!!");
			return true;
	
	}
	function convertMonth(strMonth)
{
		if(strMonth=="JAN")
			strMonth="00";
		else if(strMonth=="FEB")
			strMonth="01";
		else if(strMonth=="MAR")
			strMonth="02";
		else if(strMonth=="APR")
			strMonth="03";
		else if(strMonth=="MAY")
			strMonth="04";
		else if(strMonth=="JUN")
			strMonth="05";
		else if(strMonth=="JUL")
			strMonth="06";
		else if(strMonth=="AUG")
			strMonth="07";
		else if(strMonth=="SEP")
			strMonth="08";
		else if(strMonth=="OCT")
			strMonth="09";
		else if(strMonth=="NOV")
			strMonth="10";
		else if(strMonth=="DEC")
			strMonth="11";
	return strMonth;
}


	
	
function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
var sDate="";
       sDate	= window.showModalDialog('/processmanager/reports/GMACReports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');



	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
	

}
function ChangeDateTag(obj)
{
	var InsertVal='';
	for(iterate=0;iterate<obj.length;iterate++)
	{
		if(obj.options[iterate].selected==true)
		{
			InsertVal=InsertVal+obj.options[iterate].value+'/';
		}
	}
	InsertVal=InsertVal.substring(0,InsertVal.length-1);
	var Table=document.getElementById('newgen');
	var lastRow = Table.rows.length;
	if (lastRow > 0) Table.deleteRow(lastRow - 1);
	while(InsertVal.indexOf('_')!=-1)
	{
		InsertVal=InsertVal.replace('_',' ');
	}
	var Row=Table.insertRow(0);
	var Cell=Row.insertCell();
	Cell.className="EWLabelBoldNew";
	//Cell.innerHTML=InsertVal;
}
function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	strResult=strdate+"/"+strMonth+"/"+stryear;
	return strResult;
}


	function openreport()
	{			
		
		var sQueue="";
		var sbexp="";
		var bQueueSelected=false;
		var sbexpselected=false;
		var UserEmailID=document.getElementById('EMail-ID').value;//added by nilesh
		var RegDateRangeFrom="";
		var RegDateRangeTo="";
		var QDateRangeFrom="";
		var QDateRangeTo="";
		
		var sDocCat="";
		
		
	
		sQueue=document.forms["textForm"].returnbu.value+'~';
		

		sbexp=document.forms["textForm"].bexp.value+'~';
	
		RegDateRangeFrom=document.forms["textForm"].From_Date.value;
		RegDateRangeTo=document.forms["textForm"].To_Date.value;	
		
		QDateRangeFrom=document.forms["textForm"].E_From_Date.value;
		QDateRangeTo=document.forms["textForm"].E_To_Date.value;	
		

	
		if ((RegDateRangeFrom=='' && RegDateRangeTo=='') && (QDateRangeFrom=='' && QDateRangeTo=='') )
		{
			alert("Please select Introduction Date Range or Exception Clearing Date Range.");
			return false ;
		}
			
		if ((RegDateRangeFrom=='' && RegDateRangeTo!='') || (RegDateRangeFrom!='' && RegDateRangeTo==''))
		{
			alert("Please select Introduction Date Range.");
			return false;
		}
		
		if(RegDateRangeFrom!='' && RegDateRangeTo!='')
		{
			if(!DateComparator(RegDateRangeTo,RegDateRangeFrom))
			{
				return false;
			}
		}

		if ((QDateRangeFrom=='' && QDateRangeTo!='') || (QDateRangeFrom!='' && QDateRangeTo==''))
		{
			alert("Please select Exception Clearing Date Range.");
			return false;
		}
		
		if(QDateRangeFrom!='' && QDateRangeTo!='')
		{
			if(!DateComparator(QDateRangeTo,QDateRangeFrom))
			{
				return false;
			}
		}

		if(UserEmailID=='')
		{
			alert("Kindly enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
				
			}
		}
	
	 if(UserEmailID!='')
			{	
				
				
				//OpenRedict-Fix
    //window.top.EXCEPTION.location.href="ESReturnBUGenerate.jsp?sQueue="+sQueue+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID+"&sbexp="+sbexp;
	var URI = "ESReturnBUGenerate.jsp?sQueue="+sQueue+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID+"&sbexp="+sbexp;
	var StrOpenWin=strip_tags(URI,"");
	window.top.EXCEPTION.location.href=StrOpenWin;	
				
			}
}
	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}

</script>


<body topmargin="0" leftmargin="5" onload="" onunload="UnloadReportWindow();">

			<form name='textForm' method=post>


			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">TA ES Returned To Business Unit Report</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This report will provide a list of work items which were processed and identified to be returned to the Business Unit. Return to BU = Yes
</td></tr>
<td class="EWLabel1">Select the requisite date range for generating the report for the same.<br>
<b>* Return to BU,Balance Related Exception and Introduction Date Range are mandatory.</b></td>
				</tr>
				
				<td>
				<br/>
					<p style="color: red; font-size: 10pt">Note:  * fields are mandatory.</p>

				</td>
			</table>
			<table border="0" width="95%" cellspacing="1" align="center">
				<tr>
					<td class="EWLabel1" align="left" width='20%'><b>Return to BU<font color="RED">*</font></b></font></td>
					<td width='25%' colspan=3>
						
							<input class='TextFieldColorDate' name="returnbu" readonly type="text" value="Yes"  disabled id="returnbu" >
						
					</td>
				</tr>
				<tr>
					<td class="EWLabel1" align="left" width='20%'><b>Balance Related Exception<font color="RED">*</font></b></font></td>
					<td width='25%' colspan=3>
					
						<input class='TextFieldColorDate' name="bexp" readonly type="text" value="Cleared" disabled id="bexp" >
						
					</td>
				</tr>
				 <tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>Introduction Date Range<font color="RED">*</font> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date" readonly type="text"  id="From_Date" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date" readonly type="text"  id="To_Date" >
					
					</td>

				 </tr>
				 <tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>Exception Clearing Date Range<font color="RED">*</font> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="E_From_Date" readonly type="text"  id="E_From_Date" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="E_To_Date" readonly type="text"  id="E_To_Date" >
					
					</td>

				 </tr>


				<!--Added by nilesh for additional E-mail ID field display -->
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID<font color="RED">*</font></b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>

				
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>
	

			</form>

</body>
</Html>	 



<%@ page import="java.io.*,java.util.*,java.sql.*"%>
<%@ page import="java.text.*"%>


<HTML>
<HEAD>
<TITLE>ES Queue Status Report</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>

<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
}
</style>
<script>
	$(document).ready(function(){$('#From_Date_Reg').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", 
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date_Reg').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", 
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#From_Date_Q').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", 
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date_Q').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", 
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	});
	var allWindows = new Array();
	var win; // new window object

	/*functions echeck,ValidateForm added by nilesh*/
	function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}
//---Added by Chetan
function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";

	sDate	= window.showModalDialog('/processmanager/reports/GMACReports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');




	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
}

function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	strResult=strdate+"/"+strMonth+"/"+stryear;
	return strResult;
}

function compToday(Date_To)
{
	var todaysDate = new Date(); 
	var dd = todaysDate.getDate() ;
	var mm = todaysDate.getMonth()+1 ;
	var yy = todaysDate.getFullYear() ;

	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));

	var Date_To_date=Number(Date_To.substring(0,Date_To.indexOf("/")));	

	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));

	if(Date_To_month=="JAN")
			Date_To_month="1";
		else if(Date_To_month=="FEB")
			Date_To_month="2";
		else if(Date_To_month=="MAR")
			Date_To_month="3";
		else if(Date_To_month=="APR")
			Date_To_month="4";
		else if(Date_To_month=="MAY")
			Date_To_month="5";
		else if(Date_To_month=="JUN")
			Date_To_month="6";
		else if(Date_To_month=="JUL")
			Date_To_month="7";
		else if(Date_To_month=="AUG")
			Date_To_month="8";
		else if(Date_To_month=="SEP")
			Date_To_month="9";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";

	if(Date_To_year>yy)
	{
		return false;
	}
	else if(Date_To_year<yy)
	{
		//if(Date_From_month>Date_To_month)
		//{
		//alert("To Date can not be less than From Date.");
		//return false;
		//}
		 if(mm==Date_To_month)
		{
			if(Date_To_date>dd)
			{
				return false;
			}
		}
	}
	else if(Date_To_year==yy)
	{
		if(mm<Date_To_month)
		{
		return false;
		}
		else if(mm==Date_To_month)
		{
			if(Date_To_date>dd)
			{
				return false;
			}
		}
	}
return true ;
}
function convertMonth(strMonth)
{
		if(strMonth=="JAN")
			strMonth="00";
		else if(strMonth=="FEB")
			strMonth="01";
		else if(strMonth=="MAR")
			strMonth="02";
		else if(strMonth=="APR")
			strMonth="03";
		else if(strMonth=="MAY")
			strMonth="04";
		else if(strMonth=="JUN")
			strMonth="05";
		else if(strMonth=="JUL")
			strMonth="06";
		else if(strMonth=="AUG")
			strMonth="07";
		else if(strMonth=="SEP")
			strMonth="08";
		else if(strMonth=="OCT")
			strMonth="09";
		else if(strMonth=="NOV")
			strMonth="10";
		else if(strMonth=="DEC")
			strMonth="11";
	   return strMonth;
}

function DateComparator(Date_To,Date_From)
{	
	if(!compToday(Date_From))
	{
		alert("From Date can not be Future Date.");
		return false ;
	}
	if(!compToday(Date_To))
	{
		alert("To Date can not be Future Date.");
		return false ;
	}
	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));	
	var Date_From_month=Date_From.substring(Date_From.indexOf("/")+1,Date_From.lastIndexOf("/"));

	/*converting ToDate month to number */
	if(Date_To_month=="JAN")
			Date_To_month="01";
		else if(Date_To_month=="FEB")
			Date_To_month="02";
		else if(Date_To_month=="MAR")
			Date_To_month="03";
		else if(Date_To_month=="APR")
			Date_To_month="04";
		else if(Date_To_month=="MAY")
			Date_To_month="05";
		else if(Date_To_month=="JUN")
			Date_To_month="06";
		else if(Date_To_month=="JUL")
			Date_To_month="07";
		else if(Date_To_month=="AUG")
			Date_To_month="08";
		else if(Date_To_month=="SEP")
			Date_To_month="09";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";


	/*converting FromDate month to number */
		if(Date_From_month=="JAN")
			Date_From_month="01";
		else if(Date_From_month=="FEB")
			Date_From_month="02";
		else if(Date_From_month=="MAR")
			Date_From_month="03";
		else if(Date_From_month=="APR")
			Date_From_month="04";
		else if(Date_From_month=="MAY")
			Date_From_month="05";
		else if(Date_From_month=="JUN")
			Date_From_month="06";
		else if(Date_From_month=="JUL")
			Date_From_month="07";
		else if(Date_From_month=="AUG")
			Date_From_month="08";
		else if(Date_From_month=="SEP")
			Date_From_month="09";
		else if(Date_From_month=="OCT")
			Date_From_month="10";
		else if(Date_From_month=="NOV")
			Date_From_month="11";
		else if(Date_From_month=="DEC")
			Date_From_month="12";
	
	var Date_To_date=Number(Date_To.substring(Date_To.indexOf("0"),Date_To.indexOf("/")));	
	var Date_From_date=Number(Date_From.substring(Date_From.indexOf("0"),Date_From.indexOf("/")));

		
	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));
	var Date_From_year=Number(Date_From.substring(Date_From.lastIndexOf("/")+1,Date_From.length));

		

	if(Date_To_year<Date_From_year)
	{
		alert("To Date cannot be less than From  Date.");
		return false;
	}


	else if(Date_To_year>Date_From_year)
	{
		
		//if(Date_From_month>Date_To_month)
		//{
		//alert("To Date can not be less than From Date.");
		//return false;
		//}
		 if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{
				
				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}


	else if(Date_To_year==Date_From_year)
	{
	
		if(Date_From_month>Date_To_month)
		{
		alert("To Date can not be less than From Date.");
		return false;
		}
		else if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{

				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}
return true;
}
	
function ValidateForm(emailID){
//	var emailID=document.frmSample.txtEmail
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }
 

	
function openreport()
{	

		var sQueue="";
		var bQueueSelected=false;
		var docselected=false;
		var UserEmailID=document.getElementById('EMail-ID').value;//added by nilesh
		var RegDateRangeFrom="";
		var RegDateRangeTo="";
		var QDateRangeFrom="";
		var QDateRangeTo="";
		var owner_id=document.getElementById('owner_id').value;
		var sDocCat="";
		//alert(document.forms["textForm"].Queue.length);
		
		for(var i=0;i<document.forms["textForm"].Queue.length;i++)
		{
			if(document.forms["textForm"].Queue[i].selected)
			{
				sQueue=sQueue+document.forms["textForm"].Queue[i].value+'~';
				bQueueSelected=true;
			}

		}
		
		if(!bQueueSelected)
		{
			alert("Please select Queue Name.");
			return false;
		}
	
			
		
		RegDateRangeFrom=document.forms["textForm"].From_Date_Reg.value;
		RegDateRangeTo=document.forms["textForm"].To_Date_Reg.value;	
		
		QDateRangeFrom=document.forms["textForm"].From_Date_Q.value;
		QDateRangeTo=document.forms["textForm"].To_Date_Q.value;	
		
		if ((RegDateRangeFrom=='' && RegDateRangeTo=='') && (QDateRangeFrom=='' && QDateRangeTo=='') )
		{
			alert("Please select Registration Date Range or Queue Entry Date Range.");
			return false ;
		}
	
		if ((RegDateRangeFrom=='' && RegDateRangeTo!='') || (RegDateRangeFrom!='' && RegDateRangeTo==''))
		{
			alert("Please select Registration Date Range.");
			return false;
		}
		
		if(RegDateRangeFrom!='' && RegDateRangeTo!='')
		{
			if(!DateComparator(RegDateRangeTo,RegDateRangeFrom))
			{
				return false;
			}
		}
		
		if ((QDateRangeFrom=='' && QDateRangeTo!='') || (QDateRangeFrom!='' && QDateRangeTo==''))
		{
			alert("Please select Queue Entry Date Range.");
			return false;
		}
		
		if(QDateRangeFrom!='' && QDateRangeTo!='')
		{
			if(!DateComparator(QDateRangeTo,QDateRangeFrom))
			{
				return false;
			}
		}
		
		var sTestQueue=sQueue.split('~');
			


		if(sQueue.indexOf("All")!=-1 && sTestQueue.length>2)
		{
			alert("No other Queue Name can be chosen after choosing All");
			return false;
			//sQueue='All~';

		}
		
		
		if(sQueue=='Introduction~Processing~Approval~Cancel~InProgress~')
		{
			sQueue='All~';
			
		}
		
		
		if(!DateComparator(RegDateRangeTo,RegDateRangeFrom))
		{
		return false;
		}
		else if(!DateComparator(QDateRangeTo,QDateRangeFrom))
		{
		return false;
		}
		
		if(UserEmailID=='')
		{
			alert("Kindly enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
				
			}
		}
	
	 if(UserEmailID!='')
			{	
				

//OpenRedict-Fix
    //window.top.APPROVALPROCESSQUEUESTATUS.location.href="ESQueueStatusGenerate.jsp?sQueue="+sQueue+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID+"&owner_id="+owner_id;
	var URI = "ESQueueStatusGenerate.jsp?sQueue="+sQueue+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID+"&owner_id="+owner_id;
	var StrOpenWin=strip_tags(URI,"");
	window.top.APPROVALPROCESSQUEUESTATUS.location.href=StrOpenWin;				
				
			}
	
		
		
  }

	
	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}

	//malkeet
	function chkradio(obj)
	{
		if(obj == 'r')
		{
			if(document.getElementById('Queue_Date').checked == true) 
			{
				document.getElementById('Queue_Date').checked = false;
			}
			document.getElementById('From_Date_Q').value='';
			document.getElementById('To_Date_Q').value='';
			document.getElementById('From_Date_Q').style.background='Gray';
			document.getElementById('To_Date_Q').style.background='Gray';
			document.getElementById('From_Date_IMG_Queue').disabled=true;
			document.getElementById('To_Date_IMG_Queue').disabled=true;
			document.getElementById('From_Date_IMG_Reg').disabled=false;
			document.getElementById('To_Date_IMG_Reg').disabled=false;
			document.getElementById('From_Date_Reg').style.background='White';
			document.getElementById('To_Date_Reg').style.background='White';
		}
		else if(obj == 'q')
		{
			if(document.getElementById('Registration').checked == true) 
			{
				document.getElementById('Registration').checked = false;
			}
			document.getElementById('From_Date_Q').style.background='White';
			document.getElementById('To_Date_Q').style.background='White';
			document.getElementById('From_Date_Reg').style.background='Gray';
			document.getElementById('To_Date_Reg').style.background='Gray';
			document.getElementById('From_Date_IMG_Reg').disabled=true;
			document.getElementById('To_Date_IMG_Reg').disabled=true;
			document.getElementById('From_Date_Reg').value='';
			document.getElementById('To_Date_Reg').value='';

			document.getElementById('From_Date_IMG_Queue').disabled=false;
			document.getElementById('To_Date_IMG_Queue').disabled=false;
		}

	}
	
	function disbFields()
 {
 	document.getElementById('From_Date_Q').value='';
	document.getElementById('To_Date_Q').value='';
	document.getElementById('From_Date_Reg').value='';
	document.getElementById('To_Date_Reg').value='';
	document.getElementById('From_Date_IMG_Queue').disabled=true;
	document.getElementById('To_Date_IMG_Queue').disabled=true;
	document.getElementById('From_Date_IMG_Reg').disabled=true;
	document.getElementById('To_Date_IMG_Reg').disabled=true;

 	document.getElementById('From_Date_Q').style.background='Gray';
	document.getElementById('To_Date_Q').style.background='Gray';
	document.getElementById('From_Date_Reg').style.background='Gray';
	document.getElementById('To_Date_Reg').style.background='Gray';

 }
</script>

<body topmargin="0" leftmargin="5" onunload="UnloadReportWindow(); "  >

			<form name='textForm' method=post>


			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">TA ES QUEUE STATUS REPORT</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td valign="center" width="100%" colspan=2 class="EWLabel1">This report will show the number of unprocessed work items in the selected queue along with other indexing details. The report will provide the current information only.</td></tr><tr><td></td></tr>
				<tr><td class="EWLabel1"><b>Queue Name is mandatory.</b>
				</td></tr>
				<td>
					<br/>
					<p style="color: red; font-size: 10pt">Note:  * fields are mandatory.</p>

				</td>
				
			</table>

		

			<table border="0" width="95%" cellspacing="1" align="center">
			
				<tr>
					<td class="EWLabel1" align="left" width='20%'><b>Queue<font color="RED">*</font></b></font></td>
					<td width='25%' colspan=3>
					<select style='width:45%' name="Queue" multiple>
							<option value="All">All</option>
							<option value="Introduction">Introduction</option>
							<option value="Processing">Processing</option>
							<option value="Approval">Approval</option>
							<option value="Cancel">Cancel</option>
							<option value="InProgress">InProgress</option>
							<option value="UPCSUpdate">UPCS Update</option>
							<option value="QC">QC</option>
							<option value="UPCSPaid">UPCS Paid</option>
							<option value="ApprovalException">Approval Exception</option>
							<option value="GEACInterface">GEAC Interface</option>
							<option value="PendingPayment">Pending Payment</option>
							<option value="UPCSQC">UPCS QC</option>
				
					</select>
					</td>
				</tr>
				
				
				
				
				 
                <!-- Added by Chetan for displaying Date range from and to field...-->
				<tr>
					<td>
					<p class="EWLabel122" ><input type = "hidden" name ="Registration" id ="Registration" value = "Registration" align='left' style="width: 10px" onClick="chkradio('r')">Registration Date Range<font color="RED">*</font></p></td>
					</tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date_Reg"  type="text" readonly id="From_Date_Reg" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date_Reg" readonly type="text"  id="To_Date_Reg" >
					
					</td>

				</tr>
				
				<tr>
					<td>
					<p class="EWLabel122" ><input type = "hidden" name ="Queue_Date" id ="Queue_Date" value = "Queue_Date"align='left' style="width: 10px" onClick="chkradio('q')">Queue Entry Date Range<font color="RED">*</font></p></td>
					</tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date_Q"  type="text" readonly id="From_Date_Q" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date_Q" readonly type="text"  id="To_Date_Q" >
					
					</td>

				</tr>
				<!-- --------------------------------------------------- -->
				<!--added by nilesh for displaying Emaild field -->
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Owner ID </b></td>
					<td >
					<input type='text' name='owner_id' style='width:145' id='owner_id'>
					</td>
				</tr>
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID<font color="RED">*</font></b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>
				
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>
	
			
			</form>
</body>
</Html>	 





 <%@ include file="customized.process" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>

 

 <%	
	String sCabname=null;
	String sSessionId = null;
	String sJtsIp = null;
	String sUserName=null;
	String sOutputXML=null;
	String sGroupName=request.getParameter("GroupName");
	int iJtsPort = 0;
	int iMainCode=0;
	String sResult="";
	boolean bError=false;
	String sStr_ServerType = null;
	try{
		
		
		sUserName=wfSession.getM_strUserName();
		sCabname=wfSession.getM_strCabName();
		sSessionId = wfSession.getM_strSessionID();
		sJtsIp =wfSession.getM_objCabinet().getM_strServerIP();
		iJtsPort =wfSession.getM_objCabinet().getM_iServerPort();
		sStr_ServerType = wfSession.getM_objCabinet().getM_strServerType();

		String Query = "" ;
		  WriteLog("Select_user"," Query::> sGroupName : "+sGroupName);
		if(sGroupName=="")
		{
			Query="select distinct b.username from pdbgroupmember a,pdbuser b where a.groupindex in(select groupindex from pdbgroup where a.userindex=b.userindex and a.userindex<>'1')";
		}
		else
		{
			Query="select distinct b.username from pdbgroupmember a,pdbuser b where a.groupindex in(select groupindex from pdbgroup where groupname in ("+sGroupName+")) and a.userindex=b.userindex and a.userindex<>'1'";
		}
		//String Query="select distinct b.username from pdbgroupmember a,pdbuser b where a.groupindex in(select groupindex from pdbgroup where groupname in ("+sGroupName+")) and a.userindex=b.userindex and a.userindex<>'1')";

       WriteLog("Select_user"," Query::> Query : "+Query);



		String sInputXML ="" ;
		//="<?xml version=\"1.0\"?><APSelect_Input><Option>APSelectWithColumnNames</Option><Query>" + Query + "</Query><EngineName>" + 				sCabname + "</EngineName><SessionId>"+sSessionId+"</SessionId></APSelect_Input>";
		
		sInputXML =  "<?xml version=\"1.0\"?>" +
					"<WMTestSelect_Input>" +
					"<Option>WFSelectTest_new</Option>" +
					"<sQry>"+Query+"</sQry>" +
					"<EngineName>"+sCabname+"</EngineName>"+
					"<NoOfCols>1</NoOfCols>" +
					"<SessionId>"+sSessionId+"</SessionId>" +
					"</WMTestSelect_Input>";

       WriteLog("Select_user"," sInputXML::> sInputXML : "+sInputXML);

		sOutputXML = WFCallBroker.execute(sStr_ServerType,"",sInputXML,sJtsIp,iJtsPort,1);

		WriteLog("Select_user"," sOutputXML::> sOutputXML : "+sOutputXML);

			 if(sOutputXML.equals("") || Integer.parseInt(sOutputXML.substring(sOutputXML.indexOf("<MainCode>")+10 , sOutputXML.indexOf("</MainCode>")))!=0)
			{
				iMainCode=15;
				sResult="Internal Server error.";
			}
			else
			{

				WFXmlResponse xmlResponse = new WFXmlResponse(sOutputXML);
				WFXmlList RecordList;
				for (RecordList =  xmlResponse.createList("Results", "Result");RecordList.hasMoreElements();RecordList.skip())
				{	
					//lstrRecordsXML = sOutputXML.substring(sOutputXML.indexOf("<Result>")+8 , sOutputXML.indexOf("</Result>"));
					sResult=sResult+RecordList.substring(RecordList.indexOf("<Result>")+8 , RecordList.indexOf("</Result>"))+"~";
				}
              WriteLog("Select_user"," sResult::> sResult : "+sResult);

			}
			

	}
	catch(Exception exp)
	{
		iMainCode=15;
		sResult=exp.toString();
		log("Productivity Report Group's User Data Fetch Exception : "+exp.toString());
	}
	out.clear();
	response.setHeader("Content-type","text/xml");
	out.println("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
	out.println("<root>");
	out.println("<MainCode>"+iMainCode+"</MainCode>");
	out.println("<ReturnValue>"+sResult+"</ReturnValue>");
	out.println("</root>"); 
%>

  
/*    
    
WNS_TAVS_USER_INFO_REPORT2 'yog1@qq.com','//10.33.192.139/XLS-File/Yogesh/UserInfReport2','APVS_UserInfoReport2','Introduction~Cancel~GEACInterface~PendingResolution~QC~VendorApproval~VendorSetup~ChangeQC~UpdateVendorChanges~','TA_APVS~',''        

WNS_TAVS_USER_INFO_REPORT2  'as@1234.com','//10.33.192.139/XLS-File/Yogesh/UserInfReport2','APVS_UserInfoReport2','Introduction~',''        
      
select * from QUEUEDEFTABLE      
      
select distinct b.username,b.PersonalName,b.FamilyName,c.groupname,e.queuename  
  from pdbgroupmember a,pdbuser b,pdbgroup c , QUEUEUSERTABLE d ,QUEUEDEFTABLE e      
  where  c.groupname='TA_APVS'       
and e.queuename in('TA_APVS_Introduction','TA_APVS_Cancel','TA_APVS_GEACInterface','TA_APVS_PendingResolution','TA_APVS_QC','TA_APVS_VendorApproval','TA_APVS_VendorSetup','TA_APVS_ChangeQC','TA_APVS_UpdateVendorChanges')       
 and a.userindex=b.userindex
 and a.userindex=d.userid
  and a.userindex<>1     
group by b.username,b.PersonalName,b.FamilyName,c.groupname,e.queuename 
order by b.username      
*/    
  
create PROCEDURE WNS_TA_APVS_USER_INFO_REPORT2 
(    
 @EmailID  nvarchar(200) ,
 @FilePath nvarchar(300),
 @fileName nvarchar(300),
 @QueueName nvarchar(300),
 @GroupName nvarchar(300),        
 @RowCount varchar(200) OUTPUT
)
AS
SET NOCOUNT ON  
BEGIN
DECLARE    
 @DataBaseName     nvarchar(255),  
 @sStatus nvarchar(20),    
 @suserName        nvarchar(100),
 @spersonalName    nvarchar(100),     
 @sfamilyName      nvarchar(100), 
 @sGroupName       nvarchar(100),    
 @sQueueName       nvarchar(100),  
 @sConcatQueueName nvarchar(500) ,  
 @Query  nvarchar(500) ,  
 @GroupNameReport  nvarchar(600),
 @QueueNameReport  nvarchar(600),
 @WhereQuery    varchar(2000), 
 @lastInd int  ,
 @Uquery nvarchar(550),    
 @QueueNameTemp nvarchar(600),    
 @GroupNameTemp nvarchar(600) 

 set @WhereQuery=' select distinct b.username,b.PersonalName,b.FamilyName,c.groupname,e.queuename into TAVS_TEMP_TABLE_USER_INFO2 from pdbgroupmember a,pdbuser b,pdbgroup c , QUEUEUSERTABLE d ,QUEUEDEFTABLE e  where '
 set @Uquery=''
 set @GroupNameReport = ''
 set @QueueNameReport = ''
 set @RowCount ='0'      
 set @QueueNameTemp = ''    
 set @GroupNameTemp =''    
 -- Temp Table for keeping all user with group and queue    
 /*if Object_ID ('TAVS_TEMP_TABLE_USER_INFO2') is not null  
 BEGIN  
  exec('drop table TAVS_TEMP_TABLE_USER_INFO2')  
  print 'drop'
 END  */

 if Object_ID ('TAVS_TEMP_TABLE_USER_INFO2') is not null  
 BEGIN  
  exec('drop table TAVS_TEMP_TABLE_USER_INFO2')     
 print 'drop'
 END  
        
 /*CREATE TABLE TAVS_TEMP_TABLE_USER_INFO2(  
   USERNAME VARCHAR(100),
   PersonalName varchar(500),
   FamilyName varchar(500),
   GROUPNAME VARCHAR(500), 
   QUEUENAME VARCHAR(500)
 )  */


 set @FileName=@FilePath+'/'+@EmailID+'_'+@fileName+'_'+convert(varchar,getdate(),104)+'.xls'    
 SET @DataBaseName = DB_name()    

      
 if(rtrim(ltrim(@GroupName))<>'All~') 
 BEGIN 
 --Added to Check for only 1 parameter 
  if(len(@GroupName)=charindex('~',@GroupName)) 
  BEGIN 
   print '11'    
   set @GroupNameTemp =ltrim(rtrim(substring(@GroupName,0,len(@GroupName))))
   set @GroupNameReport=ltrim(rtrim(substring(@GroupName,0,len(@GroupName)))) 
   set @WhereQuery=@WhereQuery+' c.groupname='''+@GroupNameReport+'''' 
  END 
  else 
  BEGIN 
   -----While loop ends 
   print '22'
   while (charindex('~',@GroupName)>1) 
   BEGIN 
    print '25'    
 set @GroupNameTemp=@GroupNameTemp+ltrim(rtrim(SUBSTRING(@GroupName,1,Charindex('~',@GroupName)-1)))+','
    set @GroupNameReport = @GroupNameReport + ''''+ltrim(rtrim(SUBSTRING(@GroupName,1,Charindex('~',@GroupName)-1)))+''''+',' 
    set @GroupName=ltrim(rtrim(Substring(@GroupName,Charindex('~',@GroupName)+len('~'),len(@GroupName)))) 
    print @GroupNameReport
   END 
   print '23'
       
   set @GroupNameReport=substring(@GroupNameReport,0,len(@GroupNameReport)) 
   set @WhereQuery= @WhereQuery + ' c.groupname in('+@GroupNameReport+') '
  END 
 END      
      
 print @Uquery
 if(rtrim(ltrim(@QueueName))<>'All~') 
 BEGIN 
  print '33'
  --Added to Check for only 1 parameter 
  if(len(@QueueName)=charindex('~',@QueueName)) 
  BEGIN 
   print '44'     
 set @QueueNameTemp=ltrim(rtrim(substring(@QueueName,0,len(@QueueName))))     
   set @QueueNameReport=ltrim(rtrim(substring(@QueueName,0,len(@QueueName)))) 
   set @WhereQuery=@WhereQuery+' and e.queuename like ''TA_APVS_'+@QueueNameReport+'''' 
  END 
  --Added to Check for only 1 parameter   
  else 
  BEGIN 
   print '55'
   -----While loop ends 
   while (charindex('~',@QueueName)>1) 
   BEGIN    
 set @QueueNameTemp = @QueueNameTemp+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+','     
    set @QueueNameReport = @QueueNameReport + '''TA_APVS_'+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+''''+',' 
    set @QueueName=ltrim(rtrim(Substring(@QueueName,Charindex('~',@QueueName)+len('~'),len(@QueueName)))) 
   END 
   set @QueueNameReport=substring(@QueueNameReport,0,len(@QueueNameReport)) 
   set @WhereQuery=@WhereQuery+' and e.queuename in('+@QueueNameReport+') '
  END      
 END      

 set @WhereQuery = @WhereQuery+' and a.userindex=b.userindex
 and a.userindex=d.userid
  and a.userindex<>1 and a.groupindex=c.groupindex    
group by b.username,b.PersonalName,b.FamilyName,c.groupname,e.queuename 
order by b.username'
 /*
 exec('select distinct b.username,b.PersonalName,b.FamilyName,c.groupname,e.queuename     
 into TAVS_TEMP_TABLE_USER_INFO2       
 from pdbgroupmember a,pdbuser b,pdbgroup c , QUEUEUSERTABLE d ,QUEUEDEFTABLE e      
 where     
 a.userindex=b.userindex
 and a.groupindex=c.groupindex
 and a.userindex=d.userid
 and d.queueid=e.queueid
 and e.queuename like ''TA_VS%'' 
 and a.userindex<>1     
 order by username,groupname,queuename') */
 
 print @WhereQuery
 exec(@WhereQuery)

--select count(*) from TAVS_TEMP_TABLE_USER_INFO2 with(nolock) 
 select @RowCount=count(*) from TAVS_TEMP_TABLE_USER_INFO2 with(nolock) 
 print @RowCount
 if(@RowCount=0)
 Begin
  print '1'
  drop table TAVS_TEMP_TABLE_USER_INFO2
 End

 else
 Begin
  if Object_ID ('TACM_USERINFO2_TEMP_AUTOMAIL') is not null       
  BEGIN
   exec('drop table TACM_USERINFO2_TEMP_AUTOMAIL')       
  END

  Exec('Create table TACM_USERINFO2_TEMP_AUTOMAIL (Header varchar(8000))') 
  print 'FileName='  + @FileName 
  Exec('Insert into TACM_USERINFO2_TEMP_AUTOMAIL 
  Select ''<html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style> 
  <table border=1>  
  <tr align="left"><td colspan=4 class=headerbold><center>Vendor Setup User Info 2 Report</center></td></tr>  
   <tr align="left"><td colspan=4 class=headerbold> Queue Name : '+@QueueNameTemp+'</td></tr>    
    <tr align="left"><td colspan=4 class=headerbold> Group Name : '+@GroupNameTemp+'</td></tr>    
  </table><br> 
  <table border=1><tr>''+      
  ''<td class=headerbold>First Name</td>''+       
  ''<td class=headerbold>Last Name</td>''+
  ''<td class=headerbold>Group Name</td>''+
  ''<td class=headerbold>Queue Name</td>'' 
  +''</tr></font>''  
  UNION ALL       
  Select distinct ''<tr><td align=left style=mso-number-format:\\@>''+ISNULL([PersonalName],'''')+''</td>''+ 
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([FamilyName],'''')+''</td>'' +        
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([groupname],'''')+''</td>'' +        
  ''<td align=left style=mso-number-format:\\@>''+ISNULL(queuename,'''')+''</td></tr>''
  from TAVS_TEMP_TABLE_USER_INFO2')
  
  update TACM_USERINFO2_TEMP_AUTOMAIL set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yy>&nbsp</td>')        
  --SET @Query = 'Master..xp_Cmdshell ''bcp "select Header FROM '+@DataBaseName+'..TACM_USERINFO2_TEMP_AUTOMAIL " queryout "'+@FileName+'" -c -T'' '        
 
  SET @Query='Master..xp_Cmdshell ''bcp "select * FROM '+@DataBaseName+'..TACM_USERINFO2_TEMP_AUTOMAIL" queryout "'+@FileName+'" -c -T'',No_output'     
  print @Query
  exec(@Query)    
  insert into NG_AutoMail_Status values('TA VS UserInfo 2 Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL) 

  declare @query1 nvarchar(1000)  
 -- set @query1 ='select distinct username,PersonalName,isNull(FamilyName,'' '') as lastname,groupname,queuename from TAVS_TEMP_TABLE_USER_INFO2 order by username'  

 -- exec(@query1)   

  drop table TAVS_TEMP_TABLE_USER_INFO2    
  --drop table TAVS_TEMP_TABLE_USER_INFO2    
  drop table TACM_USERINFO2_TEMP_AUTOMAIL
 END
 Select @RowCount
END 


 <%@ include file="customized.process" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>


<HTML>
<HEAD>
<TITLE>Vendor Setup User Info Report 2</TITLE>
</HEAD>

<link href="/webdesktop/CustomForms/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>

<script src="/webdesktop/CustomForms/reports/omniflow/scripts/Common.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>

 <%


	String sGroupname="";
	String sGroupname1="";


	String sTempGroupName="";
	String sStr_ServerType="";
	FileInputStream fis = null;

	try
	{
			String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAVSUserInfoReport2.ini";
			Properties ini = new Properties();
			fis = new FileInputStream(PathUtil.normalize(sRootPathini));
			ini.load(fis);
		
			sGroupname     =ini.getProperty("GROUPNAMES");
			sGroupname1 = sGroupname ;
			sTempGroupName ="'"+sGroupname.replaceAll(",","','")+"'";
			sGroupname     =sGroupname.replaceAll(",","~")+"~";

	}
	catch(Exception e)
	{
		out.println("Exception:" + e.toString());
	}
	finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
							out.println("Exception:" + e.toString());
						}
					}
				}


%>


<script>
	var FromDate = new Date();
	var type = '';
	var allWindows = new Array();
	var win; // new window object

	/*functions echeck,ValidateForm added by nilesh*/
	function echeck(str)
	{

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;
	}

function ValidateForm(emailID){
//	var emailID=document.frmSample.txtEmail
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }

function ChangeDateTag(obj)
{
	alert(obj);
	var InsertVal='';
	for(iterate=0;iterate<obj.length;iterate++)
	{
		if(obj.options[iterate].selected==true)
		{
			InsertVal=InsertVal+obj.options[iterate].value+'/';
		}
	}
	InsertVal=InsertVal.substring(0,InsertVal.length-1);
	var Table=document.getElementById('newgen');
	var lastRow = Table.rows.length;
	if (lastRow > 0) Table.deleteRow(lastRow - 1);
	while(InsertVal.indexOf('_')!=-1)
	{
		InsertVal=InsertVal.replace('_',' ');
	}
	var Row=Table.insertRow(0);
	var Cell=Row.insertCell();
	Cell.className="EWLabelBoldNew";
	Cell.innerHTML=InsertVal;
}

function DateComparator(Date_To,Date_From)
{

	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));	
	var Date_From_month=Date_From.substring(Date_From.indexOf("/")+1,Date_From.lastIndexOf("/"));

	/*converting ToDate month to number */
	if(Date_To_month=="JAN")
			Date_To_month="01";
		else if(Date_To_month=="FEB")
			Date_To_month="02";
		else if(Date_To_month=="MAR")
			Date_To_month="03";
		else if(Date_To_month=="APR")
			Date_To_month="04";
		else if(Date_To_month=="MAY")
			Date_To_month="05";
		else if(Date_To_month=="JUN")
			Date_To_month="06";
		else if(Date_To_month=="JUL")
			Date_To_month="07";
		else if(Date_To_month=="AUG")
			Date_To_month="08";
		else if(Date_To_month=="SEP")
			Date_To_month="09";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";


	/*converting FromDate month to number */
		if(Date_From_month=="JAN")
			Date_From_month="01";
		else if(Date_From_month=="FEB")
			Date_From_month="02";
		else if(Date_From_month=="MAR")
			Date_From_month="03";
		else if(Date_From_month=="APR")
			Date_From_month="04";
		else if(Date_From_month=="MAY")
			Date_From_month="05";
		else if(Date_From_month=="JUN")
			Date_From_month="06";
		else if(Date_From_month=="JUL")
			Date_From_month="07";
		else if(Date_From_month=="AUG")
			Date_From_month="08";
		else if(Date_From_month=="SEP")
			Date_From_month="09";
		else if(Date_From_month=="OCT")
			Date_From_month="10";
		else if(Date_From_month=="NOV")
			Date_From_month="11";
		else if(Date_From_month=="DEC")
			Date_From_month="12";
	
	var Date_To_date=Number(Date_To.substring(Date_To.indexOf("0"),Date_To.indexOf("/")));	
	var Date_From_date=Number(Date_From.substring(Date_From.indexOf("0"),Date_From.indexOf("/")));

		
	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));
	var Date_From_year=Number(Date_From.substring(Date_From.lastIndexOf("/")+1,Date_From.length));

		

	if(Date_To_year<Date_From_year)
	{
		alert("To Date cannot be less than From  Date.");
		return false;
	}

	else if(Date_To_year>Date_From_year)
	{

		if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{
				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}
	else if(Date_To_year==Date_From_year)
	{
		if(Date_From_month>Date_To_month)
		{
		alert("To Date can not be less than From Date.");
		return false;
		}
		else if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{
				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}

	var toDate = new Date(Date_To_month+"/"+Date_To_date+"/"+Date_To_year);
	var fromDate = new Date(Date_From_month+"/"+Date_From_date+"/"+Date_From_year);
	var oneDay=1000*60*60*24;

	var dateDiff=Math.ceil((toDate.getTime()-fromDate.getTime())/oneDay);
	if(dateDiff>90)
	{
		alert('Date Range can not be greater than 90 days.');
		return false;
	}
return true;
}



function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";
	sDate	= window.showModalDialog('/processmanager/reports/GMACReports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');
	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
	

}
function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	strResult=strdate+"/"+strMonth+"/"+stryear;
	return strResult;
}

	function openreport()
	{
		var QueueName="";
		var GroupName="";
		var GroupNameForm="";
		var GroupNameForm1="";
		var FinalGroupNames="";
		var UserEmailID="";

		UserEmailID=document.getElementById('EMail-ID').value;

		if(document.getElementById('Gname').checked == false && document.getElementById('Qname').checked == false)
		{
			alert("Please select an appropriate Queue/Group Name");
			return false;
		}

		if(document.getElementById('Gname').checked == true)
		{
			QueueName='Introduction~VendorSetup~PendingResolution~Cancel~QC~VendorApproval~UpdateVendorChanges~ChangeQC~GEACInterface~' ;

			for(var l=0;l<document.forms["textForm"].GroupI.length;l++)
			{
				if(document.forms["textForm"].GroupI[l].selected)
				{
					GroupNameForm=GroupNameForm+document.forms["textForm"].GroupI[l].value+'~';
				}
			}

			if(GroupNameForm == '')
			{
				alert("Please select Group Name.");
				return false;
			}
			if(GroupNameForm=="All~")
			{
				GroupNameForm='<%=sGroupname%>';
			}
			if(GroupNameForm=="~")
			{
				GroupNameForm='<%=sGroupname%>';
			}

			var sGroups=GroupNameForm.split('~');

			if(GroupNameForm.indexOf("All")!=-1 && sGroups.length>2)
			{
				alert("No other Group Name can be chosen after choosing All");
				return false;
			}  

			if(GroupNameForm=='<%=sGroupname%>')
			{
				GroupNameForm='<%=sGroupname%>';
			}

			if(GroupNameForm=='')
			{
				GroupNameForm=='<%=sGroupname%>'
			}
		}

		if(document.getElementById('Qname').checked == true)
		{
			GroupNameForm='<%=sGroupname%>';
			for(var i=0;i<document.forms["textForm"].Queue.length;i++)
			{
				if(document.forms["textForm"].Queue[i].selected)
				{
					QueueName=QueueName+document.forms["textForm"].Queue[i].value+'~';
				}
			}
			
			if(QueueName == '')
			{
				alert("Please select Queue Name.");
				return false;
			}

			var sTest=QueueName.split('~');
			if(QueueName.indexOf("All")!=-1 && sTest.length>2)
			{
				alert("No other Queue Name can be chosen after choosing All");
				return false;
			}  


			if(QueueName=='')
			{
				QueueName='Introduction~VendorSetup~PendingResolution~Cancel~QC~VendorApproval~UpdateVendorChanges~ChangeQC~GEACInterface~';
			}
			if(QueueName=='~')
			{
				QueueName='Introduction~VendorSetup~PendingResolution~Cancel~QC~VendorApproval~UpdateVendorChanges~ChangeQC~GEACInterface~';
			}
		}

		if(UserEmailID=='')
		{
			alert("Please enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
				return false ;
			}
		}


		if((UserEmailID!='')&&(QueueName!='' || GroupNameForm!=''))
		{
			//alert("VSUserInfo2Generate.jsp?&QueueName="+QueueName+"&ReportName=<%=request.getParameter("ReportName")%>&GroupName="+GroupNameForm+"&UserEmailID="+UserEmailID) ;
			
		//OpenRedict-Fix
    //window.top.USERINFO2.location.href="VSUserInfo2Generate.jsp?&QueueName="+QueueName+"&ReportName=<%=request.getParameter("ReportName")%>&GroupName="+GroupNameForm+"&UserEmailID="+UserEmailID;
	var URI ="VSUserInfo2Generate.jsp?&QueueName="+QueueName+"&ReportName=<%=request.getParameter("ReportName")%>&GroupName="+GroupNameForm+"&UserEmailID="+UserEmailID;
	var StrOpenWin=strip_tags(URI,"");
	window.top.USERINFO2.location.href=StrOpenWin;
		}
}

	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}
	

	function DisableOtherCombo(Mode)
	{	
		if(Mode=='Q')
		{
			if(document.textForm.GroupI.value=="")
			{
				
				document.textForm.Queue.disabled=false;
			}
			else
			{
				document.textForm.Queue.disabled=true;
			}
		}
		else
		{
			if(document.textForm.Queue.value=="")
			{
				
				document.textForm.GroupI.disabled=false;
			}
			else
			{
				document.textForm.GroupI.disabled=true;
			}
			
		}
		
	}
 function disbFields()
 {
 	document.getElementById('Queue').value='';
	document.getElementById('GroupI').value='';
	document.getElementById('Queue').disabled=true;
	document.getElementById('GroupI').disabled=true;


 }
function chkradio(obj)
{
	if(obj == 'g')
	{
		if(document.getElementById('Qname').checked == true) 
		{
			document.getElementById('Qname').checked = false;
		}
		for(var l=0;l<document.forms["textForm"].Queue.length;l++)
		{
			if(document.forms["textForm"].Queue[l].selected)
			{
				document.forms["textForm"].Queue[l].selected=false ;
			}
		}
		document.getElementById('GroupI').disabled=false;
		document.getElementById('Queue').disabled=true;

	}
	else if(obj == 'q')
	{
		if(document.getElementById('Gname').checked == true) 
		{
			document.getElementById('Gname').checked = false;
		}
		for(var l=0;l<document.forms["textForm"].GroupI.length;l++)
		{
			if(document.forms["textForm"].GroupI[l].selected)
			{
				document.forms["textForm"].GroupI[l].selected=false ;
			}
		}
		document.getElementById('GroupI').disabled=true;
		document.getElementById('Queue').disabled=false;

	}

}
function FillGroupCombo()
{
	var sGroupname='<%=sGroupname1%>';
	var GroupnameArray=sGroupname.split(',');
	//alert(sGroupname) ;
	for (var j=0;j<GroupnameArray.length-1;j++)
	{
		optn=document.createElement("option");
		req=document.getElementById("GroupI");
		optn.text=GroupnameArray[j];
		optn.value=GroupnameArray[j];
		req.options.add(optn);
	}
}
</script>

<body topmargin="0" leftmargin="5" onload="disbFields();FillGroupCombo();" onunload="UnloadReportWindow();">

			<form name='textForm' method=post>


			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader">Vendor Setup User Info Report 2</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This report gives the details of all users, group they belong to and queues they have access to.
</td></tr>
<tr><td class="EWLabel1">Select All Queues if report is to be generated for the details of all users, group they belong to and queues they have access to, else select the specific Queue, multiple selections are acceptable.
</td></tr><tr><td class="EWLabel1">Select a Group Name for generating report of users in that group.<br></td>
</tr><tr><td class="EWLabel1"><b> Either Queue Name or Group Name is Mandatory.</b></td>
				</tr>
			</table>
			<table border="0" width="95%" cellspacing="1" align="center">
<td colspan = 2 class="EWLabel1"><font color="RED">*</font> <b>Fields are Mandatory<b><BR></td>
				 <tr>
				 <td class="EWLabel1" align="left" width='20%'>
				 <input type = "radio" class="text" name ="Qname" id ="Qname" value = "Qname" class="EWLabel1" onClick="chkradio('q')">
				 <b>Queue Name <font color="RED">*</font>
					<td width='45%' COLSPAN=3>
					<!--td class="EWLabel1">
					<input type = "radio" class="text" name ="RadioG" id ="RadioQueue" value = "Queue" class="EWLabel1" onClick="chkradio('Queue')"> <font color='Blue'><b>&nbsp;&nbsp;&nbsp;Queue Name*</b></font></td>
					<td width='25%' COLSPAN=3-->
					<!--id given by megha-->
					<select style='width:65%' name="Queue" id="Queue" multiple>
					<option value="All">--All--</option>
					<option value="Introduction">Introduction</option>
					<option value="VendorSetup">VendorSetup</option>
					<option value="PendingResolution">PendingResolution</option>
					<option value="Cancel">Cancel</option>
					<option value="QC">QC</option>
					<option value="VendorApproval">VendorApproval</option>
					<option value="UpdateVendorChanges">UpdateVendorChanges</option>
					<option value="ChangeQC">ChangeQC</option>
					<option value="GEACInterface">GEACInterface</option>
					</select>
					</td>
				</tr>

				
				<tr>
					<td class="EWLabel1" align="left" width='20%'>
					<input type = "radio" class="text" name ="Gname" id ="Gname" value = "Gname" class="EWLabel1" onClick="chkradio('g')">
					<b>Group Name <font color="RED">*</font> 
					<td width='45%' COLSPAN=3>
					<!--td class="EWLabel1">
					<input type = "radio" class="text" name ="RadioG" id ="RadioGroup" value = "Group" class="EWLabel1" onClick="chkradio('Group')"> <font color='Blue'><b>&nbsp;&nbsp;&nbsp;Group Name*</b></font></td>
					<td width='30%' COLSPAN=3-->
					<!--id given by megha-->
						<select style='width:65%' class='TextFieldColor'  id="GroupI" name="GroupI" multiple >
						<option value="All">--All--</option>
						</select>
					</td>
				</tr>
					
					<tr>&nbsp;</tr>
					
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID <font color="RED">*</font></b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr></table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%"><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>

			</form>
</body>
</Html>	 




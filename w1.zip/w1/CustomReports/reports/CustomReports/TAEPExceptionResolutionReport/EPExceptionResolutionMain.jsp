

<HTML>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<HEAD>
<TITLE>TAEP Exception Resolution Report</TITLE>
</HEAD>

<FRAMESET ROWS="100%,0%" >
	<FRAME SRC="EPExceptionResolution.jsp" NAME="frmHeader" frameborder=no noresize scrolling=Yes>
	<FRAME SRC="" NAME="TAEPEXCEPTIONRESOLUTIONREPORT" frameborder=no scrolling=no>
	
</FRAMESET>
</html>


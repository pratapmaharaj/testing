/*      
WNS_TA_AP_AGING_REPORT 'All~','ALL~','01/JAN/2009','013/DEC/2013','UserName,a.WI_Name,activityname,Branch_Location,Vendor_Type,Priority,Company_Code,Vendor_ID,Document_Number,Document_Amount,Currency,Document_Date,Registration_Date,cast(Wi_ExitTime as v  
archar(30)) as Wi_ExitTime1,(datediff(mi,Registration_Date,Wi_ExitTime)) as Aging','mmm@mmm.com',''   
  
WNS_TA_AP_Aging_Report 'Introduction~Processing~Approval~ApprovalException~Cancel~CheckList~Coding~GEAC INTERFACE~JournalEntry~  
PendingResolution~PendingPayment~PolicyHolderPayment~QC','01/JAN/2009','13/DEC/2014','','','PO Invoices~  
Non PO Invoices~Policy Holder Payments~Escheatment~Credit Memo~Statement~','1ST KNOX NATL BANK','D10000339',  
'All~','b.username,a.WI_Name,  
Current_Work_Step,  
Document_Category,  
Priority,  
Pay_Entity,  
Vendor_Name,  
Vendor_Number,  
Invoice_Number,  
Total_Invoice_Amount,  
Invoice_Date,  
Additional_Comments,  
Approval_Decision,  
Approved_Invoice_Amount,  
Multi_Payment,  
b.Wi_EntryTime as QueueEntryDateTime,  
b.Wi_ExitTime as QueueExitDateTime,  
(datediff(dd,Registration_Date,b.Wi_ExitTime)) as Aging','mmm@mmm.com',''    
  
  
  
  
*/        
        
          
CREATE PROCEDURE [dbo].[WNS_TA_AP_AGING_REPORT]                     
(               
@QueueName  VARCHAR(300) ,                    
@RDateFrom  VARCHAR(255),                      
@RDateTo  VARCHAR(255),  
@QDateFrom  VARCHAR(255),                      
@QDateTo  VARCHAR(255),  
@DocCat VARCHAR(300),  
@Vname VARCHAR(100),  
@Vnumber VARCHAR(100),  
@ApprovalDecision varchar(100),                      
@Fields varchar(8000),                  
@EmailID varchar(200),  
@RowCount Varchar(100) OUT                       
)                      
AS          
declare                        
@WhereQuery varchar(2000),                    
@WhereQuery1 varchar(2000),                       
@Query varchar(5000),                    
@Query1 varchar(5000),                        
@QueryHistory varchar(5000),                        
@QueryFinal varchar(5000),                        
@Tables varchar(200),                    
@Tables1 varchar(200),                        
@QueueNameReport varchar(200),                        
@sQueueName varchar(200),      
@ProcessTypeReport varchar(200),                        
@OrderBy varchar(300),                        
@OrderByFinal varchar(300),                    
@Querytemp varchar(5000),  
@FileName varchar(255),                        
@sDocCat varchar(255),  
@sApprovalDecision varchar(255)                      
  --\\10.33.192.139\XLS-File                   
                        
                        
BEGIN                      
Set nocount on                        
set @FileName='//10.33.192.139/XLS-File/ProcessManager/reports/Gmac report/AP/'+@EmailID+'_NG_AP_Aging_Report_'+convert(varchar,getdate(),104)+'.xls'                                     
set @WhereQuery='WHERE '    
   
                  
set @WhereQuery1='WHERE '    
--SET @RowCount=''     
set @sQueueName=''  
set @sDocCat=''                    
set @QueueNameReport=''                         
set @ProcessTypeReport=''     
set @sApprovalDecision=''                     
set @OrderBy=' order by wi_name,WI_EXITTIME'                        
--set @OrderByFinal=' order by c.WI_RowCount,c.wi_name,c.queuename '                       
set @Tables='WNS_TA_AP_EXT_Table A with(nolock),WNS_TA_AP_EntryExitTable B with(nolock)'                    
set @Tables1='WNS_TA_AP_EntryExitTable'                      
set @WhereQuery=@WhereQuery+' a.wi_name=b.wi_name '                  
        
          
if Object_ID('#NG_AP_Aging_Report_Temp') is not null            
begin            
print 'Table dropped'            
 exec('drop table #NG_AP_Aging_Report_Temp')            
end              
          
Create Table #NG_AP_Aging_Report_Temp                          
(                          
 User_ID NVARCHAR(100),   
 WI_Name NVARCHAR(100),   
 Queue_Name NVARCHAR(100),   
 Document_category NVARCHAR(100),   
 Priority NVARCHAR(100),   
 Pay_entity NVARCHAR(100),   
 Vendor_Name NVARCHAR(100),   
 Vendor_ID NVARCHAR(100),   
 Invoice_Number NVARCHAR(100),   
 Invoice_Amount NVARCHAR(100),   
 Invoice_Date NVARCHAR(100),   
 Comments NVARCHAR(100),   
 Approval_Decision NVARCHAR(100),   
 Approved_Invoice_Amount NVARCHAR(100),   
 Multi_Payment NVARCHAR(100),   
 Queue_Entry_Date NVARCHAR(100),   
 Queue_Exit_Date NVARCHAR(100),   
 Aging NVARCHAR(100)      
)                              
  
if(rtrim(ltrim(@RDateFrom))<>'')                        
 SET @RDateFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,rtrim(ltrim(@RDateFrom)),121)))))                         
if(rtrim(ltrim(@RDateTo))<>'')                        
 SET @RDateTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,rtrim(ltrim(@RDateTo)),121)))))  
   
if(rtrim(ltrim(@QDateFrom))<>'')                        
 SET @QDateFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,rtrim(ltrim(@QDateFrom)),121)))))                         
if(rtrim(ltrim(@QDateTo))<>'')                        
 SET @QDateTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,rtrim(ltrim(@QDateTo)),121)))))          
--Added to Check for only 1 parameter                                  
if(rtrim(ltrim(@QueueName))<>'All~')                        
 BEGIN                        
   --Added to Check for only 1 parameter                        
   if(len(@QueueName)=charindex('~',@QueueName))                        
   BEGIN                        
    set @sQueueName=ltrim(rtrim(substring(@QueueName,0,len(@QueueName))))              
     set @WhereQuery=@WhereQuery+' and a.Current_Work_Step='+@sQueueName+''                                            
   END                                                                                  
         else                        
   BEGIN                                             
     while (charindex('~',@QueueName)>1)                        
    BEGIN  
       set @sQueueName = @sQueueName + ''''+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+''''+','                        
       set @QueueName=ltrim(rtrim(Substring(@QueueName,Charindex('~',@QueueName)+len('~'),len(@QueueName))))   
       END    
    set @sQueueName=substring(@sQueueName,0,len(@sQueueName))                        
    if(rtrim(ltrim(@RDateFrom))<>'' AND rtrim(ltrim(@RDateTo))<>'')                        
     set @WhereQuery=@WhereQuery+' and a.Current_Work_Step in('+@sQueueName+')'                                            
   END                       
   END                        
 END        
   
 if(rtrim(ltrim(@DocCat))<>'All~')                        
 BEGIN                        
   --Added to Check for only 1 parameter                        
   if(len(@DocCat)=charindex('~',@DocCat))                        
   BEGIN                        
    set @sDocCat=ltrim(rtrim(substring(@DocCat,0,len(@DocCat))))  
    set @WhereQuery=@WhereQuery+' AND a.Document_Category='+@sDocCat+''                                              
   END                                                                                  
         else                        
   BEGIN                                             
     while (charindex('~',@DocCat)>1)                        
    BEGIN  
       set @sDocCat = @sDocCat + ''''+ltrim(rtrim(SUBSTRING(@DocCat,1,Charindex('~',@DocCat)-1)))+''''+','                        
       set @DocCat=ltrim(rtrim(Substring(@DocCat,Charindex('~',@DocCat)+len('~'),len(@DocCat))))   
       END    
                      
     set @sDocCat=substring(@sDocCat,0,len(@sDocCat))                        
    set @WhereQuery=@WhereQuery+' AND a.Document_Category in('+@sDocCat+')'                        
   END                        
 END  
   
  if(rtrim(ltrim(@ApprovalDecision))<>'All~')                        
 BEGIN                        
   --Added to Check for only 1 parameter                        
   if(len(@ApprovalDecision)=charindex('~',@ApprovalDecision))                        
   BEGIN                        
    set @sDocCat=ltrim(rtrim(substring(@ApprovalDecision,0,len(@ApprovalDecision))))  
    set @WhereQuery=@WhereQuery+' AND a.Approval_Decision='+@sDocCat+')'                                              
   END                                                                                  
         else                        
   BEGIN                                             
     while (charindex('~',@ApprovalDecision)>1)                        
    BEGIN  
       set @sApprovalDecision = @sApprovalDecision + ''''+ltrim(rtrim(SUBSTRING(@ApprovalDecision,1,Charindex('~',@ApprovalDecision)-1)))+''''+','                        
       set @ApprovalDecision=ltrim(rtrim(Substring(@ApprovalDecision,Charindex('~',@ApprovalDecision)+len('~'),len(@ApprovalDecision))))   
       END    
                      
     set @sApprovalDecision=substring(@sApprovalDecision,0,len(@sApprovalDecision))                        
    set @WhereQuery=@WhereQuery+' AND a.Approval_Decision in('+@sApprovalDecision+')'                        
   END                        
 END        
   
 print 'Where Query--->'+@WhereQuery                                     
if(rtrim(ltrim(@RDateFrom))<>'' AND rtrim(ltrim(@RDateTo))<>'')                        
  BEGIN                                                 
 set @WhereQuery=@WhereQuery+' AND a.Registration_Date between '''+rtrim(ltrim(@RDateFrom))+''' AND '''+ rtrim(ltrim(@RDateTo))+''''                    
  END                    
if(rtrim(ltrim(@QDateFrom))<>'' AND rtrim(ltrim(@QDateTo))<>'')                        
 BEGIN                                                 
 set @WhereQuery=@WhereQuery+' AND Wi_EntryTime >='''+rtrim(ltrim(@QDateFrom))+''' AND wi_ExitTime <='''+ rtrim(ltrim(@QDateTo))+''''                    
 END                    
            
  print  @WhereQuery         
 if(rtrim(ltrim(@Vname))<>'')  
 begin  
 set @WhereQuery=@WhereQuery+' AND Vendor_Name='''+ rtrim(ltrim(@Vname))+''''     
 end    
  if(rtrim(ltrim(@Vnumber))<>'')  
 begin  
 set @WhereQuery=@WhereQuery+' AND Vendor_Number='''+ rtrim(ltrim(@Vnumber))+''''     
 end  
   
                        
SET @Query='SELECT '+@Fields+' FROM '  + @Tables + @WhereQuery                    
--SET @Query1='SELECT wi_name FROM '+@Tables1+' '+ @WhereQuery1                    
                        
print @Query                    
--print @Query1                        
                        
--set @QueryHistory=@Query1                        
/*                        
                    
if(rtrim(ltrim(@RDateFrom))<>'' AND rtrim(ltrim(@RDateTo))<>'')                           
BEGIN                    
set @QueryFinal=@Query+' and A.wi_name in('+@Query1+') and activityname not in (''Introduction'',''Exit'')'+@OrderBy                    
END                    
ELSE                    
set @QueryFinal=@Query+@OrderBy                    
--exec(@QueryFinal)                  
                  
--print @QueryFinal  
*/                    
Set @Querytemp='insert into #NG_AP_Aging_Report_Temp(User_ID,WI_Name,Queue_Name,Document_category,Priority,Pay_entity,Vendor_Name,Vendor_ID,Invoice_Number,Invoice_Amount,Invoice_Date,Comments,Approval_Decision,Approved_Invoice_Amount,Multi_Payment,Queue_E
ntry_Date,Queue_Exit_Date,Aging)'                            
SET @Querytemp=@Querytemp+@Query                  
exec (@Querytemp)                  
                  
                  
  --select * from #NG_AP_Aging_Report_Temp  
--print @Querytemp                  
  
select @RowCount=count(*) from #NG_AP_Aging_Report_Temp with(nolock)                      
if(@RowCount=0)                      
Begin                      
drop table #NG_AP_Aging_Report_Temp                      
End                   
                  
else                      
begin                          
                          
if Object_ID ('NG_TEMP_AUTOMAIL') is not null                             
          BEGIN                             
          exec('drop table NG_TEMP_AUTOMAIL')                             
          END                                        
Exec('Create table NG_TEMP_AUTOMAIL (Header varchar(8000),Row_Index int IDENTITY(1,1) PRIMARY KEY )')                             
Exec('Insert into NG_TEMP_AUTOMAIL                             
                          
Select ''<html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color:   
white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>                             
<table border=1><tr><td class=headerbold>UserID</td>''+                             
''<td class=headerbold>WI Name</td>''+                    
''<td class=headerbold>Queue Name</td>''+                            
''<td class=headerbold> Document category</td>''+                                                       
''<td class=headerbold>Priority</td>''+                          
''<td class=headerbold>Pay Entity</td>''+                          
''<td class=headerbold>Vendor Name</td>''+                          
''<td class=headerbold>Vendor ID</td>''+                          
''<td class=headerbold>Invoice Number</td>''+                          
''<td class=headerbold>Invoice Amount</td>''+                          
''<td class=headerbold>Invoice Date</td>''+        
''<td class=headerbold>Comments</td>''+       
''<td class=headerbold>Approval Decision</td>''+       
''<td class=headerbold> Approved Invoice Amount</td>''+       
''<td class=headerbold>Multi Payment</td>''+                           
''<td class=headerbold>Queue Entry Date</td>''+                          
''<td class=headerbold>Queue Exit Date</td>''+                          
''<td class=headerbold>Aging(Minutes)</td>''                          
+''</tr></font>''                             
                            
UNION ALL                 
Select ''<tr><td align=left style=mso-number-format:\\@>''+ISNULL([User_ID],'''')+''</td>''+                             
''<td align=left style=mso-number-format:\\@>''+ISNULL([WI_Name],'''')+''</td>''+                             
''<td align=left style=mso-number-format:\\@>''+ISNULL([Queue_Name],'''')+''</td>''+                             
''<td align=left style=mso-number-format:\\@>''+ISNULL([Document_category],'''')+''</td>''+                  
''<td align=left style=mso-number-format:\\@>''+ISNULL([Priority],'''')+''</td>'' +                                 
''<td align=left style=mso-number-format:\\@>''+ISNULL([Pay_entity],'''')+''</td>'' +                   
''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Name],'''')+''</td>'' +      
''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_ID],'''')+''</td>'' +                   
''<td align=left style=mso-number-format:\\@>''+ISNULL([Invoice_Number],'''')+''</td>'' +                   
''<td align=left style=mso-number-format:\\@>''+ISNULL([Invoice_Amount],'''')+''</td>'' +       
''<td align=left style=mso-number-format:\\@>''+ISNULL([Invoice_Date],'''')+''</td>'' +        
''<td align=left style=mso-number-format:\\@>''+ISNULL([Comments],'''')+''</td>'' +        
''<td align=left style=mso-number-format:\\@>''+ISNULL([Approval_Decision],'''')+''</td>'' +        
''<td align=left style=mso-number-format:\\@>''+ISNULL([Approved_Invoice_Amount],'''')+''</td>'' +        
''<td align=left style=mso-number-format:\\@>''+ISNULL([Multi_Payment],'''')+''</td>'' +           
''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Queue_Entry_Date],''''),120)+''</td>''+                    
''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Queue_Exit_Date],''''),120)+''</td>''+                
''<td align=left style=mso-number-format:\\@>''+ISNULL([Aging],'''')+''</td>''                  
from #NG_AP_Aging_Report_Temp')                             
                          
   
 --select * from NG_TEMP_AUTOMAIL  
update NG_TEMP_AUTOMAIL set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yy>&nbsp</td>')                              
SET @Query='Master..xp_Cmdshell ''bcp "select Header FROM GMAC..NG_TEMP_AUTOMAIL" queryout "'+@FileName+'" -c -T'',No_output'                           
                          
exec(@Query)                          
                          
insert into NG_AutoMail_Status values('AP Aging Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL)                          
                          
drop table #NG_AP_Aging_Report_Temp                          
drop table NG_TEMP_AUTOMAIL                          
                      
end                      
              
--select @RowCount                  
                          
--End      
      
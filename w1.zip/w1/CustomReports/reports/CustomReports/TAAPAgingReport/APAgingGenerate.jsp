<%@ include file="customized.process" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.sql.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="com.tcsta.util.PathUtil" %>

<HTML>
<HEAD>
<TITLE>AP Aging Report</TITLE>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="/../../../omniflow/scripts/wfgeneral.js">
</script>

<body >
<%!

 public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }
%>

<%
WriteLog("AP_Aging","sOutputXML ::> sOutputXML : IN APAgingGenerate") ;

	String sProcessDefId=null;
	String sProcedureName=null;
	String sColumnHeaders=null;
	String sReportName=null;
	String sFileName=null;
	String sNumberOfColumns=null;
	String sProcedureNameKey=null;
	String sColumnHeadersKey=null;
	String sFileNameKey=null;
	String sNumberOfColumnsKey=null;
	String sHeaderKey=null;
	String sHeaderPresentKey=null;
	String sDBMappedColsKey=null;
	String sHeaderValue=null;
	String sHeaderPresentValue=null;
	String sCabinetName=null;	
	String sDBMappedCols=null;
	String sFieldValuesKey=null;
	String sFieldValues=null;
	String sFieldValuesReport="";
	String sUserMailID=null;
	String sFilePath=null;
	String sFilePathKey=null;
	String UserNames = "" ;
	
	sReportName	=request.getParameter("ReportName");
	sUserMailID=request.getParameter("UserEmailID");
	sReportName	=sReportName.toUpperCase();
	
	WriteLog("AP_Aging","sReportName : "+sReportName) ;
	WriteLog("AP_Aging","sUserMailID : "+sUserMailID) ;

	sProcedureNameKey=sReportName +"_PROCEDURENAME" ;
	WriteLog("AP_Aging","sProcedureNameKey : "+sProcedureNameKey) ;
	
	sColumnHeadersKey=sReportName+"_COLUMNHEADERS";
	
	WriteLog("AP_Aging","sColumnHeadersKey : "+sColumnHeadersKey) ;
	sFileNameKey=sReportName+"_FILENAME";

	WriteLog("AP_Aging","sFileNameKey : "+sFileNameKey) ;

	sNumberOfColumnsKey=sReportName+"_NUMBEROFCOLUMNS";

	WriteLog("AP_Aging","sNumberOfColumnsKey : "+sNumberOfColumnsKey) ;

	sHeaderPresentKey=sReportName+"_HEADERPRESENT";

	WriteLog("AP_Aging","sHeaderPresentKey : "+sHeaderPresentKey) ;
	
	sHeaderKey=sReportName+"_HEADER";

	WriteLog("AP_Aging","sHeaderKey : "+sHeaderKey) ;
	
	sDBMappedColsKey=sReportName+"_DBMAPPEDCOLS";
	WriteLog("AP_Aging","sDBMappedColsKey : "+sDBMappedColsKey) ;
	sFieldValuesKey=sReportName+"_FIELDVALUES";

	WriteLog("AP_Aging","sFieldValuesKey : "+sFieldValuesKey) ;
	
	sFilePathKey=sReportName+"_PATH";
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAAPAgingReport.ini";
	//String sRootPathini=application.getRealPath("")+File.separator+"reports"+File.separator+"GMACReports"+File.separator+"ApprovalProcessAgingReport" + File.separator + "reports.ini";
	Properties ini = new Properties();
	//Unreleased dataresource release fix
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("AP_Aging","Unable to read AP_Aging.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("AP_Aging","Unable to close the AP_Aging.ini file");
						}
					}
				}
	
	

	WriteLog("AP_Aging","sOutputXML ::> sFilePathKey : "+sFilePathKey);

	String pathName = "" ;
	pathName = ini.getProperty(sReportName +"_FILEPATH");
	sProcessDefId=ini.getProperty("PROCESSDEFID");
	
	sCabinetName=ini.getProperty("CABINETNAME");
	sProcedureName=ini.getProperty(sProcedureNameKey);
	
	sColumnHeaders=ini.getProperty(sColumnHeadersKey);
	
	sFileName=ini.getProperty(sFileNameKey);
	
	sNumberOfColumns=ini.getProperty(sNumberOfColumnsKey);
	
	sHeaderPresentValue=ini.getProperty(sHeaderPresentKey);
	
	sDBMappedCols=ini.getProperty(sDBMappedColsKey);
	
	sFieldValues=ini.getProperty(sFieldValuesKey);
	
	sFilePath=ini.getProperty(sFilePathKey);

	if(sHeaderPresentValue.equals("YES")) 
	{
		sHeaderValue=ini.getProperty(sHeaderKey);
	}

	String sCabname=null;
	String sSessionId = null;
	String sJtsIp = null;
	String sUserName = null;
	String sReportProcedureName=null;
	String sReportTableName=null;
	String sOutputXML="";
	String sInputXML = "";
	String maincode = "";
	String Totalrec = "0";
	String url = "";
	String Status="";
	String sStr_ServerType="";
	String sInputXml="";
	double fPercentage=0;
	String sColumnNamesArr[]=split(sColumnHeaders,',');
	String sDBMappedColsArr[]=split(sDBMappedCols,',');
	String sFinalColumns[]=split(sColumnHeaders,',');
	
	for(int i=0;i<sColumnNamesArr.length;i++)
	{
		if(sColumnNamesArr[i].indexOf("~D")!=-1)
			sFinalColumns[i]=sColumnNamesArr[i].substring(0,sColumnNamesArr[i].length()-2);

	}

	String sFieldNamesDB[]=split(sFieldValues,'#');

	for(int i=0;i<sFieldNamesDB.length;i++)
	{
		sFieldValuesReport=sFieldValuesReport+sFieldNamesDB[i]+',';
	}
	sFieldValuesReport=sFieldValuesReport.substring(0,sFieldValuesReport.length()-1);
	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("AP_Aging","sRootPathDBini="+sRootPathDBini);
	
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("AP_Aging","Unable to readsRootPathDBini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("AP_Aging","Unable to close the sRootPathDBini file");
						}
					}
				}
	
	String driverName = null;

	String connectionUrl=ini.getProperty("CONNECTIONSTRING");
	driverName = ini.getProperty("DRIVERNAME");

	String RegDateRangeFrom=request.getParameter("RegDateRangeFrom");
	String RegDateRangeTo=request.getParameter("RegDateRangeTo");
	String QDateRangeFrom=request.getParameter("QDateRangeFrom");
	String QDateRangeTo=request.getParameter("QDateRangeTo");
	String QueueName=request.getParameter("QueueName");
	String VName=request.getParameter("VName");
	String VNumber=request.getParameter("VNumber");
	String DocCat=request.getParameter("DocCat");
	String Approval_decision=request.getParameter("Approval_decision");
	
	WriteLog("AP_Aging","APAgingGenerate.jsp?QueueName="+QueueName+"&RegDateRangeFrom="+RegDateRangeFrom+"&RegDateRangeTo="+RegDateRangeTo+"&QDateRangeFrom="+QDateRangeFrom+"&QDateRangeTo="+QDateRangeTo+"&DocCat="+DocCat+"&VName="+VName+"&VNumber="+VNumber+"&Approval_decision="+Approval_decision);
	String sRowXml="";
	WriteLog("AP_Aging",sFilePath);

	int iJtsPort = 0;
	boolean bError=false;
	//connectionUrl = connectionUrl+";"+"databaseName="+sCabinetName+";user="+dbuserName+";password="+dbpass;
	CallableStatement callableStatement = null;
	Connection conn=null;	
	String getDBUSERByUserIdSql = "{call "+sProcedureName+"(?,?,?,?,?,?,?,?,?,?,?,?,?)}";

	String output = "" ;
	WriteLog("AP_Aging",sProcedureName);
			
	try{
			Class.forName(driverName);
			conn = DriverManager.getConnection(connectionUrl);
			callableStatement = conn.prepareCall(getDBUSERByUserIdSql);
			callableStatement.setString(1, QueueName);
			callableStatement.setString(2, RegDateRangeFrom);
			callableStatement.setString(3, RegDateRangeTo);
			callableStatement.setString(4, QDateRangeFrom);
			callableStatement.setString(5, QDateRangeTo);
			callableStatement.setString(6, DocCat);
			callableStatement.setString(7, VName);
			callableStatement.setString(8, VNumber);
			callableStatement.setString(9, Approval_decision);
			callableStatement.setString(10, sFieldValuesReport);
			callableStatement.setString(11, sUserMailID);
			callableStatement.setString(12, sFilePath);
			callableStatement.registerOutParameter(13, java.sql.Types.VARCHAR);
			callableStatement.execute();

			output = callableStatement.getString(13);
			WriteLog("AP_Aging"," output "+output);
			
			
	}
	catch(SQLException ignore)
	{
		%>
									<script>alert("Some Error please check logs");</script>
									<%
		WriteLog("AP_Aging"," WFSession Data Fetch Exception:::::: "+ignore.toString());
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		bError= true;
		
	}
	finally {
 
	if (callableStatement != null) {
        try {
            callableStatement.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
}
	if(!bError)
	{

		WriteLog("AP_Aging"," output:::::: "+output);
		try
		{

			if(output.equals(""))
			{
				bError= true;
					%>
					<script>alert("Error in Executing Procedure:");</script>
					<%
				//maincode=sOutputXML.substring(sOutputXML.indexOf("<MainCode>")+10 , sOutputXML.indexOf("</MainCode>"));
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+output+"</b></font><center>");
				
				
			}
			else
			{
				
					try
							{
								 if(Integer.parseInt(output) == 0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
							log("AP_Aging "+ig.toString());
							%>
									<script>alert("Some Error please check logs");</script>
									<%
								out.println(ig.toString());
												
							}
			}
		}
		
		catch(Exception exp)
		{
			%>
									<script>alert("Some Error please check logs");</script>
									<%
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
			log("AP_Aging "+exp.toString());
		}
		
	}


%>
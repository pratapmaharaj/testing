USE [GMAC]
GO

/****** Object:  StoredProcedure [dbo].[APVS_MANUAL_INTRODUCTION_REPORT]    Script Date: 01/10/2014 11:41:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

  /*

GMAC_MANUAL_INTRODUCTION_REPORT
'NaoAP','All~','25/DEC/2011','28/FEB/2012','WI_Name,WIIntroducedBy,Intro_Date,Vendor_Type,Document_Category,Vendor_Name,Vendor_ID,Invoice_Number,Invoice_Date,Amount,Received_Date,Due_Date,Invoice_Description'


*/
ALTER PROCEDURE [dbo].[APVS_MANUAL_INTRODUCTION_REPORT]    
(    
@IntroductioType varchar(100),   
@VendorType  VARCHAR(100),    
@DateRangeFrom  VARCHAR(100),    
@DateRangeTo  VARCHAR(100),    
@Fields varchar(8000)    
)    
    
AS    
declare    
@WhereQuery varchar(2000),    
@Query varchar(5000),    
@Tables varchar(200),    
@VendorTypeReport varchar(200),    
@OrderBy varchar(300)    
  
    
BEGIN  
  
Set nocount on  
set @OrderBy=' order by WI_Name'  
set @WhereQuery=' where Introduction_Type is null  '  
  

set @Tables='dbo.WNS_TA_APVS_EXT_Table with(nolock)'    
  
  
if(rtrim(ltrim(@DateRangeFrom))<>'')    
 SET @DateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@DateRangeFrom,121)))))     
if(rtrim(ltrim(@DateRangeTo))<>'')    
 SET @DateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@DateRangeTo,121)))))   
  
  
if(rtrim(ltrim(@VendorType))<>'All~')    
BEGIN    
    
    
--Added to Check for only 1 parameter    
if(len(@VendorType)=charindex('~',@VendorType))    
BEGIN    
set @VendorTypeReport=ltrim(rtrim(substring(@VendorType,0,len(@VendorType))))    
    
set @WhereQuery=@WhereQuery+' AND Vendor_Type='''+@VendorTypeReport+''''    
END    
    
--Added to Check for only 1 parameter    
    
else    
    
BEGIN    
    
-----While loop ends    
while (charindex('~',@VendorType)>1)    
BEGIN    
set @VendorTypeReport = @VendorTypeReport + ''''+ltrim(rtrim(SUBSTRING(@VendorType,1,Charindex('~',@VendorType)-1)))+''''+','    
  set @VendorType=ltrim(rtrim(Substring(@VendorType,Charindex('~',@VendorType)+len('~'),len(@VendorType))))    
    
    
END    
    
-----While loop ends     
    
    
set @VendorTypeReport=substring(@VendorTypeReport,0,len(@VendorTypeReport))    
    
    
set @WhereQuery=@WhereQuery+' AND Vendor_Type in('+@VendorTypeReport+')'    
    
END    
    
END  


if(rtrim(ltrim(@IntroductioType))<>'All~')    
BEGIN    
    
    
--Added to Check for only 1 parameter    
if(len(@IntroductioType)=charindex('~',@IntroductioType))    
BEGIN    
set @VendorTypeReport=ltrim(rtrim(substring(@IntroductioType,0,len(@IntroductioType))))    
    
set @WhereQuery=@WhereQuery+' AND Introduction_Type='''+@VendorTypeReport+''''    
END    
    
--Added to Check for only 1 parameter    
    
else    
    
BEGIN    
    
-----While loop ends    
while (charindex('~',@IntroductioType)>1)    
BEGIN    
set @VendorTypeReport = @VendorTypeReport + ''''+ltrim(rtrim(SUBSTRING(@IntroductioType,1,Charindex('~',@IntroductioType)-1)))+''''+','    
  set @IntroductioType=ltrim(rtrim(Substring(@IntroductioType,Charindex('~',@IntroductioType)+len('~'),len(@IntroductioType))))    
    
    
END    
    
-----While loop ends     
    
    
set @VendorTypeReport=substring(@VendorTypeReport,0,len(@VendorTypeReport))    
    
    
set @WhereQuery=@WhereQuery+' AND Introduction_Type in('+@VendorTypeReport+')'    
    
END    
    
END  
 
  
if(rtrim(ltrim(@DateRangeFrom))<>'' AND rtrim(ltrim(@DateRangeTo))<>'')    
BEGIN    
 set @WhereQuery=@WhereQuery+' AND Registration_Date between '''+rtrim(ltrim(@DateRangeFrom))+''' AND '''+ rtrim(ltrim(@DateRangeTo))+''''    
    
END     
  
 SET @Query='SELECT '+@Fields+' from '+ @Tables + @WhereQuery + @OrderBy   
print @Query  
exec(@Query)  
    
    
    
End    

  
GO



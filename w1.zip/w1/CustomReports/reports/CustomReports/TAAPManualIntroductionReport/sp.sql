          
  /*          
          
VS_MANUAL_INTRODUCTION_REPORT 'All~','All~','03/JAN/2014','14/JAN/2014','Wi_Name,WIIntroducedBy,Registration_Date,Vendor_Request_Type,Vendor_type,Priority,Vendor_Name,Vendor_Number,Payment_Terms,Vendor_Status,Address_Line_1,Address_Line_2,City_Address_Lin
  
e_3,State_Code,Postal_code,Additional_Comments,Optional_Address_1,Optional_Address_2,Vendor_Email_ID,Combined_Single_Payment,Tax_ID_Number,SSN_Number,V_1099_Code,V_1099_Payee_Name, ACH, Bank_Account_Payment_Code,Code,Account_Number,Exception_Type,W9_Indic
  
ator','aa@bb.com','//10.33.192.139/XLS-File/ProcessManager/reports/Gmac report/VS/','Manual_Introduction_Report'          
          
          
*/          
CREATE PROCEDURE [dbo].[VS_MANUAL_INTRODUCTION_REPORT]              
(              
@VendorRequestType varchar(100),             
@VendorType  VARCHAR(100),              
@DateRangeFrom  VARCHAR(100),              
@DateRangeTo  VARCHAR(100),              
@Fields varchar(8000),      
@EmailID varchar (100) ,      
@FilePath  varchar(200),      
@FileName  varchar(200)          
)              
              
AS              
declare              
@WhereQuery varchar(2000),              
@Query varchar(5000),              
@Tables varchar(200),              
@VendorTypeReport varchar(200),      
@VendorRequestTypeReport varchar(200),             
@OrderBy varchar(300)              
            
              
BEGIN            
            
Set nocount on        
set @FileName=@FilePath+'/'+@EmailID+'_'+@FileName+'_'+convert(varchar,getdate(),104)+'.xls'            
set @OrderBy=' order by WI_Name'            
set @WhereQuery=' where Introduction_Type=''Manual''  '            
            
          
set @Tables='dbo.WNS_TA_APVS_EXT_Table with(nolock)'              
            
            
if(rtrim(ltrim(@DateRangeFrom))<>'')              
 SET @DateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@DateRangeFrom,121)))))               
if(rtrim(ltrim(@DateRangeTo))<>'')              
 SET @DateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@DateRangeTo,121)))))             
      
    
if(rtrim(ltrim(@VendorRequestType))<>'All~')              
BEGIN              
              
              
--Added to Check for only 1 parameter              
if(len(@VendorRequestType)=charindex('~',@VendorRequestType))              
BEGIN              
set @VendorRequestTypeReport=ltrim(rtrim(substring(@VendorRequestType,0,len(@VendorRequestType))))              
              
set @WhereQuery=@WhereQuery+' AND Vendor_Request_Type='''+@VendorRequestTypeReport+''''              
END              
              
--Added to Check for only 1 parameter              
              
else              
              
BEGIN              
              
-----While loop ends              
while (charindex('~',@VendorRequestType)>1)              
BEGIN              
set @VendorRequestTypeReport = @VendorRequestTypeReport + ''''+ltrim(rtrim(SUBSTRING(@VendorRequestType,1,Charindex('~',@VendorRequestType)-1)))+''''+','              
  set @VendorRequestType=ltrim(rtrim(Substring(@VendorRequestType,Charindex('~',@VendorRequestType)+len('~'),len(@VendorRequestType))))              
              
              
END              
              
-----While loop ends               
              
              
set @VendorRequestTypeReport=substring(@VendorRequestTypeReport,0,len(@VendorRequestTypeReport))              
              
              
set @WhereQuery=@WhereQuery+' AND Vendor_Request_Type in('+@VendorRequestTypeReport+')'              
              
END              
              
END                   
         
     
    
          
            
if(rtrim(ltrim(@VendorType))<>'All~')              
BEGIN              
              
              
--Added to Check for only 1 parameter              
if(len(@VendorType)=charindex('~',@VendorType))              
BEGIN              
set @VendorTypeReport=ltrim(rtrim(substring(@VendorType,0,len(@VendorType))))              
              
set @WhereQuery=@WhereQuery+' AND Vendor_Type='''+@VendorTypeReport+''''              
END              
              
--Added to Check for only 1 parameter              
              
else                          
BEGIN              
              
-----While loop ends              
while (charindex('~',@VendorType)>1)              
BEGIN              
set @VendorTypeReport = @VendorTypeReport + ''''+ltrim(rtrim(SUBSTRING(@VendorType,1,Charindex('~',@VendorType)-1)))+''''+','              
  set @VendorType=ltrim(rtrim(Substring(@VendorType,Charindex('~',@VendorType)+len('~'),len(@VendorType))))              
              
              
END              
              
-----While loop ends               
              
              
set @VendorTypeReport=substring(@VendorTypeReport,0,len(@VendorTypeReport))              
              
              
set @WhereQuery=@WhereQuery+' AND Vendor_Type in('+@VendorTypeReport+')'              
              
END              
              
END                   
            
if(rtrim(ltrim(@DateRangeFrom))<>'' AND rtrim(ltrim(@DateRangeTo))<>'')              
BEGIN              
 set @WhereQuery=@WhereQuery+' AND Registration_Date between '''+rtrim(ltrim(@DateRangeFrom))+''' AND '''+ rtrim(ltrim(@DateRangeTo))+''''              
              
END               
     
 SET @Query='SELECT '+@Fields+' from '+ @Tables + @WhereQuery + @OrderBy             
print @Query            
exec(@Query)            
              
  insert into NG_AutoMail_Status values('VS Manual Introduction Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL)             
              
End 
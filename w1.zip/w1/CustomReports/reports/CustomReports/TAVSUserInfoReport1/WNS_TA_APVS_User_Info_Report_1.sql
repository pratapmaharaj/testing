/*select * from TAVS_TEMP_TABLE_USER_INFO1    
select * from WNS_TA_USER_LOGIN_LOGOUT_INFO

WNS_TA_APVS_User_Info_Report_1 '01/MAR/2014','00:0','03/APR/2014','00:0','kuldeep~','convert(varchar(20),a.LogDate,103) as Logdate,b.UserName,LoginTime,LogoutTime,cast(a.totalloggedintime as varchar(30)) as TotalLoggedInTime','User1111@123.com','//10.33.200.82/crebsfs/CR_EBS_APPS_MODEL/Omniflow/Reports/VS/TAVSUserInfoReport1',''
  
*/ 
    
alter  PROCEDURE WNS_TA_APVS_User_Info_Report_1 
(  
@DateRangeFrom  VARCHAR(50), 
@FTime VARCHAR(50), 
@DateRangeTo  VARCHAR(50),
@TTime VARCHAR(50),
@username VARCHAR(50),  
@Fields varchar(8000),
@EmailID varchar(100),
@FilePath varchar(200),  
@result varchar(200) OUTPUT  

)  
AS  
declare  
@WhereQuery varchar(2000),  
@Query varchar(5000),  
@Tables varchar(200),  
@OrderBy varchar(300),
@FileName varchar(300),
@DataBaseName varchar(200),
@RowCount nvarchar(50),
@usernameReport varchar(200)
BEGIN   
	Set nocount on  
	set @WhereQuery=''  
	set @OrderBy=' order by a.logindate'
	set @usernameReport = ''  
	print @FTime
	print @TTime
 
	set @Tables='WNS_TA_USER_LOGIN_LOGOUT_INFO a,pdbuser b '  
	if(rtrim(ltrim(@DateRangeFrom))<>'')  
		SET @DateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@DateRangeFrom,121)))))   
	if(rtrim(ltrim(@DateRangeTo))<>'')  
		SET @DateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@DateRangeTo,121)))))   

	print @DateRangeFrom  

	if Object_ID ('TAVS_TEMP_TABLE_USER_INFO1') is not null  
	BEGIN  
		exec('drop table TAVS_TEMP_TABLE_USER_INFO1')     
	END 
	CREATE TABLE [dbo].[TAVS_TEMP_TABLE_USER_INFO1](  
	 [Logdate] [varchar](20) NULL,  
	 [userid] [nvarchar](512) NULL,  
	 [logintime] [datetime] NULL,  
	 [logouttime] [datetime] NULL,  
	 [TotalLoggedInTime] [varchar](10) NOT NULL,  
	 [LogId] [int] NOT NULL  
	)

  if(rtrim(ltrim(@username))<>'All~')       
 BEGIN       
  --Added to Check for only 1 parameter       
  if(len(@username)=charindex('~',@username))       
  BEGIN       
   set @usernameReport=ltrim(rtrim(substring(@username,0,len(@username))))       
   set @WhereQuery=@WhereQuery+' AND userid='''+@usernameReport+''''       
  END       
      
  --Added to Check for only 1 parameter         
  else       
  BEGIN       
   -----While loop ends       
   while (charindex('~',@username)>1)       
   BEGIN       
    set @usernameReport = @usernameReport + ''''+ltrim(rtrim(SUBSTRING(@username,1,Charindex('~',@username)-1)))+''''+','       
    set @username=ltrim(rtrim(Substring(@username,Charindex('~',@username)+len('~'),len(@username))))       
   END       
      
   set @usernameReport=substring(@usernameReport,0,len(@usernameReport))       
   set @WhereQuery=@WhereQuery+' AND userid in('+@usernameReport+')'       
  END       
 END 
 
	print @WhereQuery  

	SET @Query='insert into  TAVS_TEMP_TABLE_USER_INFO1 select * from '+ @Tables + @WhereQuery + @OrderBy  
	print @Query 
   
	set @Query ='insert into TAVS_TEMP_TABLE_USER_INFO1 select ISNULL((convert(varchar(20),a.logintime,121)),(convert(varchar(20),a.logouttime,121))) as Logdate,  
	a.userid,a.logintime,a.logouttime,'''' as TotalLoggedInTime ,LogId   
	   from WNS_TA_USER_LOGIN_LOGOUT_INFO a,pdbuser b,pdbgroup c, pdbgroupmember d   
	  where   
	  a.userid = b.UserName  
	  and c.GroupIndex=d.GroupIndex   
	  and b.UserIndex=d.UserIndex   
	  and GroupName like ''%vs%''   
	  and ( a.logintime between (dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,'''+@DateRangeFrom+''',121))))) )   
		and (dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,'''+@DateRangeTo+''',121))))) )   
		OR   
		a.logouttime between (dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,'''+@DateRangeFrom+''',121))))) )   
		and (dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,'''+@DateRangeTo+''',121))))) )   
		)  '+@WhereQuery+'
	  order by a.userid,a.logid,a.logintime'   
  
	print @Query  
	exec(@Query) 

	SET @FileName=@FilePath+'/'+@EmailID+'_TAEP_UserInfo1_Report_'+convert(varchar,getdate(),104)+'.xls'
	SET @DataBaseName = DB_name()
   
	update a set a.logouttime=b.logouttime from TAVS_TEMP_TABLE_USER_INFO1 a,TAVS_TEMP_TABLE_USER_INFO1 b  
	where a.userid=b.userid and (a.logid+1)=b.logid  
   
  -- select * from TAVS_TEMP_TABLE_USER_INFO1 
	delete from TAVS_TEMP_TABLE_USER_INFO1 where logintime is null or logouttime is null  
	/*  
  exec('update TAVS_TEMP_TABLE_USER_INFO1 set  
 totalloggedintime = isnull(datediff(mm,logintime,logouttime),''0'')')  */  
 
	update TAVS_TEMP_TABLE_USER_INFO1 set  
	totalloggedintime = isnull(cast(datediff(HOUR,logintime,logouttime) as float),'0')  
 --select * from TAVS_TEMP_TABLE_USER_INFO1
 
 --select * from TAVS_TEMP_TABLE_USER_INFO1   
 select @RowCount=count(*) from TAVS_TEMP_TABLE_USER_INFO1 with(nolock)     
  if(@RowCount=0)  
   Begin
   --print '1'
   drop table TAVS_TEMP_TABLE_USER_INFO1  
   End     
    
  else 
   Begin   
    if Object_ID ('TAVS_USERINFO1_TEMP_AUTOMAIL') is not null 
    BEGIN  
    exec('drop table TAVS_USERINFO1_TEMP_AUTOMAIL') 
    END

  Exec('Create table TAVS_USERINFO1_TEMP_AUTOMAIL (Header varchar(8000))') 
  print 'FileName='  + @FileName   
  Exec('Insert into TAVS_USERINFO1_TEMP_AUTOMAIL  

    Select ''<html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>   

    <table border=1>  
    <tr align="left"><td colspan=16 class=headerbold>Vendor Setup User Info 1 Report</td></tr>  
    </table><br>   
 <table border=1><tr>''+
 ''<td class=headerbold>Date</td>''+  
 ''<td class=headerbold>User Name</td>''+ 
 ''<td class=headerbold>Login Time</td>''+
 ''<td class=headerbold>Logout Time</td>''+
 ''<td class=headerbold>Total Logged in Time (hrs)</td>''     
 +''</tr></font>''  

 UNION ALL 
 
 Select ''<tr><td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+ISNULL([Logdate],'''')+''</td>''+
 ''<td align=left style=mso-number-format:\@>''+ISNULL([Userid],'''')+''</td>''+   
   
 ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([logintime],''''),120)+''</td>'' +    
 ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([logouttime],''''),120)+''</td>'' +    
 ''<td align=left style=mso-number-format:\@>''+ISNULL(TotalLoggedInTime,'''')+''</td></tr>''
   
 from TAVS_TEMP_TABLE_USER_INFO1  ') 

     print 'before update'    
    update TAVS_USERINFO1_TEMP_AUTOMAIL set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yy>&nbsp</td>')  
    SET @Query = 'Master..xp_Cmdshell ''bcp "select Header FROM '+@DataBaseName+'..TAEP_USERINFO1_TEMP_AUTOMAIL " queryout "'+@FileName+'" -c -T'' '  

 SET @Query='Master..xp_Cmdshell ''bcp "select * FROM '+@DataBaseName+'..TAVS_USERINFO1_TEMP_AUTOMAIL" queryout "'+@FileName+'" -c -T'',No_output' 
 print @Query
 exec(@Query)
 
 insert into NG_AutoMail_Status values('TA VS UserInfo 1 Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL)   

 drop table TAVS_TEMP_TABLE_USER_INFO1  
  
 drop table TAVS_USERINFO1_TEMP_AUTOMAIL

 End     
 --select @RowCount
 If(@RowCount > 0)
 Begin
  Set @result=@RowCount
 End
 Else
 Begin
  Set @result=@RowCount
 End

    Select @result
 
End  

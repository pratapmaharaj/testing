<%@ include file="customized.process" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="java.sql.*"%>

<HTML>
<HEAD>
<TITLE>TACM User Info Report1 Report</TITLE>
</HEAD>

<link href="/webdesktop/CustomForms/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>


<body >
<%!

 public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }
%>

<%
WriteLog("1_VSUSERINFO","sOutputXML ::> sOutputXML : here") ;
	
	Connection conn = null;
	Statement st;
	String connectionUrl =""; 
	boolean empty=true;
	String sProcessDefId=null;
	String sProcedureName=null;
	String sColumnHeaders=null;
	String sReportName=null;
	String sFileName=null;
	String sNumberOfColumns=null;
	String sProcedureNameKey=null;
	String sColumnHeadersKey=null;
	String sFileNameKey=null;
	String sNumberOfColumnsKey=null;
	String sHeaderKey=null;
	String sHeaderPresentKey=null;
	String sDBMappedColsKey=null;
	String sHeaderValue=null;
	String sHeaderPresentValue=null;
	String sCabinetName=null;	
	String sDBMappedCols=null;
	String sFieldValuesKey=null;
	String sFieldValues=null;
	String sFieldValuesReport="";
	String sUserMailID=null;
	String sFilePath=null;
	String sFilePathKey=null;
	String UserNames = "" ;
	sReportName	=request.getParameter("ReportName");
	UserNames = request.getParameter("UserNames");

	sUserMailID=request.getParameter("UserEmailID");
	sReportName	=sReportName.toUpperCase();
	WriteLog("1_VSUSERINFO","sOutputXML ::> sReportName : "+sReportName) ;
	WriteLog("1_VSUSERINFO","sOutputXML ::> sUserMailID : "+sUserMailID) ;

	sProcedureNameKey=sReportName +"_PROCEDURENAME" ;
	WriteLog("1_VSUSERINFO","sOutputXML ::> sProcedureNameKey : "+sProcedureNameKey) ;
	sColumnHeadersKey=sReportName+"_COLUMNHEADERS";
	WriteLog("1_VSUSERINFO","sOutputXML ::> sColumnHeadersKey : "+sColumnHeadersKey) ;
	sFileNameKey=sReportName+"_FILENAME";

	WriteLog("1_VSUSERINFO","sOutputXML ::> sFileNameKey : "+sFileNameKey) ;

	sNumberOfColumnsKey=sReportName+"_NUMBEROFCOLUMNS";

	WriteLog("1_VSUSERINFO","sOutputXML ::> sNumberOfColumnsKey : "+sNumberOfColumnsKey) ;

	sHeaderPresentKey=sReportName+"_HEADERPRESENT";

	WriteLog("1_VSUSERINFO","sOutputXML ::> sHeaderPresentKey : "+sHeaderPresentKey) ;
	
	sHeaderKey=sReportName+"_HEADER";

	WriteLog("1_VSUSERINFO","sOutputXML ::> sHeaderKey : "+sHeaderKey) ;
	sDBMappedColsKey=sReportName+"_DBMAPPEDCOLS";
	WriteLog("1_VSUSERINFO","sOutputXML ::> sDBMappedColsKey : "+sDBMappedColsKey) ;
	sFieldValuesKey=sReportName+"_FIELDVALUES";

	WriteLog("1_VSUSERINFO","sOutputXML ::> sFieldValuesKey : "+sFieldValuesKey) ;
	
	sFilePathKey=sReportName+"_FILEPATH";
	

	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAVSUserInfoReport1.ini";

	Properties ini = new Properties();
	
		FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("1_VSUSERINFO","Unable to read 1_VSUSERINFO.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("1_VSUSERINFO","Unable to close the 1_VSUSERINFO.ini file");
						}
					}
				}
				
	//WriteLog("1_VSUSERINFO","sOutputXML ::> sFieldValuesKey : "+sFieldValuesKey) ;

	String pathName = "" ;
	pathName = ini.getProperty(sReportName +"_FILEPATH");

	sProcedureName=ini.getProperty(sProcedureNameKey);
	
	sColumnHeaders=ini.getProperty(sColumnHeadersKey);
	
	sFileName=ini.getProperty(sFileNameKey);
	
	sNumberOfColumns=ini.getProperty(sNumberOfColumnsKey);
	
	sHeaderPresentValue=ini.getProperty(sHeaderPresentKey);
	
	sDBMappedCols=ini.getProperty(sDBMappedColsKey);
	
	sFieldValues=ini.getProperty(sFieldValuesKey);
	
	sFilePath=ini.getProperty(sFilePathKey);

	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("1_VSUSERINFO","sRootPathDBini="+sRootPathDBini);
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("1_VSUSERINFO","Unable to read 1_VSUSERINFO.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("1_VSUSERINFO","Unable to close the 1_VSUSERINFO.ini file");
						}
					}
				}
				
	String driverName = null;
	driverName=ini.getProperty("DRIVERNAME");
	connectionUrl=ini.getProperty("CONNECTIONSTRING");
	WriteLog("1_VSUSERINFO","driverName="+driverName+",connectionUrl="+connectionUrl);

	CallableStatement callableStatement = null;

	WriteLog("1_VSUSERINFO"," output "+connectionUrl);
	if(sHeaderPresentValue.equals("YES")) 
	{
		sHeaderValue=ini.getProperty(sHeaderKey);
	}

	String sCabname=null;
	String sSessionId = null;
	String sJtsIp = null;
	String sUserName = null;
	String sReportProcedureName=null;
	String sReportTableName=null;
	
	String sFromDate=request.getParameter("FromDates");
	String sToDate=request.getParameter("ToDate");

	String sOutputXML="";
	String sInputXML = "";
	String maincode = "";
	String Totalrec = "0";

	String url = "";
	String Status="";
	String sStr_ServerType="";
	String sInputXml="";
	double fPercentage=0;
	String sColumnNamesArr[]=split(sColumnHeaders,',');
	String sDBMappedColsArr[]=split(sDBMappedCols,',');
	String sFinalColumns[]=split(sColumnHeaders,',');
	for(int i=0;i<sColumnNamesArr.length;i++)
	{
		if(sColumnNamesArr[i].indexOf("~D")!=-1)
			sFinalColumns[i]=sColumnNamesArr[i].substring(0,sColumnNamesArr[i].length()-2);

	}
	
	String sFieldNamesDB[]=split(sFieldValues,'#');

	for(int i=0;i<sFieldNamesDB.length;i++)
	{
		sFieldValuesReport=sFieldValuesReport+sFieldNamesDB[i]+',';
	}
	sFieldValuesReport=sFieldValuesReport.substring(0,sFieldValuesReport.length()-1);
	
	//Aging Implementation
	
	String sRowXml="";

	int iJtsPort = 0;
	boolean bError=false;
	String FTime = request.getParameter("FTime");
	String TTime = request.getParameter("TTime");
	String getDBUSERByUserIdSql = "{call "+sProcedureName+"(?,?,?,?,?,?,?,?,?)}";
	String output = "" ;
	try
	{
		WriteLog("1_VSUSERINFO"," sFromDate "+sFromDate);
		WriteLog("1_VSUSERINFO"," sToDate "+sToDate);
		WriteLog("1_VSUSERINFO"," sFieldValuesReport "+sFieldValuesReport);
		WriteLog("1_VSUSERINFO"," Param "+sProcedureName+" '"+sFromDate+"','"+FTime+"','"+sToDate+"','"+TTime+"','"+UserNames+"','"+sFieldValuesReport+"','"+sUserMailID+"','"+sFilePath+"',''");

			Class.forName(driverName);
			conn = DriverManager.getConnection(connectionUrl);
			callableStatement = conn.prepareCall(getDBUSERByUserIdSql);
			callableStatement.setString(1, sFromDate);
			callableStatement.setString(2, FTime);
			callableStatement.setString(3, sToDate);
			callableStatement.setString(4, TTime);
			callableStatement.setString(5, UserNames);
			callableStatement.setString(6, sFieldValuesReport);
			callableStatement.setString(7, sUserMailID);
			callableStatement.setString(8, sFilePath);
			callableStatement.registerOutParameter(9, java.sql.Types.VARCHAR);
			callableStatement.execute();

			output = callableStatement.getString(9);
			WriteLog("1_VSUSERINFO"," output "+output);
	}
	catch(SQLException ignore)
	{
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		bError= true;
		WriteLog("1_VSUSERINFO"," WFSession Data Fetch Exception:::::: "+ignore.toString());
	}
	finally {
 
	if (callableStatement != null) {
        try {
            callableStatement.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
	}

if(!bError)
	{

		WriteLog("1_VSUSERINFO"," output:::::: "+output);
		try
		{

			if(output.equals(""))
			{
				bError= true;
				//maincode=sOutputXML.substring(sOutputXML.indexOf("<MainCode>")+10 , sOutputXML.indexOf("</MainCode>"));
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+output+"</b></font><center>");
			}
			else
			{
				
					try
							{
								 if(Integer.parseInt(output) == 0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
								out.println(ig.toString());
								WriteLog("1_VSUSERINFO"," Exception "+ig.toString());
							}
			}
		}
		
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
			WriteLog("1_VSUSERINFO"," Exception "+exp.toString());
		}
		
	}
%>
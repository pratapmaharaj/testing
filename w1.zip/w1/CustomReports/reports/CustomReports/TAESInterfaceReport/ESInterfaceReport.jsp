

<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>

<%@ include file="customized.process" %>


<HTML>
<HEAD>
<TITLE>ES GEAC Interface Report</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>
<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
}
</style>

<script>
$(document).ready(function(){$('#From_Date_Into').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date_Into').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", 
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#From_Date_Inter').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", 
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date_Inter').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", 
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	});
	var FromDate = new Date();
	var type = '';
	var allWindows = new Array();
	var win; // new window object
/*functions echeck,ValidateForm*/

 	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}
	
	function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}

function ValidateForm(emailID){
//	var emailID=document.frmSample.txtEmail
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }


 function ChangeDateTag(obj)
{
	var InsertVal='';
	for(iterate=0;iterate<obj.length;iterate++)
	{
		if(obj.options[iterate].selected==true)
		{
			InsertVal=InsertVal+obj.options[iterate].value+'/';
		}
	}
	InsertVal=InsertVal.substring(0,InsertVal.length-1);
	var Table=document.getElementById('newgen');
	var lastRow = Table.rows.length;
	if (lastRow > 0) Table.deleteRow(lastRow - 1);
	while(InsertVal.indexOf('_')!=-1)
	{
		InsertVal=InsertVal.replace('_',' ');
	}
	var Row=Table.insertRow(0);
	var Cell=Row.insertCell();
	Cell.className="EWLabelBoldNew";
	Cell.innerHTML=InsertVal;
}
function convertMonth(strMonth)
{
		if(strMonth=="JAN")
			strMonth="00";
		else if(strMonth=="FEB")
			strMonth="01";
		else if(strMonth=="MAR")
			strMonth="02";
		else if(strMonth=="APR")
			strMonth="03";
		else if(strMonth=="MAY")
			strMonth="04";
		else if(strMonth=="JUN")
			strMonth="05";
		else if(strMonth=="JUL")
			strMonth="06";
		else if(strMonth=="AUG")
			strMonth="07";
		else if(strMonth=="SEP")
			strMonth="08";
		else if(strMonth=="OCT")
			strMonth="09";
		else if(strMonth=="NOV")
			strMonth="10";
		else if(strMonth=="DEC")
			strMonth="11";
	return strMonth;
}

function DateComparator(Date_To,Date_From)
{	
	
		if (Date_From == "" && Date_To == "")
			{
				return true;
			}

			var FromDay = Date_From.split("/")[0];
			var FromMonth = convertMonth(Date_From.split("/")[1]);
			var FromYear = Date_From.split("/")[2];
			
			//alert("From:::Day::"+FromDay+"  Month::"+FromMonth+"	Year::"+FromYear);
			
			var ToDay = Date_To.split("/")[0];
			var ToMonth = convertMonth(Date_To.split("/")[1]);
			var ToYear = Date_To.split("/")[2];
			
			//alert("To:::Day::"+ToDay+"  Month::"+ToMonth+"	Year::"+ToYear);
			
			var CurrentDate=new Date();
			var CurrentDay = CurrentDate.getDate();
			var CurrentMonth = CurrentDate.getMonth();
			var CurrentYear = CurrentDate.getFullYear();
			//alert("Current:::Day::"+CurrentDay+"  Month::"+CurrentMonth+"	Year::"+CurrentYear);

			var toDate = (new Date(ToYear,ToMonth,ToDay)).getTime();
			var fromDate = (new Date(FromYear,FromMonth,FromDay)).getTime();
			var CurrentDate = (new Date(CurrentYear,CurrentMonth,CurrentDay)).getTime();
			
			//alert("FromDate::"+fromDate+"  ToDate::"+toDate+"	Current::"+CurrentDate);

			//alert("Fr : "+new Date(fromDate)+"\nTo : "+new Date(toDate)+"\nCu : "+new Date(CurrentDate));
			if(fromDate > toDate)
			{
				alert("To Date cannot be less than From Date.");
				return false;
			}
			else if(fromDate > CurrentDate)
			{
				alert("From Date cannot be future date.");
				return false;
			}
			else if(toDate > CurrentDate)
			{
				alert("To Date cannot be future date.");
				return false;
			}
			//alert("BAzooka111111!!!");
			return true;

	
}


function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";
	sDate	= window.showModalDialog('/processmanager/reports/GMACReports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');
	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
	

}
function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	strResult=strdate+"/"+strMonth+"/"+stryear;
	return strResult;
}


	
	
	function openreport()
	{	
		var From_Date_Into="";
		var To_Date_Into=''
		
		var QC_Decision='';
		var UserEmailID=document.getElementById('EMail-ID').value;

		From_Date_Into=document.forms["textForm"].From_Date_Into.value;
		To_Date_Into=document.forms["textForm"].To_Date_Into.value;
		From_Date_Inter=document.forms["textForm"].From_Date_Inter.value;
		To_Date_Inter=document.forms["textForm"].To_Date_Inter.value;
		//alert(UserEmailID+''+RegDateRangeFrom+''+RegDateRangeTo+''+QDateRangeFrom+''+QDateRangeTo);
	
		
		
		

		
	
	//------------------------------------Date Validation start--------------------------------		
	
	if ((document.forms["textForm"].From_Date_Into.value=='' && document.forms["textForm"].To_Date_Into.value=='') && (document.forms["textForm"].From_Date_Inter.value=='' && document.forms["textForm"].To_Date_Inter.value=='') )
		{
			alert("Please Select Introduction Date or Interface Date");
			return false ;
		}
	
	

	
		if ((document.forms["textForm"].From_Date_Into.value=='' && document.forms["textForm"].To_Date_Into.value!='') || (document.forms["textForm"].From_Date_Into.value!='' && document.forms["textForm"].To_Date_Into.value==''))
		{
			alert("Please select the Introduction Date Range.");
			return false;
		}
	
		if(document.forms["textForm"].From_Date_Into.value!='' && document.forms["textForm"].To_Date_Into.value!='')
		{
			if(!DateComparator(document.forms["textForm"].To_Date_Into.value,document.forms["textForm"].From_Date_Into.value))
			{
				return false;
			}
		}
		
		
		
		
		if ((document.forms["textForm"].From_Date_Inter.value=='' && document.forms["textForm"].To_Date_Inter.value!='') || (document.forms["textForm"].From_Date_Inter.value!='' && document.forms["textForm"].To_Date_Inter.value==''))
		{
			alert("Please select the Interface Date Range.");
			return false;
		}
	
		if(document.forms["textForm"].From_Date_Inter.value!='' && document.forms["textForm"].To_Date_Inter.value!='')
		{
			if(!DateComparator(document.forms["textForm"].To_Date_Inter.value,document.forms["textForm"].From_Date_Inter.value))
			{
				return false;
			}
		}
		
	
	
	
	
	
	
	
	
	
	
	

	//------------------------------------Date Validation End--------------------------------		
	
	
	//------------------------------------UserEmail Validation start--------------------------------	
		
		if(UserEmailID=='')
		{
			alert("Kindly enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
				
			}
		}
  //-------------------------------------END-----------------------------------------------------

		

		
		if(UserEmailID!='')
			{	
		
				//OpenRedict-Fix
    //window.top.ESINTERFACEEREPORT.location.href="ESInterfaceReportGenerate.jsp?From_Date_Into="+From_Date_Into+"&To_Date_Into="+To_Date_Into+"&From_Date_Inter="+From_Date_Inter+"&To_Date_Inter="+To_Date_Inter+"&ReportName=<%=request.getParameter("ReportName")%>&UserEmailID="+UserEmailID;
	var URI = "ESInterfaceReportGenerate.jsp?From_Date_Into="+From_Date_Into+"&To_Date_Into="+To_Date_Into+"&From_Date_Inter="+From_Date_Inter+"&To_Date_Inter="+To_Date_Inter+"&ReportName=<%=request.getParameter("ReportName")%>&UserEmailID="+UserEmailID;
	var StrOpenWin=strip_tags(URI,"");
	window.top.ESINTERFACEEREPORT.location.href=StrOpenWin;
				
	
			}
			
	
}
		function disbFields()
 {
 	document.getElementById('From_Date_Inter').value='';
	document.getElementById('To_Date_Inter').value='';
	document.getElementById('From_Date_Into').value='';
	document.getElementById('To_Date_Into').value='';
	//document.getElementById('From_Date_IMG_Inter').disabled=true;
	//document.getElementById('To_Date_IMG_Inter').disabled=true;
	//document.getElementById('From_Date_IMG_Into').disabled=true;
	//document.getElementById('To_Date_IMG_Into').disabled=true;

 	document.getElementById('From_Date_Inter').style.background='Gray';
	document.getElementById('To_Date_Inter').style.background='Gray';
	document.getElementById('From_Date_Into').style.background='Gray';
	document.getElementById('To_Date_Into').style.background='Gray';

 }
function chkradio(obj)
	{
		if(obj == 'i')
		{
			if(document.getElementById('Interface').checked == true) 
			{
				document.getElementById('Interface').checked = false;
			}
			document.getElementById('From_Date_Inter').value='';
			document.getElementById('To_Date_Inter').value='';
			document.getElementById('From_Date_Inter').style.background='Gray';
			document.getElementById('To_Date_Inter').style.background='Gray';
			//document.getElementById('From_Date_IMG_Inter').disabled=true;
			//document.getElementById('To_Date_IMG_Inter').disabled=true;
			//document.getElementById('From_Date_IMG_Into').disabled=false;
			//document.getElementById('To_Date_IMG_Into').disabled=false;
			document.getElementById('From_Date_Into').style.background='White';
			document.getElementById('To_Date_Into').style.background='White';
		}
		else if(obj == 'd')
		{
			if(document.getElementById('Introduction').checked == true) 
			{
				document.getElementById('Introduction').checked = false;
			}
			document.getElementById('From_Date_Inter').style.background='White';
			document.getElementById('To_Date_Inter').style.background='White';
			document.getElementById('From_Date_Into').style.background='Gray';
			document.getElementById('To_Date_Into').style.background='Gray';
			//document.getElementById('From_Date_IMG_Into').disabled=true;
			//document.getElementById('To_Date_IMG_Into').disabled=true;
			document.getElementById('From_Date_Into').value='';
			document.getElementById('To_Date_Into').value='';

			//document.getElementById('From_Date_IMG_Inter').disabled=false;
			//document.getElementById('To_Date_IMG_Inter').disabled=false;
		}

	}


	
</script>

<body topmargin="0" leftmargin="5" onunload="UnloadReportWindow();"  >

			<form name='textForm' method=post>


			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">TA ES GEAC INTERFACE REPORT</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This will be a daily scheduled report with list of all the workitems that have been sent for interface with GEAC on a given day. 
				</td></tr>
				<tr><td class="EWLabel1"> 
				Following columns will be present in the report.
				</td></tr>
				<tr><td class="EWLabel1">
				</td></tr><tr><td class="EWLabel1">Select the requisite date range for generating the report for the same.</td>
				</tr>
				
				<td>
				<br/>
					<p style="color: red; font-size: 10pt">Note:  * fields are mandatory.</p>

				</td>
				</table>

			

			<table border="0" width="95%" cellspacing="1" align="center">
				
				
				  
				
				
				<tr>
					<td>
					<p class="EWLabel122"><input type = "hidden" name ="Introduction" id ="Introduction" value = "Introduction" align='left' style="width: 14px" >Introduction Date Range<font color="RED">*</font></p></td>
					</tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date_Into" type="text" readonly id="From_Date_Into" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date_Into" readonly type="text"  id="To_Date_Into" >
					
					</td>

				</tr>
				<tr>&nbsp;</tr>
				
				<tr>
					<td>
					<p class="EWLabel122"><input type = "hidden" name ="Interface" id ="Interface" value = "Interface" align='left' style="width: 14px" >Interface Date Range<font color="RED">*</font></p></td>
					</tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date_Inter" readonly type="text"  id="From_Date_Inter" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date_Inter" readonly type="text"  id="To_Date_Inter" >
					
					</td>

				</tr>
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID<font color="RED">*</font></b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>

				
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>
	
			
			</form>
</body>
</Html>	 




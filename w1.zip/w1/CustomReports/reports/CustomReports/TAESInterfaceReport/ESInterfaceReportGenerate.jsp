<%@ include file="customized.process" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.sql.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="com.tcsta.util.PathUtil" %>

<HTML>
<HEAD>
<TITLE>AP Interface Report</TITLE>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
</script>

<body >
<%!

 public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }
%>

<%
WriteLog("ES_GEAC_Interface","sOutputXML ::> sOutputXML : IN ESAgingGenerate") ;

	String sProcessDefId=null;
	String sProcedureName=null;
	String sColumnHeaders=null;
	String sReportName=null;
	String sFileName=null;
	String sNumberOfColumns=null;
	String sProcedureNameKey=null;
	String sColumnHeadersKey=null;
	String sFileNameKey=null;
	String sNumberOfColumnsKey=null;
	String sHeaderKey=null;
	String sHeaderPresentKey=null;
	String sDBMappedColsKey=null;
	String sHeaderValue=null;
	String sHeaderPresentValue=null;
	String sCabinetName=null;	
	String sDBMappedCols=null;
	String sFieldValuesKey=null;
	String sFieldValues=null;
	String sFieldValuesReport="";
	String sUserMailID=null;
	String sFilePath=null;
	String sFilePathKey=null;
	String UserNames = "" ;
	
	sReportName	=request.getParameter("ReportName");
	sUserMailID=request.getParameter("UserEmailID");
	sReportName	=sReportName.toUpperCase();
	
	WriteLog("ES_GEAC_Interface","sReportName : "+sReportName) ;
	WriteLog("ES_GEAC_Interface","sUserMailID : "+sUserMailID) ;

	sProcedureNameKey=sReportName +"_PROCEDURENAME" ;
	WriteLog("ES_GEAC_Interface","sProcedureNameKey : "+sProcedureNameKey) ;
	
	sColumnHeadersKey=sReportName+"_COLUMNHEADERS";
	
	WriteLog("ES_GEAC_Interface","sColumnHeadersKey : "+sColumnHeadersKey) ;
	sFileNameKey=sReportName+"_FILENAME";

	WriteLog("ES_GEAC_Interface","sFileNameKey : "+sFileNameKey) ;

	sNumberOfColumnsKey=sReportName+"_NUMBEROFCOLUMNS";

	WriteLog("ES_GEAC_Interface","sNumberOfColumnsKey : "+sNumberOfColumnsKey) ;

	sHeaderPresentKey=sReportName+"_HEADERPRESENT";

	WriteLog("ES_GEAC_Interface","sHeaderPresentKey : "+sHeaderPresentKey) ;
	
	sHeaderKey=sReportName+"_HEADER";

	WriteLog("ES_GEAC_Interface","sHeaderKey : "+sHeaderKey) ;
	
	sDBMappedColsKey=sReportName+"_DBMAPPEDCOLS";
	WriteLog("ES_GEAC_Interface","sDBMappedColsKey : "+sDBMappedColsKey) ;
	sFieldValuesKey=sReportName+"_FIELDVALUES";

	WriteLog("ES_GEAC_Interface","sFieldValuesKey : "+sFieldValuesKey) ;
	
	sFilePathKey=sReportName+"_PATH";
	
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAESInterfaceReport.ini";
	
	Properties ini = new Properties();
	//Unreleased dataresource release fix
	FileInputStream fis = null;
		try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("ES_GEAC_Interface","Unable to read TAESInterfaceReport.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("ES_GEAC_Interface","Unable to close the TAESInterfaceReport.ini file");
						}
					}
				}
	//ini.load(new FileInputStream(sRootPathini));

	
	
	
	String pathName = "" ;
	pathName = ini.getProperty(sReportName +"_PATH");
	sProcessDefId=ini.getProperty("PROCESSDEFID");
	
	sCabinetName=ini.getProperty("CABINETNAME");
	sProcedureName=ini.getProperty(sProcedureNameKey);
	
	sColumnHeaders=ini.getProperty(sColumnHeadersKey);
	
	sFileName=ini.getProperty(sFileNameKey);
	
	sNumberOfColumns=ini.getProperty(sNumberOfColumnsKey);
	
	sHeaderPresentValue=ini.getProperty(sHeaderPresentKey);
	
	sDBMappedCols=ini.getProperty(sDBMappedColsKey);
	
	sFieldValues=ini.getProperty(sFieldValuesKey);
	
	sFilePath=ini.getProperty(sFilePathKey);
	WriteLog("ES_GEAC_Interface","sHeaderPresentValue"+sHeaderPresentValue);
	WriteLog("ES_GEAC_Interface","sCabinetName"+sCabinetName);
	WriteLog("ES_GEAC_Interface","sProcedureName"+sProcedureName);
	WriteLog("ES_GEAC_Interface","sFileName"+sFileName);
	WriteLog("ES_GEAC_Interface","sNumberOfColumns"+sNumberOfColumns);
	WriteLog("ES_GEAC_Interface","sHeaderPresentValue"+sHeaderPresentValue);
	WriteLog("ES_GEAC_Interface","sDBMappedCols"+sDBMappedCols);


	if(sHeaderPresentValue.equals("YES")) 
	{
		sHeaderValue=ini.getProperty(sHeaderKey);
	}

	String sCabname=null;
	String sSessionId = null;
	String sJtsIp = null;
	String sUserName = null;
	String sReportProcedureName=null;
	String sReportTableName=null;
	String sOutputXML="";
	String sInputXML = "";
	String maincode = "";
	String Totalrec = "0";
	String url = "";
	String Status="";
	String sStr_ServerType="";
	String sInputXml="";
	double fPercentage=0;
		
	String sColumnNamesArr[]=split(sColumnHeaders,',');
	String sDBMappedColsArr[]=split(sDBMappedCols,',');
	String sFinalColumns[]=split(sColumnHeaders,',');
	
	for(int i=0;i<sColumnNamesArr.length;i++)
	{
		if(sColumnNamesArr[i].indexOf("~D")!=-1)
			sFinalColumns[i]=sColumnNamesArr[i].substring(0,sColumnNamesArr[i].length()-2);

	}

	String sFieldNamesDB[]=split(sFieldValues,'#');

	for(int i=0;i<sFieldNamesDB.length;i++)
	{
		sFieldValuesReport=sFieldValuesReport+sFieldNamesDB[i]+',';
	}
	sFieldValuesReport=sFieldValuesReport.substring(0,sFieldValuesReport.length()-1);

	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("ES_GEAC_Interface","sRootPathDBini="+sRootPathDBini);
	//Unreleased dataresource release fix
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("ES_GEAC_Interface","Unable to DBReports.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("ES_GEAC_Interface","DBReports.ini file");
						}
					}
				}
				
	//ini.load(new FileInputStream(sRootPathDBini));
	String driverName = null;

	String connectionUrl=ini.getProperty("CONNECTIONSTRING");
	driverName = ini.getProperty("DRIVERNAME");
	WriteLog("ES_GEAC_Interface"," output "+connectionUrl);
	
	String From_Date_Into=request.getParameter("From_Date_Into");
	if(From_Date_Into.equals("undefined"))
	{
		From_Date_Into="";
	}
	String To_Date_Into=request.getParameter("To_Date_Into");
	if(To_Date_Into.equals("undefined"))
	{
		To_Date_Into="";
	}
	String From_Date_Inter=request.getParameter("From_Date_Inter");
	if(From_Date_Inter.equals("undefined"))
	{
		From_Date_Inter="";
	}
	String To_Date_Inter=request.getParameter("To_Date_Inter");
	if(To_Date_Inter.equals("undefined"))
	{
		To_Date_Inter="";
	}
	String Document_Category="";
	String Vendor_Name="";
	String Vendor_Number="";

	
	WriteLog("ES_GEAC_Interface","APILCRGenerate.jsp?From_Date_Into="+From_Date_Into+"&To_Date_Into="+To_Date_Into+"&Document_Category="+Document_Category+"&Vendor_Name="+Vendor_Name+"&Vendor_Number="+Vendor_Number+"&From_Date_Inter="+From_Date_Inter+"&To_Date_Inter="+To_Date_Inter+"mailid-->"+sUserMailID+"filename-->"+sFileName+"patrh--->"+sFilePath);	
	String sRowXml="";
	
	int iJtsPort = 0;
	boolean bError=false;
	

	CallableStatement callableStatement = null;
	Connection conn=null;
	String getDBUSERByUserIdSql = "{call "+sProcedureName+"(?,?,?,?,?,?,?,?)}";

	String output = "" ;
	WriteLog("ES_GEAC_Interface","From_Date_Into "+From_Date_Into);
	WriteLog("ES_GEAC_Interface","To_Date_Into "+To_Date_Into);
	WriteLog("ES_GEAC_Interface","Document_Category "+Document_Category);
	WriteLog("ES_GEAC_Interface","Vendor_Name "+Vendor_Name);
	WriteLog("ES_GEAC_Interface","Vendor_Number "+Vendor_Number);
	WriteLog("ES_GEAC_Interface","From_Date_Inter"+From_Date_Inter);
	WriteLog("ES_GEAC_Interface","To_Date_Inter"+To_Date_Inter);
	WriteLog("ES_GEAC_Interface","sUserMailID"+sUserMailID);
	
	
			
	try{
			Class.forName(driverName);
			conn = DriverManager.getConnection(connectionUrl);
			callableStatement = conn.prepareCall(getDBUSERByUserIdSql);
			callableStatement.setString(1, From_Date_Into);
			callableStatement.setString(2, To_Date_Into);
			
			callableStatement.setString(3, From_Date_Inter);
			callableStatement.setString(4, To_Date_Inter);
			callableStatement.setString(5, sUserMailID);
			callableStatement.setString(6, sFileName);
			callableStatement.setString(7, sFilePath);
			callableStatement.registerOutParameter(8, java.sql.Types.VARCHAR);
			callableStatement.execute();

			output = callableStatement.getString(8);
			WriteLog("ES_GEAC_Interface"," output "+output);
			
	}
	catch(SQLException ignore)
	{
		%>
									<script>alert("Some Error please check logs");</script>
									<%
		WriteLog("ES_GEAC_Interface"," WFSession Data Fetch Exception:::::: "+ignore.toString());
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		bError= true;
		
	}
	finally {
 
	if (callableStatement != null) {
        try {
            callableStatement.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
	}
	if(!bError)
	{

		WriteLog("ES_GEAC_Interface"," output:::::: "+output);
		try
		{

			if(output.equals(""))
			{
				bError= true;
					%>
					<script>alert("Error in Executing Procedure:");</script>
					<%
				//maincode=sOutputXML.substring(sOutputXML.indexOf("<MainCode>")+10 , sOutputXML.indexOf("</MainCode>"));
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+output+"</b></font><center>");
				
				
			}
			else
			{
				
					try
							{
								 if(Integer.parseInt(output) == 0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
							log("ES_GEAC_Interface "+ig.toString());
							%>
									<script>alert("Some Error please check logs");</script>
									<%
								out.println(ig.toString());
												
							}
			}
		}
		
		catch(Exception exp)
		{
			%>
									<script>alert("Some Error please check logs");</script>
									<%
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
			log("ES_GEAC_Interface "+exp.toString());
		}
		
	}

%>

<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="com.newgen.wfdesktop.util.*" %>
<%@ page import="java.util.*"%>
<%@page pageEncoding="UTF-8"%>
<%@ include file="/CustomForms/TA_AP_Custom/AP/customized_TA.process" %> 
<%@page contentType="text/html;charset=UTF-8"%>

<%
	
%>
 <head>
 <!-- For submitting form when click on ENTER Key -->

 <script>
 function stopRKey(evt) { 
	var evt = (evt) ? evt : ((event) ? event : null); 
	var node = (evt.target) ? evt.target : ((evt.srcElement) ? evt.srcElement : null); 
	if ((evt.keyCode == 13) && (node.type=="text")) {
		return false;
	} 
} 
document.onkeypress = stopRKey; 
 </script>
</head>

<link rel="stylesheet" href="/webdesktop/webtop/TA_AP/css/docstyle.css" TYPE="text/css"> 
<link rel="stylesheet" href="/webdesktop/webtop/TA_AP/css/example.css" TYPE="text/css" MEDIA="screen">
<link rel="stylesheet" href="example-print.css" TYPE="text/css" MEDIA="print">
<link rel="stylesheet" href="/webdesktop/webtop/TA_APVS/css/docstyle.css" TYPE="text/css"> 
<link rel="stylesheet" href="/webdesktop/webtop/TA_APVS/css/example.css" TYPE="text/css" MEDIA="screen">

<script src="/webtop/scripts/Common.js"></script> 
<link href="/webdesktop/CustomForms/TA_AP_Custom/Web/css/TA_AP_Style.css" rel="stylesheet" type="text/css">
<body onload=fnLoad();>
<FORM name="dataform" >
<h1><img src="/webdesktop/webtop/TA_AP/Images/logo.png" width=150 height=50></img></h1>
	<table border=1 width="100%">
		 <tr >
			<td colspan=3 align='center' width="100%" bgcolor="#CCCCFF">
			<b>Vendor Search</b>
		   </td>
		</tr>

	  <tr width=100%>
			<td width=140 nowrap align=left  class="EWTableContentsText">Vendor Name</td>
			<td align=left class="EWTableContentsText" >
			<input name="vendor_name" type="text" onkeyPress="fnOnKeyPress()" class='TextFieldColor' style=width:130></td>
						<td width=140 nowrap align=left  class="EWTableContentsText"></td>
		</tr>
		
		<tr width=100%>
			<td width=140 nowrap align=left  class="EWTableContentsText">Vendor Number</td>
			<td align=left class="EWTableContentsText" >
			<input name="vendor_id" type="text"   onkeyPress="fnOnKeyPress()"  class='TextFieldColor' style=width:130>
			<td bgcolor="#CCCCFF"><div class="myButton2"><INPUT align=center type="button" name="btnSearch" id='btnSearch' value="" onClick="fnSearchClick()"></div></td>
</td>
		</tr>


		
		</table>
</form>
</body>
<script>
var objwindowTop=window.top;
function fnOnKeyPress()
{
	if(event.keyCode==13)
	{
		fnSearchClick();
	}
}
function fnLoad()
{
	document.dataform.vendor_name.focus();
	fnDisablePrev();
	fnDisableNext();
}
 
function fnSearchClick()
{
	var sSearchstring=document.dataform.vendor_id.value;
	var sSearchstring1=document.dataform.vendor_name.value;
    //var sSearchstring2=document.dataform.ExchangeToBase.value;
	
	if((sSearchstring=='' )  && (sSearchstring1==''))
	   {
	   
	      if((sSearchstring.length<1) )
		          {
			      alert("Kindly enter Vendor Name with minimum of one characters.");
			      document.dataform.vendor_name.focus();
			      return;
		          }
	   }
	   
	   

	   
	   if((sSearchstring.length<1) && (sSearchstring1==''))
		          {
			      alert("Kindly enter Vendor Name  with minimum of 1 characters.");
			      document.dataform.vendor_name.focus();
			      return;
		          }
		if((sSearchstring1.length<1) && (sSearchstring=='') )
		          {
			      alert("Kindly enter Vendor Id with minimum of 1 characters.");
			      document.dataform.vendor_id.focus();
			      return;
		          }	

	   if((sSearchstring.length<1) && (sSearchstring1.length<1))
		          {
			      alert("Kindly enter Vendor Name or  Vendor Id with minimum of 1 characters.");
			      document.dataform.vendor_name.focus();
			      return;
		          }
	   
				  
	   
	var sFinalSearchString="";

	//sSearchstring=StarSearch(sSearchstring);
	//sSearchstring1=StarSearch(sSearchstring1);

	sFinalSearchString=sSearchstring+'~'+sSearchstring1;
	objwindowTop.frames["frmView"].document.getElementById("msgCell").innerText="Please wait while the request is getting processed...";
	objwindowTop.frames["frmView"].document.dataform.Method.value="";	 
	objwindowTop.frames["frmView"].document.dataform.SearchString.value=sFinalSearchString;
	objwindowTop.frames["frmView"].document.dataform.submit();
}



function fnDisableNext()
{
}
function fnDisablePrev()
{
}
function fnNextClick()
{
	objwindowTop.frames["frmView"].document.dataform.Method.value="Next";
	objwindowTop.frames["frmView"].document.dataform.submit();
}
function fnPrevClick()
{
	objwindowTop.frames["frmView"].document.dataform.Method.value="Prev";
	objwindowTop.frames["frmView"].document.dataform.submit();
}
</script>
</html>

<link href="/webtop/css/docstyle.css" rel="stylesheet" type="text/css">
<body >
<FORM name="dataform" >
<center>
	<table>
		 	<td align='center'>
				<input type="Button" class="EWButton" name="btnOk" value="    OK    " onClick="fnOk()">					
				<input type="Button" class="EWButton" name="btnCancel" value=" Cancel " onclick="self.close()">
		    </td>
		</tr>
	</table>
</center>  
</form>
<script>
function fnOk()
{
	var Matrix_tbl=window.top.frames["frmView"].document.getElementById("Matrix_Grid");
	if(Matrix_tbl==null)
	{
		alert('Please select the Vendor Deatils');
	}
	else 
	{
		var rowlength = Matrix_tbl.rows.length;
		var row = "";
		var selected=false;
		var venid1="";
		var vendn1="";
		var Payterm1="";
		var Payterm2="";
		var BusinessAreaname2="";
		var sReturnValue=new Array();
	
		if(rowlength>2)
		{
			for(var i=1;i<rowlength;i++)
			{
				row= Matrix_tbl.rows[i];

				venid1=row.cells[1].innerHTML;
				vendn1=row.cells[2].innerHTML;
				Payterm1=row.cells[3].innerHTML;
				Payterm2=row.cells[4].innerHTML;
				//venid1=venid1.substring(5,venid1.length-6);
                //vendn1=vendn1.substring(5,venid1.length-6);
				var sReturnValue1 = "" ;
 				if(window.top.frames["frmView"].document.dataform.BusinessAreaRadio[i-1].checked)
				{
					for(var k=1;k<row.cells.length;k++)
					{
						sReturnValue=sReturnValue+"~"+row.cells[k].innerHTML ;
					}
					//alert(sReturnValue1) ;
					/*
 					if(vendn1=="")
					{
						
						sReturnValue=row.cells[1].innerHTML+ '~' + vendn1+ '~'+'~'+'Y';
					}
					else
					{
						sReturnValue=row.cells[1].innerHTML+ '~' + vendn1+ '~'+ Payterm1 + '~' +Payterm2 + '~' + 'N';
					}
					*/
					selected=true;

					while(sReturnValue.indexOf("&amp;")!=-1)
					{
						sReturnValue=sReturnValue.replace("&amp;","&");
					}
					//Added by sweejo as ">","<" values gets converted....
					while(sReturnValue.indexOf("&gt;")!=-1)

					{
						sReturnValue=sReturnValue.replace("&gt;",">");
					}
					while(sReturnValue.indexOf("&lt;")!=-1)
					{
						sReturnValue=sReturnValue.replace("&lt;","<");
					}
					while(sReturnValue.indexOf("&nbsp;")!=-1)
					{
						sReturnValue=sReturnValue.replace("&nbsp;","");
					}

						window.returnValue=sReturnValue;
						window.close();
				}
		}
		if(selected==false)
		{
			alert("Please select Vendor Deatils.");
		}
	}
	else
	{
		for(var i=1;i<rowlength;i++)
		{
			row= Matrix_tbl.rows[i];

			var sReturnValue1 = "" ;
			if(window.top.frames["frmView"].document.dataform.BusinessAreaRadio.checked)
			{
				for(var k=1;k<row.cells.length;k++)
				{
					sReturnValue=sReturnValue+"~"+row.cells[k].innerHTML ;
				}
				
					//alert(sReturnValue) ;
					/*
				if(venid1=="" && vendn1=="" && BusinessAreaname2=="" && Payterm1=="" && Payterm2=="")
				{
					sReturnValue=row.cells[1].innerHTML +'~' + svendn1+ '~'+'~'+'~'+'Y';
				}
				else
				{
					sReturnValue=row.cells[1].innerHTML +'~' + vendn1+ '~'+ Payterm1 + '~' +Payterm2 + '~' + 'N';
				}
				*/
				selected=true;
				while(sReturnValue.indexOf("&amp;")!=-1)
				{
					sReturnValue=sReturnValue.replace("&amp;","&");
				}
				
					while(sReturnValue.indexOf("&gt;")!=-1)

					{
						sReturnValue=sReturnValue.replace("&gt;",">");
					}
					while(sReturnValue.indexOf("&lt;")!=-1)

					{
						sReturnValue=sReturnValue.replace("&lt;","<");
					}

					window.returnValue=sReturnValue;
					window.close();
				
			}

		}
		if(selected==false)
		{
			alert("Please select the Vendor Deatils.");
		}

	}
}
 
}
</script>
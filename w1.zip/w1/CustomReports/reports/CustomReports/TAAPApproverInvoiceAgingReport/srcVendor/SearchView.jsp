
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="com.newgen.wfdesktop.util.*" %>
<%@ page import="java.util.*"%>
<%@ include file="/CustomForms/TA_AP_Custom/AP/customized_TA.process" %> 
<%@ page contentType="text/html;charset=UTF-8"%>
<%@page pageEncoding="UTF-8"%>

<link rel="stylesheet" href="/webdesktop/webtop/TA_AP/css/docstyle.css" TYPE="text/css"> 


<%
	WriteLog("TA_Vendor_Search","View:::::::::::::::::Open" );
	int iBatchSize=5;
	String sCabname=null;
	String sSessionId = null;
	String sJtsIp = null;
	String sErrMsg="";
	ArrayList alBusinessAreaData=null;
	int iJtsPort = 0;
	String sFirstBusinessAreaNo="0";
	String sLastBusinessAreaNo="0";
	String searchInputArr[];
	String searchBusinessAreaArr[];
	String searchString1="";
	String searchString2 ="";
	String sSearchString="";

	String sVendor="";

	String sid="";
	String SearchArr[];
	
	String sOutput="";

	String strNoOfCols = "37";
	String sOutputXML="";
	String BusinessAreaCode ="";
	boolean bError=false;
	boolean te=false;
	

	boolean bNextEnable=false;
	boolean bPrevEnable=false;
	try
	{
		sCabname=wfsession.getEngineName();
		sSessionId = wfsession.getSessionId();
		sJtsIp = wfsession.getJtsIp();
		iJtsPort = wfsession.getJtsPort();		
	}
	catch(Exception e)
	{
		bError=true;
		sErrMsg="Session Timeout.";
	}
	if(!bError)
	{
		
		try
		{	

			if(request.getParameter("SearchString")!=null)
			{
				sSearchString=request.getParameter("SearchString").replaceAll("'","''");

				String temp=new String(request.getParameter("SearchString").getBytes("iso-8859-1"),"iso-8859-7");

				String sQuery="";

				WriteLog("TA_Vendor_Search","temp  :"+temp);
				
				if(sSearchString.indexOf('~')!=-1)
				{
					SearchArr=split(sSearchString,'~');
					sVendor=SearchArr[1];
					sid = SearchArr[0];
				
				}
				WriteLog("TA_Vendor_Search","TA View:"+request.getParameter("SearchString"));

		/*sQuery = "select rtrim(ltrim(Vendor_Name)),rtrim(ltrim(Vendor_Number)), "+
		"rtrim(ltrim(Bank_Code_Number)), rtrim(ltrim(Bank_Account_Number)), "+
		"rtrim(ltrim(Address_1)), rtrim(ltrim(Address_2)), "+
		"rtrim(ltrim(Address_3)), rtrim(ltrim(Email_ID)), "+
		"rtrim(ltrim(Optional_Address_1)), rtrim(ltrim(Optional_Address_2)), "+
		"rtrim(ltrim(W9_Indicator)), rtrim(ltrim(V1099_Code)) "+
		"from WNS_TA_APVS_Vendor_Master WITH(NOLOCK) ";*/
		
		sQuery = "select rtrim(ltrim(Vendor_Name)),rtrim(ltrim(Vendor_Number)), "+
		"rtrim(ltrim(Bank_Code_Number)), rtrim(ltrim(Bank_Account_Number)), "+
		"rtrim(ltrim(Address_1)), rtrim(ltrim(Address_2)), "+
		"rtrim(ltrim(Address_3)), rtrim(ltrim(Email_ID)), "+
		"rtrim(ltrim(Optional_Address_1)), rtrim(ltrim(Optional_Address_2)), "+
		"rtrim(ltrim(W9_Indicator)), rtrim(ltrim(V1099_Code)), "+
		"rtrim(ltrim(Vendor_Terms)), rtrim(ltrim(Vendor_Entity)), "+
		"rtrim(ltrim(Vendor_Status)), rtrim(ltrim(State_Code)), "+
		"rtrim(ltrim(State_Code_Validation)), rtrim(ltrim(Postal_Code)), "+
		"rtrim(ltrim(Optional_Address_Use)), rtrim(ltrim(Combined_Single_Payment)), "+
		"rtrim(ltrim(Tax_ID)), rtrim(ltrim(V1099_Payee_Name)), "+
		"rtrim(ltrim(V1099_Payee_Name_Indicator)), rtrim(ltrim(Bank_Account_Payment)), "+
		"rtrim(ltrim(Bank_Account_Name)), rtrim(ltrim(Bank_Name_Line_1)), "+
		"rtrim(ltrim(Bank_Name_Line_2)), rtrim(ltrim(Bank_Address_Line_1)), "+
		"rtrim(ltrim(Bank_Address_Line_2)), rtrim(ltrim(Bank_Address_Line_3)), "+
		"rtrim(ltrim(Bank_Postal_Code)), rtrim(ltrim(Vendor_Bank_Account_Reference)), "+
		"rtrim(ltrim(Prenote_Switch)), rtrim(ltrim(ACH_Standard_Entry_Code)), "+
		"rtrim(ltrim(Bank_Account_Payment_Code)), rtrim(ltrim(Saving_Account_Indicator)), "+
		"rtrim(ltrim(Payment_Method)) "+
		"from WNS_TA_APVS_Vendor_Master WITH(NOLOCK) ";

		if (sVendor.contains("%") || sid.contains("%"))		
	 	 {
			sQuery=sQuery+" where   vendor_name  like '"+sVendor+"%' and  vendor_number  like '"+sid+"%' ";
		}
		else if (sVendor.isEmpty())
		{
			 sQuery=sQuery+" where   vendor_name  like ('"+sVendor+"%') and  vendor_number  in ('"+sid+"') ";																										
		}
		 else if (sid.isEmpty())
		 {
			 sQuery=sQuery+" where   vendor_name in ('"+sVendor+"') and  vendor_id  like ('"+sid+"%') ";
		}
		else if (!sid.isEmpty() && !sVendor.isEmpty())
		{
			 sQuery=sQuery+" where   vendor_name in ('"+sVendor+"') and  vendor_id  in ('"+sid+"') ";
		}

			WriteLog("TA_Vendor_Search","sQuery :"+sQuery);
            String inputXML = "<?xml version=\"1.0\"?>" +
							"<WMTestSelect_Input>" +
							"<Option>WFSelectTest_new</Option>" +
							"<sQry>"+sQuery+"</sQry>" +
							"<EngineName>"+sCabname+"</EngineName>"+
							"<NoOfCols>"+strNoOfCols+"</NoOfCols>" +
							"<SessionId>"+sSessionId+"</SessionId>" +
							"</WMTestSelect_Input>";

			sOutputXML = WFCallBroker.execute(inputXML,sJtsIp,iJtsPort,1);
			sOutputXML = ParseResult(sOutputXML);
			WriteLog("TA_Vendor_Search","sOutputXML :"+sOutputXML);

			String RowData[] = sOutputXML.split("~");
			}
		}
		catch(Exception e)
		{
			bError=true;
			
			e.printStackTrace();
		}
	}

%>
<link href="/webtop/css/docstyle.css" rel="stylesheet" type="text/css">
<body onload="fnLoad()">
<FORM name="dataform" method='post'>
	<table border="1" class="TableView">
		<tr width="100%"><td class="EWLabelBlue" id="msgCell" align="center">


<%							if(sOutputXML.equals("")){
							out.println("No Records Found");
							}else{
%>
		</td></tr>
		<tr width=100%>
			<td align="left" class="EWTableContents" width=100%>
			<!--  <DIV STYLE="overflow: auto; width: 100%; height: 200; 
							  border-left: 1px gray solid; border-bottom: 1px gray solid; 
							  padding:0px; margin: 0px"> -->
							  <table id="Matrix_Grid" border='1'>
						
						<%
						// if(!sData.trim().equals(""))
						// {
					  	sOutput="<tr width='100%'> <td class='EWTableContentsText' width='2%'></td> <td width='32%' class='EWTableContentsText'><b>Vendor Name</b></td>"+
		"<td width='32%' class='EWTableContentsText'><b>Vendor Number</b></td> <td width='32%' class='EWTableContentsText'><b>Bank Code Number</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Bank Account Number</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Address Line 1</b></td> <td width='32%' class='EWTableContentsText'><b>Address Line 2</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>City Address Line 3</b></td> <td width='32%' class='EWTableContentsText'><b>Email ID</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Optional Address 1</b></td> <td width='32%' class='EWTableContentsText'><b>Optional Address 2</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>W9 Indicator</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>1099 Code</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Vendor Terms</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Vendor Entity</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Vendor Status</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>State Code</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>State Code Validation</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Postal Code</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Optional Address Use</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Combined/Single Payment</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Tax ID</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>1099 Payee Name</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>1099 Payee Name Indicator</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Bank Account Payment</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Bank Account Name</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Bank Name Line 1</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Bank Name Line 2</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Bank Address Line 1</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Bank Address Line 2</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Bank Address Line 3</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Bank Postal Code</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Vendor Bank Account Reference</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Prenote Switch</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>ACH Standard Entry Code</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Bank Account Payment Code</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Saving Account Indicator</b></td> "+
		"<td width='32%' class='EWTableContentsText'><b>Payment Method</b></td> "+
		"</tr>" ;


				out.println(sOutput); 

				char tild='~';
				char spChar='�';

					String sRowData[]=split(sOutputXML,tild);

				for(int count=0;count<sRowData.length;count++)
				{
					
					char source[] =sRowData[count].toCharArray();
					char destination[]=new char[source.length];

					int y=0;

					for(int x=0;x<source.length;x++)
					{
						
						int q=(int)source[x];
						
						if(163==q)
						{
							destination[y]='~';
							y++;
						}
						else
						{
							destination[y]=source[x];
							y++;

						}

						
					}

					String test=new String(destination);

					String ColData[] = split(test,'~');

					sOutput="<tr width='100%'><td class='TextFieldColorLightDisb' width='5%'><input type='radio' name='BusinessAreaRadio'></td>" ;

					for(int k = 1 ; k <ColData.length;k++)
					{
						if(ColData[k].equals("null") || ColData[k].equals(""))
						{
							ColData[k]="";
						} 
						sOutput = sOutput+"<td nowrap width='32%' class='TextFieldColorLightDisb'>"+ColData[k]+"</td>" ;
					}
					//<td width='32%' class='TextFieldColorLightDisb'>"+ColData[2]+"</td><td width='32%' class='TextFieldColorLightDisb'>"+ColData[3]+"</td><td width='32%' class='TextFieldColorLightDisb'>"+ColData[4]+"</td></tr>";
					out.println(sOutput);
				}
			}
			%>
						   </table>
						  
			<!-- <DIV> -->
			<%!		/*	public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }*/
	%>
			
			</td>
		</tr>
	</table>
	<input type="text" name="Method" style="visibility:hidden">
	<input type="text" name="SearchString" value="<%=sSearchString%>" style="visibility:hidden">
	<input type="text" name="PrevValue" value="<%=sFirstBusinessAreaNo%>" style="visibility:hidden">
	<input type="text" name="NextValue" value="<%=sLastBusinessAreaNo%>" style="visibility:hidden">
</form>
<script>

<%
if(!sSearchString.equals(""))
{
	if(bPrevEnable)
		out.println("window.top.frames['frmInput'].fnEnablePrev();");
	else
		out.println("window.top.frames['frmInput'].fnDisablePrev();");
	if(bNextEnable)
		out.println("window.top.frames['frmInput'].fnEnableNext();");
	else
		out.println("window.top.frames['frmInput'].fnDisableNext();");
}
%>

function fnLoad()
{
	var Matrix_tbl="";
	var Matrix_row="";
	var Matrix_cell="";
}
 



</script>
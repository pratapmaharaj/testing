
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="com.newgen.wfdesktop.util.*" %>
<%@ page import="java.util.*"%>
<%@ page import="java.net.*"%>
<%@ include file="/CustomForms/TA_AP_Custom/AP/customized_TA.process" %> 
<%@ page contentType="text/html;charset=UTF-8"%>
<%@page pageEncoding="UTF-8"%>

<head>
<title>Vendor Details Search</title>
</head>
<%
	
	WriteLog("TA_Vendor_Search","Main:::::::::::::::::Open" );

%>

<FRAMESET ROWS="50%,40%,*" >
	
	<FRAME width="100%" SRC="SearchInput.jsp"  NAME="frmInput" frameborder=no noresize scrolling=NO>
	<FRAME width="100%" SRC="SearchView.jsp" NAME="frmView" frameborder=no noresize scrolling=YES>
	<FRAME width="100%" SRC="SearchBottom.jsp" NAME="frmBottom" frameborder=no noresize scrolling=No>

</FRAMESET>
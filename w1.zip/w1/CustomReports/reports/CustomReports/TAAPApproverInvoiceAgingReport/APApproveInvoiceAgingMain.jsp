

<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="java.lang.String.*"%>
<%@ page import="java.lang.Object"%>
<%@ page import="java.lang.Exception"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<HTML>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<HEAD>
<TITLE>AP Approve Invoice Aging Report</TITLE>
</HEAD>

<FRAMESET ROWS="100%,0%" >
	<FRAME SRC="APApproveInvoiceAging.jsp?ReportName=APPROVAERINVOICEAGING" NAME="frmHeader" frameborder=no noresize scrolling=Yes>
	<FRAME SRC="" NAME="APPROVAERINVOICEAGING" frameborder=no scrolling=no>
	
</FRAMESET>
</html>


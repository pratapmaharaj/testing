
<%@ include file="customized.process" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="java.sql.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>


<HTML>
<HEAD>
<TITLE>AP Approve Invoice Aging Report</TITLE>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>


<body>
<%


	WriteLog("APApproverInvoiceAging"," ::> sInputXML : ");
	
	Connection conn = null;
	Statement st;
	//String connectionUrl =""; 
	boolean empty=true;
	
	String sProcessDefId=null;
	String sProcedureName=null;
	String sColumnHeaders=null;
	String sReportName=null;
	String sFileName=null;
	String sNumberOfColumns=null;
	String sProcedureNameKey=null;
	String sColumnHeadersKey=null;
	String sFileNameKey=null;
	String sNumberOfColumnsKey=null;
	String sHeaderKey=null;
	String sHeaderPresentKey=null;
	String sDBMappedColsKey=null;
	String sHeaderValue=null;
	String sHeaderPresentValue=null;
	String sCabinetName=null;	
	String sDBMappedCols=null;
	String sFieldValuesKey=null;
	String sFieldValues=null;
	String sUserMailID=null;//added by nilesh
	String fileName = "" ;
	String filePath="" ;

	sUserMailID=request.getParameter("UserEmailID");//added by nilesh


	sReportName	=request.getParameter("ReportName");
	sReportName	=sReportName.toUpperCase();
	
WriteLog("APApproverInvoiceAging"," ::> sReportName : "+sReportName);
	sProcedureNameKey=sReportName +"_PROCEDURENAME";
	sColumnHeadersKey=sReportName+"_COLUMNHEADERS";
	sFileNameKey=sReportName+"_FILENAME";
	sNumberOfColumnsKey=sReportName+"_NUMBEROFCOLUMNS";
	sHeaderPresentKey=sReportName+"_HEADERPRESENT";
	sHeaderKey=sReportName+"_HEADER";
	sDBMappedColsKey=sReportName+"_DBMAPPEDCOLS";
	sFieldValuesKey=sReportName+"_FIELDVALUES";
WriteLog("APApproverInvoiceAging"," ::> sColumnHeadersKey : "+sColumnHeadersKey);

		//String sRootPathini=application.getRealPath("")+File.separator+"reports"+File.separator+"GMACReports"+File.separator+"ApprovalProcessApproverInvoiceAgingReport" + File.separator + "reports.ini";
		String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAAPApproverInvoiceAgingReport.ini";	
		

	Properties ini = new Properties();
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("APApproverInvoiceAging","Unable to read APApproverInvoiceAging.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("APApproverInvoiceAging","Unable to close the APApproverInvoiceAging.ini file");
						}
					}
				}
	
	
	WriteLog("APApproverInvoiceAging"," ::> sRootPathini : "+sRootPathini);

	WriteLog("APApproverInvoiceAging"," ::> filePath : "+sReportName+"_FILEPATH");
	filePath = ini.getProperty(sReportName+"_FILEPATH");

	fileName=ini.getProperty(sReportName+"_FILENAME") ;
	sProcessDefId=ini.getProperty("PROCESSDEFID");
	sCabinetName=ini.getProperty("CABINETNAME");

	WriteLog("APApproverInvoiceAging"," ::> sCabinetName : "+sCabinetName);

	sProcedureName=ini.getProperty(sProcedureNameKey);
	sColumnHeaders=ini.getProperty(sColumnHeadersKey);
	sFileName=ini.getProperty(sFileNameKey);
	sNumberOfColumns=ini.getProperty(sNumberOfColumnsKey);
	sHeaderPresentValue=ini.getProperty(sHeaderPresentKey);
	sDBMappedCols=ini.getProperty(sDBMappedColsKey);
	sFieldValues=ini.getProperty(sFieldValuesKey);
	sFieldValues=sFieldValues.replaceAll("#",",");

WriteLog("APApproverInvoiceAging"," ::> sProcedureName : "+sProcedureName);

	/*connectionUrl      =ini.getProperty("ConnectionUrl");
	String dbuserName = ini.getProperty("username");
	String dbpass     = ini.getProperty("password");*/

	
	//connectionUrl = connectionUrl+";"+"databaseName="+sCabinetName+";user="+dbuserName+";password="+dbpass;
	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("APApproverInvoiceAging","sRootPathDBini="+sRootPathDBini);
	
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("APApproverInvoiceAging","Unable to read APApproverInvoiceAging.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("APApproverInvoiceAging","Unable to close the APApproverInvoiceAging.ini file");
						}
					}
				}
	
	String driverName = null;

	String connectionUrl=ini.getProperty("CONNECTIONSTRING");
	driverName = ini.getProperty("DRIVERNAME");	
	CallableStatement callableStatement = null;

	WriteLog("APApproverInvoiceAging"," connectionUrl "+connectionUrl);
	
	if(sHeaderPresentValue.equals("YES")) {
	sHeaderValue=ini.getProperty(sHeaderKey);

}
WriteLog("APApproverInvoiceAging"," ::> sColumnHeaders : "+sColumnHeaders);



	String vnumber=request.getParameter("vnumber");
	String DateRangeFrom=request.getParameter("DateRangeFrom");
	String DateRangeTo=request.getParameter("DateRangeTo");
	String sApproval_decision=request.getParameter("sApproval_decision");
	String Document_Category=request.getParameter("Document_Category");
	String vname=request.getParameter("vname");
	String approver_name=request.getParameter("approver_name");
	WriteLog("APApproverInvoiceAging"," ::> Request----> : &Queue="+vnumber+"&DateRangeFrom="+DateRangeFrom+"&DateRangeTo="+DateRangeTo+"&sApproval_decision="+sApproval_decision+"&Document_Category="+Document_Category+"&vname="+vname+"&approver_name="+approver_name);


	double fPercentage=0;
	String sColumnNamesArr[]=sColumnHeaders.split(",");
	String sDBMappedColsArr[]=sDBMappedCols.split(",");
	String sRowXml="";
	String sFinalColumns[]=sColumnHeaders.split(",");
	for(int i=0;i<sColumnNamesArr.length;i++)
	{
		if(sColumnNamesArr[i].indexOf("~D")!=-1)
			sFinalColumns[i]=sColumnNamesArr[i].substring(0,sColumnNamesArr[i].length()-2);

	}

	boolean bError=false;
	

	String getDBUSERByUserIdSql = "{call "+sProcedureName+"(?,?,?,?,?,?,?,?,?,?,?)}";
	String output = "" ;
	try
	{
			Class.forName(driverName);
			conn = DriverManager.getConnection(connectionUrl);
			callableStatement = conn.prepareCall(getDBUSERByUserIdSql);
			callableStatement.setString(1, DateRangeFrom);
			callableStatement.setString(2, DateRangeTo);
			callableStatement.setString(3, Document_Category);
			callableStatement.setString(4, vname);
			callableStatement.setString(5, vnumber);
			callableStatement.setString(6, approver_name);
			callableStatement.setString(7, sApproval_decision);
			callableStatement.setString(8, sUserMailID);
			callableStatement.setString(9,fileName);
			callableStatement.setString(10,filePath);
			callableStatement.registerOutParameter(11, java.sql.Types.VARCHAR);
			callableStatement.execute();

			output = callableStatement.getString(11);
			WriteLog("APApproverInvoiceAging"," output "+output);
		
	}
	catch(SQLException ignore)
	{
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		bError= true;
		WriteLog("APApproverInvoiceAging"," WFSession Data Fetch Exception:::::: "+ignore.toString());
	}
	finally {
 
	if (callableStatement != null) {
        try {
            callableStatement.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
}

	if(!bError)
	{

		WriteLog("APApproverInvoiceAging"," output:::::: "+output);
		try
		{

			if(output.equals(""))
			{
				bError= true;
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+output+"</b></font><center>");
			}
			else
			{
				
					try
							{
								 if(Integer.parseInt(output) == 0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
								out.println(ig.toString());
												
							}
			}
		}
		
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
			out.println("VendorSetupExceptionReport "+exp.toString());
		}
		
	}	
	
	%>

	
		
			<FORM name="textForm">

			</form>	
		
	
			

<%!
 public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }


%>





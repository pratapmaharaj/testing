<!-- 
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-TA_CM
Module : GMAC-TA_CM
File Name : TAEPEXCEPTIONREPORTMain.jsp
Author :   
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date Change By Change Description (Bug No. (If Any))
(DD/MM/YYYY)
----------------------------------------------------------------------------------------------------
 -->

<HTML>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<HEAD>
<TITLE>TAEP Exception Report</TITLE>
</HEAD>

<FRAMESET ROWS="100%,0%" >
	<FRAME SRC="EPException.jsp" NAME="frmHeader" frameborder=no noresize scrolling=Yes>
	<FRAME SRC="" NAME="TAEPEXCEPTIONREPORT" frameborder=no scrolling=no>
	
</FRAMESET>
</html>


/*
WNS_TCI_Exception_Report 'All~','All~','All~','04/DEC/2013','26/DEC/2013','current_work_step,a.WI_Name,b.ExceptionName,Document_Type,Branch_Location,PO_number,Company_Code,Vendor_Name,Vendor_ID,Document_Number,Document_Amount,Currency,Document_Date,entry_time,b.ActionDatetime,a.Exception_Raising_Comments,b.UserName,1,1,Additional_Comments','test@1234.com','//10.33.192.139/XLS-File/ProcessManager/reports/Gmac report/TCI/','TCI_EXCEOTION_REPORT'
*/

Create PROCEDURE WNS_TCI_Exception_Report
( 
@ClaimantType  VARCHAR(200), 
@ProcessType  VARCHAR(200),
@Exp  VARCHAR(200), 
@DateRangeFrom  VARCHAR(50), 
@DateRangeTo  VARCHAR(50), 
@Fields varchar(8000), 
@EmailID varchar(200),
@FilePath varchar(200),
@FileName varchar(200)
) 
AS 
declare 
	@WhereQuery    varchar(2000), 
	@Query    varchar(5000), 
	@Query1   varchar(5000), 
	@Querysum varchar(5000), 
	@Tables   varchar(200), 
	@ExpReport     varchar(200), 
	@DocumentTypeReport varchar(200), 
	@ProcessTypeReport varchar(200),
	@OrderBy varchar(300),    
	@RowCount varchar(50),  
	@Disp_ExceptionName varchar(100), 
	@Count_Exception varchar(100), 
	@status_temp varchar(8000),
	@dbname varchar(60)

BEGIN  
	Set nocount on  
	set @FileName=@FilePath+'/'+@EmailID+'_'+@FileName+'_'+convert(varchar,getdate(),104)+'.xls' 
	set @WhereQuery='WHERE ' 
	set @ExpReport='' 
	set @DocumentTypeReport='' 
	set @OrderBy=' order by a.WI_Name'  

	print  @FileName

	/*
	if Object_ID('#TCI_Exception_Report_Temp') is not null   
	begin   
		print 'Table dropped'   
		exec('drop table #TCI_Exception_Report_Temp')   
	end

	if Object_ID('#TCISummaryException') is not null   
	begin   
		print 'Table dropped'   
		exec('drop table #TCISummaryException')   
	end
	*/

	Create Table #TCI_Exception_Report_Temp  
	(
		Current_Work_Step   varchar(150),
		WI_Name             varchar(150),
		ExceptionName       varchar(100),
		Owner_ID            varchar(100),
		Printed_Name        varchar(100),
		Claim_Amount        varchar(100), 
		Entry_Time          Datetime,
		ExceptionRaisedDatetime Datetime,
		Exception_Raising_Comments  varchar(250),
		RaisedByUser                varchar(50),
		AgingDays varchar(20),  
		AgingHrs varchar(20) ,   
		Additional_Comments  varchar(250)
	)

	--create temporary summary table 
	Create Table #TCISummaryException 
	( 
	Disp_ExceptionName varchar(100), 
	Count_Exception varchar(100) 
	)

	set @Tables='WNS_TA_EP_EXT_Table a with(nolock) ,EXCEPTIONTABLE b with(nolock) '

	set @WhereQuery=@WhereQuery+' a.WI_Name=b.ProcessInstanceId and b.actionid=''9'' and b.ProcessDefId=''17''' 

	if(rtrim(ltrim(@DateRangeFrom))<>'') 
		SET @DateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@DateRangeFrom,121)))))  
	if(rtrim(ltrim(@DateRangeTo))<>'') 
		SET @DateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@DateRangeTo,121)))))  

	print @DateRangeFrom 

	-- Add Document Type
	if(rtrim(ltrim(@DocumentType))<>'All~') 
	BEGIN 
		--Added to Check for only 1 parameter 
		if(len(@DocumentType)=charindex('~',@DocumentType)) 
		BEGIN 
			set @DocumentTypeReport=ltrim(rtrim(substring(@DocumentType,0,len(@DocumentType)))) 
			set @WhereQuery=@WhereQuery+' AND a.Document_Type='''+@DocumentTypeReport+'''' 
		END 

		--Added to Check for only 1 parameter   
		else 
		BEGIN 
			-----While loop ends 
			while (charindex('~',@DocumentType)>1) 
			BEGIN 
				set @DocumentTypeReport = @DocumentTypeReport + ''''+ltrim(rtrim(SUBSTRING(@DocumentType,1,Charindex('~',@DocumentType)-1)))+''''+',' 
				set @DocumentType=ltrim(rtrim(Substring(@DocumentType,Charindex('~',@DocumentType)+len('~'),len(@DocumentType)))) 
			END 

			set @DocumentTypeReport=substring(@DocumentTypeReport,0,len(@DocumentTypeReport)) 
			set @WhereQuery=@WhereQuery+' AND a.Document_Type in('+@DocumentTypeReport+')' 
		END 
	END 

	print 'After Doc Type '+@WhereQuery
	-- Add Process Type
	if(rtrim(ltrim(@ProcessType))<>'All~') 
	BEGIN 
		--Added to Check for only 1 parameter 
		if(len(@ProcessType)=charindex('~',@ProcessType)) 
		BEGIN 
			set @ProcessTypeReport=ltrim(rtrim(substring(@ProcessType,0,len(@ProcessType)))) 
			set @WhereQuery=@WhereQuery+' AND a.Process_Name='''+@ProcessTypeReport+'''' 
		END 

		--Added to Check for only 1 parameter   
		else 
		BEGIN 
			-----While loop ends 
			while (charindex('~',@ProcessType)>1) 
			BEGIN 
				set @ProcessTypeReport = @ProcessTypeReport + ''''+ltrim(rtrim(SUBSTRING(@ProcessType,1,Charindex('~',@ProcessType)-1)))+''''+',' 
				set @ProcessType=ltrim(rtrim(Substring(@ProcessType,Charindex('~',@ProcessType)+len('~'),len(@ProcessType)))) 
			END 

			set @ProcessTypeReport=substring(@ProcessTypeReport,0,len(@ProcessTypeReport)) 
			set @WhereQuery=@WhereQuery+' AND a.Process_Name in('+@ProcessTypeReport+')' 
		END 
	END 
	else
	begin
		 set @ProcessTypeReport='ALL'
	end

	print 'After Process Type '+@WhereQuery
	if(rtrim(ltrim(@Exp))<>'All~') 
	BEGIN
		print 'Individual Exception '+@Exp 
		--Added to Check for only 1 parameter 
		if(len(@Exp)=charindex('~',@Exp)) 
		BEGIN 
			set @ExpReport=ltrim(rtrim(substring(@Exp,0,len(@Exp))))   
			set @WhereQuery=@WhereQuery+' AND B.ExceptionName='''+@ExpReport+'''' 
		END  
		--Added to Check for only 1 parameter 
		else 
		BEGIN 
			print @Exp 
			while (charindex('~',@Exp)>1) 
			BEGIN 
				set @ExpReport = @ExpReport + ''''+ltrim(rtrim(SUBSTRING(@Exp,1,Charindex('~',@Exp)-1)))+''''+',' 
				set @Exp=ltrim(rtrim(Substring(@Exp,Charindex('~',@Exp)+len('~'),len(@Exp)))) 
			END 
			set @ExpReport=substring(@ExpReport,0,len(@ExpReport)) 

			set @WhereQuery=@WhereQuery+' AND b.ExceptionName in('+@ExpReport+')' 
		END 
 	END 

	print 'After Adding Exception Name '+@WhereQuery

	if(rtrim(ltrim(@DateRangeFrom))<>'' AND rtrim(ltrim(@DateRangeTo))<>'') 
	BEGIN 
		set @WhereQuery=@WhereQuery+' AND b.ActionDatetime between '''+rtrim(ltrim(@DateRangeFrom))+''' AND '''+ rtrim(ltrim(@DateRangeTo))+'''' 
	END 
	print 'After Adding Date Range '+@WhereQuery

	SET @Query=' insert into #EP_Exception_Report_Temp(Current_Work_Step,WI_Name,ExceptionName,Owner_ID,Printed_Name,Entry_Time,ExceptionRaisedDatetime,
									Exception_Raising_Comments,RaisedByUser,AgingDays,AgingHrs,Additional_Comments)'    
	SET @Query1='SELECT '+@Fields+' from '+ @Tables + @WhereQuery + @OrderBy  
	seT  @Query=@Query + @Query1 

	print 'Final SQL '+@Query
	exec(@Query) 

	exec('update #TCI_Exception_Report_Temp set
	AgingHrs = isnull(datediff(hh,ExceptionRaisedDatetime,convert(varchar,getdate(),121)),''0''),
	AgingDays = cast((isnull(datediff(hh,ExceptionRaisedDatetime,convert(varchar,getdate(),121)),''0''))/24.0 as numeric(10,2))')


	SET @Query='insert into #TCISummaryException(Disp_ExceptionName,Count_Exception) '
	SET @Querysum='select case exceptionName when''Exp_Missing_Claim''then ''Exp_Missing_Claim Exception :''when''Exp_Balance_related''then ''Exp_Balance_related Exception:''
	when''Exp_Beneficiary''then ''Exp_Beneficiary Exception:''when''Exp_Cancel''then ''Exp_Cancel Exception :''
	else ''Exception'' end as Disp_exceptionname, count(*) as   
	count_exception from #TCI_Exception_Report_Temp group by exceptionName' 

	set @Query=@Query+@Querysum 
	print 'Exception Count '+@Query
	exec (@Query) 

	/*
	select @RowCount=count(*) from #TCISummaryException with(nolock)
	if(@RowCount=0)     
	Begin
		print 'Drop #TCISummaryException'
		drop table #TCISummaryException     
	End
	*/

	select @RowCount=count(*) from #TCI_Exception_Report_Temp with(nolock) 

	if(@RowCount=0)   
	Begin   
		print 'No Record Found #TCI_Exception_Report_Temp'
		--drop table #TCI_Exception_Report_Temp   
	End   
	else   
	begin  
		print 'Report Records '+@RowCount
		if Object_ID ('TCI_TEMP_AUTOMAIL') is not null   
		BEGIN     
		exec('drop table TCI_TEMP_AUTOMAIL')     
		END

		Exec('Create table TCI_TEMP_AUTOMAIL (Header varchar(8000),ROw_Index int IDENTITY(1,1) PRIMARY KEY)')

		Exec('Insert into TCI_TEMP_AUTOMAIL   
		Select ''<html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>
		<table border=1>                    
   <tr align="left"><td colspan=20 class=headerbold>TCI Exception Report</td></tr>
   <tr align="left"><td colspan=20 class=headerbold> Process : '+@ProcessTypeReport+'</td></tr>
   <tr align="left"><td colspan=20 class=headerbold> From : '+@DateRangeFrom+'</td></tr>                   
   <tr align="left"><td colspan=20 class=headerbold> To : '+@DateRangeTo+'</td></tr>                    
   </table>  <br>   
		<table border=1><tr><td class=headerbold>Current Queue</td>''+
		''<td class=headerbold>WI Name</td>''+
		''<td class=headerbold>Exception Name</td>''+
		''<td class=headerbold>Owner ID</td>''+
		''<td class=headerbold>Print Name</td>''+
		''<td class=headerbold>Claim Amount</td>''+
		''<td class=headerbold>Introduction Date</td>''+
		''<td class=headerbold>Exception Raised Date-Time</td>''+
		''<td class=headerbold>Exception Raised Comments</td>''+
		''<td class=headerbold>Raised By User</td>''+
		''<td class=headerbold>Aging In Days</td>''+
		''<td class=headerbold>Aging In Hrs</td>''+
		''<td class=headerbold>Additional Comments</td>''+
		''<td class=headerbold></td>''+
		+''</tr></font>'' 

		UNION ALL
		Select ''<tr><td align=left style=mso-number-format:\\@>''+ISNULL([Current_Work_Step],'''')+''</td>''+
		''<td align=left style=mso-number-format:\\@>''+ISNULL([WI_Name],'''')+''</td>''+ 
		''<td align=left style=mso-number-format:\\@>''+ISNULL([ExceptionName],'''')+''</td>''+ 
		''<td align=left style=mso-number-format:\\@>''+ISNULL([Owner_ID],'''')+''</td>''+ 
		''<td align=left style=mso-number-format:\\@>''+ISNULL([Printed_Name],'''')+''</td>''+ 
		''<td align=left style=mso-number-format:\\@>''+ISNULL([Claim_Amount],'''')+''</td>''+  
		''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Entry_Time],''''),120)+''</td>''+ 
		''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([ExceptionRaisedDatetime],''''),120)+''</td>''+  
		''<td align=left style=mso-number-format:\\@>''+ISNULL([Exception_Raising_Comments],'''')+''</td>''+ 
		''<td align=left style=mso-number-format:\\@>''+ISNULL([RaisedByUser],'''')+''</td>''+ 
		''<td align=left style=mso-number-format:\\@>''+ISNULL([AgingDays],'''')+''</td>''+ 
		''<td align=left style=mso-number-format:\\@>''+ISNULL([AgingHrs],'''')+''</td>''+ 
		''<td align=left style=mso-number-format:\\@>''+ISNULL([Additional_Comments],'''')+''</td>''
		from #TCI_Exception_Report_Temp') 

		select @status_temp='</tr></table><table><tr><td>&nbsp</td>'+'<td>&nbsp</td></tr>' 

		DECLARE TCISummaryException_Cursor CURSOR FAST_FORWARD FOR  
		Select Disp_ExceptionName,Count_Exception from #TCISummaryException 
		OPEN TCISummaryException_Cursor     
		FETCH NEXT FROM TCISummaryException_Cursor INTO  @Disp_ExceptionName,@Count_Exception   
		WHILE @@FETCH_STATUS = 0 
		Begin 
			select @status_temp=@status_temp+'<tr><td>'+convert(varchar(100),@Disp_ExceptionName)+'</td><td>'+convert(varchar(100),@Count_Exception)+'</td></tr>' 
			FETCH NEXT FROM TCISummaryException_Cursor INTO @Disp_ExceptionName,@Count_Exception 
		End 
 
		close TCISummaryException_Cursor     
		Deallocate TCISummaryException_Cursor  
		select @status_temp=@status_temp+'</table>'   
		exec('insert into TCI_TEMP_AUTOMAIL select '''+@status_temp+'''   ')  

		update TCI_TEMP_AUTOMAIL set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>&nbsp</td>')     
		select @dbname = DB_NAME()
		print @dbname
		SET @Query='Master..xp_Cmdshell ''bcp "select Header FROM '+@dbname+'..TCI_TEMP_AUTOMAIL order by row_index asc " queryout "'+@FileName+'" -c -T'',no_output'   
		exec(@Query)  
		  
		insert into NG_AutoMail_Status values('TCI Exception Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL)  
		 
		--drop table #TCISummaryException 
		--drop table #TCI_Exception_Report_Temp  
		drop table TCI_TEMP_AUTOMAIL  
 
	end     
	 select @RowCount 
END

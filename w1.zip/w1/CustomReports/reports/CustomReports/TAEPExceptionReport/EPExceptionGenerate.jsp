<!-- 
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-TA_CM
Module : GMAC-TA_CM
File Name : TAEPEXCEPTIONREPORTMain.jsp
Author :   
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date Change By Change Description (Bug No. (If Any))
(DD/MM/YYYY)
----------------------------------------------------------------------------------------------------
 -->
<%@ include file="customized.process" %> 
<%@ page import="java.io.*" %>
<%@ page import="java.util.*" %>
<%@ page import="javax.servlet.*"%>
<%@ page import="java.text.DateFormat"%>
<%@ page import="java.text.SimpleDateFormat"%>
<%@ page import="javax.servlet.http.*"%>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>
<%@ page import="java.sql.DriverManager,java.sql.Connection,java.sql.PreparedStatement,java.sql.CallableStatement,java.sql.ResultSet,java.sql.SQLException"%>

<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>

<HTML>
<HEAD>
<TITLE>TAEP Exception Report</TITLE>
</HEAD>
<link href="/processmanager/omniflow/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>

</script>

<body topmargin="0" leftmargin="5" >

<%
	WriteLog("TAEPException Report","Initial");								
	int sProcessDefId      =1;
	String sProcedureName     ="";
	String sColumnHeaders     ="";
	String sReportName        ="";
	String sFileName          ="";
	String sNumberOfColumns   ="";
	String sProcedureNameKey  ="";
	String sColumnHeadersKey  ="";
	String sFileNameKey       ="";
	String sNumberOfColumnsKey="";
	String sHeaderKey         ="";
	String sHeaderPresentKey  ="";
	String sDBMappedColsKey   ="";
	String sHeaderValue       ="";
	String sHeaderPresentValue="";
	String sCabinetName       ="";	
	String sDBMappedCols      ="";
	String sFieldValuesKey    ="";
	String sFieldValues       ="";
	String sUserMailID        ="";
	String sFromDate          =null;
	String sToDate            =null;
		String sFromTime          ="00";
	String sToTime            ="00";
	String sFilePath          = "" ;

    sFromDate = request.getParameter("FromDate");
	sToDate = request.getParameter("ToDate");
	String Queue=request.getParameter("sQueue");

	sReportName	  =request.getParameter("ReportName");
	sUserMailID   =request.getParameter("UserEmailID");
	
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAEPExceptionReport.ini";
	WriteLog("TAEPException Report","sRootPathini="+sRootPathini+",sReportName="+sReportName);								
	
	Properties ini = new Properties();
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("TAEPException Report","Unable to read TAEPException Report.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("TAEPException Report","Unable to close the TAEPException Report.ini file");
						}
					}
				}
	
	
	sProcessDefId=1;
	sCabinetName="omnicab";

	 sProcedureName=sReportName+"_PROCEDURENAME";

	 sFilePath = sReportName+"_FILEPATH";
     sFileNameKey        =sReportName+"_FILENAME";
     sNumberOfColumnsKey =sReportName+"_NUMBEROFCOLUMNS";
	 sFieldValuesKey     =sReportName+"_FIELDVALUES";

    sFieldValues=ini.getProperty(sFieldValuesKey);
	sFieldValues=sFieldValues.replaceAll("#",",");
	
	sFilePath = ini.getProperty(sFilePath) ;
    sFileName        =ini.getProperty(sFileNameKey);
	sNumberOfColumns =ini.getProperty(sNumberOfColumnsKey);
	sProcedureName = ini.getProperty(sProcedureName) ;
		
	String sCabname             = null;
	String sSessionId           = null;
	String sJtsIp               = null;
	String sUserName            = null;
	String sReportProcedureName =null;
	String sReportTableName=null;

	WriteLog("TAEPException Report","sFilePath="+sFilePath);	
	
	Date CurrDate     =new Date();
	DateFormat dt     = new SimpleDateFormat("dd-MMM-yyyy");
	String sCurrdate  =dt.format(CurrDate);

	String sOutputXML   ="";
	String sInputXML    ="";
	String maincode     ="";
	String Totalrec     ="0";
	String sStr_ServerType = null;
	String url = "";
	String Status="";
	double fPercentage=0;
	String sRowXml="";
	
	int iJtsPort = 0;
	
	
	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("TAEPException Report","sRootPathDBini="+sRootPathDBini);								
	
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("TAEPException Report","Unable to read TAEPException Report.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("TAEPException Report","Unable to close the TAEPException Report.ini file");
						}
					}
				}
	

	String conString = null;
	String driverName = null;
	driverName=ini.getProperty("DRIVERNAME");
	conString=ini.getProperty("CONNECTIONSTRING");
	WriteLog("TAEPException Report","driverName="+driverName+",conString="+conString);								
	
	boolean bError=false;
	
	Connection conn=null;
	CallableStatement cs=null;
	ResultSet resultset=null;
	try
	{
		Class.forName(driverName);	
		conn = DriverManager.getConnection(conString);
		
		cs = conn.prepareCall("{?=call "+sProcedureName+"(?,?,?,?,?,?,?)}"); 
		
		WriteLog("TAEPException Report","cs.toString()="+cs.toString());	
		cs.registerOutParameter(1, java.sql.Types.VARCHAR);
		
		cs.setString(2,Queue);
		cs.setString(3,sFromDate);
		cs.setString(4,sToDate);
		cs.setString(5,sFieldValues);
		cs.setString(6,sUserMailID);
		cs.setString(7,sFilePath);
		cs.setString(8,"TA_EP_EXCEPTION_REPORT");
		
		
		WriteLog("TAEPException Report","variables="+cs+"---Queue="+Queue+","+sFromDate+","+sToDate+","+sFieldValues+","+sUserMailID+","+sFilePath);	
		
		
		resultset = cs.executeQuery();
		WriteLog("TAEPException Report","resultset="+resultset);	
		
		while( resultset.next() )
		{
              WriteLog("TAEPException Report","output="+resultset.getString( 1 ));	
			  sOutputXML = resultset.getString(1);
        }
	}
	catch(SQLException ignore)
	{	
		WriteLog("TAEPException Report"," WFSession Data Fetch Exception:::::: "+ignore.toString());
		bError= true;
	}
	finally {
    
    if (resultset != null) {
        try {
            resultset.close();
        } catch (SQLException e) { }
    }
	if (cs != null) {
        try {
            cs.close();
        } catch (SQLException e) {  }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
}
	
	
	if(!bError)
	{
		try
		{
		   if(sOutputXML.equals("NORECORD"))
		   {
			WriteLog("TAEPException Report","no record ");
			bError= true;
			
			%>
			<script>alert("No Records found for the Current Request Criteria.");</script>
			<%
		   }
			else if(sOutputXML.equals("SUCCESS"))
			{
				WriteLog("TAEPException Report","found record");

				%>
				<script>alert("The Report will be delivered to your mailbox shortly");</script>
				<%

			}
			else 
			{
				WriteLog("TAEPException Report","Technical error");

				%>
				<script>alert("Internal Server error. Please logout and try again.\nIf problem persists then contact to the support team.");</script>
				<%

			}

		}
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			WriteLog("TAEPException Report", exp.toString());
			bError= true;
		}

		
	}
	else
	{
	%>
			<script>alert("Internal Server Error.");</script>
	<%
	}
%>	

<FORM name="textForm">
</form>	

</body>

</html>
			
		
				


			
			






<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="com.tcsta.util.PathUtil" %>
<%@ include file="customized.process" %>
<%@ page import="java.sql.*"%>

<HTML>
<HEAD>
<TITLE>AP ES Scan Recon Report</TITLE>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>

</script>


<body>

<%!

 public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }


%>

<%

    Connection conn = null;
	Statement st;
	
	boolean empty=true;

	String sProcedureName=null;
	String sColumnHeaders=null;
	String sReportName=null;
	String sFileName=null;
	String sNumberOfColumns=null;
	String sProcedureNameKey=null;
	String sColumnHeadersKey=null;
	String sFileNameKey=null;
	String sNumberOfColumnsKey=null;
	String sHeaderKey=null;
	String sHeaderPresentKey=null;
	String sDBMappedColsKey=null;
	String sHeaderValue=null;
	String sHeaderPresentValue=null;
	String sCabinetName=null;	
	String sDBMappedCols=null;
	String sFieldValuesKey=null;
	String sFieldValues=null;
	String sFieldValuesReport="";
	String sUserMailID=null;
	String sFileNamePathKey="";
	String sFilePath="";
	

	sReportName	=request.getParameter("ReportName");
	sReportName	=sReportName.toUpperCase();
	sUserMailID=request.getParameter("UserEmailID");
	sProcedureNameKey=sReportName +"_PROCEDURENAME";
	sColumnHeadersKey=sReportName+"_COLUMNHEADERS";
	sFileNameKey=sReportName+"_FILENAME";
	sFileNamePathKey=sReportName+"_FILEPATH";
	sNumberOfColumnsKey=sReportName+"_NUMBEROFCOLUMNS";
	sHeaderPresentKey=sReportName+"_HEADERPRESENT";
	sHeaderKey=sReportName+"_HEADER";
	sDBMappedColsKey=sReportName+"_DBMAPPEDCOLS";
	sFieldValuesKey=sReportName+"_FIELDVALUES";

	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAESScanReconReport.ini";
	

	Properties ini = new Properties();
	//Unreleased dataresource release fix
	FileInputStream fis = null;
		try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("ES Scan Recon Report","Unable to read TAESScanReconReport.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("ES Scan Recon Report","Unable to close the TAESScanReconReport.ini file");
						}
					}
				}
	//ini.load(new FileInputStream(sRootPathini));

    sCabinetName=ini.getProperty("CABINETNAME");
	sProcedureName     =ini.getProperty(sProcedureNameKey);
	sColumnHeaders     =ini.getProperty(sColumnHeadersKey);
	sFileName          =ini.getProperty(sFileNameKey);
	sNumberOfColumns   =ini.getProperty(sNumberOfColumnsKey);
	sHeaderPresentValue=ini.getProperty(sHeaderPresentKey);
	sDBMappedCols      =ini.getProperty(sDBMappedColsKey);
	sFieldValues       =ini.getProperty(sFieldValuesKey);
	sFilePath		   =ini.getProperty(sFileNamePathKey);
	
	
	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("ES Scan Recon Report","sRootPathDBini="+sRootPathDBini);
	//Unreleased dataresource release fix
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("ES Scan Recon Report","Unable to DBReports.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("ES Scan Recon Report","DBReports.ini file");
						}
					}
				}
	//ini.load(new FileInputStream(sRootPathDBini));
	String driverName = null;

	String connectionUrl=ini.getProperty("CONNECTIONSTRING");
	driverName = ini.getProperty("DRIVERNAME");
	CallableStatement callableStatement = null;

	WriteLog("ES Scan Recon Report"," output "+connectionUrl);

	if(sHeaderPresentValue.equals("YES")) 
	{
		sHeaderValue=ini.getProperty(sHeaderKey);
	}

	//String sDocumentCategoryType=request.getParameter("DocumentCategoryType");
	//String sVendorName=request.getParameter("VendorName");
	String sFromDate    =request.getParameter("DateRangeFrom");
	String sToDate      =request.getParameter("DateRangeTo");

	String sOutputXML ="";
	String sInputXML  ="";
	String maincode   ="";
	String Totalrec   ="0";
	String 	sStr_ServerType="";

	String url         ="";
	String Status      ="";
	String sInputXml   ="";
	double fPercentage =0;
	String 	sReturnValue="";
	String sColumnNamesArr[]=split(sColumnHeaders,',');
	String sFinalColumns[]=split(sColumnHeaders,',');
	String sDBMappedColsArr[]=split(sDBMappedCols,',');
	for(int i=0;i<sColumnNamesArr.length;i++)
	{
		if(sColumnNamesArr[i].indexOf("~D")!=-1)
			sFinalColumns[i]=sColumnNamesArr[i].substring(0,sColumnNamesArr[i].length()-2);

	}
		String sFieldNamesDB[]=split(sFieldValues,'#');

		for(int i=0;i<sFieldNamesDB.length;i++)
		{
			sFieldValuesReport=sFieldValuesReport+sFieldNamesDB[i]+',';
		}
	sFieldValuesReport =sFieldValuesReport.substring(0,sFieldValuesReport.length()-1);
	String sRowXml="";
	int iJtsPort = 0;
	boolean bError=false;

	WriteLog("ES Scan Recon Report"," output "+sProcedureName);
	
	String getDBUSERByUserIdSql = "{call "+sProcedureName+"(?,?,?,?,?,?,?)}";
	String output = "" ;
	try
	{
		//WriteLog("ES Scan Recon Report"," sDocumentCategoryType "+sDocumentCategoryType);
		//WriteLog("ES Scan Recon Report"," sVendorName "+sVendorName);
		WriteLog("ES Scan Recon Report"," sFromDate "+sFromDate);
		WriteLog("ES Scan Recon Report"," sToDate "+sToDate);
		WriteLog("ES Scan Recon Report"," sFieldValuesReport "+sFieldValuesReport);
		WriteLog("ES Scan Recon Report"," sUserMailID "+sUserMailID);

			Class.forName(driverName);
			conn = DriverManager.getConnection(connectionUrl);
			callableStatement = conn.prepareCall(getDBUSERByUserIdSql);
			callableStatement.setString(1, sFromDate);
			callableStatement.setString(2, sToDate);
			callableStatement.setString(3, sFieldValuesReport);
			callableStatement.setString(4, sUserMailID);
			callableStatement.setString(5, sFilePath);
			callableStatement.setString(6, sFileName);
			callableStatement.registerOutParameter(7, java.sql.Types.VARCHAR);
			callableStatement.execute();

			output = callableStatement.getString(7);
			WriteLog("ES Scan Recon Report"," output "+output);
	}
	catch(SQLException ignore)
	{
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		bError= true;
		WriteLog("ES Scan Recon Report"," WFSession Data Fetch Exception:::::: "+ignore.toString());
	}
	finally {
 
	if (callableStatement != null) {
        try {
            callableStatement.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
	}


	if(!bError)
	{

		WriteLog("ES Scan Recon Report"," output:::::: "+output);
		try
		{

			if(output.equals(""))
			{
				bError= true;
				//maincode=sOutputXML.substring(sOutputXML.indexOf("<MainCode>")+10 , sOutputXML.indexOf("</MainCode>"));
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+output+"</b></font><center>");
			}
			else
			{
				
					try
							{
								 if(Integer.parseInt(output) == 0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
								out.println(ig.toString());
												
							}
			}
		}
		
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
			log("ES Scan Recon Report Exception : "+exp.toString());
		}
		
	}

%>

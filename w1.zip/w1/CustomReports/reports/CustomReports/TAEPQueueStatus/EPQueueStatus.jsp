<!-- 
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-TCI
Module : TCI
File Name : TCIQueueStatus.jsp
Author :   
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date Change By Change Description (Bug No. (If Any))
(DD/MM/YYYY)

----------------------------------------------------------------------------------------------------
 -->

<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>


<HTML>
<HEAD>
<TITLE>TA EP Report</TITLE>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>
<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
}
</style>
<script>
	$(document).ready(function(){$('#From_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	
	});
	var allWindows = new Array();
	var win; // new window object

	/*functions echeck,ValidateForm added by nilesh*/
	function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}
//---Added by Chetan
function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";

	sDate	= window.showModalDialog('/webdesktop/CustomForms/reports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');




	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
}

function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	//strResult=strdate+"/"+strMonth+"/"+stryear;
	strResult=strtempdate+"/"+strdate+"/"+stryear;
	return strResult;
}

function convertMonth(strMonth)
{
		if(strMonth=="JAN")
			strMonth="00";
		else if(strMonth=="FEB")
			strMonth="01";
		else if(strMonth=="MAR")
			strMonth="02";
		else if(strMonth=="APR")
			strMonth="03";
		else if(strMonth=="MAY")
			strMonth="04";
		else if(strMonth=="JUN")
			strMonth="05";
		else if(strMonth=="JUL")
			strMonth="06";
		else if(strMonth=="AUG")
			strMonth="07";
		else if(strMonth=="SEP")
			strMonth="08";
		else if(strMonth=="OCT")
			strMonth="09";
		else if(strMonth=="NOV")
			strMonth="10";
		else if(strMonth=="DEC")
			strMonth="11";
	return strMonth;
}
function convertMonth1(strMonth)
{
		if(strMonth=="01")
			strMonth="JAN";
		else if(strMonth=="02")
			strMonth="FEB";
		else if(strMonth=="03")
			strMonth="MAR";
		else if(strMonth=="04")
			strMonth="APR";
		else if(strMonth=="05")
			strMonth="MAY";
		else if(strMonth=="06")
			strMonth="JUN";
		else if(strMonth=="07")
			strMonth="JUL";
		else if(strMonth=="08")
			strMonth="AUG";
		else if(strMonth=="09")
			strMonth="SEP";
		else if(strMonth=="10")
			strMonth="OCT";
		else if(strMonth=="11")
			strMonth="NOV";
		else if(strMonth=="12")
			strMonth="DEC";
	return strMonth;
}

function DateComparator(Date_To,Date_From)
	{	
			if (Date_From == "" && Date_To == "")
			{
				return true;
			}

			var FromDay = Date_From.split("/")[0];
			var FromMonth = convertMonth(Date_From.split("/")[1]);
			var FromYear = Date_From.split("/")[2];
			
			
			
			var ToDay = Date_To.split("/")[0];
			var ToMonth = convertMonth(Date_To.split("/")[1]);
			var ToYear = Date_To.split("/")[2];
			
			
			
			var CurrentDate=new Date();
			var CurrentDay = CurrentDate.getDate();
			var CurrentMonth = CurrentDate.getMonth();
			var CurrentYear = CurrentDate.getFullYear();
			

			var toDate = (new Date(ToYear,ToMonth,ToDay)).getTime();
			var fromDate = (new Date(FromYear,FromMonth,FromDay)).getTime();
			var CurrentDate = (new Date(CurrentYear,CurrentMonth,CurrentDay)).getTime();
			
			
			if(fromDate > toDate)
			{
				alert("To Date cannot be less than From Date.");
				return false;
			}
			else if(fromDate > CurrentDate)
			{
				alert("From Date cannot be future date.");
				return false;
			}
			else if(toDate > CurrentDate)
			{
				alert("To Date cannot be future date.");
				return false;
			}
			
			return true;
	
	}
//--------------------------------------------

function ValidateForm(emailID){
//	var emailID=document.frmSample.txtEmail
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }
	
	function openreport()
	{			
		
		//var ClaimantType=document.forms["textForm"].Claimant_Type.value;
		var sQueue="";
		//var ClaimantType="";
		var bQueueSelected=false;
		//var bClaimantType=false;
		var UserEmailID=document.getElementById('EMail-ID').value;//added by nilesh
		// Added by Chetan------
		var DateRangeFrom="";
		var DateRangeTo="";

		
		DateRangeFrom=document.forms["textForm"].From_Date.value;
		DateRangeTo=document.forms["textForm"].To_Date.value;

		var sdatecon=DateRangeFrom.split('/');
		var sMonth=convertMonth1(sdatecon[0]);
		var sDay=sdatecon[1];
		var sYear=sdatecon[2];
		DateRangeFrom=sDay+"/"+sMonth+"/"+sYear;
		
		var stodatecon=DateRangeTo.split('/');
		var sMonth1=convertMonth1(stodatecon[0]);
		var sDay1=stodatecon[1];
		var sYear1=stodatecon[2];
		
		DateRangeTo=sDay1+"/"+sMonth1+"/"+sYear1;
		
		
		if(document.forms["textForm"].From_Date.value=='')
		{
			DateRangeFrom='';
		}
		if(document.forms["textForm"].To_Date.value=='')
		{
			DateRangeTo='';
		}
		//---------------------------------------
		//----Added by Chetan-------
		//-------------------------
	/*	for(var i=0;i<document.forms["textForm"].Claimant_Type.length;i++)
				{
					if(document.forms["textForm"].Claimant_Type[i].selected)
					{
					ClaimantType=ClaimantType+document.forms["textForm"].Claimant_Type[i].value+'~';
					bClaimantType=true;
					}

				}
	*/	
		for(var i=0;i<document.forms["textForm"].Queue.length;i++)
				{
					if(document.forms["textForm"].Queue[i].selected)
					{
					sQueue=sQueue+document.forms["textForm"].Queue[i].value+'~';
					bQueueSelected=true;
					}

				}
			var sTestQueue=sQueue.split('~');
		//	var sTestClaimType=ClaimantType.split('~');

		//---------------------------------------------------
		
		
		
	/*	if(!bClaimantType)
		{
			alert("Please Select Claimant Type.");
			return false;
		}
	*/	
		if(!bQueueSelected)
		{
			alert("Please Select Queue.");
			return false;
		}
		
	/*	if(ClaimantType.indexOf("All")!=-1 && sTestClaimType.length>2)
		{
			alert("No other Document Catagory can be chosen after choosing All");
			return false;
			//ClaimantType='All~';
		} 
     */
		if(sQueue.indexOf("All")!=-1 && sTestQueue.length>2)
		{
			alert("No other Queue Name can be chosen after choosing All");
			return false;
			//sQueue='All~';

		}
	/*	if(ClaimantType=='Customer~Non_Customer~')
		{
			ClaimantType='All~';
		}
    */
		if(sQueue=='Introduction~Processing~Cancel~PendingApproval~InProgress~')
		{
			sQueue='All~';
		}
	    //--Added by Chetan
		if(!bQueueSelected)
		{
			alert("Please select a Queue.");
			return false;
		
		}
		//------------------------------------------

		//added by nilesh for validation of emails

       if (DateRangeFrom=='') 
		   {
			alert("Enter the from Date Range.");
			return false;
		    }

		

		if ((DateRangeFrom=='' && DateRangeTo!='') || (DateRangeFrom!='' && DateRangeTo==''))
		{
			alert("Enter the complete Date Range.");
			return false;
		}
		

		if(!DateComparator(DateRangeTo,DateRangeFrom))
		{
			return false;
		}




		if(UserEmailID=='')
		{
			alert("Kindly enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
				
			}
		}
		

       if((UserEmailID!='')&&(DateRangeTo!="")&&(DateRangeFrom!="")&&(sQueue!="") )
			{	
			var ReportName="QUEUESTATUS";
			//window.top.QUEUESTATUS.location.href="EPQueueStatusGenerate.jsp?sQueue="+sQueue+"&ReportName="+ReportName+"&FromDate="+DateRangeFrom+"&ToDate="+DateRangeTo+"&UserEmailID="+UserEmailID;
			
			//OpenRedict-Fix
    //window.top.TAEPQUEUESTATUSREPORT.location.href="EPQueueStatusGenerate.jsp?sQueue="+sQueue+"&ReportName=TAEPQUEUESTATUSREPORT&FromDate="+DateRangeFrom+"&ToDate="+DateRangeTo+"&UserEmailID="+UserEmailID;
	var URI = "EPQueueStatusGenerate.jsp?sQueue="+sQueue+"&ReportName=TAEPQUEUESTATUSREPORT&FromDate="+DateRangeFrom+"&ToDate="+DateRangeTo+"&UserEmailID="+UserEmailID;
	var StrOpenWin=strip_tags(URI,"");
	window.top.TAEPQUEUESTATUSREPORT.location.href=StrOpenWin;
			
			
			}
		
  }

	
	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}

</script>

<body topmargin="0" leftmargin="5" onunload="UnloadReportWindow();">

			<form name='textForm' method=post>


			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">TA EP QUEUE STATUS REPORT</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This report will show the number of un processed work items in the selected queue along with other Indexing details. The Report will provide the current information only. It is not possible to retrive the status in a future date/time. Process Owner / Supervisor can save the generated report for their future references.
</td></tr><tr><td class="EWLabel1">Select All Queues if report is to be generated for viewing the workitems present across different worksteps, else select the specific Queue, multiple selections are again acceptable.
</td></tr>
				
			</table>

		

			<table border="0" width="95%" cellspacing="1" align="center">
			
				 <tr>
					<td class="EWLabel1" align="left" width='20%'><b>Queue</b></td>
					<td width='25%' colspan=3>
					<select name="Queue" multiple>
					<option value="All">All</option>
					<option value="Introduction">Introduction</option>
					<option value="Processing">Processing</option>
					<option value="Cancel">Cancel WI</option>
					<option value="PendingApproval">Pending Approval</option>
					<option value="InProgress">InProgress</option>
					<option value="Exit">Exit</option>
					</select>
					</td>
				</tr>
                <!-- Added by Chetan for displaying Date range from and to field...-->
				<tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>Date Range &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date" readonly type="text"  id="From_Date" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date" readonly type="text"  id="To_Date" >
					
					</td>

				</tr>
				<!-- --------------------------------------------------- -->
				<!--added by nilesh for displaying Emaild field -->

				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID*</b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>
				 
				 
				

				
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>
	
			
			</form>
</body>
</Html>	 




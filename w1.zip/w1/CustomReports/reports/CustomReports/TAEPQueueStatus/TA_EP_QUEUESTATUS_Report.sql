/*
  WNS_TCI_QUEUESTATUS_Report 'ALL~','ALL~','ALL~','Current_Work_Step,a.WI_Name,Introduction_Type,Registration_Date,Scan_Image_File_Name,Document_Type,Priority,Branch_Location,Company_Code,Vendor_Name,Vendor_ID,Employee_Name,Employee_ID,Document_Number,Document_Amount,Currency,Document_Date,Additional_Comments,Entry_Time','01/DEC/2011','23/DEC/2013','test@testing.com','//10.33.192.139/XLS-File/ProcessManager/reports/Gmac report/TCI/','Queue_Status_Report'

SELECT Current_Work_Step,a.WI_Name,Introduction_Type,Registration_Date,Scan_Image_File_Name,Document_Type,Priority,Branch_Location,Company_Code,Vendor_Name,Vendor_ID,Employee_Name,Employee_ID,Document_Number,Document_Amount,Currency,Document_Date,Additional_Comments,Entry_Time from WNS_TCI_AP_EXT_Table a with(nolock)  
WHERE  Current_Work_Step<>'Null' 
and Entry_Time BETWEEN 'Dec  4 2011 12:00AM' AND 'Dec 23 2013 11:59PM' 
order by Current_Work_Step,a.Wi_Name 
 
*/

CREATE PROCEDURE WNS_TCI_QUEUESTATUS_Report
(
@DocumentType   VARCHAR(50),
@ProcessType    VARCHAR(50),
@QueueName      VARCHAR(255),
@Fields         varchar(8000),
@DateRangeFrom  VARCHAR(50),
@DateRangeTo    VARCHAR(50),
@EmailID        varchar(200),
@FilePath       varchar(200),
@FileName       varchar(200)
)
AS
	declare
	@WhereQuery varchar(2000),
	@Query varchar(5000),
	@Tables varchar(200),
	@BkpTable varchar(200),
	@QueueNameReport varchar(200),
	@DocumentReport varchar(200), 
	@ProcessReport varchar(200), 
	@EntryExitDetails varchar(8000),
	@RowCount varchar(50),
	@Disp_QName varchar(100), 
	@Count_Q varchar(100),
	@status_temp varchar(8000),
	@dbname varchar(60)

BEGIN
	Set nocount on 
	set @FileName=@FilePath+'/'+@EmailID+'_'+@FileName+'_'+convert(varchar,getdate(),104)+'.xls'            
	set @WhereQuery='WHERE '
	set @Tables='WNS_TCI_AP_EXT_Table a with(nolock) '       
	set @QueueNameReport=''
	SET @DocumentReport=''
	SET @ProcessReport=''
--print @DocumentType

	--if Object_ID('#TCI_Queuestatus_Report_Temp') is not null
	--begin
	--print 'Table dropped'
	--	exec('drop table #TCI_Queuestatus_Report_Temp')
	--end  
	 
	Create Table #TCI_Queuestatus_Report_Temp 
	( 
		Current_Work_Step  varchar(100),
		WI_Name           varchar(150),
		Introduction_Type varchar(100),
		Registration_Date datetime,
		Scan_Image_File_Name   varchar(255), 
		Document_Type          varchar(100),
		Priority               varchar(20),
		Branch_Location        varchar(200),
		Company_Code           varchar(50),
		Vendor_Name            varchar(100),
		Vendor_ID              varchar(100),
		emp_name               varchar(60),
		emp_id                 varchar(20),
		Document_Number        varchar(100),
		Document_Amount        varchar(25),
		Currency               varchar(25),
		Document_Date          datetime,
		Additional_Comments    varchar(100),
		wi_EntryTime     datetime 
	) 

	--if Object_ID('#TCIQSummaryException') is not null   
	--begin   
	--	print 'Summary Table dropped'   
	--	exec('drop table #TCIQSummaryException')   
	--end
	--create temporary summary table 
	Create Table #TCIQSummaryException 
	( 
		Disp_QName varchar(100), 
		Count_Q varchar(100) 
	)

	if(rtrim(ltrim(@DocumentType))<>'All~')
	BEGIN
		if(len(@DocumentType)=charindex('~',@DocumentType))
		BEGIN               
			set @DocumentReport=ltrim(rtrim(substring(@DocumentType,0,len(@DocumentType))))
			print @DocumentReport
			set @WhereQuery=@WhereQuery+' Document_Type ='''+@DocumentReport+''''
		End
		else
		BEGIN         
			while (charindex('~',@DocumentType)>1)
			BEGIN
				set @DocumentReport = @DocumentReport + ''''+ltrim(rtrim(SUBSTRING(@DocumentType,1,Charindex('~',@DocumentType)-1)))+''''+','
				set @DocumentType=ltrim(rtrim(Substring(@DocumentType,Charindex('~',@DocumentType)+len('~'),len(@DocumentType))))
			END                           
			set @DocumentReport=SUBSTRING(@DocumentReport,0,len(@DocumentReport)) 
			set @WhereQuery=@WhereQuery+' Document_Type in('+@DocumentReport+')'   
		END

		--PRINT @WhereQuery
		SET @WhereQuery=@WhereQuery + ' and '
	END

	if(rtrim(ltrim(@ProcessType))<>'All~')
	BEGIN
		if(len(@ProcessType)=charindex('~',@ProcessType))
		BEGIN               
			set @ProcessReport=ltrim(rtrim(substring(@ProcessType,0,len(@ProcessType))))
			print @ProcessReport
			set @WhereQuery=@WhereQuery+' Process_name ='''+@ProcessReport+''''
		End
		else
		BEGIN
			while (charindex('~',@ProcessType)>1)
			BEGIN
				set @ProcessReport = @ProcessReport + ''''+ltrim(rtrim(SUBSTRING(@ProcessType,1,Charindex('~',@ProcessType)-1)))+''''+','
				set @ProcessType=ltrim(rtrim(Substring(@ProcessType,Charindex('~',@ProcessType)+len('~'),len(@ProcessType))))
			END                           
			set @ProcessReport=SUBSTRING(@ProcessReport,0,len(@ProcessReport)) 
			set @WhereQuery=@WhereQuery+' Process_name in('+@ProcessReport+')'   
		END
		--PRINT @WhereQuery
		SET @WhereQuery=@WhereQuery + ' and '         
	END
	else
	begin
		set @ProcessReport = 'ALL'
	end

	if(rtrim(ltrim(@QueueName))<>'All~')
	BEGIN
		--print 'in not all'+@QueueName
		while (charindex('~',@QueueName)>1)
		BEGIN
			set @QueueNameReport = @QueueNameReport + ''''+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+''''+','
			set @QueueName=ltrim(rtrim(Substring(@QueueName,Charindex('~',@QueueName)+len('~'),len(@QueueName))))
		END

		set @QueueNameReport=SUBSTRING(@QueueNameReport,0,len(@QueueNameReport))
		set @WhereQuery=@WhereQuery+' Current_Work_Step in('+@QueueNameReport+')'

		print @WhereQuery
	END
     
	Else
	BEGIN 
		set @WhereQuery=@WhereQuery+' Current_Work_Step<>''Null'''        
		print @WhereQuery
	End
	print @queuename
--if(rtrim(ltrim(@QueueName))='All')
 --BEGIN  
--Added by chetan for date range

	if(rtrim(ltrim(@DateRangeFrom))<>'')
		SET @DateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@DateRangeFrom,121)))))                       

	if(rtrim(ltrim(@DateRangeTo))<>'')
		SET @DateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@DateRangeTo,121)))))                  

	if(rtrim(ltrim(@DateRangeFrom)) != '' and rtrim(ltrim(@DateRangeTo)) != '')             
	BEGIN
		set @WhereQuery = @WhereQuery+' and Entry_Time BETWEEN '''+@DateRangeFrom+''' AND '''+@DateRangeTo+''''
	END
------------------------------------------

	Set @Query='insert into #TCI_Queuestatus_Report_Temp(Current_Work_Step,WI_Name,Introduction_Type,Registration_Date,Scan_Image_File_Name,Document_Type,Priority,Branch_Location,Company_Code,Vendor_Name,Vendor_ID,emp_name,emp_id,
				Document_Number,Document_Amount,Currency,Document_Date,Additional_Comments,wi_EntryTime) '            
	SET @Query=@Query+' SELECT '+@Fields+' from '+ @Tables + ' '+@WhereQuery + ' order by Current_Work_Step,a.Wi_Name '       
     
	print (@Query)
	exec(@Query) 

	--Create summary
	SET @Query='insert into #TCIQSummaryException(Disp_QName,Count_Q) '
	SET @Query=@Query+' select case Current_Work_Step 
	when''Introduction''then ''Introduction :''when''Processing''then ''Processing :''
	when''Pending Resolution''then ''Pending Resolution :''when''Cancel''then ''Cancel :
	''when''Pending Approval''then ''Pending Approval :''when''QC''then ''QC :
	''when''SAP update''then ''SAP update 
	:''when''Verifier Validation''then ''Verifier Validation :''
	when''Authorization''then ''Authorization :'' when ''Batch Correction''then ''Batch Correction :''
	else ''Queue Name :'' end as Disp_Qname, count(*) as   
	count_Q from #TCI_Queuestatus_Report_Temp group by Current_Work_Step' 

	--set @Query=@Query+@Querysum 
	print 'Exception Count '+@Query
	exec (@Query) 
	select @RowCount=count(*) from #TCIQSummaryException with(nolock)     

	--if(@RowCount=0)     
	--Begin
	--	print 'Drop #TCIQSummaryException'
	--	drop table #TCIQSummaryException     
	--End

	select @RowCount=count(*) from #TCI_Queuestatus_Report_Temp with(nolock)         

	if(@RowCount=0)         
	Begin         
		drop table #TCI_Queuestatus_Report_Temp         
	End
	else
	begin 
		if Object_ID ('TCI_TEMP_AUTOMAIL_Q') is not null    
		BEGIN    
			exec('drop table TCI_TEMP_AUTOMAIL_Q')
		END              

		Exec('Create table TCI_TEMP_AUTOMAIL_Q (Header varchar(8000),ROw_Index int IDENTITY(1,1) PRIMARY KEY)')

   set @Query='Insert into TCI_TEMP_AUTOMAIL_Q 
			Select ''<html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>      

			<table border=1>
			<tr align="left"><td colspan=19 class=headerbold>TCI QUEUE STATUS REPORT</td></tr>
			<tr align="left"><td colspan=19 class=headerbold> Process : '+@ProcessReport+'</td></tr>
			<tr align="left"><td colspan=19 class=headerbold> From : '+@DateRangeFrom+'</td></tr>
			<tr align="left"><td colspan=19 class=headerbold> To : '+@DateRangeTo+'</td></tr>
			</table>  <br>   
			<table border=1><tr><td class=headerbold>Current Queue</td>''+    
			''<td class=headerbold>WI Name</td>''+
			''<td class=headerbold>Introduction Type</td>''+
			''<td class=headerbold>Registration Date</td>''+
			''<td class=headerbold>Scan Image Name</td>''+
			''<td class=headerbold>Document category</td>''+
			''<td class=headerbold>Priority</td>''+
			''<td class=headerbold>Branch/location</td>''+
			''<td class=headerbold>Company Code</td>''+
			''<td class=headerbold>Vendor Name</td>''+
			''<td class=headerbold>Vendor ID</td>''+
			''<td class=headerbold>Employee Name</td>''+
			''<td class=headerbold>Employee ID</td>''+
			''<td class=headerbold>Document Number</td>''+
			''<td class=headerbold>Document Amount</td>''+
			''<td class=headerbold>Currency</td>''+
			''<td class=headerbold>Document Date</td>''+
			''<td class=headerbold>Additional Comments</td>''+
			''<td class=headerbold> Queue Entry Date</td>''
			+''</tr></font>''
			UNION ALL    

			Select ''<tr><td align=left style=mso-number-format:\\@>''+ISNULL([Current_Work_Step],'''')+''</td>''+    
			''<td align=left style=mso-number-format:\\@>''+ISNULL([Wi_Name],'''')+''</td>''+    
			''<td align=left style=mso-number-format:\\@>''+ISNULL([Introduction_Type],'''')+''</td>''+   
			''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Registration_Date],''''),120)+''</td>''+ 
			''<td align=left style=mso-number-format:\\@>''+ISNULL([Scan_Image_File_Name],'''')+''</td>''+   
			''<td align=left style=mso-number-format:\\@>''+ISNULL([Document_Type],'''')+''</td>'' +    
			''<td align=left style=mso-number-format:\\@>''+ISNULL([Priority],'''')+''</td>'' + 
			''<td align=left style=mso-number-format:\\@>''+ISNULL([Branch_Location],'''')+''</td>'' + 
			''<td align=left style=mso-number-format:\\@>''+ISNULL([Company_Code],'''')+''</td>'' + 
			''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Name],'''')+''</td>'' + 
			''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_ID],'''')+''</td>'' + 
			''<td align=left style=mso-number-format:\\@>''+ISNULL([emp_name],'''')+''</td>'' + 
			''<td align=left style=mso-number-format:\\@>''+ISNULL([emp_id],'''')+''</td>'' + 
			''<td align=left style=mso-number-format:\\@>''+ISNULL([Document_Number],'''')+''</td>'' + 
			''<td align=left style=mso-number-format:\\@>''+ISNULL([Document_Amount],'''')+''</td>'' + 
			''<td align=left style=mso-number-format:\\@>''+ISNULL([Currency],'''')+''</td>'' + 
			''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Document_Date],''''),120)+''</td>''+ 
			''<td align=left style=mso-number-format:\\@>''+ISNULL([Additional_Comments],'''')+''</td>'' + 
			''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([wi_EntryTime],''''),120)+''</td>''
			from #TCI_Queuestatus_Report_Temp'

print @Query
Exec(@Query)    

		select @status_temp='</tr></table><table><tr><td>&nbsp</td>'+'<td>&nbsp</td></tr>' 

		DECLARE TCISummaryException_Cursor CURSOR FAST_FORWARD FOR  
		Select Disp_QName,Count_Q from #TCIQSummaryException 
		OPEN TCISummaryException_Cursor     
		FETCH NEXT FROM TCISummaryException_Cursor INTO  @Disp_QName,@Count_Q   
		WHILE @@FETCH_STATUS = 0 
		Begin 
			select @status_temp=@status_temp+'<tr><td align=left style=mso-number-format:\\@>'+convert(varchar(100),@Disp_QName)+'</td><td align=left style=mso-number-format:\\@>'+convert(varchar(100),@Count_Q)+'</td></tr>' 
			FETCH NEXT FROM TCISummaryException_Cursor INTO @Disp_QName,@Count_Q 
		End 
 
		close TCISummaryException_Cursor     
		Deallocate TCISummaryException_Cursor  
   
--print @status_temp
		select @status_temp=@status_temp+'</table>'
		exec('insert into TCI_TEMP_AUTOMAIL_Q select '''+@status_temp+'''   ')  

		update TCI_TEMP_AUTOMAIL_Q set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yy>&nbsp</td>')     		

		select @dbname = DB_NAME()
		SET @Query='Master..xp_Cmdshell ''bcp "select Header FROM '+@dbname+'..TCI_TEMP_AUTOMAIL_Q order by row_index asc " queryout "'+@FileName+'" -c -T'', no_output  '  

		exec(@Query)
		insert into NG_AutoMail_Status values('TCI Queue Status Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL) 
 
		--drop table #TCIQSummaryException 
		--drop table #TCI_Queuestatus_Report_Temp 
		drop table TCI_TEMP_AUTOMAIL_Q 

	end
	select @RowCount
End 


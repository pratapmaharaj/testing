<!-- 
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-GMAC
Module : GMAC-PLMIC
File Name : PLMICAgingGenerate.jsp
Author :   Tarit Gupta
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date			Change By				Change Description (Bug No. (If Any))
(DD/MM/YYYY)
05/11/2008		Santul Sharma	Comm_05
12/01/2009		Nilesh Kandolkar(WNS)	Remove code for generating report in XLS.

----------------------------------------------------------------------------------------------------
 -->
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ include file="customized.process" %>
<%@ page import="com.tcsta.util.PathUtil" %>

<HTML>
<HEAD>
<TITLE>TA EP Report</TITLE>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>



</script>



<body >

<%!

 public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }


%>

<%
try
{
	String sProcessDefId=null;
	String sProcedureName=null;
	String sColumnHeaders=null;
	String sReportName=null;
	String sFileName=null;
	String sNumberOfColumns=null;
	String sProcedureNameKey=null;
	String sColumnHeadersKey=null;
	String sFileNameKey=null;
	String sNumberOfColumnsKey=null;
	String sHeaderKey=null;
	String sHeaderPresentKey=null;
	String sDBMappedColsKey=null;
	String sHeaderValue=null;
	String sHeaderPresentValue=null;
	String sCabinetName=null;	
	String sDBMappedCols=null;
	String sFieldValuesKey=null;
	String sFieldValues=null;
	String sFieldValuesReport="";
	String sUserMailID=null;//added by nilesh

	sReportName	=request.getParameter("ReportName");
	sUserMailID=request.getParameter("UserEmailID");//added by nilesh 
	sReportName	=sReportName.toUpperCase();

	
	sProcedureNameKey=sReportName +"_PROCEDURENAME";

	
	sColumnHeadersKey=sReportName+"_COLUMNHEADERS";
	
	sFileNameKey=sReportName+"_FILENAME";

	

	sNumberOfColumnsKey=sReportName+"_NUMBEROFCOLUMNS";

	

	sHeaderPresentKey=sReportName+"_HEADERPRESENT";

	


	sHeaderKey=sReportName+"_HEADER";

	
	sDBMappedColsKey=sReportName+"_DBMAPPEDCOLS";
	
	sFieldValuesKey=sReportName+"_FIELDVALUES";

	

	String sRootPathini=application.getRealPath("")+File.separator+"reports"+File.separator+"GMACReports"+File.separator+"TAEPAgingReport" + File.separator + "reports.ini";

	Properties ini = new Properties();
	
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("EPAGING Report","Unable to close the EPAGING Report.ini file");
						}
					}
				}
	

	sProcessDefId=ini.getProperty("PROCESSDEFID");
	
	sCabinetName=ini.getProperty("CABINETNAME");
	sProcedureName=ini.getProperty(sProcedureNameKey);
	
	sColumnHeaders=ini.getProperty(sColumnHeadersKey);
	
	sFileName=ini.getProperty(sFileNameKey);
	
	sNumberOfColumns=ini.getProperty(sNumberOfColumnsKey);
	
	sHeaderPresentValue=ini.getProperty(sHeaderPresentKey);
	
	sDBMappedCols=ini.getProperty(sDBMappedColsKey);
	
	sFieldValues=ini.getProperty(sFieldValuesKey);

	if(sHeaderPresentValue.equals("YES")) 
	{
		sHeaderValue=ini.getProperty(sHeaderKey);
	}

	String sCabname=null;
	String sSessionId = null;
	String sJtsIp = null;
	String sUserName = null;
	String sReportProcedureName=null;
	String sReportTableName=null;
	//String sProcessType=request.getParameter("ProcessType");
	//String sDocumentType=request.getParameter("DocumentType");
	String sQueueName=request.getParameter("QueueName");
	String sFromDate=request.getParameter("FromDates");
	String sToDate=request.getParameter("ToDate");
	int sFromtime=00;
	int sTotime=00;
	String sFIELDPATH="//10.33.192.139/XLS-File/ProcessManager/reports/Gmac report/TA_EP/";



	Date CurrDate=new Date();
	DateFormat dt = new SimpleDateFormat("dd-MMM-yyyy");
	String sCurrdate=dt.format(CurrDate);

	String sOutputXML="";
	String sInputXML = "";
	String maincode = "";
	String Totalrec = "0";

	String url = "";
	String Status="";
	String 	sStr_ServerType="";
	String sInputXml="";
	double fPercentage=0;
	String sColumnNamesArr[]=split(sColumnHeaders,',');
	String sDBMappedColsArr[]=split(sDBMappedCols,',');
	String sFinalColumns[]=split(sColumnHeaders,',');
	for(int i=0;i<sColumnNamesArr.length;i++)
	{
		if(sColumnNamesArr[i].indexOf("~D")!=-1)
			sFinalColumns[i]=sColumnNamesArr[i].substring(0,sColumnNamesArr[i].length()-2);

	}

		String sFieldNamesDB[]=split(sFieldValues,'#');

		for(int i=0;i<sFieldNamesDB.length;i++)
		{
			sFieldValuesReport=sFieldValuesReport+sFieldNamesDB[i]+',';
		}
		
	sFieldValuesReport=sFieldValuesReport.substring(0,sFieldValuesReport.length()-1);
	
	//Aging Implementation
	
	String sRowXml="";

	int iJtsPort = 0;
	boolean bError=false;

	try
	{
		/*sCabinetName=wfsession.getEngineName();
		sSessionId = wfsession.getSessionId();
		sJtsIp = wfsession.getJtsIp();
		iJtsPort = wfsession.getJtsPort();
		sUserName = wfsession.getUserName();*/


		 sUserName=wfSession.getM_strUserName();
		sCabinetName=wfSession.getM_strCabName();
		sSessionId = wfSession.getM_strSessionID();
		sJtsIp =wfSession.getM_objCabinet().getM_strServerIP();
		iJtsPort =wfSession.getM_objCabinet().getM_iServerPort();
		sStr_ServerType = wfSession.getM_objCabinet().getM_strServerType();




		
	}
	catch(Exception ignore)
	{
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		WriteLog("EPAGING REPORT ",ignore.toString());
		bError= true;
	}

	/*added additional sUserMailID in params tag in sInputXML by nilesh */
	if(!bError)
	{
				
				/*sInputXML = "<?xml version=\"1.0\"?>"
						  +"<APProcedure_Input>\n"
						  +"<Option>APProcedure</Option>\n"
						  +"<ProcName>"+sProcedureName+"</ProcName>\n"
						  +"<Params>'"+sDocumentType+"','"+sQueueName+ "','"+ sFromDate +"','"+sToDate+"','"+sFieldValuesReport+"','"+sFIELDPATH+"'</Params>\n"
						  +"<NoOfCols>"+sNumberOfColumns+"</NoOfCols>\n"
						  +"<EngineName>" +sCabinetName+ "</EngineName>\n"
						  +"<SessionId>" +sSessionId+ "</SessionId>\n"
						  +"</APProcedure_Input>";*/

			 sInputXML =  "<?xml version=\"1.0\"?>\n"
						  + "<WFTestMethod_Input>\n"
						  + "<Option>NG_execute_Result</Option>\n"
						  + "<ProcName>"+sProcedureName+"</ProcName>\n"
    					   +"<Params>'"+sQueueName+ "','"+ sFromDate  +"','"+sToDate+"','"+ sFromtime  +"','"+sTotime+"','"+sFieldValuesReport+"','"+sUserMailID+"','"+sFIELDPATH+"'</Params>\n"
          			 	   +"<NoOfCols>1</NoOfCols>\n"
					       + "<EngineName>"+sCabinetName+ "</EngineName>\n"
						   + "<SessionId>" + sSessionId + "</SessionId>\n"
						   + "</WFTestMethod_Input>";





         WriteLog("EPAGING REPORT ","sInputXML ::> sInputXML : "+sInputXML);



		try
		{
			
        
		 sOutputXML = WFCallBroker.execute(sStr_ServerType,"",sInputXML,sJtsIp,iJtsPort,1);
         WriteLog("EPAGING REPORT ","sInputXML ::> sOutputXML : "+sOutputXML);


			if(sOutputXML.equals("") || Integer.parseInt(sOutputXML.substring(sOutputXML.indexOf("<MainCode>")+10 , sOutputXML.indexOf("</MainCode>")))!=0)
			{
				bError= true;
				maincode=sOutputXML.substring(sOutputXML.indexOf("<MainCode>")+10 , sOutputXML.indexOf("</MainCode>"));
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+maincode+"</b></font><center>");
			}
			else
			{
					//added by nilesh for no record and delivery alerts 
							try
							{
			 String sReturnValue =sOutputXML.substring(sOutputXML.indexOf("<Results>")+9,sOutputXML.indexOf("</Results>"));
			 int    iReturnValue =Integer.parseInt(sReturnValue);
             WriteLog("EPAGING REPORT ","iReturnValue ::> inside line 220 : "+iReturnValue);
								if(iReturnValue==0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
								out.println(ig.toString());
								WriteLog("EPAGING REPORT ",ig.toString());
												
							}
							
							//commented by nilesh
							/*try
							{
								int i=0;
								WFXmlResponse xmlResponse = new WFXmlResponse(sOutputXML);
								WFXmlList RecordList;

							   for (RecordList =  xmlResponse.createList("Records", "Record");RecordList.hasMoreElements();RecordList.skip())
								{   
								 
								   for(i=0;i<sColumnNamesArr.length;i++)
									{
										sRowXml=sRowXml+RecordList.getVal(sDBMappedColsArr[i])+'^';
										
									}
									sRowXml=sRowXml.substring(0,sRowXml.length()-1)+'~'	;
								}
								
								if(sRowXml!="")
								{
									sRowXml=sRowXml.substring(0,sRowXml.length()-1);
								}
								
							}
							catch(Exception ig)
							{ 
								out.println(ig.toString());
								//log("Movement Report Data Formulation Error : "+ig);
												
							}*/
			}


		}
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			WriteLog("EPAGING REPORT ",exp.toString());
			bError= true;
			
		}

		
	}
	
%>

<FORM name="textForm">
		
		<!--Commented by nilesh-->
		<!--	<%
				if(sRowXml=="")
				{%>
						<script>
							alert("No record found");
						</script>
			<%
				}
				else
				{
					response.setContentType ("application/excel"); 
					response.addHeader("content-disposition","attachment;filename="+sFileName+".xls");
					%>
			<table width="100%" align ="center" border=0>
				<tr >
					<td width="40%" align='left'> Status As On : <%=sCurrdate%> </td>
									
				</tr>
				</table>
				<table width="100%" align ="center" border=1>
				<tr width="100%">
					<%
					if(sHeaderPresentValue.equals("YES")) {
					%>
					<tr width="100%">
					<%
					String sHeader[]=split(sHeaderValue,',');
					for(int iHeaderCount=0;iHeaderCount<sHeader.length;iHeaderCount++) {
						%>
						<td width=<%=100.0/sHeader.length%>%  class="EWSubHeader"><b><%=sHeader[iHeaderCount]%></b></td>
						<%
						}
					%>
					</tr>
					
					<%
					}
					%>
					
					<%
					fPercentage=100.0/sColumnNamesArr.length;
					for(int iColumnCount=0;iColumnCount<sColumnNamesArr.length;iColumnCount++)
					{
					
					%>
					<td width=<%=fPercentage%>%  class="EWSubHeader"><b><%=sFinalColumns[iColumnCount]%></b></td>
					<%
					}	
					%>	
					</tr>
					<%
					if (sRowXml!="")
					{
					String sRowData1[]=split(sRowXml,'~');
					
					%>
					<tr width="100%">
					<%
					for(int i=0;i<sRowData1.length;i++)	{
						String sColData[]=split(sRowData1[i],'^');
						for(int jColumnCnt=0;jColumnCnt<sColData.length;jColumnCnt++)
						{
							//Change No:Comm_05 by Santul Sharma
							if(sColumnNamesArr[jColumnCnt].indexOf("~D")!=-1 )
							{							
						%>
							<td width=<%=fPercentage%>%  style="mso-number-format:'mm\/dd\/yyyy\\ hh:mm:ss'"><%=sColData[jColumnCnt]%></td>
						<%
							
							}
							else
							{
								%>
									<td width=<%=fPercentage%>%  class="EWLabel1"><%=sColData[jColumnCnt]%></td>
								<%

							}
													

						}  //end jColumn for //end jColumn for	
						%>
						
						
						</tr>
		
		
						<%
							
						}//outer i loop for
					
					} ///if sRowXml ends

				%>
			
			
			</table>
			-->
			</form>	
			<%
			}
	
}
catch(Exception e)
{
	WriteLog("EPAGING REPORT ",e.toString());
  
}

	%>	

</body>
</html>
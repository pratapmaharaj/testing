<!-- 
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-TACM
Module : GMAC-TACM
File Name : TACMQueueStatusMain.jsp
Author :   
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date			Change By		Change Description (Bug No. (If Any))
(DD/MM/YYYY)


----------------------------------------------------------------------------------------------------
 -->

<HTML>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<HEAD>
<TITLE>TAEP Queue Status Report</TITLE><!-- Change No:Res_30 -->
</HEAD>

<FRAMESET ROWS="100%,0%" >
	<FRAME SRC="EPQueueStatus.jsp" NAME="frmHeader" frameborder=no noresize scrolling=Yes>
	<FRAME SRC="" NAME="TACMQUEUESTATUSREPORT" frameborder=no scrolling=no>
	
</FRAMESET>
</html>


<%@ include file="customized.process" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="java.sql.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>


<HTML>
<HEAD>
<TITLE>TACM User Info Report1 Report</TITLE>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>



<body >
<%!

 public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }
%>

<%
WriteLog("VS_QueueStatus","sOutputXML ::> sOutputXML : here") ;

	Connection conn = null;
	Statement st;
	String connectionUrl =""; 
	boolean empty=true;

	String sProcessDefId=null;
	String sProcedureName=null;
	String sColumnHeaders=null;
	String sReportName=null;
	String sFileName=null;
	String sNumberOfColumns=null;
	String sProcedureNameKey=null;
	String sColumnHeadersKey=null;
	String sFileNameKey=null;
	String sNumberOfColumnsKey=null;
	String sHeaderKey=null;
	String sHeaderPresentKey=null;
	String sDBMappedColsKey=null;
	String sHeaderValue=null;
	String sHeaderPresentValue=null;
	String sCabinetName=null;	
	String sDBMappedCols=null;
	String sFieldValuesKey=null;
	String sFieldValues=null;
	String sFieldValuesReport="";
	String sUserMailID=null;
	String sFilePath=null;
	String sFilePathKey=null;
	String UserNames = "" ;
	sReportName	=request.getParameter("ReportName");
	UserNames = request.getParameter("UserNames");

	sUserMailID=request.getParameter("UserEmailID");
	sReportName	=sReportName.toUpperCase();
	WriteLog("VS_QueueStatus","sOutputXML ::> sReportName : "+sReportName) ;
	WriteLog("VS_QueueStatus","sOutputXML ::> sUserMailID : "+sUserMailID) ;

	sProcedureNameKey=sReportName +"_PROCEDURENAME" ;
	WriteLog("VS_QueueStatus","sOutputXML ::> sProcedureNameKey : "+sProcedureNameKey) ;
	sColumnHeadersKey=sReportName+"_COLUMNHEADERS";
	WriteLog("VS_QueueStatus","sOutputXML ::> sColumnHeadersKey : "+sColumnHeadersKey) ;
	sFileNameKey=sReportName+"_FILENAME";

	WriteLog("VS_QueueStatus","sOutputXML ::> sFileNameKey : "+sFileNameKey) ;

	sNumberOfColumnsKey=sReportName+"_NUMBEROFCOLUMNS";

	WriteLog("VS_QueueStatus","sOutputXML ::> sNumberOfColumnsKey : "+sNumberOfColumnsKey) ;

	sHeaderPresentKey=sReportName+"_HEADERPRESENT";

	WriteLog("VS_QueueStatus","sOutputXML ::> sHeaderPresentKey : "+sHeaderPresentKey) ;
	
	sHeaderKey=sReportName+"_HEADER";

	WriteLog("VS_QueueStatus","sOutputXML ::> sHeaderKey : "+sHeaderKey) ;
	sDBMappedColsKey=sReportName+"_DBMAPPEDCOLS";
	WriteLog("VS_QueueStatus","sOutputXML ::> sDBMappedColsKey : "+sDBMappedColsKey) ;
	sFieldValuesKey=sReportName+"_FIELDVALUES";

	WriteLog("VS_QueueStatus","sOutputXML ::> sFieldValuesKey : "+sFieldValuesKey) ;
	
	sFilePathKey=sReportName+"_FILEPATH";
	

	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAVSQueueStatusReport.ini";

	Properties ini = new Properties();
	
		FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("VSApproverStatusGenerate","Unable to read VSApproverStatusGenerate.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("VSApproverStatusGenerate","Unable to close the VSApproverStatusGenerate.ini file");
						}
					}
				}
				

	String pathName = "" ;
	pathName = ini.getProperty(sReportName +"_FILEPATH");

	sProcedureName=ini.getProperty(sProcedureNameKey);

	sColumnHeaders=ini.getProperty(sColumnHeadersKey);
	
	sFileName=ini.getProperty(sFileNameKey);
	
	sNumberOfColumns=ini.getProperty(sNumberOfColumnsKey);
	
	sHeaderPresentValue=ini.getProperty(sHeaderPresentKey);
	
	sDBMappedCols=ini.getProperty(sDBMappedColsKey);
	
	sFieldValues=ini.getProperty(sFieldValuesKey);
	
	sFilePath=ini.getProperty(sFilePathKey);
	
	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("VSApproverStatusGenerate","sRootPathDBini="+sRootPathDBini);
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("VSApproverStatusGenerate","Unable to read VSApproverStatusGenerate.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("VSApproverStatusGenerate","Unable to close the VSApproverStatusGenerate.ini file");
						}
					}
				}
				

	String driverName = null;
	driverName=ini.getProperty("DRIVERNAME");
	connectionUrl=ini.getProperty("CONNECTIONSTRING");
	WriteLog("VSApproverStatusGenerate","driverName="+driverName+",conString="+connectionUrl);

	CallableStatement callableStatement = null;

	WriteLog("VS_QueueStatus"," output "+connectionUrl);

	if(sHeaderPresentValue.equals("YES")) 
	{
		sHeaderValue=ini.getProperty(sHeaderKey);
	}

	String sCabname=null;
	String sSessionId = null;
	String sJtsIp = null;
	String sUserName = null;
	String sReportProcedureName=null;
	String sReportTableName=null;

	String sOutputXML="";
	String sInputXML = "";
	String maincode = "";
	String Totalrec = "0";

	String url = "";
	String Status="";
	String sStr_ServerType="";
	String sInputXml="";
	double fPercentage=0;
	String sColumnNamesArr[]=split(sColumnHeaders,',');
	String sDBMappedColsArr[]=split(sDBMappedCols,',');
	String sFinalColumns[]=split(sColumnHeaders,',');
	for(int i=0;i<sColumnNamesArr.length;i++)
	{
		if(sColumnNamesArr[i].indexOf("~D")!=-1)
			sFinalColumns[i]=sColumnNamesArr[i].substring(0,sColumnNamesArr[i].length()-2);

	}
	
	String sFieldNamesDB[]=split(sFieldValues,'#');

	for(int i=0;i<sFieldNamesDB.length;i++)
	{
		sFieldValuesReport=sFieldValuesReport+sFieldNamesDB[i]+',';
	}
	sFieldValuesReport=sFieldValuesReport.substring(0,sFieldValuesReport.length()-1);
	
	String sRegFromDate=request.getParameter("RegFromDate");
	String sRegToDate=request.getParameter("RegToDate");
	String sQFromDate=request.getParameter("QFromDate");
	String sQToDate=request.getParameter("QToDate");
	String VendorType=request.getParameter("VendorType");
	String Queue=request.getParameter("sQueue");
	String VendorRequestType = request.getParameter("VendorRequestType");
	
	String sRowXml="";

	int iJtsPort = 0;
	boolean bError=false;
	
	String getDBUSERByUserIdSql = "{call "+sProcedureName+"(?,?,?,?,?,?,?,?,?,?,?,?)}";
	String output = "" ;
	try
	{
WriteLog("VS_QueueStatus"," Ip Param '"+Queue+"','"+VendorRequestType+"','"+VendorType+"','"+sRegFromDate+"','"+sRegToDate+"','"+sQFromDate+"','"+sQToDate+"','"+sFieldValuesReport+"','"+sUserMailID+"','"+sFilePath+"','"+sFileName+"'");
			Class.forName(driverName);
			conn = DriverManager.getConnection(connectionUrl);
			callableStatement = conn.prepareCall(getDBUSERByUserIdSql);
			callableStatement.setString(1, Queue);
			callableStatement.setString(2, VendorRequestType);
			callableStatement.setString(3, VendorType);
			callableStatement.setString(4, sRegFromDate);
			callableStatement.setString(5, sRegToDate);
			callableStatement.setString(6, sQFromDate);
			callableStatement.setString(7, sQToDate);
			callableStatement.setString(8, sFieldValuesReport);
			callableStatement.setString(9, sUserMailID);
			callableStatement.setString(10, sFilePath);
			callableStatement.setString(11, sFileName);
			callableStatement.registerOutParameter(12, java.sql.Types.VARCHAR);
			callableStatement.execute();

			output = callableStatement.getString(12);
			WriteLog("VS_QueueStatus"," output "+output);
	}
	catch(SQLException ignore)
	{
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		bError= true;
		WriteLog("VS_QueueStatus"," WFSession Data Fetch Exception:::::: "+ignore.toString());
			%>
				<script>alert("Error While Generating Report");</script>
			<%
	}
	finally {
 
	if (callableStatement != null) {
        try {
            callableStatement.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
	}
if(!bError)
	{

		WriteLog("VS_QueueStatus"," output:::::: "+output);
		try
		{

			if(output.equals(""))
			{
				bError= true;
				//maincode=sOutputXML.substring(sOutputXML.indexOf("<MainCode>")+10 , sOutputXML.indexOf("</MainCode>"));
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+output+"</b></font><center>");
			}
			else
			{
				
					try
							{
								 if(Integer.parseInt(output) == 0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
								out.println(ig.toString());
								%>
									<script>alert("Error While Generating Report");</script>
								<%
								WriteLog("VS_QueueStatus"," ig.toString() :::::: "+ig.toString());
							}
			}
		}
		
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
			log("VS_QueueStatus "+exp.toString());
			WriteLog("VS_QueueStatus"," exp.toString() :::::: "+exp.toString());
			%>
				<script>alert("Error While Generating Report");</script>
			<%
		}
		
	}

%>
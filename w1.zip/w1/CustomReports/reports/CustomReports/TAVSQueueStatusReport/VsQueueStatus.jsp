

<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>


<HTML>
<HEAD>
<TITLE>Vendor Setup Queue Status Report</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>


</HEAD>
<link href="/webdesktop/CustomForms/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>
<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
	
}
</style>
<script>
	var allWindows = new Array();
	var win; // new window object
	$(document).ready(function(){$('#From_Date_Reg').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", disabled: true,
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date_Reg').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", disabled: true,
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#From_Date_Q').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", disabled: true,
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date_Q').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", disabled: true,
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	});

	/*functions echeck,ValidateForm added by nilesh*/
	function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}
//---Added by Chetan
function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";

	sDate	= window.showModalDialog('/processmanager/reports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');




	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
}

function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	strResult=strdate+"/"+strMonth+"/"+stryear;
	return strResult;
}

function convertMonth(strMonth)
{
		if(strMonth=="JAN")
			strMonth="00";
		else if(strMonth=="FEB")
			strMonth="01";
		else if(strMonth=="MAR")
			strMonth="02";
		else if(strMonth=="APR")
			strMonth="03";
		else if(strMonth=="MAY")
			strMonth="04";
		else if(strMonth=="JUN")
			strMonth="05";
		else if(strMonth=="JUL")
			strMonth="06";
		else if(strMonth=="AUG")
			strMonth="07";
		else if(strMonth=="SEP")
			strMonth="08";
		else if(strMonth=="OCT")
			strMonth="09";
		else if(strMonth=="NOV")
			strMonth="10";
		else if(strMonth=="DEC")
			strMonth="11";
	   return strMonth;
}
function compToday(Date_To)
{
	var todaysDate = new Date(); 
	var dd = todaysDate.getDate() ;
	var mm = todaysDate.getMonth()+1 ;
	var yy = todaysDate.getFullYear() ;

	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));

	var Date_To_date=Number(Date_To.substring(0,Date_To.indexOf("/")));	

	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));

	if(Date_To_month=="JAN")
			Date_To_month="1";
		else if(Date_To_month=="FEB")
			Date_To_month="2";
		else if(Date_To_month=="MAR")
			Date_To_month="3";
		else if(Date_To_month=="APR")
			Date_To_month="4";
		else if(Date_To_month=="MAY")
			Date_To_month="5";
		else if(Date_To_month=="JUN")
			Date_To_month="6";
		else if(Date_To_month=="JUL")
			Date_To_month="7";
		else if(Date_To_month=="AUG")
			Date_To_month="8";
		else if(Date_To_month=="SEP")
			Date_To_month="9";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";

	if(Date_To_year>yy)
	{
		return false;
	}
	else if(Date_To_year<yy)
	{
		//if(Date_From_month>Date_To_month)
		//{
		//alert("To Date can not be less than From Date.");
		//return false;
		//}
		 if(mm==Date_To_month)
		{
			if(Date_To_date>dd)
			{
				return false;
			}
		}
	}
	else if(Date_To_year==yy)
	{
		if(mm<Date_To_month)
		{
		return false;
		}
		else if(mm==Date_To_month)
		{
			if(Date_To_date>dd)
			{
				return false;
			}
		}
	}
return true ;
}

function DateComparator(Date_To,Date_From)
{	
	if(!compToday(Date_From))
	{
		alert("From Date can not be Future Date.");
		return false ;
	}
	if(!compToday(Date_To))
	{
		alert("To Date can not be Future Date.");
		return false ;
	}
	//alert(dd+" "+mm+" "+yy) ;
	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));	
	var Date_From_month=Date_From.substring(Date_From.indexOf("/")+1,Date_From.lastIndexOf("/"));

	/*converting ToDate month to number */
	if(Date_To_month=="JAN")
			Date_To_month="01";
		else if(Date_To_month=="FEB")
			Date_To_month="02";
		else if(Date_To_month=="MAR")
			Date_To_month="03";
		else if(Date_To_month=="APR")
			Date_To_month="04";
		else if(Date_To_month=="MAY")
			Date_To_month="05";
		else if(Date_To_month=="JUN")
			Date_To_month="06";
		else if(Date_To_month=="JUL")
			Date_To_month="07";
		else if(Date_To_month=="AUG")
			Date_To_month="08";
		else if(Date_To_month=="SEP")
			Date_To_month="09";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";

	/*convering FromDate month to number */
		if(Date_From_month=="JAN")
			Date_From_month="01";
		else if(Date_From_month=="FEB")
			Date_From_month="02";
		else if(Date_From_month=="MAR")
			Date_From_month="03";
		else if(Date_From_month=="APR")
			Date_From_month="04";
		else if(Date_From_month=="MAY")
			Date_From_month="05";
		else if(Date_From_month=="JUN")
			Date_From_month="06";
		else if(Date_From_month=="JUL")
			Date_From_month="07";
		else if(Date_From_month=="AUG")
			Date_From_month="08";
		else if(Date_From_month=="SEP")
			Date_From_month="09";
		else if(Date_From_month=="OCT")
			Date_From_month="10";
		else if(Date_From_month=="NOV")
			Date_From_month="11";
		else if(Date_From_month=="DEC")
			Date_From_month="12";
	
	var Date_To_date=Number(Date_To.substring(0,Date_To.indexOf("/")));	
	var Date_From_date=Number(Date_From.substring(0,Date_From.indexOf("/")));

	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));
	var Date_From_year=Number(Date_From.substring(Date_From.lastIndexOf("/")+1,Date_From.length));

	var inputTo = Date_To_date+''+Date_To_month+''+Date_To_year ;
	var inputFrom = Date_From_date+''+Date_From_month+''+Date_From_year ;


	if(Date_To_year<Date_From_year)
	{
		alert("To Date cannot be less than From  Date.");
		return false;
	}
	else if(Date_To_year>Date_From_year)
	{
		 if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{
				
				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}


	else if(Date_To_year==Date_From_year)
	{
	
		if(Date_From_month>Date_To_month)
		{
		alert("To Date can not be less than From Date.");
		return false;
		}
		else if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{

				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}

	var toDate = new Date(Date_To_month+"/"+Date_To_date+"/"+Date_To_year);
	var fromDate = new Date(Date_From_month+"/"+Date_From_date+"/"+Date_From_year);
	var oneDay=1000*60*60*24;

	var dateDiff=Math.ceil((toDate.getTime()-fromDate.getTime())/oneDay);
	if(dateDiff>90)
	{
		alert('Date Range can not be greater than 90 days.');
		return false;
	}

return true;
}
	
function ValidateForm(emailID){
//	var emailID=document.frmSample.txtEmail
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }
 
 function disbFields()
 {
 	document.getElementById('From_Date_Q').value='';
	document.getElementById('To_Date_Q').value='';
	document.getElementById('From_Date_Reg').value='';
	document.getElementById('To_Date_Reg').value='';
	//document.getElementById('From_Date_IMG_Queue').disabled=true;
	//document.getElementById('To_Date_IMG_Queue').disabled=true;
	//document.getElementById('From_Date_IMG_Reg').disabled=true;
	//document.getElementById('To_Date_IMG_Reg').disabled=true;

 	document.getElementById('From_Date_Q').style.backgroundColor='grey';
	document.getElementById('To_Date_Q').style.backgroundColor='grey';
	document.getElementById('From_Date_Reg').style.backgroundColor='grey';
	document.getElementById('To_Date_Reg').style.backgroundColor='grey';

 }
 function chkradio(obj)
	{
		if(obj == 'r')
		{
			if(document.getElementById('Queue_Date').checked == true) 
			{
				document.getElementById('Queue_Date').checked = false;
			}
			document.getElementById('From_Date_Q').value='';
			document.getElementById('To_Date_Q').value='';
			document.getElementById('From_Date_Q').style.backgroundColor='grey';
			document.getElementById('To_Date_Q').style.backgroundColor='grey';
			//document.getElementById('From_Date_IMG_Queue').disabled=true;
			//document.getElementById('To_Date_IMG_Queue').disabled=true;
			//document.getElementById('From_Date_IMG_Reg').disabled=false;
			//document.getElementById('To_Date_IMG_Reg').disabled=false;
			document.getElementById('From_Date_Reg').style.backgroundColor='white';
			document.getElementById('To_Date_Reg').style.backgroundColor='white';
			$('#From_Date_Reg').datepicker("enable");
			$('#To_Date_Reg').datepicker("enable");
			$('#To_Date_Q').datepicker("disable");
			$('#From_Date_Q').datepicker("disable");
		}
		else if(obj == 'q')
		{
			if(document.getElementById('Registration').checked == true) 
			{
				document.getElementById('Registration').checked = false;
			}
			document.getElementById('From_Date_Q').style.backgroundColor='white';
			document.getElementById('To_Date_Q').style.backgroundColor='white';
			document.getElementById('From_Date_Reg').style.backgroundColor='grey';
			document.getElementById('To_Date_Reg').style.backgroundColor='grey';
			//document.getElementById('From_Date_IMG_Reg').disabled=true;
			//document.getElementById('To_Date_IMG_Reg').disabled=true;
			document.getElementById('From_Date_Reg').value='';
			document.getElementById('To_Date_Reg').value='';

			//document.getElementById('From_Date_IMG_Queue').disabled=false;
			//document.getElementById('To_Date_IMG_Queue').disabled=false;
			$('#From_Date_Reg').datepicker("disable");
			$('#To_Date_Reg').datepicker("disable");
			$('#To_Date_Q').datepicker("enable");
			$('#From_Date_Q').datepicker("enable");
		}

	}
	
	function openreport()
	{	var sQueue="";
		var VendorRequestType="";
		var VendorType="";
		var bQueueSelected=false;
		var bVendor=false;
		var bVendorReq = false;
		var UserEmailID=document.getElementById('EMail-ID').value;//added by nilesh
		var RegDateRangeFrom="";
		var RegDateRangeTo="";
		var QDateRangeFrom="";
		var QDateRangeTo="";
		
		for(var i=0;i<document.forms["textForm"].Queue.length;i++)
		{
			if(document.forms["textForm"].Queue[i].selected)
			{
				sQueue=sQueue+document.forms["textForm"].Queue[i].value+'~';
				bQueueSelected=true;
			}

		}

		for(var i=0;i<document.forms["textForm"].Vendor_Type.length;i++)
				{
					if(document.forms["textForm"].Vendor_Type[i].selected)
					{
					VendorType=VendorType+document.forms["textForm"].Vendor_Type[i].value+'~';
					bVendor=true;
					}

				}
				
		for(var i=0;i<document.forms["textForm"].Vendor_Request_Type.length;i++)
				{
					if(document.forms["textForm"].Vendor_Request_Type[i].selected)
					{
					VendorRequestType=VendorRequestType+document.forms["textForm"].Vendor_Request_Type[i].value+'~';
					bVendorReq=true;
					}

				}
				
		
		if(document.getElementById('Registration').checked)
		{
			RegDateRangeFrom=document.forms["textForm"].From_Date_Reg.value;
			RegDateRangeTo=document.forms["textForm"].To_Date_Reg.value;	
		}
		if(document.getElementById('Queue_Date').checked)
		{
			QDateRangeFrom=document.forms["textForm"].From_Date_Q.value;
			QDateRangeTo=document.forms["textForm"].To_Date_Q.value;	
		}
		
		
			var sTestQueue=sQueue.split('~');
			var sTestVendorType=VendorType.split('~');
			var sTestVendorReqType=VendorRequestType.split('~');

		//---------------------------------------------------
		
		
		if(!bQueueSelected)
		{
			alert("Please Select Queue.");
			return false;
		}

		if(!document.getElementById('Registration').checked && !document.getElementById('Queue_Date').checked)
		{
			alert('Please select either an Registration Date range or Queue entry date range.') ;
			return false ;
		}
		if(document.getElementById('Registration').checked)
		{
			if(RegDateRangeFrom=='')
			{
				alert("Please select an appropriate From Date");
				return false;
			}
			if(RegDateRangeTo=='')
			{
				alert("Please select an appropriate To Date");
				return false;
			}
		}
		
		if(document.getElementById('Queue_Date').checked)
		{
			if(QDateRangeFrom=='')
			{
				alert("Please select an appropriate From Date");
				return false;
			}
			if(QDateRangeTo=='')
			{
				alert("Please select an appropriate To Date");
				return false;
			}
		}
		
		if(sQueue.indexOf("All")!=-1 && sTestQueue.length>2)
		{
			alert("No other Queue Name can be chosen after choosing All");
			return false;
			//sQueue='All~';

		}
		
		if(VendorType.indexOf("All")!=-1 && sTestVendorType.length>2)
		{
			alert("No other Vendor Type can be chosen after choosing All");
			return false;
			//VendorType='All~';
		} 

		if(VendorRequestType.indexOf("All")!=-1 && sTestVendorReqType.length>2)
		{
			alert("No other Vendor Request Type can be chosen after choosing All");
			return false;
			//VendorRequestType='All~'
		}  

		if(VendorType == '')
		{
			VendorType = 'All~' ;
		}
		if(VendorType=='Policyholder vendors~Escheatment vendors~Tax vendors~PO vendors~Licensing and filing fee vendors~Non PO Vendors~')
		{
			VendorType='Policyholder vendors~Escheatment vendors~Tax vendors~PO vendors~Licensing and filing fee vendors~Non PO Vendors~';
		}
		
		if(VendorRequestType=='New~Change~')
		{
			VendorRequestType='New~Change~' ;
		}

		if(VendorRequestType=='')
		{
			VendorRequestType = 'All~' ;
		}
		if(sQueue=='VendorSetup~PendingResolution~Cancel~QC~VendorApproval~UpdateVendorChanges~ChangeQC~GEACInterface~')
		{
			sQueue='VendorSetup~PendingResolution~Cancel~QC~VendorApproval~UpdateVendorChanges~ChangeQC~GEACInterface~';
		}
		
		if(!DateComparator(RegDateRangeTo,RegDateRangeFrom))
		{
		return false;
		}
		else if(!DateComparator(QDateRangeTo,QDateRangeFrom))
		{
		return false;
		}
		
		if(UserEmailID=='')
		{
			alert("Please enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
				return false ;
			}
		}
		
		//alert(UserEmailID+" - "+RegDateRangeTo+" - "+RegDateRangeFrom+" - "+sQueue) ;
       if((UserEmailID!='')&&(RegDateRangeTo!="")&&(RegDateRangeFrom!="")&&(sQueue!=""))
		{	
			//OpenRedict-Fix
		//window.top.VENDORSETUPQUEUESTATUS.location.href="VsQueueStatusGenerate.jsp?sQueue="+sQueue+"&VendorRequestType="+VendorRequestType+"&VendorType="+VendorType+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID;;
		var StrOpenWin=strip_tags("VsQueueStatusGenerate.jsp?sQueue="+sQueue+"&VendorRequestType="+VendorRequestType+"&VendorType="+VendorType+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID,"");
			window.top.VENDORSETUPQUEUESTATUS.location.href=StrOpenWin
		}
		else if ((UserEmailID!='')&&(QDateRangeTo!="")&&(QDateRangeFrom!="")&&(sQueue!=""))
		{	
			//OpenRedict-Fix
		//window.top.VENDORSETUPQUEUESTATUS.location.href="VsQueueStatusGenerate.jsp?sQueue="+sQueue+"&VendorRequestType="+VendorRequestType+"&VendorType="+VendorType+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID;
		var StrOpenWin=strip_tags("VsQueueStatusGenerate.jsp?sQueue="+sQueue+"&VendorRequestType="+VendorRequestType+"&VendorType="+VendorType+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID,"");
			window.top.VENDORSETUPQUEUESTATUS.location.href=StrOpenWin
			
		}
		
  }

	
	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}

</script>

<body topmargin="0" leftmargin="5" onload="disbFields();" onunload="UnloadReportWindow();">

			<form name='textForm' method=post>


			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">VENDOR SETUP QUEUE STATUS REPORT</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This report will show the number of un processed work items in the selected queue along with other Indexing details. The Report will provide the current information only. It is not possible to retrive the status in a future date/time. Process Owner / Supervisor can save the generated report for their future references.
</td></tr><tr><td class="EWLabel1"> 
Select All as the Vendor Types if the report has to be generated for the entire spectrum of the avalilable Vendor Type, else select the specific Vendor Type, multiple selections are acceptable.
</td></tr><tr><td class="EWLabel1">Select All Queues if report is to be generated for viewing the workitems present across different worksteps, else select the specific Queue, multiple selections are acceptable.<br>
Select All Vendor Request Types if report is to be generated for viewing the workitems present across all Vendor Request Types, else select the specific Vendor Request Types, multiple selections are acceptable.
Enter the requisiste date range.You can enter either Registration Date Range or Queue Entry Date Range.
</td></tr>
<tr><td class="EWLabel1"><b>Date Range and Queue Name is mandatory.</b>
</td></tr>
			</table>
			<table border="0" width="95%" cellspacing="1" align="center">
<td colspan = 2 class="EWLabel1"><font color="RED">*</font> <b>Fields are Mandatory<b><BR>
				<tr>
					<td class="EWLabel1" align="left" width='20%'><b>Queue <font color="RED">*</font></b></font></td>
					<td width='45%' colspan=3>
					<select style='width:65%' name="Queue" multiple>
					<option value="All">All</option>
					<option value="VendorSetup">VendorSetup</option>
					<option value="PendingResolution">PendingResolution</option>
					<option value="Cancel">Cancel</option>
					<option value="QC">QC</option>
					<option value="VendorApproval">VendorApproval</option>
					<option value="UpdateVendorChanges">UpdateVendorChanges</option>
					<option value="ChangeQC">ChangeQC</option>
					<option value="GEACInterface">GEACInterface</option>
					</select>
					</td>
				</tr>

				<tr>
				<td class="EWLabel1" align="left" width='20%'><b>Vendor Request Type</b></td>
				<td width='45%' colspan=3>
					<select style='width:65%' name="Vendor_Request_Type" multiple>
					<option value="All">All</option>
					<option value="New">New</option>
					<option value="Change">Change</option>
					</select>
				</td>
				</tr>
				<tr>
					<td class="EWLabel1" align="left" width='20%'><b>Vendor Type</b></td>
					<td width='45%' colspan=3>
					<select style='width:65%' name="Vendor_Type" multiple>
					<option value="All">All</option>
					<option value="Policyholder vendors">Policyholder vendors</option>
					<option value="Escheatment vendors">Escheatment vendors</option>
					<option value="Tax vendors">Tax vendors</option>
					<option value="PO vendors">PO vendors</option>
					<option value="Licensing and filing fee vendors">Licensing & filing fee vendors</option>
					<option value="Non PO Vendors">Non PO Vendors</option>
					</select>
					</td>
				</tr>
				
				 
                <!-- Added by Chetan for displaying Date range from and to field...-->
				<tr>&nbsp;</tr>
				 <tr>
				 <tr>
				 <td class="EWLabel1">
					<input type = "radio" class="text" name ="Registration" id ="Registration" value = "Registration" class="EWLabel1" onClick="chkradio('r')"> <font color='Blue'><b>&nbsp;&nbsp;&nbsp;Registration Date <font color="RED">*</font></b></font></td>
				</tr>
				<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
				<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date_Reg" type="text" readonly id="From_Date_Reg" >
					
				</td>
				<td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
				<td width='25%'><input class='TextFieldColorDate' name="To_Date_Reg" readonly type="text"  id="To_Date_Reg" >
					
				</td>

				</tr>

				<tr>
				 <tr>
				 <td class="EWLabel1">
					<input type = "radio" class="EWLabel1" name ="Queue_Date" id ="Queue_Date" value = "Queue_Date" onClick="chkradio('q')"><font color='Blue'><b>&nbsp;&nbsp;&nbsp;Queue Entry Date <font color="RED">*</font><b></td>
					</tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date_Q" readonly type="text"  id="From_Date_Q" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date_Q" readonly type="text"  id="To_Date_Q" >
					
					</td>

				</tr>

				<tr>

				<!-- --------------------------------------------------- -->
				<!--added by nilesh for displaying Emaild field -->

				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID <font color="RED">*</font></b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>
				
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>
	
			
			</form>
</body>
</Html>	 




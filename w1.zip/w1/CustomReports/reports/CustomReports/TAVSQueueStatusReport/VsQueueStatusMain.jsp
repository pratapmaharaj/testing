

<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="java.lang.String.*"%>
<%@ page import="java.lang.Object"%>
<%@ page import="java.lang.Exception"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<HTML>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>


<HEAD>
<TITLE>Vendor Setup Queue Status Report</TITLE><!-- Change No:Res_30 -->
</HEAD>

<FRAMESET ROWS="100%,0%" >
	<FRAME SRC="VsQueueStatus.jsp?ReportName=VENDORSETUPQUEUESTATUS" NAME="frmHeader" frameborder=no noresize scrolling=Yes>
	<FRAME SRC="" NAME="VENDORSETUPQUEUESTATUS" frameborder=no scrolling=no>
	
</FRAMESET>
</html>


       
/*
        
WNS_TA_APVS_QUEUESTATUS_Report 'Introduction~','All~','All~','01/FEB/2014','07/MAR/2014','','','Current_Work_Step ,WI_Name ,Introduction_Type ,Registration_Date,Vendor_Request_Type,Vendor_type,Priority ,Vendor_Name,Vendor_Number ,Payment_Terms,Vendor_Stat
us,Address_Line_1,Address_Line_2,City_Address_Line_3 ,State_Code,Postal_code , Optional_Address_1 ,Optional_Address_2 ,Vendor_Email_ID ,Combined_single_Payment ,Tax_ID_Number ,SSN_Number ,V_1099_Code,V_1099_Payee_Name,ACH ,Bank_Account_Payment_Code ,Code 
,Account_Number ,Exception_Type ,W9_Indicator ,Additional_Comments,Approval_Decision,Approvers_Comments,Entry_Time','tes@qqq.com','//10.33.192.139/XLS-File/Yogesh/Queue','Vs_QueueStatus',''    
    
SELECT Current_Work_Step ,WI_Name ,Introduction_Type ,Registration_Date,Vendor_Request_Type,Vendor_type,Priority ,Vendor_Name,Vendor_Number ,Payment_Terms,Vendor_Status,Address_Line_1,Address_Line_2,City_Address_Line_3 ,State_Code,Postal_code , Optional_A
ddress_1 ,Optional_Address_2 ,Vendor_Email_ID ,Combined_single_Payment ,Tax_ID_Number ,SSN_Number ,V_1099_Code,V_1099_Payee_Name,ACH ,Bank_Account_Payment_Code ,Code ,Account_Number ,Exception_Type ,W9_Indicator ,Additional_Comments,Approval_Decision,Appr
overs_Comments,Entry_Time from WNS_TA_APVS_EXT_Table a with(nolock)    
WHERE  Registration_Date between 'Jan  1 2014 12:00AM' AND 'Mar  7 2014 11:59PM'   
and Current_Work_Step in('Introduction') order by Current_Work_Step,a.Wi_Name     
  
select distinct Current_Work_Step from  WNS_TA_APVS_EXT_Table      
*/

Create PROCEDURE WNS_TA_APVS_QUEUESTATUS_Report           
( 
@QueueName      VARCHAR(255),            
@VendorRequestType VARCHAR(255), 
@VendorType   VARCHAR(200),
@RegDateRangeFrom  VARCHAR(50),
@RegDateRangeTo    VARCHAR(50),            
@QDateRangeFrom    VARCHAR(50),            
@QDateRangeTo    VARCHAR(50),            
@Fields         VARCHAR(8000),           
@EmailID        varchar(200),
@FilePath       varchar(200),
@FileName       varchar(200) ,            
@RowCount varchar(200) OUTPUT 
)
AS
   
 declare
 @WhereQuery varchar(2000),
 @Query varchar(5000),
 @Tables varchar(200),
 @BkpTable varchar(200),
 @QueueNameReport varchar(200),
 @VendorTypeReport varchar(200), 
 @VendorRequestTypeReport varchar(200),
 @EntryExitDetails varchar(8000),
 @Disp_QName varchar(100), 
 @Count_Q varchar(100),
 @status_temp varchar(8000),
 @dbname varchar(60) ,         
 @DateRangeFrom varchar(60),         
 @DateRangeTo varchar(60),    
 @qname varchar(200),    
 @vreqType nvarchar(200),    
 @vType nvarchar(300)    

BEGIN
 Set nocount on 
 set @FileName=@FilePath+'/'+@EmailID+'_'+@FileName+'_'+convert(varchar,getdate(),104)+'.xls'            
 set @WhereQuery='WHERE '
 set @Tables='WNS_TA_APVS_EXT_Table a with(nolock) '       
 set @QueueNameReport=''
 SET @VendorTypeReport=''           
 SET @VendorRequestTypeReport=''         
 Set @DateRangeFrom=''         
 Set @DateRangeTo='' 
 set @RowCount ='0'    
 set @qname = ''   set @vreqType = ''     
 set @vType = ''
 
 Create Table #TAVS_Queuestatus_Report_Temp 
 ( 
   Current_Work_Step varchar(50) ,
   WI_Name varchar(50) ,
   Introduction_Type varchar(100) ,
   Registration_Date varchar(100) ,
   Vendor_Request_Type varchar(100) ,
   Vendor_type varchar(100) ,
   Priority varchar(50) ,     
   Vendor_Name varchar(100) ,
   Vendor_Number varchar(100) ,
   Payment_Terms varchar(100) ,
   Vendor_Status varchar(100) ,
   Address_Line_1 varchar(100) ,
   Address_Line_2 varchar(100) ,
   City_Address_Line_3 varchar(100) ,
   State_Code varchar(20) ,
   Postal_code varchar(50) ,
   Optional_Address_1 varchar(550) ,           
   Optional_Address_2 varchar(550) ,            
   Vendor_Email_ID varchar(80) ,           
   Combined_single_Payment varchar(30) ,           
   Tax_ID_Number varchar(30) ,           
   SSN_Number varchar(30), 
   V_1099_Code varchar(30) ,           
   V_1099_Payee_Name varchar(100) ,           
   ACH varchar(30) ,           
   Bank_Account_Payment_Code varchar(30) ,           
   Code varchar(30),         
   Account_Number varchar(100) ,           
   Exception_Type varchar(100) ,           
   W9_Indicator varchar(30) ,           
   Additional_Comments varchar(550) ,
   Approval_Decision varchar(100) ,        
   Approvers_Comments varchar(550) ,            
   Entry_Time varchar(30)        
 ) 

 Create Table #TAVSQSummaryException 
 (           
  Disp_QName varchar(1000), 
  Count_Q varchar(100)      
 )
      
--Registration Date Range 
if(rtrim(ltrim(@RegDateRangeFrom))<>'' and rtrim(ltrim(@RegDateRangeTo))<>'')   
begin 
if(rtrim(ltrim(@RegDateRangeFrom))<>'') 
 SET @DateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@RegDateRangeFrom,121))))) 
 SET @RegDateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@RegDateRangeFrom,121)))))           
if(rtrim(ltrim(@RegDateRangeTo))<>'') 
 SET @DateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@RegDateRangeTo,121))))) 
 SET @RegDateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@RegDateRangeTo,121)))))         
end 
else 
begin 
--Queue Date Range            
if(rtrim(ltrim(@QDateRangeFrom))<>'') 
 SET @DateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@QDateRangeFrom,121)))))           
 SET @QDateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@QDateRangeFrom,121))))) 
           
if(rtrim(ltrim(@QDateRangeTo))<>'') 
SET @DateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@QDateRangeTo,121))))) 
  SET @QDateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@QDateRangeTo,121))))) 
end 
 
print @DateRangeFrom       
print @DateRangeTo 
          
if(rtrim(ltrim(@RegDateRangeFrom))<>'' AND rtrim(ltrim(@RegDateRangeTo))<>'')           
BEGIN           
 set @WhereQuery=@WhereQuery+' Registration_Date between '''+rtrim(ltrim(@RegDateRangeFrom))+''' AND '''+ rtrim(ltrim(@RegDateRangeTo))+''''           
END
     
if(rtrim(ltrim(@QDateRangeFrom))<>'' AND rtrim(ltrim(@QDateRangeTo))<>'')           
BEGIN           
 set @WhereQuery=@WhereQuery+' Entry_Time between '''+rtrim(ltrim(@QDateRangeFrom))+''' AND '''+ rtrim(ltrim(@QDateRangeTo))+''''           
END   
          
--vendor type            
  if(rtrim(ltrim(@VendorType))<>'All~')      
  BEGIN      
 if(len(@VendorType)=charindex('~',@VendorType))      
 BEGIN     
   set @vType =ltrim(rtrim(substring(@VendorType,0,len(@VendorType))))        
   set @VendorTypeReport=ltrim(rtrim(substring(@VendorType,0,len(@VendorType))))    
         print '-------'      
   print @VendorTypeReport      
   set @WhereQuery=@WhereQuery+' and Vendor_Type ='''+@VendorTypeReport+''''      
 End      
 else      
  BEGIN  
  while (charindex('~',@VendorType)>1)      
  BEGIN    
   print '++++++'    
            print @VendorType    
    
   set @vType = @vType+ltrim(rtrim(SUBSTRING(@VendorType,1,Charindex('~',@VendorType)-1)))+','        
   set @VendorTypeReport = @VendorTypeReport + ''''+ltrim(rtrim(SUBSTRING(@VendorType,1,Charindex('~',@VendorType)-1)))+''''+','      
   set @VendorType=ltrim(rtrim(Substring(@VendorType,Charindex('~',@VendorType)+len('~'),len(@VendorType))))      
  END     
  set @VendorTypeReport=SUBSTRING(@VendorTypeReport,0,len(@VendorTypeReport))       
  set @WhereQuery=@WhereQuery+' and Vendor_Type in('+@VendorTypeReport+')'         
 END      
      
  --PRINT @WhereQuery      
  SET @WhereQuery=@WhereQuery      
 END     

--vendor request type            
   
 if(rtrim(ltrim(@VendorRequestType))<>'All~')      
 BEGIN      
 if(len(@VendorRequestType)=charindex('~',@VendorRequestType))      
 BEGIN
   set @vreqType=ltrim(rtrim(substring(@VendorRequestType,0,len(@VendorRequestType))))            
   set @VendorRequestTypeReport=ltrim(rtrim(substring(@VendorRequestType,0,len(@VendorRequestType))))      
   print @VendorRequestTypeReport      
   set @WhereQuery=@WhereQuery+' and Vendor_Request_Type ='''+@VendorRequestTypeReport+''''      
 End      
  else      
  BEGIN  
    while (charindex('~',@VendorRequestType)>1)      
   BEGIN     
    set @vreqType=@vreqType+ltrim(rtrim(SUBSTRING(@VendorRequestType,1,Charindex('~',@VendorRequestType)-1)))+','       
    set @VendorRequestTypeReport = @VendorRequestTypeReport + ''''+ltrim(rtrim(SUBSTRING(@VendorRequestType,1,Charindex('~',@VendorRequestType)-1)))+''''+','      
    set @VendorRequestType=ltrim(rtrim(Substring(@VendorRequestType,Charindex('~',@VendorRequestType)+len('~'),len(@VendorRequestType))))      
   END     
   set @VendorRequestTypeReport=SUBSTRING(@VendorRequestTypeReport,0,len(@VendorRequestTypeReport))       
   set @WhereQuery=@WhereQuery+' and Vendor_Request_Type in('+@VendorRequestTypeReport+')'         
  END      
      
  --PRINT @WhereQuery      
  SET @WhereQuery=@WhereQuery      
 END    
      
            
 --Queue name           
 if(rtrim(ltrim(@QueueName))<>'All~')       
 BEGIN  
  while (charindex('~',@QueueName)>1)
 BEGIN     
  set @qname =@qname+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+','
  set @QueueNameReport = @QueueNameReport + ''''+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+''''+','
  set @QueueName=ltrim(rtrim(Substring(@QueueName,Charindex('~',@QueueName)+len('~'),len(@QueueName))))
 END
 set @QueueNameReport=SUBSTRING(@QueueNameReport,0,len(@QueueNameReport))       
 set @WhereQuery=@WhereQuery+' and Current_Work_Step in('+@QueueNameReport+')'     
 print @WhereQuery
 END
 Else
 BEGIN 
 set @WhereQuery=@WhereQuery+' and Current_Work_Step<>''Null'''        
 print @WhereQuery      
 End     
    
 print @queuename        
--queuename      
         

          
---------------------------------------------------------------------------------- 

Set @Query='insert into #TAVS_Queuestatus_Report_Temp(Current_Work_Step ,WI_Name ,Introduction_Type ,Registration_Date,Vendor_Request_Type,Vendor_type,Priority ,Vendor_Name,Vendor_Number ,Payment_Terms,Vendor_Status,Address_Line_1,Address_Line_2,City_Address_Line_3 ,State_Code,Postal_code , Optional_Address_1 ,Optional_Address_2 ,Vendor_Email_ID ,Combined_single_Payment ,Tax_ID_Number ,SSN_Number ,V_1099_Code,V_1099_Payee_Name,ACH ,Bank_Account_Payment_Code ,Code ,Account_Number ,Exception_Type ,W9_Indicator ,Additional_Comments ,Approval_Decision ,Approvers_Comments,Entry_Time)'           
 SET @Query=@Query+' SELECT '+@Fields+' from '+ @Tables + ' '+@WhereQuery + ' order by Current_Work_Step,a.Wi_Name '            
 print (@Query)
 exec(@Query) 

 --Create summary

 SET @Query='insert into #TAVSQSummaryException(Disp_QName,Count_Q) '
 SET @Query=@Query+' select case Current_Work_Step 
 when''Introduction''then ''Introduction :''     
 when''VendorSetup''then ''VendorSetup :''
 when''PendingResolution''then ''Pending Resolution :''     
 when''Cancel''then ''Cancel :''     
 when''VendorApproval''then ''Vendor Approval :''            
when''Exit''then ''Exit :''          
 when''QC''then ''QC :''           
 when''GEACInterface''then ''GEAC Interface :''
 when''ChangeQC''then ''Change QC :''            
 when''UpdateVendorChanges''then ''Update Vendor Changes :''            
 else ''Queue Name :'' end as Disp_Qname, count(*) as   
 count_Q from #TAVS_Queuestatus_Report_Temp group by Current_Work_Step' 
      --set @Query=@Query+@Querysum 
 print 'Exception Count '+@Query
 exec (@Query)     
    
select @RowCount=count(*) from #TAVSQSummaryException with(nolock)     
 if(@RowCount=0)  
 Begin  
 drop table #TAVSQSummaryException  
 End     
           
 select @RowCount=count(*) from #TAVS_Queuestatus_Report_Temp with(nolock)         

 if(@RowCount=0)         
 Begin         
  drop table #TAVS_Queuestatus_Report_Temp         
 End
 else
 begin 
  if Object_ID ('TA_TEMP_AUTOMAIL1') is not null    
  BEGIN    
   exec('drop table TA_TEMP_AUTOMAIL1')
  END 

  Exec('Create table TA_TEMP_AUTOMAIL1 (Header varchar(max),ROw_Index int IDENTITY(1,1) PRIMARY KEY)')

   exec ('Insert into TA_TEMP_AUTOMAIL1 
   Select ''<html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>      

   <table border=1>
   <tr align="left"><td colspan=34 class=headerbold><center> VENDOR SETUP QUEUE STATUS REPORT </center></td></tr>
   <tr align="left"><td colspan=34 class=headerbold> Registration Date From : '+@RegDateRangeFrom+'</td></tr>
   <tr align="left"><td colspan=34 class=headerbold> Registration Date To : '+@RegDateRangeTo+'</td></tr>    
   <tr align="left"><td colspan=34 class=headerbold> Queue Entry Date From : '+@QDateRangeFrom+'</td></tr>    
   <tr align="left"><td colspan=34 class=headerbold> Queue Entry Date To : '+@QDateRangeTo+'</td></tr>    
   <tr align="left"><td colspan=34 class=headerbold> Queue Name : '+@qname+'</td></tr>    
   <tr align="left"><td colspan=34 class=headerbold> Vendor Request Type : '+@vreqType+'</td></tr>    
   <tr align="left"><td colspan=34 class=headerbold> Vendor Type : '+@vType+'</td></tr>            
   </table>  <br> ''+    
   ''<table border=1><tr><td class=headerbold>Current Queue</td>''+    
   ''<td class=headerbold>WI Name</td>''+
   ''<td class=headerbold>Introduction Type</td>''+
   ''<td class=headerbold>Registration Date</td>''+
   ''<td class=headerbold>Vendor Request Type</td>''+
   ''<td class=headerbold>Vendor Type</td>''+
   ''<td class=headerbold>Priority</td>''+   
   ''<td class=headerbold>Vendor Name</td>''+
   ''<td class=headerbold>Vendor number</td>''+
   ''<td class=headerbold>Payment Terms</td>''+
   ''<td class=headerbold>Vendor Status</td>''+
   ''<td class=headerbold>Address Line 1</td>''+
   ''<td class=headerbold>Address Line 2</td>''+
   ''<td class=headerbold>City Address Line 3</td>''+
   ''<td class=headerbold>State Code</td>''+
   ''<td class=headerbold>Postal code (Zip code)</td>''+            
   ''<td class=headerbold>Optional Address 1</td>''+            
   ''<td class=headerbold>Optional Address 2</td>''+            
   ''<td class=headerbold>Vendor Email ID</td>''+            
   ''<td class=headerbold>Combined or Single</td>''+            
   ''<td class=headerbold>Tax ID</td>''+            
   ''<td class=headerbold>SSN Number</td>''+            
   ''<td class=headerbold>1099 Code</td>''+            
   ''<td class=headerbold>1099 Payee Name</td>''+
   ''<td class=headerbold>ACH</td>''+            
   ''<td class=headerbold>BAP Code</td>''+          
   ''<td class=headerbold>ABA Code</td>''+
   ''<td class=headerbold>Account Number</td>''+            
   ''<td class=headerbold>Exception Type</td>''+            
   ''<td class=headerbold>W9 Indicator</td>''+            
   ''<td class=headerbold>Additional Comments</td>''+
   ''<td class=headerbold>Approval Decision</td>''+      
 ''<td class=headerbold>Approvers Comments</td>''+         
   ''<td class=headerbold>Queue Entry Date</td>''
   +''</tr></font>''
UNION ALL 
      
   Select ''<tr><td align=left style=mso-number-format:\\@>''+ISNULL([Current_Work_Step],'''')+''</td>''+    
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Wi_Name],'''')+''</td>''+    
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Introduction_Type],'''')+''</td>''+   
   ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Registration_Date],''''),120)+''</td>''+  
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Request_Type],'''')+''</td>'' + 
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_type],'''')+''</td>'' + 
   ''<td align=left style=mso-number-format:\@>''+ISNULL([Priority],'''')+''</td>'' +   
   ''<td align=left style=mso-number-format:\@>''+ISNULL([Vendor_Name],'''')+''</td>'' + 
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Number],'''')+''</td>'' + 
   ''<td align=left style=mso-number-format:\@>''+ISNULL([Payment_Terms],'''')+''</td>'' + 
   ''<td align=left style=mso-number-format:\@>''+ISNULL([Vendor_Status],'''')+''</td>'' + 
   ''<td align=left style=mso-number-format:\@>''+ISNULL([Address_Line_1],'''')+''</td>'' + 
   ''<td align=left style=mso-number-format:\@>''+ISNULL([Address_Line_2],'''')+''</td>'' + 
   ''<td align=left style=mso-number-format:\@>''+ISNULL([City_Address_Line_3],'''')+''</td>'' + 
   ''<td align=left style=mso-number-format:\@>''+ISNULL([State_Code],'''')+''</td>'' + 
   ''<td align=left style=mso-number-format:\@>''+ISNULL([Postal_code],'''')+''</td>'' +
   ''<td align=left style=mso-number-format:\@>''+ISNULL([Optional_Address_1],'''')+''</td>'' + 
   ''<td align=left style=mso-number-format:\@>''+ISNULL([Optional_Address_2],'''')+''</td>'' +            
   ''<td align=left style=mso-number-format:\@>''+ISNULL([Vendor_Email_ID],'''')+''</td>'' +            
   ''<td align=left style=mso-number-format:\@>''+ISNULL([Combined_single_Payment],'''')+''</td>'' +            
   ''<td align=left style=mso-number-format:\@>''+ISNULL([Tax_ID_Number],'''')+''</td>'' +            
   ''<td align=left style=mso-number-format:\@>''+ISNULL([SSN_Number],'''')+''</td>''+        
   ''<td align=left style=mso-number-format:\@>''+ISNULL([V_1099_Code],'''')+''</td>'' +  
   ''<td align=left style=mso-number-format:\@>''+ISNULL([V_1099_Payee_Name],'''')+''</td>'' +  
   ''<td align=left style=mso-number-format:\@>''+ISNULL([ACH],'''')+''</td>'' +  
   ''<td align=left style=mso-number-format:\@>''+ISNULL([Bank_Account_Payment_Code],'''')+''</td>'' +  
   ''<td align=left style=mso-number-format:\@>''+ISNULL([Code],'''')+''</td>'' +  
   ''<td align=left style=mso-number-format:\@>''+ISNULL([Account_Number],'''')+''</td>'' +  
   ''<td align=left style=mso-number-format:\@>''+ISNULL([Exception_Type],'''')+''</td>'' +  
   ''<td align=left style=mso-number-format:\@>''+ISNULL([W9_Indicator],'''')+''</td>'' +  
   ''<td align=left style=mso-number-format:\@>''+ISNULL([Additional_Comments],'''')+''</td>'' +  
   ''<td align=left style=mso-number-format:\@>''+ISNULL([Approval_Decision],'''')+''</td>'' +  
   ''<td align=left style=mso-number-format:\@>''+ISNULL([Approvers_Comments],'''')+''</td>'' +           
   ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Entry_Time],''''),120)+''</td>''  
   from #TAVS_Queuestatus_Report_Temp' )          

   print @Query 
 select @status_temp='<tr></tr></tr></table><html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style><table border=1><tr>'+'<td class=headerbold><b>Queue Name </b></td><td class=headerbold><b>Workitems Processed</b></td></tr>'       

   DECLARE APVSSummaryException_Cursor CURSOR FAST_FORWARD FOR  
   Select Disp_QName,Count_Q from #TAVSQSummaryException           
   OPEN APVSSummaryException_Cursor     
   FETCH NEXT FROM APVSSummaryException_Cursor INTO  @Disp_QName,@Count_Q   
   WHILE @@FETCH_STATUS = 0 
   Begin 
   select @status_temp=@status_temp+'<tr><td align=left style=mso-number-format:\\@>'+convert(varchar(100),@Disp_QName)+'</td><td align=left style=mso-number-format:\\@>'+convert(varchar(100),@Count_Q)+'</td></tr>' 
   FETCH NEXT FROM APVSSummaryException_Cursor INTO @Disp_QName,@Count_Q 
  End 
 
  close APVSSummaryException_Cursor     
  Deallocate APVSSummaryException_Cursor  

--print @status_temp
  select @status_temp=@status_temp+'</table>'
  exec('insert into TA_TEMP_AUTOMAIL1 select '''+@status_temp+'''   ')      
  

 /*update TA_TEMP_AUTOMAIL1 set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yy>&nbsp</td>') */      

  select @dbname = DB_NAME()
  SET @Query='Master..xp_Cmdshell ''bcp "select Header FROM '+@dbname+'..TA_TEMP_AUTOMAIL1 order by row_index asc " queryout "'+@FileName+'" -c -T'', no_output  '  

  exec(@Query)
  insert into NG_AutoMail_Status values('TA VS Queue Status Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL) 
    --select @RowCount 
  drop table #TAVSQSummaryException 
  drop table #TAVS_Queuestatus_Report_Temp 
  drop table TA_TEMP_AUTOMAIL1 
       
 end
  select @RowCount
End 



<%@ page import="java.io.*,java.util.*,java.sql.*"%>
<%@ page import="java.text.*"%>

<%@ include file="customized.process" %>
<%@ page import="java.io.*" %>
<%@ page import="java.util.*" %>
<%@ page import="javax.servlet.*"%>
<%@ page import="java.text.DateFormat"%>
<%@ page import="java.text.SimpleDateFormat"%>
<%@ page import="javax.servlet.http.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>




<%
	String sYear     ="";
	String sMonth     ="";
	String sDay        ="";
	String sFileName          ="";
	String sReportName   ="VENDORCHANGEREPORT";
	String sProcedureNameKey  ="";
	String sColumnHeadersKey  ="";
	String sFileNameKey       ="";
	String sNumberOfColumnsKey="";
	String sDisp         ="";
	String sHeaderPresentKey  ="";
	String sDBMappedColsKey   ="";
	String sHeaderValue       ="";
	String sHeaderPresentValue="";
	String sCabinetName       ="";	
	String sDBMappedCols      ="";
	String sFieldValuesKey    ="";
	String sFieldValues       ="";
	String sUserMailID        ="";
	//added by chetan
	String sFromDate          =null;
	String sToDate            =null;
	String sFilePath          = "" ;
	String sApproverDesc	  =null;
	String sQueue 			 = null;
	String Vendor_Type  = null;
	String QC_descion = null;
   sFromDate = request.getParameter("RegFromDate");
	sToDate = request.getParameter("RegToDate");
	//-------------------

	
	
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAVSVendorChangeReport.ini";
	

	Properties ini = new Properties();
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						
						}
					}
				}
	

	//sProcessDefId=16;
	//sCabinetName="GMAC";

	//sProcedureName=sReportName+"_PROCEDURENAME";

	sYear = sReportName+"_Releaseyear";
     sMonth        =sReportName+"_Releasemonth";
     sDay =sReportName+"_Releaseday";
	 sDisp = sReportName+"_Releasedisp";
	 
	 
	 sYear = ini.getProperty(sYear);
	 sMonth = ini.getProperty(sMonth);
	 sDay = ini.getProperty(sDay);
	 sDisp = ini.getProperty(sDisp);
	 
	 System.out.println("Value of year"+sYear+"Month=="+sMonth+"Daye=="+sDay);
	 
	 %>


<HTML>
<HEAD>
<TITLE>Vendor Change Report</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>
<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
}
</style>

<script>
	var allWindows = new Array();
	var win; // new window object
	$(document).ready(function(){$('#From_Date_Q').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date_Q').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	
	});
	/*functions echeck,ValidateForm added by nilesh*/
	function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}
//---Added by Chetan
function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";

	sDate	= window.showModalDialog('/processmanager/reports/GMACReports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');




	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
}

function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	strResult=strdate+"/"+strMonth+"/"+stryear;
	return strResult;
}

function convertMonth(strMonth)
{
		if(strMonth=="JAN")
			strMonth="00";
		else if(strMonth=="FEB")
			strMonth="01";
		else if(strMonth=="MAR")
			strMonth="02";
		else if(strMonth=="APR")
			strMonth="03";
		else if(strMonth=="MAY")
			strMonth="04";
		else if(strMonth=="JUN")
			strMonth="05";
		else if(strMonth=="JUL")
			strMonth="06";
		else if(strMonth=="AUG")
			strMonth="07";
		else if(strMonth=="SEP")
			strMonth="08";
		else if(strMonth=="OCT")
			strMonth="09";
		else if(strMonth=="NOV")
			strMonth="10";
		else if(strMonth=="DEC")
			strMonth="11";
	   return strMonth;
}

function DateComparator(Date_To,Date_From)
{	

	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));	
	var Date_From_month=Date_From.substring(Date_From.indexOf("/")+1,Date_From.lastIndexOf("/"));
	
	/*converting ToDate month to number */
	if(Date_To_month=="JAN")
			Date_To_month="01";
		else if(Date_To_month=="FEB")
			Date_To_month="02";
		else if(Date_To_month=="MAR")
			Date_To_month="03";
		else if(Date_To_month=="APR")
			Date_To_month="04";
		else if(Date_To_month=="MAY")
			Date_To_month="05";
		else if(Date_To_month=="JUN")
			Date_To_month="06";
		else if(Date_To_month=="JUL")
			Date_To_month="07";
		else if(Date_To_month=="AUG")
			Date_To_month="08";
		else if(Date_To_month=="SEP")
			Date_To_month="09";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";


	/*converting FromDate month to number */
		if(Date_From_month=="JAN")
			Date_From_month="01";
		else if(Date_From_month=="FEB")
			Date_From_month="02";
		else if(Date_From_month=="MAR")
			Date_From_month="03";
		else if(Date_From_month=="APR")
			Date_From_month="04";
		else if(Date_From_month=="MAY")
			Date_From_month="05";
		else if(Date_From_month=="JUN")
			Date_From_month="06";
		else if(Date_From_month=="JUL")
			Date_From_month="07";
		else if(Date_From_month=="AUG")
			Date_From_month="08";
		else if(Date_From_month=="SEP")
			Date_From_month="09";
		else if(Date_From_month=="OCT")
			Date_From_month="10";
		else if(Date_From_month=="NOV")
			Date_From_month="11";
		else if(Date_From_month=="DEC")
			Date_From_month="12";
	
	var Date_To_date=Number(Date_To.substring(Date_To.indexOf("0"),Date_To.indexOf("/")));	
	var Date_From_date=Number(Date_From.substring(Date_From.indexOf("0"),Date_From.indexOf("/")));

		
	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));
	var Date_From_year=Number(Date_From.substring(Date_From.lastIndexOf("/")+1,Date_From.length));
	
	//alert("whole date"+Date_From);
		

	if(Date_To_year<Date_From_year)
	{
		alert("To Date cannot be less than From  Date.");
		return false;
	}


	else if(Date_To_year>Date_From_year)
	{
		
		//if(Date_From_month>Date_To_month)
		//{
		//alert("To Date can not be less than From Date.");
		//return false;
		//}
		 if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{
				
				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}


	else if(Date_To_year==Date_From_year)
	{
	
		if(Date_From_month>Date_To_month)
		{
		alert("To Date can not be less than From Date.");
		return false;
		}
		else if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{

				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}
	
	// added for report change
	
		var FromDay = Date_From.split("/")[0];
			var FromMonth = convertMonth(Date_From.split("/")[1]);
			var FromYear = Date_From.split("/")[2];
			
			//alert("From:::Day::"+FromDay+"  Month::"+FromMonth+"	Year::"+FromYear);
			
			var ToDay = Date_To.split("/")[0];
			var ToMonth = convertMonth(Date_To.split("/")[1]);
			var ToYear = Date_To.split("/")[2];
			
			//alert("To:::Day::"+ToDay+"  Month::"+ToMonth+"	Year::"+ToYear);
			
			var CurrentDate=new Date();
			var CurrentDay = CurrentDate.getDate();
			var CurrentMonth = CurrentDate.getMonth();
			var CurrentYear = CurrentDate.getFullYear();
			var rday= <%=sDay%>;
			var rmonth = <%=sMonth%>;
			var ryear = <%=sYear%>;
			
			//alert("Current:::Day::"+CurrentDay+"  Month::"+CurrentMonth+"	Year::"+CurrentYear);

			var toDate = (new Date(ToYear,ToMonth,ToDay)).getTime();
			var fromDate = (new Date(FromYear,FromMonth,FromDay)).getTime();
			var CurrentDate = (new Date(CurrentYear,CurrentMonth,CurrentDay)).getTime();
			//var pastDate = (new Date("<%=sYear%>","<%=sMonth%>","<%=sDay%>")).getTime();
			var pastDate = (new Date(ryear,rmonth,rday)).getTime();
			
			
			//alert("day="+rday+"rmonth"+rmonth+"year"+ryear);
			//alert("Current date"+CurrentDate);
			
			//alert("CurrentYear"+CurrentYear);
			//alert("CurrentMonth"+CurrentMonth);
			//alert("CurrentDay"+CurrentDay);
			
			if(fromDate > toDate)
			{
				alert("To Date cannot be less than From Date.");
				return false;
			}
			else if(fromDate > CurrentDate)
			{
				alert("From Date cannot be future date.");
				return false;
			}
			else if(toDate > CurrentDate)
			{
				alert("To Date cannot be future date.");
				return false;
			}
			
			if(pastDate>fromDate)
			{
				var dispdate = "<%=sDisp%>";
				alert("From Date cannot be less than "+dispdate);
				return false;
			}
	
	/*if(Date_From_year<'2018')
	{
		alert("inside year"+Date_From_year.value);
		if(Date_From_month<'03')
		{
			alert("inside month"+Date_From_month);
			if(Date_From<'1')
			{
				
				alert("inside day"+Date_From);

				alert("From date should not be less than date of report release");
				return false;
			}
		}
	}*/
	
	
return true;
}
	
function ValidateForm(emailID){
//	var emailID=document.frmSample.txtEmail
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }
 

	
function openreport()
{	

		var sQueue="";
		var bQueueSelected=false;
		var docselected=false;
		var UserEmailID=document.getElementById('EMail-ID').value;//added by nilesh
		var RegDateRangeFrom="";
		var RegDateRangeTo="";
		var QDateRangeFrom="";
		var QDateRangeTo="";
		var DocumentCategory="";
		var VendorNumber="";
		var VendorName="";
		var sDocCat="";
		//alert(document.forms["textForm"].Queue.length);
		
		for(var i=0;i<document.forms["textForm"].Queue.length;i++)
		{
			if(document.forms["textForm"].Queue[i].selected)
			{
				sQueue=sQueue+document.forms["textForm"].Queue[i].value+'~';
				bQueueSelected=true;
			}

		}
		//alert(bQueueSelected);
		/*if(!bQueueSelected)
		{
			alert("Please Select Queue.");
			return false;
		}*/
		for(var i=0;i<document.forms["textForm"].Vendor_Type.length;i++)
		{
			if(document.forms["textForm"].Vendor_Type[i].selected)
			{
				
				DocumentCategory=DocumentCategory+document.forms["textForm"].Vendor_Type[i].value+'~';
				docselected=true;
				
			}
		}
		//alert("Queue=="+sQueue);
		//alert("Vendor Type"+DocumentCategory);
		if(docselected){
		sDocCat=DocumentCategory.split('~');
				}
				
				
				
		
		//if(document.getElementById('Queue_Date').checked)
		//{
			QDateRangeFrom=document.forms["textForm"].From_Date_Q.value;
			QDateRangeTo=document.forms["textForm"].To_Date_Q.value;	
		//}

			VendorNumber=document.forms["textForm"].QC_Decision.value;
			VendorName=document.forms["textForm"].Approver_Decision.value;
		
	//	alert("QC Decsion"+VendorNumber);
	//	alert("Approver_Decision"+VendorName);
		
			var sTestQueue=sQueue.split('~');
			

		//---------------------------------------------------
		
		
		/*if(!document.getElementById('Registration').checked && !document.getElementById('Queue_Date').checked)
		{
		alert("Please Select Queue Date Or Registration Date");
		return false;
		}
		else{
		if(document.getElementById('Registration').checked){
		if(RegDateRangeFrom=='')
		{
			alert("Please select an appropriate Registration FromDate");
				return false;
		}
		if(RegDateRangeTo==''){
			alert("Please select an appropriate Registration ToDate");
				return false;
		}
		}
		
		if(document.getElementById('Queue_Date').checked){
		if(QDateRangeFrom=='')
		{
			alert("Please select an appropriate Queue FromDate");
				return false;
		}
		if(QDateRangeTo==''){
			alert("Please select an appropriate Queue ToDate");
				return false;
		}
		}
		}*/

		if(QDateRangeFrom=='')
		{
			alert("Please select an appropriate Approval FromDate");
				return false;
		}
		if(QDateRangeTo==''){
			alert("Please select an appropriate Approval ToDate");
				return false;
		}
		
		if(sQueue.indexOf("All")!=-1 && sTestQueue.length>2)
		{
			alert("No other Queue Name can be chosen after choosing All");
			return false;
			//sQueue='All~';

		}
		if(DocumentCategory.indexOf("All")!=-1 && sDocCat.length>2)
		{
			alert("No other Vendor Type can be chosen after choosing All");
			return false;
			//QueueName='All~';
		}
		
		
		if(sQueue=='Cancel~ChangeQC~Exit~PendingResolution~QC~UpdateVendorChanges~VendorApproval~VendorSetup~')
		{
			sQueue='All~';
			
		}
		if(DocumentCategory=='Escheatment vendors~Licensing and filing fee vendors~Non PO Vendors~PO vendors~Policyholder vendors~Tax vendors~')
		{
			DocumentCategory='All~';
			}
		
		if(!DateComparator(RegDateRangeTo,RegDateRangeFrom))
		{
		return false;
		}
		else if(!DateComparator(QDateRangeTo,QDateRangeFrom))
		{
		return false;
		}
		
		if(UserEmailID=='')
		{
			alert("Kindly enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
				
			}
		}
		
		
		var query="vendorchangeGenerate.jsp?sQueue="+sQueue+"&DocumentCategory="+DocumentCategory+"&VendorNumber="+VendorNumber+"&VendorName="+VendorName+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID;
			
			//alert(query);
			
			//OpenRedict-Fix
    //window.top.VENDORCHANGEREPORT.location.href="vendorchangeGenerate.jsp?sQueue="+sQueue+"&DocumentCategory="+DocumentCategory+"&VendorNumber="+VendorNumber+"&VendorName="+VendorName+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+QDateRangeFrom+"&RegToDate="+QDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID;	var StrOpenWin=strip_tags("..\\..\\..\\..\\webdesktop\\CustomForms\\TA_AP_Custom\\AP\\srcCodingLine\\MultilineMain1.jsp?WI_Name="+WI_Name+"&AP_Status="+AP_Status+"&Payment_Type="+Payment_Type+"&Total_Invoice_Amount="+Total_Invoice_Amount+"&Document_Category="+Document_Category+"&Balance1="+Balance+"&Missing_Code_Combination1="+Missing_Code_Combination+"&Pay_Entity1="+Pay_Entity+"&Missing_paying_Entity1="+Missing_paying_Entity+"&Sales_Tax_Applicable1="+Sales_Tax_Applicable+"&Wire_Transfer_form_number1="+Wire_Transfer_Form_Number+"&Total_of_Line_amount1="+Total_Of_Line_Amount+"&Specific_Limit1="+Specific_Limit_chk+"&Specific1="+Specific_Limit_Type+"&Sales1="+Sales_Tax_Amount+"&Approved1="+Approved_Invoice_Amount+"&email_ID11="+Approvers_Email_ID1+"&Short1="+Short_Pay_Comments+"&Coder_Comment1="+Coders_Comment+"&Remittance1="+Remittance_Message+"&Intercompany_Flag1="+Intercompany_Flag+"&Parent_Company1="+Parent_Company+"&Foreign_Currency_Flag1="+Foreign_Currency_Flag+"&Missing_Cost_centre_owner1="+Missing_Cost_Centre_Owner+"&SpecificLimitType1="+SpecificLimitType+"&MaxCostCenter1="+MaxCostCenter+"&Approve_Emp_ID1="+Approver_Emp_ID+"&Approve_Emp_Name1="+Approver_Emp_Name+"&BU1="+Business_Unit+"&CCO_Emp_ID1="+CCO_Employee_ID+"&CCO_Emp_Email_ID1="+CCO_Employee_Email_ID+"&CCO_Employee_Name1="+CCO_Employee_Name+"&AP_Check1="+AP_Check+"&return_check11="+return_check+"&ACH1="+ACH+"","");
	var URI = "vendorchangeGenerate.jsp?sQueue="+sQueue+"&DocumentCategory="+DocumentCategory+"&VendorNumber="+VendorNumber+"&VendorName="+VendorName+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+QDateRangeFrom+"&RegToDate="+QDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID;
	var StrOpenWin=strip_tags(URI,"");
	window.top.VENDORCHANGEREPORT.location.href=StrOpenWin;
		
		/*
	if(document.getElementById('Registration').checked)
		{
		 if((UserEmailID!='')&&(RegDateRangeTo!="")&&(RegDateRangeFrom!="")&&(sQueue!=""))
			{	
			var query="vendorchangeGenerate.jsp?sQueue="+sQueue+"&DocumentCategory="+DocumentCategory+"&VendorNumber="+VendorNumber+"&VendorName="+VendorName+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID;
			
			//alert(query);
			window.top.APPROVALPROCESSQUEUESTATUS.location.href="vendorchangeGenerate.jsp?sQueue="+sQueue+"&DocumentCategory="+DocumentCategory+"&VendorNumber="+VendorNumber+"&VendorName="+VendorName+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID;
			}
		}
	else if(document.getElementById('Queue_Date').checked)
	{
	 if((UserEmailID!='')&&(QDateRangeTo!="")&&(QDateRangeFrom!="")&&(sQueue!=""))
			{	
			var query="vendorchangeGenerate.jsp?sQueue="+sQueue+"&DocumentCategory="+DocumentCategory+"&VendorNumber="+VendorNumber+"&VendorName="+VendorName+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID;
		//	alert(query);
			window.top.APPROVALPROCESSQUEUESTATUS.location.href="vendorchangeGenerate.jsp?sQueue="+sQueue+"&DocumentCategory="+DocumentCategory+"&VendorNumber="+VendorNumber+"&VendorName="+VendorName+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID;
			}
	
	}*/
			
      
		
		
  }

	
	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}

	//malkeet
	function chkradio(obj)
	{
		if(obj == 'r')
		{
			if(document.getElementById('Queue_Date').checked == true) 
			{
				document.getElementById('Queue_Date').checked = false;
			}
			document.getElementById('From_Date_Q').value='';
			document.getElementById('To_Date_Q').value='';
			//commented by megha
			//document.getElementById('From_Date_Q').style.backgroundColor='grey';
			//document.getElementById('To_Date_Q').style.backgroundColor='grey';
			//document.getElementById('From_Date_IMG_Queue').disabled=true;
			//document.getElementById('To_Date_IMG_Queue').disabled=true;
			//document.getElementById('From_Date_IMG_Reg').disabled=false;
			//document.getElementById('To_Date_IMG_Reg').disabled=false;
			document.getElementById('From_Date_Reg').style.backgroundColor='white';
			document.getElementById('To_Date_Reg').style.backgroundColor='white';
		}
		else if(obj == 'q')
		{
			if(document.getElementById('Registration').checked == true) 
			{
				document.getElementById('Registration').checked = false;
			}
			document.getElementById('From_Date_Q').style.backgroundColor='white';
			document.getElementById('To_Date_Q').style.backgroundColor='white';
			document.getElementById('From_Date_Reg').style.backgroundColor='grey';
			document.getElementById('To_Date_Reg').style.backgroundColor='grey';
			//document.getElementById('From_Date_IMG_Reg').disabled=true;
			//document.getElementById('To_Date_IMG_Reg').disabled=true;
			document.getElementById('From_Date_Reg').value='';
			document.getElementById('To_Date_Reg').value='';

			//document.getElementById('From_Date_IMG_Queue').disabled=false;
			//document.getElementById('To_Date_IMG_Queue').disabled=false;
		}

	}
	
	function disbFields()
 {
 	document.getElementById('From_Date_Q').value='';
	document.getElementById('To_Date_Q').value='';
	//document.getElementById('From_Date_Reg').value='';
	//document.getElementById('To_Date_Reg').value='';
	//document.getElementById('From_Date_IMG_Queue').disabled=true;
	//document.getElementById('To_Date_IMG_Queue').disabled=true;
	//document.getElementById('From_Date_IMG_Reg').disabled=true;
	//document.getElementById('To_Date_IMG_Reg').disabled=true;
	//commented by megha as breaking the code
	
 	//document.getElementById('From_Date_Q').style.backgroundColor='grey';
	//document.getElementById('To_Date_Q').style.backgroundColor='grey';
	//document.getElementById('From_Date_Reg').style.backgroundColor='grey';
	//document.getElementById('To_Date_Reg').style.backgroundColor='grey';

 }
</script>


<body topmargin="0" leftmargin="5" onunload="UnloadReportWindow(); "  onload="disbFields();">

			<form name='textForm' method=post>


			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">Vendor Change Report</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This report will provide the list of WI with Request type as �Change� and Approved on selected date range. This report is output of Vendor Change Audit trail along with workiteam numbers. 
Select the Approval date range for generating the report for the same. 
.
</td></tr>
<tr><td class="EWLabel1"><b>Date Range is mandatory.</b>
</td></tr>
				
			</table>

		

			<table border="0" width="95%" cellspacing="1" align="center">
			
				<tr>
					<td class="EWLabel1" align="left" width='20%'><b>Queue</b></font></td>
					<td width='25%' colspan=3>
					<select name="Queue" multiple>
					<option value="All">All</option>
					<option value="VendorSetup">VendorSetup</option>
					<option value="VendorApproval">VendorApproval</option>
					<option value="UpdateVendorChanges">UpdateVendorChanges</option>
					<option value="QC">QC</option>
					<option value="PendingResolution">PendingResolution</option>
					<option value="Exit">Exit</option>
					<option value="ChangeQC">ChangeQC</option>
					<option value="Cancel">Cancel</option>
					
				
					</select>
					</td>
				</tr>
				
				 <tr>
					<td class="EWLabel1" align="left" width='20%'><b>Vendor Type</b></font></td>
					<td width='25%' colspan=3>
					<select name="Vendor_Type" multiple>
					<option value="All">All</option>
					<option value="Escheatment vendors">Escheatment vendors</option>
					<option value="Licensing and filing fee vendors">Licensing and filing fee vendors</option>
					<option value="Non PO Vendors">Non PO Vendors</option>
					<option value="PO vendors">PO vendors</option>
					<option value="Policyholder vendors">Policyholder vendors</option>
					<option value="Tax vendors">Tax vendors</option>
					
					
				
					</select>
					</td>
				</tr>

				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Approver Decision</b></td>
					<td >
					<select name="Approver_Decision">
					<option value="All">All</option>
					<option value="Approved">Approved</option>
					
					
				
					</select>
					
					</td>
				</tr>
				
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Change QC Decision</b></td>
					<td >
					<select name="QC_Decision">
					<option value="All">All</option>
					<option value="Pass">Pass</option>
					<option value="Fail">Fail</option>
					
					
				
					</select>
					
					
					</td>
				</tr>
				
				 
                <!-- Added by Chetan for displaying Date range from and to field...-->
				<!--<tr>
					<td>
					<p class="EWLabel122" ><input type = "radio" name ="Registration" id ="Registration" value = "Registration" align='left' style="width: 10px" onClick="chkradio('r')">&nbsp;Registration Date*</p></td>
					</tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date_Reg" readonly type="text"  id="From_Date_Reg" >
					<input type="image" id="From_Date_IMG_Reg" Title="Click to select Date."  onclick="ShowCalendar('From_Date_Reg');return false;" src="/processmanager/reports/GMACReports/GMAC/Calendar/images/Calendar.gif" border="0">
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date_Reg" readonly type="text"  id="To_Date_Reg" >
					<input type="image" id="To_Date_IMG_Reg" Title="Click to select Date."  onclick="ShowCalendar('To_Date_Reg');return false;" src="/processmanager/reports/GMACReports/GMAC/Calendar/images/Calendar.gif" border="0">
					</td>

				</tr>-->
				
				<tr>
					<td>
					<p class="EWLabel122" >&nbsp;Approval Date*</p></td>
					</tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date_Q" type="text" readonly id="From_Date_Q" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date_Q" readonly type="text"  id="To_Date_Q" >
					
					</td>

				</tr>
				<!-- --------------------------------------------------- -->
				<!--added by nilesh for displaying Emaild field -->

				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID*</b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>
				
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>
	
			
			</form>
</body>
</Html>	 




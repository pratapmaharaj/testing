
<%@ include file="customized.process" %>
<%@ page import="java.io.*" %>
<%@ page import="java.util.*" %>
<%@ page import="javax.servlet.*"%>
<%@ page import="java.text.DateFormat"%>
<%@ page import="java.text.SimpleDateFormat"%>
<%@ page import="javax.servlet.http.*"%>
<%@ page import="java.text.*"%>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="com.newgen.wfdesktop.xmlapi.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>


<HTML>
<HEAD>
<TITLE>Vendor Setup Approval Status Report</TITLE>

</HEAD>
<link href="/processmanager/omniflow/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>

<body topmargin="0" leftmargin="5" >
<%
	String sProcedureName     ="";
	String sColumnHeaders     ="";
	String sReportName        ="";
	String sFileName          ="";
	String sNumberOfColumns   ="";
	String sProcedureNameKey  ="";
	String sColumnHeadersKey  ="";
	String sFileNameKey       ="";
	String sNumberOfColumnsKey="";
	String sHeaderKey         ="";
	String sHeaderPresentKey  ="";
	String sDBMappedColsKey   ="";
	String sHeaderValue       ="";
	String sHeaderPresentValue="";
	String sCabinetName       ="";	
	String sDBMappedCols      ="";
	String sFieldValuesKey    ="";
	String sFieldValues       ="";
	String sUserMailID        ="";
	//added by chetan
	String sFromDate          =null;
	String sToDate            =null;
	String sFilePath          = "" ;
	String sApproverDesc	  =null;
	String sQueue 			 = null;
	String Vendor_Type  = null;
	String QC_descion = null;
   sFromDate = request.getParameter("RegFromDate");
	sToDate = request.getParameter("RegToDate");
	//-------------------

	sReportName	  =request.getParameter("ReportName");
	sUserMailID   =request.getParameter("UserEmailID");
	sApproverDesc =request.getParameter("VendorName");
	sQueue        = request.getParameter("sQueue");
	Vendor_Type = request.getParameter("DocumentCategory");
	QC_descion  = request.getParameter("VendorNumber");
	
	
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAVSVendorChangeReport.ini";
	

	Properties ini = new Properties();
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						
						}
					}
				}

	//sProcessDefId=16;
	sCabinetName="GMAC";

	sProcedureName=sReportName+"_PROCEDURENAME";

	sFilePath = sReportName+"_FILEPATH";
     sFileNameKey        =sReportName+"_FILENAME";
     sNumberOfColumnsKey =sReportName+"_NUMBEROFCOLUMNS";
	 sFieldValuesKey     =sReportName+"_FIELDVALUES";
	 sNumberOfColumns  = sReportName+"_NUMBEROFCOLUMNS";

    sFieldValues=ini.getProperty(sFieldValuesKey);
	//sFieldValues=sFieldValues.replaceAll("#",",");
	
	sFilePath = ini.getProperty(sFilePath);
	sFileNameKey = ini.getProperty(sFileNameKey);
	sNumberOfColumnsKey = ini.getProperty(sNumberOfColumnsKey);
	sProcedureName = ini.getProperty(sProcedureName);
	sNumberOfColumns = ini.getProperty(sNumberOfColumns);
	//sFilePath = "//10.33.186.136/crebsfs";
    sFileName        ="Vendor_Change";
	//sNumberOfColumns ="44";
	//sProcedureName = "WNS_TA_AP_Vendor_Change_report" ;

	String sCabname             = null;
	String sSessionId           = null;
	String sJtsIp               = null;
	String sUserName            = null;
	String sReportProcedureName =null;
	String sReportTableName=null;

	String VendorType=request.getParameter("Vendor_Type");
	String sVendorReqTyep=request.getParameter("Vendor_Request_Type");
	
	//log("tarit1"+VendorType);
	Date CurrDate     =new Date();
	DateFormat dt     = new SimpleDateFormat("dd-MMM-yyyy");
	String sCurrdate  =dt.format(CurrDate);

	String sOutputXML   ="";
	String sInputXML    ="";
	String maincode     ="";
	String Totalrec     ="0";
	String sStr_ServerType = null;
	

	String url = "";
	String Status="";

	double fPercentage=0;
	String sRowXml="";
	

	int iJtsPort = 0;
	boolean bError=false;
	
	try
	{

		/*sCabinetName=wfSession.getM_strCabName();
		sSessionId = wfSession.getM_strSessionID();
		sJtsIp = wfSession.getM_objCabinet().getM_strServerIP();
		iJtsPort = wfSession.getM_objCabinet().getM_iServerPort();
		sStr_ServerType = wfSession.getM_objCabinet().getM_strServerType();*/
		sCabinetName=wfsession.getEngineName();	
		sSessionId = wfsession.getSessionId();	
		sJtsIp = wfsession.getJtsIp();
		iJtsPort = wfsession.getJtsPort();
	}
	catch(Exception ignore)
	{	
		
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp->161->"+ignore.toString()+"</b></font>");
		bError= true;
	}
	
if(!bError)
	{

	
	/* WNS_TA_AP_Vendor_Change_report '01/JAN/2016','25/APR/2018','All~','','','','suhas.walke@wns.com','TA_AP_Vendor_change_report','//10.33.186.136/crebsfs','' 

@From_Date_Q varchar(200),                  
@To_Date_Q varchar(200),                  
@Queue varchar(200),                  
@Vendor_Type varchar(200),
@Approver_Decision varchar(200),
@QC_Decision varchar(200),                    
@Email_Id varchar(200),                  
@FileName varchar(200),                     
@Path varchar(200),                  
@RowCount varchar(50) out   

	*/

WriteLog("VENDOR_CHANGE_STATUS_REPORT","Before input xl ::> Report Name : "+sReportName+ "File name"+sFileNameKey+"number of coloumn"+sNumberOfColumnsKey);
WriteLog("VENDOR_CHANGE_STATUS_REPORT","Before input xl ::> Path  Name : "+sFilePath);
	
WriteLog("VENDOR_CHANGE_STATUS_REPORT","Before input xl ::> VendorType : "+VendorType+" sFieldValues "+sFieldValues+ " sFromDate "+sFromDate+" sToDate  "+sToDate+" sUserMailID "+sUserMailID+" File Path "+sFilePath+" File Name"+sFileName);


				 sInputXML =  "<?xml version=\"1.0\"?>\n"
            + "<WFTestMethod_Input>\n"
            + "<Option>NG_execute_Result</Option>\n"
            + "<ProcName>"+sProcedureName+"</ProcName>\n"
           +"<Params>'"+sFromDate+"','"+sToDate+"','"+sQueue+"','"+Vendor_Type+"','"+sApproverDesc+"','"+QC_descion+"','"+sUserMailID+"','"+sFileName+"','"+sFilePath+"','"+sColumnHeaders+"' </Params>\n"
            + "<NoOfCols>1</NoOfCols>\n"
            + "<EngineName>"+sCabinetName+ "</EngineName>\n"
            + "<SessionId>" + sSessionId + "</SessionId>\n"
            + "</WFTestMethod_Input>";



WriteLog("VENDOR_CHANGE_STATUS_REPORT","sInputXML ::> sInputXML : "+sInputXML);

  try
		{
			
		//sOutputXML = WFCallBroker.execute(sStr_ServerType,"",sInputXML,sJtsIp,iJtsPort,1);
		sOutputXML = WFCallBroker.execute(sInputXML,sJtsIp,iJtsPort,1);
    	WriteLog("VENDOR_CHANGE_STATUS_REPORT","sOutputXML ::> sOutputXML : "+sOutputXML);
		
        if(sOutputXML.equals("") || Integer.parseInt(sOutputXML.substring(sOutputXML.indexOf("<MainCode>")+10 , sOutputXML.indexOf("</MainCode>")))!=0)
		   {
		WriteLog("VENDOR_CHANGE_STATUS_REPORT","sOutputXML ::> inside line 202 : ");
			bError= true;
			maincode=sOutputXML.substring(sOutputXML.indexOf("<MainCode>")+10 , sOutputXML.indexOf("</MainCode>"));
			%>
				<script>alert("Internal Server error. Please logout and try again.\nIf problem persists then contact to the support team.");</script>
			<%
		}


			else
			{
		    	WriteLog("VENDOR_CHANGE_STATUS_REPORT","sOutputXML ::> inside line 213 : ");

				try
							{

                 String sReturnValue=sOutputXML.substring(sOutputXML.indexOf("<Results>")+9,sOutputXML.indexOf("</Results>"));
				int iReturnValue=Integer.parseInt(sReturnValue);
                 WriteLog("VENDOR_CHANGE_STATUS_REPORT","iReturnValue ::> inside line 220 : "+iReturnValue);
								if(iReturnValue==0)
								{
											    	WriteLog("VENDOR_CHANGE_STATUS_REPORT","sOutputXML ::> inside line 223 : ");
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
								out.println(ig.toString());
												
							}

			}


		}
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
		}

		
	}
	
	%>

	
			

<%!
 public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }


%>
			
			
		
				


			
			





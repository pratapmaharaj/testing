/*    
[WNS_AP_AP_Coder_Code] '01/JAN/2014','25/FEB/2014','All~','','asdas@asdsa.com',    
'malkeet','//10.33.192.139/XLS-File/kalsi',''    
    
*/    
    
CREATE procedure [dbo].[WNS_AP_AP_Coder_Code]    
(    
@From_Date_Q varchar(200),    
@To_Date_Q varchar(200),    
@Document_Category varchar(200),    
@Coder_Code varchar(200),      
@Email_Id varchar(200),    
@FileName varchar(200),       
@Path varchar(50),    
@RowCount varchar(50) out                             
)      
as     
declare     
@WhereQuery varchar(2000),                            
@Query varchar(max),                                                         
@Tables varchar(200),                            
@OrderBy varchar(300),    
@sDocument_Category varchar(400)    
                            
begin    
Set nocount on       
 set @FileName=@Path+'/'+@Email_Id+'_'+@FileName+'_'+convert(varchar,getdate(),104)+'.xls'      
 --set @FileName='//10.33.192.139/XLS-File/ProcessManager/reports/Gmac report/AP/'+@Email_Id+'maklkeet'+convert(varchar,getdate(),104)+'.xls'                                                   
 set @WhereQuery=' WHERE Current_work_step=''Coding'' '      
 set @Tables=' WNS_TA_AP_EXT_Table with(nolock)'     
 set @OrderBy=' order by wi_name,Current_work_step'        
 set @sDocument_Category=''      
  
print @WhereQuery    
Create table #AP_Coder_Code_Temp    
(    
Queue_Name varchar (100),  
WI_Name varchar (100),  
Registration_Date varchar (100),  
Document_category varchar (100),  
Priority varchar (100),  
coder_code varchar (100),  
Pay_entity varchar (100),  
Vendor_Name varchar (100),  
Vendor_ID varchar (100),  
Invoice_Number varchar (100),  
Invoice_Amount varchar (100),  
Invoice_Date varchar (100),  
Comments varchar (100),  
Coder_comment varchar (100),  
Status1  varchar (100)   
)     
    
 if(rtrim(ltrim(@Document_Category))<>'All~')      
  BEGIN      
    if(len(@Document_Category)=charindex('~',@Document_Category))      
     BEGIN                     
       set @sDocument_Category=ltrim(rtrim(substring(@Document_Category,0,len(@Document_Category))))      
       print @sDocument_Category      
       set @WhereQuery=@WhereQuery+' and Document_Category='''+@Document_Category+''''      
     End      
    else      
     BEGIN               
       while (charindex('~',@Document_Category)>1)      
      BEGIN      
      set @sDocument_Category = @sDocument_Category + ''''+ltrim(rtrim(SUBSTRING(@Document_Category,1,Charindex('~',@Document_Category)-1)))+''''+','      
      set @Document_Category=ltrim(rtrim(Substring(@Document_Category,Charindex('~',@Document_Category)+len('~'),len(@Document_Category))))      
      END                                 
      set @sDocument_Category=SUBSTRING(@sDocument_Category,0,len(@sDocument_Category))       
      set @WhereQuery=@WhereQuery+' and Document_Category in('+@sDocument_Category+')'         
    END      
 End    
  
if(rtrim(ltrim(@From_Date_Q))<>'')      
  SET @From_Date_Q = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@From_Date_Q,121)))))                             
      
 if(rtrim(ltrim(@To_Date_Q))<>'')      
  SET @To_Date_Q = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@To_Date_Q,121)))))                        
      
 if(rtrim(ltrim(@From_Date_Q)) != '' and rtrim(ltrim(@To_Date_Q)) != '')                   
 BEGIN      
  set @WhereQuery = @WhereQuery+' and Entry_Time BETWEEN '''+@From_Date_Q+''' AND '''+@To_Date_Q+''''      
 END      
    
    
if(rtrim(ltrim(@Coder_Code))<>'')    
Begin    
set @WhereQuery = @WhereQuery+' and Coder_Code='''+@Coder_Code+''''    
End    
    
  
print @WhereQuery    
end    
set @Query=''    
set @Query='insert into #AP_Coder_Code_Temp select   
Current_Work_Step,WI_Name,Registration_Date,Document_Category,Priority,Coder_Code,Pay_Entity,Vendor_Name,Vendor_Number,Invoice_Number,Total_Invoice_Amount,Invoice_Date,invoice_comment,Coders_Comment,AP_Status  
 from '+@Tables+ @WhereQuery+@OrderBy    
   
  
  
print @Query    
    
exec (@Query)    
    
--select * from #AP_Coder_Code_Temp    
select @RowCount=count(*) from #AP_Coder_Code_Temp                          
 if(@RowCount=0)                            
  Begin                            
  drop table #AP_Coder_Code_Temp                            
  End                                    
else                           
 Begin                                                    
                                 
if Object_ID ('NG_TEMP_AUTOMAIL') is not null                               
          BEGIN                               
          exec('drop table NG_TEMP_AUTOMAIL')                               
          END     
Create table NG_TEMP_AUTOMAIL (Header varchar(8000),Row_Index int IDENTITY(1,1) PRIMARY KEY )    
    
--select * from  NG_TEMP_AUTOMAIL                          
Exec('Insert into NG_TEMP_AUTOMAIL                                   
                Select ''<html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>                           
  
      
<table border=1><tr>  
<td class=headerbold>Queue Name</td>''+                                  
''<td class=headerbold>WI Name</td>''+                                                       
''<td class=headerbold>Registration Date</td>''+                          
''<td class=headerbold>Document category</td>''+                 
''<td class=headerbold>Priority</td>''+     
''<td class=headerbold>coder code</td>''+                     
''<td class=headerbold>Pay entity</td>''+                                
''<td class=headerbold>Vendor Name</td>''+                                
''<td class=headerbold>Vendor ID</td>'' +                          
''<td class=headerbold>Invoice Number</td>''+                        
''<td class=headerbold>Invoice Amount</td>''+     
''<td class=headerbold>Invoice Date</td>''+     
''<td class=headerbold>Comments</td>''+     
''<td class=headerbold>Coder comment</td>''+     
''<td class=headerbold>Status</td>''+                               
''</tr></font>''                                   
UNION ALL                                
Select ''<tr><td align=left style=mso-number-format:\\@>''+ISNULL(Queue_Name,'''')+''</td>''+                                   
''<td align=left style=mso-number-format:\\@>''+ISNULL(WI_Name,'''')+''</td>''+            
 ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL(Registration_Date,''''),120)+''</td>''+                  
''<td align=left style=mso-number-format:\\@>''+ISNULL([Document_Category],'''')+''</td>''+                         
''<td align=left style=mso-number-format:\\@>''+ISNULL(Priority,'''')+''</td>''+                          
''<td align=left style=mso-number-format:\\@>''+ISNULL(coder_code,'''')+''</td>''+       
''<td align=left style=mso-number-format:\\@>''+ISNULL(Pay_entity,'''')+''</td>''+       
 ''<td align=left style=mso-number-format:\\@>''+ISNULL(Vendor_Name,'''')+''</td>''+       
 ''<td align=left style=mso-number-format:\\@>''+ISNULL(Vendor_ID,'''')+''</td>''+      
 ''<td align=left style=mso-number-format:\\@>''+ISNULL(Invoice_Number,'''')+''</td>''+    
 ''<td align=left style=mso-number-format:\\@>''+ISNULL(Invoice_Amount,'''')+''</td>''+    
 ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL(Invoice_Date,''''),120)+''</td>''+    
 ''<td align=left style=mso-number-format:\\@>''+ISNULL(Comments,'''')+''</td>''+    
 ''<td align=left style=mso-number-format:\\@>''+ISNULL(Coder_comment,'''')+''</td>''+    
 ''<td align=left style=mso-number-format:\\@>''+ISNULL(Status1,'''')+''</td>''                           
from #AP_Coder_Code_Temp')                           
       
       
   --select * from NG_TEMP_AUTOMAIL       
       
   print @FileName                 
update NG_TEMP_AUTOMAIL set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yy>&nbsp</td>')                            
SET @Query='Master..xp_Cmdshell ''bcp "select Header FROM GMAC..NG_TEMP_AUTOMAIL" queryout "'+@FileName+'" -c -T'',No_output'                                 
--print @Query                          
exec(@Query)                                
insert into NG_AutoMail_Status values('GMAC Coder Code Report',''+@FileName+'',''+@Email_Id+'',0,getdate(),NULL)                             
                               
drop table #AP_Coder_Code_Temp                                
drop table NG_TEMP_AUTOMAIL                                        
                                   
 End                               
select @RowCount 
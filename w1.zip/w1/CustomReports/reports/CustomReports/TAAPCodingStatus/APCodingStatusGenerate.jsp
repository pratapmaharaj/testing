<%@ include file="customized.process" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.sql.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="com.tcsta.util.PathUtil" %>

<HTML>
<HEAD>
<TITLE>AP Coding Status Report</TITLE>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="/../../../omniflow/scripts/wfgeneral.js">
</script>

<body >
<%!

 public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }
%>

<%
WriteLog("AP_Coding_Status","sOutputXML ::> sOutputXML : IN APAgingGenerate") ;

	String sProcessDefId=null;
	String sProcedureName=null;
	String sColumnHeaders=null;
	String sReportName=null;
	String sFileName=null;
	String sNumberOfColumns=null;
	String sProcedureNameKey=null;
	String sColumnHeadersKey=null;
	String sFileNameKey=null;
	String sNumberOfColumnsKey=null;
	String sHeaderKey=null;
	String sHeaderPresentKey=null;
	String sDBMappedColsKey=null;
	String sHeaderValue=null;
	String sHeaderPresentValue=null;
	String sCabinetName=null;	
	String sDBMappedCols=null;
	String sFieldValuesKey=null;
	String sFieldValues=null;
	String sFieldValuesReport="";
	String sUserMailID=null;
	String sFilePath=null;
	String sFilePathKey=null;
	String UserNames = "" ;
	
	sReportName	=request.getParameter("ReportName");
	sUserMailID=request.getParameter("UserEmailID");
	sReportName	=sReportName.toUpperCase();
	
	WriteLog("AP_Coding_Status","sReportName : "+sReportName) ;
	WriteLog("AP_Coding_Status","sUserMailID : "+sUserMailID) ;

	sProcedureNameKey=sReportName +"_PROCEDURENAME" ;
	WriteLog("AP_Coding_Status","sProcedureNameKey : "+sProcedureNameKey) ;
	
	sColumnHeadersKey=sReportName+"_COLUMNHEADERS";
	
	WriteLog("AP_Coding_Status","sColumnHeadersKey : "+sColumnHeadersKey) ;
	sFileNameKey=sReportName+"_FILENAME";

	WriteLog("AP_Coding_Status","sFileNameKey : "+sFileNameKey) ;

	sNumberOfColumnsKey=sReportName+"_NUMBEROFCOLUMNS";

	WriteLog("AP_Coding_Status","sNumberOfColumnsKey : "+sNumberOfColumnsKey) ;

	sHeaderPresentKey=sReportName+"_HEADERPRESENT";

	WriteLog("AP_Coding_Status","sHeaderPresentKey : "+sHeaderPresentKey) ;
	
	sHeaderKey=sReportName+"_HEADER";

	WriteLog("AP_Coding_Status","sHeaderKey : "+sHeaderKey) ;
	
	sDBMappedColsKey=sReportName+"_DBMAPPEDCOLS";
	WriteLog("AP_Coding_Status","sDBMappedColsKey : "+sDBMappedColsKey) ;
	sFieldValuesKey=sReportName+"_FIELDVALUES";

	WriteLog("AP_Coding_Status","sFieldValuesKey : "+sFieldValuesKey) ;
	
	sFilePathKey=sReportName+"_PATH";
	
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAAPCodingStatus.ini";
	//String sRootPathini=application.getRealPath("")+File.separator+"reports"+File.separator+"GMACReports"+File.separator+"ApprovalProcessCodingStatus" + File.separator + "reports.ini";
	Properties ini = new Properties();
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("AP_Coding_Status","Unable to read AP_Coding_Status.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("AP_Coding_Status","Unable to close the AP_Coding_Status.ini file");
						}
					}
				}
	
	

	//WriteLog("AP_Coding_Status","sOutputXML ::> sFieldValuesKey : "+sFieldValuesKey);
	
	/*String connectionUrl=ini.getProperty("ConnectionUrl");
	String dbuserName = ini.getProperty("username");
	String dbpass     = ini.getProperty("password");*/
	String pathName = "" ;
	pathName = ini.getProperty(sReportName +"_PATH");
	sProcessDefId=ini.getProperty("PROCESSDEFID");
	
	sCabinetName=ini.getProperty("CABINETNAME");
	sProcedureName=ini.getProperty(sProcedureNameKey);
	
	sColumnHeaders=ini.getProperty(sColumnHeadersKey);
	
	sFileName=ini.getProperty(sFileNameKey);
	
	sNumberOfColumns=ini.getProperty(sNumberOfColumnsKey);
	
	sHeaderPresentValue=ini.getProperty(sHeaderPresentKey);
	
	sDBMappedCols=ini.getProperty(sDBMappedColsKey);
	
	sFieldValues=ini.getProperty(sFieldValuesKey);
	
	sFilePath=ini.getProperty(sFilePathKey);
	WriteLog("AP_Coding_Status",sHeaderPresentValue);

	if(sHeaderPresentValue.equals("YES")) 
	{
		sHeaderValue=ini.getProperty(sHeaderKey);
	}

	String sCabname=null;
	String sSessionId = null;
	String sJtsIp = null;
	String sUserName = null;
	String sReportProcedureName=null;
	String sReportTableName=null;
	String sOutputXML="";
	String sInputXML = "";
	String maincode = "";
	String Totalrec = "0";
	String url = "";
	String Status="";
	String sStr_ServerType="";
	String sInputXml="";
	double fPercentage=0;
		
	String sColumnNamesArr[]=split(sColumnHeaders,',');
	String sDBMappedColsArr[]=split(sDBMappedCols,',');
	String sFinalColumns[]=split(sColumnHeaders,',');
	
	for(int i=0;i<sColumnNamesArr.length;i++)
	{
		if(sColumnNamesArr[i].indexOf("~D")!=-1)
			sFinalColumns[i]=sColumnNamesArr[i].substring(0,sColumnNamesArr[i].length()-2);

	}

	String sFieldNamesDB[]=split(sFieldValues,'#');

	for(int i=0;i<sFieldNamesDB.length;i++)
	{
		sFieldValuesReport=sFieldValuesReport+sFieldNamesDB[i]+',';
	}
	sFieldValuesReport=sFieldValuesReport.substring(0,sFieldValuesReport.length()-1);


	String From_Date_Q=request.getParameter("From_Date_Q");
	String To_Date_Q=request.getParameter("To_Date_Q");
	String Document_Category=request.getParameter("Document_Category");
	String Coder_Code=request.getParameter("Coder_Code");
	
	
	WriteLog("AP_Coding_Status","From_Date_Q="+From_Date_Q+"&To_Date_Q="+To_Date_Q+"&Document_Category="+Document_Category+"&Coder_Code="+Coder_Code+"mailid-->"+sUserMailID+"filename-->"+sFileName+"patrh--->"+sFilePath);
	System.out.println("AP_Coding_Status "+"From_Date_Q="+From_Date_Q+"&To_Date_Q="+To_Date_Q+"&Document_Category="+Document_Category+"&Coder_Code="+Coder_Code+"mailid-->"+sUserMailID+"filename-->"+sFileName+"patrh--->"+sFilePath);
	
	String sRowXml="";
	
    WriteLog("AP_Coding_Status","Malkeet -------------"); 
	int iJtsPort = 0;
	boolean bError=false;

	//connectionUrl = connectionUrl+";"+"databaseName="+sCabinetName+";user="+dbuserName+";password="+dbpass;
	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("AP_Coding_Status","sRootPathDBini="+sRootPathDBini);
	System.out.println("Coding Status ini path"+sRootPathDBini);
	
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("AP_Coding_Status","Unable to read AP_Coding_Status.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("AP_Coding_Status","Unable to close the AP_Coding_Status.ini file");
						}
					}
				}
	
	String driverName = null;

	String connectionUrl=ini.getProperty("CONNECTIONSTRING");
	System.out.println("connectionUrl "+connectionUrl);
	driverName = ini.getProperty("DRIVERNAME");
	System.out.println("driverName"+ driverName);
	CallableStatement callableStatement = null;
	Connection conn=null;	
	String getDBUSERByUserIdSql = "{call "+sProcedureName+"(?,?,?,?,?,?,?,?)}";
	
	String output = "" ;
	WriteLog("AP_Coding_Status",sProcedureName);
			
	try{
			Class.forName(driverName);
			conn = DriverManager.getConnection(connectionUrl);
			callableStatement = conn.prepareCall(getDBUSERByUserIdSql);
			callableStatement.setString(1, From_Date_Q);
			callableStatement.setString(2, To_Date_Q);
			callableStatement.setString(3, Document_Category);
			callableStatement.setString(4, Coder_Code);
			callableStatement.setString(5, sUserMailID);
			callableStatement.setString(6, sFileName);
			callableStatement.setString(7, sFilePath);
			callableStatement.registerOutParameter(8, java.sql.Types.VARCHAR);
			callableStatement.execute();

			output = callableStatement.getString(8);
			WriteLog("AP_Coding_Status"," output "+output);
			System.out.println("Coding Statuc Proc call output"+output);
		
			
	}
	catch(SQLException ignore)
	{
		WriteLog("AP_Coding_Status"," WFSession Data Fetch Exception:::::: "+ignore.toString());
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		bError= true;
		
	}
	finally {
 
	if (callableStatement != null) {
        try {
            callableStatement.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
}


	if(!bError)
	{

		WriteLog("AP_Coding_Status"," output:::::: "+output);
		try
		{

			if(output.equals(""))
			{
				bError= true;
				//maincode=sOutputXML.substring(sOutputXML.indexOf("<MainCode>")+10 , sOutputXML.indexOf("</MainCode>"));
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+output+"</b></font><center>");
			}
			else
			{
				
					try
							{
								 if(Integer.parseInt(output) == 0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
								out.println(ig.toString());
												
							}
			}
		}
		
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
			log("AP_Coding_Status : "+exp.toString());
		}
		
	}



%>
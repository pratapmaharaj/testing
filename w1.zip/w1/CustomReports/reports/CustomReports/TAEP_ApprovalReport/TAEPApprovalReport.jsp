<!-- 
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-TCI
Module : TCI
File Name : TCIException.jsp
Author :  
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date Change By Change Description (Bug No. (If Any))
(DD/MM/YYYY)
20/01/2009		Nilesh Kandolkar(WNS))	Added one text for EMAIL and alert for date comparing.
----------------------------------------------------------------------------------------------------
 -->

<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>


<HTML>
<HEAD>
<TITLE>TA EP Approval Report</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>
<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
}
</style>
<script>
	var allWindows = new Array();
	var win; // new window object
	$(document).ready(function(){$('#From_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	
	});
	/*functions echeck,ValidateForm added by nilesh*/
	function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}

function ValidateForm(emailID){

	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }


/*added by nilesh for comparision of Dates*/

function DateComparator(Date_To,Date_From)
	{	
			if (Date_From == "" && Date_To == "")
			{
				return true;
			}

			var FromDay = Date_From.split("/")[0];
			var FromMonth = convertMonth(Date_From.split("/")[1]);
			var FromYear = Date_From.split("/")[2];
			
			
			
			var ToDay = Date_To.split("/")[0];
			var ToMonth = convertMonth(Date_To.split("/")[1]);
			var ToYear = Date_To.split("/")[2];
			
			
			
			var CurrentDate=new Date();
			var CurrentDay = CurrentDate.getDate();
			var CurrentMonth = CurrentDate.getMonth();
			var CurrentYear = CurrentDate.getFullYear();
			

			var toDate = (new Date(ToYear,ToMonth,ToDay)).getTime();
			var fromDate = (new Date(FromYear,FromMonth,FromDay)).getTime();
			var CurrentDate = (new Date(CurrentYear,CurrentMonth,CurrentDay)).getTime();
			
			
		if(document.forms["textForm"].From_Date.value=='')
		{
			DateRangeFrom='';
		}
		if(document.forms["textForm"].To_Date.value=='')
		{
			DateRangeTo='';
		}

			if(fromDate > toDate)
			{
				alert("To Date cannot be less than From Date.");
				return false;
			}
			else if(fromDate > CurrentDate)
			{
				alert("From Date cannot be future date.");
				return false;
			}
			else if(toDate > CurrentDate)
			{
				alert("To Date cannot be future date.");
				return false;
			}
			
			return true;
	
	}


	
	function convertMonth(strMonth)
{
		if(strMonth=="JAN")
			strMonth="00";
		else if(strMonth=="FEB")
			strMonth="01";
		else if(strMonth=="MAR")
			strMonth="02";
		else if(strMonth=="APR")
			strMonth="03";
		else if(strMonth=="MAY")
			strMonth="04";
		else if(strMonth=="JUN")
			strMonth="05";
		else if(strMonth=="JUL")
			strMonth="06";
		else if(strMonth=="AUG")
			strMonth="07";
		else if(strMonth=="SEP")
			strMonth="08";
		else if(strMonth=="OCT")
			strMonth="09";
		else if(strMonth=="NOV")
			strMonth="10";
		else if(strMonth=="DEC")
			strMonth="11";
	return strMonth;
}
function convertMonth1(strMonth)
{
		if(strMonth=="01")
			strMonth="JAN";
		else if(strMonth=="02")
			strMonth="FEB";
		else if(strMonth=="03")
			strMonth="MAR";
		else if(strMonth=="04")
			strMonth="APR";
		else if(strMonth=="05")
			strMonth="MAY";
		else if(strMonth=="06")
			strMonth="JUN";
		else if(strMonth=="07")
			strMonth="JUL";
		else if(strMonth=="08")
			strMonth="AUG";
		else if(strMonth=="09")
			strMonth="SEP";
		else if(strMonth=="10")
			strMonth="OCT";
		else if(strMonth=="11")
			strMonth="NOV";
		else if(strMonth=="12")
			strMonth="DEC";
	return strMonth;
}
function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
var sDate="";
       sDate	= window.showModalDialog('/webdesktop/CustomForms/reports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');



	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
	

}
function ChangeDateTag(obj)
{
	var InsertVal='';
	for(iterate=0;iterate<obj.length;iterate++)
	{
		if(obj.options[iterate].selected==true)
		{
			InsertVal=InsertVal+obj.options[iterate].value+'/';
		}
	}
	InsertVal=InsertVal.substring(0,InsertVal.length-1);
	var Table=document.getElementById('newgen');
	var lastRow = Table.rows.length;
	if (lastRow > 0) Table.deleteRow(lastRow - 1);
	while(InsertVal.indexOf('_')!=-1)
	{
		InsertVal=InsertVal.replace('_',' ');
	}
	var Row=Table.insertRow(0);
	var Cell=Row.insertCell();
	Cell.className="EWLabelBoldNew";
	//Cell.innerHTML=InsertVal;
}
function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	//strResult=strdate+"/"+strMonth+"/"+stryear;
	strResult=strtempdate+"/"+strdate+"/"+stryear;
	return strResult;
}


	function openreport()
	{			
		
		//var DocumentType=document.forms["textForm"].Document_Type.value;
		var sExp="";
		var DocumentType="";
		var ProcessType="";
		var bExpSelected=false;
		var bDocuement=false;
		DateRangeFrom=document.forms["textForm"].From_Date.value;
		DateRangeTo=document.forms["textForm"].To_Date.value;

		//added by nilesh for retriving email id value
		var UserEmailID=document.getElementById('EMail-ID').value;//added by nilesh
			var sdatecon=DateRangeFrom.split('/');
		var sMonth=convertMonth1(sdatecon[0]);
		var sDay=sdatecon[1];
		var sYear=sdatecon[2];
		DateRangeFrom=sDay+"/"+sMonth+"/"+sYear;
		
		var stodatecon=DateRangeTo.split('/');
		var sMonth1=convertMonth1(stodatecon[0]);
		var sDay1=stodatecon[1];
		var sYear1=stodatecon[2];
		
		DateRangeTo=sDay1+"/"+sMonth1+"/"+sYear1;
		
		
		if(document.forms["textForm"].From_Date.value=='')
		{
			DateRangeFrom='';
		}
		if(document.forms["textForm"].To_Date.value=='')
		{
			DateRangeTo='';
		}
		
//alert("ttttt"+document.forms["textForm"].Document_Type[0].value);
		/*for(var i=0;i<document.forms["textForm"].Document_Type.length;i++)
				{
					if(document.forms["textForm"].Document_Type[i].selected)
					{
					DocumentType=DocumentType+document.forms["textForm"].Document_Type[i].value+'~';
					
					}
				}*/

		/*for(var i=0;i<document.forms["textForm"].Process_Type.length;i++)
			{
				if(document.forms["textForm"].Process_Type[i].selected)
				{
					ProcessType=ProcessType+document.forms["textForm"].Process_Type[i].value+'~';
				}
			}*/

		
		
		
		/*var sTestDocType=DocumentType.split('~');
		var sTestProcType=ProcessType.split('~');
		

		if(DocumentType=='')
		{
			alert("Please select an appropriate Document Type");
			return false;
		}
		if(ProcessType=='')
		{
			alert("Please select an appropriate Process");
			return false;
		}
		*/
		if(document.forms["textForm"].From_Date.value=='')
		{
			DateRangeFrom='';
		}
		if(document.forms["textForm"].To_Date.value=='')
		{
			DateRangeTo='';
		}

		if(DateRangeFrom=='')
		{
			alert("Please select an appropriate From Date");
			return false;
		}
		if(DateRangeTo=='')
		{
			alert("Please select an appropriate To Date");
			return false;
		}
				
		if(sExp=="" && DateRangeFrom=="" && DateRangeTo=="" )
		{
			alert("Please select atleast one selection criteria.");
			return false;
		
		}
		else if ((DateRangeFrom=="" && DateRangeTo!="") || (DateRangeFrom!="" && DateRangeTo==""))
		{
			alert("Enter the complete Date Range.");
			return false;
		}
		
		
		
/*
		if(DocumentType.indexOf("All")!=-1 && sTestDocType.length>2)
		{
			alert("No other Document Type can be chosen after choosing All");
			return false;
			//DocumentType='All~';

		} 
		if(ProcessType.indexOf("All")!=-1 && sTestProcType.length>2)
		{
			alert("No other Process Type can be chosen after choosing All");
			return false;
			//DocumentType='All~';

		} 
		

		if(DocumentType=='KR~CR~')
		{
			DocumentType='All~';
		}
		if(ProcessType=='AP~EXP~')
		{
			ProcessType='All~';
		}*/
		
			
		

		/*Added by nilesh-Function is called for  comparing dates*/
				
		if(!DateComparator(DateRangeTo,DateRangeFrom))
		{
		return false;
		}
		
		//Added by nilesh for validation of Mail-ID
		if(UserEmailID=='')
		{
			alert("Kindly enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
			}
		}


		if(UserEmailID!='')
			{
			
		
			
				//OpenRedict-Fix
    //window.top.TAEPAPPROVALREPORT.location.href="TAEPApprovalReportGenerate.jsp?FromDates="+DateRangeFrom+"&ToDate="+DateRangeTo+"&UserEmailID="+UserEmailID+"&ReportName=<%=request.getParameter("ReportName")%>" ;
	var URI = "TAEPApprovalReportGenerate.jsp?FromDates="+DateRangeFrom+"&ToDate="+DateRangeTo+"&UserEmailID="+UserEmailID+"&ReportName=<%=request.getParameter("ReportName")%>" ;
	var StrOpenWin=strip_tags(URI,"");
	window.top.TAEPAPPROVALREPORT.location.href=StrOpenWin;
			
			}
}
	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}

</script>

<body topmargin="0" leftmargin="5" onunload="UnloadReportWindow();">

			<form name='textForm' method=post>


			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">TA EP Approval Report</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This report will provide the details of documents which are in Approval Queue and the documents which went to approval queue 
</td></tr>
<tr><td class="EWLabel1"> 
</td></tr>
<tr><td class="EWLabel1"> 
</td></tr>
<tr><td class="EWLabel1">Select the requisite date range for generating the report for the same.</td>
				</tr>
			</table>

			<table border="0" width="95%" cellspacing="1" align="center">
				<tr>
					<td valign="center" width="100%" colspan=4 height=12></td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=4 class="EWLabel1"><b>Report Criteria :</b></td>
				</tr>
				
			</table>

			<table border="0" width="95%" cellspacing="1" align="center">

						
				
	 
				<tr>&nbsp;</tr>
				 <tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>Date Range &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date" readonly type="text"  id="From_Date" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date" type="text" readonly id="To_Date" >
					
					</td>

				</tr>


				<!--Added by nilesh for additional E-mail ID field display -->
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID*</b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>

				
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>
	
			
			</form>
</body>
</Html>	 




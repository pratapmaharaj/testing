<!-- 
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-TCI
Module : TCI
File Name : TCIExceptionGenerate.jsp
Author :   Tarit Gupta
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date			Change By		Change Description (Bug No. (If Any))
(DD/MM/YYYY)
05/11/2008		Santul Sharma	Comm_05
20/01/2009		Nilesh Kandolkar(WNS)	Remove code for generating report in XLS.
----------------------------------------------------------------------------------------------------
 -->
<%@ include file="customized.process" %> 
<%@ page import="java.io.*" %>
<%@ page import="java.util.*" %>
<%@ page import="javax.servlet.*"%>
<%@ page import="java.text.DateFormat"%>
<%@ page import="java.text.SimpleDateFormat"%>
<%@ page import="javax.servlet.http.*"%>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>
<%@ page import="java.text.*"%>
<%@ page import="java.sql.DriverManager,java.sql.Connection,java.sql.PreparedStatement,java.sql.CallableStatement,java.sql.ResultSet,java.sql.SQLException"%>

<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>



<HTML>
<HEAD>
<TITLE>TA EP Approval Report</TITLE>
</HEAD>

<link href="/processmanager/omniflow/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>



</script>


<body>

<%
	
	String sProcessDefId=null;
	String sProcedureName=null;
	String sColumnHeaders=null;
	String sReportName=null;
	String sFileName=null;
	String sNumberOfColumns=null;
	String sProcedureNameKey=null;
	String sColumnHeadersKey=null;
	String sFileNameKey=null;
	String sNumberOfColumnsKey=null;
	String sHeaderKey=null;
	String sHeaderPresentKey=null;
	String sDBMappedColsKey=null;
	String sHeaderValue=null;
	String sHeaderPresentValue=null;
	String sCabinetName=null;	
	String sDBMappedCols=null;
	String sFieldValuesKey=null;
	String sFieldValues=null;
	int BagImageCount=0;
	int MultipleDocCount=0;
	int NewVendorCount=0;
	int Miscellaneous=0;
	int DuplicateCount=0;
	int NotInvoiceCount=0;
	int CostQualityVariance=0;
	int MissingPO=0;
	int MissingIncApprovalCount=0;
	int GoodsRecptVarification=0;
	int IncorrectCoding=0;
	String sUserMailID=null;//added by nilesh
	String fileName = "" ;
	String filePath="" ;

	sUserMailID=request.getParameter("UserEmailID");//added by nilesh


	sReportName	=request.getParameter("ReportName");
	sReportName	=sReportName.toUpperCase();
	
	sReportName="APPROVALREPORT";
	

	sProcedureNameKey=sReportName +"_PROCEDURENAME";
	sColumnHeadersKey=sReportName+"_COLUMNHEADERS";
	sFileNameKey=sReportName+"_FILENAME";
	sNumberOfColumnsKey=sReportName+"_NUMBEROFCOLUMNS";
	sHeaderPresentKey=sReportName+"_HEADERPRESENT";
	sHeaderKey=sReportName+"_HEADER";
	sDBMappedColsKey=sReportName+"_DBMAPPEDCOLS";
	sFieldValuesKey=sReportName+"_FIELDVALUES";

	/*String sRootPathini=application.getRealPath("")+File.separator+"reports"+File.separator+"GMACReports"+File.separator+"TAEP_ApprovalReport" + File.separator+"reports.ini";
	CustomForms\reports\CustomReports\TAEP_ApprovalReport
	*/
	
	
		
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAEP_ApprovalReport.ini";
	WriteLog("TAEP_APPROVAL_REPORT","sRootPathini="+sRootPathini);
	Properties ini = new Properties();

	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("TAEP_APPROVAL_REPORT","Unable to read TAEP_APPROVAL_REPORT.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("TAEP_APPROVAL_REPORT","Unable to close the TAEP_APPROVAL_REPORT.ini file");
						}
					}
				}

	filePath = ini.getProperty(sReportName+"_FILEPATH");
	fileName=ini.getProperty(sReportName+"_FILENAME") ;
	sProcessDefId=ini.getProperty("PROCESSDEFID");
	sCabinetName=ini.getProperty("CABINETNAME");
	sProcedureName=ini.getProperty(sProcedureNameKey);
	sColumnHeaders=ini.getProperty(sColumnHeadersKey);
	sFileName=ini.getProperty(sFileNameKey);
	sNumberOfColumns=ini.getProperty(sNumberOfColumnsKey);
	sHeaderPresentValue=ini.getProperty(sHeaderPresentKey);
	sDBMappedCols=ini.getProperty(sDBMappedColsKey);
	sFieldValues=ini.getProperty(sFieldValuesKey);
	sFieldValues=sFieldValues.replaceAll("#",",");
	
	
	if(sHeaderPresentValue.equals("YES")) {
	sHeaderValue=ini.getProperty(sHeaderKey);

	}
	
	String sCabname=null;
	String sSessionId = null;
	String sJtsIp = null;
	String sUserName = null;
	String sReportProcedureName=null;
	String sReportTableName=null;

	String DocumentType="";//request.getParameter("DocumentType");
	String ProcessType="";//request.getParameter("ProcessType");
	String sFromDate=request.getParameter("FromDates");
	String sToDate=request.getParameter("ToDate");
	
	//log("tarit1"+DocumentType);
	Date CurrDate=new Date();
	DateFormat dt = new SimpleDateFormat("dd-MMM-yyyy");
	String sCurrdate=dt.format(CurrDate);

	String sOutputXML="";
	String sInputXML = "";
	String maincode = "";
	String Totalrec = "0";
    String sStr_ServerType = null;
	String url = "";
	String Status="";
	String sInputXml="";
	double fPercentage=0;
	String sColumnNamesArr[]=split(sColumnHeaders,',');
	String sDBMappedColsArr[]=split(sDBMappedCols,',');
	String sRowXml="";
	String sFinalColumns[]=split(sColumnHeaders,',');
	for(int i=0;i<sColumnNamesArr.length;i++)
	{
		if(sColumnNamesArr[i].indexOf("~D")!=-1)
			sFinalColumns[i]=sColumnNamesArr[i].substring(0,sColumnNamesArr[i].length()-2);

	}

	int iJtsPort = 0;
	boolean bError=false;

	
	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("TAEP_APPROVAL_REPORT","sRootPathDBini="+sRootPathDBini);								
	
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("TAEP_APPROVAL_REPORT","Unable to read TAEP_APPROVAL_REPORT.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("TAEP_APPROVAL_REPORT","Unable to close the TAEP_APPROVAL_REPORT.ini file");
						}
					}
				}
	
	String conString = null;
	String driverName = null;
	driverName=ini.getProperty("DRIVERNAME");
	conString=ini.getProperty("CONNECTIONSTRING");
	

	WriteLog("TAEP_APPROVAL_REPORT","driverName="+driverName);
	WriteLog("TAEP_APPROVAL_REPORT","conString="+conString);
	WriteLog("TAEP_APPROVAL_REPORT","sProcedureName="+sProcedureName);
	WriteLog("TAEP_APPROVAL_REPORT","sFieldValues="+sFieldValues);
	
	
	
	
	Connection conn = null;
	CallableStatement cs = null;
	
		
	try
	{
	
		
		WriteLog("TAEP_APPROVAL_REPORT","cs.toString()=1");	
		Class.forName(driverName);	
		conn = DriverManager.getConnection(conString);
		
		WriteLog("TAEP_APPROVAL_REPORT","cs.toString()=2");	
		
		cs = conn.prepareCall("{call "+sProcedureName+"(?,?,?,?,?,?,?)}"); 
		
		/*@DateRangeFrom  VARCHAR(50),           
		@DateRangeTo  VARCHAR(50),           
		@Fields varchar(8000),           
		@EmailID varchar(200),          
		@FilePath varchar(200),          
		@FileName varchar(200),        
		@result varchar(200) output*/
		
		cs.setString(1,sFromDate);
		cs.setString(2,sToDate);
		cs.setString(3,sFieldValues);
		cs.setString(4,sUserMailID);
		cs.setString(5,filePath);
		cs.setString(6,fileName);
		cs.registerOutParameter(7, java.sql.Types.VARCHAR);
		
		WriteLog("TAEP_APPROVAL_REPORT","variables="+sFieldValues+","+sFromDate+","+sToDate+","+sUserMailID+","+filePath+","+fileName);	
		WriteLog("TAEP_APPROVAL_REPORT","sProcedureName="+sProcedureName);	
		
		cs.execute();
		
		
        WriteLog("TAEP_APPROVAL_REPORT","output="+cs.getString(7));	
		sOutputXML = cs.getString(7);
		WriteLog("TAEP_APPROVAL_REPORT","sOutputXML="+sOutputXML);	
        
		

	}
	catch(SQLException ignore)
	{	
		
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp->161->"+ignore.toString()+"</b></font>");
		WriteLog("TAEP_APPROVAL_REPORT","sOutputXML="+ignore.toString());	
		bError= true;
	}
	finally {
    
   
	if (cs != null) {
        try {
            cs.close();
        } catch (SQLException e) {  }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
}
	if(!bError)
	{
		try
		{
		   if(sOutputXML.equals("NORECORD"))
		   {
			WriteLog("TAEPQUEUESTATUS REPORT ","no record ");
			bError= true;
			
			%>
			<script>alert("No Records found for the Current Request Criteria.");</script>
			<%
		   }
			else if(sOutputXML.equals("SUCCESS"))
			{
				WriteLog("TAEPQUEUESTATUS REPORT ","found record");

				%>
				<script>alert("The Report will be delivered to your mailbox shortly");</script>
				<%

			}
			else 
			{
				WriteLog("TAEPQUEUESTATUS REPORT ","Technical error");

				%>
				<script>alert("Internal Server error. Please logout and try again.\nIf problem persists then contact to the support team.");</script>
				<%

			}

		}
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
		}

		
	}
	else
	{
	%>
			<script>alert("Internal Server Error.");</script>
	<%
	}
	WriteLog("TAEP_APPROVAL_REPORT","sOutputXML ::> inside line 213 : "+sReportName);
%>	

	
	
	
	


	
<FORM name="textForm">

</form>	
		
	
			







<!-- 
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-TCI
Module : TCI
File Name : TCIExceptionMain.jsp
Author :   Tarit Gupta
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date			Change By		Change Description (Bug No. (If Any))
(DD/MM/YYYY)

13/08/2008		Bhawna Gupta	Res_21
----------------------------------------------------------------------------------------------------
 -->

<HTML>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<HEAD>
<TITLE>TA EP Approval Report</TITLE>
</HEAD>

<FRAMESET ROWS="100%,0%" >
	<FRAME SRC="TAEPApprovalReport.jsp?ReportName=<%=request.getParameter("ReportName")%>" NAME="frmHeader" frameborder=no noresize scrolling=Yes>
	<FRAME SRC="" NAME="TAEPAPPROVALREPORT" frameborder=no scrolling=no>
	
</FRAMESET>
</html>


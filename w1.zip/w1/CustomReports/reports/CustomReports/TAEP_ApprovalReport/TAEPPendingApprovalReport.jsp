<!-- 
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-TCI
Module : TCI
File Name : TCIException.jsp
Author :  
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date Change By Change Description (Bug No. (If Any))
(DD/MM/YYYY)
20/01/2009		Nilesh Kandolkar(WNS))	Added one text for EMAIL and alert for date comparing.
----------------------------------------------------------------------------------------------------
 -->
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>

<HTML>
<HEAD>
<TITLE>TA EP Approval Report</TITLE>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>

<script>
	var allWindows = new Array();
	var win; // new window object
	/*functions echeck,ValidateForm added by nilesh*/
	function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}

function ValidateForm(emailID){

	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }


/*added by nilesh for comparision of Dates*/

function DateComparator(Date_To,Date_From)
{	

	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));	
	var Date_From_month=Date_From.substring(Date_From.indexOf("/")+1,Date_From.lastIndexOf("/"));

	/*converting ToDate month to number */
	if(Date_To_month=="JAN")
			Date_To_month="01";
		else if(Date_To_month=="FEB")
			Date_To_month="02";
		else if(Date_To_month=="MAR")
			Date_To_month="03";
		else if(Date_To_month=="APR")
			Date_To_month="04";
		else if(Date_To_month=="MAY")
			Date_To_month="05";
		else if(Date_To_month=="JUN")
			Date_To_month="06";
		else if(Date_To_month=="JUL")
			Date_To_month="07";
		else if(Date_To_month=="AUG")
			Date_To_month="08";
		else if(Date_To_month=="SEP")
			Date_To_month="09";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";


	/*converting FromDate month to number */
		if(Date_From_month=="JAN")
			Date_From_month="01";
		else if(Date_From_month=="FEB")
			Date_From_month="02";
		else if(Date_From_month=="MAR")
			Date_From_month="03";
		else if(Date_From_month=="APR")
			Date_From_month="04";
		else if(Date_From_month=="MAY")
			Date_From_month="05";
		else if(Date_From_month=="JUN")
			Date_From_month="06";
		else if(Date_From_month=="JUL")
			Date_From_month="07";
		else if(Date_From_month=="AUG")
			Date_From_month="08";
		else if(Date_From_month=="SEP")
			Date_From_month="09";
		else if(Date_From_month=="OCT")
			Date_From_month="10";
		else if(Date_From_month=="NOV")
			Date_From_month="11";
		else if(Date_From_month=="DEC")
			Date_From_month="12";
	
	var Date_To_date=Number(Date_To.substring(Date_To.indexOf("0"),Date_To.indexOf("/")));	
	var Date_From_date=Number(Date_From.substring(Date_From.indexOf("0"),Date_From.indexOf("/")));

		
	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));
	var Date_From_year=Number(Date_From.substring(Date_From.lastIndexOf("/")+1,Date_From.length));

		

	if(Date_To_year<Date_From_year)
	{
		alert("To Date cannot be less than From  Date.");
		return false;
	}


	else if(Date_To_year>Date_From_year)
	{
		
		//if(Date_From_month>Date_To_month)
		//{
		//alert("To Date can not be less than From Date.");
		//return false;
		//}
		 if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{
				
				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}


	else if(Date_To_year==Date_From_year)
	{
	
		if(Date_From_month>Date_To_month)
		{
		alert("To Date can not be less than From Date.");
		return false;
		}
		else if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{
				
				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}
return true;
}


	
	
function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
var sDate="";
       sDate	= window.showModalDialog('/processmanager/reports/GMACReports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');



	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
	

}
function ChangeDateTag(obj)
{
	var InsertVal='';
	for(iterate=0;iterate<obj.length;iterate++)
	{
		if(obj.options[iterate].selected==true)
		{
			InsertVal=InsertVal+obj.options[iterate].value+'/';
		}
	}
	InsertVal=InsertVal.substring(0,InsertVal.length-1);
	var Table=document.getElementById('newgen');
	var lastRow = Table.rows.length;
	if (lastRow > 0) Table.deleteRow(lastRow - 1);
	while(InsertVal.indexOf('_')!=-1)
	{
		InsertVal=InsertVal.replace('_',' ');
	}
	var Row=Table.insertRow(0);
	var Cell=Row.insertCell();
	Cell.className="EWLabelBoldNew";
	//Cell.innerHTML=InsertVal;
}
function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	strResult=strdate+"/"+strMonth+"/"+stryear;
	return strResult;
}


	function openreport()
	{			
		
		
		var sExp="";
		var DocumentType="";
		var ProcessType="";
		var bExpSelected=false;
		var bDocuement=false;
		DateRangeFrom=document.forms["textForm"].From_Date.value;
		DateRangeTo=document.forms["textForm"].To_Date.value;

		//added by nilesh for retriving email id value
		var UserEmailID=document.getElementById('EMail-ID').value;//added by nilesh
		
		

		for(var i=0;i<document.forms["textForm"].Document_Type.length;i++)
				{
					if(document.forms["textForm"].Document_Type[i].selected)
					{
					DocumentType=DocumentType+document.forms["textForm"].Document_Type[i].value+'~';
					
					}
				}

		for(var i=0;i<document.forms["textForm"].Process_Type.length;i++)
			{
				if(document.forms["textForm"].Process_Type[i].selected)
				{
					ProcessType=ProcessType+document.forms["textForm"].Process_Type[i].value+'~';
				}
			}

		
		
		
		var sTestDocType=DocumentType.split('~');
		var sTestProcType=ProcessType.split('~');
		

		if(DocumentType=='')
		{
			alert("Please select an appropriate Document Type");
			return false;
		}
		if(ProcessType=='')
		{
			alert("Please select an appropriate Process");
			return false;
		}
		
		if(DateRangeFrom=='')
		{
			alert("Please select an appropriate From Date");
			return false;
		}
		if(DateRangeTo=='')
		{
			alert("Please select an appropriate To Date");
			return false;
		}
				
		if(DocumentType=="" && sExp=="" && DateRangeFrom=="" && DateRangeTo=="" && ProcessType=="")
		{
			alert("Please select atleast one selection criteria.");
			return false;
		
		}
		else if ((DateRangeFrom=="" && DateRangeTo!="") || (DateRangeFrom!="" && DateRangeTo==""))
		{
			alert("Enter the complete Date Range.");
			return false;
		}
		
		
		

		if(DocumentType.indexOf("All")!=-1 && sTestDocType.length>2)
		{
			alert("No other Document Type can be chosen after choosing All");
			return false;
			//DocumentType='All~';

		} 
		if(ProcessType.indexOf("All")!=-1 && sTestProcType.length>2)
		{
			alert("No other Process Type can be chosen after choosing All");
			return false;
			//DocumentType='All~';

		} 
		

		if(DocumentType=='KR~CR~')
		{
			DocumentType='All~';
		}
		if(ProcessType=='AP~EXP~')
		{
			ProcessType='All~';
		}
		
			
		

		/*Added by nilesh-Function is called for  comparing dates*/
				
		if(!DateComparator(DateRangeTo,DateRangeFrom))
		{
		return false;
		}
		
		//Added by nilesh for validation of Mail-ID
		if(UserEmailID=='')
		{
			alert("Kindly enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
			}
		}


		if(UserEmailID!='')
			{
			
		
			
			//OpenRedict-Fix
    //window.top.TAEPAPPROVALREPORT.location.href="TAEPApprovalRepMain.jsp?FromDates="+DateRangeFrom+"&ToDate="+DateRangeTo+"&UserEmailID="+UserEmailID+"&DocumentType="+DocumentType+"&ProcessType="+ProcessType+"&ReportName=<%=request.getParameter("ReportName")%>" ;
	var URI = "TAEPApprovalRepMain.jsp?FromDates="+DateRangeFrom+"&ToDate="+DateRangeTo+"&UserEmailID="+UserEmailID+"&DocumentType="+DocumentType+"&ProcessType="+ProcessType+"&ReportName=<%=request.getParameter("ReportName")%>" ;
	var StrOpenWin=strip_tags(URI,"");
	window.top.TAEPAPPROVALREPORT.location.href=StrOpenWin;
			}
}
	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}

</script>

<body topmargin="0" leftmargin="5" onunload="UnloadReportWindow();">

			<form name='textForm' method=post>


			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">TCI Pending Document Approval Report</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This report will provide the details of documents Pending Approval
</td></tr>
<tr><td class="EWLabel1"> 
Select Process Type if the report has to be generated for the particular Process Types.
</td></tr>
<tr><td class="EWLabel1"> 
Select All as the Document Category if the report has to be generated for the entire spectrum of the avalilable Document Category, else select the specific Document Category, multiple selections are acceptable.
</td></tr>
<tr><td class="EWLabel1">Select the requisite date range for generating the report for the same.</td>
				</tr>
			</table>

			<table border="0" width="95%" cellspacing="1" align="center">
				<tr>
					<td valign="center" width="100%" colspan=4 height=12></td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=4 class="EWLabel1"><b>Report Criteria :</b></td>
				</tr>
				
			</table>

			<table border="0" width="95%" cellspacing="1" align="center">

				<tr>
					<td class="EWLabel1" align="left" width='20%'><b>Process Type</b></td>
					<td width='35%' colspan=3>
					<select style='width:33%' name="Process_Type" multiple>
					<option value="All">All</option>
					<option value="AP">AP</option>
					<option value="Exp">Exp</option>
					</select>
					</td>
				</tr>
				<tr>
					<td class="EWLabel1" align="left" width='20%'><b>Document Category</b></td>
					<td width='35%' colspan=3>
					<select style='width:33%' name="Document_Type" multiple>
					<option value="All">All</option>
					<option value="KR">KR</option>
					<option value="CP">CP</option>
					</select>
					</td>
				</tr>
				
	 
				<tr>&nbsp;</tr>
				 <tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>Date Range &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date" readonly type="text"  id="From_Date" >
					<input type="image" id="From_Date_IMG" Title="Click to select Date."  onclick="ShowCalendar('From_Date');return false;" src="/processmanager/reports/GMACReports/GMAC/Calendar/images/Calendar.gif" border="0">
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date" readonly type="text"  id="To_Date" >
					<input type="image" id="To_Date_IMG" Title="Click to select Date."  onclick="ShowCalendar('To_Date');return false;" src="/processmanager/reports/GMACReports/GMAC/Calendar/images/Calendar.gif" border="0">
					</td>

				</tr>


				<!--Added by nilesh for additional E-mail ID field display -->
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID*</b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>

				
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>
	
			
			</form>
</body>
</Html>	 




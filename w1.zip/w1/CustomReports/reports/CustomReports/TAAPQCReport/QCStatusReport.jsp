<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*"%>
<%@ page import="com.google.common.collect.ArrayListMultimap"%>
<%@ page import="com.google.common.collect.Multimap"%>


<jsp:useBean id="list" class="java.util.TreeMap" scope="request" />

<HTML>
<HEAD>
<TITLE>AP QC Status Report</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>
</HEAD>

<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>
<%@ include file="customized.process" %>
<script src="../../GMAC/Scripts/Common.js"></script>
<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
}
</style>
<%

Multimap<String, String> myMultimap = ArrayListMultimap.create(); 
  
String sResult="";
int iMainCode=0;

ArrayList Queue_Checklist=new ArrayList();

String strNoOfCols="2";
String sInputXML2=null;
String sOutputXML2=null;
	
	String sCabname=null;
	String sSessionId = null;
	String sJtsIp = null;
	int iJtsPort = 0;
	String sStr_ServerType="";
	
WriteLog("TA_AP_QC_StatusReport ","Inside QC Queue Status Report.......!!!!!");

try{
			try{
				//System.out.println("wfsession"+wfSession.getM_strSessionID());
			/*sCabname=wfSession.getM_strCabName();
			sSessionId  = wfSession.getM_strSessionID();
			sJtsIp      = wfSession.getM_objCabinet().getM_strServerIP();
			iJtsPort    = wfSession.getM_objCabinet().getM_iServerPort();
			sStr_ServerType = wfSession.getM_objCabinet().getM_strServerType();
			*/
			sCabname=wfsession.getEngineName();	
			sSessionId = wfsession.getSessionId();	
			sJtsIp = wfsession.getJtsIp();
			iJtsPort = wfsession.getJtsPort();}
			catch(Exception e){
				System.out.println("e"+e);
			}

	String sQueryQCList="select CheckListName,CheckListName+':'+reason from WNS_TA_AP_CheckList_Master with (nolock)";

	WriteLog("TA_AP_QC_StatusReport ","sQuery :"+sQueryQCList);
			
			sInputXML2 = "<?xml version=\"1.0\"?>" +
								"<WMTestSelect_Input>" +
								"<Option>WFSelectTest_new</Option>" +
								"<sQry>"+sQueryQCList+"</sQry>" +
								"<EngineName>"+sCabname+"</EngineName>"+
								"<NoOfCols>"+strNoOfCols+"</NoOfCols>" +
								"<SessionId>"+sSessionId+"</SessionId>" +
								"</WMTestSelect_Input>";
								
			WriteLog("TA_AP_QC_StatusReport ","sInputXML :"+sInputXML2);

			
			//sOutputXML2 = WFCallBroker.execute(sStr_ServerType,"",sInputXML2,sJtsIp,iJtsPort,1);		
			sOutputXML2 = WFCallBroker.execute(sInputXML2,sJtsIp,iJtsPort,1);
			WriteLog("TA_AP_QC_StatusReport ","sOutputXML :"+sOutputXML2);
			//System.out.println("QC Chceklist"+sOutputXML2);
			
			

if(sOutputXML2.equals("") || Integer.parseInt(sOutputXML2.substring(sOutputXML2.indexOf("<MainCode>")+10 , sOutputXML2.indexOf("</MainCode>")))!=0)
				{
					iMainCode=15;
					sResult="Internal Server error.";
				}
				else
				{
					sResult="";
					WFXmlResponse xmlResponse = new WFXmlResponse(sOutputXML2);
					WFXmlList RecordList;
					
					char spChar='�';
					
					
					
					for (RecordList =  xmlResponse.createList("Results", "Result");RecordList.hasMoreElements();RecordList.skip())
					{	
						
						String sRowData[]=split(RecordList.getVal("Result"),spChar);
						myMultimap.put(sRowData[0],sRowData[1]);  
						sResult=sResult+RecordList.getVal("Result")+'~';
					}

				  WriteLog("TA_AP_QC_StatusReport "," sResult::> sResult : "+sResult);
				  System.out.println("QC Checklist"+ sResult);
				}
				

			
				
		}
		catch(Exception e)
		{
			WriteLog("TA_AP_QC_StatusReport "," Error::> : "+e.getMessage());
           Queue_Checklist=null;
		   System.out.println("QC Chceklist"+e);
		}
		
%>



<script>
	var FromDate = new Date();
	var type = '';
	var allWindows = new Array();
	var win; // new window object
	$(document).ready(function(){$('#From_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	
	});
/*
function DateComparator(Date_To,Date_From)
{	

	var todaysDate = new Date(); 
	var dd = todaysDate.getDate() ;
	var mm = todaysDate.getMonth()+1 ;
	var yy = todaysDate.getFullYear() ;
	if(mm<10)
	{
		mm = "0"+mm ;
	}

	var today = dd+''+mm+''+yy ;

	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));	
	var Date_From_month=Date_From.substring(Date_From.indexOf("/")+1,Date_From.lastIndexOf("/"));

	if(Date_To_month=="JAN")
			Date_To_month="01";
		else if(Date_To_month=="FEB")
			Date_To_month="02";
		else if(Date_To_month=="MAR")
			Date_To_month="03";
		else if(Date_To_month=="APR")
			Date_To_month="04";
		else if(Date_To_month=="MAY")
			Date_To_month="05";
		else if(Date_To_month=="JUN")
			Date_To_month="06";
		else if(Date_To_month=="JUL")
			Date_To_month="07";
		else if(Date_To_month=="AUG")
			Date_To_month="08";
		else if(Date_To_month=="SEP")
			Date_To_month="09";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";

		if(Date_From_month=="JAN")
			Date_From_month="01";
		else if(Date_From_month=="FEB")
			Date_From_month="02";
		else if(Date_From_month=="MAR")
			Date_From_month="03";
		else if(Date_From_month=="APR")
			Date_From_month="04";
		else if(Date_From_month=="MAY")
			Date_From_month="05";
		else if(Date_From_month=="JUN")
			Date_From_month="06";
		else if(Date_From_month=="JUL")
			Date_From_month="07";
		else if(Date_From_month=="AUG")
			Date_From_month="08";
		else if(Date_From_month=="SEP")
			Date_From_month="09";
		else if(Date_From_month=="OCT")
			Date_From_month="10";
		else if(Date_From_month=="NOV")
			Date_From_month="11";
		else if(Date_From_month=="DEC")
			Date_From_month="12";
	
	var Date_To_date=Number(Date_To.substring(Date_To.indexOf("0"),Date_To.indexOf("/")));	
	var Date_From_date=Number(Date_From.substring(Date_From.indexOf("0"),Date_From.indexOf("/")));

		
	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));
	var Date_From_year=Number(Date_From.substring(Date_From.lastIndexOf("/")+1,Date_From.length));

	var inputTo = Date_To+''+Date_To_month+''+Date_To_year ;
	var inputFrom = Date_From+''+Date_From_month+''+Date_From_year ;

	if(inputFrom>today)
	{
		alert("From date can not be future date.") ;
		return false ;
	}

	if(inputTo>today)
	{
		alert("To date can not be future date.") ;
		return false ;
	}


	if(Date_To_year<Date_From_year)
	{
		alert("To Date cannot be less than From  Date.");
		return false;
	}

	else if(Date_To_year>Date_From_year)
	{
		//if(Date_From_month>Date_To_month)
		//{
		//alert("To Date can not be less than From Date.");
		//return false;
		//}
		if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{
				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}
	else if(Date_To_year==Date_From_year)
	{
		if(Date_From_month>Date_To_month)
		{
		alert("To Date can not be less than From Date.");
		return false;
		}
		else if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{
				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}
return true;
}
*/
function compToday(Date_To)
{
	var todaysDate = new Date(); 
	var dd = todaysDate.getDate() ;
	var mm = todaysDate.getMonth()+1 ;
	var yy = todaysDate.getFullYear() ;

	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));

	var Date_To_date=Number(Date_To.substring(0,Date_To.indexOf("/")));	

	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));

	if(Date_To_month=="JAN")
			Date_To_month="1";
		else if(Date_To_month=="FEB")
			Date_To_month="2";
		else if(Date_To_month=="MAR")
			Date_To_month="3";
		else if(Date_To_month=="APR")
			Date_To_month="4";
		else if(Date_To_month=="MAY")
			Date_To_month="5";
		else if(Date_To_month=="JUN")
			Date_To_month="6";
		else if(Date_To_month=="JUL")
			Date_To_month="7";
		else if(Date_To_month=="AUG")
			Date_To_month="8";
		else if(Date_To_month=="SEP")
			Date_To_month="9";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";

	if(Date_To_year>yy)
	{
		return false;
	}
	else if(Date_To_year<yy)
	{
		//if(Date_From_month>Date_To_month)
		//{
		//alert("To Date can not be less than From Date.");
		//return false;
		//}
		 if(mm==Date_To_month)
		{
			if(Date_To_date>dd)
			{
				return false;
			}
		}
	}
	else if(Date_To_year==yy)
	{
		if(mm<Date_To_month)
		{
		return false;
		}
		else if(mm==Date_To_month)
		{
			if(Date_To_date>dd)
			{
				return false;
			}
		}
	}
return true ;
}

function DateComparator(Date_To,Date_From)
{	

	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));	
	var Date_From_month=Date_From.substring(Date_From.indexOf("/")+1,Date_From.lastIndexOf("/"));

	/*converting ToDate month to number */
	if(Date_To_month=="JAN")
			Date_To_month="01";
		else if(Date_To_month=="FEB")
			Date_To_month="02";
		else if(Date_To_month=="MAR")
			Date_To_month="03";
		else if(Date_To_month=="APR")
			Date_To_month="04";
		else if(Date_To_month=="MAY")
			Date_To_month="05";
		else if(Date_To_month=="JUN")
			Date_To_month="06";
		else if(Date_To_month=="JUL")
			Date_To_month="07";
		else if(Date_To_month=="AUG")
			Date_To_month="08";
		else if(Date_To_month=="SEP")
			Date_To_month="09";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";


	/*converting FromDate month to number */
		if(Date_From_month=="JAN")
			Date_From_month="01";
		else if(Date_From_month=="FEB")
			Date_From_month="02";
		else if(Date_From_month=="MAR")
			Date_From_month="03";
		else if(Date_From_month=="APR")
			Date_From_month="04";
		else if(Date_From_month=="MAY")
			Date_From_month="05";
		else if(Date_From_month=="JUN")
			Date_From_month="06";
		else if(Date_From_month=="JUL")
			Date_From_month="07";
		else if(Date_From_month=="AUG")
			Date_From_month="08";
		else if(Date_From_month=="SEP")
			Date_From_month="09";
		else if(Date_From_month=="OCT")
			Date_From_month="10";
		else if(Date_From_month=="NOV")
			Date_From_month="11";
		else if(Date_From_month=="DEC")
			Date_From_month="12";
	
	var Date_To_date=Number(Date_To.substring(0,Date_To.indexOf("/")));	
	var Date_From_date=Number(Date_From.substring(0,Date_From.indexOf("/")));

		
	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));
	var Date_From_year=Number(Date_From.substring(Date_From.lastIndexOf("/")+1,Date_From.length));

		

	if(Date_To_year<Date_From_year)
	{
		alert("To Date cannot be less than From  Date.");
		return false;
	}


	else if(Date_To_year>Date_From_year)
	{
		
		//if(Date_From_month>Date_To_month)
		//{
		//alert("To Date can not be less than From Date.");
		//return false;
		//}
		 if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{
				
				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}


	else if(Date_To_year==Date_From_year)
	{
	
		if(Date_From_month>Date_To_month)
		{
		alert("To Date can not be less than From Date.");
		return false;
		}
		else if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{

				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}
	
	
	var to_Date_1 = new Date(Date_To_month+"/"+Date_To_date+"/"+Date_To_year);
	var from_Date_1 = new Date(Date_From_month+"/"+Date_From_date+"/"+Date_From_year);
	var oneDay=1000*60*60*24;

	var dateDiff=Math.ceil((to_Date_1.getTime()-from_Date_1.getTime())/oneDay);

	if(dateDiff>90)
	{
		alert('Date Range can not be greater than 90 days.');
		return false;
	}
	
return true;
}

function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}

function ValidateForm(emailID){
//	var emailID=document.frmSample.txtEmail
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }
	
function ChangeDateTag(obj)
{
	var InsertVal='';
	for(iterate=0;iterate<obj.length;iterate++)
	{
		if(obj.options[iterate].selected==true)
		{
			InsertVal=InsertVal+obj.options[iterate].value+'/';
		}
	}
	InsertVal=InsertVal.substring(0,InsertVal.length-1);
	var Table=document.getElementById('newgen');
	var lastRow = Table.rows.length;
	if (lastRow > 0) Table.deleteRow(lastRow - 1);
	while(InsertVal.indexOf('_')!=-1)
	{
		InsertVal=InsertVal.replace('_',' ');
	}
	var Row=Table.insertRow(0);
	var Cell=Row.insertCell();
	Cell.className="EWLabelBoldNew";
	Cell.innerHTML=InsertVal;
}

function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";
	sDate	= window.showModalDialog('/processmanager/reports/GMACReports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');
	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
	

}
function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	strResult=strdate+"/"+strMonth+"/"+stryear;
	return strResult;
}


	function openreport()
	{	
		var DocumentCategoryType="";
		var QCChecklist="";
		
		var QCReason="";
		
		
		
		var DateRangeFrom="";
		var DateRangeTo="";
		var UserEmailID=document.getElementById('EMail-ID').value;
		
		DateRangeFrom=document.forms["textForm"].From_Date.value;
		DateRangeTo=document.forms["textForm"].To_Date.value;

		//alert(UserEmailID+""+DateRangeFrom+""+DateRangeTo) ;
		
		for(var i=0;i<document.forms["textForm"].Document_Category.length;i++)
			{
				if(document.forms["textForm"].Document_Category[i].selected)
				{
					DocumentCategoryType=DocumentCategoryType+document.forms["textForm"].Document_Category[i].value+'~';
				}
			}
		
		for(var i=0;i<document.forms["textForm"].QC_QueueChecklist.length;i++)
			{
				if(document.forms["textForm"].QC_QueueChecklist[i].selected)
				{
					QCChecklist=QCChecklist+document.forms["textForm"].QC_QueueChecklist[i].value+'~';
				}
			}
		
		for(var i=0;i<document.forms["textForm"].QC_Reason.length;i++)
			{
				if(document.forms["textForm"].QC_Reason[i].selected)
				{
					QCReason=QCReason+document.forms["textForm"].QC_Reason[i].value+'~';
				}
			}
			
		var sTestDocumentCategoryType=DocumentCategoryType.split('~');
		var sTestQCQueueChecklist=QCChecklist.split('~');
		var sTestQCReason=QCReason.split('~');
		

		if(DateRangeFrom=='')
		{
			alert("Please select an appropriate From Date");
			return false;
		}
		if(DateRangeTo=='')
		{
			alert("Please select an appropriate To Date");
			return false;
		}
				

		if(DocumentCategoryType.indexOf("All")!=-1 && sTestDocumentCategoryType.length>2)
		{
			alert("No other Document Category can be chosen after choosing All");
			return false;
		} 
		
		if(QCChecklist.indexOf("All")!=-1 && sTestQCQueueChecklist.length>2)
		{
			alert("No other QC Checklist can be chosen after choosing All");
			return false;
		} 
		
		if(QCReason.indexOf("All")!=-1 && sTestQCReason.length>2)
		{
			alert("No other QC Reason for failure can be chosen after choosing All");
			return false;
		} 
		
		
		/*if(DocumentCategoryType=='Non PO Invoices~Policy Holder Payments~Escheatment~Credit Memo~Statement~Others~')
		{
			DocumentCategoryType='All~';
		}*/
		
		if(DocumentCategoryType=='')
		{
			alert('Kindly Select Document Category');
			return false;
			//DocumentCategoryType='All~';
		}
		
		if(QCChecklist=='')
		{
			alert('Kindly Select QC Checklist');
			return false;
			//QCChecklist='All~';
		}
		
		if(QCReason=='')
		{
			alert('Kindly Select QC Reason for Failure');
			return false;
			//QCReason='All~';
		}

		if(DateRangeFrom==""||DateRangeTo=="")
		{
			alert("Select the Date Range.");
			return false;
		}
	
	
		 if ((DateRangeFrom=="" && DateRangeTo!="") || (DateRangeFrom!="" && DateRangeTo==""))
		{
			alert("Enter the complete Date Range.");
			return false;
		}
		
		if(!DateComparator(DateRangeTo,DateRangeFrom))
		{
			return false;
		}

		if(UserEmailID=='')
		{
			alert("Kindly enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
			}
		}
		//alert("ManualIntroductionReportGenerate.jsp?VendorRequestType="+VendorRequestType+"&VendorType="+VendorType+"&DateRangeFrom="+DateRangeFrom+"&DateRangeTo="+DateRangeTo+"&ReportName=<%=request.getParameter("ReportName")%>&UserEmailID="+UserEmailID) ;
		if((UserEmailID!='')&&(DateRangeFrom!='')&&(DateRangeTo!=''))
		{
			
			//OpenRedict-Fix
			//window.top.QCSTATUSREPORT.location.href="QCStatusReportGenerate.jsp?DocumentCategoryType="+DocumentCategoryType+"&QCChecklist="+QCChecklist+"&QCReason="+QCReason+"&DateRangeFrom="+DateRangeFrom+"&DateRangeTo="+DateRangeTo+"&ReportName=<%=request.getParameter("ReportName")%>&UserEmailID="+UserEmailID;
			var URI = "QCStatusReportGenerate.jsp?DocumentCategoryType="+DocumentCategoryType+"&QCChecklist="+QCChecklist+"&QCReason="+QCReason+"&DateRangeFrom="+DateRangeFrom+"&DateRangeTo="+DateRangeTo+"&ReportName=<%=request.getParameter("ReportName")%>&UserEmailID="+UserEmailID;
			var StrOpenWin=strip_tags(URI,"");
			window.top.QCSTATUSREPORT.location.href=StrOpenWin;
			
			
		}
		
}



function Add_to_QC_Reason()
{
var flag=0;
 var x = document.getElementById("QC_QueueChecklist");
 var theSelect = document.getElementById("QC_Reason"); 
  var i = 0;

  for (i = 0; i < theSelect.length; i++){
  if (theSelect == null) return;
	if (theSelect.options == null) return;
  while (theSelect.options.length > 0) {
		theSelect.remove(0);
		}
  }
  
	var option = document.createElement("option");     
	option.value="All";
	option.innerHTML="All";
	theSelect.appendChild(option);
  
  for (i = 0; i < x.length; i++){
    var selectedOne = x.options[i];
    if (selectedOne.selected == true){
	
<%	
for(String value_keyset : myMultimap.keySet()) 
{  
%>	
		 if (selectedOne.value == '<%=value_keyset%>')
		 {
			<%
			Collection listreason = myMultimap.get(value_keyset);  
			Iterator itr_reason = listreason.iterator();
			while(itr_reason.hasNext()) {
			%>
				var reasons='<%=itr_reason.next()%>';
				var option = document.createElement("option");     
				option.value=reasons;
				option.innerHTML=reasons;
				theSelect.appendChild(option);
			<%
		}
			%>
			
		}
<%	
}
%>

			if(selectedOne.value=="All")
			{
			theSelect.value = "All";
			}
	 
    }
  }
 
}


	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}
	
</script>



<body topmargin="0" leftmargin="5" onunload="UnloadReportWindow();">

			<form name='textForm' method=post>


			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">TA AP QC STATUS REPORT</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This report will provide the list of workitems that have failed in QC queue for the selected date range along with the failed parameters.
</td></tr>
<tr><td class="EWLabel1">Select the requisite date range for generating the report for the same.<br><b></b></td>
				</tr>
				
				<td>
		<br/>
					<p style="color: red; font-size: 10pt">Note:  * fields are mandatory.</p>

				</td>
			</table>

			

			<table border="0" width="95%" cellspacing="1" align="center">

			 <tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>Introduction Date Range<font color="RED">*</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date" readonly type="text"  id="From_Date" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date" readonly  type="text"  id="To_Date" >
					
					</td>

				</tr>
				
				
				
			<tr>
					<td class="EWLabel1" align="left" width='20%'><b>Document Category<font color="RED">*</font></b></font></td>
					<td width='25%' colspan=3>
					<select style='width:45%' name="Document_Category" multiple>
					<option value="All">All</option>
					<option value="PO Invoices">PO Invoices</option>
					<option value="Non PO Invoices">Non PO Invoices</option>
					<option value="Policy Holder Payments">PH Payments</option>
					<option value="Escheatment">Escheatment</option>
					<option value="Credit Memo">Credit Memo</option>
					<option value="Statement">Statement</option>
					<option value="Others">Others</option>
					</select>
					</td>
				</tr>

				<tr>&nbsp;</tr>
				
			
			
			<tr>
					<td class="EWLabel1" align="left" width='20%'><b>QC Checklist<font color="RED">*</font></b></font></td>
					<td width='25%' colspan=3>
					<select style='width:45%' id="QC_QueueChecklist" name="QC_QueueChecklist" onChange="Add_to_QC_Reason()" multiple>
					<option value="All">All</option>
					<%					
						for(String value : myMultimap.keySet()) {  
						%>
						<option value='<%= value%>'><%= value%></option> 
						<%
					} 
					%>
					</select>
					</td>
				</tr>
				
				<tr>
					<td class="EWLabel1" align="left" width='20%'><b>QC Reason for failure<font color="RED">*</font></b></font></td>
					<td width='25%' colspan=3>
					<select style='width:100%' id="QC_Reason" name="QC_Reason" multiple>
					<option value="All">All</option>
					<%
					/*
					Iterator itr1=QCReason_list.iterator();
					String temp="";
					while(itr1.hasNext())
					{	
						temp=(String)itr1.next();
						%>
						<option value='<%= temp%>'><%= temp%></option> 
						<%
					}
					*/
					%>
					</select>
					</td>
				</tr>

				
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID<font color="RED">*</font></b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id="EMail-ID">
					</td>
				</tr>
				

				
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>
	</form>
</body>
</Html>	 




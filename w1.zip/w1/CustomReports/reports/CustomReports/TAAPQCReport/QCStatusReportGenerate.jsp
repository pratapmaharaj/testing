<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ include file="customized.process" %>
<%@ page import="java.sql.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>

<HTML>
<HEAD>
<TITLE>AP QC Status Report</TITLE>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>

</script>


<body>

<%

    Connection conn = null;
	Statement st;

	String sProcedureName=null;
	String sReportName=null;
	String sFileName=null;
	String sProcedureNameKey=null;
	String sFileNameKey=null;
	String sUserMailID=null;
	String sFileNamePathKey="";
	String sFilePath="";
	
	
	WriteLog("TA_AP_QC_StatusReport ","Inside QC Status Report Generate.......!!!!!");
	
	sReportName	=request.getParameter("ReportName");
	sReportName	=sReportName.toUpperCase();
	sUserMailID=request.getParameter("UserEmailID");
	sProcedureNameKey=sReportName +"_PROCEDURENAME";
	sFileNameKey=sReportName+"_FILENAME";
	sFileNamePathKey=sReportName+"_FILEPATH";
	
	WriteLog("TA_AP_QC_StatusReport "," sReportName : "+sReportName);
	WriteLog("TA_AP_QC_StatusReport "," sUserMailID : "+sUserMailID);
	WriteLog("TA_AP_QC_StatusReport "," sProcedureNameKey : "+sProcedureNameKey);
	WriteLog("TA_AP_QC_StatusReport "," sFileNameKey : "+sFileNameKey);
	WriteLog("TA_AP_QC_StatusReport "," sFileNamePathKey : "+sFileNamePathKey);
	
	
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAAPQCStatusReport.ini";
	
	Properties ini = new Properties();
	
	WriteLog("TA_AP_QC_StatusReport "," Before INI Load sRootPathini : "+sRootPathini);
	
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("TA_AP_QC_StatusReport","Unable to read TA_AP_QC_StatusReport.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("TA_AP_QC_StatusReport","Unable to close the TA_AP_QC_StatusReport.ini file");
						}
					}
				}
;

	WriteLog("TA_AP_QC_StatusReport "," After INI Load");
	
	sProcedureName     =ini.getProperty(sProcedureNameKey);;
	sFileName          =ini.getProperty(sFileNameKey);
	sFilePath		   =ini.getProperty(sFileNamePathKey);
	
	WriteLog("TA_AP_QC_StatusReport "," sRootPathini : "+sRootPathini);
	WriteLog("TA_AP_QC_StatusReport "," sProcedureName : "+sProcedureName);
	WriteLog("TA_AP_QC_StatusReport "," sFileName : "+sFileName);
	WriteLog("TA_AP_QC_StatusReport "," sFilePath : "+sFilePath);
	
	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("TA_AP_QC_StatusReport ","sRootPathDBini="+sRootPathDBini);
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("TA_AP_QC_StatusReport","Unable to read TA_AP_QC_StatusReport.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("TA_AP_QC_StatusReport","Unable to close the TA_AP_QC_StatusReport.ini file");
						}
					}
				}
	
	String driverName = null;

	String connectionUrl=ini.getProperty("CONNECTIONSTRING");
	driverName = ini.getProperty("DRIVERNAME");
	CallableStatement callableStatement = null;

	WriteLog("TA_AP_QC_StatusReport "," output "+connectionUrl);

	String sDocumentCategoryType=request.getParameter("DocumentCategoryType");
	String sQCChecklist=request.getParameter("QCChecklist");
	String sQCReason=request.getParameter("QCReason");
	String sFromDate    =request.getParameter("DateRangeFrom");
	String sToDate      =request.getParameter("DateRangeTo");
	
	boolean bError=false;
	WriteLog("TA_AP_QC_StatusReport "," output "+sProcedureName);
	
	
	String getDBUSERByUserIdSql = "{call "+sProcedureName+"(?,?,?,?,?,?,?,?,?)}";
	String output = "" ;
	try
	{
		WriteLog("TA_AP_QC_StatusReport "," sDocumentCategoryType "+sDocumentCategoryType);
		WriteLog("TA_AP_QC_StatusReport "," sQCChecklist "+sQCChecklist);
		WriteLog("TA_AP_QC_StatusReport "," sQCReason "+sQCReason);
		WriteLog("TA_AP_QC_StatusReport "," sFromDate "+sFromDate);
		WriteLog("TA_AP_QC_StatusReport "," sToDate "+sToDate);
		WriteLog("TA_AP_QC_StatusReport "," sUserMailID "+sUserMailID);
		
			Class.forName(driverName);
			conn = DriverManager.getConnection(connectionUrl);
			callableStatement = conn.prepareCall(getDBUSERByUserIdSql);
			callableStatement.setString(1, sDocumentCategoryType);
			callableStatement.setString(2, sFromDate);
			callableStatement.setString(3, sToDate);
			callableStatement.setString(4, sUserMailID);
			callableStatement.setString(5, sQCReason);
			callableStatement.setString(6, sQCChecklist);
			callableStatement.setString(7, sFilePath);
			callableStatement.setString(8, sFileName);
			callableStatement.registerOutParameter(9, java.sql.Types.VARCHAR);
			
			callableStatement.execute();
			

			output = callableStatement.getString(9);
			//output = "1";
			WriteLog("TA_AP_QC_StatusReport "," output "+output);
	}
	catch(SQLException ignore)
	{
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		bError= true;
		WriteLog("TA_AP_QC_StatusReport "," WFSession Data Fetch Exception:::::: "+ignore.toString());
		%>
									<script>alert("Unable to retrive the value !!!\nClose the browser and delete cookies by pressing CTRL + F5 !!!\nIf problem persists then your browser does not support the application !!!");</script>
		<%
		
	}
	finally {
 
	if (callableStatement != null) {
        try {
            callableStatement.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
	}

	if(!bError)
	{

		WriteLog("TA_AP_QC_StatusReport "," output:::::: "+output);
		try
		{

			if(output==null || output.equals("")  )
			{
				bError= true;
				WriteLog("TA_AP_QC_StatusReport "," bError:::::: "+bError);
				%>
									<script>alert("Unable to retrive the value !!!\nClose the browser and delete cookies by pressing CTRL + F5 !!!\nIf problem persists then your browser does not support the application !!!");</script>
				<%
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+output+"</b></font><center>");
				
			}
			else
			{
				
					try
							{
								 if(Integer.parseInt(output) == 0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
								out.println(ig.toString());
												
							}
			}
		}
		
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
			//log("Introduction Report Exception : "+exp.toString());
		}
		
	}

%>

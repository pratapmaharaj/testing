 <%@ include file="customized.process" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<HTML>
<HEAD>
<TITLE>AP Exception Resolution Report</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>
<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
}
</style>
<script>
	$(document).ready(function(){$('#From_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	
	});
	var allWindows = new Array();
	var win; // new window object
	/*functions echeck,ValidateForm added by nilesh*/
	function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}

function ValidateForm(emailID){
//	var emailID=document.frmSample.txtEmail
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }


/*added by nilesh for comparision of Dates*/

function DateComparator(Date_To,Date_From)
	{	
			if (Date_From == "" && Date_To == "")
			{
				return false;
			}

			var FromDay = Date_From.split("/")[0];
			var FromMonth = convertMonth(Date_From.split("/")[1]);
			var FromYear = Date_From.split("/")[2];
			
			//alert("From:::Day::"+FromDay+"  Month::"+FromMonth+"	Year::"+FromYear);
			
			var ToDay = Date_To.split("/")[0];
			var ToMonth = convertMonth(Date_To.split("/")[1]);
			var ToYear = Date_To.split("/")[2];
			
			//alert("To:::Day::"+ToDay+"  Month::"+ToMonth+"	Year::"+ToYear);
			
			var CurrentDate=new Date();
			var CurrentDay = CurrentDate.getDate();
			var CurrentMonth = CurrentDate.getMonth();
			//var CurrentYear = CurrentDate.getFullYear();
			var CurrentYear = CurrentDate.getFullYear();
			//alert("Current:::Day::"+CurrentDay+"  Month::"+CurrentMonth+"	Year::"+CurrentYear);

			var toDate = (new Date(ToYear,ToMonth,ToDay)).getTime();
			var fromDate = (new Date(FromYear,FromMonth,FromDay)).getTime();
			var CurrentDate = (new Date(CurrentYear,CurrentMonth,CurrentDay)).getTime();
			
			//alert("FromDate::"+fromDate+"  ToDate::"+toDate+"	Current::"+CurrentDate);

			//alert("Fr : "+new Date(fromDate)+"\nTo : "+new Date(toDate)+"\nCu : "+new Date(CurrentDate));
			if(fromDate > toDate)
			{
				alert("To Date cannot be less than From Date.");
				return false;
			}
			else if(fromDate > CurrentDate)
			{
				alert("From Date cannot be future date.");
				return false;
			}
			else if(toDate > CurrentDate)
			{
				alert("To Date cannot be future date.");
				return false;
			}
			//alert("BAzooka111111!!!");
			return true;
	
	}
	function convertMonth(strMonth)
{
		if(strMonth=="JAN")
			strMonth="00";
		else if(strMonth=="FEB")
			strMonth="01";
		else if(strMonth=="MAR")
			strMonth="02";
		else if(strMonth=="APR")
			strMonth="03";
		else if(strMonth=="MAY")
			strMonth="04";
		else if(strMonth=="JUN")
			strMonth="05";
		else if(strMonth=="JUL")
			strMonth="06";
		else if(strMonth=="AUG")
			strMonth="07";
		else if(strMonth=="SEP")
			strMonth="08";
		else if(strMonth=="OCT")
			strMonth="09";
		else if(strMonth=="NOV")
			strMonth="10";
		else if(strMonth=="DEC")
			strMonth="11";
	return strMonth;
}


	
	
function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
var sDate="";
       sDate	= window.showModalDialog('/processmanager/reports/GMACReports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');



	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
	

}
function ChangeDateTag(obj)
{
	var InsertVal='';
	for(iterate=0;iterate<obj.length;iterate++)
	{
		if(obj.options[iterate].selected==true)
		{
			InsertVal=InsertVal+obj.options[iterate].value+'/';
		}
	}
	InsertVal=InsertVal.substring(0,InsertVal.length-1);
	var Table=document.getElementById('newgen');
	var lastRow = Table.rows.length;
	if (lastRow > 0) Table.deleteRow(lastRow - 1);
	while(InsertVal.indexOf('_')!=-1)
	{
		InsertVal=InsertVal.replace('_',' ');
	}
	var Row=Table.insertRow(0);
	var Cell=Row.insertCell();
	Cell.className="EWLabelBoldNew";
	//Cell.innerHTML=InsertVal;
}
function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	strResult=strdate+"/"+strMonth+"/"+stryear;
	return strResult;
}


	function openreport()
	{			
		
		var QueueName="";
		var DocumentCategoryType="";
		var VendorName = document.getElementById("Vendor_Name").value ;
		var VendorNumber = document.getElementById("Vendor_Number").value ;
		var Exp="";
		var bExpSelected=false;
		var bQueueNameSelected=false;
		var bVendorTypeSelected=false;
		DateRangeFrom=document.forms["textForm"].From_Date.value;
		DateRangeTo=document.forms["textForm"].To_Date.value;

		var UserEmailID=document.getElementById('EMail-ID').value;//added by nilesh
		
		for(var i=0;i<document.forms["textForm"].Queue.length;i++)
		{
			if(document.forms["textForm"].Queue[i].selected)
			{
			QueueName=QueueName+document.forms["textForm"].Queue[i].value+'~';
			
			}
		}

		for(var i=0;i<document.forms["textForm"].Document_Category.length;i++)
			{
				if(document.forms["textForm"].Document_Category[i].selected)
				{
					DocumentCategoryType=DocumentCategoryType+document.forms["textForm"].Document_Category[i].value+'~';
				}
			}

		for(var i=0;i<document.forms["textForm"].ExceptionType.length;i++)
		{
			if(document.forms["textForm"].ExceptionType[i].selected)
			{
			Exp=Exp+document.forms["textForm"].ExceptionType[i].value+'~';
			
			}
		}
		
		
		var sTestDocumentCategoryType=DocumentCategoryType.split('~');
		var sTestQueueName=QueueName.split('~');
		var sTestExp=Exp.split('~');

		if(Exp=='')
		{
			Exp = "All~" ;
		}
		if(DateRangeFrom=='')
		{
			alert("Please select WI Introduction DateRange From Date");
			return false;
		}
		if(DateRangeTo=='')
		{
			alert("Please select WI Introduction DateRange To Date");
			return false;
		}
		
		if ((DateRangeFrom=="" && DateRangeTo!="") || (DateRangeFrom!="" && DateRangeTo==""))
		{
			alert("Enter the complete Date Range.");
			return false;
		}
		
		if(DocumentCategoryType.indexOf("All")!=-1 && sTestDocumentCategoryType.length>2)
		{
			alert("No other Vendor Type can be chosen after choosing All");
			return false;
		} 
		
		if(QueueName.indexOf("All")!=-1 && sTestQueueName.length>2)
		{
			alert("No other Queue Name can be chosen after choosing All");
			return false;
			//DocumentType='All~';
		} 

		if(Exp.indexOf("All")!=-1 && sTestExp.length>2)
		{
			alert("No other Exception can be chosen after choosing All");
			return false;
			//Exp='All~';
		} 

		if(DocumentCategoryType=='Payment Request~Non PO Invoices~Policy Holder Payments~Escheatment~Credit Memo~Statement~Others~')
		{
			DocumentCategoryType='All~';
		}
		if(DocumentCategoryType=='')
		{
			DocumentCategoryType='All~';
		}
		if(QueueName=='Introduction~Processing~Coding~Approval~QC~GEACINTERFACE~PendingResolution~Rescan~Split~Cancel~ApprovalException~PolicyHolderPayment~PendingPayment~JournalEntry~')
		{
			QueueName='All~';
		}
		
		if(Exp=='Query_Missing_Information~W9_Missing~PO_Receipt_Not_Done~Multiple_Document~Missing_Document~Bad_Image~Vendor_Setup~Vendor_Amendments~Cancel_Duplicate~Missing_Cost_Centre_Owner~Missing_Approval_Level_Limit~Missing_paying_Entity~')
		{
			Exp='All~';
		}

		if(VendorName=="")
		{
			VendorName="" ;
		}

		if(VendorNumber=="")
		{
			VendorNumber="" ;
		}

		if(QueueName=="")
		{
			QueueName = "All~" ;
		}

		if(!DateComparator(DateRangeTo,DateRangeFrom))
		{
		return false;
		}
		
		if(UserEmailID=='')
		{
			alert("Please enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
			}
		}


		if(UserEmailID!='')
			{//window.top.TCIException.location.href="TCIExceptionGenerate.jsp?DocumentType="+DocumentType+"&sExp="+sExp+"&FromDates="+DateRangeFrom+"&ToDate="+DateRangeTo+"&ReportName=<%=request.getParameter("ReportName")%>&UserEmailID="+UserEmailID;
		
			//window.top.EXCEPTION.location.href="APExceptionResolutionGenerate.jsp?FromDates="+DateRangeFrom+"&ToDate="+DateRangeTo+"&sExp="+Exp+"&UserEmailID="+UserEmailID+"&DocumentCategoryType="+DocumentCategoryType+"&QueueName="+QueueName+"&ReportName=<%=request.getParameter("ReportName")%>"+"&VendorNumber="+escape(VendorNumber)+"&VendorName="+escape(VendorName) ;
			//OpenRedict-Fix
			//window.top.APEXCEPTIONRESOLUTION.location.href="APExceptionResolutionGenerate.jsp?FromDates="+DateRangeFrom+"&ToDate="+DateRangeTo+"&sExp="+Exp+"&UserEmailID="+UserEmailID+"&DocumentCategoryType="+DocumentCategoryType+"&QueueName="+QueueName+"&ReportName=<%=request.getParameter("ReportName")%>"+"&VendorNumber="+escape(VendorNumber)+"&VendorName="+escape(VendorName) ;
			
			var URI = "APExceptionResolutionGenerate.jsp?FromDates="+DateRangeFrom+"&ToDate="+DateRangeTo+"&sExp="+Exp+"&UserEmailID="+UserEmailID+"&DocumentCategoryType="+DocumentCategoryType+"&QueueName="+QueueName+"&ReportName=<%=request.getParameter("ReportName")%>"+"&VendorNumber="+escape(VendorNumber)+"&VendorName="+escape(VendorName) ;
			var StrOpenWin=strip_tags(URI,"");
			window.top.APEXCEPTIONRESOLUTION.location.href=StrOpenWin;
			}
}
/*function fnVendorSearch()
{
	var sFeatures = "dialogHeight:500px; dialogWidth:575px; status:no; dialogHide:no;";
	var sVendorInfo= window.showModalDialog("..\\..\\..\\..\\webdesktop\\CustomForms\\TA_AP_Custom\\AP\\srcVendor\\SearchMain.jsp",'',sFeatures);
	if(sVendorInfo == undefined)
	{
		sVendorInfo="";
	}
	else
	{
		var dataReturned = sVendorInfo.split("~");
		document.getElementById("Vendor_Name").value=dataReturned[1];
		document.getElementById("Vendor_Number").value=dataReturned[2];
		
	}
	return true ;
}*/
function UnloadReportWindow()
{
	if(win!=null)
		win.close();
}

</script>


<body topmargin="0" leftmargin="5" onload="" onunload="UnloadReportWindow();">

			<form name='textForm' method=post>


			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">TA AP EXCEPTION REPORT</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This report will provide the time for pending exceptions.
</td></tr>
<tr><td class="EWLabel1">Select All Exception Types if report is to be generated for all the Exception Types available, else select the specific Exception Type, multiple selections are acceptable.
</td></tr><tr><td class="EWLabel1">Select the requisite date range for generating the report for the same.<br>
<b>Exception Name and Date Range are mandatory.</b></td>
				</tr>
				
				<td>
		<br/>
					<p style="color: red; font-size: 10pt">Note:  * fields are mandatory.</p>

				</td>
			</table>
			<table border="0" width="95%" cellspacing="1" align="center">
				 <tr>
					<td class="EWLabel1" align="left" width='20%'><b>Queue</b></td>
					<td width='35%' colspan=3>
					<select style='width:45%' name="Queue" multiple>
					<option value="All">All</option>
					<option value="Introduction">Introduction</option>
					<option value="Processing">Processing</option>
					<option value="PolicyHolderPayment">PolicyHolderPayment</option>
					<option value="PendingResolution">Pending Resolution</option>
					<option value="Rescan">Rescan</option>
					<option value="Split">Split</option>
					<option value="Cancel">Cancel</option>
					<option value="QC">QC</option>
					<option value="Coding">Coding</option>
					<option value="Approval">Approval</option>
					<option value="ApprovalException">ApprovalException</option>
					<option value="GEACINTERFACE">GEAC INTERFACE</option>
					<option value="JournalEntry">JournalEntry</option>
					<option value="PendingPayment">PendingPayment</option>
					</select>
					</td>
				</tr>
				<tr>
					<td class="EWLabel1" align="left" width='20%'><b>Document Category</b></font></td>
					<td width='25%' colspan=3>
					<select style='width:45%' name="Document_Category" multiple>
					<option value="All">All</option>
					<option value="Payment Request">Payment Request</option>
					<option value="PO Invoices">PO Invoices</option>
					<option value="Non PO Invoices">Non PO Invoices</option>
					<option value="Policy Holder Payments">PH Payments</option>
					<option value="Escheatment">Escheatment</option>
					<option value="Credit Memo">Credit Memo</option>
					<option value="Statement">Statement</option>
					<option value="Others">Others</option>
					
				
					</select>
					</td>
				</tr>
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Exception Name</b></td>
					<td width='35%' colspan=3>
					<select style='width:45%' class='TextFieldColor' name="ExceptionType" multiple >
					<option value="All">ALL</option>
					<option value="Query_Missing_Information">Query Missing Information</option>
					<option value="W9_Missing">W9 Missing</option>
					<option value="PO_Receipt_Not_Done">PO Receipt Not Done</option>
					<option value="Multiple_Document">Multiple Document</option>
					<option value="Missing_Document">Missing Document</option>
					<option value="Bad_Image">Bad Image</option>
					<option value="Vendor_Setup">Vendor Setup</option>
					<option value="Vendor_Amendments">Vendor Amendments</option>
					<option value="Cancel_Duplicate">Cancel Duplicate</option>
					<option value="Missing_Cost_Centre_Owner">Missing Cost Centre Owner</option>
					<option value="Missing_Approval_Level_Limit">Missing Approval Level Limit</option>
					<option value="Missing_paying_Entity">Missing paying Entity</option>
					
					</select>
					</td>
				</tr>
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Vendor Name</b></td>
					<td width='100%' colspan=3>
						<input name="Vendor_Name" id="Vendor_Name" type="text"  maxLength=40 class='TextFieldColorLight'>
						
						<!--<img onClick="fnVendorSearch();" id="VendorNamesearch" src="/webdesktop/CustomForms/TA_AP_Custom/Web/images/search5.gif" alt="Vendor Name search" width="20" height="20" align="absmiddle">-->
					</td>
				</tr>
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Vendor Number</b></td>
					<td width='35%' colspan=3>
						<input name="Vendor_Number" id="Vendor_Number" type="text"  maxLength=40 class='TextFieldColorLight'>
					</td>
				</tr>
				<tr>&nbsp;</tr>
				 <tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>WI Introduction Date Range<font color="RED">*</font> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date" readonly type="text"  id="From_Date" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date" readonly type="text"  id="To_Date" >
					
					</td>

				</tr>


				<!--Added by nilesh for additional E-mail ID field display -->
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID<font color="RED">*</font></b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>

				
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>
	

			</form>

</body>
</Html>	 

<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ include file="customized.process" %>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="java.sql.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>

<HTML>
<HEAD>
<TITLE>AP Exception Resolution Report</TITLE>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="/../../../omniflow/scripts/wfgeneral.js">



</script>


<body>
<%
		
	//Connection conn = null;
	Statement st;
	//String connectionUrl =""; 
	boolean empty=true;
	String sProcedureName=null;
	String sColumnHeaders=null;
	String sReportName=null;
	String sFileName=null;
	String sNumberOfColumns=null;
	String sProcedureNameKey=null;
	String sColumnHeadersKey=null;
	String sFileNameKey=null;
	String sNumberOfColumnsKey=null;
	String sHeaderKey=null;
	String sHeaderPresentKey=null;
	String sDBMappedColsKey=null;
	String sHeaderValue=null;
	String sHeaderPresentValue=null;
	String sCabinetName=null;	
	String sDBMappedCols=null;
	String sFieldValuesKey=null;
	String sFieldValues=null;
	int BagImageCount=0;
	int MultipleDocCount=0;
	int NewVendorCount=0;
	int Miscellaneous=0;
	int DuplicateCount=0;
	int NotInvoiceCount=0;
	int CostQualityVariance=0;
	int MissingPO=0;
	int MissingIncApprovalCount=0;
	int GoodsRecptVarification=0;
	int IncorrectCoding=0;
	String sUserMailID=null;//added by nilesh
	String sPath="" ;

	WriteLog("APExceptionResolutionREPORT","sOutputXML ::> sOutputXML : ");

	sUserMailID=request.getParameter("UserEmailID");
	sReportName	=request.getParameter("ReportName");
	sReportName	=sReportName.toUpperCase();
	sProcedureNameKey=sReportName +"_PROCEDURENAME";
	sColumnHeadersKey=sReportName+"_COLUMNHEADERS";
	sFileNameKey=sReportName+"_FILENAME";
	sNumberOfColumnsKey=sReportName+"_NUMBEROFCOLUMNS";
	sHeaderPresentKey=sReportName+"_HEADERPRESENT";
	sHeaderKey=sReportName+"_HEADER";
	sDBMappedColsKey=sReportName+"_DBMAPPEDCOLS";
	sFieldValuesKey=sReportName+"_FIELDVALUES";
	sPath=sReportName+"_PATH" ;

	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAAPExceptionResolutionReport.ini";
	//String sRootPathini=application.getRealPath("")+File.separator+"reports"+File.separator+"GMACReports"+File.separator+"ApprovalProcessExceptionResolutionReport" + File.separator+"reports.ini";
	
	Properties ini = new Properties();
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("APExceptionResolutionREPORT","Unable to read APExceptionResolutionREPORT.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("APExceptionResolutionREPORT","Unable to close the APExceptionResolutionREPORT.ini file");
						}
					}
				}
	
	
	sProcedureName=ini.getProperty(sProcedureNameKey);
	sColumnHeaders=ini.getProperty(sColumnHeadersKey);
	sFileName=ini.getProperty(sFileNameKey);
	sNumberOfColumns=ini.getProperty(sNumberOfColumnsKey);
	sHeaderPresentValue=ini.getProperty(sHeaderPresentKey);
	sDBMappedCols=ini.getProperty(sDBMappedColsKey);
	sFieldValues=ini.getProperty(sFieldValuesKey);
	sFieldValues=sFieldValues.replaceAll("#",",");
	sPath=ini.getProperty(sPath);
	sCabinetName=ini.getProperty("CABINETNAME");
/*	connectionUrl      =ini.getProperty("ConnectionUrl");
	String dbuserName = ini.getProperty("username");
	String dbpass     = ini.getProperty("password");*/

	
//	connectionUrl = connectionUrl+";"+"databaseName="+sCabinetName+";user="+dbuserName+";password="+dbpass;
//	CallableStatement callableStatement = null;

//	WriteLog("APExceptionResolutionREPORT"," output "+connectionUrl);

	if(sHeaderPresentValue.equals("YES")) {
	sHeaderValue=ini.getProperty(sHeaderKey);

	}

	String sCabname=null;
	String sSessionId = null;
	String sJtsIp = null;
	String sUserName = null;
	String sReportProcedureName=null;
	String sReportTableName=null;
	
	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("APExceptionResolutionREPORT","sRootPathDBini="+sRootPathDBini);
	
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("APExceptionResolutionREPORT","Unable to read APExceptionResolutionREPORT.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("APExceptionResolutionREPORT","Unable to close the APExceptionResolutionREPORT.ini file");
						}
					}
				}
	String driverName = null;

	String connectionUrl=ini.getProperty("CONNECTIONSTRING");
	driverName = ini.getProperty("DRIVERNAME");
	WriteLog("APExceptionResolutionREPORT"," output "+connectionUrl);	
	
	String QueueName=request.getParameter("QueueName");
	String sExp=request.getParameter("sExp");
	String sFromDate=request.getParameter("FromDates");
	String sToDate=request.getParameter("ToDate");
	String DocumentCategory=request.getParameter("DocumentCategoryType");
	String VendorName=request.getParameter("VendorName");
	String VendorNumber=request.getParameter("VendorNumber");

	String sOutputXML="";
	String sInputXML = "";
	String maincode = "";
	String Totalrec = "0";
    String sStr_ServerType = null;
	String url = "";
	String Status="";
	double fPercentage=0;
	String sColumnNamesArr[]=split(sColumnHeaders,',');
	String sDBMappedColsArr[]=split(sDBMappedCols,',');
	String sRowXml="";
	String sFinalColumns[]=split(sColumnHeaders,',');
	for(int i=0;i<sColumnNamesArr.length;i++)
	{
		if(sColumnNamesArr[i].indexOf("~D")!=-1)
			sFinalColumns[i]=sColumnNamesArr[i].substring(0,sColumnNamesArr[i].length()-2);

	}

	int iJtsPort = 0;
	boolean bError=false;
	CallableStatement callableStatement = null;
	Connection conn=null;	
	WriteLog("APExceptionResolutionREPORT","sOutputXML ::> sOutputXML : "+bError);
	WriteLog("APExceptionResolutionREPORT","variables="+QueueName+"#"+DocumentCategory+"#"+VendorName+"#"+VendorNumber+"#"+sExp+"#"+sFromDate+"#"+sToDate+"#"+sFieldValues+"#"+sUserMailID+"#"+sPath );
	String getDBUSERByUserIdSql = "{call "+sProcedureName+"(?,?,?,?,?,?,?,?,?,?,?,?)}";
	String output = "" ;
	try
	{
			WriteLog("APExceptionResolutionREPORT","sOutputXML ::> inside try : ");
			Class.forName(driverName);
			conn = DriverManager.getConnection(connectionUrl);
			callableStatement = conn.prepareCall(getDBUSERByUserIdSql);
			callableStatement.setString(1, QueueName);
			callableStatement.setString(2, DocumentCategory);
			callableStatement.setString(3, VendorName);
			callableStatement.setString(4, VendorNumber);
			callableStatement.setString(5, sExp);
			callableStatement.setString(6, sFromDate);
			callableStatement.setString(7, sToDate);
			callableStatement.setString(8, sFieldValues);
			callableStatement.setString(9, sUserMailID);
			callableStatement.setString(10, sPath);
			callableStatement.setString(11, sFileName);
			callableStatement.registerOutParameter(12, java.sql.Types.VARCHAR);
			callableStatement.execute();

			output = callableStatement.getString(12);
			WriteLog("APExceptionResolutionREPORT"," output "+output);
	}
	catch(Exception ignore)
	{
		//out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		bError= true;
		 ignore.printStackTrace();
		WriteLog("APExceptionResolutionREPORT"," WFSession Data Fetch Exception:::::: "+ignore.toString());
	}
	finally {
 
	if (callableStatement != null) {
        try {
            callableStatement.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
}


if(!bError)
	{

		WriteLog("APExceptionResolutionREPORT"," output:::::: "+output);
		try
		{

			if(output.equals(""))
			{
				bError= true;
				//maincode=sOutputXML.substring(sOutputXML.indexOf("<MainCode>")+10 , sOutputXML.indexOf("</MainCode>"));
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+output+"</b></font><center>");
			}
			else
			{
				
					try
							{
								 if(Integer.parseInt(output) == 0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
								out.println(ig.toString());
												
							}
			}
		}
		
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
			WriteLog("APExceptionResolutionREPORT"," output:::::: "+exp.toString());
		}
		
	}
	
	%>

			
		
			<FORM name="textForm">
		

			</form>	
		
	
			

<%!
 public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }


%>





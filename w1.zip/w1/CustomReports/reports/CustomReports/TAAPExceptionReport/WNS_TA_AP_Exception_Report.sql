/*        
WNS_TA_AP_Exception_Report 'All~','All~','All~','All~','All~','20/Feb/2014','24/Feb/2014','Current_Work_Step,a.Wi_Name,b.ExceptionName,Document_Category,Priority,Pay_Entity,Vendor_Name,Vendor_Number,ACH,AP_Check,Invoice_Number,Total_Invoice_Amount,Invoice
_Date,Approver_Comments,Registration_Date,b.ActionDatetime as ExceptionRaisedDatetime,b.ExceptionComments,b.UserId,1,1,Additional_Comments', 'aa@bb.com','//10.33.192.139/XLS-File/Yogesh/APExceptionResolution','APEXCEPTION',''   
  
*/        
        
CREATE PROCEDURE WNS_TA_AP_Exception_Report        
(         
@QueueName nvarchar(250),    
@DocumentCategory  VARCHAR(200),     
@VendorName  VARCHAR(200),    
@VendorNumber  VARCHAR(200),    
@Exp  VARCHAR(200),     
@DateRangeFrom  VARCHAR(50),     
@DateRangeTo  VARCHAR(50),     
@Fields varchar(8000),     
@EmailID varchar(200),    
@FilePath varchar(200),    
@FileName varchar(300),  
@RowCount varchar(200) OUTPUT      
)         
AS         
declare         
  
@WhereQuery    varchar(2000),     
 @Query    varchar(5000),     
 @Query1   varchar(5000),     
 @Querysum varchar(5000),     
 @Tables   varchar(200),     
 @ExpReport     varchar(200),     
 @DocumentCategoryReport varchar(200),     
 @QueueNameReport varchar(200),    
 @VendorNameReport varchar(200),    
 @VendorNumberReport varchar(200),    
 @ProcessTypeReport varchar(200),    
 @OrderBy varchar(300),          
 @Disp_ExceptionName varchar(100),     
 @Count_Exception varchar(100),     
 @status_temp varchar(8000),    
 @processinstanceid varchar(100),    
 @activityname varchar(100) ,    
 @actiondatetime datetime,    
 @exceptioncomments varchar(250),    
 @username varchar(50),    
 @dbname varchar(60)     
        
BEGIN          
 Set nocount on          
 set @FileName=@FilePath+'/'+@EmailID+'_'+@FileName+'_'+convert(varchar,getdate(),104)+'.xls'         
 set @WhereQuery='WHERE '         
 set @ExpReport=''         
 set @QueueNameReport=''        
 set @VendorNumberReport=''        
 set @RowCount='0'       
 set @OrderBy=' order by a.WI_Name'          
        
 print  @FileName        
        
 Create Table #TA_AP_Exception_Report_Temp          
 (        
  Current_Work_Step   nvarchar(150),    
  WI_Name             nvarchar(150),    
  ExceptionName       nvarchar(100),     
  Document_Category       nvarchar(100),    
  Priority         nvarchar(100),    
  Pay_Entity           nvarchar(100),     
  Vendor_Name     nvarchar(100),     
  Vendor_Number     nvarchar(100),  
  ACH   nvarchar(100),  
  AP_Check  nvarchar(100),  
  Invoice_Number            nvarchar(100),    
  Total_Invoice_Amount       nvarchar(100),    
  Invoice_Date         nvarchar(100),    
  Approver_Comments  nvarchar(250),    
  Registration_Date nvarchar(250),    
  Raised_ActionDatetime nvarchar(250),       
  Raised_By_UserId  nvarchar(250),    
  ExceptionComments  nvarchar(250),    
  Aging_In_Days  nvarchar(250),    
  Aging_In_Hrs  nvarchar(250),    
  Additional_Comments  nvarchar(250)      
        
 )        
        
 --create temporary summary table         
 Create Table #TCISummaryException         
 (         
 Disp_ExceptionName varchar(1000),         
 Count_Exception varchar(100)         
 )        
        
 set @Tables='WNS_TA_AP_EXT_Table a with(nolock) ,exceptiontable b with(nolock) '        
        
 set @WhereQuery=@WhereQuery+' a.WI_Name=b.Processinstanceid and b.actionid=''9'' and b.processdefid=''13'''         
        
 if(rtrim(ltrim(@DateRangeFrom))<>'')         
  SET @DateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@DateRangeFrom,121)))))          
 if(rtrim(ltrim(@DateRangeTo))<>'')         
  SET @DateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@DateRangeTo,121)))))          
        
 print @DateRangeFrom         
        
 -- Add Document Type        
 if(rtrim(ltrim(@QueueName))<>'All~')         
 BEGIN         
  --Added to Check for only 1 parameter         
  if(len(@QueueName)=charindex('~',@QueueName))         
  BEGIN         
   set @QueueNameReport=ltrim(rtrim(substring(@QueueName,0,len(@QueueName))))         
   set @WhereQuery=@WhereQuery+' AND current_work_step='''+@QueueNameReport+''''         
  END         
        
  --Added to Check for only 1 parameter           
  else         
  BEGIN         
   -----While loop ends         
   while (charindex('~',@QueueName)>1)         
   BEGIN         
    set @QueueNameReport = @QueueNameReport + ''''+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+''''+','         
    set @QueueName=ltrim(rtrim(Substring(@QueueName,Charindex('~',@QueueName)+len('~'),len(@QueueName))))         
   END         
        
   set @QueueNameReport=substring(@QueueNameReport,0,len(@QueueNameReport))         
   set @WhereQuery=@WhereQuery+' AND current_work_step in('+@QueueNameReport+')'         
  END         
 END         
        
 print 'After Doc Type '+@WhereQuery        
 -- Add Process Type        
 if(rtrim(ltrim(@DocumentCategory))<>'All~')     
 BEGIN     
  --Added to Check for only 1 parameter     
  if(len(@DocumentCategory)=charindex('~',@DocumentCategory))     
  BEGIN     
   set @DocumentCategoryReport=ltrim(rtrim(substring(@DocumentCategory,0,len(@DocumentCategory))))     
   set @WhereQuery=@WhereQuery+' AND a.Document_Category='''+@DocumentCategoryReport+''''     
  END     
    
  --Added to Check for only 1 parameter       
  else     
  BEGIN     
   -----While loop ends     
   while (charindex('~',@DocumentCategory)>1)     
   BEGIN     
    set @DocumentCategoryReport = @DocumentCategoryReport + ''''+ltrim(rtrim(SUBSTRING(@DocumentCategory,1,Charindex('~',@DocumentCategory)-1)))+''''+','     
    set @DocumentCategory=ltrim(rtrim(Substring(@DocumentCategory,Charindex('~',@DocumentCategory)+len('~'),len(@DocumentCategory))))     
   END     
    
   set @DocumentCategoryReport=substring(@DocumentCategoryReport,0,len(@DocumentCategoryReport))     
   set @WhereQuery=@WhereQuery+' AND a.Document_Category in('+@DocumentCategoryReport+')'     
  END     
 END         
        
if(rtrim(ltrim(@VendorName))<>'All~')     
 BEGIN     
  --Added to Check for only 1 parameter     
  if(len(@VendorName)=charindex('~',@VendorName))     
  BEGIN     
   set @VendorNameReport=ltrim(rtrim(substring(@VendorName,0,len(@VendorName))))     
   set @WhereQuery=@WhereQuery+' AND a.Vendor_Name='''+@VendorNameReport+''''     
  END     
    
  --Added to Check for only 1 parameter       
  else     
  BEGIN     
   -----While loop ends     
   while (charindex('~',@VendorName)>1)     
   BEGIN     
    set @VendorNameReport = @VendorNameReport + ''''+ltrim(rtrim(SUBSTRING(@VendorName,1,Charindex('~',@VendorName)-1)))+''''+','     
    set @VendorName=ltrim(rtrim(Substring(@VendorName,Charindex('~',@VendorName)+len('~'),len(@VendorName))))     
   END     
    
   set @VendorNameReport=substring(@VendorNameReport,0,len(@VendorNameReport))     
   set @WhereQuery=@WhereQuery+' AND a.Vendor_Name in('+@VendorNameReport+')'     
  END     
 END    
     
 if(rtrim(ltrim(@VendorNumber))<>'All~')     
 BEGIN     
  --Added to Check for only 1 parameter     
  if(len(@VendorNumber)=charindex('~',@VendorNumber))     
  BEGIN     
   set @VendorNumberReport=ltrim(rtrim(substring(@VendorNumber,0,len(@VendorNumber))))     
   set @WhereQuery=@WhereQuery+' AND a.Vendor_Number='''+@VendorNumberReport+''''     
  END     
    
  --Added to Check for only 1 parameter       
  else     
  BEGIN     
   -----While loop ends     
   while (charindex('~',@VendorNumber)>1)     
   BEGIN     
    set @VendorNumberReport = @VendorNumberReport + ''''+ltrim(rtrim(SUBSTRING(@VendorNumber,1,Charindex('~',@VendorNumber)-1)))+''''+','     
    set @VendorNumber=ltrim(rtrim(Substring(@VendorNumber,Charindex('~',@VendorNumber)+len('~'),len(@VendorNumber))))     
   END     
    
   set @VendorNumberReport=substring(@VendorNumberReport,0,len(@VendorNumberReport))     
   set @WhereQuery=@WhereQuery+' AND a.Vendor_Number in('+@VendorNumberReport+')'     
  END     
 END    
    
 print 'After Doc Type '+@WhereQuery    
     
     
    
 print 'After Process Type '+@WhereQuery    
 if(rtrim(ltrim(@Exp))<>'All~')     
 BEGIN    
  print 'Individual Exception '+@Exp     
  --Added to Check for only 1 parameter     
  if(len(@Exp)=charindex('~',@Exp))     
  BEGIN     
   set @ExpReport=ltrim(rtrim(substring(@Exp,0,len(@Exp))))       
   set @WhereQuery=@WhereQuery+' AND B.ExceptionName='''+@ExpReport+''''     
  END      
  --Added to Check for only 1 parameter     
  else     
  BEGIN     
   print @Exp     
   while (charindex('~',@Exp)>1)     
   BEGIN     
    set @ExpReport = @ExpReport + ''''+ltrim(rtrim(SUBSTRING(@Exp,1,Charindex('~',@Exp)-1)))+''''+','     
    set @Exp=ltrim(rtrim(Substring(@Exp,Charindex('~',@Exp)+len('~'),len(@Exp))))     
   END     
   set @ExpReport=substring(@ExpReport,0,len(@ExpReport))     
    
   set @WhereQuery=@WhereQuery+' AND b.ExceptionName in('+@ExpReport+')'     
  END     
  END       
    
print 'aaaaaaa'    
print @WhereQuery    
   
 print 'After Adding Exception Name '+@WhereQuery        
        
 if(rtrim(ltrim(@DateRangeFrom))<>'' AND rtrim(ltrim(@DateRangeTo))<>'')         
 BEGIN         
  set @WhereQuery=@WhereQuery+' AND b.actiondatetime between '''+rtrim(ltrim(@DateRangeFrom))+''' AND '''+ rtrim(ltrim(@DateRangeTo))+''''         
 END         
 print 'After Adding Date Range '+@WhereQuery        
        
 SET @Query=' insert into #TA_AP_Exception_Report_Temp(Current_Work_Step,WI_Name,ExceptionName,Document_Category,Priority,Pay_Entity,Vendor_Name,Vendor_Number,ACH,AP_Check,Invoice_Number,Total_Invoice_Amount,Invoice_Date,Approver_Comments,Registration_Dat
e,Raised_ActionDatetime,Raised_By_UserId,ExceptionComments,Aging_In_Days,Aging_In_Hrs,Additional_Comments)'            
 SET @Query1=' SELECT '+@Fields+' from '+ @Tables + @WhereQuery + @OrderBy          
 seT  @Query=@Query + @Query1         
        
 print 'Final SQL '+@Query        
 exec(@Query)         
        
 delete from #TA_AP_Exception_Report_Temp where WI_Name in ( select processinstanceid from exceptiontable, #TA_AP_Exception_Report_Temp where wi_name=processinstanceid and actionid='10')        
 exec('update #TA_AP_Exception_Report_Temp set        
 Aging_In_Hrs = isnull(datediff(hh,Raised_ActionDatetime,convert(varchar,getdate(),121)),''0''),        
 Aging_In_Days = cast((isnull(datediff(hh,Raised_ActionDatetime,convert(varchar,getdate(),121)),''0''))/24.0 as numeric(10,2))')        
        
        
 SET @Query='insert into #TCISummaryException(Disp_ExceptionName,Count_Exception) '        
 SET @Querysum='select case ExceptionName when''Query Missing Information''then ''Query Missing Information Exception:''when''Missing W9''then ''Missing W9 Exception:''        
 when''Cancel Duplicate''then ''Cancel Duplicate Exception:''   
when''PO Receipt Not Done''then ''PO Receipt Not Done Exception:''  
when''Multiple Document''then ''Multiple Document Exception:''  
when''Missing Document''then ''Missing Document Exception:''   
when''Bad Image''then ''Bad Image Exception:''   
when''Vendor Setup''then ''Vendor Setup Exception:''   
when''Vendor Amendments''then ''Vendor Amendments Exception:''   
 else ''Exception'' end as Disp_exceptionname, count(*) as           
 count_exception from #TA_AP_Exception_Report_Temp group by ExceptionName'         
        
 set @Query=@Query+@Querysum         
 print 'Exception Count '+@Query        
 exec (@Query)         
        
 select @RowCount=count(*) from #TA_AP_Exception_Report_Temp with(nolock)         
        
 if(@RowCount=0)           
 Begin           
  print 'No Record Found #TA_AP_Exception_Report_Temp'        
  --drop table #TA_AP_Exception_Report_Temp           
 End           
 else           
 begin          
  print 'Report Records '+@RowCount        
  if Object_ID ('TA_TEMP_AUTOMAIL') is not null           
  BEGIN             
  exec('drop table TA_TEMP_AUTOMAIL')             
  END        
        
  Exec('Create table TA_TEMP_AUTOMAIL (Header varchar(8000),ROw_Index int IDENTITY(1,1) PRIMARY KEY)')        
        
  Exec('Insert into TA_TEMP_AUTOMAIL           
  Select ''<html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>        
  <table border=1>        
   <tr align="left"><td colspan=36 class=headerbold>VS Exception Report</td></tr>        
   <tr align="left"><td colspan=36 class=headerbold> Process : '+@ExpReport+'</td></tr>        
   <tr align="left"><td colspan=36 class=headerbold> From : '+@DateRangeFrom+'</td></tr>                           
   <tr align="left"><td colspan=36 class=headerbold> To : '+@DateRangeTo+'</td></tr>                            
   </table>  <br>           
    <table border=1><tr><td class=headerbold>Current Queue</td>''+    
  ''<td class=headerbold>WI Name</td>''+    
  ''<td class=headerbold>Exception Name</td>''+    
  ''<td class=headerbold>Document category</td>''+    
  ''<td class=headerbold>Priority</td>''+    
  ''<td class=headerbold>Pay entity</td>''+    
  ''<td class=headerbold>Vendor Name</td>''+    
  ''<td class=headerbold>Vendor Number</td>''+   
  ''<td class=headerbold>ACH</td>''+    
  ''<td class=headerbold>Check</td>''+    
  ''<td class=headerbold>Invoice Number</td>''+    
  ''<td class=headerbold>Invoice Amount</td>''+    
  ''<td class=headerbold>Invoice Date</td>''+    
  ''<td class=headerbold>Comments</td>''+    
  ''<td class=headerbold>Introduction Date</td>''+    
  ''<td class=headerbold>Exception Raised Date-Time</td>''+    
  ''<td class=headerbold>Exception Raised Comments</td>''+    
  ''<td class=headerbold>Raised By User</td>''+  
  ''<td class=headerbold>Aging In Days</td>''+    
  ''<td class=headerbold>Aging In Hours</td>''+    
  ''<td class=headerbold>Additional Comments</td>''+    
  +''</tr></font>''         
    
  UNION ALL    
  Select ''<tr><td align=left style=mso-number-format:\\@>''+ISNULL([Current_Work_Step],'''')+''</td>''+    
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([WI_Name],'''')+''</td>''+     
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([ExceptionName],'''')+''</td>''+     
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Document_Category],'''')+''</td>''+     
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Priority],'''')+''</td>''+     
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Pay_Entity],'''')+''</td>''+     
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Name],'''')+''</td>''+     
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Number],'''')+''</td>''+   
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Name],'''')+''</td>''+     
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([ACH],'''')+''</td>''+     
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([AP_Check],'''')+''</td>''+     
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Total_Invoice_Amount],'''')+''</td>''+     
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Invoice_Date],'''')+''</td>''+     
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Approver_Comments],'''')+''</td>''+     
  ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Registration_Date],''''),120)+''</td>''+     
  ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Raised_ActionDatetime],''''),120)+''</td>''+    
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Raised_By_UserId],'''')+''</td>''+     
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Aging_In_Days],'''')+''</td>''+     
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Aging_In_Hrs],'''')+''</td>''+     
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Addtional_Comments],'''')+''</td>''      
  from #TA_AP_Exception_Report_Temp')         
        
  select @status_temp='</tr></table><table><tr><td>&nbsp</td>'+'<td>&nbsp</td></tr>'         
        
  DECLARE TASummaryException_Cursor CURSOR FAST_FORWARD FOR          
  Select Disp_ExceptionName,Count_Exception from #TCISummaryException         
  OPEN TASummaryException_Cursor             
  FETCH NEXT FROM TASummaryException_Cursor INTO  @Disp_ExceptionName,@Count_Exception           
  WHILE @@FETCH_STATUS = 0         
  Begin         
   select @status_temp=@status_temp+'<tr><td>'+convert(varchar(100),@Disp_ExceptionName)+'</td><td>'+convert(varchar(100),@Count_Exception)+'</td></tr>'         
   FETCH NEXT FROM TASummaryException_Cursor INTO @Disp_ExceptionName,@Count_Exception         
  End         
         
  close TASummaryException_Cursor             
  Deallocate TASummaryException_Cursor          
  select @status_temp=@status_temp+'</table>'           
  exec('insert into TA_TEMP_AUTOMAIL select '''+@status_temp+'''   ')          
        
  update TA_TEMP_AUTOMAIL set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>&nbsp</td>')             
  select @dbname = DB_NAME()        
  print @dbname        
  SET @Query='Master..xp_Cmdshell ''bcp "select Header FROM '+@dbname+'..TA_TEMP_AUTOMAIL order by row_index asc " queryout "'+@FileName+'" -c -T'',no_output'           
  exec(@Query)          
            
  insert into NG_AutoMail_Status values('TCI Exception Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL)          
           
  --drop table #TCISummaryException         
  --drop table #TA_AP_Exception_Report_Temp          
  drop table TA_TEMP_AUTOMAIL          
         
 end             
  select @RowCount         
END 
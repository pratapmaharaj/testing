
  /*  

VS_MANUAL_INTRODUCTION_REPORT 'New~Change~','All~','01/DEC/2013','30/Mar/2014','WI_Name,WIIntroducedBy,Registration_Date,Vendor_Request_Type,Vendor_type,Priority,Vendor_Name,Vendor_Number,Payment_Terms,Vendor_Status,Address_Line_1,Address_Line_2,City_Addr
  
ess_Line_3,State_Code,Postal_code,Additional_Comments,Optional_Address_1,Optional_Address_2,Vendor_Email_ID,Combined_Single_Payment,Tax_ID_Number,SSN_Number,V_1099_Code,V_1099_Payee_Name,ACH,Bank_Account_Payment_Code,Code,Account_Number,Exception_Type,W9_
  
Indicator','aa@bb.com','//10.33.192.139/XLS-File/ProcessManager/reports/Gmac report/TAVS/','Manual_Introduction_Report',''    
  
SELECT WI_Name,WIIntroducedBy,Registration_Date,Vendor_Request_Type,Vendor_type,Priority,Vendor_Name,Vendor_Number,Payment_Terms,Vendor_Status,Address_Line_1,Address_Line_2,City_Address_Line_3,State_Code,Postal_code,Additional_Comments,Optional_Address_1,
  
Optional_Address_2,Vendor_Email_ID,Combined_Single_Payment,Tax_ID_Number,SSN_Number,V_1099_Code,V_1099_Payee_Name,ACH,Bank_Account_Payment_Code,Code,Account_Number,Exception_Type,W9_Indicator from dbo.WNS_TA_APVS_EXT_Table with(nolock) where Introduction_
  
Type='Manual'   and Vendor_Request_Type in('New','Change')     
and Vendor_Type ='All'     
AND Registration_Date between 'Dec  1 2013 12:00AM' AND 'Mar 30 2014 11:59PM'    
 and Vendor_Type <> ''     
and Vendor_Request_Type<>'' order by WI_Name    
*/
  
alter PROCEDURE WNS_TA_APVS_MANUAL_INTRODUCTION_REPORT
(
@VendorRequestType varchar(100),
@VendorType  VARCHAR(100),
@DateRangeFrom  VARCHAR(100),
@DateRangeTo  VARCHAR(100),
@Fields varchar(8000),
@EmailID varchar (100) ,
@FilePath  varchar(200),
@FileName  varchar(200),
@RowCount INT OUTPUT
)

AS  
SET NOCOUNT ON
Begin  
 declare
 @WhereQuery varchar(2000),
 @Query varchar(5000),
 @Tables varchar(200),
 @VendorTypeReport varchar(200),
 @VendorRequestTypeReport varchar(200),
 @OrderBy varchar(300)  ,
 @status_temp varchar(8000),    
 @vReqType nvarchar(200),    
 @vType nvarchar(200) ,
 @DataBaseName as nvarchar(255)

 set @WhereQuery =''
 set @Query =''  
 set @Tables =''  
 set @VendorTypeReport =''  
 set @VendorRequestTypeReport =''  
 set @OrderBy =''  
 set @RowCount =0  
 set @status_temp ='' 
 set @vReqType = ''    
 set @vType = ''     

 if Object_ID('#APVS_TEMP_TABLE_ManualIntro') is not null  
 begin  
  print 'Table dropped'  
  exec('drop table #APVS_TEMP_TABLE_ManualIntro')  
 end
select @DataBaseName=DB_name()
 CREATE TABLE #APVS_TEMP_TABLE_ManualIntro (
  WI_Name VARCHAR(100),
  WIIntroducedBy VARCHAR(100),  
  Registration_Date VARCHAR(100),
  Vendor_Request_Type VARCHAR(100),   
  Vendor_type VARCHAR(100),
  Priority VARCHAR(100),
  Vendor_Name VARCHAR(100),
  Vendor_Number VARCHAR(100),
  Payment_Terms VARCHAR(100),
  Vendor_Status VARCHAR(100),
  Address_Line_1 VARCHAR(100),
  Address_Line_2 VARCHAR(100),
  City_Address_Line_3 VARCHAR(100),
  State_Code VARCHAR(100), 
  Postal_code VARCHAR(100),  
  Additional_Comments varchar(512),  
  Optional_Address_1 VARCHAR(100),
  Optional_Address_2 VARCHAR(100),
  Vendor_Email_ID VARCHAR(100),
  Combined_single_Payment VARCHAR(100),
  Tax_ID_Number VARCHAR(100),
  SSN_Number VARCHAR(100),
  V_1099_Code VARCHAR(100),
  V_1099_Payee_Name VARCHAR(100),
  ACH VARCHAR(100),
  Bank_Account_Payment_Code VARCHAR(100),
  Code varchar(100),
  Account_Number VARCHAR(100),
  Exception_Type VARCHAR(100),
  W9_Indicator VARCHAR(100) 
 ) 
 
 BEGIN
  set @FileName=@FilePath+'/'+@EmailID+'_'+@FileName+'_'+convert(varchar,getdate(),104)+'.xls'  
  set @OrderBy=' order by WI_Name'  
  set @WhereQuery=' where Introduction_Type=''Manual''  '   
  set @Tables='dbo.WNS_TA_APVS_EXT_Table with(nolock)'


  if(rtrim(ltrim(@DateRangeFrom))<>'')  
  BEGIN  
  SET @DateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@DateRangeFrom,121))))) 
  END  
  if(rtrim(ltrim(@DateRangeTo))<>'')
  BEGIN  
  SET @DateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@DateRangeTo,121)))))
  END  
 
 --vendor request type
 if(rtrim(ltrim(@VendorRequestType))<>'All~')
 BEGIN
 if(len(@VendorRequestType)=charindex('~',@VendorRequestType))
 BEGIN  
     set @vReqType=ltrim(rtrim(substring(@VendorRequestType,0,len(@VendorRequestType))))    
  set @VendorRequestTypeReport=ltrim(rtrim(substring(@VendorRequestType,0,len(@VendorRequestType))))
  print @VendorRequestTypeReport    
  if (rtrim(ltrim(@VendorRequestTypeReport))<>'')  
  begin  
   set @WhereQuery=@WhereQuery+' and Vendor_Request_Type ='''+@VendorRequestTypeReport+''''
  end  
 End
 else
 BEGIN   
  while (charindex('~',@VendorRequestType)>1)
  BEGIN    
   set @vReqType=@vReqType+ltrim(rtrim(SUBSTRING(@VendorRequestType,1,Charindex('~',@VendorRequestType)-1)))+','     
   set @VendorRequestTypeReport = @VendorRequestTypeReport + ''''+ltrim(rtrim(SUBSTRING(@VendorRequestType,1,Charindex('~',@VendorRequestType)-1)))+''''+','
   set @VendorRequestType=ltrim(rtrim(Substring(@VendorRequestType,Charindex('~',@VendorRequestType)+len('~'),len(@VendorRequestType))))
  END 
  set @VendorRequestTypeReport=SUBSTRING(@VendorRequestTypeReport,0,len(@VendorRequestTypeReport)) 
  set @WhereQuery=@WhereQuery+' and Vendor_Request_Type in('+@VendorRequestTypeReport+')' 
 END
 END  
 --vendor request type
 if(rtrim(ltrim(@VendorType))<>'All~' )
 BEGIN
 if(len(@VendorType)=charindex('~',@VendorType))
 BEGIN
  print '1111'    
  set @vType =ltrim(rtrim(substring(@VendorType,0,len(@VendorType)))) 
  set @VendorTypeReport=ltrim(rtrim(substring(@VendorType,0,len(@VendorType))))
  print @VendorTypeReport    
  if (rtrim(ltrim(@VendorTypeReport))<>'')  
  begin
   set @WhereQuery=@WhereQuery+' and Vendor_Type ='''+@VendorTypeReport+''''
  end
 End
 else
 BEGIN
  print '2222'
  while (charindex('~',@VendorType)>1)
  BEGIN    
   set @vType=@vType+ltrim(rtrim(SUBSTRING(@VendorType,1,Charindex('~',@VendorType)-1)))+','    
   set @VendorTypeReport = @VendorTypeReport + ''''+ltrim(rtrim(SUBSTRING(@VendorType,1,Charindex('~',@VendorType)-1)))+''''+','
   set @VendorType=ltrim(rtrim(Substring(@VendorType,Charindex('~',@VendorType)+len('~'),len(@VendorType))))
   print @VendorTypeReport 
  END 
  set @VendorTypeReport=SUBSTRING(@VendorTypeReport,0,len(@VendorTypeReport))   
  print @VendorTypeReport    
  print @VendorType
  print '11111111'
  print @VendorTypeReport    
  set @WhereQuery=@WhereQuery+' and Vendor_Type in('+@VendorTypeReport+')'   
 END
 END

 print @WhereQuery
 if(rtrim(ltrim(@DateRangeFrom))<>'' AND rtrim(ltrim(@DateRangeTo))<>'')
 BEGIN
 set @WhereQuery=@WhereQuery+' AND Registration_Date between '''+rtrim(ltrim(@DateRangeFrom))+''' AND '''+ rtrim(ltrim(@DateRangeTo))+''''
 END 

set @WhereQuery = @WhereQuery+' and Vendor_Type <> '''' and Vendor_Request_Type<>'''''

 SET @Query='SELECT '+@Fields+' from '+ @Tables + @WhereQuery + @OrderBy
 --print @Query  
 --exec(@Query)
 
 set @Query='insert into #APVS_TEMP_TABLE_ManualIntro '+ @Query
 print  @Query
 --set @Query=@Query+'select Wi_Name,WIIntroducedBy,Registration_Date,Vendor_Request_Type,Vendor_type,Priority,Vendor_Name,Vendor_Number,Payment_Terms,Vendor_Status,Address_Line_1,Address_Line_2,City_Address_Line_3,State_Code,Postal_code,Additional_Comme 
  
 --nts,Optional_Address_1,Optional_Address_2,Vendor_Email_ID,Combined_Single_Payment,Tax_ID_Number,SSN_Number,V_1099_Code,V_1099_Payee_Name, ACH, Bank_Account_Payment_Code,Code,Account_Number,Exception_Type,W9_Indicator from WNS_TA_APVS_EXT_Table with (no
  
--loc   --k) '+@OrderBy 
 print '----'  
 print @Query  
 exec(@Query)
 
 
 select @RowCount=count(*) from #APVS_TEMP_TABLE_ManualIntro
 PRINT  @RowCount 
 if(@RowCount=0)
 Begin
  drop table #APVS_TEMP_TABLE_ManualIntro
 End
 else   
 Begin    
  if Object_ID ('NG_TEMP_AUTOMAIL') is not null   
  BEGIN   
   exec('drop table NG_TEMP_AUTOMAIL')   
  END
  PRINT '000000'  
  Exec('Create table NG_TEMP_AUTOMAIL (Header varchar(8000),ROw_Index [int] identity(1,1) not null)')   
  exec('Insert into NG_TEMP_AUTOMAIL   
Select
''<html>    
<style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>  
   <table border=1>    
 <tr align="left"><td colspan=30 class=headerbold align="left">    
 <center>    
 Vendor Setup Manual Introduction Report </center></td></tr>    
  
   <tr align="left"><td colspan=30 class=headerbold> Introduction Date From : '+@DateRangeFrom+'</td></tr>  
   <tr align="left"><td colspan=30 class=headerbold> Introduction Date To : '+@DateRangeTo+'</td></tr>  
   <tr align="left"><td colspan=30 class=headerbold> Vendor Request Type : '+@vReqType+'</td></tr>    
   <tr align="left"><td colspan=30 class=headerbold> Vendor Type : '+@vType+'</td></tr>  
</table>  <br>
<table border=1>    
<tr>    
  <td class=headerbold>Workitem Name</td>''+  
  ''<td class=headerbold>Introduced By</td>''+
  ''<td class=headerbold>Introduced Date</td>''+ 
  ''<td class=headerbold>Vendor Request Type</td>''+
  ''<td class=headerbold>Vendor Type</td>''+  
  ''<td class=headerbold>Priority</td>''+  
  ''<td class=headerbold>Vendor Name</td>''+ 
  ''<td class=headerbold>Vendor Number</td>''+ 
  ''<td class=headerbold>Payment Terms</td>''+ 
  ''<td class=headerbold>Status</td>''+ 
  ''<td class=headerbold>Address Line 1</td>''+ 
  ''<td class=headerbold>Address Line 2</td>''+ 
  ''<td class=headerbold>City Address Line 3</td>''+
  ''<td class=headerbold>State Code</td>''+ 
  ''<td class=headerbold>Postal Code</td>''+  
  ''<td class=headerbold>Comments</td>''+ 
  ''<td class=headerbold>Optional Address 1</td>''+ 
  ''<td class=headerbold>Optional Address 2</td>''+
  ''<td class=headerbold>Vendor Email ID</td>''+ 
  ''<td class=headerbold>Combined or Single</td>''+ 
  ''<td class=headerbold>Tax ID</td>''+ 
  ''<td class=headerbold>SSN Number</td>''+ 
  ''<td class=headerbold>1099 Code</td>''+ 
  ''<td class=headerbold>1099 Payee Name</td>''+  
  ''<td class=headerbold>ACH</td>''+ 
  ''<td class=headerbold>BAP Code</td>''+ 
  ''<td class=headerbold>ABA Number</td>''+
  ''<td class=headerbold>Account Number</td>''+ 
  ''<td class=headerbold>Exception Type</td>''+ 
  ''<td class=headerbold>W9 Indicator</td>''+ 
  +''</tr></font>''   
  
  UNION ALL   
  
  Select ''<tr> <td align=left style=mso-number-format:\\@>''+ISNULL([Wi_Name],'''')+''</td>''+ 
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([WIIntroducedBy],'''')+''</td>''+
  ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Registration_Date],''''),120)+''</td>''+ ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Request_Type],'''')+''</td>''+ 
  
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_type],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Priority],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Name],'''')+''</td>''+ 
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Vendor_Number],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Payment_Terms],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Vendor_Status],'''')+''</td>''+ 
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Address_Line_1],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Address_Line_2],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([City_Address_Line_3],'''')+''</td>''+ 
  ''<td align=left style=mso-number-format:\@>''+ISNULL([State_Code],'''')+''</td>''+ 
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Postal_code],'''')+''</td>''+   
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Additional_Comments],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Optional_Address_1],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Optional_Address_2],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Vendor_Email_ID],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Combined_single_Payment],'''')+''</td>''+ 
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Tax_ID_Number],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([SSN_Number],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([V_1099_Code],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([V_1099_Payee_Name],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([ACH],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Bank_Account_Payment_Code],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Code],'''')+''</td>''+  
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Account_Number],'''')+''</td>''+  
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Exception_Type],'''')+''</td>''+  
  ''<td align=left style=mso-number-format:\@>''+ISNULL([W9_Indicator],'''')+''</td>''+''</tr>''
  from #APVS_TEMP_TABLE_ManualIntro') 

  select @status_temp='<tr></tr></tr></table><html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style><table border=1><tr>'+'<td class=headerbold><b>Introduction Date From </b></td><td class=headerbold><b>Introduction Date To</b></td><td class=headerbold><b>Introduced WI Count</b></td></tr></style><tr><td>'+convert(varchar(100),@DateRangeFrom)+'</td><td>'+convert(varchar(100),@DateRangeTo)+'</td><td>'+convert(varchar(100),@RowCount)+'</td></tr>'
  select @status_temp=@status_temp+'</table>'
  exec('insert into NG_TEMP_AUTOMAIL select '''+@status_temp+'''   ')   

  update NG_TEMP_AUTOMAIL set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yy>&nbsp</td>')

  SET @Query='Master..xp_Cmdshell ''bcp "select Header FROM '+@DataBaseName+'..NG_TEMP_AUTOMAIL order by row_index asc" queryout "'+@FileName+'" -c -T'',no_output' 

  exec(@Query)

  insert into NG_AutoMail_Status values('TA VS Manual Introduction Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL)
  --select @RowCount   
  --drop table #APVS_TEMP_TABLE_ManualIntro  
  drop table NG_TEMP_AUTOMAIL 
  End 
END  
 select @RowCount 
 End 
 

<%@ include file="customized.process" %>

<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>

<%@ page import="java.sql.*"%>

<HTML>
<HEAD>
<TITLE>Vendor Setup Approval Status Report</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>
</HEAD>

<link href="/webdesktop/CustomForms/reports/GMAC/css/docstyle.css" rel="stylesheet" >
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>
<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
}
</style>
<%
	WriteLog("VS_Approval_status"," ::> Start : ");
	String sRootDBPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("VS_Approval_status"," ::> sRootDBPathini : "+sRootDBPathini);

	Properties ini = new Properties();
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootDBPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("VS_Approval_status","Unable to read VS_Approval_status.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("VS_Approval_status","Unable to close the VS_Approval_status.ini file");
						}
					}
				}


	Connection conn = null;
	String connectionUrl =ini.getProperty("CONNECTIONSTRING");
	String driverName = null;
	driverName=ini.getProperty("DRIVERNAME");

	WriteLog("VS_Approval_status","driverName="+driverName+",conString="+connectionUrl);
	String sApproverName="";
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAVSApprovalStatusReport.ini";
			ini = new Properties();
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("VS_Approval_status","Unable to read VS_Approval_status.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("VS_Approval_status","Unable to close the VS_Approval_status.ini file");
						}
					}
				}
			
	
			String sGroupname     =ini.getProperty("APPROVALSTATUSREPORT_GROUPNAME");
			String sTempGroupName ="'"+sGroupname.replaceAll(",","','")+"'";

	String query="select distinct b.username from pdbgroupmember a,pdbuser b where a.groupindex in(select groupindex from pdbgroup where a.userindex=b.userindex and a.userindex<>'1' and groupname in ("+sTempGroupName+")) order by b.username desc";
	Statement stmt = null ;
	WriteLog("VS_Approval_status"," query - "+query);
	ResultSet rs=null;
	try
	{
		Class.forName(driverName);
		conn = DriverManager.getConnection(connectionUrl);
		stmt = conn.createStatement();
		rs = stmt.executeQuery(query);

		while (rs.next()) 
		{
			sApproverName = rs.getString("username")+"~"+sApproverName;
		}
	}
	catch(SQLException e)
	{
		out.println("Exception:" + e.toString());
	}
	finally {
 
	if (rs != null) {
        try {
            rs.close();
        } catch (SQLException e) { }
    }
	if (stmt != null) {
        try {
            stmt.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
}
%>
<script>
	var allWindows = new Array();
	var win; // new window object
	$(document).ready(function(){$('#From_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", disabled: true,
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", disabled: true,
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	
	});
	/*functions echeck,ValidateForm added by nilesh*/
	function echeck(str) 
	{

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;
	}
//---Added by Chetan
function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";

	sDate	= window.showModalDialog('/processmanager/reports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');

	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
}

function UnloadReportWindow()
{
	if(win!=null)
		win.close();
}

function openreport()
{	
	var VendorType='';
	var bVendor=false;
	var VendorRequestType='';
	var approvName = '' ;
	var bVendorReqType=false;
	var Aging=document.getElementById('Aging').value;
	var UserEmailID=document.getElementById('EMail-ID').value;//added by nilesh
	var DateRangeFrom="";
	var DateRangeTo="";

	DateRangeFrom=document.forms["textForm"].From_Date.value;
	DateRangeTo=document.forms["textForm"].To_Date.value;

	for(var i=0;i<document.forms["textForm"].Vendor_Type.length;i++)
	{
		if(document.forms["textForm"].Vendor_Type[i].selected)
		{
			VendorType=VendorType+document.forms["textForm"].Vendor_Type[i].value+'~';
			bVendor=true;
		}
	}


	for(var i=0;i<document.forms["textForm"].Vendor_Request_Type.length;i++)
	{
		if(document.forms["textForm"].Vendor_Request_Type[i].selected)
		{
			VendorRequestType=VendorRequestType+document.forms["textForm"].Vendor_Request_Type[i].value+'~';
			bVendorReqType=true;
		}
	}

	var sApproverName = "" ;
	for(var i=0;i<document.forms["textForm"].Approver_Name.length;i++)
	{
		if(document.forms["textForm"].Approver_Name[i].selected)
		{
			sApproverName=sApproverName+document.forms["textForm"].Approver_Name[i].value+'~';
		}
	}

	var sTestVendorType=VendorType.split('~');
	var sTestVendorReqtype=VendorRequestType.split('~');
	var aApprover_Name = sApproverName.split('~') ;

	if(VendorType.indexOf("All")!=-1 && sTestVendorType.length>2)
	{
		alert("No other Vendor Type can be chosen after choosing All");
		return false;
		//VendorType='All~';
	} 
//alert(sApproverName+"  "+aApprover_Name.length) ;
	if(sApproverName.indexOf("All")!=-1 && aApprover_Name.length>2)
	{
		alert("No other Approver can be chosen after choosing All");
		return false;
		//VendorType='All~';
	} 

	if(VendorRequestType.indexOf("All")!=-1 && sTestVendorReqtype.length>2)
	{
		alert("No other Vendor Request Type can be chosen after choosing All");
		return false;
		//VendorRequestType='All~';
	} 

	if(VendorType=='')
	{
		VendorType = "All~" ;
	}
	if(VendorType=='Policyholder vendors~Escheatment vendors~Tax vendors~PO vendors~Licensing and filing fee vendors~Non PO Vendors~')
	{
		VendorType='Policyholder vendors~Escheatment vendors~Tax vendors~PO vendors~Licensing and filing fee vendors~Non PO Vendors~';
	}

	if(VendorRequestType=='')
	{
		VendorRequestType = "All~" ;
	}
	if(VendorRequestType=='New~Change~')
	{
		VendorRequestType='All~'
	}

	if(sApproverName=='')
	{
		sApproverName = "All~" ;
	}
	//added by nilesh for validation of emails

	if(document.getElementById('Aging_R').checked == true) 
	{
		if(isNaN(Aging))
		{
			alert("Please Enter Valid value for Aging in days.") ;
			return false ;
		}
		else if (Aging == '')
		{
			alert("Please Enter Valid value for Aging in days.") ;
			return false ;
		}

		if(Aging>90)
		{
			alert("Please Enter Aging value less than or equal to 90.") ;
			return false ;
		}
	}
	else if(document.getElementById('Intro').checked == true) 
	{
		if(DateRangeFrom=="")
		{
			alert("Please select an appropriate From Date.");
			return false;
		}

		if(DateRangeTo=="")
		{
			alert("Please select an appropriate To Date.");
			return false;
		}

		if ((DateRangeFrom=='' && DateRangeTo!='') || (DateRangeFrom!='' && DateRangeTo==''))
		{
			alert("Enter the complete Date Range.");
			return false;
		}

		if(!DateComparator(DateRangeTo,DateRangeFrom))
		{
			return false;
		}
	}
	else
	{
		alert("Please Select Either Aging In days or Approval Queue Date range") ;
		return false ;
	}
	if(UserEmailID=='')
	{
		alert("Please enter a valid E-Mail ID");
		return false;
	}
	else
	{
		if(!ValidateForm(document.getElementById('EMail-ID')))
		{
			UserEmailID='';
			return false ;
		}
	}

	//alert("VSApprovalStatusGenerate.jsp?&VendorRequestType="+VendorRequestType+"&VendorType="+VendorType+"&ApproverName="+sApproverName+"&Aging="+Aging+"&ReportName=<%=request.getParameter("ReportName")%>&FromDate="+DateRangeFrom+"&ToDate="+DateRangeTo+"&UserEmailID="+UserEmailID) ;
	if((UserEmailID!='')&&( (DateRangeTo!="" && DateRangeFrom!="") || Aging!=""))
	{	
		
		//OpenRedict-Fix
    //window.top.APPROVALSTATUSREPORT.location.href="VSApprovalStatusGenerate.jsp?&VendorRequestType="+VendorRequestType+"&VendorType="+VendorType+"&ApproverName="+sApproverName+"&Aging="+Aging+"&ReportName=<%=request.getParameter("ReportName")%>&FromDate="+DateRangeFrom+"&ToDate="+DateRangeTo+"&UserEmailID="+UserEmailID;
	var URI = "VSApprovalStatusGenerate.jsp?&VendorRequestType="+VendorRequestType+"&VendorType="+VendorType+"&ApproverName="+sApproverName+"&Aging="+Aging+"&ReportName=<%=request.getParameter("ReportName")%>&FromDate="+DateRangeFrom+"&ToDate="+DateRangeTo+"&UserEmailID="+UserEmailID;
	var StrOpenWin=strip_tags(URI,"");
	window.top.APPROVALSTATUSREPORT.location.href=StrOpenWin;
		
	}

}

function FillApproverName()
{
	var ApproverNames= '<%=sApproverName%>';

	//users=users.substring(0,users.length()-1);

	//var GroupNameArray=sGroupname.split('~');
	//var UserIdArray=sUserID.split('~');
	var ApproverNameArray=ApproverNames.split('~');

	/*for (var j=0;j<GroupNameArray.length;j++)
	{
		optn=document.createElement("option");	
		req=document.getElementById("Group");
		optn.text=GroupNameArray[j];
		optn.value=GroupNameArray[j];	
		req.options.add(optn);	
	}*/
	for (var j=0;j<ApproverNameArray.length-1;j++)
	{
		optn=document.createElement("option");	
		req=document.getElementById("Approver_Name");
		optn.text=ApproverNameArray[j];
		optn.value=ApproverNameArray[j];	
		//optn.value=UserIdArray[j];	
		req.options.add(optn);	
	}

}

function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	strResult=strdate+"/"+strMonth+"/"+stryear;
	return strResult;
}

function convertMonth(strMonth)
{
		if(strMonth=="JAN")
			strMonth="00";
		else if(strMonth=="FEB")
			strMonth="01";
		else if(strMonth=="MAR")
			strMonth="02";
		else if(strMonth=="APR")
			strMonth="03";
		else if(strMonth=="MAY")
			strMonth="04";
		else if(strMonth=="JUN")
			strMonth="05";
		else if(strMonth=="JUL")
			strMonth="06";
		else if(strMonth=="AUG")
			strMonth="07";
		else if(strMonth=="SEP")
			strMonth="08";
		else if(strMonth=="OCT")
			strMonth="09";
		else if(strMonth=="NOV")
			strMonth="10";
		else if(strMonth=="DEC")
			strMonth="11";
	return strMonth;
}

function DateComparator(Date_To,Date_From)
	{
		if (Date_From == "" && Date_To == "")
		{
			return false;
		}

		var FromDay = Date_From.split("/")[0];
		var FromMonth = convertMonth(Date_From.split("/")[1]);
		var FromYear = Date_From.split("/")[2];
		
		//alert("From:::Day::"+FromDay+"  Month::"+FromMonth+"	Year::"+FromYear);
		
		var ToDay = Date_To.split("/")[0];
		var ToMonth = convertMonth(Date_To.split("/")[1]);
		var ToYear = Date_To.split("/")[2];

		var CurrentDate=new Date();
		var CurrentDay = CurrentDate.getDate();
		var CurrentMonth = CurrentDate.getMonth();
		//var CurrentYear = CurrentDate.getFullYear();
		var CurrentYear = CurrentDate.getFullYear();
		//alert("Current:::Day::"+CurrentDay+"  Month::"+CurrentMonth+"	Year::"+CurrentYear);

		var toDate = (new Date(ToYear,ToMonth,ToDay)).getTime();
		var fromDate = (new Date(FromYear,FromMonth,FromDay)).getTime();
		var CurrentDate = (new Date(CurrentYear,CurrentMonth,CurrentDay)).getTime();
		
		//alert("FromDate::"+fromDate+"  ToDate::"+toDate+"	Current::"+CurrentDate);

		//alert("Fr : "+new Date(fromDate)+"\nTo : "+new Date(toDate)+"\nCu : "+new Date(CurrentDate));
		if(fromDate > toDate)
		{
			alert("To Date cannot be less than From Date.");
			return false;
		}
		else if(fromDate > CurrentDate)
		{
			alert("From Date cannot be future date.");
			return false;
		}
		else if(toDate > CurrentDate)
		{
			alert("To Date cannot be future date.");
			return false;
		}

		toDate = new Date(ToMonth+"/"+ToDay+"/"+ToYear);
		fromDate = new Date(FromMonth+"/"+FromDay+"/"+FromYear);
		var oneDay=1000*60*60*24;

		var dateDiff=Math.ceil((toDate.getTime()-fromDate.getTime())/oneDay);
		if(dateDiff>90)
		{
			alert('Date Range can not be greater than 90 days.');
			return false;
		}

	 return true;
	
	}
//--------------------------------------------

function ValidateForm(emailID){
//	var emailID=document.frmSample.txtEmail
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }
function chkradio(obj)
{
	if(obj == 'a')
	{
		if(document.getElementById('Intro').checked == true) 
		{
			document.getElementById('Intro').checked = false;
		}
		document.getElementById('From_Date').value='';
		document.getElementById('To_Date').value='';
		document.getElementById('From_Date').style.backgroundColor='grey';
		document.getElementById('To_Date').style.backgroundColor='grey';
		//document.getElementById('To_Date_IMG').disabled=true;
		//document.getElementById('From_Date_IMG').disabled=true; 
		document.getElementById('Aging').value = '' ;
		document.getElementById('Aging').style.backgroundColor='white';
		document.getElementById('Aging').disabled=false; 
		$('#To_Date').datepicker("disable");
		$('#From_Date').datepicker("disable");
	}
	else if(obj == 'i')
	{
		if(document.getElementById('Aging_R').checked == true) 
		{
			document.getElementById('Aging_R').checked = false;
		}
		document.getElementById('From_Date').value='';
		document.getElementById('To_Date').value='';
		document.getElementById('From_Date').style.backgroundColor='white';
		document.getElementById('To_Date').style.backgroundColor='white';
		//document.getElementById('To_Date_IMG').disabled=false;
		//document.getElementById('From_Date_IMG').disabled=false;
		document.getElementById('Aging').style.backgroundColor='grey';
		document.getElementById('Aging').disabled=true; 
		document.getElementById('Aging').value = '' ;
		$('#To_Date').datepicker("enable");
		$('#From_Date').datepicker("enable");
	}

}
 function disbFields()
 {
		document.getElementById('From_Date').value='';
		document.getElementById('To_Date').value='';
		document.getElementById('From_Date').style.backgroundColor='grey';
		document.getElementById('To_Date').style.backgroundColor='grey';
		//document.getElementById('To_Date_IMG').disabled=true;
		//document.getElementById('From_Date_IMG').disabled=true;
		document.getElementById('Aging').style.backgroundColor='grey';
		document.getElementById('Aging').disabled=true; 
		document.getElementById('Aging').value = '' ;
 }
</script>
</title>
<body topmargin="0" leftmargin="5" onload="FillApproverName();disbFields();" onunload="UnloadReportWindow();">

			<form name='textForm' method=post>
			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">Vendor Setup Approval Status Report</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This report will provide information on workitems for which approval is pending by Transamerica approvers. 
</td></tr><tr><td class="EWLabel1"> 
Select All as the Vendor Type if the report has to be generated for the entire spectrum of the avalilable Vendor Type, else select the specific Vendor Type, multiple selections are acceptable.<br>
Select All as the Vendor Request Type if the report has to be generated for the entire spectrum of the avalilable Vendor Request Type, else select the specific Vendor Request Type, multiple selections are acceptable.<br>
Select Approver Name if you want to generate report for workitems assigned to specific Approvers.<br>
Select Aging. Select Introdcution in Approver Portal date range.<br>
<b>Either Aging or Approval Portal Introduction Date Range is mandatory.</b> 
</td></tr>
</table>
<table border="0" width="95%" cellspacing="1" align="center">
<td colspan = 2 class="EWLabel1"><font color="RED">*</font> <b>Fields are Mandatory<b><BR></td>
				<tr>
					<td class="EWLabel1" align="left" width='25%'><b>Vendor Request Type</b></td>
					<td width='45%' colspan=3>
					<select style='width:65%' name="Vendor_Request_Type" multiple>
					<option value="All">All</option>
					<option value="New">New</option>
					<option value="Change">Change</option>
					</select>
					</td>
				</tr>
				<tr>
					<td class="EWLabel1" align="left" width='25%'><b>Vendor Type</b></td>
					<td width='45%' colspan=3>
					<select style='width:65%' name="Vendor_Type" multiple>
					<option value="All">All</option>
					<option value="Policyholder vendors">Policyholder vendors</option>
					<option value="Escheatment vendors">Escheatment vendors</option>
					<option value="Tax vendors">Tax vendors</option>
					<option value="PO vendors">PO vendors</option>
					<option value="Licensing and filing fee vendors">Licensing & filing fee vendors</option>
					<option value="Non PO Vendors">Non PO Vendors</option>
					</select>
					</td>
				</tr>

				<tr>
					<td class="EWLabel1" align="left" width='25%'><b>Approver Name 
					<td width='45%' COLSPAN=3>
					<!--changed by megha-->
					<select STYLE='width:65%' class='TextFieldColor' id="Approver_Name" name="Approver_Name" multiple onchange="">
						<option value="All">All</option>
					</select>

					</td>

				</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><input type = "radio" name ="Aging_R" id ="Aging_R" value = "Aging_R" onClick="chkradio('a')"><b>Aging (in Days)<font color="RED"> *</font></b></td>
					<td >
					<input type='text' name='Aging' style='width:145' id='Aging'>
					</td>
				</tr>
				
				
                <!-- Added by Chetan for displaying Date range from and to field...-->
				<tr >
					<td class="EWLabel1" align="left" width='30%'>
					<input type = "radio" name ="Intro" id ="Intro" value = "Intro" onClick="chkradio('i')">
					<b>Introduction in Approval Queue <font color="RED">*</font></b></td>
				</tr>
				<tr>
					<td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date range &nbsp;&nbsp;&nbsp;From:</b></td>
					<td><input class='TextFieldColorDate' name="From_Date"  type="text" readonly id="From_Date" >
					
					</td>
					<td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td><input class='TextFieldColorDate' name="To_Date"  type="text" readonly id="To_Date" >
					
					</td>

				</tr>
				<!-- --------------------------------------------------- -->
				<!--added by nilesh for displaying Emaild field -->

				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID <font color="RED">*</font></b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>
				 
				 
				

				
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>
	
			
			</form>
</body>
</Html>	 






<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="java.lang.String.*"%>
<%@ page import="java.lang.Object"%>
<%@ page import="java.lang.Exception"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<HTML>
<link href="/webdesktop/CustomForms/reports/GMAC/css/docstyle.css" rel="stylesheet" >
<HEAD>
<TITLE>Vendor Setup Approval Status Report</TITLE>
</HEAD>

<FRAMESET ROWS="100%,0%" >
	<FRAME SRC="VSApprovalStatus.jsp?ReportName=APPROVALSTATUSREPORT" NAME="frmHeader" wodth="100%" frameborder=no noresize scrolling=Yes>
	<FRAME SRC="" NAME="APPROVALSTATUSREPORT" frameborder=no scrolling=no>
</FRAMESET>
</html>


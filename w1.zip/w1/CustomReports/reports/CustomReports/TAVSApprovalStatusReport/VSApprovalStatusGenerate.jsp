
<%@ include file="customized.process" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="java.sql.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>


<HTML>
<HEAD>
<TITLE>Vendor Setup Approver Status Report</TITLE>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" >

<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>


<body>
<%


	WriteLog("VS_Approval_status"," ::> sInputXML : ");
	
	Connection conn = null;
	Statement st;
	String connectionUrl =""; 
	boolean empty=true;

	String sProcedureName=null;
	String sColumnHeaders=null;
	String sReportName=null;
	String sFileName=null;
	String sNumberOfColumns=null;
	String sProcedureNameKey=null;
	String sColumnHeadersKey=null;
	String sFileNameKey=null;
	String sNumberOfColumnsKey=null;
	String sHeaderKey=null;
	String sHeaderPresentKey=null;
	String sDBMappedColsKey=null;
	String sHeaderValue=null;
	String sHeaderPresentValue=null;
	String sCabinetName=null;	
	String sDBMappedCols=null;
	String sFieldValuesKey=null;
	String sFieldValues=null;
	String sUserMailID=null;//added by nilesh
	String fileName = "" ;
	String filePath="" ;

	sUserMailID=request.getParameter("UserEmailID");//added by nilesh


	sReportName	=request.getParameter("ReportName");
	sReportName	=sReportName.toUpperCase();
	
	WriteLog("VS_Approval_status"," ::> sReportName : "+sReportName);
	sProcedureNameKey=sReportName +"_PROCEDURENAME";
	sColumnHeadersKey=sReportName+"_COLUMNHEADERS";
	sFileNameKey=sReportName+"_FILENAME";
	sNumberOfColumnsKey=sReportName+"_NUMBEROFCOLUMNS";
	sHeaderPresentKey=sReportName+"_HEADERPRESENT";
	sHeaderKey=sReportName+"_HEADER";
	sDBMappedColsKey=sReportName+"_DBMAPPEDCOLS";
	sFieldValuesKey=sReportName+"_FIELDVALUES";
	WriteLog("VS_Approval_status"," ::> sColumnHeadersKey : "+sColumnHeadersKey);

	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAVSApprovalStatusReport.ini";

	Properties ini = new Properties();
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("VS_Approval_status","Unable to read VS_Approval_status.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("VS_Approval_status","Unable to close the VS_Approval_status.ini file");
						}
					}
				}
				
	WriteLog("VS_Approval_status"," ::> sRootPathini : "+sRootPathini);

	WriteLog("VS_Approval_status"," ::> filePath : "+sReportName+"_FILEPATH");
	filePath = ini.getProperty(sReportName+"_FILEPATH");

	fileName=ini.getProperty(sReportName+"_FILENAME") ;


	sProcedureName=ini.getProperty(sProcedureNameKey);
	sColumnHeaders=ini.getProperty(sColumnHeadersKey);
	sFileName=ini.getProperty(sFileNameKey);
	sNumberOfColumns=ini.getProperty(sNumberOfColumnsKey);
	sHeaderPresentValue=ini.getProperty(sHeaderPresentKey);
	sDBMappedCols=ini.getProperty(sDBMappedColsKey);
	sFieldValues=ini.getProperty(sFieldValuesKey);
	sFieldValues=sFieldValues.replaceAll("#",",");

	WriteLog("VS_Approval_status"," ::> sProcedureName : "+sProcedureName);

	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("VS_Approval_status","sRootPathDBini="+sRootPathDBini);
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("VS_Approval_status","Unable to read VS_Approval_status.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("VS_Approval_status","Unable to close the VS_Approval_status.ini file");
						}
					}
				}
				
	String conString = null;
	String driverName = null;
	driverName=ini.getProperty("DRIVERNAME");
	conString=ini.getProperty("CONNECTIONSTRING");
	WriteLog("VS_Approval_status","driverName="+driverName+",conString="+conString);

	CallableStatement callableStatement = null;

	WriteLog("VS_Approval_status"," connectionUrl "+connectionUrl);
	
	if(sHeaderPresentValue.equals("YES")) 
	{
		sHeaderValue=ini.getProperty(sHeaderKey);
	}

	WriteLog("VS_Approval_status"," ::> sColumnHeaders : "+sColumnHeaders);
	String sVendorRequestType=request.getParameter("VendorRequestType");
	String sVendorType=request.getParameter("VendorType");
	String sApproverName=request.getParameter("ApproverName");
	String sFromDate=request.getParameter("FromDate");
	String sToDate=request.getParameter("ToDate");
	String sAging=request.getParameter("Aging");

	double fPercentage=0;
	String sColumnNamesArr[]=sColumnHeaders.split(",");
	String sDBMappedColsArr[]=sDBMappedCols.split(",");
	String sRowXml="";
	String sFinalColumns[]=sColumnHeaders.split(",");
	for(int i=0;i<sColumnNamesArr.length;i++)
	{
		if(sColumnNamesArr[i].indexOf("~D")!=-1)
			sFinalColumns[i]=sColumnNamesArr[i].substring(0,sColumnNamesArr[i].length()-2);

	}

	boolean bError=false;

	WriteLog("VS_Approval_status"," ::> sVendorRequestType : "+sVendorRequestType);
	WriteLog("VS_Approval_status"," ::> sVendorType : "+sVendorType);
	WriteLog("VS_Approval_status"," ::> sApproverName : "+sApproverName);
	WriteLog("VS_Approval_status"," ::> sFieldValues : "+sFieldValues);

	String getDBUSERByUserIdSql = "{call "+sProcedureName+"(?,?,?,?,?,?,?,?,?,?,?)}";
	String output = "" ;
	try
	{
			WriteLog("VS_Approval_status"," "+sProcedureName +" '"+sVendorRequestType+"','"+sVendorType+"','"+sApproverName+"','"+sAging+"','"+sFromDate+"','"+sToDate+"','"+sFieldValues+"','"+sUserMailID+"','"+filePath+"','"+fileName+"',''");
			Class.forName(driverName) ;
			conn = DriverManager.getConnection(conString);
			callableStatement = conn.prepareCall(getDBUSERByUserIdSql);
			callableStatement.setString(1, sVendorRequestType);
			callableStatement.setString(2, sVendorType);
			callableStatement.setString(3, sApproverName);
			callableStatement.setString(4, sAging);
			callableStatement.setString(5, sFromDate);
			callableStatement.setString(6, sToDate);
			callableStatement.setString(7, sFieldValues);
			callableStatement.setString(8, sUserMailID);
			callableStatement.setString(9, filePath);
			callableStatement.setString(10, fileName);
			callableStatement.registerOutParameter(11, java.sql.Types.VARCHAR);
			callableStatement.execute();

			output = callableStatement.getString(11);
			WriteLog("VS_Approval_status"," output "+output);
	}
	catch(SQLException ignore)
	{
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		bError= true;
		WriteLog("VS_Approval_status"," WFSession Data Fetch Exception:::::: "+ignore.toString());
		%>
		<script>alert("Error While Generating Report");</script>
		<%

	}
	finally {
 
	if (callableStatement != null) {
        try {
            callableStatement.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
	}

	if(!bError)
	{

		WriteLog("VS_Approval_status"," output:::::: "+output);
		try
		{

			if(output.equals(""))
			{
				bError= true;
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+output+"</b></font><center>");
			}
			else
			{
				
					try
							{
								 if(Integer.parseInt(output) == 0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
								out.println(ig.toString());
								%>
									<script>alert("Error While Generating Report");</script>
								<%
								WriteLog("VendorSetupExceptionReport"," Error:::::: "+ig.toString());
							}
			}
		}
		
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
								%>
									<script>alert("Error While Generating Report");</script>
								<%
								WriteLog("VendorSetupExceptionReport"," Error:::::: "+exp.toString());
		}
		
	}
	
	%>

			
		
			<FORM name="textForm">

			</form>	
		
	
			

<%!
 public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }


%>





/*  
WNS_TA_APVS_Approval_Status_Report 'All~','Policyholder vendors~','All~','','01/MAR/2014','04/APR/2014','Current_Work_Step,a.WI_Name,Vendor_Request_Type,Vendor_type,Priority,Vendor_Name,Vendor_Number,Payment_Terms,Vendor_Status,Address_Line_1,Address_Line_2,City_Address_Line_3,State_Code,Postal_code,Additional_Comments,Approvers_Comments,Approval_Id,Approval_Decision,Entry_Time,Approval_Date,Registration_Date','ee@www.com','//10.33.200.82/crebsfs/CR_EBS_APPS_MODEL/Omniflow/Reports/VS/TAVSApprovalStatusReport','VS_Approval_Status_Report',''

SELECT distinct Current_Work_Step,a.WI_Name,Vendor_Request_Type,Vendor_type,Priority,Vendor_Name,Vendor_Number,Payment_Terms,Vendor_Status,Address_Line_1,Address_Line_2,City_Address_Line_3,State_Code,Postal_code,Additional_Comments,Approvers_Comments,Approval_Id,Approval_Decision,Entry_Time,Approval_Date,Registration_Date from WNS_TA_APVS_EXT_Table a with(nolock)  
WHERE (Approval_Decision='' or Approval_Decision is null) and  
current_work_step ='VendorApproval'
 and Vendor_Type ='Policyholder vendors' 
 and Entry_Time BETWEEN 'Mar  1 2014 12:00AM' AND 'Apr  4 2014 11:59PM' order by Wi_Name 
*/  

  
alter PROCEDURE WNS_TA_APVS_Approval_Status_Report  

(  
@VendorReqType varchar(200),  
@VendorType VARCHAR(500),  
@approverName varchar(200),  
@Aging  varchar(20),  
@DateRangeFrom  VARCHAR(50),  
@DateRangeTo VARCHAR(50),  
@Fields varchar(4000),  
@EmailID  varchar(200),  
@FilePath varchar(200),  
@FileName varchar(200),  
@RowCount  varchar(500) OUTPUT  
)  
AS
declare  
	@WhereQuery varchar(2000),  
	@Query varchar(5000),  
	@Tables varchar(200),  
	@BkpTable varchar(200),  
	@VendorReport varchar(200),
	@EntryExitDetails varchar(8000),  
	@Disp_QName varchar(100),
	@Count_Q varchar(100),  
	@status_temp varchar(8000),  
	@dbname varchar(60),  
	@Queuename varchar (50),  
	@VendorReqTypeReport varchar(250),  
	@approverNameReport varchar(250),
	@appName nvarchar(4000),
	@VendorTypeTemp nvarchar(250),
	@VendorReqTypeTemp nvarchar(250)  
  
	BEGIN  
		Set nocount on
		set @FileName=@FilePath+'/'+@EmailID+'_'+@FileName+'_'+convert(varchar,getdate(),104)+'.xls'  
		set @WhereQuery='WHERE (Approval_Decision='''' or Approval_Decision is null) and '  

		set @Tables='WNS_TA_APVS_EXT_Table a with(nolock) ';
		SET @VendorReport=''  
		SET @Queuename='VendorApproval'
		set @appName = ''
		set @VendorTypeTemp = ''
		set @VendorReqTypeTemp = '' 
		 --print @VendorType  
		 
		  --if Object_ID('#TAVS_Approvalstatus_Report_Temp') is not null  
		  --begin  
		  --print 'Table dropped'  
		  -- exec('drop table #TAVS_Approvalstatus_Report_Temp')  
		  --end 
  
		Create Table #TAVS_Approvalstatus_Report_Temp
		(
			Current_Work_Step varchar(30) ,  
			WI_Name varchar(50) ,  
			Vendor_Request_Type varchar(30) ,  
			Vendor_type varchar(50) ,  
			Priority varchar(100) ,  
			Vendor_Name varchar(100) ,  
			Vendor_Number varchar(80) ,  
			Payment_Terms varchar(100) ,  
			Vendor_Status varchar(100) ,  
			Address_Line_1 varchar(550) ,  
			Address_Line_2 varchar(550) ,  
			City_Address_Line_3 varchar(550) ,  
			State_Code varchar(10) ,  
			Postal_code varchar(50) ,  
			Additional_Comments nvarchar(512), 
			Approvers_Comments varchar(512) ,  
			Approval_Id varchar(512) ,  
			Approval_Decision varchar(100) ,  
			Wi_EntryTime varchar(30),  
			Approval_Date varchar(30),  
			Registration_Date varchar(30),  
			Aging varchar(30),
			rn varchar(3)
		)
		--Approval_req_Date  
		--Wi_EntryTime  

		--set @WhereQuery=@WhereQuery+' and  a.current_wrk_step = ''VendorApproval''' 
		set @WhereQuery=@WhereQuery+' current_work_step =' +''''+@Queuename+''''  
		print @WhereQuery  
  
		--Vendor_Request_Type  

		if(rtrim(ltrim(@VendorReqType))<>'All~')  
		BEGIN  
			if(len(@VendorReqType)=charindex('~',@VendorReqType))  
			BEGIN  
				set @VendorReqTypeTemp =ltrim(rtrim(substring(@VendorReqType,0,len(@VendorReqType))))  
				set @VendorReqTypeReport=ltrim(rtrim(substring(@VendorReqType,0,len(@VendorReqType))))  
				print @VendorReqTypeReport  
				set @WhereQuery=@WhereQuery+' and Vendor_Request_Type ='''+@VendorReqTypeReport+''''  
			End  
			else  
			BEGIN  
				while (charindex('~',@VendorReqType)>1)  
				BEGIN
					set @VendorReqTypeTemp = @VendorReqTypeTemp+ltrim(rtrim(SUBSTRING(@VendorReqType,1,Charindex('~',@VendorReqType)-1)))+',' 
					set @VendorReqTypeReport = @VendorReqTypeReport + ''''+ltrim(rtrim(SUBSTRING(@VendorReqType,1,Charindex('~',@VendorReqType)-1)))+''''+','  
					set @VendorReqType=ltrim(rtrim(Substring(@VendorReqType,Charindex('~',@VendorReqType)+len('~'),len(@VendorReqType))))  
				END 
set @VendorReqTypeReport=SUBSTRING(@VendorReqTypeReport,0,len(@VendorReqTypeReport))
set @WhereQuery=@WhereQuery+' and Vendor_Request_Type in('+@VendorReqTypeReport+')'  
  END  
  
  --PRINT @WhereQuery  
  SET @WhereQuery=@WhereQuery  
 END  
  
 --approverName  
 if(rtrim(ltrim(@approverName))<>'All~')  
 BEGIN  
  if(len(@approverName)=charindex('~',@approverName))  
  BEGIN 
 set @appName =ltrim(rtrim(substring(@approverName,0,len(@approverName)))) 
set @approverNameReport=ltrim(rtrim(substring(@approverName,0,len(@approverName))))  
print @approverNameReport  
  -- set @WhereQuery=@WhereQuery+' and Approval_Id ='''+@approverNameReport+''''  
  End  
  else  
  BEGIN  
while (charindex('~',@approverName)>1)  
BEGIN
 set @appName = @appName+ltrim(rtrim(SUBSTRING(@approverName,1,Charindex('~',@approverName)-1)))+',' 
 set @approverNameReport = @approverNameReport + ''''+ltrim(rtrim(SUBSTRING(@approverName,1,Charindex('~',@approverName)-1)))+''''+','  
 set @approverName=ltrim(rtrim(Substring(@approverName,Charindex('~',@approverName)+len('~'),len(@approverName))))  
END 
set @approverNameReport=SUBSTRING(@approverNameReport,0,len(@approverNameReport))
  -- set @WhereQuery=@WhereQuery+' and Approval_Id in('+@approverNameReport+')'  
  END  
  --PRINT @WhereQuery  
  SET @WhereQuery=@WhereQuery  
 END  
  
 if(rtrim(ltrim(@VendorType))<>'All~')  
 BEGIN  
  if(len(@VendorType)=charindex('~',@VendorType))  
  BEGIN
 set @VendorTypeTemp =ltrim(rtrim(substring(@VendorType,0,len(@VendorType)))) 
set @VendorReport=ltrim(rtrim(substring(@VendorType,0,len(@VendorType))))  
print @VendorReport  
set @WhereQuery=@WhereQuery+' and Vendor_Type ='''+@VendorReport+''''  
  End  
  else  
  BEGIN  
while (charindex('~',@VendorType)>1)  
BEGIN 
 set @VendorTypeTemp=@VendorTypeTemp+ltrim(rtrim(SUBSTRING(@VendorType,1,Charindex('~',@VendorType)-1)))+','  
set @VendorReport = @VendorReport + ''''+ltrim(rtrim(SUBSTRING(@VendorType,1,Charindex('~',@VendorType)-1)))+''''+','  
 set @VendorType=ltrim(rtrim(Substring(@VendorType,Charindex('~',@VendorType)+len('~'),len(@VendorType))))  
END 
set @VendorReport=SUBSTRING(@VendorReport,0,len(@VendorReport))
set @WhereQuery=@WhereQuery+' and Vendor_Type in('+@VendorReport+')'  
  END  
  
  --PRINT @WhereQuery  
  SET @WhereQuery=@WhereQuery  
 END  
  
 
  
 if(rtrim(ltrim(@DateRangeFrom))<>'')  
  SET @DateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@DateRangeFrom,121)))))
  
 if(rtrim(ltrim(@DateRangeTo))<>'')  
  SET @DateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@DateRangeTo,121))))) 
  
 if(rtrim(ltrim(@DateRangeFrom)) != '' and rtrim(ltrim(@DateRangeTo)) != '')
 BEGIN  
  set @WhereQuery = @WhereQuery+' and Entry_Time BETWEEN '''+@DateRangeFrom+''' AND '''+@DateRangeTo+''''  
 END  
  
 -- WI passed away from approver queue  
/*insert into #TAVS_Approvalstatus_Report_Temp(  
WI_Name ,Current_Work_Step ,  Vendor_Request_Type , Vendor_type, Priority , Vendor_Name ,  
Vendor_Number , Payment_Terms, Vendor_Status , Address_Line_1 , Address_Line_2,  
City_Address_Line_3 , State_Code, Postal_code , Approvers_Comments , Approval_Id,  
Approval_Decision, Approval_Date , Registration_Date,Wi_EntryTime,Additional_Comments)  
select distinct a.WI_Name ,Current_Work_Step  ,  Vendor_Request_Type , Vendor_type, Priority ,  
Vendor_Name , Vendor_Number , Payment_Terms, Vendor_Status , Address_Line_1 ,  
Address_Line_2, City_Address_Line_3 , State_Code, Postal_code ,  
Approvers_Comments , Approval_Id, Approval_Decision, Approval_Date , Registration_Date,  
 b.Wi_EntryTime ,Additional_Comments
from WNS_TA_APVS_EXT_Table a with(nolock),WNS_TA_APVS_EntryExitTable b with(nolock) where a.wi_name in (select distinct wi_name from WNS_TA_APVS_EntryExitTable where activityname = 'VendorApproval')  
and a.wi_name = b.wi_name  
and activityname = 'VendorApproval' */  
  
--select * from #TAVS_Approvalstatus_Report_Temp  
  
 Set @Query='insert into #TAVS_Approvalstatus_Report_Temp(Current_Work_Step, WI_Name , Vendor_Request_Type, Vendor_type , Priority , Vendor_Name , Vendor_Number , Payment_Terms , Vendor_Status , Address_Line_1 , Address_Line_2 , City_Address_Line_3 ,State_Code , Postal_code , Additional_Comments,Approvers_Comments, Approval_Id , Approval_Decision , Wi_EntryTime , Approval_Date , Registration_Date)'  
 SET @Query=@Query+' SELECT distinct '+@Fields+' from '+ @Tables + ' '+@WhereQuery + ' order by Wi_Name '  
 
 print (@Query)  
 exec(@Query)
  
--select * from #TAVS_Approvalstatus_Report_Temp  
  
 exec('update #TAVS_Approvalstatus_Report_Temp set  
 Aging = cast((isnull(datediff(hh,wi_entrytime,convert(varchar,getdate(),121)),''0''))/24.0 as numeric(10,2))')  
  
		if(ltrim(rtrim(@Aging))<>'')
		begin
			select @RowCount=count(*) from #TAVS_Approvalstatus_Report_Temp with(nolock) where CAST(Aging AS numeric(10,2)) <= CAST(@Aging AS numeric(10,2))  
		end
		else
		BEGIN
			select @RowCount=count(*) from #TAVS_Approvalstatus_Report_Temp with(nolock)
		END

  
 
  
 if(@RowCount=0)  
 Begin  
  drop table #TAVS_Approvalstatus_Report_Temp  
 
 End  
 else  
 begin
  if Object_ID ('TAVS_TEMP_AUTOMAIL_Q') is not null
  BEGIN
exec('drop table TAVS_TEMP_AUTOMAIL_Q')  
  END 

  print @VendorReqTypeTemp  
  Exec('Create table TAVS_TEMP_AUTOMAIL_Q (Header varchar(8000),ROw_Index int IDENTITY(1,1) PRIMARY KEY)')  
	if(ltrim(rtrim(@Aging))<>'')
	begin
		Exec('Insert into TAVS_TEMP_AUTOMAIL_Q
		Select ''<html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style> 
		<table border=1>  
		<tr align="left"><td colspan=22 class=headerbold><center>Vendor Setup Approval Status Report</center></td></tr>  
		<tr align="left"><td colspan=22 class=headerbold> From : '+@DateRangeFrom+'</td></tr>  
		<tr align="left"><td colspan=22 class=headerbold> To : '+@DateRangeTo+'</td></tr>
		  <tr align="left"><td colspan=22 class=headerbold> Approver Name : '+@appName+'</td></tr> 
		  <tr align="left"><td colspan=22 class=headerbold> Vendor Type : '+@VendorTypeTemp+'</td></tr> 
		  <tr align="left"><td colspan=22 class=headerbold> Vendor Request Type : '+@VendorReqTypeTemp+'</td></tr>
		  <tr align="left"><td colspan=22 class=headerbold> Aging (In Days) : '+@Aging+'</td></tr>  
		</table>  <br>  
		<table border=1><tr><td class=headerbold>Current Queue</td>''+
		''<td class=headerbold>WI Name</td>''+  
		''<td class=headerbold>Vendor Request Type</td>''+  
		  ''<td class=headerbold>Vendor Type</td>''+  
		''<td class=headerbold>Priority</td>''+  
		''<td class=headerbold>Vendor Name</td>''+  
		''<td class=headerbold>Vendor number</td>''+  
		''<td class=headerbold>Payment Terms</td>''+  
		''<td class=headerbold>Vendor Status</td>''+  
		''<td class=headerbold>Address Line 1</td>''+  
		''<td class=headerbold>Address Line 2</td>''+  
		''<td class=headerbold>City Address Line 3</td>''+  
		''<td class=headerbold>State Code</td>''+  
		''<td class=headerbold>Postal code (Zip code)</td>''+  
		''<td class=headerbold>Additional Comments</td>''+  
		''<td class=headerbold>Approvers Comments</td>''+ 
		''<td class=headerbold>Approver Name</td>''+  
		''<td class=headerbold>Approval Decision</td>''+  
		''<td class=headerbold>Assigned Date</td>''+  
		''<td class=headerbold>Approved Date</td>''+  
		''<td class=headerbold>Introduced Date</td>''+  
		''<td class=headerbold>Aging (In Days)</td>''+  
		''</tr></font>''  
		UNION ALL
		  
		Select ''<tr><td align=left style=mso-number-format:\\@>''+ISNULL([Current_Work_Step],'''')+''</td>''+
		''<td align=left style=mso-number-format:\\@>''+ISNULL([Wi_Name],'''')+''</td>''+
		''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Request_Type],'''')+''</td>'' +
		''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_type],'''')+''</td>'' +
		''<td align=left style=mso-number-format:\\@>''+ISNULL([Priority],'''')+''</td>'' +  
		''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Name],'''')+''</td>'' +
		''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Number],'''')+''</td>'' +
		''<td align=left style=mso-number-format:\@>''+''''+ISNULL([Payment_Terms],'''')+''</td>'' +
		''<td align=left style=mso-number-format:\@>''+ISNULL([Vendor_Status],'''')+''</td>'' +
		''<td align=left style=mso-number-format:\@>''+ISNULL([Address_Line_1],'''')+''</td>'' +
		''<td align=left style=mso-number-format:\@>''+ISNULL([Address_Line_2],'''')+''</td>'' +
		''<td align=left style=mso-number-format:\@>''+ISNULL([City_Address_Line_3],'''')+''</td>'' +
		''<td align=left style=mso-number-format:\@>''+ISNULL([State_Code],'''')+''</td>'' +
		''<td align=left style=mso-number-format:\@>''+ISNULL([Postal_code],'''')+''</td>'' +
		''<td align=left style=mso-number-format:\@>''+ISNULL([Additional_Comments],'''')+''</td>'' +
		 ''<td align=left style=mso-number-format:\@>''+ISNULL([Approvers_Comments],'''')+''</td>'' +
		''<td align=left style=mso-number-format:\@>''+ISNULL([Approval_Id],'''')+''</td>'' +
		''<td align=left style=mso-number-format:\@>''+ISNULL([Approval_Decision],'''')+''</td>'' +
		''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Wi_EntryTime],''''),120)+''</td>''+
		''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Approval_Date],''''),120)+''</td>''+
		''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Registration_Date],''''),120)+''</td>''+
		''<td align=left style=mso-number-format:\@>''+ISNULL([Aging],'''')+''</td>''  
		from #TAVS_Approvalstatus_Report_Temp where CAST(Aging AS numeric(10,2)) <= CAST('+@Aging+' AS numeric(10,2))')  
		  
	END
	ELSE
	BEGIN
Exec('Insert into TAVS_TEMP_AUTOMAIL_Q
Select ''<html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style> 
<table border=1>  
<tr align="left"><td colspan=22 class=headerbold><center>Vendor Setup Approval Status Report</center></td></tr>  
<tr align="left"><td colspan=22 class=headerbold> From : '+@DateRangeFrom+'</td></tr>  
<tr align="left"><td colspan=22 class=headerbold> To : '+@DateRangeTo+'</td></tr>
  <tr align="left"><td colspan=22 class=headerbold> Approver Name : '+@appName+'</td></tr> 
  <tr align="left"><td colspan=22 class=headerbold> Vendor Type : '+@VendorTypeTemp+'</td></tr> 
  <tr align="left"><td colspan=22 class=headerbold> Vendor Request Type : '+@VendorReqTypeTemp+'</td></tr>
  <tr align="left"><td colspan=22 class=headerbold> Aging (In Days) : '+@Aging+'</td></tr>  
</table>  <br>  
<table border=1><tr><td class=headerbold>Current Queue</td>''+
''<td class=headerbold>WI Name</td>''+  
''<td class=headerbold>Vendor Request Type</td>''+  
  ''<td class=headerbold>Vendor Type</td>''+  
''<td class=headerbold>Priority</td>''+  
''<td class=headerbold>Vendor Name</td>''+  
''<td class=headerbold>Vendor number</td>''+  
''<td class=headerbold>Payment Terms</td>''+  
''<td class=headerbold>Vendor Status</td>''+  
''<td class=headerbold>Address Line 1</td>''+  
''<td class=headerbold>Address Line 2</td>''+  
''<td class=headerbold>City Address Line 3</td>''+  
''<td class=headerbold>State Code</td>''+  
''<td class=headerbold>Postal code (Zip code)</td>''+  
''<td class=headerbold>Additional Comments</td>''+  
''<td class=headerbold>Approvers Comments</td>''+ 
''<td class=headerbold>Approver Name</td>''+  
''<td class=headerbold>Approval Decision</td>''+  
''<td class=headerbold>Assigned Date</td>''+  
''<td class=headerbold>Approved Date</td>''+  
''<td class=headerbold>Introduced Date</td>''+  
''<td class=headerbold>Aging (In Days)</td>''+  
''</tr></font>''  
UNION ALL
  
Select ''<tr><td align=left style=mso-number-format:\\@>''+ISNULL([Current_Work_Step],'''')+''</td>''+
''<td align=left style=mso-number-format:\\@>''+ISNULL([Wi_Name],'''')+''</td>''+
''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Request_Type],'''')+''</td>'' +
''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_type],'''')+''</td>'' +
''<td align=left style=mso-number-format:\\@>''+ISNULL([Priority],'''')+''</td>'' +  
''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Name],'''')+''</td>'' +
''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Number],'''')+''</td>'' +
''<td align=left style=mso-number-format:\@>''+''''+ISNULL([Payment_Terms],'''')+''</td>'' +
''<td align=left style=mso-number-format:\@>''+ISNULL([Vendor_Status],'''')+''</td>'' +
''<td align=left style=mso-number-format:\@>''+ISNULL([Address_Line_1],'''')+''</td>'' +
''<td align=left style=mso-number-format:\@>''+ISNULL([Address_Line_2],'''')+''</td>'' +
''<td align=left style=mso-number-format:\@>''+ISNULL([City_Address_Line_3],'''')+''</td>'' +
''<td align=left style=mso-number-format:\@>''+ISNULL([State_Code],'''')+''</td>'' +
''<td align=left style=mso-number-format:\@>''+ISNULL([Postal_code],'''')+''</td>'' +
''<td align=left style=mso-number-format:\@>''+ISNULL([Additional_Comments],'''')+''</td>'' +
 ''<td align=left style=mso-number-format:\@>''+ISNULL([Approvers_Comments],'''')+''</td>'' +
''<td align=left style=mso-number-format:\@>''+ISNULL([Approval_Id],'''')+''</td>'' +
''<td align=left style=mso-number-format:\@>''+ISNULL([Approval_Decision],'''')+''</td>'' +
''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Wi_EntryTime],''''),120)+''</td>''+
''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Approval_Date],''''),120)+''</td>''+
''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Registration_Date],''''),120)+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([Aging],'''')+''</td>''  
from #TAVS_Approvalstatus_Report_Temp with(nolock)')  
  
	END
  --print @Query  
 -- Exec(@Query)
  
select @status_temp='<tr></tr></tr></table><html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style><table border=1><tr>'+'<td class=headerbold><b>Date From </b></td><td class=headerbold><b>Date To</b></td><td class=headerbold><b>WI Count</b></td></tr></style><tr><td>'+convert(varchar(100),@DateRangeFrom)+'</td><td>'+convert(varchar(100),@DateRangeTo)+'</td><td>'+convert(varchar(100),@RowCount)+'</td></tr>' 
  select @status_temp=@status_temp+'</table>' 
  
--print @status_temp  

  exec('insert into TAVS_TEMP_AUTOMAIL_Q select '''+@status_temp+'''') 
  
  update TAVS_TEMP_AUTOMAIL_Q set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yy>&nbsp</td>')
  
  select @dbname = DB_NAME()  
  SET @Query='Master..xp_Cmdshell ''bcp "select Header FROM '+@dbname+'..TAVS_TEMP_AUTOMAIL_Q order by row_index asc " queryout "'+@FileName+'" -c -T'', no_output  ' 
  
  exec(@Query)  
  insert into NG_AutoMail_Status values('VS Approval Status Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL)  

  --drop table #TAVSQSummaryException
  --drop table #TAVS_Approvalstatus_Report_Temp
  drop table TAVS_TEMP_AUTOMAIL_Q
  
 end  
 select @RowCount  
end  

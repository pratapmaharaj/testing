<!-- 
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-TCI
Module : TCI
File Name : Select_User.jsp
Author :
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date Change By Change Description (Bug No. (If Any))
(DD/MM/YYYY)
----------------------------------------------------------------------------------------------------
 -->
 <%@ include file="customized.process" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*,java.sql.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>

 

 <%	
	String sCabname=null;
	String sSessionId = null;
	String sJtsIp = null;
	String sUserName=null;
	String sOutputXML=null;
	String sGroupName=request.getParameter("GroupName");
	int iJtsPort = 0;
	int iMainCode=0;
	String sResult="";
	boolean bError=false;
	String sStr_ServerType = null;
	
	
		
		String sRootPathini=application.getRealPath("")+File.separator+"reports"+File.separator+"GMACReports"+File.separator+"ApprovalProcessProductivityReport" + File.separator + "Report.ini";
		Properties ini = new Properties();
		
		FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(sRootPathini);
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("AP_Productivity_Report","Unable to read AP_Productivity_Report.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("AP_Productivity_Report","Unable to close the AP_Productivity_Report.ini file");
						}
					}
				}
	
		String connectionUrl=ini.getProperty("ConnectionUrl");
		String dbuserName = ini.getProperty("username");
		String dbpass     = ini.getProperty("password");
		String DB=ini.getProperty("CABINETNAME");
		connectionUrl = connectionUrl+";"+"databaseName="+DB+";user="+dbuserName+";password="+dbpass;
		Connection conn=null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		try
		{		
			
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			conn = DriverManager.getConnection(connectionUrl);
			
			
			ps=conn.prepareStatement("select distinct b.username from pdbgroupmember a,pdbuser b where a.groupindex in(select groupindex from pdbgroup where groupname in (?)) and a.userindex=b.userindex and a.userindex<>1");
			ps.setString(1,sGroupName);
			rs=ps.executeQuery();
			while(rs.next())
			{
				sResult+=rs.getString(1)+'~';	
			}
		}

	catch(Exception e)
	{	sResult="Exception:" + e.toString();
		out.println("Exception:" + e.toString());
		
	}
	finally {
    
    if (rs != null) {
        try {
            rs.close();
        } catch (SQLException e) { }
    }
	if (ps != null) {
        try {
            ps.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
}
		
		WriteLog("AP_Productivity_Report "," sResult::> sResult : "+sResult);
			
			
%>

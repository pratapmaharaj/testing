 <%@ include file="customized.process" %>

<%@ page import="java.io.*,java.util.*,java.sql.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>
<%@ page import="java.sql.*"%>

<HTML>
<HEAD>
<TITLE>AP Productivity Report</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>
<script src="../../GMAC/Scripts/Common.js"></script>
<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
}
</style>

 <%
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAAPProductivityReport.ini";
	Properties ini = new Properties();
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("AP_Productivity_Report","Unable to read AP_Productivity_Report.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("AP_Productivity_Report","Unable to close the AP_Productivity_Report.ini file");
						}
					}
				}
	

	Connection conn = null;
	String sUserName1 = "" ;
	String connectionUrl = "" ;
	String sApproverName="";
	String sGroupname     =ini.getProperty("GROUPNAMES");
	String sTempGroupName ="'"+sGroupname.replaceAll(",","','")+"'";
	sGroupname     =sGroupname.replaceAll(",","~");

	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("AP_Productivity_Report","sRootPathDBini="+sRootPathDBini);

	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("AP_Productivity_Report","Unable to read AP_Productivity_Report.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("AP_Productivity_Report","Unable to close the AP_Productivity_Report.ini file");
						}
					}
				}

	String driverName = null;
	driverName=ini.getProperty("DRIVERNAME");
	connectionUrl=ini.getProperty("CONNECTIONSTRING");
	WriteLog("AP_Productivity_Report","driverName="+driverName+",conString="+connectionUrl);

	WriteLog("AP_Productivity_Report"," connectionUrl "+connectionUrl);

	String query="select distinct b.username,b.userindex from pdbgroupmember a,pdbuser b where a.groupindex in(select groupindex from pdbgroup where groupname in ("+sTempGroupName+")) and a.userindex=b.userindex and a.userindex<>1" ;
	Statement stmt = null ;
	WriteLog("AP_Productivity_Report"," query "+query);
	ResultSet rs=null;
	try
	{
		Class.forName(driverName);
		conn = DriverManager.getConnection(connectionUrl);
		stmt = conn.createStatement();
		rs = stmt.executeQuery(query);

		while (rs.next()) 
		{
			sUserName1 = rs.getString("username")+"~"+sUserName1;
		}
	}
	catch(SQLException e)
	{
		out.println("Exception:" + e.toString());
	}
	
	finally {
    if (rs != null) {
        try {
            rs.close();
        } catch (SQLException e) {   }
    }
    if (stmt != null) {
        try {
            stmt.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) {  }
    }
}
	
	
%>


<script>
	var userList = "" ;
	var FromDate = new Date();
	var type = '';
	var allWindows = new Array();
	var win; // new window object
	$(document).ready(function(){$('#From_Date_Queue').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date_Queue').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	
	});
	/*functions echeck,ValidateForm added by nilesh*/
	function echeck(str)
	{

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}

function ValidateForm(emailID){
//	var emailID=document.frmSample.txtEmail
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }

function ChangeDateTag(obj)
{
	alert(obj);
	var InsertVal='';
	for(iterate=0;iterate<obj.length;iterate++)
	{
		if(obj.options[iterate].selected==true)
		{
			InsertVal=InsertVal+obj.options[iterate].value+'/';
		}
	}
	InsertVal=InsertVal.substring(0,InsertVal.length-1);
	var Table=document.getElementById('newgen');
	var lastRow = Table.rows.length;
	if (lastRow > 0) Table.deleteRow(lastRow - 1);
	while(InsertVal.indexOf('_')!=-1)
	{
		InsertVal=InsertVal.replace('_',' ');
	}
	var Row=Table.insertRow(0);
	var Cell=Row.insertCell();
	Cell.className="EWLabelBoldNew";
	Cell.innerHTML=InsertVal;
}

function compToday(Date_To)
{
	var todaysDate = new Date(); 
	var dd = todaysDate.getDate() ;
	var mm = todaysDate.getMonth()+1 ;
	//var yy = todaysDate.getFullYear() ;
	var yy = todaysDate.getFullYear() ;
	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));

	var Date_To_date=Number(Date_To.substring(0,Date_To.indexOf("/")));	

	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));

	if(Date_To_month=="JAN")
			Date_To_month="1";
		else if(Date_To_month=="FEB")
			Date_To_month="2";
		else if(Date_To_month=="MAR")
			Date_To_month="3";
		else if(Date_To_month=="APR")
			Date_To_month="4";
		else if(Date_To_month=="MAY")
			Date_To_month="5";
		else if(Date_To_month=="JUN")
			Date_To_month="6";
		else if(Date_To_month=="JUL")
			Date_To_month="7";
		else if(Date_To_month=="AUG")
			Date_To_month="8";
		else if(Date_To_month=="SEP")
			Date_To_month="9";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";

	if(Date_To_year>yy)
	{
		return false;
	}
	else if(Date_To_year<yy)
	{
		//if(Date_From_month>Date_To_month)
		//{
		//alert("To Date can not be less than From Date.");
		//return false;
		//}
		 if(mm==Date_To_month)
		{
			if(Date_To_date>dd)
			{
				return false;
			}
		}
	}
	else if(Date_To_year==yy)
	{
		if(mm<Date_To_month)
		{
		return false;
		}
		else if(mm==Date_To_month)
		{
			if(Date_To_date>dd)
			{
				return false;
			}
		}
	}
return true ;
}
function DateComparator(Date_To,Date_From)
{	
	if(!compToday(Date_To))
	{
		alert("To Date can not be Future Date.");
		return false ;
	}

	if(!compToday(Date_From))
	{
		alert("From Date can not be Future Date.");
		return false ;
	}
	//alert(dd+" "+mm+" "+yy) ;
	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));	
	var Date_From_month=Date_From.substring(Date_From.indexOf("/")+1,Date_From.lastIndexOf("/"));

	/*converting ToDate month to number */
	if(Date_To_month=="JAN")
			Date_To_month="01";
		else if(Date_To_month=="FEB")
			Date_To_month="02";
		else if(Date_To_month=="MAR")
			Date_To_month="03";
		else if(Date_To_month=="APR")
			Date_To_month="04";
		else if(Date_To_month=="MAY")
			Date_To_month="05";
		else if(Date_To_month=="JUN")
			Date_To_month="06";
		else if(Date_To_month=="JUL")
			Date_To_month="07";
		else if(Date_To_month=="AUG")
			Date_To_month="08";
		else if(Date_To_month=="SEP")
			Date_To_month="09";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";


	/*converting FromDate month to number */
		if(Date_From_month=="JAN")
			Date_From_month="01";
		else if(Date_From_month=="FEB")
			Date_From_month="02";
		else if(Date_From_month=="MAR")
			Date_From_month="03";
		else if(Date_From_month=="APR")
			Date_From_month="04";
		else if(Date_From_month=="MAY")
			Date_From_month="05";
		else if(Date_From_month=="JUN")
			Date_From_month="06";
		else if(Date_From_month=="JUL")
			Date_From_month="07";
		else if(Date_From_month=="AUG")
			Date_From_month="08";
		else if(Date_From_month=="SEP")
			Date_From_month="09";
		else if(Date_From_month=="OCT")
			Date_From_month="10";
		else if(Date_From_month=="NOV")
			Date_From_month="11";
		else if(Date_From_month=="DEC")
			Date_From_month="12";

	var Date_To_date=Number(Date_To.substring(0,Date_To.indexOf("/")));	
	var Date_From_date=Number(Date_From.substring(0,Date_From.indexOf("/")));

	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));
	var Date_From_year=Number(Date_From.substring(Date_From.lastIndexOf("/")+1,Date_From.length));

	if(Date_To_year<Date_From_year)
	{
		alert("To Date cannot be less than From  Date.");
		return false;
	}
	else if(Date_To_year>Date_From_year)
	{
		//if(Date_From_month>Date_To_month)
		//{
		//alert("To Date can not be less than From Date.");
		//return false;
		//}
		 if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{
				
				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}
	else if(Date_To_year==Date_From_year)
	{
	
		if(Date_From_month>Date_To_month)
		{
		alert("To Date can not be less than From Date.");
		return false;
		}
		else if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{

				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}

	var toDate = new Date(Date_To_month+"/"+Date_To_date+"/"+Date_To_year);
	var fromDate = new Date(Date_From_month+"/"+Date_From_date+"/"+Date_From_year);
	var oneDay=1000*60*60*24;

	var dateDiff=Math.ceil((toDate.getTime()-fromDate.getTime())/oneDay);
	/*if(dateDiff>90)
	{
		alert('Date Range can not be greater than 90 days.');
		return false;
	}*/
return true;
}
function FillGroupUserCombo()
{
	var sGroupname='<%=sGroupname%>';
	var UserNames='<%=sUserName1%>';
	userList = UserNames ;
	var UserNameArray=UserNames.split('~');
	
	for (var j=0;j<UserNameArray.length-1;j++)
	{
		optn=document.createElement("option");	
		req=document.getElementById("User");
		optn.text=UserNameArray[j];
		optn.value=UserNameArray[j];	
		req.options.add(optn);	
	}

}

function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";
	sDate	= window.showModalDialog('/processmanager/reports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');
	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
	

}
function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	strResult=strdate+"/"+strMonth+"/"+stryear;
	return strResult;
}
	
	function openreport()
	{	
		var QueueName="";
		var RegDateRangeFrom="";
		var RegDateRangeTo="";
		var QueueDateRangeFrom="";
		var QueueDateRangeTo="";
		var GroupName="";
		var UserNameForm="";
		var FinalUserNames="";
		var UserEmailID="";
		var DocumentCategory="";
		var QCDecision="";
		
		UserEmailID=document.getElementById('EMail-ID').value;
		
		QueueDateRangeFrom=document.forms["textForm"].From_Date_Queue.value;
		QueueDateRangeTo=document.forms["textForm"].To_Date_Queue.value;	


		for(var i=0;i<document.forms["textForm"].QC_Decision.length;i++)
		{
			if(document.forms["textForm"].QC_Decision[i].selected)
			{
				
				QCDecision=QCDecision+document.forms["textForm"].QC_Decision[i].value+'~';
				
			}
		}
		
		for(var i=0;i<document.forms["textForm"].Queue.length;i++)
		{
			if(document.forms["textForm"].Queue[i].selected)
			{
				
				QueueName=QueueName+document.forms["textForm"].Queue[i].value+'~';
				
			}
		}
		
		for(var i=0;i<document.forms["textForm"].Document_Category.length;i++)
		{
			if(document.forms["textForm"].Document_Category[i].selected)
			{
				
				DocumentCategory=DocumentCategory+document.forms["textForm"].Document_Category[i].value+'~';
				
			}
		}
		
		///For Users

		for(var l=0;l<document.forms["textForm"].User.length;l++)
		{
			if(document.forms["textForm"].User[l].selected)
			{
				
				UserNameForm=UserNameForm+document.forms["textForm"].User[l].value+'~';
				
			}
		}

		///For Users

		if(GroupName=="\'\'")
		{
			GroupName="";
		}

		if(UserNameForm=="~")
		{
			UserNameForm="";
		}

		var sTest=QueueName.split('~');
		var sDocCat=DocumentCategory.split('~');
		var sGroups=GroupName.split('~');
		var sUsers=UserNameForm.split('~');
		var sQCDecision=QCDecision.split('~');
		
		if(QueueName=='')
		{
			alert("Please select an appropriate Queue Name");
			return false;
		}

		
		if(UserNameForm.indexOf("All")!=-1 && sUsers.length>2)
		{
			alert("No other User can be chosen after choosing All.");
			return false;
			//QueueName='All~';
		}  

		if(UserNameForm==userList)
		{
			UserNameForm='All~';
		}

		if(QueueName.indexOf("All")!=-1 && sTest.length>2)
		{
			alert("No other Queue Name can be chosen after choosing All");
			return false;
			//QueueName='All~';
		}
		
		
		if(QueueDateRangeFrom=='')
		{
			alert('Please Select Queue Date Range From Date');
			return false;
		}
		if(QueueDateRangeTo=='')
		{
			alert('Please Select Queue Date Range To Date');
			return false;
		}
		
		if(DocumentCategory.indexOf("All")!=-1 && sDocCat.length>2)
		{
			alert("No other Document Category can be chosen after choosing All");
			return false;
			//QueueName='All~';
		} 

		if(QueueName=='Introduction~Processing~Coding~Approval~QC~GEACINTERFACE~PendingResolution~Rescan~Split~Cancel~ApprovalException~PolicyHolderPayment~PendingPayment~JournalEntry~')
		{
			QueueName='All~';
		}
		if(DocumentCategory=='Non PO Invoices~Policy Holder Payments~Escheatment~Credit Memo~Statement~Others~')
		{
			DocumentCategory='All~';
		}
		if(QCDecision=='Pass~Fail~')
		{
			QCDecision='All~';
		}
		
		
			console.log(sGroups);
			if(sGroups!="")
			{	
				alert('called');
				ServerRequest("Select_User.jsp","GroupName="+encodeURIComponent(GroupName));
				if (iAjaxMainCode=="15")
				{
					alert('Internal Server error.Please try again later.');
					return false;
				}
				else if (sAjaxReturnValue=="")
				{
					alert('Internal Server error.Please try again later.');
					return false;
				}
				else
				{
					FinalUserNames=sAjaxReturnValue;
				}
			}	
			if(sUsers!="")
			{
					FinalUserNames=UserNameForm;
			}

			/*Added by nilesh-Function is called for  comparing dates*/
				
		if(!DateComparator(QueueDateRangeTo,QueueDateRangeFrom))
		{
		return false;
		}

			/*added by nilesh for email validation*/
		if(UserEmailID=='')
		{
			alert("Please enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
			}
		}
				
					
			 if ((UserEmailID!='')&&(QueueName!='')&&(QueueDateRangeFrom!='')&&(QueueDateRangeTo !=''))
			{
				//OpenRedict-Fix
				//window.top.PRODUCTIVITYREPORT.location.href="APProductivityReportGenerate.jsp?&QueueName="+QueueName+"&QueueDateRangeFrom="+QueueDateRangeFrom+"&QueueDateRangeTo="+QueueDateRangeTo+"&ReportName=<%=request.getParameter("ReportName")%>&UserNames="+FinalUserNames+"&UserEmailID="+UserEmailID+"&Document_Category="+DocumentCategory+"&QC_Decision="+QCDecision;
				
				var URI = "APProductivityReportGenerate.jsp?&QueueName="+QueueName+"&QueueDateRangeFrom="+QueueDateRangeFrom+"&QueueDateRangeTo="+QueueDateRangeTo+"&ReportName=<%=request.getParameter("ReportName")%>&UserNames="+FinalUserNames+"&UserEmailID="+UserEmailID+"&Document_Category="+DocumentCategory+"&QC_Decision="+QCDecision;
				var StrOpenWin=strip_tags(URI,"");
				window.top.PRODUCTIVITYREPORT.location.href=StrOpenWin;
			}
			
}

	function DisableOtherCombo(Mode)
	{	
		if(Mode=='U')
		{
			if(document.textForm.Group.value=="")
			{
				
				document.textForm.User.disabled=false;
			}
			else
			{
				document.textForm.User.disabled=true;
			}
		}
		else
		{
			if(document.textForm.User.value=="")
			{
				
				document.textForm.Group.disabled=false;
			}
			else
			{
				document.textForm.Group.disabled=true;
			}
			
		}
		
	}
	
	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}
	
	function chkradio(obj)
	{
		
		

	}

</script>

<body topmargin="0" leftmargin="5" onload="FillGroupUserCombo();" onunload="UnloadReportWindow();">

			<form name='textForm' method=post>


			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">TA AP PRODUCTIVITY REPORT</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This report will provide user wise productivity statistics, i.e., number of workitems processed in various queues.
</td></tr>
<tr><td class="EWLabel1">Select All Queues if report is to be generated for viewing the workitems present across different worksteps, else select the specific Queue, multiple selections are again acceptable.
</td></tr><tr><td class="EWLabel1">Select a set of Users for whom the productivity has to be calculated.<br>
Select the requisite date range for generating the report for the same.</td>
</tr><tr><td class="EWLabel1"><b> Queue Name and Date Range are Mandatory.</b></td>
				</tr>
				<td>
		<br/>
					<p style="color: red; font-size: 10pt">Note:  * fields are mandatory.</p>

				</td>
			</table>

			

			<table border="0" width="95%" cellspacing="1" align="center">

				 <tr>
					<td class="EWLabel1" align="left" width='20%'><b>Queue<font color="RED">*</font></b></font></td>
					<td width='25%' colspan=3>
					<select style='width:45%' name="Queue" multiple>
					<option value="All">All</option>
					<option value="Introduction">Introduction</option>
					<option value="Processing">Processing</option>
					<option value="PolicyHolderPayment">PolicyHolderPayment</option>
					<option value="PendingResolution">Pending Resolution</option>
					<option value="Rescan">Rescan</option>
					<option value="Split">Split</option>
					<option value="Cancel">Cancel</option>
					<option value="QC">QC</option>
					<option value="Coding">Coding</option>
					<option value="Approval">Approval</option>
					<option value="ApprovalException">ApprovalException</option>
					<option value="GEAC INTERFACE">GEAC INTERFACE</option>
					<option value="JournalEntry">JournalEntry</option>
					<option value="PendingPayment">PendingPayment</option>
				
					</select>
					</td>
				</tr>

				</tr>
				<tr>
					<td class="EWLabel1" align="left" width='20%'><b>User 
					<td width='25%' COLSPAN=3>
						<!-- commented by megha
						<select style='width:45%' class='TextFieldColor'  name="User" multiple onchange="">
						-->
						<select style='width:45%' class='TextFieldColor'  id="User" multiple onchange="">
						<option value="All">All</option>			

						</select>
					
					</td>

				</tr>	

				 <tr>
					<td class="EWLabel1" align="left" width='20%'><b>Document Category</b></font></td>
					<td width='25%' colspan=3>
					<select style='width:45%' name="Document_Category" multiple>
					<option value="All">All</option>
					<option value="PO Invoices">PO Invoices</option>
					<option value="Non PO Invoices">Non PO Invoices</option>
					<option value="Policy Holder Payments">PH Payments</option>
					<option value="Escheatment">Escheatment</option>
					<option value="Credit Memo">Credit Memo</option>
					<option value="Statement">Statement</option>
					<option value="Others">Others</option>
					
				
					</select>
					</td>
				</tr>
				
				<tr>&nbsp;</tr>
				<tr >
					<td class="EWLabel1" align="left" width='20%'><b>QC Decision</b></td>
					<td width='25%' colspan=3>
					<select style='width:45%' name="QC_Decision" multiple>
					<option value="All">All</option>
					<option value="Pass">Pass</option>
					<option value="Fail">Fail</option>
					</select>
					</td>
				</tr>
				
				<tr>&nbsp;</tr>
				 
				 <tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>Queue Date Range<font color="RED">*</font> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date_Queue" readonly type="text"  id="From_Date_Queue" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date_Queue" readonly type="text"  id="To_Date_Queue" >
					
					</td>

				</tr>

			<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID<font color="RED">*</font></b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>
				
				</tr>

			

				
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>

			</form>
</body>
</Html>	 
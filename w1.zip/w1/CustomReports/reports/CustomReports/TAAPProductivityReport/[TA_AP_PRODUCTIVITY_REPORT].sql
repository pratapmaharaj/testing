    
    
    
/*         
        
       
      
TA_AP_PRODUCTIVITY_REPORT 'All~','01/JAN/2014','08/FEB/2014','All~',      
'Wi_ExitTime,UserName,Current_Work_Step,a.WI_Name,Registration_Date,Priority,Pay_Entity,Vendor_Name,Vendor_Number,ACH,AP_Check,Invoice_Number,Total_Invoice_Amount,Invoice_Date,Additional_Comments,QC_Decision,Reason_For_Return_Check,Approval_Decision,Appro
  
    
ved_Invoice_Amount,Multi_Payment,Wi_EntryTime,cast(Wi_ExitTime  as varchar(30)) as Wi_ExitTime1,(datediff(DD,Registration_Date,Wi_ExitTime)) as Aging',      
'','All~','yogesh.bindwal@wns.com','//10.33.192.139/XLS-File/AP/ProductivityReport'        
      
      
TA_AP_PRODUCTIVITY_REPORT 'All~','04/FEB/2014','11/FEB/2014','All~','Wi_ExitTime,UserName,Current_Work_Step,a.WI_Name,Registration_Date,Priority,Pay_Entity,Vendor_Name,Vendor_Number,ACH,AP_Check,Invoice_Number,Total_Invoice_Amount,Invoice_Date,Additional_
  
    
Comments,QC_Decision,Reason_For_Return_Check,Approval_Decision,Approved_Invoice_Amount,Multi_Payment,Wi_EntryTime,cast(Wi_ExitTime  as varchar(30)) as Wi_ExitTime1,(datediff(DD,Registration_Date,Wi_ExitTime)) as Aging','ok','All~','aa@bb.com','//10.33.192
  
    
.139/XLS-File/AP/ProductivityReport'      
*/            
        
        
CREATE PROCEDURE [dbo].[TA_AP_PRODUCTIVITY_REPORT]          
(          
@QueueName  VARCHAR(100),        
@QueueDateRangeFrom  VARCHAR(100),        
@QueueDateRangeTo  VARCHAR(100),        
@UserName varchar(1000),        
@Fields varchar(8000),        
@QCDecision varchar(1000),      
@DocumentCategory varchar(1000),        
@EmailID varchar(200),        
@path    nvarchar(50),  
@RowCount varchar(50) out     
)        
        
AS        
declare        
 @WhereQuery varchar(2000),        
 @Query varchar(5000),        
 @QueryHistory varchar(5000),        
 @QueryFinal varchar(5000),        
 @Tables varchar(200),        
 @QueueNameReport varchar(200),        
 @UserNameReport varchar(1000),       
 @DocNameReport varchar(1000),      
 @OrderBy varchar(300),        
 @OrderByFinal varchar(300),          
 @FileName varchar(200),               
 @USERNAMESUM varchar(100),        
 @ACTIVITYNAME varchar(100),            
 @WI_PROCESSED varchar(100),            
 @AVG_TIME varchar(100),        
 @status_temp varchar(8000),             
 @DataBaseName varchar(60),        
 @quName nvarchar(250),        
 @userN nvarchar(250)        
           
 Set nocount on        
 BEGIN         
          
 select @DataBaseName=DB_name()        
 if Object_ID('#AP_TEMP_TABLE_Productivity') is not null          
 begin          
  print 'Table dropped'          
  exec('drop table #AP_TEMP_TABLE_Productivity')          
 end            
        
 if Object_ID('APProductivitysummary') is not null          
 begin          
  print 'Table dropped'          
  exec('drop table APProductivitysummary')          
 end            
        
 CREATE TABLE #AP_TEMP_TABLE_Productivity (          
 Wi_ExitTime NVARCHAR(100),        
 UserName NVARCHAR(1000),        
 Current_Work_Step NVARCHAR(100),        
 WI_Name NVARCHAR(100),          
 Registration_Date varchar(100),      
 Priority nvarchar(100),      
 Pay_Entity NVARCHAR(100),            
 Vendor_Name NVARCHAR(200),         
 Vendor_Number NVARCHAR(100),            
 ACH NVARCHAR(100),        
 AP_Check NVARCHAR(100),             
 Invoice_Number NVARCHAR(100),        
 Total_Invoice_Amount NVARCHAR(10),        
 Invoice_Date NVARCHAR(100),         
 Additional_Comments NVARCHAR(100),            
 QC_Decision  NVARCHAR(100),           
 Reason_For_Return_Check NVARCHAR(10),            
 Approval_Decision NVARCHAR(10),         
 Approved_Invoice_Amount NVARCHAR(512),            
            
 Multi_Payment NVARCHAR(100),             
 Wi_EntryTime NVARCHAR(100),        
 Wi_ExitTime1 NVARCHAR(100),      
 Aging NVARCHAR(100)       
 )        
         
 --Temporary Table           
         
 --create temporary summary table             
 Create Table APProductivitysummary        
 (        
 USERNAME varchar(100),        
 ACTIVITYNAME varchar(100),            
 WI_PROCESSED varchar(100),            
 AVG_TIME varchar(100)             
 )        
         
 set @FileName=@path+'/'+@EmailID+'_AP_Productivity_Report_'+convert(varchar,getdate(),104)+'.xls'          
 set @WhereQuery='WHERE '        
 set @QueueNameReport=''         
 set @UserNameReport=''        
 set @OrderBy=' order by b.UserName,Current_Work_Step,b.wi_name,b.wi_exittime'        
 set @OrderByFinal=' order by UserName,Current_Work_Step,wi_name,wi_exittime'     
 set @RowCount = ''     
         
 print 'Obtained Users '+@UserName        
 print 'Obtained Queues'+@QueueName          
 set @Tables='WNS_TA_AP_EXT_Table a with(nolock),WNS_TA_AP_EntryExitTable b with(nolock )'         
 set @WhereQuery=@WhereQuery+' a.wi_name=b.wi_name '        
         
         
       
        
 if(rtrim(ltrim(@QueueDateRangeFrom))<>'')        
 BEGIN        
  SET @QueueDateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@QueueDateRangeFrom,121)))))         
 END        
 if(rtrim(ltrim(@QueueDateRangeTo))<>'')        
 BEGIN        
  SET @QueueDateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@QueueDateRangeTo,121)))))            
 END        
       
       
----user name addition      
       
 if(rtrim(ltrim(@UserName))<>'All~')        
 BEGIN           
  if(len(@UserName)=charindex('~',@UserName))         
  BEGIN        
   set @UserNameReport=ltrim(rtrim(substring(@UserName,0,len(@UserName))))        
   --set @quName = @quName+','+ltrim(rtrim(substring(@QueueName,0,len(@QueueName))))        
   set @WhereQuery=@WhereQuery+' AND b.UserName='''+@UserNameReport+''''        
  END        
  else        
  BEGIN         
   while (charindex('~',@UserName)>1)            
   BEGIN        
    set @UserNameReport = @UserNameReport + ''''+ltrim(rtrim(SUBSTRING(@UserName,1,Charindex('~',@UserName)-1)))+''''+','        
    set @UserName=ltrim(rtrim(Substring(@UserName,Charindex('~',@UserName)+len('~'),len(@UserName))))         
    --set @quName=@quName +','+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+','        
   END        
        
   set @UserNameReport=substring(@QueueNameReport,0,len(@UserNameReport))        
   set @WhereQuery=@WhereQuery+' AND b.UserNamee in('+@UserNameReport+')'        
  END        
 END        
      
        
----UserName Addition         
        
        
 if(rtrim(ltrim(@QueueName))<>'All~')        
 BEGIN           
  if(len(@QueueName)=charindex('~',@QueueName))         
  BEGIN        
   set @QueueNameReport=ltrim(rtrim(substring(@QueueName,0,len(@QueueName))))        
   --set @quName = @quName+','+ltrim(rtrim(substring(@QueueName,0,len(@QueueName))))        
   set @WhereQuery=@WhereQuery+' AND B.ACTIVITYNAME='''+@QueueNameReport+''''        
  END        
  else        
  BEGIN         
   while (charindex('~',@QueueName)>1)            
   BEGIN        
    set @QueueNameReport = @QueueNameReport + ''''+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+''''+','        
    set @QueueName=ltrim(rtrim(Substring(@QueueName,Charindex('~',@QueueName)+len('~'),len(@QueueName))))         
    --set @quName=@quName +','+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+','        
   END        
        
   set @QueueNameReport=substring(@QueueNameReport,0,len(@QueueNameReport))        
   set @WhereQuery=@WhereQuery+' AND b.activityname in('+@QueueNameReport+')'        
  END        
 END        
         
 --reg Date           
        
 --reg date         
        
 --q date        
 if(rtrim(ltrim(@QueueDateRangeFrom))<>'' AND rtrim(ltrim(@QueueDateRangeTo))<>'')        
 BEGIN        
  set @WhereQuery=@WhereQuery+' AND Entry_Time between '''+rtrim(ltrim(@QueueDateRangeFrom))+''' AND '''+ rtrim(ltrim(@QueueDateRangeTo))+''''        
 END          
 --q date           
        
---Doc category      
       
       
       
       
 if(rtrim(ltrim(@DocumentCategory))<>'All~')        
 BEGIN           
  if(len(@DocumentCategory)=charindex('~',@DocumentCategory))         
 BEGIN        
   set @DocNameReport=ltrim(rtrim(substring(@DocumentCategory,0,len(@DocumentCategory))))        
   --set @quName = @quName+','+ltrim(rtrim(substring(@QueueName,0,len(@QueueName))))        
   set @WhereQuery=@WhereQuery+' AND B.ACTIVITYNAME='''+@DocNameReport+''''        
  END        
  else        
  BEGIN         
   while (charindex('~',@DocumentCategory)>1)            
   BEGIN        
    set @DocNameReport = @DocNameReport + ''''+ltrim(rtrim(SUBSTRING(@DocumentCategory,1,Charindex('~',@DocumentCategory)-1)))+''''+','        
    set @DocumentCategory=ltrim(rtrim(Substring(@DocumentCategory,Charindex('~',@DocumentCategory)+len('~'),len(@DocumentCategory))))         
    --set @quName=@quName +','+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+','        
   END        
        
   set @DocNameReport=substring(@DocNameReport,0,len(@DocNameReport))        
   set @WhereQuery=@WhereQuery+' AND b.activityname in('+@DocNameReport+')'        
  END        
 END       
       
 ---Doc category      
       
 ---QC Decision      
       
 if(rtrim(ltrim(@QCDecision))<>'')        
 BEGIN        
  set @WhereQuery=@WhereQuery+' AND a.QC_Decision='''+@QCDecision+''''        
 END      
       
 ---QC Decision      
 print @Fields         
         
 SET @Query='SELECT '+@Fields+' from '+ @Tables + @WhereQuery + @OrderBy        
         
 print '----'        
 print  @Query           
 set @QueryHistory=@Query        
         
 set @QueryHistory=Replace(@QueryHistory,'WNS_TA_AP_EntryExitTable','WNS_TA_AP_EntryExitTable_History')        
         
 --print @QueryHistory            
 set @Query='insert into #AP_TEMP_TABLE_Productivity '+ @Query        
 set @QueryHistory='insert into #AP_TEMP_TABLE_Productivity '+@QueryHistory        
 print     @Query           
 exec(@Query)          
         
 exec(@QueryHistory)        
          
 set @QueryFinal='select Wi_ExitTime,UserName,Current_Work_Step,a.WI_Name,Registration_Date,Priority,Pay_Entity,Vendor_Name,Vendor_Number,ACH,AP_Check,Invoice_Number,Total_Invoice_Amount,Invoice_Date,Additional_Comments,QC_Decision,Reason_For_Return_Chec 
 
k    
,Approval_Decision,Approved_Invoice_Amount,Multi_Payment,Wi_EntryTime,Wi_ExitTime1,isnull(datediff(DD,Registration_Date,Wi_ExitTime),''0'') as Aging from #AP_TEMP_TABLE_Productivity with(nolock)'+@OrderByFinal        
 print @QueryFinal        
          
 --exec(@QueryFinal)          
         
 SET @Query='insert into APProductivitysummary(USERNAME,ACTIVITYNAME,WI_PROCESSED,AVG_TIME)'        
 SET @QueryHistory='select USERNAME,Current_Work_Step,count(Current_Work_Step)as WI_PROCESSED,avg(convert(float,aging))as AVG_TIME from #AP_TEMP_TABLE_Productivity group by USERNAME,Current_Work_Step order by username'        
 set @Query=@Query+@QueryHistory        
 print(@Query)        
 exec (@Query)            
 select @RowCount=count(*) from APProductivitysummary with(nolock)        
 if(@RowCount=0)        
 Begin        
 drop table APProductivitysummary        
 End           
 print 'dfsdsd'            
 ------------        
 select @RowCount=count(*) from #AP_TEMP_TABLE_Productivity with(nolock)        
 if(@RowCount=0)          
 Begin          
 drop table #AP_TEMP_TABLE_Productivity          
 End          
 else         
 Begin        
 if Object_ID ('NG_TEMP_AUTOMAIL') is not null           
 BEGIN           
 exec('drop table NG_TEMP_AUTOMAIL')           
 END            
         
 Exec('Create table NG_TEMP_AUTOMAIL (Header varchar(8000),ROw_Index [int] identity(1,1) not null)')             
 set @Query = 'Insert into NG_TEMP_AUTOMAIL           
 Select ''<html> <style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>           
 <table border=1>        
 <tr align="left"><td colspan=18 class=headerbold align="left">        
 <center>                    
 TA Vendor Setup Productivity Report </center></td></tr>        
 </table>  <br>        
 <table border=1><tr><td class=headerbold>Date</td>''+          
 ''<td class=headerbold>User Name</td>''+            
 ''<td class=headerbold>Queue Name</td>''+            
 ''<td class=headerbold>Workitem Name</td>''+            
 ''<td class=headerbold>Registration Date</td>''+            
 ''<td class=headerbold>Priority</td>''+        
 ''<td class=headerbold>Pay Entity</td>''+       
 ''<td class=headerbold>Vendor Name</td>''+       
 ''<td class=headerbold>Vendor ID</td>''+            
 ''<td class=headerbold>ACH</td>''+         
 ''<td class=headerbold>Check</td>''+         
 ''<td class=headerbold>Invoice Number</td>''+             
 ''<td class=headerbold>Invoice Amount</td>''+           
 ''<td class=headerbold>Invoice Date</td>''+        
 ''<td class=headerbold>Approvers Comments</td>''+        
 ''<td class=headerbold>QC decision</td>''+             
 ''<td class=headerbold>QC Reasons</td>''+       
 ''<td class=headerbold>Approval Decision</td>''+        
 ''<td class=headerbold>Approved Invoice Amount</td>''+         
 ''<td class=headerbold>Multi Payment</td>''+             
 ''<td class=headerbold>Queue Entry Date</td>''+            
 ''<td class=headerbold>Queue Exit Date</td>''+            
 ''<td class=headerbold>Aging</td>''             
 +''</tr></font>''           
         
 UNION ALL      
      
      
          
 Select ''<tr><td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Wi_ExitTime],''''),120)+''</td>''+             
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([UserName],'''')+''</td>''+            
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Current_Work_Step],'''')+''</td>''+            
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([WI_Name],'''')+''</td>''+          
 ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Registration_Date],''''),120)+''</td>''+       
''<td align=left style=mso-number-format:\\@>''+ISNULL([Priority],'''')+''</td>''+       
''<td align=left style=mso-number-format:\\@>''+ISNULL([Pay_Entity],'''')+''</td>''+        
''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Name],'''')+''</td>''+        
''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Number],'''')+''</td>''+       
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([ACH],'''')+''</td>''+            
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([AP_Check],'''')+''</td>''+            
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Invoice_Number],'''')+''</td>''+          
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Total_Invoice_Amount],'''')+''</td>''+        
 ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Invoice_Date],''''),120)+''</td>''+       
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Additional_Comments],'''')+''</td>''+            
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([QC_Decision],'''')+''</td>''+            
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Reason_For_Return_Check],'''')+''</td>''+        
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Approval_Decision],'''')+''</td>''+       
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Approved_Invoice_Amount],'''')+''</td>''+             
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Multi_Payment],'''')+''</td>''+             
             
 ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Wi_EntryTime],''''),120)+''</td>''+         
 ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Wi_ExitTime1],''''),120)+''</td>''+            
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Aging],'''')+''</td></tr>''          
 from #AP_TEMP_TABLE_Productivity'        
         
 print @Query        
 exec(@Query)         
          
         
 select @status_temp='<tr></tr></tr></table><html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style><table  
 
b    
      
order=1><tr><td class=headerbold><b>USER</b></td>'+'<td class=headerbold><b>QUEUE</b></td><td class=headerbold><b>Workitems Processed</b></td><td class=headerbold><b>Average Time(In Minutes)</b></td></tr>'            
         
 DECLARE APProductivitysummary_Cursor CURSOR FAST_FORWARD FOR         
 Select USERNAME,ACTIVITYNAME,WI_PROCESSED,AVG_TIME from APProductivitysummary             
 OPEN APProductivitysummary_Cursor            
 FETCH NEXT FROM APProductivitysummary_Cursor INTO  @USERNAMESUM,@ACTIVITYNAME,@WI_PROCESSED,@AVG_TIME         
 WHILE @@FETCH_STATUS = 0             
 Begin        
  select @status_temp=@status_temp+'<tr><td>'+convert(varchar(100),@USERNAMESUM)+'</td><td>'+convert(varchar(100),@ACTIVITYNAME)+'</td><td>'+convert(varchar(100),@WI_PROCESSED)+'</td><td>'+convert(varchar(100),@AVG_TIME)+'</td></tr>'         
  FETCH NEXT FROM APProductivitysummary_Cursor INTO @USERNAMESUM,@ACTIVITYNAME,@WI_PROCESSED,@AVG_TIME        
 End        
         
 close APProductivitysummary_Cursor            
 Deallocate APProductivitysummary_Cursor         
 select @status_temp=@status_temp+'</table>'            
 exec('insert into NG_TEMP_AUTOMAIL select '''+@status_temp+'''   ')        
        
 update NG_TEMP_AUTOMAIL set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yy>&nbsp</td>')          
        
 SET @Query='Master..xp_Cmdshell ''bcp "select Header FROM '+@DataBaseName+'..NG_TEMP_AUTOMAIL order by row_index asc" queryout "'+@FileName+'" -c -T'',no_output'         
         
 --select * from  NG_TEMP_AUTOMAIL             
 exec(@Query)        
          
 insert into NG_AutoMail_Status values('AP Productivity Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL)             
         
 drop table APProductivitysummary        
 drop table #AP_TEMP_TABLE_Productivity        
 drop table NG_TEMP_AUTOMAIL            
          
         
 End           
 select @RowCount          
         
 End 
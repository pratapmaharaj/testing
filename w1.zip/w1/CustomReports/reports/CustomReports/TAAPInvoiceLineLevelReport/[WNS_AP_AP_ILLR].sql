/*    
[WNS_AP_AP_ILLR] '','','','','','',  
'','','','','','asdasdadadadasdasdadad@asdsa.com',    
'malkeet','//10.33.192.139/XLS-File/kalsi',''    
    
*/    
    
CREATE procedure [dbo].[WNS_AP_AP_ILLR]    
(    
@Document_Category varchar(200),  
@Coder_code varchar(200),  
@Vendor_Name varchar(200),  
@Vendor_Number varchar(200),  
@Cost_centre varchar(200),  
@Account varchar(200),  
@Company_code varchar(200),  
@From_Date_Intro varchar(200),  
@To_Date_Intro varchar(200),  
@From_Date_Q varchar(200),  
@To_Date_Q  varchar(200),  
@Email_Id varchar(200),    
@FileName varchar(200),       
@Path varchar(50),    
@RowCount varchar(50) out                             
)      
as     
declare     
@WhereQuery varchar(2000),                            
@Query varchar(max),                                                         
@Tables varchar(200),                            
@OrderBy varchar(300),    
@sDocument_Category varchar(400),    
@sQC_Decision varchar(300)    
                            
begin    
Set nocount on       
 set @FileName=@Path+'/'+@Email_Id+'_'+@FileName+'_'+convert(varchar,getdate(),104)+'.xls'      
 --set @FileName='//10.33.192.139/XLS-File/ProcessManager/reports/Gmac report/AP/'+@Email_Id+'maklkeet'+convert(varchar,getdate(),104)+'.xls'                                                   
 set @WhereQuery=' WHERE a.wi_name=c.WI_No '      
 set @Tables=' WNS_TA_AP_EXT_Table a with(nolock),Tbl_TA_AP_CodingDetails_Master c with(nolock) '     
 set @OrderBy=' order by a.wi_name,Current_Work_Step'        
 set @sDocument_Category=''      
 set @sQC_Decision=''    
print @WhereQuery    
Create table #AP_ILLR_Temp    
(    
Queue_Name varchar(200),  
WI_Name varchar(200),  
Registration_Date varchar(200),  
Document_category varchar(200),  
Priority varchar(200),  
coder_code varchar(200),  
Payment_type varchar(200),  
Pay_entity varchar(200),  
Vendor_Name varchar(200),  
Vendor_ID varchar(200),  
Invoice_Number varchar(200),  
Invoice_Amount varchar(200),  
Invoice_Date varchar(200),  
Comments varchar(200),  
Approval_Decision varchar(200),  
Approved_Invoice_Amount varchar(200),  
Multi_Payment varchar(200),  
Cost_centre varchar(200),  
Account varchar(200),  
Company_Code varchar(200),  
UTA varchar(200),  
GL_description_1 varchar(200),  
GL_description_2 varchar(200),  
GL_description_3 varchar(200),  
Coder_comment varchar(200)   
)     
    
 if(rtrim(ltrim(@Document_Category))<>'All~' and rtrim(ltrim(@Document_Category))<>''  )      
  BEGIN      
    if(len(@Document_Category)=charindex('~',@Document_Category))      
     BEGIN                     
       set @sDocument_Category=ltrim(rtrim(substring(@Document_Category,0,len(@Document_Category))))      
       print @sDocument_Category      
       set @WhereQuery=@WhereQuery+' and Document_Category='''+@Document_Category+''''      
     End      
    else      
     BEGIN               
       while (charindex('~',@Document_Category)>1)      
      BEGIN      
      set @sDocument_Category = @sDocument_Category + ''''+ltrim(rtrim(SUBSTRING(@Document_Category,1,Charindex('~',@Document_Category)-1)))+''''+','      
      set @Document_Category=ltrim(rtrim(Substring(@Document_Category,Charindex('~',@Document_Category)+len('~'),len(@Document_Category))))      
      END                                 
      set @sDocument_Category=SUBSTRING(@sDocument_Category,0,len(@sDocument_Category))       
      set @WhereQuery=@WhereQuery+' and Document_Category in('+@sDocument_Category+')'         
    END      
 End    
  
  
if(rtrim(ltrim(@From_Date_Intro))<>'')      
  SET @From_Date_Intro = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@From_Date_Intro,121)))))                             
      
 if(rtrim(ltrim(@To_Date_Intro))<>'')      
  SET @To_Date_Intro = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@To_Date_Intro,121)))))                        
if(rtrim(ltrim(@From_Date_Q))<>'')      
  SET @From_Date_Q = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@From_Date_Q,121)))))                             
      
 if(rtrim(ltrim(@To_Date_Q))<>'')      
  SET @To_Date_Q = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@To_Date_Q,121)))))                        
  
 if(rtrim(ltrim(@From_Date_Intro)) != '' and rtrim(ltrim(@To_Date_Intro)) != '')                   
 BEGIN      
  set @WhereQuery = @WhereQuery+' and Registration_Date BETWEEN '''+@From_Date_Intro+''' AND '''+@To_Date_Intro+''''      
 END      
if(rtrim(ltrim(@From_Date_Q)) != '' and rtrim(ltrim(@To_Date_Q)) != '')                   
 BEGIN      
  set @WhereQuery = @WhereQuery+' and Entry_Time BETWEEN '''+@From_Date_Q+''' AND '''+@To_Date_Q+''''      
 END      
if(rtrim(ltrim(@Vendor_Number))<>'')    
Begin    
set @WhereQuery = @WhereQuery+' and Vendor_Number='''+@Vendor_Number+''''    
End    
    
if(rtrim(ltrim(@Vendor_Name))<>'')    
Begin    
set @WhereQuery = @WhereQuery+' and Vendor_Name='''+@Vendor_Name+''''    
End   
   
if(rtrim(ltrim(@Coder_code))<>'')    
Begin    
set @WhereQuery = @WhereQuery+' and Coder_Code='''+@Coder_code+''''    
End    
  
if(rtrim(ltrim(@Cost_centre))<>'')    
Begin    
set @WhereQuery = @WhereQuery+' and c.Expense_Cost_Center='''+@Cost_centre+''''    
End    
if(rtrim(ltrim(@Account))<>'')    
Begin    
set @WhereQuery = @WhereQuery+' and c.Expense_Account='''+@Account+''''    
End    
  
if(rtrim(ltrim(@Company_code))<>'')    
Begin    
set @WhereQuery = @WhereQuery+' and c.Expense_Company_Code='''+@Company_code+''''    
End    
  
print @WhereQuery    
end    
set @Query=''    
set @Query='insert into #AP_ILLR_Temp select distinct   
Current_Work_Step,  
a.WI_Name,  
Registration_Date,  
Document_Category,  
Priority,  
Coder_Code,  
Payment_Type,  
Pay_Entity,  
Vendor_Name,  
Vendor_Number,  
Invoice_Number,  
Total_Invoice_Amount,  
Invoice_Date,  
invoice_comment,  
Approval_Decision,  
Approved_Invoice_Amount,  
Multi_Payment,  
c.Expense_Cost_Center,  
c.Expense_Account,  
c.Expense_Company_Code,  
c.UTA,  
c.GL_Description1,  
c.GL_Description2,  
c.GL_Description3,  
Coders_Comment from '+@Tables+ @WhereQuery+@OrderBy    
    
print @Query    
    
exec (@Query)    
    
select * from #AP_ILLR_Temp    
select @RowCount=count(*) from #AP_ILLR_Temp                          
 if(@RowCount=0)                            
  Begin                            
  drop table #AP_ILLR_Temp                            
  End                                    
else                           
 Begin                                                    
                              
if Object_ID ('NG_TEMP_AUTOMAIL') is not null                               
          BEGIN                               
          exec('drop table NG_TEMP_AUTOMAIL')                               
          END     
Create table NG_TEMP_AUTOMAIL (Header varchar(8000),Row_Index int IDENTITY(1,1) PRIMARY KEY )    
    
--select * from  NG_TEMP_AUTOMAIL                          
Exec('Insert into NG_TEMP_AUTOMAIL                                   
                Select ''<html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>                           
   
<table border=1><tr><td class=headerbold>Queue Name</td>''+                                  
''<td class=headerbold>WI Name</td>''+  
''<td class=headerbold>Registration Date</td>''+  
''<td class=headerbold>Document category</td>''+  
''<td class=headerbold>Priority</td>''+  
''<td class=headerbold>Coder code</td>''+  
''<td class=headerbold>Payment type</td>''+  
''<td class=headerbold>Pay entity</td>''+  
''<td class=headerbold>Vendor Name</td>''+  
''<td class=headerbold>Vendor ID</td>''+  
''<td class=headerbold>Invoice Number</td>''+  
''<td class=headerbold>Invoice Amount</td>''+  
''<td class=headerbold>Invoice Date</td>''+  
''<td class=headerbold>Comments</td>''+  
''<td class=headerbold>Approval Decision</td>''+  
''<td class=headerbold>Approved Invoice Amount</td>''+  
''<td class=headerbold>Multi Payment</td>''+  
''<td class=headerbold>Cost centre</td>''+  
''<td class=headerbold>Account</td>''+  
''<td class=headerbold>Company Code</td>''+  
''<td class=headerbold>UTA</td>''+  
''<td class=headerbold>GL description_1</td>''+  
''<td class=headerbold>GL description_2</td>''+  
''<td class=headerbold>GL description_3</td>''+  
''<td class=headerbold>Coder_comment</td>''+  
''</tr></font>''                                   
UNION ALL           
Select ''<tr><td align=left style=mso-number-format:\\@>''+ISNULL([Queue_Name],'''')+''</td>''+                                   
''<td align=left style=mso-number-format:\\@>''+ISNULL([WI_Name],'''')+''</td>''+                          
''<td align=left style=mso-number-format:\\@>''+ISNULL([Registration_Date],'''')+''</td>''+                         
''<td align=left style=mso-number-format:\\@>''+ISNULL([Document_category],'''')+''</td>''+                          
''<td align=left style=mso-number-format:\\@>''+ISNULL([Priority],'''')+''</td>''+       
''<td align=left style=mso-number-format:\\@>''+ISNULL([coder_code],'''')+''</td>''+       
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Payment_type],'''')+''</td>''+       
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Pay_entity],'''')+''</td>''+      
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Name],'''')+''</td>''+    
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_ID],'''')+''</td>''+    
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Invoice_Number],'''')+''</td>''+    
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Invoice_Amount],'''')+''</td>''+    
 ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Invoice_Date],''''),120)+''</td>''+    
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Comments],'''')+''</td>''+    
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Approval_Decision],'''')+''</td>''+    
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Approved_Invoice_Amount],'''')+''</td>''+    
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Multi_Payment],'''')+''</td>''+    
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Cost_centre],'''')+''</td>''+    
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Account],'''')+''</td>''+    
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Company_Code],'''')+''</td>''+    
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([UTA],'''')+''</td>''+    
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([GL_description_1],'''')+''</td>''+    
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([GL_description_2],'''')+''</td>''+    
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([GL_description_3],'''')+''</td>''+    
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Coder_comment],'''')+''</td>''    
from #AP_ILLR_Temp')                           
       
       
   --select * from NG_TEMP_AUTOMAIL       
       
   print @FileName                 
update NG_TEMP_AUTOMAIL set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yy>&nbsp</td>')                            
SET @Query='Master..xp_Cmdshell ''bcp "select Header FROM GMAC..NG_TEMP_AUTOMAIL" queryout "'+@FileName+'" -c -T'',No_output'                                 
--print @Query                          
exec(@Query)                                
insert into NG_AutoMail_Status values('GMAC Invoice Line Level Report',''+@FileName+'',''+@Email_Id+'',0,getdate(),NULL)                             
                               
drop table #AP_ILLR_Temp                                
drop table NG_TEMP_AUTOMAIL                                        
                                   
 End                               
select @RowCount 
/*  
  WNS_TA_APVS_Approval_Status_Report 'ALL~','All~','All~','18','01/FEB/2014','20/FEB/2014','Current_Work_Step,a.WI_Name,Vendor_Request_Type,Vendor_type,Priority,Vendor_Name,Vendor_Number,Payment_Terms,Vendor_Status,Address_Line_1,Address_Line_2,City_Addre
ss_Line_3,State_Code,Postal_code,Approvers_Comments,Approval_Id,wi_exittime,Approval_Decision,Wi_EntryTime,Approval_Date,Registration_Date','fee@fgg.com','//10.33.192.139/XLS-File/Yogesh/ApproverStatus','VS_Approval_Status_Report',''  
  
SELECT Current_Work_Step,a.WI_Name,Vendor_Request_Type,Vendor_type,Priority,Vendor_Name,Vendor_Number,Payment_Terms,Vendor_Status,Address_Line_1,Address_Line_2,City_Address_Line_3,State_Code,Postal_code,Approvers_Comments,Approval_Id,wi_exittime,Approval_
Decision,Wi_EntryTime,Approval_Date,Registration_Date from WNS_TA_APVS_EXT_Table a with(nolock),WNS_TA_APVS_EntryExitTable B with(nolock) WHERE current_work_step ='VendorApproval' and Entry_Time BETWEEN 'Feb  1 2014 12:00AM' AND 'Feb 20 2014 11:59PM' orde
r by a.Wi_Name   
  
*/  
CREATE PROCEDURE WNS_TA_AP_Approval_Status_Report  
(  
@Queuename varchar(500),  
@DateRangeFrom   VARCHAR(500),  
@DateRangeTo varchar(200),  
@Approval_Decision        varchar(500),  
@Document_Category  VARCHAR(500),  
@Vname    VARCHAR(100),  
@Approver_Name Varchar(100),  
@Fields         varchar(4000),  
@EmailID        varchar(200),  
@FilePath       varchar(200),  
@FileName       varchar(200),  
@RowCount  varchar(500) OUTPUT  
)  
AS   
declare  
 @sQueuename varchar(400),  
 @sApproval_Decision varchar(400),  
 @sDocument_Category varchar(400),  
 @WhereQuery varchar(2000),  
 @Query varchar(5000),  
 @Tables varchar(200),  
 @BkpTable varchar(200),  
 @VendorReport varchar(200),   
 @EntryExitDetails varchar(8000),  
 @Disp_QName varchar(100),   
 @Count_Q varchar(100),  
 @status_temp varchar(8000),  
 @dbname varchar(60),  
 --@Queuename varchar (50),  
 @VendorReqTypeReport varchar(250),  
 @approverNameReport varchar(250),  
 @Aging varchar(100)  
  
BEGIN  
 Set nocount on   
 set @FileName=@FilePath+'/'+@EmailID+'_'+@FileName+'_'+convert(varchar,getdate(),104)+'.xls'              
 set @WhereQuery='WHERE a.wi_name=b.wi_name and '  
 set @Tables='WNS_TA_AP_EXT_Table a with(nolock),WNS_TA_AP_EntryExitTable B with(nolock)';      
 SET @VendorReport=''  
 set @sQueuename=''  
 set @sApproval_Decision=''  
 set @sDocument_Category=''  
 --SET @Queuename='VendorApproval'  
--print @VendorType  
  
 --if Object_ID('#TAVS_Approvalstatus_Report_Temp') is not null  
 --begin  
 --print 'Table dropped'  
 -- exec('drop table #TAVS_Approvalstatus_Report_Temp')  
 --end    
  
 Create Table #TAAP_Approvalstatus_Report_Temp   
 (   
   Current_Queue varchar(100),   
   WI_Name varchar(100),  
   Document_Category varchar(100),   
   Vendor_Name varchar(100),  
   Vendor_Id varchar(100),  
   ACH varchar(100),  
   Check1 varchar(100),  
   Invoice_Number varchar(100),  
   Invoice_Date varchar(100),  
   Invoice_Amount varchar(100),  
   Approval_Type varchar(100),   
   Approver_Name varchar(100),  
   Approval_Request_Date varchar(100),  
   Approval_Decision varchar(100),  
   Assign_2nd_Approver_To varchar(100),  
   Assign_2nd_Approver_date varchar(100),  
   Assigned_Date varchar(100),  
   Approved_Date varchar(100),  
   Introduction_Date varchar(100),  
   Overall_Aging varchar(100)  
 )   
--Approval_req_Date  
--Wi_EntryTime  
  
 --Vendor_Request_Type  
 if(rtrim(ltrim(@Queuename))<>'All~')  
 BEGIN  
  if(len(@Queuename)=charindex('~',@Queuename))  
  BEGIN                 
   set @sQueuename=ltrim(rtrim(substring(@Queuename,0,len(@Queuename))))  
   print @sQueuename  
   set @WhereQuery=@WhereQuery+' Vendor_Request_Type ='''+@Queuename+''''  
  End  
  else  
  BEGIN           
   while (charindex('~',@Queuename)>1)  
   BEGIN  
    set @sQueuename = @sQueuename + ''''+ltrim(rtrim(SUBSTRING(@Queuename,1,Charindex('~',@Queuename)-1)))+''''+','  
    set @Queuename=ltrim(rtrim(Substring(@Queuename,Charindex('~',@Queuename)+len('~'),len(@Queuename))))  
   END                             
   set @sQueuename=SUBSTRING(@sQueuename,0,len(@sQueuename))   
   set @WhereQuery=@WhereQuery+' Vendor_Request_Type in('+@sQueuename+')'     
  END  
  
  --PRINT @WhereQuery  
  SET @WhereQuery=@WhereQuery  
 END  
  
 --approverName  
 if(rtrim(ltrim(@Approval_Decision))<>'All~')  
 BEGIN  
  if(len(@Approval_Decision)=charindex('~',@Approval_Decision))  
  BEGIN                 
   set @sApproval_Decision=ltrim(rtrim(substring(@Approval_Decision,0,len(@Approval_Decision))))  
   print @sApproval_Decision  
   set @WhereQuery=@WhereQuery+' Approval_Id ='''+@sApproval_Decision+''''  
  End  
  else  
  BEGIN           
   while (charindex('~',@Approval_Decision)>1)  
   BEGIN  
    set @sApproval_Decision = @sApproval_Decision + ''''+ltrim(rtrim(SUBSTRING(@Approval_Decision,1,Charindex('~',@Approval_Decision)-1)))+''''+','  
    set @Approval_Decision=ltrim(rtrim(Substring(@Approval_Decision,Charindex('~',@Approval_Decision)+len('~'),len(@Approval_Decision))))  
   END                             
   set @sApproval_Decision=SUBSTRING(@sApproval_Decision,0,len(@sApproval_Decision))   
   set @WhereQuery=@WhereQuery+' Approval_Id in('+@sApproval_Decision+')'     
  END  
  
  --PRINT @WhereQuery  
  SET @WhereQuery=@WhereQuery  
 END  
  
 if(rtrim(ltrim(@Document_Category))<>'All~')  
 BEGIN  
  if(len(@Document_Category)=charindex('~',@Document_Category))  
  BEGIN                 
   set @sDocument_Category=ltrim(rtrim(substring(@Document_Category,0,len(@Document_Category))))  
   print @sDocument_Category  
   set @WhereQuery=@WhereQuery+' Vendor_Type ='''+@sDocument_Category+''''  
  End  
  else  
  BEGIN           
   while (charindex('~',@Document_Category)>1)  
   BEGIN  
    set @sDocument_Category = @sDocument_Category + ''''+ltrim(rtrim(SUBSTRING(@Document_Category,1,Charindex('~',@Document_Category)-1)))+''''+','  
    set @Document_Category=ltrim(rtrim(Substring(@Document_Category,Charindex('~',@Document_Category)+len('~'),len(@Document_Category))))  
   END                             
   set @sDocument_Category=SUBSTRING(@sDocument_Category,0,len(@sDocument_Category))   
   set @WhereQuery=@WhereQuery+' Vendor_Type in('+@sDocument_Category+')'     
  END  
  
  --PRINT @WhereQuery  
  SET @WhereQuery=@WhereQuery  
 END  
  
 BEGIN   
  --set @WhereQuery=@WhereQuery+' and  a.current_wrk_step = ''VendorApproval'''    
  --set @WhereQuery=@WhereQuery+'activityname='+''''+@Queuename+''''+' and current_work_step =' +''''+@Queuename+''''  
  print @WhereQuery  
 End  
  
 if(rtrim(ltrim(@DateRangeFrom))<>'')  
  SET @DateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@DateRangeFrom,121)))))                         
  
 if(rtrim(ltrim(@DateRangeTo))<>'')  
  SET @DateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@DateRangeTo,121)))))                    
  
 if(rtrim(ltrim(@DateRangeFrom)) != '' and rtrim(ltrim(@DateRangeTo)) != '')               
 BEGIN  
  set @WhereQuery = @WhereQuery+' and Entry_Time BETWEEN '''+@DateRangeFrom+''' AND '''+@DateRangeTo+''''  
 END  
  
 -- WI passed away from approver queue  
insert into #TAVS_Approvalstatus_Report_Temp(  
WI_Name ,Current_Work_Step ,  Vendor_Request_Type , Vendor_type, Priority , Vendor_Name ,  
   Vendor_Number , Payment_Terms, Vendor_Status , Address_Line_1 , Address_Line_2,  
   City_Address_Line_3 , State_Code, Postal_code , Approvers_Comments , Approval_Id,  
   Approval_Decision, Approval_Date , Registration_Date,Approval_req_Date,Wi_EntryTime)  
select distinct a.WI_Name ,Current_Work_Step  ,  Vendor_Request_Type , Vendor_type, Priority ,  
   Vendor_Name , Vendor_Number , Payment_Terms, Vendor_Status , Address_Line_1 ,  
   Address_Line_2, City_Address_Line_3 , State_Code, Postal_code ,  
   Approvers_Comments , Approval_Id, Approval_Decision, Approval_Date , Registration_Date,  
   b.Wi_EntryTime, b.Wi_EntryTime    
from WNS_TA_APVS_EXT_Table a with(nolock),WNS_TA_APVS_EntryExitTable b with(nolock) where a.wi_name in (select distinct wi_name from WNS_TA_APVS_EntryExitTable where activityname = 'VendorApproval')  
and a.wi_name = b.wi_name  
and activityname = 'VendorApproval'  
  
--select * from #TAVS_Approvalstatus_Report_Temp  
  
 Set @Query='insert into #TAVS_Approvalstatus_Report_Temp(Current_Work_Step, WI_Name , Vendor_Request_Type, Vendor_type , Priority , Vendor_Name , Vendor_Number , Payment_Terms , Vendor_Status , Address_Line_1 , Address_Line_2 , City_Address_Line_3 ,State
_Code , Postal_code , Approvers_Comments, Approval_Id , Approval_req_Date , Approval_Decision , Wi_EntryTime , Approval_Date , Registration_Date)'              
 SET @Query=@Query+' SELECT distinct '+@Fields+' from '+ @Tables + ' '+@WhereQuery + ' and Approval_Decision <>'''' and a.wi_name not in(select wi_name from #TAVS_Approvalstatus_Report_Temp) order by a.Wi_Name '         
       
 print (@Query)  
 exec(@Query)   
  
 exec('update #TAVS_Approvalstatus_Report_Temp set  
 Aging = cast((isnull(datediff(hh,wi_entrytime,convert(varchar,getdate(),121)),''0''))/24.0 as numeric(10,2))')  
  
  
 select @RowCount=count(*) from #TAVS_Approvalstatus_Report_Temp with(nolock) where Aging < @Aging           
  
 if(@RowCount=0)           
 Begin           
  drop table #TAVS_Approvalstatus_Report_Temp           
 End  
 else  
 begin   
  if Object_ID ('TAVS_TEMP_AUTOMAIL_Q') is not null      
  BEGIN      
   exec('drop table TAVS_TEMP_AUTOMAIL_Q')  
  END                
  
  Exec('Create table TAVS_TEMP_AUTOMAIL_Q (Header varchar(8000),ROw_Index int IDENTITY(1,1) PRIMARY KEY)')  
  
   set @Query='Insert into TAVS_TEMP_AUTOMAIL_Q   
   Select ''<html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>        
  
   <table border=1>  
   <tr align="left"><td colspan=22 class=headerbold>VENDOR SETUP APPROVAL STATUS REPORT</td></tr>  
   <tr align="left"><td colspan=22 class=headerbold> From : '+@DateRangeFrom+'</td></tr>  
   <tr align="left"><td colspan=22 class=headerbold> To : '+@DateRangeTo+'</td></tr>  
   </table>  <br>     
   <table border=1><tr><td class=headerbold>Current Queue</td>''+      
   ''<td class=headerbold>WI Name</td>''+  
   ''<td class=headerbold>Vendor Request Type</td>''+  
   ''<td class=headerbold>Vendor Type</td>''+  
   ''<td class=headerbold>Priority</td>''+  
   ''<td class=headerbold>Vendor Name</td>''+  
   ''<td class=headerbold>Vendor number</td>''+  
   ''<td class=headerbold>Payment Terms</td>''+  
   ''<td class=headerbold>Vendor Status</td>''+  
   ''<td class=headerbold>Address Line 1</td>''+  
   ''<td class=headerbold>Address Line 2</td>''+  
   ''<td class=headerbold>City Address Line 3</td>''+  
   ''<td class=headerbold>State Code</td>''+  
   ''<td class=headerbold>Postal code (Zip code)</td>''+  
   ''<td class=headerbold>Comments</td>''+  
   ''<td class=headerbold>Approver Name</td>''+  
   ''<td class=headerbold>Approval Request Date</td>''+  
   ''<td class=headerbold>Approval Decision</td>''+  
   ''<td class=headerbold>Assigned Date</td>''+  
   ''<td class=headerbold>Approved Date</td>''+  
   ''<td class=headerbold>Introduced Date</td>''+  
   ''<td class=headerbold>Aging</td>''+  
   ''</tr></font>''  
   UNION ALL      
  
   Select ''<tr><td align=left style=mso-number-format:\\@>''+ISNULL([Current_Work_Step],'''')+''</td>''+      
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Wi_Name],'''')+''</td>''+      
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Request_Type],'''')+''</td>'' +   
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_type],'''')+''</td>'' +   
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Priority],'''')+''</td>'' +  
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Name],'''')+''</td>'' +   
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Number],'''')+''</td>'' +   
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Payment_Terms],'''')+''</td>'' +   
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Status],'''')+''</td>'' +   
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Address_Line_1],'''')+''</td>'' +   
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Address_Line_2],'''')+''</td>'' +   
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([City_Address_Line_3],'''')+''</td>'' +   
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([State_Code],'''')+''</td>'' +   
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Postal_code],'''')+''</td>'' +   
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Approvers_Comments],'''')+''</td>'' +   
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Approval_Id],'''')+''</td>'' +   
   ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Approval_req_Date],''''),120)+''</td>''+  
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Approval_Decision],'''')+''</td>'' +   
   ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Wi_EntryTime],''''),120)+''</td>''+   
   ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Approval_Date],''''),120)+''</td>''+   
   ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Registration_Date],''''),120)+''</td>''+   
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Aging],'''')+''</td>''  
   from #TAVS_Approvalstatus_Report_Temp'  
  
  print @Query  
  Exec(@Query)      
  
  select @status_temp='</tr></table><table><tr><td>&nbsp</td><td>&nbsp</td></tr>'    
     
--print @status_temp  
  select @status_temp=@status_temp+'</table>'  
  exec('insert into TAVS_TEMP_AUTOMAIL_Q select '''+@status_temp+'''   ')    
  
  update TAVS_TEMP_AUTOMAIL_Q set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yy>&nbsp</td>')         
  
  select @dbname = DB_NAME()  
  SET @Query='Master..xp_Cmdshell ''bcp "select Header FROM '+@dbname+'..TAVS_TEMP_AUTOMAIL_Q order by row_index asc " queryout "'+@FileName+'" -c -T'', no_output  '    
  
  exec(@Query)  
  insert into NG_AutoMail_Status values('VS Approval Status Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL)   
   
  --drop table #TAVSQSummaryException   
  --drop table #TAVS_Approvalstatus_Report_Temp   
  drop table TAVS_TEMP_AUTOMAIL_Q   
  
 end  
 --select @RowCount  
End   
  


<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="java.lang.String.*"%>
<%@ page import="java.lang.Object"%>
<%@ page import="java.lang.Exception"%>

<HTML>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<HEAD>
<TITLE>AP Approval Status Report</TITLE>
</HEAD>

<FRAMESET ROWS="100%,0%" >
	<FRAME SRC="APApprovalStatus.jsp?ReportName=APPROVALSTATUSREPORT" NAME="frmHeader" frameborder=no noresize scrolling=Yes>
	<FRAME SRC="" NAME="APPROVALSTATUSREPORT" frameborder=no scrolling=no>
	
</FRAMESET>
</html>


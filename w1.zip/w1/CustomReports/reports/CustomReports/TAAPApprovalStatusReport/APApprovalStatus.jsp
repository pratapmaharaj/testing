
<%@ include file="customized.process" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="java.sql.*"%>

<HTML>
<HEAD>
<TITLE>AP Approval Status Report</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>
<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
	
}
</style>

<script>
	var allWindows = new Array();
	var win; // new window object

	$(document).ready(function(){
	$('#From_Date_Q').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date_Q').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	});
	function ValidateForm(emailID){
//	var emailID=document.frmSample.txtEmail
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }

	function echeck(str) 
	{

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;
	}
//---Added by Chetan
function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";

	sDate	= window.showModalDialog('/processmanager/reports/GMACReports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');

	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
}

function UnloadReportWindow()
{
	if(win!=null)
		win.close();
}

function openreport()
{	
	var Queue='';
	var Document_Category='';
	var bQueue=false;
	var Approval_decision = '' ;
	var bDocument_Category=false;
	
	var UserEmailID=document.getElementById('EMail-ID').value;//added by nilesh
	var DateRangeFrom="";
	var DateRangeTo="";

	
	DateRangeFrom=document.forms["textForm"].From_Date_Q.value;
	DateRangeTo=document.forms["textForm"].To_Date_Q.value;

	for(var i=0;i<document.forms["textForm"].Queue.length;i++)
	{
		if(document.forms["textForm"].Queue[i].selected)
		{
			Queue=Queue+document.forms["textForm"].Queue[i].value+'~';
			bQueue=true;
		}
	}


	for(var i=0;i<document.forms["textForm"].Document_Category.length;i++)
	{
		if(document.forms["textForm"].Document_Category[i].selected)
		{
			Document_Category=Document_Category+document.forms["textForm"].Document_Category[i].value+'~';
			bDocument_Category=true;
		}
	}

	var sApproval_decision= "" ;
	for(var i=0;i<document.forms["textForm"].Approval_decision.length;i++)
	{
		if(document.forms["textForm"].Approval_decision[i].selected)
		{
			sApproval_decision=sApproval_decision+document.forms["textForm"].Approval_decision[i].value+'~';
		}
	}

	var stestqueue=Queue.split('~');
	var stestdoccat=Document_Category.split('~');
	var stestappdec= sApproval_decision.split('~') ;
	
	
	//alert(Queue+''+Document_Category+''+sApproval_decision)
	


	if(Queue.indexOf("All")!=-1 && stestqueue.length>2)
	{
		alert("No other Queue can be chosen after choosing All");
		return false;
		//VendorType='All~';
	} 
//alert(sApproverName+"  "+aApprover_Name.length) ;
	if(Document_Category.indexOf("All")!=-1 && stestdoccat.length>2)
	{
		alert("No other Document Category can be chosen after choosing All");
		return false;
		//VendorType='All~';
	} 

	if(sApproval_decision.indexOf("All")!=-1 && stestappdec.length>2)
	{
		alert("No other Approval Decision can be chosen after choosing All");
		return false;
		//VendorRequestType='All~';
	} 
	
	var vname='';
	var approver_name='';
	vname==document.getElementById('Vendor_Name').value;
	approver_name==document.getElementById('Approver_Name').value;

	if(Queue==''){
	alert('Please Select Queue Name');
	return false;
	}
	
	if (DateRangeFrom=='') 
	{
	alert("Enter the from Date Range.");
	return false;
	}

	if ((DateRangeFrom=='' && DateRangeTo!='') || (DateRangeFrom!='' && DateRangeTo==''))
	{
		alert("Enter the complete Date Range.");
		return false;
	}

	if(!DateComparator(DateRangeTo,DateRangeFrom))
	{
		return false;
	}
	
	
	/*if(sApproval_decision==''){
	alert('Please Select Approval decision');
	return false;
	}
	
	if(Document_Category==''){
	alert('please Select Document Category');
	return false;
	}*/

	/*if(vname==''){
	alert('please Select Vendor name');
	return false;
	}
	if(approver_name==''){
	alert('please Select Approver Name');
	return false;
	}*/
	if(UserEmailID=='')
	{
		alert("Please enter a valid E-Mail ID");
		return false;
	}
	else
	{
		if(!ValidateForm(document.getElementById('EMail-ID')))
		{
			UserEmailID='';
			return false ;
		}
	}
	
		if(Queue=='Introduction~Processing~Approval~ApprovalException~Cancel~CheckList~Coding~GEACINTERFACE~JournalEntry~PendingResolution~PendingPayment~PolicyHolderPayment~QC~Rescan~Split~')
		{
			Queue='All~';
		}
		if(sApproval_decision=='Approved~Reject to Coder~Reject to WNS~')
		{
			sApproval_decision='All~';
		}
		
		if(Document_Category=='PO Invoices~Non PO Invoices~Policy Holder Payments~Escheatment~Credit Memo~Statement~Others~')
		{
			Document_Category='All~';
		}
		
			//OpenRedict-Fix
	////alert("VSApprovalStatusGenerate.jsp?&VendorRequestType="+VendorRequestType+"&VendorType="+VendorType+"&ApproverName="+sApproverName+"&Aging="+Aging+"&ReportName=<%=request.getParameter("ReportName")%>&FromDate="+DateRangeFrom+"&ToDate="+DateRangeTo+"&UserEmailID="+UserEmailID) ;
		//window.top.APPROVALSTATUSREPORT.location.href="APApprovalStatusGenerate.jsp?&Queue="+Queue+"&DateRangeFrom="+DateRangeFrom+"&DateRangeTo="+DateRangeTo+"&sApproval_decision="+sApproval_decision+"&Document_Category="+Document_Category+"&vname="+vname+"&approver_name="+approver_name+"&ReportName=<%=request.getParameter("ReportName")%>&UserEmailID="+UserEmailID;
		
		var URI = "APApprovalStatusGenerate.jsp?&Queue="+Queue+"&DateRangeFrom="+DateRangeFrom+"&DateRangeTo="+DateRangeTo+"&sApproval_decision="+sApproval_decision+"&Document_Category="+Document_Category+"&vname="+vname+"&approver_name="+approver_name+"&ReportName=<%=request.getParameter("ReportName")%>&UserEmailID="+UserEmailID;
		 var StrOpenWin=strip_tags(URI,"");
		 window.top.APPROVALSTATUSREPORT.location.href=StrOpenWin;
	
	}


function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	strResult=strdate+"/"+strMonth+"/"+stryear;
	return strResult;
}

function convertMonth(strMonth)
{
		if(strMonth=="JAN")
			strMonth="00";
		else if(strMonth=="FEB")
			strMonth="01";
		else if(strMonth=="MAR")
			strMonth="02";
		else if(strMonth=="APR")
			strMonth="03";
		else if(strMonth=="MAY")
			strMonth="04";
		else if(strMonth=="JUN")
			strMonth="05";
		else if(strMonth=="JUL")
			strMonth="06";
		else if(strMonth=="AUG")
			strMonth="07";
		else if(strMonth=="SEP")
			strMonth="08";
		else if(strMonth=="OCT")
			strMonth="09";
		else if(strMonth=="NOV")
			strMonth="10";
		else if(strMonth=="DEC")
			strMonth="11";
	return strMonth;
}

function DateComparator(Date_To,Date_From)
	{	
			if (Date_From == "" && Date_To == "")
			{
				return true;
			}

			var FromDay = Date_From.split("/")[0];
			var FromMonth = convertMonth(Date_From.split("/")[1]);
			var FromYear = Date_From.split("/")[2];
			
			//alert("From:::Day::"+FromDay+"  Month::"+FromMonth+"	Year::"+FromYear);
			
			var ToDay = Date_To.split("/")[0];
			var ToMonth = convertMonth(Date_To.split("/")[1]);
			var ToYear = Date_To.split("/")[2];
			
			//alert("To:::Day::"+ToDay+"  Month::"+ToMonth+"	Year::"+ToYear);
			
			var CurrentDate=new Date();
			var CurrentDay = CurrentDate.getDate();
			var CurrentMonth = CurrentDate.getMonth();
			//var CurrentYear = CurrentDate.getFullYear();
			var CurrentYear = CurrentDate.getFullYear();
			//alert("Current:::Day::"+CurrentDay+"  Month::"+CurrentMonth+"	Year::"+CurrentYear);

			var toDate = (new Date(ToYear,ToMonth,ToDay)).getTime();
			var fromDate = (new Date(FromYear,FromMonth,FromDay)).getTime();
			var CurrentDate = (new Date(CurrentYear,CurrentMonth,CurrentDay)).getTime();
			
			//alert("FromDate::"+fromDate+"  ToDate::"+toDate+"	Current::"+CurrentDate);

			//alert("Fr : "+new Date(fromDate)+"\nTo : "+new Date(toDate)+"\nCu : "+new Date(CurrentDate));
			if(fromDate > toDate)
			{
				alert("To Date cannot be less than From Date.");
				return false;
			}
			else if(fromDate > CurrentDate)
			{
				alert("From Date cannot be future date.");
				return false;
			}
			else if(toDate > CurrentDate)
			{
				alert("To Date cannot be future date.");
				return false;
			}
			//alert("BAzooka111111!!!");
			var toDate = new Date(ToMonth+"/"+ToDay+"/"+ToYear);
	var fromDate = new Date(FromMonth+"/"+FromDay+"/"+FromYear);
	var oneDay=1000*60*60*24;

	var dateDiff=Math.ceil((toDate.getTime()-fromDate.getTime())/oneDay);
	/*if(dateDiff>90)
	{
		alert('Date Range can not be greater than 90 days.');
		return false;
	}*/
			return true;
	
	}
//--------------------------------------------

</script>
</title>
<body topmargin="0" leftmargin="5"onunload="UnloadReportWindow();">

			<form name='textForm' method=post id="#FromId">


			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">TA AP APPROVAL STATUS REPORT</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This report will provide information on workitems for which approval is pending by Transamerica approvers. 
</td></tr><tr><td class="EWLabel1"> 
Select All as the Vendor Type if the report has to be generated for the entire spectrum of the avalilable Vendor Type, else select the specific Vendor Type, multiple selections are acceptable.<br>
Select All as the Vendor Request Type if the report has to be generated for the entire spectrum of the avalilable Vendor Request Type, else select the specific Vendor Request Type, multiple selections are acceptable.<br>
Select Approver Name if you want to generate report for workitems assigned to specific Approvers.<br>
Select Aging. Select Introdcution in Approver Portal date range.<br>
<b>Either Aging or Approval Portal Introduction Date Range is mandatory.</b> 
</td></tr>

				<td>
		<br/>
					<p style="color: red; font-size: 10pt">Note:  * fields are mandatory.</p>

				</td>
</table>
<table border="0" width="95%" cellspacing="1" align="center">


			<tr>
					<td class="EWLabel1" align="left" width='20%'><b>Queue<font color="RED">*</font></b></font></td>
					<td width='25%' colspan=3>
					<select style='width:45%' name="Queue" multiple>
					<option value="All">All</option>
					<option value="Introduction">Introduction</option>
					<option value="Processing">Processing</option>
					<option value="PolicyHolderPayment">PolicyHolderPayment</option>
					<option value="PendingResolution">Pending Resolution</option>
					<option value="Rescan">Rescan</option>
					<option value="Split">Split</option>
					<option value="Cancel">Cancel</option>
					<option value="QC">QC</option>
					<option value="Coding">Coding</option>
					<option value="Approval">Approval</option>
					<option value="ApprovalException">ApprovalException</option>
					<option value="GEACINTERFACE">GEAC Interface</option>
					<option value="JournalEntry">JournalEntry</option>
					<option value="PendingPayment">PendingPayment</option>
				
					</select>
					</td>
				</tr>
				<tr>&nbsp;</tr>
				 <tr>
					<td>
					<p class="EWLabel122" >&nbsp;Queue Entry Date<font color="RED">*</font></p></td>
					</tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date_Q" readonly type="text"  id="From_Date_Q" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date_Q" readonly type="text"  id="To_Date_Q" >
					
					</td>

				</tr>
				<tr>&nbsp;</tr>
					<tr>
					<td class="EWLabel1" align="left" width='20%'><b>Approval Decision 
					<td width='25%' COLSPAN=3>
					<select style='width:45%' class='TextFieldColor'  name="Approval_decision" multiple>
						<option value="All">All</option>
						<option value="Approved">Approved</option>
						<option value="Reject to Coder">Reject to WNS</option>
						<option value="Reject to WNS">Reject to Coder</option>
						
					</select>

					</td>

				</tr>
				<tr>&nbsp;</tr>
				 <tr>
					<td class="EWLabel1" align="left" width='30%'><b>Document Category</b></font></td>
					<td width='25%' colspan=3>
					<select style='width:45%' name="Document_Category" multiple>
					<option value="All">All</option>
					<option value="PO Invoices">PO Invoices</option>
					<option value="Non PO Invoices">Non PO Invoices</option>
					<option value="Policy Holder Payments">PH Payments</option>
					<option value="Escheatment">Escheatment</option>
					<option value="Credit Memo">Credit Memo</option>
					<option value="Statement">Statement</option>
					<option value="Others">Others</option>
					
				
					</select>
					</td>
				</tr>
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Vendor Name</b></td>
					<td >
					<input type='text' name='Vendor_Name' style='width:145' id='Vendor_Name'>
					</td>
				</tr>
				
				<tr>&nbsp;</tr>
					<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Approver Name</b></td>
					<td >
					<input type='text' name='Approver_Name' style='width:145' id='Approver_Name'>
					</td>
				</tr>
				
				<tr>&nbsp;</tr>

				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID<font color="RED">*</font></b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>


				
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>
	
			
			</form>
</body>
</Html>	 




<!-- 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date			Change By		Change Description (Bug No. (If Any))
(DD/MM/YYYY)

----------------------------------------------------------------------------------------------------
 -->
<%@ include file="customized.process" %> 
<%@ page import="java.io.*" %>
<%@ page import="java.util.*" %>
<%@ page import="javax.servlet.*"%>
<%@ page import="java.text.DateFormat"%>
<%@ page import="java.text.SimpleDateFormat"%>
<%@ page import="javax.servlet.http.*"%>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>
<%@ page import="java.text.*"%>
<%@ page import="java.sql.DriverManager,java.sql.Connection,java.sql.Statement,java.sql.PreparedStatement,java.sql.CallableStatement,java.sql.ResultSet,java.sql.SQLException"%>

<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>

<HTML>
<HEAD>
<TITLE>TA Common Account Lockedout Report</TITLE>
</HEAD>
<link href="/processmanager/omniflow/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>


<body >

<%

	WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","--------------TA Common Users Account Lockedout Report Generate started---------------");	
	
	String sProcedureName     ="";
	String sReportName        ="";
	String sFileName          ="";
	String sNumberOfColumns   ="";
	String sProcedureNameKey  ="";
	String sFileNameKey       ="";
	String sDBMappedCols      ="";
	String sFieldValuesKey    ="";
	String sFieldValues       ="";
	String sUserMailID        ="";
	String sFromDate          =null;
	String sToDate            =null;
	String sFilePath          = "" ;

    sFromDate = request.getParameter("FromDate");
	sToDate = request.getParameter("ToDate");
	String UserNames=request.getParameter("UserNames");
	sReportName	  =request.getParameter("ReportName");
	sUserMailID   =request.getParameter("UserEmailID");
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TACommonLockedoutReport.ini";
	WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","sRootPathini="+sRootPathini+",sReportName="+sReportName);								
	
	Properties ini = new Properties();
	
	//Unreleased dataresource release fix
	FileInputStream fis = null;
		try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","DBReports.ini file");
						}
					}
				}
	//ini.load(new FileInputStream(sRootPathini));
	sProcedureName=sReportName+"_PROCEDURENAME";
	sFilePath = sReportName+"_FILEPATH";
    sFileNameKey        =sReportName+"_FILENAME";
	sFilePath = ini.getProperty(sFilePath) ;
    sFileName        =ini.getProperty(sFileNameKey);
	sProcedureName = ini.getProperty(sProcedureName) ;
		
	String sCabname             = null;
	String sSessionId           = null;
	String sJtsIp               = null;
	String sUserName            = null;
	String sReportProcedureName =null;
	String sReportTableName=null;

	WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","sFilePath="+sFilePath);	
	
	Date CurrDate     =new Date();
	DateFormat dt     = new SimpleDateFormat("dd-MMM-yyyy");
	String sCurrdate  =dt.format(CurrDate);

	String sOutputXML   ="";
	String sInputXML    ="";
	String maincode     ="";
	String Totalrec     ="0";
	String sStr_ServerType = null;
	String url = "";
	String Status="";
	double fPercentage=0;
	String sRowXml="";
	
	int iJtsPort = 0;
	
	

	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","sRootPathDBini="+sRootPathDBini);

//Unreleased dataresource release fix
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","Unable to DBReports.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","DBReports.ini file");
						}
					}
				}	
	//ini.load(new FileInputStream(sRootPathDBini));
	
	String conString = null;
	String driverName = null;
	driverName=ini.getProperty("DRIVERNAME");
	conString=ini.getProperty("CONNECTIONSTRING");
	WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","driverName="+driverName+",conString="+conString);								
	
	boolean bError=false;
	System.out.println(sProcedureName);
	System.out.println("Params "+sFromDate+" "+sToDate+" "+UserNames+" "+sUserMailID+" "+sFilePath);
	Connection conn=null;
	CallableStatement cs=null;
	ResultSet resultset=null;
	try
	{
		Class.forName(driverName);	
		conn = DriverManager.getConnection(conString);
		
		cs = conn.prepareCall("{?=call "+sProcedureName+"(?,?,?,?,?)}"); 
		WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","sProcedureName="+sProcedureName);	
		
		WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","cs.toString()="+cs.toString());	
		cs.registerOutParameter(1, java.sql.Types.VARCHAR);
		
		cs.setString(2,sFromDate);
		cs.setString(3,sToDate);
		cs.setString(4,UserNames);		
		cs.setString(5,sUserMailID);
		cs.setString(6,sFilePath);
		
		WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","variables="+sFromDate+","+sToDate+","+UserNames+","+sUserMailID+",sFilePath="+sFilePath);	
		
		
		resultset = cs.executeQuery();
		WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","resultset="+resultset);
			
		
		while( resultset.next() )
		{
              WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","output="+resultset.getString( 1 ));	
			  sOutputXML = resultset.getString(1);
			  System.out.println("resultset="+sOutputXML);	
        }
		

	}
	catch(SQLException ignore)
	{	
		
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp->161->"+ignore.toString()+"</b></font>");
		bError= true;
	
	}
	finally {
    
    if (resultset != null) {
        try {
            resultset.close();
        } catch (SQLException e) { }
    }
	if (cs != null) {
        try {
            cs.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
}
	
	
	if(!bError)
	{
		try
		{
		   if(sOutputXML.equals("NO REC"))
		   {
			WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","no record ");
			bError= true;
			
			%>
			<script>alert("No Records found for the Current Request Criteria.");</script>
			<%
		   }
			else if(sOutputXML.equals("SUCCESS"))
			{
				WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","found record");

				%>
				<script>alert("The Report will be delivered to your mailbox shortly");</script>
				<%

			}
			else 
			{
				WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","Technical error");

				%>
				<script>alert("Internal Server error. Please logout and try again.\nIf problem persists then contact to the support team.");</script>
				<%

			}

		}
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
		}

		
	}
	else
	{
	%>
			<script>alert("Internal Server Error.");</script>
	<%
	}
%>	

<FORM name="textForm">
</form>	

</body>

</html>
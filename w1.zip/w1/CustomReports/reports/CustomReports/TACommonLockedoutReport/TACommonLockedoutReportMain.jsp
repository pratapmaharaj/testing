<!-- 
----------------------------------------------------------------------------------------------------
Group : Application �Projects
Product / Project : Omniflow/WNS-TCI
Module : Common report
File Name : TAcommonLockedoutReportMain.jsp
Author :  
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date			Change By		Change Description (Bug No. (If Any))
(DD/MM/YYYY)
13-06-2018		Mehul			Created report for Account Lockedout in omniflow
----------------------------------------------------------------------------------------------------
 -->
<HTML>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<HEAD>
<TITLE>Account Lockedout Report</TITLE>
</HEAD>

<FRAMESET ROWS="100%,0%" >
<FRAME SRC="TACommonLockedoutReport.jsp" NAME="frmHeader" frameborder=no noresize scrolling=Yes>
	<FRAME SRC="" NAME="TACommonLockedoutReport" frameborder=no scrolling=no>
	
</FRAMESET>
</html>


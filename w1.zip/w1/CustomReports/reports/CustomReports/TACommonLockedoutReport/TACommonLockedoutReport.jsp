<!-- 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date Change By Change Description (Bug No. (If Any))
(DD/MM/YYYY)

----------------------------------------------------------------------------------------------------
 -->

<%@ include file="customized.process" %> 
<%@ page import="java.io.*" %>
<%@ page import="java.util.*" %>
<%@ page import="javax.servlet.*"%>
<%@ page import="java.text.DateFormat"%>
<%@ page import="java.text.SimpleDateFormat"%>
<%@ page import="javax.servlet.http.*"%>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>
<%@ page import="java.text.*"%>
<%@ page import="java.sql.DriverManager,java.sql.Connection,java.sql.Statement,java.sql.PreparedStatement,java.sql.CallableStatement,java.sql.ResultSet,java.sql.SQLException"%>




<HTML>
<HEAD>
<TITLE>TA ES Productivity Report</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>
</HEAD>

<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="/processmanager/omniflow/scripts/Common.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>
<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
}
</style>

 <%	
	
	String sUserName="";
	String Query="";
	
	try
	{
		
		
		WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","--------------TA Common Users AccountLockedout Report started---------------");
		Properties ini = new Properties();
		
		Query="select username,* from pdbuser order by 1";
		
		WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","Query="+Query);
		
		String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
		WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","sRootPathDBini="+sRootPathDBini);
		//Unreleased dataresource release fix
	FileInputStream fis = null;
		try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","Unable to close the TACMApprovalStatusReport.ini file");
						}
					}
				}
		//ini.load(new FileInputStream(sRootPathDBini));
		String conString = null;
		String driverName = null;
		driverName=ini.getProperty("DRIVERNAME");
		conString=ini.getProperty("CONNECTIONSTRING");
		WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","driverName="+driverName+",conString="+conString);								
	
		boolean bError=false;
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try
		{
			Class.forName(driverName);	
			conn = DriverManager.getConnection(conString);
			stmt = conn.createStatement();
		    rs =  stmt.executeQuery(Query);
            while (rs.next()) 
			{
				sUserName = sUserName+rs.getString("username").trim() + "~";
				WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","output="+sUserName);
			} 
				WriteLog("TACOMMONACCOUNTLOCKEDOUT_REPORT","Final Output="+sUserName);	
		}
		catch(SQLException ignore)
		{	

			bError= true;
		}
	finally {
    
		if (rs != null) {
        try {
            rs.close();
        } catch (SQLException e) { }
		}
		if (stmt != null) {
        try {
            stmt.close();
        } catch (SQLException e) { }
		}
		if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
		}
	}		
	

	}
	catch(Exception e)
	{
		out.println("Exception:" + e.toString());
	}
%>


<script>
	var FromDate = new Date();
	var type = '';
	var allWindows = new Array();
	var win;
	
	$(document).ready(function(){$('#From_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	
	});
	function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}

function ValidateForm(emailID){
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }

function ChangeDateTag(obj)
{
	var InsertVal='';
	for(iterate=0;iterate<obj.length;iterate++)
	{
		if(obj.options[iterate].selected==true)
		{
			InsertVal=InsertVal+obj.options[iterate].value+'/';
		}
	}
	InsertVal=InsertVal.substring(0,InsertVal.length-1);
	var Table=document.getElementById('newgen');
	var lastRow = Table.rows.length;
	if (lastRow > 0) Table.deleteRow(lastRow - 1);
	while(InsertVal.indexOf('_')!=-1)
	{
		InsertVal=InsertVal.replace('_',' ');
	}
	var Row=Table.insertRow(0);
	var Cell=Row.insertCell();
	Cell.className="EWLabelBoldNew";
	Cell.innerHTML=InsertVal;
}

function DateComparator(Date_To,Date_From)
{	

			if (Date_From == "" && Date_To == "")
			{
				return true;
			}

			var FromDay = Date_From.split("/")[0];
			var FromMonth = convertMonth(Date_From.split("/")[1]);
			var FromYear = Date_From.split("/")[2];
			
			var ToDay = Date_To.split("/")[0];
			var ToMonth = convertMonth(Date_To.split("/")[1]);
			var ToYear = Date_To.split("/")[2];
			
			var CurrentDate=new Date();
			var CurrentDay = CurrentDate.getDate();
			var CurrentMonth = CurrentDate.getMonth();
			var CurrentYear = CurrentDate.getFullYear();
			
			var toDate = (new Date(ToYear,ToMonth,ToDay)).getTime();
			var fromDate = (new Date(FromYear,FromMonth,FromDay)).getTime();
			var CurrentDate = (new Date(CurrentYear,CurrentMonth,CurrentDay)).getTime();
			
			if(fromDate > toDate)
			{
				alert("To Date cannot be less than From Date.");
				return false;
			}
			else if(fromDate > CurrentDate)
			{
				alert("From Date cannot be future date.");
				return false;
			}
			else if(toDate > CurrentDate)
			{
				alert("To Date cannot be future date.");
				return false;
			}

			
			var toDateNew = new Date(ToMonth+"/"+ToDay+"/"+ToYear);
			var fromDateNew = new Date(FromMonth+"/"+FromDay+"/"+FromYear);
			var oneDay=1000*60*60*24;

			var dateDiff=Math.ceil((toDateNew.getTime()-fromDateNew.getTime())/oneDay);
			/*if(dateDiff>180)
			{
				alert('Please select report duration less than or equal to 6 months');
				return false;
			}*/
		
			return true;


}

function convertMonth(strMonth)
{
		if(strMonth=="JAN")
			strMonth="00";
		else if(strMonth=="FEB")
			strMonth="01";
		else if(strMonth=="MAR")
			strMonth="02";
		else if(strMonth=="APR")
			strMonth="03";
		else if(strMonth=="MAY")
			strMonth="04";
		else if(strMonth=="JUN")
			strMonth="05";
		else if(strMonth=="JUL")
			strMonth="06";
		else if(strMonth=="AUG")
			strMonth="07";
		else if(strMonth=="SEP")
			strMonth="08";
		else if(strMonth=="OCT")
			strMonth="09";
		else if(strMonth=="NOV")
			strMonth="10";
		else if(strMonth=="DEC")
			strMonth="11";
	return strMonth;
}

function FillGroupUserCombo()
{
	
	var UserNames='<%=sUserName%>';
	var UserNameArray=UserNames.split('~');
	
	for (var j=0;j<UserNameArray.length-1;j++)
	{
		optn=document.createElement("option");	
		req=document.getElementById("User");
		optn.text=UserNameArray[j];
		optn.value=UserNameArray[j];	
		req.options.add(optn);	
	}

}

function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";
	sDate	= window.showModalDialog('/processmanager/reports/GMACReports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');
	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
	

}

function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	strResult=strdate+"/"+strMonth+"/"+stryear;
	return strResult;
}

	function openreport()
	{	
		
		
		var DateRangeFrom="";
		var DateRangeTo="";
		var UserNameForm="";
		var FinalUserNames="";
		var UserEmailID="";
		
		
		UserEmailID=document.getElementById('EMail-ID').value;
		
		DateRangeFrom=document.forms["textForm"].From_Date.value;
		DateRangeTo=document.forms["textForm"].To_Date.value;

		for(var l=0;l<document.forms["textForm"].User.length;l++)
		{
			if(document.forms["textForm"].User[l].selected)
			{
				
				UserNameForm=UserNameForm+document.forms["textForm"].User[l].value+'~';
				
			}
		}

		if(UserNameForm=="~")
		{
			UserNameForm="All~";
		}

		var sUsers=UserNameForm.split('~');

		
		if(DateRangeFrom=='')
		{
			alert("Please select an appropriate From Date");
			return false;
		}
		if(DateRangeTo=='')
		{
			alert("Please select an appropriate To Date");
			return false;
		}

		if ((DateRangeFrom=="" && DateRangeTo!="") || (DateRangeFrom!="" && DateRangeTo==""))
		{
			alert("Enter the complete Date Range.");
			return false;
		}
		if(!DateComparator(DateRangeTo,DateRangeFrom))
		{
		return false;
		}
		
		if(sUsers=="")
		{
			alert("Kindly Select the Users");
			return false;
			
		}
		
		if(sUsers!="")
		{
				FinalUserNames=UserNameForm;
		}
		
		if(UserEmailID=='')
		{
			alert("Kindly enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
			}
		}
			
			if(UserEmailID!='')
			{
				
				//OpenRedict-Fix
    //window.top.TACommonLockedoutReport.location.href="TACommonLockedoutReportGenerate.jsp?ReportName=TACommonLockedoutReport&FromDate="+DateRangeFrom+"&ToDate="+DateRangeTo+"&UserEmailID="+UserEmailID+"&UserNames="+FinalUserNames;
	var URI = "TACommonLockedoutReportGenerate.jsp?ReportName=TACommonLockedoutReport&FromDate="+DateRangeFrom+"&ToDate="+DateRangeTo+"&UserEmailID="+UserEmailID+"&UserNames="+FinalUserNames;
	var StrOpenWin=strip_tags(URI,"");
	window.top.TACommonLockedoutReport.location.href=StrOpenWin;
			}
			
}
	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}

</script>

<body topmargin="0" leftmargin="5" onload="FillGroupUserCombo();" onunload="UnloadReportWindow();">

			<form name='textForm' method=post>


			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">Account Lockedout REPORT</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This report will provide automatically capture whenever the user account locked out of Omniflow due to exceeding the maximum number of sequential attempts, so that the report generated provides stats for the selected users.
</td></tr><tr><td class="EWLabel1">Select All Users if report is to be generated for viewing the Users Lockedout present, else select the specific User, multiple selections are again acceptable.
</td></tr><tr>
				</tr><tr><td class="EWLabel1">Select the date account lockout occurred range for generating the report for the same.</td>
				</tr>
			</table>

			

			<table border="0" width="95%" cellspacing="1" align="center">

				 
				 <tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>Date Range &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date" readonly type="text"  id="From_Date" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date" readonly type="text"  id="To_Date" >
					
					</td>

				</tr>
				
				<tr>
					<td class="EWLabel1" align="left" width='20%'><b>User 
					<td width='25%' COLSPAN=3>
						<!--id given by megha-->
						<select STYLE='width:50%' class='TextFieldColor' id="User" name="User" multiple onchange="DisableOtherCombo('G')">
						<option value="">--All Users--</option>			

						</select>
					
					</td>

				</tr>

			<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID*</b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>

				
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>
	
			
			</form>
</body>
</Html>	 




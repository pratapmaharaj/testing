

<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>

<%@ include file="customized.process" %>


<HTML>
<HEAD>
<TITLE>ES Life Cycle Report</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>

<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
}
</style>
<script>
	$(document).ready(function(){$('#From_Date_Reg').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date_Reg').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", 
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#From_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", 
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", 
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#From_Date_pay').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", 
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date_pay').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", 
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	});
	var FromDate = new Date();
	var type = '';
	var allWindows = new Array();
	var win; // new window object
/*functions echeck,ValidateForm*/
 
 	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}
	
	function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}

function ValidateForm(emailID){
//	var emailID=document.frmSample.txtEmail
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }


 function ChangeDateTag(obj)
{
	var InsertVal='';
	for(iterate=0;iterate<obj.length;iterate++)
	{
		if(obj.options[iterate].selected==true)
		{
			InsertVal=InsertVal+obj.options[iterate].value+'/';
		}
	}
	InsertVal=InsertVal.substring(0,InsertVal.length-1);
	var Table=document.getElementById('newgen');
	var lastRow = Table.rows.length;
	if (lastRow > 0) Table.deleteRow(lastRow - 1);
	while(InsertVal.indexOf('_')!=-1)
	{
		InsertVal=InsertVal.replace('_',' ');
	}
	var Row=Table.insertRow(0);
	var Cell=Row.insertCell();
	Cell.className="EWLabelBoldNew";
	Cell.innerHTML=InsertVal;
}
function compToday(Date_To)
{
	var todaysDate = new Date(); 
	var dd = todaysDate.getDate() ;
	var mm = todaysDate.getMonth()+1 ;
	var yy = todaysDate.getFullYear() ;

	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));

	var Date_To_date=Number(Date_To.substring(0,Date_To.indexOf("/")));	

	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));

	if(Date_To_month=="JAN")
			Date_To_month="1";
		else if(Date_To_month=="FEB")
			Date_To_month="2";
		else if(Date_To_month=="MAR")
			Date_To_month="3";
		else if(Date_To_month=="APR")
			Date_To_month="4";
		else if(Date_To_month=="MAY")
			Date_To_month="5";
		else if(Date_To_month=="JUN")
			Date_To_month="6";
		else if(Date_To_month=="JUL")
			Date_To_month="7";
		else if(Date_To_month=="AUG")
			Date_To_month="8";
		else if(Date_To_month=="SEP")
			Date_To_month="9";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";

	if(Date_To_year>yy)
	{
		return false;
	}
	else if(Date_To_year<yy)
	{
		//if(Date_From_month>Date_To_month)
		//{
		//alert("To Date can not be less than From Date.");
		//return false;
		//}
		 if(mm==Date_To_month)
		{
			if(Date_To_date>dd)
			{
				return false;
			}
		}
	}
	else if(Date_To_year==yy)
	{
		if(mm<Date_To_month)
		{
		return false;
		}
		else if(mm==Date_To_month)
		{
			if(Date_To_date>dd)
			{
				return false;
			}
		}
	}
return true ;
}
function DateComparator(Date_To,Date_From)
{	
	if(!compToday(Date_From))
	{
		alert("From Date can not be Future Date.");
		return false ;
	}
	if(!compToday(Date_To))
	{
		alert("To Date can not be Future Date.");
		return false ;
	}
	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));	
	var Date_From_month=Date_From.substring(Date_From.indexOf("/")+1,Date_From.lastIndexOf("/"));

	/*converting ToDate month to number */
	if(Date_To_month=="JAN")
			Date_To_month="01";
		else if(Date_To_month=="FEB")
			Date_To_month="02";
		else if(Date_To_month=="MAR")
			Date_To_month="03";
		else if(Date_To_month=="APR")
			Date_To_month="04";
		else if(Date_To_month=="MAY")
			Date_To_month="05";
		else if(Date_To_month=="JUN")
			Date_To_month="06";
		else if(Date_To_month=="JUL")
			Date_To_month="07";
		else if(Date_To_month=="AUG")
			Date_To_month="08";
		else if(Date_To_month=="SEP")
			Date_To_month="09";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";


	/*converting FromDate month to number */
		if(Date_From_month=="JAN")
			Date_From_month="01";
		else if(Date_From_month=="FEB")
			Date_From_month="02";
		else if(Date_From_month=="MAR")
			Date_From_month="03";
		else if(Date_From_month=="APR")
			Date_From_month="04";
		else if(Date_From_month=="MAY")
			Date_From_month="05";
		else if(Date_From_month=="JUN")
			Date_From_month="06";
		else if(Date_From_month=="JUL")
			Date_From_month="07";
		else if(Date_From_month=="AUG")
			Date_From_month="08";
		else if(Date_From_month=="SEP")
			Date_From_month="09";
		else if(Date_From_month=="OCT")
			Date_From_month="10";
		else if(Date_From_month=="NOV")
			Date_From_month="11";
		else if(Date_From_month=="DEC")
			Date_From_month="12";
	
	var Date_To_date=Number(Date_To.substring(Date_To.indexOf("0"),Date_To.indexOf("/")));	
	var Date_From_date=Number(Date_From.substring(Date_From.indexOf("0"),Date_From.indexOf("/")));

		
	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));
	var Date_From_year=Number(Date_From.substring(Date_From.lastIndexOf("/")+1,Date_From.length));

		

	if(Date_To_year<Date_From_year)
	{
		alert("To Date cannot be less than From  Date.");
		return false;
	}


	else if(Date_To_year>Date_From_year)
	{
		
		//if(Date_From_month>Date_To_month)
		//{
		//alert("To Date can not be less than From Date.");
		//return false;
		//}
		 if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{
				
				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}


	else if(Date_To_year==Date_From_year)
	{
	
		if(Date_From_month>Date_To_month)
		{
		alert("To Date can not be less than From Date.");
		return false;
		}
		else if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{

				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}
return true;
}


function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";
	sDate	= window.showModalDialog('/processmanager/reports/GMACReports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');
	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
	

}
function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	strResult=strdate+"/"+strMonth+"/"+stryear;
	return strResult;
}

function openreport()
{
		var Queue='';
		var From_Date_pay="" ;
		var To_Date_pay = "" ;
		var From_Date_Reg="";
		var To_Date_Reg=''
		var From_Date="" ;
		var To_Date = "" ;
		var owner_id=document.getElementById('owner_id').value;
		var Transferred_date="";
		var QC_Decision='';
		var UserEmailID=document.getElementById('EMail-ID').value;
		var returnCheck="";
		var bQueue=false;

		From_Date_pay=document.forms["textForm"].From_Date_pay.value;
		To_Date_pay=document.forms["textForm"].To_Date_pay.value;
		From_Date_Reg=document.forms["textForm"].From_Date_Reg.value;
		To_Date_Reg=document.forms["textForm"].To_Date_Reg.value;
		From_Date=document.forms["textForm"].From_Date.value;
		To_Date=document.forms["textForm"].To_Date.value;
		//Transferred_date=document.forms["textForm"].Transferred_date.value;
		//alert(UserEmailID+''+RegDateRangeFrom+''+RegDateRangeTo+''+QDateRangeFrom+''+QDateRangeTo);

		for(var i=0;i<document.forms["textForm"].Queue.length;i++)
		{
			if(document.forms["textForm"].Queue[i].selected)
			{
				Queue=Queue+document.forms["textForm"].Queue[i].value+'~';
				bQueue=true;
			}
		}
		
		
		for(var i=0;i<document.forms["textForm"].QC_Decision.length;i++)
		{
			if(document.forms["textForm"].QC_Decision[i].selected)
			{
				
				QC_Decision=QC_Decision+document.forms["textForm"].QC_Decision[i].value+'~';
				
			}
		}

		var stestqueue=Queue.split('~');
		
		var sTestQC=QC_Decision.split('~');
		

		
	//------------------------------------Date Validation start--------------------------------
	if ((From_Date_Reg=='' && To_Date_Reg=='') && (From_Date=='' && To_Date=='') && (From_Date_pay=='' && To_Date_pay==''))
	{
		alert("Please select Introduction Date range or Queue Entry date range or Payment date range.");
		return false ;
	}
	
	if ((From_Date_Reg=='' && To_Date_Reg!='') || (From_Date_Reg!='' && To_Date_Reg==''))
	{
		alert("Please select the Introduction Date Range.");
		return false;
	}
	if(From_Date_Reg!='' && To_Date_Reg!='')
	{
		if(!DateComparator(To_Date_Reg,From_Date_Reg))
		{
			return false;
		}
	}

	
		

		if ((From_Date_pay=='' && To_Date_pay!='') || (From_Date_pay!='' && To_Date_pay==''))
		{
			alert("Please select the Payment Date Range.");
			return false;
		}

		if(!DateComparator(To_Date_pay,From_Date_pay))
		{
			return false;
		}
	
	

		if ((From_Date=='' && To_Date!='') || (From_Date!='' && To_Date==''))
		{
			alert("Please select Queue Entry Date Range.");
			return false;
		}

		if(!DateComparator(To_Date,From_Date))
		{
			return false;
		}
	
		if(!bQueue)
		{
			alert("Please select Queue Name.");
			return false;
		}
		
		if(Queue.indexOf("All")!=-1 && stestqueue.length>2)
		{
			alert("No other Queue can be chosen after choosing All");
			return false;
		}
		if(returnCheck.indexOf("All")!=-1 && sTestreturnCheck.length>2)
		{
			alert("No other Return Check can be chosen after choosing All");
			return false;
		} 
		if(returnCheck=='')
		{
			returnCheck='All~';
		}
		if(Queue=='Introduction~Processing~Approval~Cancel~InProgress~')
		{
			Queue='All~';
		}
	
	
	//------------------------------------Date Validation End--------------------------------		
	
		if(QC_Decision.indexOf("All~")>-1 && sTestQC.length>2)
		{
			alert("No other QC Decision can be chosen after choosing All");
			return false;
		} 	
	//------------------------------------QC Decision Validation End--------------------------------		
	
	//------------------------------------UserEmail Validation start--------------------------------	
		
		if(UserEmailID=='')
		{
			alert("Kindly enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
				
			}
		}
  //-------------------------------------END-----------------------------------------------------

		
		if(QC_Decision=='All~Fail~Pass~')
		{
			QC_Decision='All~';
		}

		if(UserEmailID!='')
			{	
			
	//OpenRedict-Fix
    //window.top.ESLIFECYCLEREPORT.location.href="ESILCRGenerate.jsp?From_Date_Reg="+From_Date_Reg+"&To_Date_Reg="+To_Date_Reg+"&QC_Decision="+QC_Decision+"&ReportName=<%=request.getParameter("ReportName")%>&UserEmailID="+UserEmailID+"&From_Date="+From_Date+"&To_Date="+To_Date+"&Queue="+Queue+"&From_Date_pay="+From_Date_pay+"&To_Date_pay="+To_Date_pay+"&owner_id="+owner_id ;
	var URI = "ESILCRGenerate.jsp?From_Date_Reg="+From_Date_Reg+"&To_Date_Reg="+To_Date_Reg+"&QC_Decision="+QC_Decision+"&ReportName=<%=request.getParameter("ReportName")%>&UserEmailID="+UserEmailID+"&From_Date="+From_Date+"&To_Date="+To_Date+"&Queue="+Queue+"&From_Date_pay="+From_Date_pay+"&To_Date_pay="+To_Date_pay+"&owner_id="+owner_id ;
	var StrOpenWin=strip_tags(URI,"");
	window.top.ESLIFECYCLEREPORT.location.href=StrOpenWin;
			}
			
	
}

function chkradio(obj)
{
	if(obj == 'r')
	{
		if(document.getElementById('Reg').checked == true) 
		{
			document.getElementById('PaymentDate').checked = false;
			document.getElementById('Intro').checked = false;
		}
		document.getElementById('From_Date').value='';
		document.getElementById('To_Date').value='';
		document.getElementById('To_Date_pay').value = '' ;
		document.getElementById('From_Date_pay').value = '' ;
		document.getElementById('From_Date_Reg').value = '' ;
		document.getElementById('To_Date_Reg').value = '' ;

		document.getElementById('To_Date_IMG').disabled=true;
		document.getElementById('From_Date_IMG').disabled=true; 
		document.getElementById('From_Date_IMG_pay').disabled=true; 
		document.getElementById('To_Date_IMG_pay').disabled=true; 
		document.getElementById('From_Date_IMG_Reg').disabled=false;
		document.getElementById('To_Date_IMG_Reg').disabled=false;

		/*document.getElementById('From_Date').style.backgroundColor='white';
		document.getElementById('To_Date').style.backgroundColor='white';
		document.getElementById('From_Date_pay').style.backgroundColor='grey';
		document.getElementById('To_Date_pay').style.backgroundColor='grey';*/


	}
	else if(obj == 'i')
	{
		if(document.getElementById('Intro').checked == true) 
		{
			document.getElementById('Reg').checked = false;
			document.getElementById('PaymentDate').checked = false;
		}
		document.getElementById('From_Date').value='';
		document.getElementById('To_Date').value='';
		document.getElementById('To_Date_pay').value = '' ;
		document.getElementById('From_Date_pay').value = '' ;
		document.getElementById('From_Date_Reg').value = '' ;
		document.getElementById('To_Date_Reg').value = '' ;

		document.getElementById('To_Date_IMG').disabled=false;
		document.getElementById('From_Date_IMG').disabled=false; 
		document.getElementById('From_Date_IMG_pay').disabled=true; 
		document.getElementById('To_Date_IMG_pay').disabled=true; 
		document.getElementById('From_Date_IMG_Reg').disabled=true;
		document.getElementById('To_Date_IMG_Reg').disabled=true;

		/*document.getElementById('From_Date').style.backgroundColor='white';
		document.getElementById('To_Date').style.backgroundColor='white';
		document.getElementById('From_Date_pay').style.backgroundColor='grey';
		document.getElementById('To_Date_pay').style.backgroundColor='grey';*/


	}
	else if(obj == 'p')
	{
		if(document.getElementById('PaymentDate').checked == true) 
		{
			document.getElementById('Intro').checked = false;
			document.getElementById('Reg').checked = false;
		}
		document.getElementById('From_Date').value='';
		document.getElementById('To_Date').value='';
		document.getElementById('To_Date_pay').value = '' ;
		document.getElementById('From_Date_pay').value = '' ;
		document.getElementById('From_Date_Reg').value = '' ;
		document.getElementById('To_Date_Reg').value = '' ;
		

		document.getElementById('To_Date_IMG').disabled=true;
		document.getElementById('From_Date_IMG').disabled=true; 
		document.getElementById('From_Date_IMG_pay').disabled=false; 
		document.getElementById('To_Date_IMG_pay').disabled=false; 
		document.getElementById('From_Date_IMG_Reg').disabled=true;
		document.getElementById('To_Date_IMG_Reg').disabled=true;
		

		/*document.getElementById('From_Date').style.backgroundColor='grey';
		document.getElementById('To_Date').style.backgroundColor='grey';
		document.getElementById('From_Date_pay').style.backgroundColor='white';
		document.getElementById('To_Date_pay').style.backgroundColor='white';*/
	}

}
 function disbFields()
 {
		document.getElementById('From_Date_Reg').value = '' ;
		document.getElementById('To_Date_Reg').value = '' ;
		document.getElementById('From_Date').value='';
		document.getElementById('To_Date').value='';
		document.getElementById('To_Date_pay').value = '' ;
		document.getElementById('From_Date_pay').value = '' ;

		document.getElementById('To_Date_IMG').disabled=true;
		document.getElementById('From_Date_IMG').disabled=true; 
		document.getElementById('From_Date_IMG_pay').disabled=true; 
		document.getElementById('To_Date_IMG_pay').disabled=true;
		document.getElementById('From_Date_IMG_Reg').disabled=true;
		document.getElementById('To_Date_IMG_Reg').disabled=true;		

		/*document.getElementById('From_Date').style.backgroundColor='grey';
		document.getElementById('To_Date').style.backgroundColor='grey';
		document.getElementById('From_Date_pay').style.backgroundColor='grey';
		document.getElementById('To_Date_pay').style.backgroundColor='grey';*/
		
 }

</script>

<body topmargin="0" leftmargin="5" onunload="UnloadReportWindow();" >

			<form name='textForm' method=post>


			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">TA ES Life Cycle Report</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This report will provide the end of the day report for volumes of workitems processed in a selected queue along with other indexing details. 
					</td></tr>
					<tr><td class="EWLabel1">Select the requisite date range for generating the report for the same.</td>
				</tr>
				<td>
		<br/>
					<p style="color: red; font-size: 10pt">Note:  * fields are mandatory.</p>
				</td>
			</table>

			<table border="0" width="95%" cellspacing="1" colspan='2' align="center">
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='10%'>
					<input type = "hidden" name ="Reg" id ="Reg" value = "Reg" onClick="chkradio('r')">
					<b>Introduction Date Range<font color="RED">*</font></b></td>
				</tr>
				<tr>
					<td class="EWLabel1" align="left"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='10%'>
					<input class='TextFieldColorDate' name="From_Date_Reg"  type="text" readonly id="From_Date_Reg" >
			
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='5%'><input class='TextFieldColorDate' name="To_Date_Reg" readonly type="text"  id="To_Date_Reg" >
					
					</td>

				</tr>

                <!-- Added by Chetan for displaying Date range from and to field...-->
				<tr >
					<td class="EWLabel1" align="left" width='35%'>
					<input type = "hidden" name ="Intro" id ="Intro" value = "Intro" onClick="chkradio('i')">
					<b>Queue Entry Date Range<font color="RED">*</font></b></td>
				</tr>
				<tr>
					<td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;From:</b></td>
					<td><input class='TextFieldColorDate' name="From_Date" type="text" readonly id="From_Date" >
					
					</td>
					<td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td><input class='TextFieldColorDate' name="To_Date" readonly type="text"  id="To_Date" >
					
					</td>

				</tr>
				</tr>
				<tr >
					<td class="EWLabel1" align="left" width='35%'>
					<input type = "hidden" name ="PaymentDate" id ="PaymentDate" value = "PaymentDate" onClick="chkradio('p')">
					<b>Payment Date Range<font color="RED">*</font></b></td>
				</tr>
				<tr>
					<td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;From:</b></td>
					<td><input class='TextFieldColorDate' name="From_Date_pay" readonly type="text"  id="From_Date_pay" >
					
					</td>
					<td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td><input class='TextFieldColorDate' name="To_Date_pay" readonly type="text"  id="To_Date_pay" >
					
					</td>
				</tr>
				<tr>&nbsp;</tr>
				<tr>
					<td class="EWLabel1" align="left" width='20%'><b>Queue<font color="RED">*</font></b></td>
					<td width='25%' colspan=3>
					<select style='width:45%' name="Queue" multiple>
							<option value="All">All</option>
							<option value="Introduction">Introduction</option>
							<option value="Processing">Processing</option>
							<option value="Approval">Approval</option>
							<option value="Cancel">Cancel</option>
							<option value="InProgress">InProgress</option>
							<option value="UPCSUpdate">UPCS Update</option>
							<option value="QC">QC</option>
							<option value="UPCSPaid">UPCS Paid</option>
							<option value="ApprovalException">Approval Exception</option>
							<option value="GEACInterface">GEAC Interface</option>
							<option value="PendingPayment">Pending Payment</option>
							<option value="UPCSQC">UPCS QC</option>
				
					</select>
					</td>
				</tr>
				
				
				<tr>&nbsp;</tr>

				<tr>
					<td class="EWLabel1" align="left" width='20%'><b>QC Decision 
					<td width='25%' COLSPAN=3>
					<select style='width:45%' class='TextFieldColor'  name="QC_Decision" multiple>
						<option value="All">All</option>
						<option value="Fail">Fail</option>
						<option value="Pass">Pass</option>
					</select>
					</td>
				</tr>
				
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Owner ID </b></td>
					<td >
					<input type='text' name='owner_id' style='width:145' id='owner_id'>
					</td>
				</tr>
				
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID<font color="RED">*</font></b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>

				
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>
	
			
			</form>
</body>
</Html>	 




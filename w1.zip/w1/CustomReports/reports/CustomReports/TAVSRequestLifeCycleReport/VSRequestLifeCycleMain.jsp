

<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="java.lang.String.*"%>
<%@ page import="java.lang.Object"%>
<%@ page import="java.lang.Exception"%>

<HTML>

<link href="/webdesktop/CustomForms/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>

<HEAD>
<TITLE>Vendor Setup Request Life Cycle report</TITLE><!-- Change No:Res_30 -->
</HEAD>

<FRAMESET ROWS="100%,0%" >
	<FRAME SRC="VSRequestLifeCycleDisp.jsp?ReportName=VSLIFECYCLE" NAME="frmHeader" frameborder=no noresize scrolling=Yes>
	<FRAME SRC="" NAME="VSLIFECYCLE" frameborder=no scrolling=no>
	
</FRAMESET>
</html>


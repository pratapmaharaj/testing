/*  

WNS_TA_APVS_LifeCycle_REPORT'All~', 'Change~', '', '', '', '01/MAR/2014', '28/MAR/2014', 'a.WI_Name,activityname,Vendor_Request_Type,Vendor_type,Priority,Vendor_Name,Vendor_Number,Payment_Terms,Vendor_Status,Address_Line_1,Address_Line_2,City_Address_Line_3,State_Code, Postal_code,Optional_Address_1,Optional_Address_2,Vendor_Email_ID,Combined_single_Payment,Tax_ID_Number,SSN_Number,V_1099_Code,V_1099_Payee_Name,ACH,Bank_Account_Payment_Code,Code,Account_Number,Exception_Type,W9_Indicator,Approvers_Comments,Approval_Decision,QC_Decision,Additional_Comments,Wi_EntryTime,Wi_ExitTime,UserName,(datediff(mi,Wi_EntryTime,Wi_ExitTime)) as Aging', 'ddddds@qqq.com','//10.33.200.82/crebsfs/CR_EBS_APPS_MODEL/Omniflow/Reports/VS/TAVSRequestLifeCycleReport',''

 
 
*/
    
  
create PROCEDURE WNS_TA_APVS_LifeCycle_REPORT 
(    
@QueueName  VARCHAR(100),
@VendorRequestType VARCHAR(100),   
@VendorType VARCHAR(100),  
@ApprovalDecision VARCHAR(100),
@QCDecision VARCHAR(100),  
@RegDateRangeFrom  VARCHAR(100),  
@RegDateRangeTo  VARCHAR(100), 
@Fields varchar(8000), 
@EmailID varchar(200),    
@Path_Val varchar(200), 
@RowCount varchar(200) OUTPUT 
)  
  
AS   
declare  
@WhereQuery varchar(2000),  
@Query varchar(5000),  
@QueryHistory varchar(5000),  
@QueryFinal varchar(5000),  
@Tables varchar(200),  
@QueueNameReport varchar(200),  
@VendorRequestTypeReport varchar(200),   
@VendorTypeReport varchar(200),   
@ApprovalDecisionReport varchar(200),   
@QCDecisionReport varchar(200), 
@OrderBy varchar(300),  
@OrderByFinal varchar(300), 
@FileName varchar(200),   
@USERNAMESUM varchar(100),  
@Current_Work_Step varchar(100),   
@WI_PROCESSED varchar(100),   
@AVG_TIME varchar(100),    
@status_temp varchar(8000),
@qname varchar(200) ,
@vreqType nvarchar(100),
@vType nvarchar(300),
@adec nvarchar(100),
@qcdec nvarchar(100),
@DataBaseName varchar(60)
  
Set nocount on  
BEGIN   
  
--Temporary Table   
if Object_ID('#APVS_TEMP_TABLE_Lifecycle') is not null
begin
print 'Table dropped'
 exec('drop table #APVS_TEMP_TABLE_Lifecycle')
end
   
if Object_ID('APVSLifecyclesummary') is not null
begin
print 'Table dropped'
 exec('drop table APVSLifecyclesummary')
end 
  
CREATE TABLE #APVS_TEMP_TABLE_Lifecycle (   
WI_Name VARCHAR(100),   
Current_Work_Step VARCHAR(100),   
Vendor_Request_Type VARCHAR(100),  
Vendor_type VARCHAR(100),   
Priority VARCHAR(100),   
Vendor_Name VARCHAR(100),   
Vendor_Number VARCHAR(100),   
Payment_Terms VARCHAR(100), 
Vendor_Status VARCHAR(100),   
Address_Line_1 VARCHAR(100),   
Address_Line_2 VARCHAR(100),   
City_Address_Line_3 VARCHAR(100),   
State_Code VARCHAR(100),
Postal_code VARCHAR(100),   
Optional_Address_1 VARCHAR(100),   
Optional_Address_2 VARCHAR(100),   
Vendor_Email_ID VARCHAR(100),   
Combined_single_Payment VARCHAR(100),   
Tax_ID_Number VARCHAR(100),   
SSN_Number VARCHAR(100),   
V_1099_Code VARCHAR(100),   
V_1099_Payee_Name VARCHAR(100),   
ACH VARCHAR(100),   
Bank_Account_Payment_Code VARCHAR(100),   
Code varchar(100),   
Account_Number VARCHAR(100),   
Exception_Type VARCHAR(100),   
W9_Indicator VARCHAR(100),   
Approvers_Comments VARCHAR(512),   
Approval_Decision VARCHAR(100),   
QC_Decision VARCHAR(100),   
Additional_Comments Varchar(512),   
Wi_EntryTime VARCHAR(100),   
Wi_ExitTime VARCHAR(100),   
UserName VARCHAR(100),   
Aging VARCHAR(100)   
)  

--Temporary Table  
 
--create temporary summary table 
Create Table APVSLifecyclesummary  
(  
USERNAME varchar(100),  
Current_Work_Step varchar(100),   
WI_PROCESSED varchar(100),   
AVG_TIME varchar(100)   
)  
 set @FileName=@Path_Val+'/'+@EmailID+'_VS_Lifecycle_Report__'+convert(varchar,getdate(),104)+'.xls'
print  @FileName  
--set @FileName='//10.33.192.139/XLS-File/'+@EmailID+'NG_VS_Lifecycle_Report_'+convert(varchar,getdate(),104)+'.xls'   
set @WhereQuery='WHERE '  
set @QueueNameReport=''   
set @VendorRequestTypeReport = ''   
set @VendorTypeReport = ''   
set @ApprovalDecisionReport = '' 
set @QCDecisionReport=''  
set @OrderBy=' order by b.wi_name '  
set @OrderByFinal=' order by UserName,a.Current_Work_Step ' 
set @RowCount='0'
set @qname = ''
set @vreqType=''
set @vType='' 
set @adec = ''
set @qcdec = ''
 select @DataBaseName=DB_name()   
    
set @Tables='WNS_TA_APVS_EXT_Table a with(nolock),WNS_TA_APVS_EntryExitTable b with(nolock )'   
set @WhereQuery=@WhereQuery+' a.wi_name=b.wi_name '  
if(rtrim(ltrim(@RegDateRangeFrom))<>'')  
 SET @RegDateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@RegDateRangeFrom,121)))))
   
if(rtrim(ltrim(@RegDateRangeTo))<>'')  
 SET @RegDateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@RegDateRangeTo,121)))))   

if(rtrim(ltrim(@RegDateRangeFrom))<>'' AND rtrim(ltrim(@RegDateRangeTo))<>'')  
BEGIN  
 set @WhereQuery=@WhereQuery+' AND Registration_Date between '''+rtrim(ltrim(@RegDateRangeFrom))+''' AND '''+ rtrim(ltrim(@RegDateRangeTo))+''''  

--Queuename  
if(rtrim(ltrim(@QueueName))<>'')  
begin   
if(rtrim(ltrim(@QueueName))<>'All~')  
BEGIN 
if(len(@QueueName)=charindex('~',@QueueName)) 
BEGIN  
set @qname=ltrim(rtrim(substring(@QueueName,0,len(@QueueName)))) 
set @QueueNameReport=ltrim(rtrim(substring(@QueueName,0,len(@QueueName))))
if(rtrim(ltrim(@QueueName))<>'')
begin
set @WhereQuery=@WhereQuery+' AND Current_Work_Step='''+@QueueNameReport+''''  
end 
END  
else  
BEGIN  
while (charindex('~',@QueueName)>1)  
BEGIN 
 set @qname= @qname+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+','
set @QueueNameReport = @QueueNameReport + ''''+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+''''+','  
  set @QueueName=ltrim(rtrim(Substring(@QueueName,Charindex('~',@QueueName)+len('~'),len(@QueueName))))
END  
 
set @QueueNameReport=substring(@QueueNameReport,0,len(@QueueNameReport))  
if(rtrim(ltrim(@QueueName))<>'')
begin
set @WhereQuery=@WhereQuery+' AND Current_Work_Step in('+@QueueNameReport+')'  
end    
END   
END    
end   
--Queuename 
--VendorRequestType    
if(rtrim(ltrim(@VendorRequestType))<>'')  
BEGIN 
if(rtrim(ltrim(@VendorRequestType))<>'All~') 
BEGIN 
if(len(@VendorRequestType)=charindex('~',@VendorRequestType))  
BEGIN
set @vreqType =ltrim(rtrim(substring(@VendorRequestType,0,len(@VendorRequestType)))) 
set @VendorRequestTypeReport=ltrim(rtrim(substring(@VendorRequestType,0,len(@VendorRequestType)))) 
if(rtrim(ltrim(@VendorRequestType))<>'') 
begin
set @WhereQuery=@WhereQuery+' AND Vendor_Request_Type='''+@VendorRequestTypeReport+''''  
end 
END  
else  
BEGIN  
while (charindex('~',@VendorRequestType)>1)  
BEGIN 
set @vreqType=@vreqType+ltrim(rtrim(SUBSTRING(@VendorRequestType,1,Charindex('~',@VendorRequestType)-1)))+','    
set @VendorRequestTypeReport = @VendorRequestTypeReport + ''''+ltrim(rtrim(SUBSTRING(@VendorRequestType,1,Charindex('~',@VendorRequestType)-1)))+''''+','  
  set @VendorRequestType=ltrim(rtrim(Substring(@VendorRequestType,Charindex('~',@VendorRequestType)+len('~'),len(@VendorRequestType))))
END  
 
set @VendorRequestTypeReport=substring(@VendorRequestTypeReport,0,len(@VendorRequestTypeReport))if(rtrim(ltrim(@VendorRequestType))<>'') 
begin
set @WhereQuery=@WhereQuery+' AND Vendor_Request_Type in('+@VendorRequestTypeReport+')'  
end
END   
 
  
END 
END 
--VendorRequestType   
--VendorType  
if(rtrim(ltrim(@VendorType))<>'')  
BEGIN 
if(rtrim(ltrim(@VendorType))<>'All~')  
BEGIN 
if(len(@VendorType)=charindex('~',@VendorType)) 
BEGIN
set @vType =ltrim(rtrim(substring(@VendorType,0,len(@VendorType))))  
set @VendorTypeReport=ltrim(rtrim(substring(@VendorType,0,len(@VendorType))))  
if(rtrim(ltrim(@VendorTypeReport))<>'')  
begin  
set @WhereQuery=@WhereQuery+' AND Vendor_Type='''+@VendorTypeReport+''''  
end 
END  
else  
BEGIN  
while (charindex('~',@VendorType)>1)  
BEGIN
set @vType =  @vType+ltrim(rtrim(SUBSTRING(@VendorType,1,Charindex('~',@VendorType)-1)))+','   
set @VendorTypeReport = @VendorTypeReport + ''''+ltrim(rtrim(SUBSTRING(@VendorType,1,Charindex('~',@VendorType)-1)))+''''+','  
  set @VendorType=ltrim(rtrim(Substring(@VendorType,Charindex('~',@VendorType)+len('~'),len(@VendorType))))
END  
 
set @VendorTypeReport=substring(@VendorTypeReport,0,len(@VendorTypeReport))
if(rtrim(ltrim(@VendorTypeReport))<>'')  
begin  
set @WhereQuery=@WhereQuery+' AND Vendor_Type in('+@VendorTypeReport+')'
end 
END 
END
END  
--VendorType
--Approval Decision 
print @ApprovalDecision    
if(rtrim(ltrim(@ApprovalDecision))<>'')  
BEGIN  
 if(rtrim(ltrim(@ApprovalDecision))<>'All~') 
 BEGIN 
  if(len(@ApprovalDecision)=charindex('~',@ApprovalDecision)) 
  BEGIN  
   print 'ssssss' 
   set @adec=ltrim(rtrim(substring(@ApprovalDecision,0,len(@ApprovalDecision))))
   set @ApprovalDecisionReport=ltrim(rtrim(substring(@ApprovalDecision,0,len(@ApprovalDecision)))) 
   if(rtrim(ltrim(@ApprovalDecision))<>'')  
   begin 
    set @WhereQuery=@WhereQuery+' AND Approval_Decision='''+@ApprovalDecisionReport+''''  
   end 
  END  
  else  
  BEGIN  
   while (charindex('~',@ApprovalDecision)>1)  
   BEGIN
    print 'ssssss111' 
    set @adec = @adec +ltrim(rtrim(SUBSTRING(@ApprovalDecision,1,Charindex('~',@ApprovalDecision)-1)))+','   
    set @ApprovalDecisionReport = @ApprovalDecisionReport + ''''+ltrim(rtrim(SUBSTRING(@ApprovalDecision,1,Charindex('~',@ApprovalDecision)-1)))+''''+','  
    set @ApprovalDecision=ltrim(rtrim(Substring(@ApprovalDecision,Charindex('~',@ApprovalDecision)+len('~'),len(@ApprovalDecision))))
   END   
   set @ApprovalDecisionReport=substring(@ApprovalDecisionReport,0,len(@ApprovalDecisionReport))  
   if(rtrim(ltrim(@ApprovalDecisionReport))<>'')  
   begin
    set @WhereQuery=@WhereQuery+' AND Approval_Decision in('+@ApprovalDecisionReport+')'   
   end    
  END
 END
END  
--Approval Decision   
--QC Decision  
if(rtrim(ltrim(@QCDecision))<>'')  
BEGIN 
if(rtrim(ltrim(@QCDecision))<>'All~')  
BEGIN  
if(len(@QCDecision)=charindex('~',@QCDecision)) 
BEGIN   
set @qcdec =ltrim(rtrim(substring(@QCDecision,0,len(@QCDecision))))
set @QCDecisionReport=ltrim(rtrim(substring(@QCDecision,0,len(@QCDecision)))) 
if(rtrim(ltrim(@QCDecision))<>'')
begin    
set @WhereQuery=@WhereQuery+' AND QC_Decision='''+@QCDecisionReport+''''   
end   
END  
else  
BEGIN  
while (charindex('~',@QCDecision)>1)  
BEGIN
set @qcdec = @qcdec+ltrim(rtrim(SUBSTRING(@QCDecision,1,Charindex('~',@QCDecision)-1)))+','
set @QCDecisionReport = @QCDecisionReport + ''''+ltrim(rtrim(SUBSTRING(@QCDecision,1,Charindex('~',@QCDecision)-1)))+''''+','   
  set @QCDecision=ltrim(rtrim(Substring(@QCDecision,Charindex('~',@QCDecision)+len('~'),len(@QCDecision))))
END  
 
set @QCDecisionReport=substring(@QCDecisionReport,0,len(@QCDecisionReport))
if(rtrim(ltrim(@QCDecision))<>'')
begin    
set @WhereQuery=@WhereQuery+' AND QC_Decision in('+@QCDecisionReport+')'
end  
END  
  END
END
--QC Decision   
   
--date range
 --date range
  
END   
print @Fields
print 'sssssssssssssssssss'  
print @WhereQuery 
SET @Query='SELECT '+@Fields+' from '+ @Tables + @WhereQuery + @OrderBy
print  @Query
set @QueryHistory=@Query  
set @QueryHistory=Replace(@QueryHistory,'WNS_TA_APVS_EntryExitTable','WNS_TA_APVS_EntryExitTable_History')  
--print @QueryHistory   
set @Query='insert into #APVS_TEMP_TABLE_Lifecycle '+ @Query  
set @QueryHistory='insert into #APVS_TEMP_TABLE_Lifecycle '+@QueryHistory  
  
exec(@Query) 
  
--exec(@QueryHistory)  

set @QueryFinal='select WI_Name,Current_Work_Step,Vendor_Request_Type,Vendor_type,Priority,Vendor_Name,Vendor_Number,Payment_Terms,Vendor_Status,Address_Line_1,Address_Line_2,City_Address_Line_3,State_Code, Postal_code,Optional_Address_1,Optional_Address_2,Vendor_Email_ID,Combined_single_Payment,Tax_ID_Number,SSN_Number,V_1099_Code,V_1099_Payee_Name,ACH,Bank_Account_Payment_Code,Code,Account_Number,Exception_Type,W9_Indicator,Approvers_Comments,Approval_Decision,QC_Decision,Additional_Comments,Wi_EntryTime,Wi_ExitTime,UserName,(datediff(mi,Wi_EntryTime,Wi_ExitTime)) as AGING from #APVS_TEMP_TABLE_Lifecycle with(nolock)'+@OrderByFinal  
print @QueryFinal  
    
--exec(@QueryFinal) 
 
SET @Query='insert into APVSLifecyclesummary(USERNAME,Current_Work_Step,WI_PROCESSED,AVG_TIME)'  
SET @QueryHistory='select USERNAME,Current_Work_Step,count(Current_Work_Step)as WI_PROCESSED,avg(convert(float,aging))as AVG_TIME from #APVS_TEMP_TABLE_Lifecycle group by USERNAME,Current_Work_Step order by username' 

set @Query=@Query+@QueryHistory  
print(@Query)  
exec (@Query)   
select @RowCount=count(*) from APVSLifecyclesummary with(nolock) 
 if(@RowCount=0) 
 Begin 
 drop table APVSLifecyclesummary 
 End
print 'dfsdsd' 
----- 
select @RowCount=count(*) from #APVS_TEMP_TABLE_Lifecycle with(nolock) 
 if(@RowCount=0)
  Begin   
  drop table #APVS_TEMP_TABLE_Lifecycle    
  End   
 else  
  Begin 
   if Object_ID ('APVS_TEMP_TABLE_Lifecycle_Excel') is not null
   BEGIN
   exec('drop table APVS_TEMP_TABLE_Lifecycle_Excel')   
   END 
   
Exec('Create table APVS_TEMP_TABLE_Lifecycle_Excel (Header varchar(8000),ROw_Index [int] identity(1,1) not null)')    
exec('Insert into APVS_TEMP_TABLE_Lifecycle_Excel
Select 
''<html>   
<style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>

   <table border=1>    
 <tr align="left"><td colspan=36 class=headerbold align="left">    
 <center>
 Vendor Setup Request Life Cycle Report </center></td></tr>
   <tr align="left"><td colspan=36 class=headerbold> From : '+@RegDateRangeFrom+'</td></tr>  
   <tr align="left"><td colspan=36 class=headerbold> To : '+@RegDateRangeTo+'</td></tr>  
   <tr align="left"><td colspan=36 class=headerbold> Queue Name : '+@qname+'</td></tr>
 <tr align="left"><td colspan=36 class=headerbold> Vendor Request Type : '+@vreqType+'</td></tr>
   <tr align="left"><td colspan=36 class=headerbold> Vendor Type : '+@vType+'</td></tr>  
 <tr align="left"><td colspan=36 class=headerbold> Approvers Decision : '+@adec+'</td></tr>
 <tr align="left"><td colspan=36 class=headerbold> QC Decision : '+@qcdec+'</td></tr> 
</table>  <br>
<table border=1>   
<tr>   
<td class=headerbold>Workitem Name</td>''+    
''<td class=headerbold>Queue Name</td>''+   
''<td class=headerbold>Vendor Request Type</td>''+ 
''<td class=headerbold>Vendor Type</td>''+  
''<td class=headerbold>Priority</td>''+  
''<td class=headerbold>Vendor Name</td>''+ 
''<td class=headerbold>Vendor Number</td>''+    
''<td class=headerbold>Payment Terms</td>''+
''<td class=headerbold>Status</td>''+
''<td class=headerbold>Address Line 1</td>''+
''<td class=headerbold>Address Line 2</td>''+
''<td class=headerbold>City Address Line 3</td>''+ 
''<td class=headerbold>State Code</td>''+ 
''<td class=headerbold>Postal Code</td>''+  
''<td class=headerbold>Optional Address 1</td>''+  
''<td class=headerbold>Optional Address 2</td>''+
''<td class=headerbold>Vendor Email ID</td>''+  
''<td class=headerbold>Combined or Single</td>''+  
''<td class=headerbold>Tax ID</td>''+  
''<td class=headerbold>SSN Number</td>''+
''<td class=headerbold>1099 Code</td>''+
''<td class=headerbold>1099 Payee Name</td>''+   
''<td class=headerbold>ACH</td>''+ 
''<td class=headerbold>BAP Code</td>''+ 
''<td class=headerbold>ABA Number</td>''+ 
''<td class=headerbold>Account Number</td>''+  
''<td class=headerbold>Exception Type</td>''+  
''<td class=headerbold>W9 Indicator</td>''+  
''<td class=headerbold>Approvers Comments</td>''+  
''<td class=headerbold>Approval Decision</td>''+  
''<td class=headerbold>QC Decision</td>''+ 
''<td class=headerbold>Additional Comments</td>''+    
''<td class=headerbold>Queue Entry Date</td>''+ 
''<td class=headerbold>Queue Exit Date</td>''+  
''<td class=headerbold>UserName</td>''+
''<td class=headerbold>Aging (In Minutes)</td>'' 

+''</tr></font>''
   
UNION ALL
   
Select ''<tr>   
<td align=left style=mso-number-format:\\@>''+ISNULL([Wi_Name],'''')+''</td>''+  
''<td align=left style=mso-number-format:\\@>''+ISNULL([Current_Work_Step],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Request_Type],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_type],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([Priority],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([Vendor_Name],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([Vendor_Number],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([Payment_Terms],'''')+''</td>''+    
''<td align=left style=mso-number-format:\@>''+ISNULL([Vendor_Status],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([Address_Line_1],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([Address_Line_2],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([City_Address_Line_3],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([State_Code],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([Postal_code],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([Optional_Address_1],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([Optional_Address_2],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([Vendor_Email_ID],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([Combined_single_Payment],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([Tax_ID_Number],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([SSN_Number],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([V_1099_Code],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([V_1099_Payee_Name],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([ACH],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([Bank_Account_Payment_Code],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([Code],'''')+''</td>''+   
''<td align=left style=mso-number-format:\@>''+ISNULL([Account_Number],'''')+''</td>''+   
''<td align=left style=mso-number-format:\@>''+ISNULL([Exception_Type],'''')+''</td>''+   
''<td align=left style=mso-number-format:\@>''+ISNULL([W9_Indicator],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([Approvers_Comments],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([Approval_Decision],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([QC_Decision],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([Additional_Comments],'''')+''</td>''+   
''<td align=left   
style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Wi_EntryTime],''''),120)+''</td>''+   
''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Wi_ExitTime],''''),120)+''</td>''+   
''<td align=left style=mso-number-format:\\@>''+ISNULL([UserName],'''')+''</td>''+ 
''<td align=left style=mso-number-format:\\@>''+ISNULL([AGING],'''')+'' </td> ''
 from #APVS_TEMP_TABLE_Lifecycle ')  
  

select @status_temp='</tr><tr></tr></table><html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style><table border=1><tr>'+'<td class=headerbold><b>USER</b></td>'+'<td class=headerbold><b>QUEUE</b></td><td class=headerbold><b>Workitems Processed</b></td><td class=headerbold><b>Average Time(In Minutes)</b></td></tr>'
    
 DECLARE APVSLifecyclesummary_Cursor CURSOR FAST_FORWARD FOR 
 Select USERNAME,Current_Work_Step,WI_PROCESSED,AVG_TIME from APVSLifecyclesummary
  OPEN APVSLifecyclesummary_Cursor 
  FETCH NEXT FROM APVSLifecyclesummary_Cursor INTO  @USERNAMESUM,@Current_Work_Step,@WI_PROCESSED,@AVG_TIME
  WHILE @@FETCH_STATUS = 0    
   Begin
    select @status_temp=@status_temp+'<tr><td>'+convert(varchar(100),@USERNAMESUM)+'</td><td>'+convert(varchar(100),@Current_Work_Step)+'</td><td>'+convert(varchar(100),@WI_PROCESSED)+'</td><td>'+convert(varchar(100),@AVG_TIME)+'</td></tr>'    

    FETCH NEXT FROM APVSLifecyclesummary_Cursor INTO @USERNAMESUM,@Current_Work_Step,@WI_PROCESSED,@AVG_TIME    
   End
    
  close APVSLifecyclesummary_Cursor   
 Deallocate APVSLifecyclesummary_Cursor 
select @status_temp=@status_temp+'</table>'  
exec('insert into APVS_TEMP_TABLE_Lifecycle_Excel select '''+@status_temp+'''   ') 
  
update APVS_TEMP_TABLE_Lifecycle_Excel set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yy>&nbsp</td>')

SET @Query='Master..xp_Cmdshell ''bcp "select Header FROM '+@DataBaseName+'..APVS_TEMP_TABLE_Lifecycle_Excel order by row_index asc" queryout "'+@FileName+'" -c -T'',no_output'  
 
--select * from  APVS_TEMP_TABLE_Lifecycle_Excel
exec(@Query)
 
insert into NG_AutoMail_Status values('TA VS Lifecycle Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL)

drop table APVSLifecyclesummary
drop table #APVS_TEMP_TABLE_Lifecycle
drop table APVS_TEMP_TABLE_Lifecycle_Excel   
   

End  
select @RowCount 
 
End 

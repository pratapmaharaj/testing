

<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>


<HTML>
<HEAD>
<TITLE>Vendor Setup Request Life Cycle Report</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>
</HEAD>

<link href="/webdesktop/CustomForms/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>
<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
}
</style>

<script>
	var allWindows = new Array();
	$(document).ready(function(){$('#From_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	
	});
	var win; 
	function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}

//-Added by chetan 
function ShowCalendar(obj)
{	

	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";

	sDate	= window.showModalDialog('/processmanager/reports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');
	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
	

}

function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	strResult=strdate+"/"+strMonth+"/"+stryear;
	return strResult;
}
//------------------------------------

function ValidateForm(emailID){
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }

function convertMonth(strMonth)
{
	if(strMonth=="JAN")
			strMonth="00";
		else if(strMonth=="FEB")
			strMonth="01";
		else if(strMonth=="MAR")
			strMonth="02";
		else if(strMonth=="APR")
			strMonth="03";
		else if(strMonth=="MAY")
			strMonth="04";
		else if(strMonth=="JUN")
			strMonth="05";
		else if(strMonth=="JUL")
			strMonth="06";
		else if(strMonth=="AUG")
			strMonth="07";
		else if(strMonth=="SEP")
			strMonth="08";
		else if(strMonth=="OCT")
			strMonth="09";
		else if(strMonth=="NOV")
			strMonth="10";
		else if(strMonth=="DEC")
			strMonth="11";
	return strMonth;
}
/*
function DateComparator(Date_To,Date_From)
{	
	//alert(Date_To+":"+Date_From) ;
	var todaysDate = new Date(); 
	var dd = todaysDate.getDate() ;
	var mm = todaysDate.getMonth()+1 ;
	var yy = todaysDate.getFullYear() ;

	if(mm<10)
	{
		mm = "0"+mm ;
	}
	if(dd<10)
	{
		dd = "0"+dd ;
	}

	var today = dd+''+mm+''+yy ;

	//alert(dd+" "+mm+" "+yy) ;
	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));	
	var Date_From_month=Date_From.substring(Date_From.indexOf("/")+1,Date_From.lastIndexOf("/"));

	//converting ToDate month to number 
	if(Date_To_month=="JAN")
			Date_To_month="01";
		else if(Date_To_month=="FEB")
			Date_To_month="02";
		else if(Date_To_month=="MAR")
			Date_To_month="03";
		else if(Date_To_month=="APR")
			Date_To_month="04";
		else if(Date_To_month=="MAY")
			Date_To_month="05";
		else if(Date_To_month=="JUN")
			Date_To_month="06";
		else if(Date_To_month=="JUL")
			Date_To_month="07";
		else if(Date_To_month=="AUG")
			Date_To_month="08";
		else if(Date_To_month=="SEP")
			Date_To_month="09";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";


	//converting FromDate month to number 
		if(Date_From_month=="JAN")
			Date_From_month="01";
		else if(Date_From_month=="FEB")
			Date_From_month="02";
		else if(Date_From_month=="MAR")
			Date_From_month="03";
		else if(Date_From_month=="APR")
			Date_From_month="04";
		else if(Date_From_month=="MAY")
			Date_From_month="05";
		else if(Date_From_month=="JUN")
			Date_From_month="06";
		else if(Date_From_month=="JUL")
			Date_From_month="07";
		else if(Date_From_month=="AUG")
			Date_From_month="08";
		else if(Date_From_month=="SEP")
			Date_From_month="09";
		else if(Date_From_month=="OCT")
			Date_From_month="10";
		else if(Date_From_month=="NOV")
			Date_From_month="11";
		else if(Date_From_month=="DEC")
			Date_From_month="12";
	
	var Date_To_date=Number(Date_To.substring(0,Date_To.indexOf("/")));	
	var Date_From_date=Number(Date_From.substring(0,Date_From.indexOf("/")));

	if(Date_To_date<10)
	{
		Date_To_date = "0"+Date_To_date ;
	}
	if(Date_From_date<10)
	{
		Date_From_date = "0"+Date_From_date ;
	}
	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));
	var Date_From_year=Number(Date_From.substring(Date_From.lastIndexOf("/")+1,Date_From.length));

	var inputTo = Date_To_date+''+Date_To_month+''+Date_To_year ;
	var inputFrom = Date_From_date+''+Date_From_month+''+Date_From_year ;

	//alert(today+" : "+inputFrom+"-"+inputTo) ;
	if(inputFrom>today)
	{
		alert("From date can not be future date.") ;
		return false ;
	}

	if(inputTo>today)
	{
		alert("To date can not be future date.") ;
		return false ;
	}


	if(Date_To_year<Date_From_year)
	{
		alert("To Date cannot be less than From  Date.");
		return false;
	}
	else if(Date_To_year>Date_From_year)
	{
		//if(Date_From_month>Date_To_month)
		//{
		//alert("To Date can not be less than From Date.");
		//return false;
		//}
		 if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{
				
				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}
	else if(Date_To_year==Date_From_year)
	{
	
		if(Date_From_month>Date_To_month)
		{
		alert("To Date can not be less than From Date.");
		return false;
		}
		else if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{

				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}
	var toDate = new Date(Date_To_month+"/"+Date_To_date+"/"+Date_To_year);
	var fromDate = new Date(Date_From_month+"/"+Date_From_date+"/"+Date_From_year);
	var oneDay=1000*60*60*24;

	var dateDiff=Math.ceil((toDate.getTime()-fromDate.getTime())/oneDay);
	if(dateDiff>90)
	{
		alert('Date Range can not be greater than 90 days.');
		return false;
	}

return true;
}*/

function DateComparator(Date_To,Date_From)
	{
		
	if (Date_From == "" && Date_To == "")
		{
			return false;
		}
		
		var FromDay = Date_From.split("/")[0];
		var FromMonth = convertMonth(Date_From.split("/")[1]);
		var FromYear = Date_From.split("/")[2];
		
		//alert("From:::Day::"+FromDay+"  Month::"+FromMonth+"	Year::"+FromYear+"==");
		//alert((new Date(FromYear,FromMonth,FromDay)));
		
		var ToDay = Date_To.split("/")[0];
		var ToMonth = convertMonth(Date_To.split("/")[1]);
		var ToYear = Date_To.split("/")[2];
		
		//alert("To:::Day::"+ToDay+"  Month::"+ToMonth+"	Year::"+ToYear);
		//alert(new Date(ToYear,ToMonth,ToDay));
		
		var CurrentDate=new Date();
		var CurrentDay = CurrentDate.getDate();
		var CurrentMonth = CurrentDate.getMonth();
		var CurrentYear = CurrentDate.getFullYear();
		
		//alert("Current:::Day::"+CurrentDay+"  Month::"+CurrentMonth+"	Year::"+CurrentYear);
		//alert(new Date(CurrentYear,CurrentMonth,CurrentDay));
		
		var toDate = (new Date(ToYear,ToMonth,ToDay)).getTime();
		var fromDate = (new Date(FromYear,FromMonth,FromDay)).getTime();
		var CurrentDate = (new Date(CurrentYear,CurrentMonth,CurrentDay)).getTime();
		
		//alert("FromDate::"+fromDate+"  ToDate::"+toDate+"	Current::"+CurrentDate);

		//alert("Fr : "+new Date(fromDate)+"\nTo : "+new Date(toDate)+"\nCu : "+new Date(CurrentDate));
		if(fromDate > toDate)
		{
			alert("To Date cannot be less than From Date.");
			return false;
		}
		else if(fromDate > CurrentDate)
		{
			alert("From Date cannot be future date.");
			return false;
		}
		else if(toDate > CurrentDate)
		{
			alert("To Date cannot be future date.");
			return false;
		}

		//toDate = new Date(ToMonth+"/"+ToDay+"/"+ToYear);
		//fromDate = new Date(FromMonth+"/"+FromDay+"/"+FromYear);
		var oneDay=1000*60*60*24;
		//alert(fromDate);
		//alert(toDate);
		
		var dateDiff=Math.ceil((toDate+oneDay-fromDate)/oneDay);
		//var dateDiff=Math.ceil((toDate.getTime()-fromDate.getTime())/oneDay);
		//alert((toDate+oneDay-fromDate)/oneDay);
		if(dateDiff>90)
		{
			alert('Date Range can not be greater than 90 days.');
			return false;
		}

	 return true;
	
	}
	function openreport()
	{			
		var QueueName="";
		var bQueue=false;
		var VendorRequestType="";
		var bVendorReqType=false;
		var VendorType="";
		var bVendorType="";
		var ApproverDecision="";
		var bApproverDec=false;
		var QCDecision="";
		var bQCDec=false;
		var DateRangeFrom="";
		var DateRangeTo="";
		var UserEmailID=document.getElementById('EMail-ID').value;
		
		DateRangeFrom=document.forms["textForm"].From_Date.value;
		DateRangeTo=document.forms["textForm"].To_Date.value;
		
		for(var i=0;i<document.forms["textForm"].Queue_Name.length;i++)
		{
					if(document.forms["textForm"].Queue_Name[i].selected)
					{
					QueueName=QueueName+document.forms["textForm"].Queue_Name[i].value+'~';
					bQueue=true;
					}

		}
		
		for(var i=0;i<document.forms["textForm"].Vendor_Request_Type.length;i++)
		{
					if(document.forms["textForm"].Vendor_Request_Type[i].selected)
					{
					VendorRequestType=VendorRequestType+document.forms["textForm"].Vendor_Request_Type[i].value+'~';
					bVendorReqType = true;
					}

		}
				
		for(var i=0;i<document.forms["textForm"].Vendor_Type.length;i++)
		{
					if(document.forms["textForm"].Vendor_Type[i].selected)
					{
					VendorType=VendorType+document.forms["textForm"].Vendor_Type[i].value+'~';
					bVendorType = true;
					}

		}
		
		for(var i=0;i<document.forms["textForm"].Approver_Decision.length;i++)
		{
					if(document.forms["textForm"].Approver_Decision[i].selected)
					{
					ApproverDecision=ApproverDecision+document.forms["textForm"].Approver_Decision[i].value+'~';
					bApproverDec = true;
					}

		}
		
		for(var i=0;i<document.forms["textForm"].QC_Decision.length;i++)
		{
					if(document.forms["textForm"].QC_Decision[i].selected)
					{
					QCDecision=QCDecision+document.forms["textForm"].QC_Decision[i].value+'~';
					bQCDec = true;
					}

		}
		
			var sTestQueue=QueueName.split('~');
			var sTestVendorType=VendorType.split('~');
			var sTestVendorReqType=VendorRequestType.split('~');
			var sTestApproverDec=ApproverDecision.split('~');
			var sTestQCDecision=QCDecision.split('~');
			
		
		if(QueueName.indexOf("All")!=-1 && sTestQueue.length>2)
		{
			alert("No other Queue Name can be chosen after choosing All");
			return false;
		} 
		
		if(VendorRequestType.indexOf("All")!=-1 && sTestVendorReqType.length>2)
		{
			alert("No other Vendor Request Type can be chosen after choosing All");
			return false;
		} 
		
		if(VendorType.indexOf("All")!=-1 && sTestVendorType.length>2)
		{
			alert("No other Vendor Type can be chosen after choosing All");
			return false;
		} 
		
		if(ApproverDecision.indexOf("All")!=-1 && sTestApproverDec.length>2)
		{
			alert("No other Approver Decision can be chosen after choosing All");
			return false;
		} 
		
		if(QCDecision.indexOf("All")!=-1 && sTestQCDecision.length>2)
		{
			alert("No other QC Decision can be chosen after choosing All");
			return false;
		} 
		
		if(QueueName=='Introduction~VendorSetup~PendingResolution~Cancel~QC~VendorApproval~UpdateVendorChanges~ChangeQC~GEACInterface~Exit~')
		{
			QueueName='Introduction~VendorSetup~PendingResolution~Cancel~QC~VendorApproval~UpdateVendorChanges~ChangeQC~GEACInterface~Exit~';
		}
		
		if(VendorRequestType=='New~Change~')
		{
			VendorRequestType='New~Change~';
		}
		
		if(VendorType=='Policyholder vendors~Escheatment vendors~Tax vendors~PO vendors~Licensing and filing fee vendors~Non PO Vendors~')
		{
			VendorType='Policyholder vendors~Escheatment vendors~Tax vendors~PO vendors~Licensing and filing fee vendors~Non PO Vendors~';
		}
		
		if(ApproverDecision.indexOf("All")!=-1)
		{
			ApproverDecision = 'All~';
		}
			
		if(QCDecision.indexOf("All")!=-1)
		{
			QCDecision = 'All~';
		}
			
		if(DateRangeFrom=="")
		{
			alert("Please select an appropriate From Date.");
			return false;
		}

		if(DateRangeTo=="")
		{
			alert("Please select an appropriate To Date.");
			return false;
		}

		if ((DateRangeFrom=="" && DateRangeTo!="") || (DateRangeFrom!="" && DateRangeTo==""))
		{
			alert("Please Select the complete Date Range.");
			return false;
		}
		
		if(!DateComparator(DateRangeTo,DateRangeFrom))
		{
			return false;
		}
		
		if(UserEmailID=='')
		{
			alert("Please enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
				return false ;
			}
		}
		/*alert(window.top.VSLIFECYCLE.location.href="VSRequestLifeCycleGenerate.jsp?QueueName="+QueueName+"&VendorRequestType="+VendorRequestType+"&VendorType="+VendorType+"&ApproverDecision="+ApproverDecision+"&QCDecision="+QCDecision+"&ReportName=<%=request.getParameter("ReportName")%>&FromDate="+DateRangeFrom+"&ToDate="+DateRangeTo+"&UserEmailID="+UserEmailID+"");*/
			
		
		//OpenRedict-Fix
    //window.top.VSLIFECYCLE.location.href="VSRequestLifeCycleGenerate.jsp?QueueName="+QueueName+"&VendorRequestType="+VendorRequestType+"&VendorType="+VendorType+"&ApproverDecision="+ApproverDecision+"&QCDecision="+QCDecision+"&ReportName=<%=request.getParameter("ReportName")%>&FromDate="+DateRangeFrom+"&ToDate="+DateRangeTo+"&UserEmailID="+UserEmailID+"";
	var URI ="VSRequestLifeCycleGenerate.jsp?QueueName="+QueueName+"&VendorRequestType="+VendorRequestType+"&VendorType="+VendorType+"&ApproverDecision="+ApproverDecision+"&QCDecision="+QCDecision+"&ReportName=<%=request.getParameter("ReportName")%>&FromDate="+DateRangeFrom+"&ToDate="+DateRangeTo+"&UserEmailID="+UserEmailID+"";
	var StrOpenWin=strip_tags(URI,"");
	window.top.VSLIFECYCLE.location.href=StrOpenWin;

}

	
	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}

</script>

<body topmargin="0" leftmargin="5" onunload="UnloadReportWindow();">

			<form name='textForm'  	method=Get>


			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">Vendor Setup Request Life Cycle Report</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This report will provide current status as well as complete movement of a workitem from the time of entry in the system till its exit.
</td></tr><tr><td class="EWLabel1"> 
Select All as Queue if the report has to be generated for the entire spectrum of the available Queues, else select the specific Queue, multiple selections are acceptable.<br>
Select All as Vendor Request Type if the report has to be generated for the entire spectrum of the available Vendor Request Types, else select the specific Vendor Request Type, multiple selections are acceptable.
</td></tr><tr><td class="EWLabel1"> 
Select All as Vendor Type if the report has to be generated for the entire spectrum of the available Vendor Types, else select the specific Vendor Type, multiple selections are acceptable.<br>
Select All as Approver Decision if the report has to be generated for the entire spectrum of the available Approver Decisions, else select the specific Approver Decision, multiple selections are acceptable.
</td></tr><tr><td class="EWLabel1">Select All as QC Decision if report is to be generated for the entire spectrum of the available QC Decisions, else select the specific QC Decision, multiple selections are acceptable.
</td></tr>
<tr><td class="EWLabel1">Select requisite Date Range for which report is to be generated.<br><b>Date Range is mandatory</b>
</td></tr>
</table>
<table border="0" width="95%" cellspacing="1" align="center">
<td colspan = 2 class="EWLabel1"><font color="RED">*</font> <b>Fields are Mandatory<b><BR></td>
				<tr>
				<td class="EWLabel1" align="left" width='20%'><b>Queue</b></td>
				<td width='45%' colspan=3>
					<select style='width:65%' name="Queue_Name" multiple>
					<option value="All">All</option>
					<option value="Introduction">Introduction</option>
					<option value="VendorSetup">VendorSetup</option>
					<option value="PendingResolution">PendingResolution</option>
					<option value="Cancel">Cancel</option>
					<option value="QC">QC</option>
					<option value="VendorApproval">VendorApproval</option>
					<option value="UpdateVendorChanges">UpdateVendorChanges</option>
					<option value="ChangeQC">ChangeQC</option>
					<option value="GEACInterface">GEACInterface</option>
					<option value="Exit">Exit</option>
					</select>
				</td>
				</tr>
				
				<tr>
				<td class="EWLabel1" align="left" width='20%'><b>Vendor Request Type</b></td>
				<td width='45%' colspan=3>
					<select style='width:65%' name="Vendor_Request_Type" multiple>
					<option value="All">All</option>
					<option value="New">New</option>
					<option value="Change">Change</option>
					</select>
				</td>
				</tr>

				<tr>
					<td class="EWLabel1" align="left" width='20%'><b>Vendor Type</b></td>
					<td width='45%' colspan=3>
					<select style='width:65%' name="Vendor_Type" multiple>
					<option value="All">All</option>
					<option value="Policyholder vendors">Policyholder vendors</option>
					<option value="Escheatment vendors">Escheatment vendors</option>
					<option value="Tax vendors">Tax vendors</option>
					<option value="PO vendors">PO vendors</option>
					<option value="Licensing and filing fee vendors">Licensing & filing fee vendors</option>
					<option value="Non PO Vendors">Non PO Vendors</option>
					</select>
					</td>
				</tr>
				
				<tr>
				<td class="EWLabel1" align="left" width='20%'><b>Approver Decision</b></td>
				<td width='45%' colspan=3>
					<select style='width:65%' name="Approver_Decision" multiple>
					<option value="All">All</option>
					<option value="Approved">Approve</option>
					<option value="Rejected">Reject</option>
					</select>
				</td>
				</tr>
				
				<tr>
				<td class="EWLabel1" align="left" width='20%'><b>QC Decision</b></td>
				<td width='45%' colspan=3>
					<select style='width:65%' name="QC_Decision" multiple>
					<option value="All">All</option>
					<option value="Fail">Fail</option>
					<option value="Pass">Pass</option>
					</select>
				</td>
				</tr>
				
				<tr>&nbsp;</tr>
				<tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>Date Range <font color="RED">*</font> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date" readonly type="text"  id="From_Date" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date" readonly type="text"  id="To_Date" >
					
					</td>

				</tr>
	
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID <font color="RED">*</font></b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>	
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
					<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
					<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>
			</form>
</body>
</Html>	 




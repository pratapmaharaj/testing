<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ include file="customized.process" %>
<%@ page import="com.tcsta.util.PathUtil" %>
<%@ page import="java.sql.*"%>

<HTML>
<HEAD>
<TITLE>Vendor Setup Request Lifecycle Report</TITLE>
</HEAD>

<link href="/webdesktop/CustomForms/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>

<body>
<%!

 public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }
%>
<%
	WriteLog("VSLifecycle_Report","Movement STATUS GENERATE START:11111");
	
	Connection conn = null;
	Statement st;
	String connectionUrl =""; 
	boolean empty=true;
	String sProcessDefId=null;
	String sProcedureName=null;
	String sColumnHeaders=null;
	String sFileName=null;
	String sNumberOfColumns=null;
	String sProcedureNameKey=null;
	String sColumnHeadersKey=null;
	String sFileNameKey=null;
	String sNumberOfColumnsKey=null;
	String sHeaderKey=null;
	String sHeaderPresentKey=null;
	String sDBMappedColsKey=null;
	String sHeaderValue=null;
	String sHeaderPresentValue=null;
	String sCabinetName=null;	
	String sDBMappedCols=null;
	String sFieldValuesKey=null;
	String sFieldValues=null;
	String sFieldValuesReport="";
	String sFilePathValue="";
	String sReportName=request.getParameter("ReportName");
	String sUserEmailID=request.getParameter("UserEmailID");
	
	sProcedureNameKey=sReportName +"_PROCEDURENAME";
	sColumnHeadersKey=sReportName+"_COLUMNHEADERS";
	sFileNameKey=sReportName+"_FILENAME";
	sNumberOfColumnsKey=sReportName+"_NUMBEROFCOLUMNS";
	sHeaderPresentKey=sReportName+"_HEADERPRESENT";
	sHeaderKey=sReportName+"_HEADER";
	sDBMappedColsKey=sReportName+"_DBMAPPEDCOLS";
	sFieldValuesKey=sReportName+"_FIELDVALUES";

	WriteLog("VSLifecycle_Report"," sInputXML FORM GENERTA 150");
	
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAVSRequestLifeCycleReport.ini";

	Properties ini = new Properties();
	
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("VSLifecycle_Report","Unable to read VSLifecycle_Report.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("VSLifecycle_Report","Unable to close the VSLifecycle_Report.ini file");
						}
					}
				}
				
	sProcedureName=ini.getProperty(sProcedureNameKey);
	sColumnHeaders=ini.getProperty(sColumnHeadersKey);
	sFileName=ini.getProperty(sFileNameKey);
	sNumberOfColumns=ini.getProperty(sNumberOfColumnsKey);
	sHeaderPresentValue=ini.getProperty(sHeaderPresentKey);
	sDBMappedCols=ini.getProperty(sDBMappedColsKey);
	sFieldValues=ini.getProperty(sFieldValuesKey);
	sFilePathValue=ini.getProperty("VSLIFECYCLE_FILEPATH");

	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("VSLifecycle_Report","sRootPathDBini="+sRootPathDBini);
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("VSLifecycle_Report","Unable to read VSLifecycle_Report.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("VSLifecycle_Report","Unable to close the VSLifecycle_Report.ini file");
						}
					}
				}

	String driverName = null;
	driverName=ini.getProperty("DRIVERNAME");
	connectionUrl=ini.getProperty("CONNECTIONSTRING");
	WriteLog("VSLifecycle_Report","driverName="+driverName+",conString="+connectionUrl);

	CallableStatement callableStatement = null;

	WriteLog("VSLifecycle_Report"," output "+connectionUrl);

	if(sHeaderPresentValue.equals("YES")) 
	{
		sHeaderValue=ini.getProperty(sHeaderKey);
	}
	
	String sFromDates = request.getParameter("FromDate");
	String sToDate = request.getParameter("ToDate");
	String sQueue = request.getParameter("QueueName");
	String sVendorRequestType = request.getParameter("VendorRequestType");
	String sVendorType = request.getParameter("VendorType");
	String sApproverDecision = request.getParameter("ApproverDecision"); 
	String sQCDecision = request.getParameter("QCDecision"); 

	WriteLog("VSLifecycle_Report","23 : "+sReportName);
	//WriteLog("VSLifecycle_Report","sRootPathini : "+sProcedureKey);
	WriteLog("VSLifecycle_Report","sProcedureName : "+sProcedureName);
	WriteLog("VSLifecycle_Report"," : "+sFilePathValue);
	
	String sCabname=null;
	String sSessionId = null;
	String sJtsIp = null;
	int iJtsPort = 0;
	String sUserName = null;
	String sStr_ServerType = null;
	
	String sColumnNamesArr[]=split(sColumnHeaders,',');
	String sDBMappedColsArr[]=split(sDBMappedCols,',');
	String sFinalColumns[]=split(sColumnHeaders,',');
	for(int i=0;i<sColumnNamesArr.length;i++)
	{
		if(sColumnNamesArr[i].indexOf("~D")!=-1)
			sFinalColumns[i]=sColumnNamesArr[i].substring(0,sColumnNamesArr[i].length()-2);

	}
	
	String sFieldNamesDB[]=split(sFieldValues,'#');

	for(int i=0;i<sFieldNamesDB.length;i++)
	{
		sFieldValuesReport=sFieldValuesReport+sFieldNamesDB[i]+',';
	}
	sFieldValuesReport=sFieldValuesReport.substring(0,sFieldValuesReport.length()-1);
	
	boolean bError=false;
	String getDBUSERByUserIdSql = "{call "+sProcedureName+"(?,?,?,?,?,?,?,?,?,?,?)}";
	String output = "" ;
	try
	{
			WriteLog("VSLifecycle_Report"," Params "+sProcedureName+"'"+sQueue+"', '"+sVendorRequestType+"', '"+sVendorType+"', '"+sApproverDecision+"', '"+sQCDecision+"', '"+sFromDates+"', '"+sToDate+"', '"+sFieldValuesReport+"', '"+sUserEmailID+"','"+sFilePathValue+"',''");
			Class.forName(driverName);
			conn = DriverManager.getConnection(connectionUrl);
			callableStatement = conn.prepareCall(getDBUSERByUserIdSql);
			callableStatement.setString(1, sQueue);
			WriteLog("VSLifecycle_Report"," sQueue "+sQueue);
			callableStatement.setString(2, sVendorRequestType);
			WriteLog("VSLifecycle_Report"," sVendorRequestType "+sVendorRequestType);
			callableStatement.setString(3, sVendorType);
			WriteLog("VSLifecycle_Report"," sVendorType "+sVendorType);
			callableStatement.setString(4, sApproverDecision);
			WriteLog("VSLifecycle_Report"," sApproverDecision "+sApproverDecision);
			callableStatement.setString(5, sQCDecision);
			WriteLog("VSLifecycle_Report"," sQCDecision "+sQCDecision);
			callableStatement.setString(6, sFromDates);
			WriteLog("VSLifecycle_Report"," sFromDates "+sFromDates);
			callableStatement.setString(7, sToDate);
			WriteLog("VSLifecycle_Report"," sToDate "+sToDate);
			callableStatement.setString(8, sFieldValuesReport);
			WriteLog("VSLifecycle_Report"," sFieldValuesReport "+sFieldValuesReport);
			callableStatement.setString(9, sUserEmailID);
			callableStatement.setString(10, sFilePathValue);
			WriteLog("VSLifecycle_Report"," sUserEmailID "+sUserEmailID);
			callableStatement.registerOutParameter(11, java.sql.Types.VARCHAR);
			callableStatement.execute();

			output = callableStatement.getString(11);
			WriteLog("VSLifecycle_Report"," output "+output);
	}
	catch(SQLException ignore)
	{
		%>
			<script>alert("Error While Generating Report");</script>
		<%
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		bError= true;
		WriteLog("VSLifecycle_Report"," WFSession Data Fetch Exception:::::: "+ignore.toString());
	}
	finally {
 
	if (callableStatement != null) {
        try {
            callableStatement.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
	}
	WriteLog("VSLifecycle_Report","bError : "+bError);
	if(!bError)
	{

		WriteLog("VSLifecycle_Report"," output:::::: "+output);
		try
		{

			if(output.equals(""))
			{
				bError= true;
				//maincode=sOutputXML.substring(sOutputXML.indexOf("<MainCode>")+10 , sOutputXML.indexOf("</MainCode>"));
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+output+"</b></font><center>");
			}
			else
			{
				
					try
							{
								 if(Integer.parseInt(output) == 0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
								out.println(ig.toString());
								%>
									<script>alert("Error While Generating Report");</script>
								<%
								WriteLog("VSLifecycle_Report"," Error:::::: "+ig.toString());
							}
			}
		}
		
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
			WriteLog("VSLifecycle_Report"," Error:::::: "+exp.toString());
			%>
				<script>alert("Error While Generating Report");</script>
			<%
		}
	}
%>
</body>
</html>
		
				


			
			





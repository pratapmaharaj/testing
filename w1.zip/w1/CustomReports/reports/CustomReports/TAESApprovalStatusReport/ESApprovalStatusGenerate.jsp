
<%@ include file="customized.process" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="java.sql.*"%>


<HTML>
<HEAD>
<TITLE>ES Approval Status Report</TITLE>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>



</script>


<body>
<%


	WriteLog("ESApproverStatusGenerate"," ::> Generate started : ");
	
	
	Statement st;
	
	boolean empty=true;
	
	
	String sProcedureName=null;
	
	String sReportName=null;
	String sFileName=null;
	
	String sProcedureNameKey=null;
	
	String sFileNameKey=null;
	
	String sUserMailID=null;//added by nilesh
	String fileName = "" ;
	String filePath="" ;

	sUserMailID=request.getParameter("UserEmailID");


	sReportName	=request.getParameter("ReportName");
	sReportName	=sReportName.toUpperCase();
	
	WriteLog("ESApproverStatusGenerate"," ::> sReportName : "+sReportName);
	sProcedureNameKey=sReportName +"_PROCEDURENAME";
	
	sFileNameKey=sReportName+"_FILENAME";
	
	
	
	WriteLog("ESApproverStatusGenerate"," ::> Initiation Completed : ");
	
	

	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAESApprovalStatusReport.ini";	
	WriteLog("ESApproverStatusGenerate"," ::> sRootPathini : "+sRootPathini);
	Properties ini = new Properties();
	//Unreleased dataresource release fix
	FileInputStream fis = null;
		try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("ESApproverStatusGenerate","Unable to read TAESApprovalStatusReport.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("ESApproverStatusGenerate","Unable to close the TAESApprovalStatusReport.ini file");
						}
					}
				}
	//ini.load(new FileInputStream(sRootPathini));
	WriteLog("ESApproverStatusGenerate"," ::> sRootPathini : "+sRootPathini);

	WriteLog("ESApproverStatusGenerate"," ::> filePath : "+sReportName+"_FILEPATH");
	filePath = ini.getProperty(sReportName+"_FILEPATH");

	fileName=ini.getProperty(sReportName+"_FILENAME") ;
	sProcedureName=ini.getProperty(sProcedureNameKey);
	WriteLog("ESApproverStatusGenerate"," ::> sProcedureName : "+sProcedureName);
	sFileName=ini.getProperty(sFileNameKey);
	WriteLog("ESApproverStatusGenerate"," ::> sFileName : "+sFileName);
	WriteLog("ESApproverStatusGenerate"," ::> Read INI Completed : ");
	WriteLog("ESApproverStatusGenerate"," ::> sProcedureName : "+sProcedureName);
	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("ESApproverStatusGenerate","sRootPathDBini="+sRootPathDBini);
	
	//Unreleased dataresource release fix
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("ESApproverStatusGenerate","Unable to DBReports.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("ESApproverStatusGenerate","DBReports.ini file");
						}
					}
				}
				
	//ini.load(new FileInputStream(sRootPathDBini));
	String driverName = null;

	String connectionUrl=ini.getProperty("CONNECTIONSTRING");
	driverName = ini.getProperty("DRIVERNAME");
	WriteLog("ESApproverStatusGenerate"," connectionUrl "+connectionUrl);

	String Queue=request.getParameter("Queue");
	String DateRangeFrom=request.getParameter("DateRangeFrom");
	String DateRangeTo=request.getParameter("DateRangeTo");
	String sApproval_decision=request.getParameter("sApproval_decision");
	
	WriteLog("ESApproverStatusGenerate"," ::> Request----> : &Queue="+Queue+"&DateRangeFrom="+DateRangeFrom+"&DateRangeTo="+DateRangeTo+"&sApproval_decision="+sApproval_decision);


	

	boolean bError=false;
	CallableStatement callableStatement = null;
	Connection conn=null;		

	String getDBUSERByUserIdSql = "{call "+sProcedureName+"(?,?,?,?,?,?,?,?)}";
	String output = "" ;
	try
	{
			Class.forName(driverName);
			conn = DriverManager.getConnection(connectionUrl);
			callableStatement = conn.prepareCall(getDBUSERByUserIdSql);
			callableStatement.setString(1, Queue);
			callableStatement.setString(2, DateRangeFrom);
			callableStatement.setString(3, DateRangeTo);
			callableStatement.setString(4, sApproval_decision);
			callableStatement.setString(5, sUserMailID);
			callableStatement.setString(6, filePath);
			callableStatement.setString(7, fileName);
			callableStatement.registerOutParameter(8, java.sql.Types.VARCHAR);
			callableStatement.execute();

			output = callableStatement.getString(8);
			WriteLog("ESApproverStatusGenerate"," output "+output);
	}
	catch(SQLException ignore)
	{
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		bError= true;
		WriteLog("ESApproverStatusGenerate"," WFSession Data Fetch Exception:::::: "+ignore.toString());
	}
	finally {
 
	if (callableStatement != null) {
        try {
            callableStatement.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
	}

	if(!bError)
	{

		WriteLog("ESApproverStatusGenerate"," output:::::: "+output);
		try
		{

			if(output.equals(""))
			{
				bError= true;
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+output+"</b></font><center>");
			}
			else
			{
				
					try
							{
								 if(Integer.parseInt(output) == 0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
								out.println(ig.toString());
												
							}
			}
		}
		
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
			out.println("ESApproverStatusGenerate "+exp.toString());
		}
		
	}
	
	%>

			
		
			<FORM name="textForm">

			</form>	
		
	
			

<%!
 public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }


%>





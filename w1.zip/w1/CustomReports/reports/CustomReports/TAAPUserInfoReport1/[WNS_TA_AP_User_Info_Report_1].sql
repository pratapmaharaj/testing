/*        
        
WNS_TA_AP_User_Info_Report_1 '01/FEB/2014','08/FEB/2014','anudeep~KCarter~kuldeep~sweejo~ta~ta1~ta2~ta3~testumg~yogeshb~','LogDate,b.UserName,LoginTime,LogoutTime,totalloggedintime','ddd@ww.com','//10.33.192.139/XLS-File/Yogesh/UserInfReport1'      
      
select distinct username from pdbuser where userindex in(select distinct(userindex) from pdbgroupmember where groupindex in (select distinct(groupindex) from pdbgroup where Groupname like '%TA_APVS%'))      
      
      
*/        
        
        
CREATE PROCEDURE [dbo].[WNS_TA_AP_User_Info_Report_1]        
(        
@RegDateRangeFrom  VARCHAR(100),      
@RegDateRangeTo  VARCHAR(100),      
@UserName varchar(1000),      
@Fields varchar(8000),      
@EmailID varchar(200),      
@Path nvarchar(250),    
@RowCount varchar(200) OUTPUT      
)      
AS       
declare      
 @WhereQuery varchar(2000),      
 @Query varchar(5000),      
 @QueryFinal varchar(5000),      
 @Tables varchar(200),      
 @UserNameReport varchar(1000),      
 @OrderBy varchar(300),      
 @OrderByFinal varchar(300),      
 @FileName varchar(200),     
 @USERNAMESUM varchar(100),      
 @ACTIVITYNAME varchar(100),       
 @WI_PROCESSED varchar(100),       
 @AVG_TIME varchar(100),        
 @status_temp varchar(8000)         
      
 Set nocount on      
 BEGIN       
      
  if Object_ID('#AP_TEMP_TABLE_UserInfo1') is not null         
  begin         
   print 'Table dropped'         
   exec('drop table #AP_TEMP_TABLE_UserInfo1')         
  end      
        
  CREATE TABLE #AP_TEMP_TABLE_UserInfo1       
  (      
  LogDate nvarchar(200),       
  UserName varchar(200),        
  LoginTime nvarchar(200),      
  LogoutTime varchar(200),        
  TotalLoggedInTime varchar(200)        
  )        
  set @FileName=@Path+'/'+@EmailID+'_NG_VS_UserInfo1_Report_'+convert(varchar,getdate(),104)+'.xls'        
        
  set @WhereQuery='WHERE '        
  set @UserNameReport=''       
  set @OrderBy=' order by a.logdate '         
  set @OrderByFinal=' order by a.logdate '       
  set @RowCount ='0'       
        
  print 'Obtained Users '+@UserName        
  set @Tables='AP_USER_LOGIN_LOGOUT_INFO a WITH (NOLOCK), pdbuser b WITH (NOLOCK)'        
        
  if(rtrim(ltrim(@RegDateRangeFrom))<>'')      
   SET @RegDateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@RegDateRangeFrom,121)))))       
  if(rtrim(ltrim(@RegDateRangeTo))<>'')      
   SET @RegDateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@RegDateRangeTo,121)))))        
      
  set @WhereQuery=@WhereQuery + ' a.userid=b.userindex and a.logdate between ''' +@RegDateRangeFrom+''' and '''+@RegDateRangeTo+''''      
  --uname        
  if(rtrim(ltrim(@UserName))<>'All~')      
  BEGIN         
   if(len(@UserName)=charindex('~',@UserName))       
   BEGIN      
    set @UserNameReport=ltrim(rtrim(substring(@UserName,0,len(@UserName))))      
    set @WhereQuery=@WhereQuery+' AND b.UserName='''+@UserNameReport+''''      
   END      
   else      
   BEGIN       
    while (charindex('~',@UserName)>1)          
    BEGIN      
     set @UserNameReport = @UserNameReport + ''''+ltrim(rtrim(SUBSTRING(@UserName,1,Charindex('~',@UserName)-1)))+''''+','      
     set @UserName=ltrim(rtrim(Substring(@UserName,Charindex('~',@UserName)+len('~'),len(@UserName))))       
    END      
      
    set @UserNameReport=substring(@UserNameReport,0,len(@UserNameReport))      
    set @WhereQuery=@WhereQuery+' AND b.UserName in('+@UserNameReport+')'      
   END      
  END      
      
  print @Fields       
        
  SET @Query=' SELECT '+@Fields+' from '+ @Tables + @WhereQuery + @OrderBy      
         
  print  @Query         
  set @Query='insert into #AP_TEMP_TABLE_UserInfo1 '+ @Query       
  exec(@Query)      
        
  set @QueryFinal=' select LogDate,UserName,LoginTime,LogoutTime,TotalLoggedInTime from #AP_TEMP_TABLE_UserInfo1 with(nolock)'+@OrderByFinal      
  print @QueryFinal      
  select @RowCount=count(*) from #AP_TEMP_TABLE_UserInfo1 with(nolock)       
  if(@RowCount=0)         
  Begin         
   drop table #AP_TEMP_TABLE_UserInfo1         
  End         
  else        
  Begin       
   if Object_ID ('NG_TEMP_AUTOMAIL') is not null      
   BEGIN      
    exec('drop table NG_TEMP_AUTOMAIL')      
   END       
         
   Exec('Create table NG_TEMP_AUTOMAIL (Header varchar(8000),ROw_Index [int] identity(1,1) not null)')        
   exec('Insert into NG_TEMP_AUTOMAIL      
   Select  ''<html>       
   <style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>      
    <table border=1>      
 <tr align="left"><td colspan=5 class=headerbold align="left">      
 <center>                  
 TA Vendor Setup User Info Report 1</center></td></tr>      
 </table>  <br>      
   <table border=1>       
   <tr>       
   <td class=headerbold>Log Date</td>''+       
   ''<td class=headerbold>User Name</td>''+      
   ''<td class=headerbold>Login Time</td>''+      
   ''<td class=headerbold>Logout Time</td>''+        
   ''<td class=headerbold>Total Logged in Time</td>''+      
   +''</tr></font>''      
         
   UNION ALL      
   Select ''<tr><td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([LogDate],''''),120)+''</td>''+           
   ''<td align=left style=mso-number-format:\\@>''+CONVERT(CHAR(19),ISNULL([UserName],''''),120)+''</td>''+      
   ''<td align=left style=mso-number-format:\\@>''+CONVERT(CHAR(19),ISNULL([LoginTime],''''),120)+''</td>''+      
   ''<td align=left style=mso-number-format:\\@>''+CONVERT(CHAR(19),ISNULL([LogoutTime],''''),120)+''</td>''+      
   ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+ISNULL([totalloggedintime],''0'')+''</td>''         
   ''</tr>''      
   from #AP_TEMP_TABLE_UserInfo1')        
      
   --select @status_temp='</tr></table><table><tr><td><b>USER</b></td></tr>'      
   select @status_temp=@status_temp+'</table>'      
   exec('insert into NG_TEMP_AUTOMAIL select '''+@status_temp+'''')      
      
   update NG_TEMP_AUTOMAIL set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yy>&nbsp</td>')         
       
   SET @Query='Master..xp_Cmdshell ''bcp "select Header FROM GMAC..NG_TEMP_AUTOMAIL order by row_index asc" queryout "'+@FileName+'" -c -T'',no_output'         
      
   --select * from  NG_TEMP_AUTOMAIL      
   exec(@Query)         
      
   insert into NG_AutoMail_Status values('APVS UserInfo1 Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL)        
      
   drop table #AP_TEMP_TABLE_UserInfo1        
   drop table NG_TEMP_AUTOMAIL       
  End      
  select @RowCount      
      
 End 
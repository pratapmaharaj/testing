<%@ include file="customized.process" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>


 
 <HTML>
<HEAD>
<TITLE>AP User Info Report 1</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>
</HEAD>

<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>
<script src="../../GMAC/Scripts/Common.js"></script>
<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
}
</style>
<%	
	String sCabname="";
	String sSessionId = "";
	String sJtsIp = "";
	String sInputXML="";
	String sOutputXML="";
	String sprocessdefid="";
	String sGroupname="";
	String sGroupid="";
	String sUserID="";
	String sUserName1="";
	int iJtsPort = 0;
	String Query="";
	String sTempGroupName="";
	String sStr_ServerType="";
	String sNoOfCols="" ;
	try{
	//sCabname=wfSession.getM_strCabName();
	//sSessionId  = wfSession.getM_strSessionID();
	//sJtsIp      = wfSession.getM_objCabinet().getM_strServerIP();
	//iJtsPort    = wfSession.getM_objCabinet().getM_iServerPort();
		sCabname=wfsession.getEngineName();	
		sSessionId = wfsession.getSessionId();	
		sJtsIp = wfsession.getJtsIp();
		iJtsPort = wfsession.getJtsPort();
    //sStr_ServerType = wfSession.getM_objCabinet().getM_strServerType();
	}catch(Exception e){
		System.out.println("User Info 1 Report "+e);
	}
	
	try
	{
		
			String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAAPUserInfoReport1.ini";
			//String sRootPathini=application.getRealPath("")+File.separator+"reports"+File.separator+"GMACReports"+File.separator+"ApprovalProcessUserInfoReport1" + File.separator + "Report.ini";

			Properties ini = new Properties();
			
			FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("1_APUSERINFO","Unable to close the 1_APUSERINFO.ini file");
						}
					}
				}
			
			
			sGroupname     =ini.getProperty("GROUPNAMES");
			sTempGroupName ="'"+sGroupname.replaceAll(",","','")+"'";
			sGroupname     =  sGroupname.replaceAll(",","~");

			Query="select distinct b.username from pdbgroupmember a,pdbuser b where a.groupindex in(select groupindex from pdbgroup where groupname in ("+sTempGroupName+")) and a.userindex=b.userindex and a.userindex<>1";
			
			WriteLog("1_APUSERINFO ","sOutputXML ::> sOutputXML : "+Query);
			
				sInputXML = "<?xml version=\"1.0\"?><WMTestSelect_Input><Option>WFSelectTest_new</Option><sQry>" + Query + "</sQry>><EngineName>" + sCabname + "</EngineName>"+"<NoOfCols>"+"1"+"</NoOfCols><SessionId>"+sSessionId+"</SessionId></WMTestSelect_Input>";
				//System.out.println("AP user Info 1 Report "+sInputXML);
				WriteLog("1_APUSERINFO ","sOutputXML ::> sOutputXML : "+sInputXML);

			//sOutputXML = WFCallBroker.execute(sStr_ServerType,"",sInputXML,sJtsIp,iJtsPort,1);
			try{
			sOutputXML = WFCallBroker.execute(sInputXML,sJtsIp,iJtsPort,1);
			}catch(Exception e){
				System.out.println(e);
				
			}
			WriteLog("1_APUSERINFO ","sOutputXML ::> sOutputXML : "+sOutputXML);
			System.out.println("AP user Info 1 Report "+sOutputXML);
			WFXmlResponse xmlResponseU = new WFXmlResponse(sOutputXML);
			WFXmlList RecordListU;
			for (RecordListU =  xmlResponseU.createList("Results", "Result");RecordListU.hasMoreElements();RecordListU.skip())
			{
			sUserName1 = sUserName1 + RecordListU.getVal("Result") + "~";
			}
				WriteLog("1_APUSERINFO ","sOutputXML ::> sOutputXML : sUserName1 - "+sUserName1);
				
		}
		catch(Exception e)
		{
		out.println("Exception:" + e.toString());
		out.println("sOutputXML:"+sOutputXML);
		}
%>

<script>
	$(document).ready(function(){$('#From_Date_disp').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date_disp').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	
	});
	var userList = "" ;
	var FromDate = new Date();
	var type = '';
	var allWindows = new Array();
	var win; // new window object

	function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}
	
	function ValidateForm(emailID){
//	var emailID=document.frmSample.txtEmail
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }

	
	function ChangeDateTag(obj)
	{	
		var InsertVal='';
	for(iterate=0;iterate<obj.length;iterate++)
	{
		if(obj.options[iterate].selected==true)
		{
			InsertVal=InsertVal+obj.options[iterate].value+'/';
		}
	}
	InsertVal=InsertVal.substring(0,InsertVal.length-1);
	var Table=document.getElementById('newgen');
	var lastRow = Table.rows.length;
	if (lastRow > 0) Table.deleteRow(lastRow - 1);
	while(InsertVal.indexOf('_')!=-1)
	{
		InsertVal=InsertVal.replace('_',' ');
	}
	var Row=Table.insertRow(0);
	var Cell=Row.insertCell();
	Cell.className="EWLabelBoldNew";
	Cell.innerHTML=InsertVal;
	}
	function ShowCalendar(obj)
	{	
		textForm.all[obj].value =  "";
		var xaxis;
		var yaxis;
		xaxis = event.screenX;
		yaxis = event.screenY;
		var sDate="";
		sDate	= window.showModalDialog('/processmanager/reports/GMACReports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');
		if(sDate!="")
		{
			tempdate=convertdate(sDate);
			textForm.all[obj].value = tempdate;
		}
	}
	function convertdate(sLocalDate)
	{
		var sDateSeparator="/";
		var strResult;
		var nBegIndex   =sLocalDate.indexOf(sDateSeparator);
		var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
		var strdate     = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
		var stryear     = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
		var strMonth    =strtempdate;
		strResult       =strdate+"-"+strMonth+"-"+stryear;
		return strResult;
	}
	//As per the BNL Format
	function convertdateBnL(sLocalDate)
	{
		var sDateSeparator="-";
		var strResult;
		var nBegIndex   =sLocalDate.indexOf(sDateSeparator);
		var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
		var strdate     = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
		var stryear     = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
		var strMonth    ="";
		if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";
		strResult = strdate+"/"+strMonth+"/"+stryear;
		alert(strResult);
		return strResult;
	}
//Date comparator and future date checking in terms of time
function DateComparator(Date_From,Date_To)
{	
	var FromDay   = Date_From.split("-")[0];
	var FromMonth = Date_From.split("-")[1]-1;
	var FromYear  = Date_From.split("-")[2];

	var ToDay   = Date_To.split("-")[0];
	var ToMonth = Date_To.split("-")[1]-1;
	var ToYear  = Date_To.split("-")[2];

	var CurrentDate  =new Date();
	var CurrentDay   = CurrentDate.getDate();
	var CurrentMonth = CurrentDate.getMonth();
	//var CurrentYear  = CurrentDate.getYear();
	var CurrentYear  = CurrentDate.getFullYear();

	var toDate      = (new Date(ToYear,ToMonth,ToDay)).getTime();
	var fromDate    = (new Date(FromYear,FromMonth,FromDay)).getTime();
	var CurrentDate = (new Date(CurrentYear,CurrentMonth,CurrentDay)).getTime();

	if(fromDate > toDate)
	{
		alert("To Date can not be less than From Date.");
		return false;
	}
	else if(fromDate > CurrentDate)
	{
		alert("From Date can not be future date .");
		return false;
	}
	else if(toDate > CurrentDate)
	{
		alert("To Date can not be future date ");
		return false;
	}
	return true;
}

	function FillUserCombo()
	{
	
		var sGroupname='<%=sGroupname%>';
		var UserNames='<%=sUserName1%>';
		var UserNameArray=UserNames.split('~');
		userList = UserNames ;

		for (var j=0;j<UserNameArray.length-1;j++)
		{
			optn=document.createElement("option");	
			req=document.getElementById("User");
			optn.text=UserNameArray[j];
			optn.value=UserNameArray[j];		
			req.options.add(optn);	
		}
	}
	
	/*function openreport()
	{
		var From_Date = document.forms["textForm"].From_Date.value;
		var To_Date   = document.forms["textForm"].To_Date.value;
		var UserEmailID = document.getElementById('EMail-ID').value;
		var fromHH = document.getElementById('FHours').value ;
		var toHH   = document.getElementById('THours').value ;
		var fromMM = document.getElementById('FMins').value ;
		var toMM   = document.getElementById('TMins').value ;
		//alert (fromHH+":"+fromMM+"  "+toHH+":"+toMM) ;
		var UserNameForm="";
		var GroupName="";
		var FinalUserNames="";

		// Validate user list
		for(var l=0;l<document.forms["textForm"].User.length;l++)
		{
			if(document.forms["textForm"].User[l].selected)
			{
				
				UserNameForm=UserNameForm+document.forms["textForm"].User[l].value+'~';
				
			}
		}

		if(GroupName=="\'\'")
		{
			GroupName="";
		}

		if(UserNameForm=="~")
		{
			UserNameForm="";
		}

		var sGroups=GroupName.split('~');
		var sUsers=UserNameForm.split('~');

		if(sGroups!="")
		{
			ServerRequest("Select_User.jsp","GroupName="+encodeURIComponent(GroupName));
			if (iAjaxMainCode=="15")
			{
				alert('Internal Server error.Please try again later.');
				return false;
			}
			else if (sAjaxReturnValue=="")
			{
				alert('Internal Server error.Please try again later.');
				return false;
			}
			else
			{
				FinalUserNames=sAjaxReturnValue;
			}
		}	
		if(sUsers!="")
		{
				FinalUserNames=UserNameForm;
		}
	}*/
	function openreport()
	{	//changed by megha
		
		//var From_Date = document.forms["textForm"].From_Date.value;
		//var To_Date   = document.forms["textForm"].To_Date.value;
		var From_Date = document.getElementById('From_Date_disp').value;
		var To_Date   = document.getElementById('To_Date_disp').value;
		var GroupName="";
		var UserNameForm="";
		var FinalUserNames="";
		var UserEmailID="";
		var fromHH = document.getElementById('FHours').value ;
		var toHH   = document.getElementById('THours').value ;
		var fromMM = document.getElementById('FMins').value ;
		var toMM   = document.getElementById('TMins').value ;
		var UserNames = '<%=sUserName1%>';
		UserEmailID=document.getElementById('EMail-ID').value;
		///For Users

		for(var l=0;l<document.forms["textForm"].User.length;l++)
		{
			if(document.forms["textForm"].User[l].selected)
			{
				
				UserNameForm=UserNameForm+document.forms["textForm"].User[l].value+'~';
				
			}
		}

		///For Users
		
		var sUserName=document.getElementById('User').value;
		if(sUserName=='')
		{
			alert('Please Select User Name');
			return false;
		}

		if(GroupName=="\'\'")
		{
			GroupName="";
		}

		if(UserNameForm=="~")
		{
			UserNameForm="";
		}

		var sGroups=GroupName.split('~');
		var sUsers=UserNameForm.split('~');

		if(UserNameForm.indexOf("All")!=-1 && sUsers.length>2)
		{
			alert("No other User can be chosen after choosing All.");
			return false;
			//QueueName='All~';
		}  

		if(UserNameForm==userList)
		{
			UserNameForm='All~';
		}

		if(sGroups!="")
		{
				ServerRequest("Select_User.jsp","GroupName="+encodeURIComponent(GroupName));
				if (iAjaxMainCode=="15")
				{
					alert('Internal Server error.Please try again later.');
					return false;
				}
				else if (sAjaxReturnValue=="")
				{
					alert('Internal Server error.Please try again later.');
					return false;
				}
				else
				{
					FinalUserNames=sAjaxReturnValue;
				}
			}	
			if(sUsers!="")
			{
					FinalUserNames=UserNameForm;
			}

			/*added by nilesh for email validation*/
		if(UserEmailID=='')
		{
			alert("Please enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
			}
		}
	
		if(From_Date == "")
		{
			alert("Please select an appropriate From Date");
			
			return false;
		}
		else if(To_Date == "")
		{
			alert("Please select an appropriate To Date");
			return false;
		}
		else if(!DateComparator(From_Date,To_Date))
		{
			return false;
		}

		if (From_Date ==To_Date)
		{
			if ((fromHH == toHH)&&(fromMM == toMM))
			{
				alert("From time and To time is equal for the same date.Kindly select proper Date/Time.");
				return false;
			}
			else if ((fromHH == toHH)&&((fromMM > toMM)))
			{
				//alert("FMins "+document.getElementById('FMins').value+" TMins "+document.getElementById('TMins').value);
				alert("From time is greater than To time for the same date.Kindly select proper Date/Time.");
				return false;
			}
			else if (fromHH > toHH)
			{
				alert("From time is greater than To time for the same date.Kindly select proper Date/Time.");
				return false;
			}
		}
		//changed by megha
		//var DateRangeFrom = convertdateBnL(From_Date);
		//var DateRangeTo   = convertdateBnL(To_Date);
		var DateRangeFrom = From_Date;
		var DateRangeTo   = To_Date;

		var FTime=document.getElementById("FHours").value+":"+document.getElementById("FMins").value;
		var TTime=document.getElementById("THours").value+":"+document.getElementById("TMins").value;

		if((UserEmailID!='')&&(UserNames!='')&&(From_Date!='')&&(To_Date !=''))
		{
			//alert(UserNames) ;
		//OpenRedict-Fix
		//window.top.USERINFO1.location.href="APUserInfoGenerate.jsp?FromDates="+DateRangeFrom+"&ToDate="+DateRangeTo+"&FTime="+FTime+"&TTime="+TTime+"&ReportName=<%=request.getParameter("ReportName")%>&UserNames="+UserNames+"&UserEmailID="+UserEmailID;
		
		var URI = "APUserInfoGenerate.jsp?FromDates="+DateRangeFrom+"&ToDate="+DateRangeTo+"&FTime="+FTime+"&TTime="+TTime+"&ReportName=<%=request.getParameter("ReportName")%>&UserNames="+UserNames+"&UserEmailID="+UserEmailID;
		var StrOpenWin=strip_tags(URI,"");
		window.top.USERINFO1.location.href=StrOpenWin;
		
		}
		return true; 
}
	
	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}
function copyValue(obj,obj1)
{
	if(obj.value=='')
	{
		return "" ;
	}
	var date1 = obj.value.split("-") ;
	//alert(obj.value) ;
	var strtempdate = date1[1] ;
	//alert(strtempdate) ;
	var strMonth = "" ;
		if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";
	//alert(strMonth) ;
	obj1.value = date1[0]+"/"+strMonth+"/"+date1[2] ;
}
</script>

	<body topmargin="0" leftmargin="5" onload="FillUserCombo();">
	<form name='textForm' method=post>
	<table border="0" width="100%" cellspacing="0" cellpadding="0">
		<tr>
			<td width="90%"><img src="../../../omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
		</tr>
		<tr>
			<td class="EWSubHeader" colspan="2"><b>TA AP User Info Report 1</b></td>
		</tr>
		<tr>
			<td width="90%">&nbsp;</td>
		</tr>
		<tr>  
			<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">The Report provides the total logged in time of the selected User between the specified Date Ranges.</td></tr><tr><td class="EWLabel1"> 
				Please select a User for which the Report has to be generated and a suitable Date Range for which the total logged in time has to be Calculated.Both are mandatory.
			</td>
		</tr>
		</tr>
		
		<td>
		<br/>
		<p style="color: red; font-size: 10pt">Note:  * fields are mandatory.</p>

		</td>
		</tr>
	</table>
	<table border="0" width="95%" cellspacing="1" align="center">
		<tr>
			<td valign="center" width="100%" colspan=4 height=12></td>
		</tr>
		<tr>  
			<td valign="center" width="100%" colspan=4 class="EWLabel1" align="left"></td>
		</tr>
		<tr>
					<td class="EWLabel1" align="left"><b>User Name <font color="RED">*</font></b></td> 
					<td width='25%'>
						<select STYLE='width:33%' class='TextFieldColor'  name="User" id="User" multiple onchange=''>
						<option value="All">--All--</option>

						</select>
					</td>

		</tr>

		<tr>&nbsp;</tr>
		<tr>&nbsp;</tr>
		<tr>
		<tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>Date Range<font color="RED">*</font></b><br> 
					</td>
					
					<td class="EWLabel1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					&nbsp;<b>HH</b>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>MM</b></td>
					</tr>
					<tr><td class="EWLabel1" align="left" width='20%'>
					<b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date"  type="hidden"  id="From_Date">
					<input class='TextFieldColorDate' name="From_Date_disp" readonly type="text"  id="From_Date_disp">
					
					
					<select name="FHours" id="FHours">
					<option value="00">00</option>
					<option value="01">01</option>
					<option value="02">02</option>
					<option value="03">03</option>
					<option value="04">04</option>
					<option value="05">05</option>
					<option value="06">06</option>
					<option value="07">07</option>
					<option value="08">08</option>
					<option value="09">09</option>
					<option value="10">10</option>
					<option value="11">11</option>
					<option value="12">12</option>
					<option value="13">13</option>
					<option value="14">14</option>
					<option value="15">15</option>
					<option value="16">16</option>
					<option value="17">17</option>
					<option value="18">18 </option>
					<option value="19">19</option>
					<option value="20">20</option>
					<option value="21">21</option>
					<option value="22">22</option>
					<option value="23">23</option>
 					</select>
				 
				 <select name="FMins" id="FMins">
				<%
					for(int i=0;i<60;i++)
					{
					%>
					<option value='<%=i%>'><%= i %></option>
					<%} 
				%>
					</tr>
					</select></td>
				 
					
					<tr>
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date"  type="hidden"  id="To_Date" >
					<input class='TextFieldColorDate' name="To_Date_disp" readonly type="text"  id="To_Date_disp" >
					
				
					<select name="THours" id="THours">
					<option value="00">00</option>
					<option value="01">01</option>
					<option value="02">02</option>
					<option value="03">03</option>
					<option value="04">04</option>
					<option value="05">05</option>
					<option value="06">06</option>
					<option value="07">07</option>
					<option value="08">08</option>
					<option value="09">09</option>
					<option value="10">10</option>
					<option value="11">11</option>
					<option value="12">12</option>
					<option value="13">13</option>
					<option value="14">14</option>
    				<option value="15">15</option>
					<option value="16">16</option>
					<option value="17">17</option>
					<option value="18">18</option>
					<option value="19">19</option>
					<option value="20">20</option>
					<option value="21">21</option>
					<option value="22">22</option>
					<option value="23">23</option>
 					</select>
				 
				 <select name="TMins" id="TMins">
				 <%
					for(int j=0;j<60;j++)
					{
					%>
					<option value='<%=j%>'><%=j%></option>
					<%} %>
					</tr>
					</select>
					</td>
					
						</td>
				</tr>
				
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID<font color="RED">*</font></b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>

	</table>			
	<br><br>
	<table border="0" width="100%" cellspacing="1">
		<tr>    
			<td valign="center" width="100%" colspan=4><p align="center">
				<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
				<input type="button" value="Cancel"   name="B2"  class="EWButton" onclick="window.parent.close(); return false;">
			</td>
		</tr>
	</table>
</form>
</body>
</html>	 
<%!
public static String ParseResult(String str)
{
	String sReturn="";
	if(str.indexOf("<Results>")>-1)		
	{
		if(str.indexOf("<Result>")>-1)
		{
			try
			{
				WFXmlResponse xmlResponse = new WFXmlResponse(str);
				WFXmlList RecordList;
				for (RecordList =  xmlResponse.createList("Results", "Result");RecordList.hasMoreElements();)
				{
					sReturn = sReturn + RecordList.getVal("Result") + "~";				
					RecordList.skip();
				}  
				if(!(sReturn.equals("")))
				{
						sReturn=sReturn.substring(0,sReturn.length()-1);
				}
			}catch(Exception e)
			{
				e.getMessage();
			}
		}
		else
		{
			sReturn=str.substring(str.indexOf("<Results>")+9,str.indexOf("</Results>"));
		}
	}
	else
	{
		sReturn="";
	}
	return sReturn;
}
%>

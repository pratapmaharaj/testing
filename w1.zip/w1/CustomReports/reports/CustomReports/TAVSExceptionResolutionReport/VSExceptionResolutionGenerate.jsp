
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ include file="customized.process" %>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="java.sql.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>

<HTML>
<HEAD>
<TITLE>Vendor Setup Exception Resolution Report</TITLE>
</HEAD>

<link href="/webdesktop/CustomForms/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>

<body>
<%
		
	Connection conn = null;
	Statement st;
	String connectionUrl =""; 
	boolean empty=true;
	String sProcedureName=null;
	String sColumnHeaders=null;
	String sReportName=null;
	String sFileName=null;
	String sNumberOfColumns=null;
	String sProcedureNameKey=null;
	String sColumnHeadersKey=null;
	String sFileNameKey=null;
	String sNumberOfColumnsKey=null;
	String sHeaderKey=null;
	String sHeaderPresentKey=null;
	String sDBMappedColsKey=null;
	String sHeaderValue=null;
	String sHeaderPresentValue=null;
	String sCabinetName=null;	
	String sDBMappedCols=null;
	String sFieldValuesKey=null;
	String sFieldValues=null;

	String sUserMailID=null;//added by nilesh
	String sPath="" ;

	WriteLog("VSExceptionResolutionREPORT","Start ::> Start : ");

	sUserMailID=request.getParameter("UserEmailID");
	sReportName	=request.getParameter("ReportName");
	sReportName	=sReportName.toUpperCase();
	sProcedureNameKey=sReportName +"_PROCEDURENAME";
	sColumnHeadersKey=sReportName+"_COLUMNHEADERS";
	sFileNameKey=sReportName+"_FILENAME";
	sNumberOfColumnsKey=sReportName+"_NUMBEROFCOLUMNS";
	sHeaderPresentKey=sReportName+"_HEADERPRESENT";
	sHeaderKey=sReportName+"_HEADER";
	sDBMappedColsKey=sReportName+"_DBMAPPEDCOLS";
	sFieldValuesKey=sReportName+"_FIELDVALUES";
	sPath=sReportName+"_PATH" ;

	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAVSExceptionResolutionReport.ini";

	Properties ini = new Properties();
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("VSExceptionResolutionREPORT","Unable to read VSExceptionResolutionREPORT.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("VSExceptionResolutionREPORT","Unable to close the VSExceptionResolutionREPORT.ini file");
						}
					}
				}
				
	sProcedureName=ini.getProperty(sProcedureNameKey);
	sColumnHeaders=ini.getProperty(sColumnHeadersKey);
	sFileName=ini.getProperty(sFileNameKey);
	sNumberOfColumns=ini.getProperty(sNumberOfColumnsKey);
	sHeaderPresentValue=ini.getProperty(sHeaderPresentKey);
	sDBMappedCols=ini.getProperty(sDBMappedColsKey);
	sFieldValues=ini.getProperty(sFieldValuesKey);
	sFieldValues=sFieldValues.replaceAll("#",",");
	sPath=ini.getProperty(sPath);

	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("VSExceptionResolutionREPORT","sRootPathDBini="+sRootPathDBini);
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("VSExceptionResolutionREPORT","Unable to read VSExceptionResolutionREPORT.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("VSExceptionResolutionREPORT","Unable to close the VSExceptionResolutionREPORT.ini file");
						}
					}
				}
				

	String driverName = null;
	driverName=ini.getProperty("DRIVERNAME");
	connectionUrl=ini.getProperty("CONNECTIONSTRING");
	WriteLog("VSExceptionResolutionREPORT","driverName="+driverName+",conString="+connectionUrl);

	CallableStatement callableStatement = null;

	WriteLog("VSExceptionResolutionREPORT"," output "+connectionUrl);

	if(sHeaderPresentValue.equals("YES")) {
	sHeaderValue=ini.getProperty(sHeaderKey);

	}

	String sCabname=null;
	String sSessionId = null;
	String sJtsIp = null;
	String sUserName = null;
	String sReportProcedureName=null;
	String sReportTableName=null;

	String QueueName=request.getParameter("QueueName");
	String VendorType=request.getParameter("VendorType");
	String VendorRequestType=request.getParameter("VendorRequestType");
	String sExp=request.getParameter("sExp");
	String sFromDate=request.getParameter("FromDates");
	String sToDate=request.getParameter("ToDate");

	String sOutputXML="";
	String sInputXML = "";
	String maincode = "";
	String Totalrec = "0";
    String sStr_ServerType = null;
	String url = "";
	String Status="";
	double fPercentage=0;
	String sColumnNamesArr[]=split(sColumnHeaders,',');
	String sDBMappedColsArr[]=split(sDBMappedCols,',');
	String sRowXml="";
	String sFinalColumns[]=split(sColumnHeaders,',');
	for(int i=0;i<sColumnNamesArr.length;i++)
	{
		if(sColumnNamesArr[i].indexOf("~D")!=-1)
			sFinalColumns[i]=sColumnNamesArr[i].substring(0,sColumnNamesArr[i].length()-2);

	}

	int iJtsPort = 0;
	boolean bError=false;
WriteLog("VSExceptionResolutionREPORT","sOutputXML ::> sOutputXML : "+bError);
	String getDBUSERByUserIdSql = "{call "+sProcedureName+"(?,?,?,?,?,?,?,?,?,?,?)}";
	String output = "" ;
	try
	{
WriteLog("VSExceptionResolutionREPORT"," QueueName "+QueueName);
WriteLog("VSExceptionResolutionREPORT"," VendorRequestType "+VendorRequestType);
WriteLog("VSExceptionResolutionREPORT"," VendorType "+VendorType);
WriteLog("VSExceptionResolutionREPORT"," sExp "+sExp);
WriteLog("VSExceptionResolutionREPORT"," sFieldValues "+sFieldValues);
WriteLog("VSExceptionResolutionREPORT"," Params "+sProcedureName+" '"+QueueName+"','"+VendorRequestType+"','"+VendorType+"','"+sExp+"','"+sFromDate+"','"+sToDate+"','"+sFieldValues+"','"+sUserMailID+"','"+sPath+"','"+sFileName+"',''");

			Class.forName(driverName);
			conn = DriverManager.getConnection(connectionUrl);
			callableStatement = conn.prepareCall(getDBUSERByUserIdSql);
			callableStatement.setString(1, QueueName);
			callableStatement.setString(2, VendorRequestType);
			callableStatement.setString(3, VendorType);
			callableStatement.setString(4, sExp);
			callableStatement.setString(5, sFromDate);
			callableStatement.setString(6, sToDate);
			callableStatement.setString(7, sFieldValues);
			callableStatement.setString(8, sUserMailID);
			callableStatement.setString(9, sPath);
			callableStatement.setString(10, sFileName);
			callableStatement.registerOutParameter(11, java.sql.Types.VARCHAR);
			callableStatement.execute();

			output = callableStatement.getString(11);
			WriteLog("VSExceptionResolutionREPORT"," output "+output);
	}
	catch(SQLException ignore)
	{
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		bError= true;
		WriteLog("VSExceptionResolutionREPORT"," WFSession Data Fetch Exception:::::: "+ignore.toString());
		%>
			<script>alert("Error While Generating Report");</script>
		<%
	}
	finally {
 
	if (callableStatement != null) {
        try {
            callableStatement.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
	}


if(!bError)
	{

		WriteLog("VSExceptionResolutionREPORT"," output:::::: "+output);
		try
		{

			if(output.equals(""))
			{
				bError= true;
				//maincode=sOutputXML.substring(sOutputXML.indexOf("<MainCode>")+10 , sOutputXML.indexOf("</MainCode>"));
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+output+"</b></font><center>");
			}
			else
			{
				
					try
							{
								 if(Integer.parseInt(output) == 0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
								out.println(ig.toString());
								%>
									<script>alert("Error While Generating Report");</script>
								<%
								WriteLog("VSExceptionResolutionREPORT"," Error:::::: "+ig.toString());
							}
			}
		}
		
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
			WriteLog("VSExceptionResolutionREPORT"," Error:::::: "+exp.toString());
			%>
				<script>alert("Error While Generating Report");</script>
			<%
		}
		
	}
	
	%>

			
		
			<FORM name="textForm">
		

			</form>	
		
	
			

<%!
 public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }


%>





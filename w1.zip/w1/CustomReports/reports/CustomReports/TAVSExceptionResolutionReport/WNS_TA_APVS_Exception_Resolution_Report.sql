   
/*   
WNS_VS_Exception_Resolution_Report 'All~','New~','All~','All~','01/JAN/2014','25/FEB/2014','Current_Work_Step,a.WI_Name,b.ExceptionName,Vendor_Request_Type,Vendor_type,Priority,Vendor_Name,Vendor_Number,Payment_Terms,Vendor_Status,Address_Line_1,Address_L
ine_2,City_Address_Line_3,State_Code,Postal_code,Approvers_Comments,Approval_Decision,Registration_Date,b.ActionDatetime as ExceptionRaisedDatetime,Exception_Raising_Comments,b.UserName,b.ActionDatetime as ExceptionRaisedDatetime,Exception_Clearing_Commen
ts,b.UserName,1,1,Additional_Comments','aabb@ww.com','//10.33.192.139/XLS-File/Yogesh/ExceptionResolve','VSEXCEPTIONRESOLUTION',''

*/   
  
create PROCEDURE WNS_TA_APVS_Exception_Resolution_Report   
(
@QueueName nvarchar(250),   
@ProcessType  VARCHAR(200),
@VendorType  VARCHAR(200),
@Exp  VARCHAR(200),
@DateRangeFrom  VARCHAR(50),
@DateRangeTo  VARCHAR(50),
@Fields varchar(8000),
@EmailID varchar(200),   
@Path_Val varchar(200),   
@FileName varchar(300)  , 
@RowCount varchar(200) OUTPUT
)
AS
declare
 @WhereQuery varchar(2000),
 @Query varchar(5000),
 @Query1   varchar(5000),
 @Querysum varchar(5000),
 @Tables   varchar(200),
 @ExpReport varchar(200),
 @VendorTypeReport varchar(200),  
 @QueueNameReport varchar(200),   
 @ProcessTypeReport varchar(200),   
 @OrderBy varchar(300),   
 @Disp_ExceptionName varchar(100),
 @Count_Exception varchar(100),
 @status_temp varchar(8000),   
 @processinstanceid varchar(100),   
 @activityname varchar(100) ,   
 @actiondatetime datetime,   
 @exceptioncomments varchar(250),   
 @username varchar(50),   
 @dbname varchar(60),
 @QueueTemp varchar(200),
 @VendorReqTemp varchar(200),
 @VendorTypeTemp varchar(200),
 @ExpTemp varchar(200)

   
BEGIN 
 Set nocount on 
 set @FileName=@Path_Val+'/'+@EmailID+'_'+@FileName+'_'+convert(varchar,getdate(),104)+'.xls'
 set @WhereQuery=' where '
 set @ExpReport=''
 set @VendorTypeReport=''
 set @QueueNameReport=''
 set @OrderBy=' order by a.WI_Name'  
 set @RowCount = '0' 
 set @ProcessTypeReport=''
 set @QueueTemp =''
 set @VendorReqTemp =''
 set @VendorTypeTemp =''
 set @ExpTemp =''  
   
 print  @FileName   
   
 /*   
 if Object_ID('#TCI_ExceptionResolution_Report_Temp') is not null  
 begin  
  print 'Table dropped'  
  exec('drop table #TCI_ExceptionResolution_Report_Temp')  
 end   
   
 if Object_ID('#TCISummaryException') is not null  
 begin  
  print 'Table dropped'  
  exec('drop table #TCISummaryException')  
 end   
 */   

 Create Table #VS_ExceptionResolution_Report_Temp 
 ( 
 Current_Work_Step nvarchar(50),
 WI_Name nvarchar(55),
 ExceptionName nvarchar(50),
 Vendor_Request_Type nvarchar(50),
 Vendor_type nvarchar(50),
 Priority nvarchar(50),
 Vendor_Name nvarchar(50),
 Vendor_Number nvarchar(50),
 Payment_Terms nvarchar(50),
 Vendor_Status nvarchar(50),
 Address_Line_1 nvarchar(50),
 Address_Line_2 nvarchar(50),
 City_Address_Line_3 nvarchar(50),
 State_Code nvarchar(5),
 Postal_code nvarchar(55),
 Approvers_Comments nvarchar(550),
 Approval_Decision nvarchar(550),
 Registration_Date nvarchar(550),
 ExceptionRaisedDatetime nvarchar(550),
 Exception_Raising_Comments nvarchar(550),
 UserName nvarchar(55),
 ExceptionResolvedDatetime nvarchar(550),
 Exception_Clearing_Comments nvarchar(550),
 UserName1 nvarchar(55),
 Aging_In_Days nvarchar(5),
 Aging_In_Hrs nvarchar(5),
 Additional_Comments nvarchar(550)
 )   
   
 --create temporary summary table
 Create Table #VSSummaryException
 (
 Disp_ExceptionName varchar(100),
 Count_Exception varchar(100)
 )   
   
 set @Tables='WNS_TA_APVS_EXT_Table a with(nolock) ,exceptiontable b with(nolock) '   
   
 set @WhereQuery=@WhereQuery+' a.WI_Name=b.Processinstanceid  and b.actionid=''10'' and b.processdefid=''4'' and a.Current_Work_Step=''Exit'' '
   
 if(rtrim(ltrim(@DateRangeFrom))<>'')
  SET @DateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@DateRangeFrom,121))))) 
 if(rtrim(ltrim(@DateRangeTo))<>'')
  SET @DateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@DateRangeTo,121))))) 
   
 print @DateRangeFrom
   
 -- Add Document Type   
 if(rtrim(ltrim(@VendorType))<>'All~')
 BEGIN
  --Added to Check for only 1 parameter
  if(len(@VendorType)=charindex('~',@VendorType))
  BEGIN
 set @VendorTypeTemp=ltrim(rtrim(substring(@VendorType,0,len(@VendorType))))
   set @VendorTypeReport=ltrim(rtrim(substring(@VendorType,0,len(@VendorType))))
   set @WhereQuery=@WhereQuery+' AND a.Vendor_Type='''+@VendorTypeReport+''''
  END
   
  --Added to Check for only 1 parameter  
  else
  BEGIN
   -----While loop ends
   while (charindex('~',@VendorType)>1)
   BEGIN
   set @VendorTypeTemp=@VendorTypeTemp +ltrim(rtrim(SUBSTRING(@VendorType,1,Charindex('~',@VendorType)-1)))+','
set @VendorTypeReport = @VendorTypeReport + ''''+ltrim(rtrim(SUBSTRING(@VendorType,1,Charindex('~',@VendorType)-1)))+''''+','
set @VendorType=ltrim(rtrim(Substring(@VendorType,Charindex('~',@VendorType)+len('~'),len(@VendorType))))
   END
   
   set @VendorTypeReport=substring(@VendorTypeReport,0,len(@VendorTypeReport)) 
   set @WhereQuery=@WhereQuery+' AND a.Vendor_Type in('+@VendorTypeReport+')'
  END
 END
   
 if(rtrim(ltrim(@QueueName))<>'All~')
 BEGIN
  --Added to Check for only 1 parameter
  if(len(@QueueName)=charindex('~',@QueueName))
  BEGIN
   set @QueueTemp=ltrim(rtrim(substring(@QueueName,0,len(@QueueName))))
   set @QueueNameReport=ltrim(rtrim(substring(@QueueName,0,len(@QueueName))))
   set @WhereQuery=@WhereQuery+' AND a.current_work_step='''+@QueueNameReport+''''
  END
   
  --Added to Check for only 1 parameter  
  else
  BEGIN
   -----While loop ends
  while (charindex('~',@QueueName)>1)
   BEGIN
 set @QueueTemp=@QueueTemp +ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+','
set @QueueNameReport = @QueueNameReport + ''''+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+''''+','
set @QueueName=ltrim(rtrim(Substring(@QueueName,Charindex('~',@QueueName)+len('~'),len(@QueueName))))
   END
   
   set @QueueNameReport=substring(@QueueNameReport,0,len(@QueueNameReport))
   set @WhereQuery=@WhereQuery+' AND a.current_work_step in('+@QueueNameReport+')'
  END
 END
   
 print 'After Doc Type '+@WhereQuery   

 if(rtrim(ltrim(@ProcessType))<>'All~')
 BEGIN
  --Added to Check for only 1 parameter
  if(len(@ProcessType)=charindex('~',@ProcessType))
  BEGIN
 set @VendorReqTemp =ltrim(rtrim(substring(@ProcessType,0,len(@ProcessType))))
   set @ProcessTypeReport=ltrim(rtrim(substring(@ProcessType,0,len(@ProcessType))))
   set @WhereQuery=@WhereQuery+' AND a.vendor_request_type='''+@ProcessTypeReport+''''
  END
   
  --Added to Check for only 1 parameter  
  else
  BEGIN
   -----While loop ends
   while (charindex('~',@ProcessType)>1)
   BEGIN
set @VendorReqTemp =@VendorReqTemp +ltrim(rtrim(SUBSTRING(@ProcessType,1,Charindex('~',@ProcessType)-1)))+','
set @ProcessTypeReport = @ProcessTypeReport + ''''+ltrim(rtrim(SUBSTRING(@ProcessType,1,Charindex('~',@ProcessType)-1)))+''''+','
set @ProcessType=ltrim(rtrim(Substring(@ProcessType,Charindex('~',@ProcessType)+len('~'),len(@ProcessType))))
   END
   
   set @ProcessTypeReport=substring(@ProcessTypeReport,0,len(@ProcessTypeReport))
   set @WhereQuery=@WhereQuery+' AND a.vendor_request_type in('+@ProcessTypeReport+')'
  END
 END
   
 print 'After Process Type '+@WhereQuery   
 if(rtrim(ltrim(@Exp))<>'All~')
 BEGIN   
  print 'Individual Exception '+@Exp
  --Added to Check for only 1 parameter
  if(len(@Exp)=charindex('~',@Exp))
  BEGIN
 set @ExpTemp=ltrim(rtrim(substring(@Exp,0,len(@Exp))))
   set @ExpReport=ltrim(rtrim(substring(@Exp,0,len(@Exp))))  
   set @WhereQuery=@WhereQuery+' AND B.ExceptionName='''+@ExpReport+''''
  END 
  --Added to Check for only 1 parameter
  else
  BEGIN
   print @Exp
   while (charindex('~',@Exp)>1)
   BEGIN
 set @ExpTemp=@ExpTemp+ltrim(rtrim(SUBSTRING(@Exp,1,Charindex('~',@Exp)-1)))+','
set @ExpReport = @ExpReport + ''''+ltrim(rtrim(SUBSTRING(@Exp,1,Charindex('~',@Exp)-1)))+''''+','
set @Exp=ltrim(rtrim(Substring(@Exp,Charindex('~',@Exp)+len('~'),len(@Exp))))
   END
   set @ExpReport=substring(@ExpReport,0,len(@ExpReport))
   
   set @WhereQuery=@WhereQuery+' AND b.ExceptionName in('+@ExpReport+')'
  END
  END
   
 print 'After Adding Exception Name '+@WhereQuery   
   
 if(rtrim(ltrim(@DateRangeFrom))<>'' AND rtrim(ltrim(@DateRangeTo))<>'')
 BEGIN
  set @WhereQuery=@WhereQuery+' AND b.actiondatetime between '''+rtrim(ltrim(@DateRangeFrom))+''' AND '''+ rtrim(ltrim(@DateRangeTo))+''''
 END
 print 'After Adding Date Range '+@WhereQuery   

 -- set @Query1='SELECT b.activityname,a.WI_Name,Branch_Location,b.ExceptionName,Vendor_Type,Company_Code,   
 -- Vendor_Name,Vendor_ID,Document_Number,Document_Amount,Currency,Document_Date,Wi_EntryTime,   
 -- t1.ExceptionRaisedDatetime,t1.ExceptionComments,   
 -- t1.Raised_By_UserId,b.ActionDatetime as ExceptionClearDatetime,   
 -- exceptioncomments as Exception_Clearing_Comments,   
 -- b.UserName as ResolvedByUser,1,1,Additional_Comments,process_name
 -- from WNS_TCI_AP_EXT_Table a with(nolock) ,exceptiontable b with(nolock),
 -- WNS_TCI_AP_EntryExittable c with(nolock) ,   
 -- (select b.Processinstanceid ,ActionDatetime as ExceptionRaisedDatetime,   
 -- exceptioncomments as ExceptionComments,   
 -- b.UserName as Raised_By_UserId
 --  from exceptiontable b with(nolock),WNS_TCI_AP_EXT_Table a with(nolock)   
 -- where b.processinstanceid=a.wi_name   
 -- and b.actionid=''9'') as t1 WHERE t1.Processinstanceid = a.WI_Name and b.activityname=c.activityname'   
   
 SET @Query='insert into #VS_ExceptionResolution_Report_Temp(Current_Work_Step ,WI_Name ,ExceptionName ,Vendor_Request_Type ,Vendor_type ,Priority ,Vendor_Name ,Vendor_Number ,Payment_Terms ,Vendor_Status ,Address_Line_1 ,Address_Line_2 ,City_Address_Line_3 ,State_Code ,Postal_code ,Approvers_Comments ,Approval_Decision ,Registration_Date ,ExceptionRaisedDatetime ,Exception_Raising_Comments ,UserName ,ExceptionResolvedDatetime,Exception_Clearing_Comments ,UserName1 ,Aging_In_Days ,Aging_In_Hrs ,Additional_Comments)'   
 SET @Query1=@Query+' SELECT '+@Fields+' from '+ @Tables + @WhereQuery + @OrderBy 
 --seT  @Query=@Query + @Query1 + @WhereQuery + @OrderBy
   
 print 'Final SQL '+@Query1   
 exec(@Query1)


 DECLARE VS_Cursor CURSOR FAST_FORWARD FOR   
 Select processinstanceid , b.activityname ,b.actiondatetime, b.exceptioncomments,b.username,b.exceptionName   
 from exceptiontable b with(nolock) ,   
  #VS_ExceptionResolution_Report_Temp c with (nolock)   
 where b.actionid='9'
 and c.WI_Name = b.processinstanceid and b.exceptionname=c.ExceptionName  order by processinstanceid   
 OPEN VS_Cursor
 FETCH NEXT FROM VS_Cursor INTO @processinstanceid,@activityname,@actiondatetime,@exceptioncomments,@username,@status_temp
 WHILE @@FETCH_STATUS = 0
 Begin
 print @actiondatetime
  exec('update #VS_ExceptionResolution_Report_Temp set
   ExceptionRaisedDatetime ='''+@actiondatetime+''',   
   Exception_Raising_Comments = '''+@exceptioncomments+''',   
   UserName1 = '''+@username+'''
   where WI_Name='''+@processinstanceid+''' and ExceptionName='''+@status_temp+'''')   
  FETCH NEXT FROM VS_Cursor INTO @processinstanceid,@activityname,@actiondatetime,@exceptioncomments,@username,@status_temp   
 End
   
 close VS_Cursor   
 Deallocate VS_Cursor
  exec('update #VS_ExceptionResolution_Report_Temp set
 Aging_In_Hrs = isnull(datediff(hh,ExceptionRaisedDatetime,ExceptionResolvedDatetime),''0''),   
 Aging_In_Days = cast((isnull(datediff(hh,ExceptionRaisedDatetime,ExceptionResolvedDatetime),''0''))/24.0 as numeric(10,2))')   
   
   
 SET @Query='insert into #VSSummaryException(Disp_ExceptionName,Count_Exception) '   
 SET @Querysum='select case ExceptionName when ''Missing vendor information'' then ''Missing vendor information Exception :'' when ''Missing W9'' then ''Missing W9 Exception:''   
  when ''Cancel Duplicate'' then ''Cancel/Duplicate Exception:''
 else ''Exception'' end as Disp_exceptionname, count(*) as  
 count_exception from #VS_ExceptionResolution_Report_Temp group by ExceptionName'
   
 set @Query=@Query+@Querysum
 print 'Exception Count '+@Query   
 exec (@Query)
   
 select @RowCount=count(*) from #VSSummaryException with(nolock)
   
 /*   
 if(@RowCount=0)
 Begin   
  print 'Drop #TCISummaryException'   
  drop table #TCISummaryException
 End*/   
   
 select @RowCount=count(*) from #VS_ExceptionResolution_Report_Temp with(nolock)
   
 if(@RowCount=0)  
 Begin  
  print 'Drop table #VS_ExceptionResolution_Report_Temp'   
  --drop table #TCI_ExceptionResolution_Report_Temp  
 End  
 else  
 begin 
  print 'Report Records '+@RowCount   
  if Object_ID ('VS_TEMP_AUTOMAIL_ER') is not null  
  BEGIN
  exec('drop table VS_TEMP_AUTOMAIL_ER')
  END   
print 'eeee'   
  Exec('Create table VS_TEMP_AUTOMAIL_ER (Header varchar(4000),ROw_Index int IDENTITY(1,1) PRIMARY KEY)')   
   
  Exec('Insert into VS_TEMP_AUTOMAIL_ER  
  Select ''<html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>
  <table border=1>  
  <tr align="left"><td colspan=27 class=headerbold align=center>Vendor Setup Exception Resolution Report</td></tr>   
  <tr align="left"><td colspan=27 class=headerbold> From : '+@DateRangeFrom+'</td></tr> 
  <tr align="left"><td colspan=27 class=headerbold> To : '+@DateRangeTo+'</td></tr>
<tr align="left"><td colspan=27 class=headerbold> Queue Name : '+@QueueTemp+'</td></tr>
<tr align="left"><td colspan=27 class=headerbold> Vendor Request Type : '+@VendorReqTemp+'</td></tr>
<tr align="left"><td colspan=27 class=headerbold> Vendor Type : '+@VendorTypeTemp+'</td></tr>
<tr align="left"><td colspan=27 class=headerbold> Exception Name : '+@ExpTemp+'</td></tr> 
  </table>  <br> 
  <table border=1><tr><td class=headerbold>Current Queue</td>''+   
 ''<td class=headerbold>WI Name</td>''+
 ''<td class=headerbold>Exception Name</td>''+
 ''<td class=headerbold>Vendor Request Type</td>''+
 ''<td class=headerbold>Vendor type</td>''+
 ''<td class=headerbold>Priority</td>''+
 ''<td class=headerbold>Vendor Name</td>''+
 ''<td class=headerbold>Vendor number</td>''+
 ''<td class=headerbold>Payment Terms</td>''+
 ''<td class=headerbold>Status</td>''+
 ''<td class=headerbold>Address Line 1 </td>''+
 ''<td class=headerbold>Address Line 2</td>''+
 ''<td class=headerbold>City Address Line 3</td>''+
 ''<td class=headerbold>State Code</td>''+
 ''<td class=headerbold>Postal code (Zip code)</td>''+
 ''<td class=headerbold>Approvers Comments</td>''+
 ''<td class=headerbold>Approval Decision</td>''+
 ''<td class=headerbold>Introduction Date</td>''+
 ''<td class=headerbold>Exception Raised Date-Time</td>''+
 ''<td class=headerbold>Exception Raised Comments</td>''+
 ''<td class=headerbold>Raised By User</td>''+
 ''<td class=headerbold>Exception Resolved Date-Time</td>''+  
 ''<td class=headerbold>Exception Resolved Comments</td>''+
 ''<td class=headerbold>Resolved By User</td>''+
 ''<td class=headerbold>Aging In Days</td>''+
 ''<td class=headerbold>Aging In Hrs</td>''+
 ''<td class=headerbold>Additional Comments</td>''+
  +''</tr></font>''
   
  UNION ALL   
  Select ''<tr><td align=left style=mso-number-format:\\@>''+ISNULL([Current_Work_Step],'''')+''</td>''+   
''<td align=left style=mso-number-format:\\@>''+ISNULL([WI_Name],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([ExceptionName],'''')+''</td>''+
''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Request_Type],'''')+''</td>''+
''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_type],'''')+''</td>''+
''<td align=left style=mso-number-format:\\@>''+ISNULL([Priority],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([Vendor_Name],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([Vendor_Number],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([Payment_Terms],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([Vendor_Status],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([Address_Line_1],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([Address_Line_2],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([City_Address_Line_3],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([State_Code],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([Postal_code],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([Approvers_Comments],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([Approval_Decision],'''')+''</td>''+
''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(50),ISNULL([Registration_Date],''''),120)+''</td>''+ 
''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(50),ISNULL([ExceptionRaisedDatetime],''''),120)+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([Exception_Raising_Comments],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([UserName],'''')+''</td>''+
''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(50),ISNULL([ExceptionResolvedDatetime],''''),120)+''</td>''+ 
''<td align=left style=mso-number-format:\@>''+ISNULL([Exception_Clearing_Comments],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([UserName1],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([Aging_In_Days],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([Aging_In_Hrs],'''')+''</td>''+
''<td align=left style=mso-number-format:\@>''+ISNULL([Additional_Comments],'''')+'' </td> ''
  from #VS_ExceptionResolution_Report_Temp')
   
 select @status_temp='<tr></tr></tr></table><html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style><table border=1><tr>'+'<td class=headerbold><b>Exception Name </b></td><td class=headerbold><b>Exception Count</b></td></tr>'   
   
  DECLARE VSSummaryException_Cursor CURSOR FAST_FORWARD FOR 
  Select Disp_ExceptionName,Count_Exception from #VSSummaryException
  OPEN VSSummaryException_Cursor
  FETCH NEXT FROM VSSummaryException_Cursor INTO  @Disp_ExceptionName,@Count_Exception  
  WHILE @@FETCH_STATUS = 0
  Begin
   select @status_temp=@status_temp+'<tr><td>'+convert(varchar(100),@Disp_ExceptionName)+'</td><td>'+convert(varchar(100),@Count_Exception)+'</td></tr>'
   FETCH NEXT FROM VSSummaryException_Cursor INTO @Disp_ExceptionName,@Count_Exception
  End  

  close VSSummaryException_Cursor
  Deallocate VSSummaryException_Cursor 
  select @status_temp=@status_temp+'</table>'  
  exec('insert into VS_TEMP_AUTOMAIL_ER select '''+@status_temp+'''   ') 
   
  update VS_TEMP_AUTOMAIL_ER set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>&nbsp</td>')

  select @dbname = DB_NAME()   
  SET @Query='Master..xp_Cmdshell ''bcp "select Header FROM '+@dbname+'..VS_TEMP_AUTOMAIL_ER order by row_index asc " queryout "'+@FileName+'" -c -T'',no_output'  
  exec(@Query) 

  insert into NG_AutoMail_Status values('TA VS Exception Resolution Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL) 
  
  --drop table #TCISummaryException
  --drop table #TCI_ExceptionResolution_Report_Temp 
  drop table VS_TEMP_AUTOMAIL_ER 

 end
  select @RowCount
END 

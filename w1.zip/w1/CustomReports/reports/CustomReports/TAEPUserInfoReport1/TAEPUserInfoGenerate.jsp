<!-- 
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-TA_CM
Module : GMAC-TA_CM
File Name : TAEPAgingReportMain.jsp
Author :   
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date Change By Change Description (Bug No. (If Any))
(DD/MM/YYYY)
----------------------------------------------------------------------------------------------------
 -->
<%@ include file="customized.process" %> 
<%@ page import="java.io.*" %>
<%@ page import="java.util.*" %>
<%@ page import="javax.servlet.*"%>
<%@ page import="java.text.DateFormat"%>
<%@ page import="java.text.SimpleDateFormat"%>
<%@ page import="javax.servlet.http.*"%>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>
<%@ page import="java.sql.DriverManager,java.sql.Connection,java.sql.PreparedStatement,java.sql.CallableStatement,java.sql.ResultSet,java.sql.SQLException"%>

<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<HTML>
<HEAD>
<TITLE>TAEP User Info Report1 Report</TITLE>
</HEAD>

<link href="/processmanager/omniflow/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>



<body >


<%
try
{
		
	String sProcessDefId=null;
	String sProcedureName=null;
	String sColumnHeaders=null;
	String sReportName=null;
	String sFileName=null;
	String sNumberOfColumns=null;
	String sProcedureNameKey=null;
	String sColumnHeadersKey=null;
	String sFileNameKey=null;
	String sNumberOfColumnsKey=null;
	String sHeaderKey=null;
	String sHeaderPresentKey=null;
	String sDBMappedColsKey=null;
	String sHeaderValue=null;
	String sHeaderPresentValue=null;
	String sCabinetName=null;	
	String sDBMappedCols=null;
	String sFieldValuesKey=null;
	String sFieldValues=null;
	String sFieldValuesReport="";
	String sUserMailID=null;//added by nilesh
	String sFilePath=null;
	String sFilePathKey=null;
	String sOutputXML="";
	Connection conn = null;
	CallableStatement cs = null;
	String conString = null;
	String driverName = null;
	boolean bError=false;
		
	
	String sFromDate=request.getParameter("FromDates");
	String sToDate=request.getParameter("ToDate");



	Date CurrDate=new Date();
	DateFormat dt = new SimpleDateFormat("dd-MMM-yyyy");
	String sCurrdate=dt.format(CurrDate);


		
	
	sReportName	=request.getParameter("ReportName");
	sUserMailID=request.getParameter("EmailId");//added by nilesh 
	
	sReportName="TAEPUSERINFO1REPORT";
	
	sReportName	=sReportName.toUpperCase();

	
	sProcedureNameKey=sReportName +"_PROCEDURENAME";

	
	sColumnHeadersKey=sReportName+"_COLUMNHEADERS";
	
	sFileNameKey=sReportName+"_FILENAME";

	

	sNumberOfColumnsKey=sReportName+"_NUMBEROFCOLUMNS";

	

	sHeaderPresentKey=sReportName+"_COLUMNHEADERS";

	


	
	sHeaderKey=sReportName+"_HEADER";

	
	sDBMappedColsKey=sReportName+"_DBMAPPEDCOLS";
	
	sFieldValuesKey=sReportName+"_FIELDVALUES";

	
	
	sFilePathKey=sReportName+"_FILEPATH";
	

	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAEPUserInfoReport1.ini";
WriteLog("TAEPUSERINFO_REPORT","sRootPathini="+sRootPathini);
	Properties ini = new Properties();
	
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("TAEPUSERINFO_REPORT","Unable to close the TAEPUSERINFO_REPORT.ini file");
						}
					}
				}
	
	
	sProcessDefId=ini.getProperty("TAEPUSERINFO1REPORT_PROCESSDEFID");
	
	sCabinetName=ini.getProperty("TAEPUSERINFO1REPORT_CABINETNAME");
	
	
	
	sProcedureName=ini.getProperty(sProcedureNameKey);
	
	sColumnHeaders=ini.getProperty(sColumnHeadersKey);
	
	sFileName=ini.getProperty(sFileNameKey);
	
	sNumberOfColumns=ini.getProperty(sNumberOfColumnsKey);
	
	WriteLog("TAEPUSERINFO_REPORT","5.1"+sHeaderPresentKey);	
	sHeaderPresentValue=ini.getProperty(sHeaderPresentKey);
	
	sDBMappedCols=ini.getProperty(sDBMappedColsKey);
	
	sFieldValues=ini.getProperty(sFieldValuesKey);
	
	WriteLog("TAEPUSERINFO_REPORT","5.2"+sHeaderPresentValue);	
	
	sFilePath=ini.getProperty(sFilePathKey);
	
	

	if(sHeaderPresentValue.equals("YES")) 
	{
		sHeaderValue=ini.getProperty(sHeaderKey);
	}
			

    /*String sColumnNamesArr[]="";
	String sDBMappedColsArr[]="";
	String sFinalColumns[]="";
	for(int i=0;i<sColumnNamesArr.length;i++)
	{
		if(sColumnNamesArr[i].indexOf("~D")!=-1)
			sFinalColumns[i]=sColumnNamesArr[i].substring(0,sColumnNamesArr[i].length()-2);

	}

		String sFieldNamesDB[]="";

		for(int i=0;i<sFieldNamesDB.length;i++)
		{
			sFieldValuesReport=sFieldValuesReport+sFieldNamesDB[i]+',';
		}*/
		
	//sFieldValuesReport=sFieldValuesReport.substring(0,sFieldValuesReport.length()-1);
	
	
	//Aging Implementation
	

	
	

	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("TAEPUSERINFO_REPORT","sRootPathDBini="+sRootPathDBini);	
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("TAEPUSERINFO_REPORT","Unable to close the TAEPUSERINFO_REPORT.ini file");
						}
					}
				}
	
	driverName=ini.getProperty("DRIVERNAME");
	conString=ini.getProperty("CONNECTIONSTRING");
	
	WriteLog("TAEPUSERINFO_REPORT","driverName="+driverName);
	WriteLog("TAEPUSERINFO_REPORT","conString="+conString);
	
	try
	{
		Class.forName(driverName);	
		conn = DriverManager.getConnection(conString);
		
		WriteLog("TAEPUSERINFO_REPORT","cs.toString()=2");	
		
		cs = conn.prepareCall("{call "+sProcedureName+"(?,?,?,?,?,?)}"); 
		
		cs.setString(1,sFromDate);
		cs.setString(2,sToDate);
		cs.setString(3,sFieldValues);
		cs.setString(4,sUserMailID);
		cs.setString(5,sFilePath);
		cs.registerOutParameter(6, java.sql.Types.VARCHAR);
		
		WriteLog("TAEPUSERINFO_REPORT","variables="+sFieldValues+","+sFromDate+","+sToDate+","+sUserMailID+","+sFilePath+","+sFileName);	
		WriteLog("TAEPUSERINFO_REPORT","sProcedureName="+sProcedureName);	
		
		cs.execute();
		
		
        WriteLog("TAEPUSERINFO_REPORT","output="+cs.getString(6));	
		sOutputXML = cs.getString(6);
		WriteLog("TAEPUSERINFO_REPORT","sOutputXML="+sOutputXML);	
	}
	catch(SQLException ignore)
	{		
		bError= true;
	}
	finally {
 
	if (cs != null) {
        try {
            cs.close();
        } catch (SQLException e) { WriteLog("TAEPUSERINFO_REPORT","Exception"+e);}
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { WriteLog("TAEPUSERINFO_REPORT","Exception"+e);}
    }
}
	if(!bError)
	{
		try
		{
		   if(sOutputXML.equals("NORECORD"))
		   {
			WriteLog("TAEPQUEUESTATUS REPORT ","no record ");
			bError= true;
			
			%>
			<script>alert("No Records found for the Current Request Criteria.");</script>
			<%
		   }
			else if(sOutputXML.equals("SUCCESS"))
			{
				WriteLog("TAEPQUEUESTATUS REPORT ","found record");

				%>
				<script>alert("The Report will be delivered to your mailbox shortly");</script>
				<%

			}
			else 
			{
				WriteLog("TAEPQUEUESTATUS REPORT ","Technical error");

				%>
				<script>alert("Internal Server error. Please logout and try again.\nIf problem persists then contact to the support team.");</script>
				<%

			}

		}
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			WriteLog("TAEPUSERINFO_REPORT",exp.toString());
			bError= true;
		}

		
	}
	else
	{
	%>
			<script>alert("Internal Server Error.");</script>
	<%
	}
	
	}
	catch(Exception e)
	{
		WriteLog("TAEPUSERINFO_REPORT","sFilePath="+e);	
		
	}
	
%>


</body>
</html>
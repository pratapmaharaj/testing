<!-- 
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-TA_CM
Module : GMAC-TA_CM
File Name : TAEPAGINGREPORTMain.jsp
Author :   
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date Change By Change Description (Bug No. (If Any))
(DD/MM/YYYY)
----------------------------------------------------------------------------------------------------
 -->
<%@ include file="customized.process" %> 
<%@ page import="java.io.*" %>
<%@ page import="java.util.*" %>
<%@ page import="javax.servlet.*"%>
<%@ page import="java.text.DateFormat"%>
<%@ page import="java.text.SimpleDateFormat"%>
<%@ page import="javax.servlet.http.*"%>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>
<%@ page import="java.text.*"%>
<%@ page import="java.sql.DriverManager,java.sql.Connection,java.sql.PreparedStatement,java.sql.CallableStatement,java.sql.ResultSet,java.sql.SQLException"%>

<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>

<HTML>
<HEAD>
<TITLE>TAES Aging Report</TITLE>
</HEAD>
<link href="/processmanager/omniflow/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>

</script>

<body topmargin="0" leftmargin="5" >

<%
	WriteLog("TAEPAGING REPORT","Initial");								
	int sProcessDefId      =1;
	String sProcedureName     ="";
	String sColumnHeaders     ="";
	String sReportName        ="";
	String sFileName          ="";
	String sNumberOfColumns   ="";
	String sProcedureNameKey  ="";
	String sColumnHeadersKey  ="";
	String sFileNameKey       ="";
	String sNumberOfColumnsKey="";
	String sHeaderKey         ="";
	String sHeaderPresentKey  ="";
	String sDBMappedColsKey   ="";
	String sHeaderValue       ="";
	String sHeaderPresentValue="";
	String sCabinetName       ="";	
	String sDBMappedCols      ="";
	String sFieldValuesKey    ="";
	String sFieldValues       ="";
	String sUserMailID        ="";
	String sFromDate          =null;
	String sToDate            =null;
	String sFromTime          ="00";
	String sToTime            ="00";
	
	String qFromTime          ="00";
	String qToTime            ="00";
	String rFromDate          =null;
	String rToDate            =null;
	
	
	
	String sFilePath          = "" ;
	String owner_id          = "" ;
	String Approval_decision          = "" ;

    sFromDate = request.getParameter("FromDate");
	sToDate = request.getParameter("ToDate");
	
	
	rFromDate = request.getParameter("R_From_Date");
	rToDate = request.getParameter("R_To_Date");
	
	
	String Queue=request.getParameter("sQueue");
	owner_id=request.getParameter("owner_id");
	Approval_decision=request.getParameter("Approval_decision");


	sReportName	  =request.getParameter("ReportName");
	sUserMailID   =request.getParameter("UserEmailID");
	
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAESAgingReport.ini";
	WriteLog("TAEPAGING REPORT","sRootPathini="+sRootPathini+",sReportName="+sReportName);								
	WriteLog("TAEPAGING REPORT","owner_id="+owner_id+",sReportName="+sReportName);	
	WriteLog("TAEPAGING REPORT","Approval_decision="+Approval_decision+",sReportName="+sReportName);	
	
	WriteLog("TAEPAGING REPORT","rFromDate="+rFromDate+",sReportName="+sReportName);
	WriteLog("TAEPAGING REPORT","rToDate="+rToDate+",sReportName="+sReportName);
	
	Properties ini = new Properties();
	//Unreleased dataresource release fix
	FileInputStream fis = null;
		try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("TAESAGING REPORT","Unable to read TAESAgingReport.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("TAESAGING REPORT","Unable to close the TAESAgingReport.ini file");
						}
					}
				}
	//ini.load(new FileInputStream(sRootPathini));
	sProcessDefId=1;
	sCabinetName="omnicab";

	 sProcedureName=sReportName+"_PROCEDURENAME";

	 sFilePath = sReportName+"_FILEPATH";
     sFileNameKey        =sReportName+"_FILENAME";
     sNumberOfColumnsKey =sReportName+"_NUMBEROFCOLUMNS";
	 sFieldValuesKey     =sReportName+"_FIELDVALUES";

    sFieldValues=ini.getProperty(sFieldValuesKey);
	sFieldValues=sFieldValues.replaceAll("#",",");
	
	sFilePath = ini.getProperty(sFilePath) ;
    sFileName        =ini.getProperty(sFileNameKey);
	sNumberOfColumns =ini.getProperty(sNumberOfColumnsKey);
	sProcedureName = ini.getProperty(sProcedureName) ;
		
	String sCabname             = null;
	String sSessionId           = null;
	String sJtsIp               = null;
	String sUserName            = null;
	String sReportProcedureName =null;
	String sReportTableName=null;

	WriteLog("TAEPAGING REPORT","sFilePath="+sFilePath);	
	
	Date CurrDate     =new Date();
	DateFormat dt     = new SimpleDateFormat("dd-MMM-yyyy");
	String sCurrdate  =dt.format(CurrDate);

	String sOutputXML   ="";
	String sInputXML    ="";
	String maincode     ="";
	String Totalrec     ="0";
	String sStr_ServerType = null;
	String url = "";
	String Status="";
	double fPercentage=0;
	String sRowXml="";
	
	int iJtsPort = 0;
	
	
	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("TAEPAGING REPORT","sRootPathDBini="+sRootPathDBini);	
	//Unreleased dataresource release fix
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("TAEPAGING REPORT","Unable to DBReports.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("TAEPAGING REPORT","DBReports.ini file");
						}
					}
				}	
	//ini.load(new FileInputStream(sRootPathDBini));
	String conString = null;
	String driverName = null;
	driverName=ini.getProperty("DRIVERNAME");
	conString=ini.getProperty("CONNECTIONSTRING");
	WriteLog("TAEPAGING REPORT","driverName="+driverName+",conString="+conString);								
	
	boolean bError=false;
	//System.out.println("Proc name"+sProcedureName);
	//System.out.println("Params "+Queue+" "+sFromDate+" "+sToDate+" "+sFromTime+" "+sToTime+" "+owner_id+" "+Approval_decision+" "+sUserMailID+" "+sFilePath+" "+rFromDate+" "+rToDate+" "+qFromTime+" "+qToTime);
	Connection conn = null;
	CallableStatement cs = null;
	ResultSet resultset = null;
	try
	{
		Class.forName(driverName);	
		conn = DriverManager.getConnection(conString);
		
		cs = conn.prepareCall("{?=call "+sProcedureName+"(?,?,?,?,?,?,?,?,?,?,?,?,?)}"); 
		
		WriteLog("TAEPAGING REPORT","cs.toString()="+cs.toString());	
		cs.registerOutParameter(1, java.sql.Types.VARCHAR);		
		cs.setString(2,Queue);
		cs.setString(3,sFromDate);
		cs.setString(4,sToDate);
		cs.setString(5,sFromTime);
		cs.setString(6,sToTime);
		cs.setString(7,owner_id);
		cs.setString(8,Approval_decision);
		cs.setString(9,sUserMailID);
		cs.setString(10,sFilePath);		
		cs.setString(11,rFromDate);
		cs.setString(12,rToDate);
		cs.setString(13,qFromTime);
		cs.setString(14,qToTime);
		
		WriteLog("TAEPAGING REPORT","java.sql.Types.VARCHAR======================="+java.sql.Types.VARCHAR);	
		WriteLog("TAEPAGING REPORT","Queue======================="+Queue);	
		WriteLog("TAEPAGING REPORT","sFromDate======================="+sFromDate);	
		WriteLog("TAEPAGING REPORT","sToDate======================="+sToDate);	
		WriteLog("TAEPAGING REPORT","sFromTime======================="+sFromTime);			    
		WriteLog("TAEPAGING REPORT","sToTime======================="+sToTime);	
		WriteLog("TAEPAGING REPORT","owner_id======================="+owner_id);	
		WriteLog("TAEPAGING REPORT","Approval_decision======================="+Approval_decision);	
		WriteLog("TAEPAGING REPORT","sUserMailID======================="+sUserMailID);				
		WriteLog("TAEPAGING REPORT","sFilePath======================="+sFilePath);		
		WriteLog("TAEPAGING REPORT","qFromTime======================="+qFromTime);	
		WriteLog("TAEPAGING REPORT","qFromTime======================="+qToTime);	
		WriteLog("TAEPAGING REPORT","rFromDate======================="+rFromDate);	
		WriteLog("TAEPAGING REPORT","rToDate======================="+rToDate);				
		    
		
		WriteLog("TAEPAGING REPORT","cs.toString()======================="+cs.toString());	
		
		WriteLog("TAEPAGING REPORT","variables="+cs+"---Queue="+Queue+","+sFromDate+","+sToDate+","+sFromTime+","+sToTime+","+owner_id+","+Approval_decision+","+sUserMailID+","+sFilePath);	
		
		
		resultset = cs.executeQuery();
		WriteLog("TAEPAGING REPORT","resultset="+resultset);	
		
		while( resultset.next() )
		{
              WriteLog("TAEPAGING REPORT","output="+resultset.getString( 1 ));	
			  sOutputXML = resultset.getString(1);
			  System.out.println("ES aging output xml"+sOutputXML );
        }
		

	}
	catch(Exception ignore)
	{	
		
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp->161->"+ignore.toString()+"</b></font>");
		
		WriteLog("TAEPAGING REPORT","ignore======================="+ignore.toString());	
		
		bError= true;
	}
	finally {
	if (resultset != null) {
        try {
            resultset.close();
        } catch (SQLException e) { }
    }
	if (cs != null) {
        try {
            cs.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
	}
	
	
	if(!bError)
	{
		try
		{
		   if(sOutputXML.equals("NORECORD"))
		   {
			WriteLog("TAEPAGING REPORT","no record ");
			bError= true;
			
			%>
			<script>alert("No Records found for the Current Request Criteria.");</script>
			<%
		   }
			else if(sOutputXML.equals("SUCCESS"))
			{
				WriteLog("TAEPAGING REPORT","found record");

				%>
				<script>alert("The Report will be delivered to your mailbox shortly");
				window.close();
				
				
				</script>
				<%

			}
			else 
			{
				WriteLog("TAEPAGING REPORT","Technical error");

				%>
				<script>alert("Internal Server error. Please logout and try again.\nIf problem persists then contact to the support team.");</script>
				<%

			}

		}
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
			System.out.println("ES Aging"+ exp);
		}

		
	}
	else
	{
	%>
			<script>alert("Internal Server Error.");</script>
	<%
	}
%>	

<FORM name="textForm">
</form>	

</body>

</html>
			
		
				


			
			





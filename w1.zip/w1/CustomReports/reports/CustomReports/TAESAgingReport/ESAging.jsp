<!-- 
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-TA_CM
Module : GMAC-TA_CM
File Name : TAEPAGINGREPORT.jsp
Author :   
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date Change By Change Description (Bug No. (If Any))
(DD/MM/YYYY)
----------------------------------------------------------------------------------------------------
 -->

<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="java.sql.DriverManager,java.sql.Connection,java.sql.PreparedStatement,java.sql.CallableStatement,java.sql.ResultSet,java.sql.SQLException"%>

<HTML>
<HEAD>
<TITLE>TA ES Aging Report</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>
<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
}
</style>
<script>
	$(document).ready(function(){$('#From_Date').datepicker({dateFormat : "mm/dd/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date').datepicker({dateFormat : "mm/dd/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#R_From_Date').datepicker({dateFormat : "mm/dd/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#R_To_Date').datepicker({dateFormat : "mm/dd/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	});
	var FromDate = new Date();
	var type = '';
	var allWindows = new Array();
	var win; 
	// new window object
	/*functions echeck,ValidateForm*/
	function echeck(str) 
	{
		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}

function ValidateForm(emailID)
{
	//	var emailID=document.frmSample.txtEmail
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }

function ChangeDateTag(obj)
{
	var InsertVal='';
	for(iterate=0;iterate<obj.length;iterate++)
	{
		if(obj.options[iterate].selected==true)
		{
			InsertVal=InsertVal+obj.options[iterate].value+'/';
		}
	}
	InsertVal=InsertVal.substring(0,InsertVal.length-1);
	var Table=document.getElementById('newgen');
	var lastRow = Table.rows.length;
	if (lastRow > 0) Table.deleteRow(lastRow - 1);
	while(InsertVal.indexOf('_')!=-1)
	{
		InsertVal=InsertVal.replace('_',' ');
	}
	var Row=Table.insertRow(0);
	var Cell=Row.insertCell();
	Cell.className="EWLabelBoldNew";
	//Cell.innerHTML=InsertVal;
}

function DateComparator(Date_To,Date_From)
	{	
			if (Date_From == "" && Date_To == "")
			{
				return true;
			}

			var FromDay = Date_From.split("/")[0];
			var FromMonth = convertMonth(Date_From.split("/")[1]);
			var FromYear = Date_From.split("/")[2];
			
			
			
			var ToDay = Date_To.split("/")[0];
			var ToMonth = convertMonth(Date_To.split("/")[1]);
			var ToYear = Date_To.split("/")[2];
			
			
			
			var CurrentDate=new Date();
			
			var CurrentDay = CurrentDate.getDate();
			var CurrentMonth = CurrentDate.getMonth();
			var CurrentYear = CurrentDate.getFullYear();			

			var toDate = (new Date(ToYear,ToMonth,ToDay)).getTime();
			var fromDate = (new Date(FromYear,FromMonth,FromDay)).getTime();
			var CurrentDate = (new Date(CurrentYear,CurrentMonth,CurrentDay)).getTime();
			
			
			if(fromDate > toDate)
			{
				alert("To Date cannot be less than From Date.");
				return false;
			}
			else if(fromDate > CurrentDate)
			{
				alert("From Date cannot be future date.");
				return false;
			}
			else if(toDate > CurrentDate)
			{
				alert("To Date cannot be future date.");
				return false;
			}
			
			return true;
	
	}
	function convertMonth(strMonth)
{
		if(strMonth=="JAN")
			strMonth="00";
		else if(strMonth=="FEB")
			strMonth="01";
		else if(strMonth=="MAR")
			strMonth="02";
		else if(strMonth=="APR")
			strMonth="03";
		else if(strMonth=="MAY")
			strMonth="04";
		else if(strMonth=="JUN")
			strMonth="05";
		else if(strMonth=="JUL")
			strMonth="06";
		else if(strMonth=="AUG")
			strMonth="07";
		else if(strMonth=="SEP")
			strMonth="08";
		else if(strMonth=="OCT")
			strMonth="09";
		else if(strMonth=="NOV")
			strMonth="10";
		else if(strMonth=="DEC")
			strMonth="11";
	return strMonth;
}
function convertMonth1(strMonth)
{
		if(strMonth=="01")
			strMonth="JAN";
		else if(strMonth=="02")
			strMonth="FEB";
		else if(strMonth=="03")
			strMonth="MAR";
		else if(strMonth=="04")
			strMonth="APR";
		else if(strMonth=="05")
			strMonth="MAY";
		else if(strMonth=="06")
			strMonth="JUN";
		else if(strMonth=="07")
			strMonth="JUL";
		else if(strMonth=="08")
			strMonth="AUG";
		else if(strMonth=="09")
			strMonth="SEP";
		else if(strMonth=="10")
			strMonth="OCT";
		else if(strMonth=="11")
			strMonth="NOV";
		else if(strMonth=="12")
			strMonth="DEC";
	return strMonth;
}

function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";


	sDate	= window.showModalDialog('/processmanager/reports/GMACReports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');
	
	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}

}
function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	//strResult=strdate+"/"+strMonth+"/"+stryear;
	strResult=strtempdate+"/"+strdate+"/"+stryear;
	return strResult;
}

function openreport()
{	
		var QueueName="";
		var DateRangeFrom="";
		var DateRangeTo="";
		var owner_id="";
		//added by nilesh for retriving email id value
		var UserEmailID=document.getElementById('EMail-ID').value;
		//DocType=document.forms["textForm"].Document_Type.value;
		//var QueueName=document.forms["textForm"].Queue.value;
		DateRangeFrom=document.forms["textForm"].From_Date.value;
		DateRangeTo=document.forms["textForm"].To_Date.value;
		var R_DateRangeFrom=document.forms["textForm"].R_From_Date.value;
		var	R_DateRangeTo=document.forms["textForm"].R_To_Date.value;
		
	
		 
		var UserEmailID=document.getElementById('EMail-ID').value;
		
		owner_id=document.getElementById('owner_id').value;
		var sdatecon=DateRangeFrom.split('/');
		var sMonth=convertMonth1(sdatecon[0]);
		var sDay=sdatecon[1];
		var sYear=sdatecon[2];
		
		var Approval_decision="";
		
		DateRangeFrom=sDay+"/"+sMonth+"/"+sYear;
		
		var stodatecon=DateRangeTo.split('/');
		var sMonth1=convertMonth1(stodatecon[0]);
		var sDay1=stodatecon[1];
		var sYear1=stodatecon[2];
		
		DateRangeTo=sDay1+"/"+sMonth1+"/"+sYear1;
		
		if(document.forms["textForm"].From_Date.value=='')
		{
			DateRangeFrom='';
		}
		if(document.forms["textForm"].To_Date.value=='')
		{
			DateRangeTo='';
		}
		var sdatecon2=R_DateRangeFrom.split('/');
		var sMonth2=convertMonth1(sdatecon2[0]);
		var sDay2=sdatecon2[1];
		var sYear2=sdatecon2[2];
		
		
		R_DateRangeFrom=sDay2+"/"+sMonth2+"/"+sYear2;
		
		var stodatecon4=R_DateRangeTo.split('/');
		var qsMonth4=convertMonth1(stodatecon4[0]);
		var qsDay4=stodatecon4[1];
		var qsYear4=stodatecon4[2];
		
		
		
		R_DateRangeTo=qsDay4+"/"+qsMonth4+"/"+qsYear4;
		
		if(document.forms["textForm"].R_From_Date.value=='')
		{
			R_DateRangeFrom='';
		}
		if(document.forms["textForm"].R_To_Date.value=='')
		{
			R_DateRangeTo='';
		}
		
		for(var i=0;i<document.forms["textForm"].Queue.length;i++)
		{
			if(document.forms["textForm"].Queue[i].selected)
			{
				QueueName=QueueName+document.forms["textForm"].Queue[i].value+'~';
			}
		}
		
		var sTest=QueueName.split('~');
		if(QueueName=='')
		{
			alert("Please select Queue Name");
			return false;
		}
		
		if(QueueName.indexOf("All")!=-1 && sTest.length>2)
		{
			alert("No other Queue Name can be chosen after choosing All");
			return false;
			//QueueName='All~';
		}  
		
		if(QueueName=='Introduction~Processing~Approval~Cancel~InProgress~')
		{
			QueueName='All~';
		}

	if ((R_DateRangeFrom=='' && R_DateRangeTo=='') && (DateRangeFrom=='' && DateRangeTo=='') )
	{
		alert("Please select Registration Date Range or Queue Entry date Range.");
		return false ;
	}
	
	if ((R_DateRangeFrom=='' && R_DateRangeTo!='') || (R_DateRangeFrom!='' && R_DateRangeTo==''))
	{
		alert("Please select the Registration Date Range.");
		return false;
	}
	if(R_DateRangeFrom!='' && R_DateRangeTo!='')
	{
		if(!DateComparator(R_DateRangeTo,R_DateRangeFrom))
		{
			return false;
		}
	}
		
	if ((DateRangeFrom=='' && DateRangeTo!='') || (DateRangeFrom!='' && DateRangeTo==''))
	{
		alert("Please select the Queue Entry Date Range.");
		return false;
	}
	if(DateRangeFrom!='' && DateRangeTo!='')
	{
		if(!DateComparator(DateRangeTo,DateRangeFrom))
		{
			return false;
		}
	}	
		
		
		
		
		
		
		
		
		
		
		
		for(var i=0;i<document.forms["textForm"].Approval_decision.length;i++)
		{
			if(document.forms["textForm"].Approval_decision[i].selected)
			{
				
				Approval_decision=Approval_decision+document.forms["textForm"].Approval_decision[i].value+'~';
				
			}
		}
		var sTestApproval=Approval_decision.split('~');
		
	
		
		if(Approval_decision.indexOf("All~")>-1 && sTestApproval.length>2)
		{
			alert("No other Approval Decision can be chosen after choosing All");
			return false;
			

		}  
		
		if(Approval_decision=='Approved~Rejected~')
		{
			Approval_decision='All~';
		}
		
		
		
		
		

		//Added by nilesh for validation of Mail-ID
		if(UserEmailID=='')
		{
			alert("Kindly enter a valid E-Mail ID");
			return false;
		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
			}
		}
		
		

		if(UserEmailID!='')
			{	
			//window.top.TAEPAGINGREPORT.location.href="TACMAgingGenerate.jsp?QueueName="+QueueName+"&FromDates="+DateRangeFrom			+"&ToDate="+DateRangeTo+"&ReportName=<%=request.getParameter("ReportName")%>&UserEmailID="+UserEmailID;
			
			//OpenRedict-Fix
    //window.top.TAEPAGINGREPORT.location.href="ESAgingGenerate.jsp?sQueue="+QueueName+"&ReportName=TAEPAGINGREPORT&FromDate="+DateRangeFrom+"&ToDate="+DateRangeTo+"&UserEmailID="+UserEmailID+"&owner_id="+owner_id+"&Approval_decision="+Approval_decision+"&R_To_Date="+R_DateRangeTo+"&R_From_Date="+R_DateRangeFrom;
	var URI = "ESAgingGenerate.jsp?sQueue="+QueueName+"&ReportName=TAEPAGINGREPORT&FromDate="+DateRangeFrom+"&ToDate="+DateRangeTo+"&UserEmailID="+UserEmailID+"&owner_id="+owner_id+"&Approval_decision="+Approval_decision+"&R_To_Date="+R_DateRangeTo+"&R_From_Date="+R_DateRangeFrom;
	var StrOpenWin=strip_tags(URI,"");
	window.top.TAEPAGINGREPORT.location.href=StrOpenWin;
			
			
			  
			
			}

}

	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}

</script>
<body topmargin="0" leftmargin="5" onunload="UnloadReportWindow();">
			<form name='textForm' method=post>
			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">TAES AGING REPORT</td>
				</tr>
				<tr>  
				<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This report will provide the end of the day report for volumes of workitems processed in a selected queue along with other indexing details. 
				</td></tr>
				<tr><td class="EWLabel1">Select All Queues if report is to be generated for viewing the workitems present across different worksteps, else select the specific Queue, multiple selections are again acceptable.
				</td></tr>
				<tr><td class="EWLabel1">Select the requisite date range for generating the report for the same.</td>
				</tr>
				
					<br/>
						<br/>
				<tr><td><p style="color: red; font-size: 10pt">Note:  * fields are mandatory.</p></td>
				</tr>
				
			</table>

			<table border="0" width="95%" cellspacing="1" align="center">
				 <tr>
					<td class="EWLabel1" align="left" width='20%'><b>Queue<font color="RED">*</font></b></td>
					<td width='25%' colspan=3>
						<select name="Queue" multiple onchange='ChangeDateTag(this);'>
							<option value="All">All</option>
							<option value="Introduction">Introduction</option>
							<option value="Processing">Processing</option>
							<option value="Approval">Approval</option>
							<option value="Cancel">Cancel</option>
							<option value="InProgress">InProgress</option>
							<option value="UPCSUpdate">UPCS Update</option>
							<option value="QC">QC</option>
							<option value="UPCSPaid">UPCS Paid</option>
							<option value="ApprovalException">Approval Exception</option>
							<option value="GEACInterface">GEAC Interface</option>
							<option value="PendingPayment">Pending Payment</option>
							<option value="UPCSQC">UPCS QC</option>
						</select>
					</td>
				</tr>
				
				<tr>&nbsp;</tr>
				 				
					<tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>Registration Date Range<font color="RED">*</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="R_From_Date" readonly type="text"  id="R_From_Date" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="R_To_Date" readonly type="text"  id="R_To_Date" >
					
					</td>

				</tr>
				
				<tr>&nbsp;</tr>
				 				
					<tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>Queue Entry Date Range<font color="RED">*</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date" readonly type="text"  id="From_Date" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date" readonly type="text"  id="To_Date" >
					
					</td>

				</tr>
				
				
				
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Owner ID </b></td>
					<td >
					<input type='text' name='owner_id' style='width:145' id='owner_id'>
					</td>
				</tr>
				<tr>&nbsp;</tr>
				<tr>
					<td class="EWLabel1" align="left" width='20%'><b>Approval Decision 
					<td width='25%' COLSPAN=3>
					<select STYLE='width:33%' class='TextFieldColor'  name="Approval_decision" multiple>
						<option value="All">All</option>
						<option value="Approved">Approved</option>
						<option value="Rejected">Rejected</option>
						
						
					</select>

					</td>

				</tr>
		
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID*</b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>
			
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>
			</form>
</body>
</Html>
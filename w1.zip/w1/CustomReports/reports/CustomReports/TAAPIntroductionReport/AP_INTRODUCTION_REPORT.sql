            
  /*              
           
   AP_INTRODUCTION_REPORT 'All~','All~','All~','','','','03/JAN/2014','24/FEB/2014','WI_Name,Introduction_Type,WIIntroducedBy,current_Work_Step as Introduction_queue, Registration_Date,Priority,Document_category,Pre_Paid,Coder_Code,Prepared_By_NAME,Prepar
  
ed_by_Email_Id,Prepared_by_Phone_Number,Invoice_Number,Invoice_Date,Total_Invoice_Amount,PO_Number,Vendor_Name,Vendor_number,W9_Indicator,ACH,AP_Check,ABA,Account,Vendor_Email_id,Payee,Address_Line_1,Address_Line_2,City_Address_Line_3,State_Code,Country_C
  
ode,Postal_code,Optional_Address_1,Optional_Address_2,Remittance_Message,Department_of_backup_information,Contact_Person,Multi_Payment,Number_of_Recurring_payments,Recurring_payment_amount,First_payment_due_date,Frequency,Last_payment_hold,Return_Check,Re
  
turn_Check_to,Reason_for_return_check,Include_Mail_stop,Location,Specific_Limit,Specific_limit_type,Approvers_email_ID1,BAP_Code,Payment_Type,Payment_Term,Payment_Due_date,Approval_Decision,Approver_Comments,Additional_Comments',  'aa@gnma.com','//10.33.1
  
92.139/XLS-File/Yogesh/Manual','Introduction',''          
      
SELECT WI_Name,Introduction_Type,WIIntroducedBy,current_Work_Step as Introduction_queue, Registration_Date,Priority,Document_category,Pre_Paid,Coder_Code,Prepared_By_NAME,Prepared_by_Email_Id,Prepared_by_Phone_Number,Invoice_Number,Invoice_Date,Total_Invo
  
    
ice_Amount,PO_Number,Vendor_Name,Vendor_number,W9_Indicator,ACH,AP_Check,ABA,Account,Vendor_Email_id,Payee,Address_Line_1,Address_Line_2,City_Address_Line_3,State_Code,Country_Code,Postal_code,Optional_Address_1,Optional_Address_2,Remittance_Message,Depar
  
    
tment_of_backup_information,Contact_Person,Multi_Payment,Number_of_Recurring_payments,Recurring_payment_amount,First_payment_due_date,Frequency,Last_payment_hold,Return_Check,Return_Check_to,Reason_for_return_check,Include_Mail_stop,Location,Specific_Limi
  
    
t,Specific_limit_type,Approvers_email_ID1,BAP_Code,Payment_Type,Payment_Term,Payment_Due_date,Approval_Decision,Approver_Comments,Additional_Comments from WNS_TA_AP_EXT_Table with(nolock)where Vendor_Name='' AND Vendor_Number='' AND       
Prepared_by_Name='' and Document_Category ='All' and Introduction_Type ='All' and       
current_work_step ='All' AND Registration_Date between 'Jan  3 2014 12:00AM'       
AND 'Feb 24 2014 11:59PM' and Document_Category <> ' and Vendor_Name<>' and Vendor_Number<>' and Prepared_by_name<>'  order by WI_Name      
      
*/            
CREATE PROCEDURE AP_INTRODUCTION_REPORT            
(            
@DocumentCategory  VARCHAR(200),         
@IntroductionType  VARCHAR(200),         
@IntroductionQueue  VARCHAR(200),             
@VendorName  VARCHAR(200),        
@VendorNumber  VARCHAR(200),        
@PreparedbyName  VARCHAR(200),            
@DateRangeFrom  VARCHAR(100),            
@DateRangeTo  VARCHAR(100),            
@Fields varchar(8000),            
@EmailID varchar (100) ,            
@FilePath  varchar(200),            
@FileName  varchar(200),            
@RowCount varchar(200) OUTPUT            
)            
            
AS              
SET NOCOUNT ON            
Begin              
 declare            
 @WhereQuery varchar(2000),            
 @Query varchar(5000),            
 @Tables varchar(200),            
 @DocumentCategoryReport varchar(200),          
 @IntroductionTypeReport varchar(200),          
 @IntroductionQueueReport varchar(200),           
 @VendorNameReport varchar(200),         
 @VendorNumberReport varchar(200),         
 @PreparedbyNameReport varchar(200),          
 @OrderBy varchar(300)  ,            
 @status_temp varchar(8000)             
            
 set @WhereQuery =''            
 set @Query =''              
 set @Tables =''              
 set @DocumentCategoryReport =''         
 set @IntroductionTypeReport =''        
 set @IntroductionQueueReport =''         
 set @VendorNameReport =''          
 set @VendorNumberReport =''          
 set @PreparedbyNameReport =''          
 set @OrderBy =''              
 set @RowCount =0              
 set @status_temp =''              
            
 if Object_ID('#AP_TEMP_TABLE_ManualIntro') is not null              
 begin             
  print 'Table dropped'              
  exec('drop table #AP_TEMP_TABLE_ManualIntro')              
 end            
            
 CREATE TABLE #AP_TEMP_TABLE_Introduction (            
WI_Name VARCHAR(100) ,        
Introduction_Type VARCHAR(100),        
WIIntroducedBy VARCHAR(100),        
current_Work_Step VARCHAR(100),        
Registration_Date VARCHAR(100),        
Priority VARCHAR(100),        
Document_category VARCHAR(100),        
Pre_Paid VARCHAR(100),        
Coder_Code VARCHAR(100),        
Prepared_By_NAME VARCHAR(100),        
Prepared_by_Email_Id VARCHAR(100),        
Prepared_by_Phone_Number VARCHAR(100),        
Invoice_Number VARCHAR(100),        
Invoice_Date VARCHAR(100),        
Total_Invoice_Amount VARCHAR(100),        
PO_Number VARCHAR(100),        
Vendor_Name VARCHAR(100),        
Vendor_number VARCHAR(100),        
W9_Indicator VARCHAR(100),        
ACH VARCHAR(100),        
AP_Check VARCHAR(100),        
ABA VARCHAR(100),        
Account VARCHAR(100),        
Vendor_Email_id VARCHAR(100),        
Payee VARCHAR(100),        
Address_Line_1 VARCHAR(100),        
Address_Line_2 VARCHAR(100),        
City_Address_Line_3 VARCHAR(100),        
State_Code VARCHAR(100),        
Country_Code VARCHAR(100),        
Postal_code VARCHAR(100),        
Optional_Address_1 VARCHAR(100),        
Optional_Address_2 VARCHAR(100),        
Remittance_Message VARCHAR(100),        
Department_of_backup_information VARCHAR(100),        
Contact_Person VARCHAR(100),        
Multi_Payment VARCHAR(100),        
Number_of_Recurring_payments VARCHAR(100),        
Recurring_payment_amount VARCHAR(100),        
First_payment_due_date VARCHAR(100),        
Frequency VARCHAR(100),        
Last_payment_hold VARCHAR(100),        
Return_Check VARCHAR(100),        
Return_Check_to VARCHAR(100),        
Reason_for_return_check VARCHAR(100),        
Include_Mail_stop VARCHAR(100),        
Location VARCHAR(100),        
Specific_Limit VARCHAR(100),        
Specific_limit_type VARCHAR(100),        
Approvers_email_ID1 VARCHAR(100),        
BAP_Code VARCHAR(100),        
Payment_Type VARCHAR(100),        
Payment_Term VARCHAR(100),        
Payment_Due_date VARCHAR(100),        
Approval_Decision VARCHAR(100),        
Approver_Comments VARCHAR(512),        
Additional_Comments VARCHAR(512)          
            
 )             
             
 BEGIN            
  set @FileName=@FilePath+'/'+@EmailID+'_'+@FileName+'_'+convert(varchar,getdate(),104)+'.xls'              
  set @OrderBy=' order by WI_Name'              
  set @WhereQuery='where'               
  set @Tables='WNS_TA_AP_EXT_Table with(nolock)'            
            
            
  if(rtrim(ltrim(@DateRangeFrom))<>'')              
  BEGIN              
  SET @DateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@DateRangeFrom,121)))))             
  END              
  if(rtrim(ltrim(@DateRangeTo))<>'')            
  BEGIN              
  SET @DateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@DateRangeTo,121)))))            
  END              
   print @WhereQuery            
 if(rtrim(ltrim(@DateRangeFrom))<>'' AND rtrim(ltrim(@DateRangeTo))<>'')            
 BEGIN            
  set @WhereQuery=@WhereQuery+' Registration_Date between '''+rtrim(ltrim(@DateRangeFrom))+''' AND '''+ rtrim(ltrim(@DateRangeTo))+''''            
 END             
            
 --vendor request type       
if(rtrim(ltrim(@VendorName))<>'' )             
 BEGIN             
  --Added to Check for only 1 parameter             
  if(len(@VendorName)=charindex('~',@VendorName))             
  BEGIN             
   set @VendorNameReport=ltrim(rtrim(substring(@VendorName,0,len(@VendorName))))             
   set @WhereQuery=@WhereQuery+' and Vendor_Name='''+@VendorNameReport+''''             
  END             
            
  --Added to Check for only 1 parameter     
  else             
  BEGIN             
   -----While loop ends             
   while (charindex('~',@VendorName)>1)             
   BEGIN             
    set @VendorNameReport = @VendorNameReport + ''''+ltrim(rtrim(SUBSTRING(@VendorName,1,Charindex('~',@VendorName)-1)))+''''+','             
    set @VendorName=ltrim(rtrim(Substring(@VendorName,Charindex('~',@VendorName)+len('~'),len(@VendorName))))             
   END             
            
   set @VendorNameReport=substring(@VendorNameReport,0,len(@VendorNameReport))             
   set @WhereQuery=@WhereQuery+' and Vendor_Name in('+@VendorNameReport+')'             
  END             
 END          
        
if(rtrim(ltrim(@VendorNumber))<>'')             
 BEGIN             
  --Added to Check for only 1 parameter             
  if(len(@VendorNumber)=charindex('~',@VendorNumber))             
  BEGIN             
   set @VendorNumberReport=ltrim(rtrim(substring(@VendorNumber,0,len(@VendorNumber))))             
   set @WhereQuery=@WhereQuery+' AND Vendor_Number='''+@VendorNumberReport+''''             
  END             
            
  --Added to Check for only 1 parameter               
  else             
  BEGIN             
   -----While loop ends             
   while (charindex('~',@VendorNumber)>1)             
   BEGIN             
    set @VendorNumberReport = @VendorNumberReport + ''''+ltrim(rtrim(SUBSTRING(@VendorNumber,1,Charindex('~',@VendorNumber)-1)))+''''+','             
    set @VendorNumber=ltrim(rtrim(Substring(@VendorNumber,Charindex('~',@VendorNumber)+len('~'),len(@VendorNumber))))             
   END             
            
   set @VendorNumberReport=substring(@VendorNumberReport,0,len(@VendorNumberReport))             
   set @WhereQuery=@WhereQuery+' AND Vendor_Number in('+@VendorNumberReport+')'             
  END             
 END         
         
 if(rtrim(ltrim(@PreparedbyName))<>'')             
 BEGIN             
  --Added to Check for only 1 parameter             
  if(len(@PreparedbyName)=charindex('~',@PreparedbyName))             
  BEGIN             
   set @PreparedbyNameReport=ltrim(rtrim(substring(@PreparedbyName,0,len(@PreparedbyName))))             
   set @WhereQuery=@WhereQuery+' AND Prepared_by_Name='''+@PreparedbyNameReport+''''             
  END             
            
  --Added to Check for only 1 parameter               
  else             
  BEGIN             
   -----While loop ends             
   while (charindex('~',@PreparedbyName)>1)             
   BEGIN             
    set @PreparedbyNameReport = @PreparedbyNameReport + ''''+ltrim(rtrim(SUBSTRING(@PreparedbyName,1,Charindex('~',@PreparedbyName)-1)))+''''+','             
    set @PreparedbyName=ltrim(rtrim(Substring(@PreparedbyName,Charindex('~',@PreparedbyName)+len('~'),len(@PreparedbyName))))             
   END             
            
   set @PreparedbyNameReport=substring(@PreparedbyNameReport,0,len(@PreparedbyNameReport))             
   set @WhereQuery=@WhereQuery+' AND Prepared_by_Name in('+@PreparedbyNameReport+')'             
  END             
 END         
         
         
         
 --vendor request type            
if(rtrim(ltrim(@DocumentCategory))<>'')    
begin    
 if(rtrim(ltrim(@DocumentCategory))<>'All~')                              
 BEGIN                              
  if(len(@DocumentCategory)=charindex('~',@DocumentCategory))                              
  BEGIN            
   print '1111'            
   set @DocumentCategoryReport=ltrim(rtrim(substring(@DocumentCategory,0,len(@DocumentCategory))))                              
   print @DocumentCategoryReport                      
   if (rtrim(ltrim(@DocumentCategory))<>'')                    
   begin            
    set @WhereQuery=@WhereQuery+' and Document_Category ='''+@DocumentCategoryReport+''''                              
   end            
  End            
  else            
  BEGIN            
   print '2222'            
   while (charindex('~',@DocumentCategory)>1)                              
   BEGIN                             
   set @DocumentCategoryReport = @DocumentCategoryReport + ''''+ltrim(rtrim(SUBSTRING(@DocumentCategory,1,Charindex('~',@DocumentCategory)-1)))+''''+','                              
    set @DocumentCategory=ltrim(rtrim(Substring(@DocumentCategory,Charindex('~',@DocumentCategory)+len('~'),len(@DocumentCategory))))                              
    print @DocumentCategoryReport             
   END                         
   set @DocumentCategoryReport=SUBSTRING(@DocumentCategoryReport,0,len(@DocumentCategoryReport))               
   print @DocumentCategoryReport                
   print @DocumentCategory                        
   print '11111111'            
   print @DocumentCategoryReport                
   set @WhereQuery=@WhereQuery+' and Document_Category in('+@DocumentCategoryReport+')'                                 
  END                              
 END          
end    
        
if (rtrim(ltrim(@IntroductionType))<>'')    
Begin    
 if(rtrim(ltrim(@IntroductionType))<>'All~')                              
 BEGIN                              
  if(len(@IntroductionType)=charindex('~',@IntroductionType))                              
  BEGIN            
   print '1111'            
   set @IntroductionTypeReport=ltrim(rtrim(substring(@IntroductionType,0,len(@IntroductionType))))                              
   print @IntroductionTypeReport                      
   if (rtrim(ltrim(@IntroductionType))<>'')                    
   begin            
    set @WhereQuery=@WhereQuery+' and Introduction_Type ='''+@IntroductionTypeReport+''''                              
   end            
  End            
  else            
  BEGIN            
   print '2222'            
   while (charindex('~',@IntroductionType)>1)                              
   BEGIN                             
    set @IntroductionTypeReport = @IntroductionTypeReport + ''''+ltrim(rtrim(SUBSTRING(@IntroductionType,1,Charindex('~',@IntroductionType)-1)))+''''+','                              
    set @IntroductionType=ltrim(rtrim(Substring(@IntroductionType,Charindex('~',@IntroductionType)+len('~'),len(@IntroductionType))))                              
    print @IntroductionTypeReport             
   END                         
   set @IntroductionTypeReport=SUBSTRING(@IntroductionTypeReport,0,len(@IntroductionTypeReport))               
   print @IntroductionTypeReport                
   print @IntroductionType                        
   print '11111111'            
   print @IntroductionTypeReport                
   set @WhereQuery=@WhereQuery+' and Introduction_Type in('+@IntroductionTypeReport+')'                                 
  END                              
 END          
 END    
    
if(rtrim(ltrim(@IntroductionQueue))<>'')    
Begin    
  if(rtrim(ltrim(@IntroductionQueue))<>'All~')                              
 BEGIN                              
  if(len(@IntroductionQueue)=charindex('~',@IntroductionQueue))                              
  BEGIN            
   print '1111'            
   set @IntroductionQueueReport=ltrim(rtrim(substring(@IntroductionQueue,0,len(@IntroductionQueue))))                              
   print @IntroductionQueueReport                      
   if (rtrim(ltrim(@IntroductionQueue))<>'')                    
   begin            
    set @WhereQuery=@WhereQuery+' and current_work_step ='''+@IntroductionQueueReport+''''                              
   end            
  End            
  else            
  BEGIN            
   print '2222'            
   while (charindex('~',@IntroductionQueue)>1)                              
   BEGIN                             
    set @IntroductionQueueReport = @IntroductionQueueReport + ''''+ltrim(rtrim(SUBSTRING(@IntroductionQueue,1,Charindex('~',@IntroductionQueue)-1)))+''''+','                              
    set @IntroductionQueue=ltrim(rtrim(Substring(@IntroductionQueue,Charindex('~',@IntroductionQueue)+len('~'),len(@IntroductionQueue))))                              
    print @IntroductionQueueReport             
   END                    
   set @IntroductionQueueReport=SUBSTRING(@IntroductionQueueReport,0,len(@IntroductionQueueReport))               
   print @IntroductionQueueReport                
   print @IntroductionQueue                        
   print '11111111'            
   print @IntroductionQueueReport                
   set @WhereQuery=@WhereQuery+' and current_work_step in('+@IntroductionQueueReport+')'                                 
  END                              
 END         
 END           
    
set @WhereQuery = @WhereQuery+' and Document_Category <> '' and Vendor_Name<>'' and Vendor_Number<>'' and Prepared_by_name<>'' '            
            
 SET @Query='SELECT '+@Fields+' from '+ @Tables + @WhereQuery + @OrderBy            
 --print @Query              
 --exec(@Query)            
             
 set @Query='insert into #AP_TEMP_TABLE_Introduction '+ @Query            
 print  @Query            
            
 print '----'              
 print @Query              
 exec(@Query)            
             
             
 select @RowCount=count(*) from #AP_TEMP_TABLE_Introduction           
 PRINT  @RowCount             
 if(@RowCount=0)            
 Begin            
  drop table #AP_TEMP_TABLE_Introduction            
 End            
 else               
 Begin              
  if Object_ID ('NG_TEMP_AUTOMAIL') is not null               
  BEGIN               
   exec('drop table NG_TEMP_AUTOMAIL')               
  END            
  PRINT '000000'              
  Exec('Create table NG_TEMP_AUTOMAIL (Header varchar(8000),ROw_Index [int] identity(1,1) not null)')               
  exec('Insert into NG_TEMP_AUTOMAIL               
  Select ''<html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>              
  <table border=1>             
  <tr>             
  <td class=headerbold>Workitem Name</td>''+              
 ''<td class=headerbold>Introduced Type</td>''+           
 ''<td class=headerbold>Introduction By</td>''+             
 ''<td class=headerbold>Introduced Queue</td>''+             
 ''<td class=headerbold>Introduced Queue</td>''+            
 ''<td class=headerbold>Registration Date</td>''+               
 ''<td class=headerbold>Priority</td>''+          
 ''<td class=headerbold>Document Category</td>''+          
 ''<td class=headerbold>Pre Paid</td>''+            
 ''<td class=headerbold>Coder Code</td>''+             
 ''<td class=headerbold>Prepared By NAME</td>''+             
 ''<td class=headerbold>Prepared by Email Id</td>''+             
 ''<td class=headerbold>Prepared by Phone Number</td>''+             
 ''<td class=headerbold>Invoice Number</td>''+             
 ''<td class=headerbold>Invoice Date</td>''+             
 ''<td class=headerbold>Invoice Amount</td>''+          
 ''<td class=headerbold>Introduced By</td>''+            
 ''<td class=headerbold>Introduced Date</td>''+             
 ''<td class=headerbold>PO Number</td>''+             
 ''<td class=headerbold>Vendor Name</td>''+             
 ''<td class=headerbold>Vendor Number</td>''+             
 ''<td class=headerbold>W9 Indicator</td>''+          
 ''<td class=headerbold>ACH</td>''+           
 ''<td class=headerbold>Check</td>''+             
 ''<td class=headerbold>ABA</td>''+             
 ''<td class=headerbold>Account</td>''+             
 ''<td class=headerbold>Vendor Email Id</td>''+          
 ''<td class=headerbold>Payee</td>''+            
 ''<td class=headerbold>Address Line 1</td>''+             
 ''<td class=headerbold>Address Line 2</td>''+               
 ''<td class=headerbold>City Address Line 3</td>''+           
 ''<td class=headerbold>State Code</td>''+            
 ''<td class=headerbold>Country Code</td>''+             
 ''<td class=headerbold>Postal code</td>''+             
 ''<td class=headerbold>Optional Address 1</td>''+             
 ''<td class=headerbold>Optional Address 2</td>''+             
 ''<td class=headerbold>Remittance Message</td>''+             
 ''<td class=headerbold>Department of backup information</td>''+             
 ''<td class=headerbold>Contact Person</td>''+          
 ''<td class=headerbold>Multi Payment</td>''+            
 ''<td class=headerbold>Number of Recurring payments</td>''+             
 ''<td class=headerbold>Recurring payment amount</td>''+               
 ''<td class=headerbold>First payment due date</td>''+           
 ''<td class=headerbold>Frequency</td>''+            
 ''<td class=headerbold>Last payment hold</td>''+             
 ''<td class=headerbold>Return Check</td>''+             
 ''<td class=headerbold>Return Check to</td>''+             
 ''<td class=headerbold>Reason for return check</td>''+             
 ''<td class=headerbold>Include Mail stop</td>''+             
 ''<td class=headerbold>Location</td>''+             
 ''<td class=headerbold>Specific Limit</td>''+          
 ''<td class=headerbold>Specific limit type</td>''+         
 ''<td class=headerbold>Approvers email ID1</td>''+         
 ''<td class=headerbold>BAP Code</td>''+         
 ''<td class=headerbold>Payment Type</td>''+         
 ''<td class=headerbold>Payment Term</td>''+         
 ''<td class=headerbold>Payment Due date</td>''+         
 ''<td class=headerbold>Approval Decision</td>''+         
 ''<td class=headerbold>Approver Comments</td>''+         
 ''<td class=headerbold>Additional Comments</td>''+            
  +''</tr></font>''               
              
  UNION ALL               
              
  Select ''<tr> <td align=left style=mso-number-format:\\@>''+ISNULL([Wi_Name],'''')+''</td>''+           
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Introduction_Type],'''')+''</td>''+            
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([WIIntroducedBy],'''')+''</td>''+            
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([current_Work_Step],'''')+''</td>''+            
 ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Registration_Date],''''),120)+''</td>''+          
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Priority],'''')+''</td>''+            
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Document_category],'''')+''</td>''+            
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Pre_Paid],'''')+''</td>''+             
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Coder_Code],'''')+''</td>''+            
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Prepared_By_NAME],'''')+''</td>''+            
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Prepared_by_Email_Id],'''')+''</td>''+             
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Prepared_by_Phone_Number],'''')+''</td>''+            
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Invoice_Number],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Invoice_Date],''''),120)+''</td>''+             
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Total_Invoice_Amount],'''')+''</td>''+           
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([PO_Number],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Name],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_number],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([W9_Indicator],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([ACH],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([AP_Check],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([ABA],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Account],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Email_id],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Payee],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Address_Line_1],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Address_Line_2],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([City_Address_Line_3],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([State_Code],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Country_Code],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Postal_code],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Optional_Address_1],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Optional_Address_2],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Remittance_Message],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Department_of_backup_information],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Contact_Person],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Multi_Payment],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Number_of_Recurring_payments],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Recurring_payment_amount],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([First_payment_due_date],''''),120)+''</td>''+          
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Frequency],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Last_payment_hold],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Return_Check],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Return_Check_to],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Reason_for_return_check],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Include_Mail_stop],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Location],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Specific_Limit],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Specific_limit_type],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Approvers_email_ID1],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([BAP_Code],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Payment_Type],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Payment_Term],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Payment_Due_date],''''),120)+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Approval_Decision],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Approver_Comments],'''')+''</td>''+         
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Additional_Comments],'''')+''</td>''           
  from #AP_TEMP_TABLE_Introduction')             
            
  select @status_temp='</tr></table><table><tr><td><b>DATE RANGE</b></td></tr>'               
  select @status_temp=@status_temp+'</table>'            
  exec('insert into NG_TEMP_AUTOMAIL select '''+@status_temp+'''   ')               
            
  update NG_TEMP_AUTOMAIL set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yy>&nbsp</td>')            
            
  SET @Query='Master..xp_Cmdshell ''bcp "select Header FROM GMAC..NG_TEMP_AUTOMAIL order by row_index asc" queryout "'+@FileName+'" -c -T'',no_output'    
            
  exec(@Query)            
            
  insert into NG_AutoMail_Status values('Introduction Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL)            
  --select @RowCount               
  --drop table #AP_TEMP_TABLE_ManualIntro              
  drop table NG_TEMP_AUTOMAIL             
  End             
END              
 select @RowCount             
 End 
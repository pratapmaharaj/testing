<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ include file="customized.process" %>
<%@ page import="java.sql.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>

<HTML>
<HEAD>
<TITLE>AP Introduction Report</TITLE>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="/../../../omniflow/scripts/wfgeneral.js">

</script>


<body>

<%!

 public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }


%>

<%

   Connection conn = null;
	Statement st;
	//String connectionUrl =""; // "jdbc:sqlserver://10.33.193.222:1433;" +"databaseName=gmac;user=ofuser;password=ofuser";
	boolean empty=true;

	String sProcedureName=null;
	String sColumnHeaders=null;
	String sReportName=null;
	String sFileName=null;
	String sNumberOfColumns=null;
	String sProcedureNameKey=null;
	String sColumnHeadersKey=null;
	String sFileNameKey=null;
	String sNumberOfColumnsKey=null;
	String sHeaderKey=null;
	String sHeaderPresentKey=null;
	String sDBMappedColsKey=null;
	String sHeaderValue=null;
	String sHeaderPresentValue=null;
	String sCabinetName=null;	
	String sDBMappedCols=null;
	String sFieldValuesKey=null;
	String sFieldValues=null;
	String sFieldValuesReport="";
	String sUserMailID=null;
	String sFileNamePathKey="";
	String sFilePath="";
	

	sReportName	=request.getParameter("ReportName");
	sReportName	=sReportName.toUpperCase();
	sUserMailID=request.getParameter("UserEmailID");
	sProcedureNameKey=sReportName +"_PROCEDURENAME";
	sColumnHeadersKey=sReportName+"_COLUMNHEADERS";
	sFileNameKey=sReportName+"_FILENAME";
	sFileNamePathKey=sReportName+"_FILEPATH";
	sNumberOfColumnsKey=sReportName+"_NUMBEROFCOLUMNS";
	sHeaderPresentKey=sReportName+"_HEADERPRESENT";
	sHeaderKey=sReportName+"_HEADER";
	sDBMappedColsKey=sReportName+"_DBMAPPEDCOLS";
	sFieldValuesKey=sReportName+"_FIELDVALUES";
	
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAAPIntroductionReport.ini";
	//String sRootPathini=application.getRealPath("")+File.separator+"reports"+File.separator+"GMACReports"+File.separator+"ApprovalProcessIntroductionReport" + File.separator + "Report.ini";

	Properties ini = new Properties();
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("TA_AP_Introduction_Report","Unable to read TA_AP_Introduction_Report.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("TA_AP_Introduction_Report","Unable to close the TA_AP_Introduction_Report.ini file");
						}
					}
				}


    sCabinetName=ini.getProperty("CABINETNAME");
	sProcedureName     =ini.getProperty(sProcedureNameKey);
	sColumnHeaders     =ini.getProperty(sColumnHeadersKey);
	sFileName          =ini.getProperty(sFileNameKey);
	sNumberOfColumns   =ini.getProperty(sNumberOfColumnsKey);
	sHeaderPresentValue=ini.getProperty(sHeaderPresentKey);
	sDBMappedCols      =ini.getProperty(sDBMappedColsKey);
	sFieldValues       =ini.getProperty(sFieldValuesKey);
	sFilePath		   =ini.getProperty(sFileNamePathKey);
	/*connectionUrl      =ini.getProperty("ConnectionUrl");
	String dbuserName = ini.getProperty("username");
	String dbpass     = ini.getProperty("password");*/

	// "jdbc:sqlserver://10.33.193.222:1433;" +"databaseName=gmac;user=ofuser;password=ofuser";
	//connectionUrl = connectionUrl+";"+"databaseName="+sCabinetName+";user="+dbuserName+";password="+dbpass;
	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("AP_Aging","sRootPathDBini="+sRootPathDBini);
	
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("TA_AP_Introduction_Report","Unable to read TA_AP_Introduction_Report.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("TA_AP_Introduction_Report","Unable to close the TA_AP_Introduction_Report.ini file");
						}
					}
				}
	
	String driverName = null;

	String connectionUrl=ini.getProperty("CONNECTIONSTRING");
	driverName = ini.getProperty("DRIVERNAME");
	CallableStatement callableStatement = null;

	WriteLog("TA_AP_Introduction_Report"," output "+connectionUrl);

	if(sHeaderPresentValue.equals("YES")) 
	{
		sHeaderValue=ini.getProperty(sHeaderKey);
	}

	String sDocumentCategoryType=request.getParameter("DocumentCategoryType");
	String sIntroductionType=request.getParameter("IntroductionType");
	String sIntroductionQueue=request.getParameter("IntroductionQueue");
	String sVendorName=request.getParameter("VendorName");
	String sVendorNumber=request.getParameter("VendorNumber");
	String sPreparedByName=request.getParameter("PreparedByName");
	String sFromDate    =request.getParameter("DateRangeFrom");
	String sToDate      =request.getParameter("DateRangeTo");
	String returnCheck      =request.getParameter("returnCheck");

	String sOutputXML ="";
	String sInputXML  ="";
	String maincode   ="";
	String Totalrec   ="0";
	String 	sStr_ServerType="";

	String url         ="";
	String Status      ="";
	String sInputXml   ="";
	double fPercentage =0;
	String 	sReturnValue="";
	String sColumnNamesArr[]=split(sColumnHeaders,',');
	String sFinalColumns[]=split(sColumnHeaders,',');
	String sDBMappedColsArr[]=split(sDBMappedCols,',');
	for(int i=0;i<sColumnNamesArr.length;i++)
	{
		if(sColumnNamesArr[i].indexOf("~D")!=-1)
			sFinalColumns[i]=sColumnNamesArr[i].substring(0,sColumnNamesArr[i].length()-2);

	}
		String sFieldNamesDB[]=split(sFieldValues,'#');

		for(int i=0;i<sFieldNamesDB.length;i++)
		{
			sFieldValuesReport=sFieldValuesReport+sFieldNamesDB[i]+',';
		}
	sFieldValuesReport =sFieldValuesReport.substring(0,sFieldValuesReport.length()-1);
	String sRowXml="";
	int iJtsPort = 0;
	boolean bError=false;

	WriteLog("TA_AP_Introduction_Report"," output "+sProcedureName);
	
	String getDBUSERByUserIdSql = "{call "+sProcedureName+"(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
	String output = "" ;
	try
	{
		WriteLog("TA_AP_Introduction_Report"," sDocumentCategoryType "+sDocumentCategoryType);
		WriteLog("TA_AP_Introduction_Report"," sVendorName "+sVendorName);
		WriteLog("TA_AP_Introduction_Report"," sFromDate "+sFromDate);
		WriteLog("TA_AP_Introduction_Report"," sToDate "+sToDate);
		WriteLog("TA_AP_Introduction_Report"," sFieldValuesReport "+sFieldValuesReport);
		WriteLog("TA_AP_Introduction_Report"," sUserMailID "+sUserMailID);
		WriteLog("TA_AP_Introduction_Report"," returnCheck "+returnCheck);

			Class.forName(driverName);
			conn = DriverManager.getConnection(connectionUrl);
			callableStatement = conn.prepareCall(getDBUSERByUserIdSql);
			callableStatement.setString(1, sDocumentCategoryType);
			callableStatement.setString(2, sIntroductionType);
			callableStatement.setString(3, sIntroductionQueue);
			callableStatement.setString(4, sVendorName);
			callableStatement.setString(5, sVendorNumber);
			callableStatement.setString(6, sPreparedByName);
			callableStatement.setString(7, sFromDate);
			callableStatement.setString(8, sToDate);
			callableStatement.setString(9, sFieldValuesReport);
			callableStatement.setString(10, sUserMailID);
			callableStatement.setString(11, sFilePath);
			callableStatement.setString(12, sFileName);
			callableStatement.setString(13, returnCheck);
			callableStatement.registerOutParameter(14, java.sql.Types.VARCHAR);
			callableStatement.execute();

			output = callableStatement.getString(14);
			WriteLog("TA_AP_Introduction_Report"," output "+output);
	}
	catch(SQLException ignore)
	{
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		bError= true;
		WriteLog("TA_AP_Introduction_Report"," WFSession Data Fetch Exception:::::: "+ignore.toString());
	}
	finally {
 
	if (callableStatement != null) {
        try {
            callableStatement.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
	}

	if(!bError)
	{

		WriteLog("TA_AP_Introduction_Report"," output:::::: "+output);
		try
		{

			if(output.equals(""))
			{
				bError= true;
				//maincode=sOutputXML.substring(sOutputXML.indexOf("<MainCode>")+10 , sOutputXML.indexOf("</MainCode>"));
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+output+"</b></font><center>");
			}
			else
			{
				
					try
							{
								 if(Integer.parseInt(output) == 0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
								out.println(ig.toString());
												
							}
			}
		}
		
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
			log("Introduction Report Exception : "+exp.toString());
		}
		
	}

%>

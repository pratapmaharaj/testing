

<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>

<%@ include file="customized.process" %>


<HTML>
<HEAD>
<TITLE>AP Interface Report</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>
<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
	
}
</style>
<script>

	$(document).ready(function(){$('#From_Date_Into').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", disabled: true,
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date_Inter').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", disabled: true,
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#From_Date_Inter').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", disabled: true,
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date_Into').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", disabled: true,
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	});
	var FromDate = new Date();
	var type = '';
	var allWindows = new Array();
	var win; // new window object
/*functions echeck,ValidateForm*/

 	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}
	
	function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}

function ValidateForm(emailID){
//	var emailID=document.frmSample.txtEmail
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }


 function ChangeDateTag(obj)
{
	var InsertVal='';
	for(iterate=0;iterate<obj.length;iterate++)
	{
		if(obj.options[iterate].selected==true)
		{
			InsertVal=InsertVal+obj.options[iterate].value+'/';
		}
	}
	InsertVal=InsertVal.substring(0,InsertVal.length-1);
	var Table=document.getElementById('newgen');
	var lastRow = Table.rows.length;
	if (lastRow > 0) Table.deleteRow(lastRow - 1);
	while(InsertVal.indexOf('_')!=-1)
	{
		InsertVal=InsertVal.replace('_',' ');
	}
	var Row=Table.insertRow(0);
	var Cell=Row.insertCell();
	Cell.className="EWLabelBoldNew";
	Cell.innerHTML=InsertVal;
}

function DateComparator(Date_To,Date_From)
{	


	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));	
	var Date_From_month=Date_From.substring(Date_From.indexOf("/")+1,Date_From.lastIndexOf("/"));

	/*converting ToDate month to number */
	if(Date_To_month=="JAN")
			Date_To_month="01";
		else if(Date_To_month=="FEB")
			Date_To_month="02";
		else if(Date_To_month=="MAR")
			Date_To_month="03";
		else if(Date_To_month=="APR")
			Date_To_month="04";
		else if(Date_To_month=="MAY")
			Date_To_month="05";
		else if(Date_To_month=="JUN")
			Date_To_month="06";
		else if(Date_To_month=="JUL")
			Date_To_month="07";
		else if(Date_To_month=="AUG")
			Date_To_month="08";
		else if(Date_To_month=="SEP")
			Date_To_month="09";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";


	/*converting FromDate month to number */
		if(Date_From_month=="JAN")
			Date_From_month="01";
		else if(Date_From_month=="FEB")
			Date_From_month="02";
		else if(Date_From_month=="MAR")
			Date_From_month="03";
		else if(Date_From_month=="APR")
			Date_From_month="04";
		else if(Date_From_month=="MAY")
			Date_From_month="05";
		else if(Date_From_month=="JUN")
			Date_From_month="06";
		else if(Date_From_month=="JUL")
			Date_From_month="07";
		else if(Date_From_month=="AUG")
			Date_From_month="08";
		else if(Date_From_month=="SEP")
			Date_From_month="09";
		else if(Date_From_month=="OCT")
			Date_From_month="10";
		else if(Date_From_month=="NOV")
			Date_From_month="11";
		else if(Date_From_month=="DEC")
			Date_From_month="12";
	
	var Date_To_date=Number(Date_To.substring(Date_To.indexOf("0"),Date_To.indexOf("/")));	
	var Date_From_date=Number(Date_From.substring(Date_From.indexOf("0"),Date_From.indexOf("/")));

		
	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));
	var Date_From_year=Number(Date_From.substring(Date_From.lastIndexOf("/")+1,Date_From.length));


	if(Date_To_year<Date_From_year)
	{
		alert("To Date cannot be less than From  Date.");
		return false;
	}
	else if(Date_To_year>Date_From_year)
	{
		
		//if(Date_From_month>Date_To_month)
		//{
		//alert("To Date can not be less than From Date.");
		//return false;
		//}
		 if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{
				
				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}
	else if(Date_To_year==Date_From_year)
	{
	
		if(Date_From_month>Date_To_month)
		{
		alert("To Date can not be less than From Date.");
		return false;
		}
		else if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{

				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}
return true;
}


function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";
	sDate	= window.showModalDialog('/processmanager/reports/GMACReports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');
	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
	

}
function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	strResult=strdate+"/"+strMonth+"/"+stryear;
	return strResult;
}


	
	
	function openreport()
	{	
		var From_Date_Into="";
		var To_Date_Into=''
		var Document_Category="";
		var Vendor_Name="";
		var Vendor_Number="";
		var QC_Decision='';
		var UserEmailID=document.getElementById('EMail-ID').value;

		From_Date_Into=document.forms["textForm"].From_Date_Into.value;
		To_Date_Into=document.forms["textForm"].To_Date_Into.value;
		From_Date_Inter=document.forms["textForm"].From_Date_Inter.value;
		To_Date_Inter=document.forms["textForm"].To_Date_Inter.value;
		Vendor_Name=document.forms["textForm"].Vendor_Name.value;
		Vendor_Number=document.forms["textForm"].Vendor_Number.value;
		//alert(UserEmailID+''+RegDateRangeFrom+''+RegDateRangeTo+''+QDateRangeFrom+''+QDateRangeTo);
	
		for(var j=0;j<document.forms["textForm"].Document_Category.length;j++)
		{
			if(document.forms["textForm"].Document_Category[j].selected)
			{
				
				Document_Category=Document_Category+document.forms["textForm"].Document_Category[j].value+'~';
				
			}
		}

		var sTestDoc=Document_Category.split('~');
		

	//------------------------------------Document Category Validation start--------------------------------		
		if(Document_Category==''){
		alert("Please Select Document Category");
		return false;
		}
		if(Document_Category.indexOf("All~")>-1 && sTestDoc.length>2)
		{
			alert("No other Document Category can be chosen after choosing All");
			return false;
			//VendorType='All~';

		} 	
	/*	
	//------------------------------------Document Category End--------------------------------			
		
	//------------------------------------Vendor name Validation start--------------------------------		
		
		if(Vendor_Name=='')
		{
		alert("Please Enter an appropriate Vendor Name");
			return false;
		}
	//-----------------------------------------------End----------------------------------------------
	//--------------------------------Vendor Number Validation Start------------------------------------
		if(Vendor_Number=='')
		{
		alert("Please Enter an appropriate Vendor Number");
			return false;
		}
	//---------------------------------------End-----------------------------------------------------
*/
	//------------------------------------Date Validation start--------------------------------		
	if(!document.getElementById('Introduction').checked && !document.getElementById('Interface').checked)
		{
		alert("Please Select Introduction Date Or Interface Date");
		return false;
		}
		else{
		if(document.getElementById('Introduction').checked){
		if(From_Date_Into=='')
		{
			alert("Please select Introduction FromDate");
				return false;
		}
		if(To_Date_Into==''){
			alert("Please select Introduction ToDate");
				return false;
		}
		}
		
		if(document.getElementById('Interface').checked){
		if(From_Date_Inter=='')
		{
			alert("Please select Interface FromDate");
				return false;
		}
		if(To_Date_Inter==''){
			alert("Please select Interface ToDate");
				return false;
		}
		}
		}
	//------------------------------------Date Validation End--------------------------------		
	
	
	//------------------------------------UserEmail Validation start--------------------------------	
		
		if(UserEmailID=='')
		{
			alert("Kindly enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
				
			}
		}
  //-------------------------------------END-----------------------------------------------------

		if(Document_Category=='PO Invoices~Non PO Invoices~Policy Holder Payments~Escheatment~Credit Memo~Statement~Others~')
		{
			Document_Category='All~';
		}

		
		if(UserEmailID!='')
			{	
		/*	
		window.top.APINTERFACEEREPORT.location.href="APInterfaceReportGenerate.jsp?From_Date_Into="+From_Date_Into+"&To_Date_Into="+To_Date_Into+"&Document_Category="+Document_Category+"&Vendor_Name="+Vendor_Name+"&Vendor_Number="+Vendor_Number+"&From_Date_Inter="+From_Date_Inter+"&To_Date_Inter="+To_Date_Inter+"&ReportName=<%=request.getParameter("ReportName")%>&UserEmailID="+UserEmailID;
		
	*/
	//window.open("APInterfaceReportGenerate.jsp?From_Date_Into="+From_Date_Into+"&To_Date_Into="+To_Date_Into+"&Document_Category="+Document_Category+"&Vendor_Name="+Vendor_Name+"&Vendor_Number="+Vendor_Number+"&From_Date_Inter="+From_Date_Inter+"&To_Date_Inter="+To_Date_Inter+"&ReportName=<%=request.getParameter("ReportName")%>&UserEmailID="+UserEmailID);

	//OpenRedict-Fix	
	//window.top.APINTERFACEEREPORT.location.href="APInterfaceReportGenerate.jsp?From_Date_Into="+From_Date_Into+"&To_Date_Into="+To_Date_Into+"&Document_Category="+Document_Category+"&Vendor_Name="+Vendor_Name+"&Vendor_Number="+Vendor_Number+"&From_Date_Inter="+From_Date_Inter+"&To_Date_Inter="+To_Date_Inter+"&ReportName=<%=request.getParameter("ReportName")%>&UserEmailID="+UserEmailID;
	
	var URI = "APInterfaceReportGenerate.jsp?From_Date_Into="+From_Date_Into+"&To_Date_Into="+To_Date_Into+"&Document_Category="+Document_Category+"&Vendor_Name="+Vendor_Name+"&Vendor_Number="+Vendor_Number+"&From_Date_Inter="+From_Date_Inter+"&To_Date_Inter="+To_Date_Inter+"&ReportName=<%=request.getParameter("ReportName")%>&UserEmailID="+UserEmailID;
	var StrOpenWin=strip_tags(URI,"");
	window.top.APINTERFACEEREPORT.location.href=StrOpenWin;
	
	
	
			}
			
	
}
		function disbFields()
 {
 	document.getElementById('From_Date_Inter').value='';
	document.getElementById('To_Date_Inter').value='';
	document.getElementById('From_Date_Into').value='';
	document.getElementById('To_Date_Into').value='';
	//document.getElementById('From_Date_IMG_Inter').disabled=true;
	//document.getElementById('To_Date_IMG_Inter').disabled=true;
	//document.getElementById('From_Date_IMG_Into').disabled=true;
	//document.getElementById('To_Date_IMG_Into').disabled=true;

 	document.getElementById('From_Date_Inter').style.background='Gray';
	document.getElementById('To_Date_Inter').style.background='Gray';
	document.getElementById('From_Date_Into').style.background='Gray';
	document.getElementById('To_Date_Into').style.background='Gray';

 }
function chkradio(obj)
	{
		if(obj == 'i')
		{
			if(document.getElementById('Interface').checked == true) 
			{
				document.getElementById('Interface').checked = false;
			}
			document.getElementById('From_Date_Inter').value='';
			document.getElementById('To_Date_Inter').value='';
			document.getElementById('From_Date_Inter').style.background='Gray';
			document.getElementById('To_Date_Inter').style.background='Gray';
			//document.getElementById('From_Date_IMG_Inter').disabled=true;
			//document.getElementById('To_Date_IMG_Inter').disabled=true;
			//document.getElementById('From_Date_IMG_Into').disabled=false;
			//document.getElementById('To_Date_IMG_Into').disabled=false;
			document.getElementById('From_Date_Into').style.background='White';
			document.getElementById('To_Date_Into').style.background='White';
			$('#From_Date_Into').datepicker("enable");
			$('#To_Date_Into').datepicker("enable");
			$('#From_Date_Inter').datepicker("disable");
			$('#To_Date_Inter').datepicker("disable");
		}
		else if(obj == 'd')
		{
			if(document.getElementById('Introduction').checked == true) 
			{
				document.getElementById('Introduction').checked = false;
			}
			document.getElementById('From_Date_Inter').style.background='White';
			document.getElementById('To_Date_Inter').style.background='White';
			document.getElementById('From_Date_Into').style.background='Gray';
			document.getElementById('To_Date_Into').style.background='Gray';
			//document.getElementById('From_Date_IMG_Into').disabled=true;
			//document.getElementById('To_Date_IMG_Into').disabled=true;
			document.getElementById('From_Date_Into').value='';
			document.getElementById('To_Date_Into').value='';
			$('#From_Date_Into').datepicker("disable");
			$('#To_Date_Into').datepicker("disable");
			$('#From_Date_Inter').datepicker("enable");
			$('#To_Date_Inter').datepicker("enable");

			//document.getElementById('From_Date_IMG_Inter').disabled=false;
			//document.getElementById('To_Date_IMG_Inter').disabled=false;
		}

	}


	
</script>

<body topmargin="0" leftmargin="5" onunload="UnloadReportWindow();" onload="disbFields();" >

			<form name='textForm' method=post>


			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">TA AP INTERFACE REPORT</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This will be a daily scheduled report with list of all the workitems that have been sent for interface with GEAC on a given day. 
</td></tr>
<tr><td class="EWLabel1"> 
Following columns will be present in the report.
</td></tr>
<tr><td class="EWLabel1">
</td></tr><tr><td class="EWLabel1">Select the requisite date range for generating the report for the same.</td>
				</tr>
				
				<td>
		<br/>
					<p style="color: red; font-size: 10pt">Note:  * fields are mandatory.</p>

				</td>
			</table>

			

			<table border="0" width="95%" cellspacing="1" align="center">
				
				
				  <tr>
					<td class="EWLabel1" align="left" width='30%'><b>Document Category</b></font></td>
					<td width='25%' colspan=3>
					<select name="Document_Category" multiple>
					<option value="All">All</option>
					<option value="PO Invoices">PO Invoices</option>
					<option value="Non PO Invoices">Non PO Invoices</option>
					<option value="Policy Holder Payments">PH Payments</option>
					<option value="Escheatment">Escheatment</option>
					<option value="Credit Memo">Credit Memo</option>
					<option value="Statement">Statement</option>
					<option value="Others">Others</option>
					
				
					</select>
					</td>
				</tr>
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Vendor Name</b></td>
					<td >
					<input type='text' name='Vendor_Name' style='width:145' id='Vendor_Name'>
					</td>
				</tr>
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Vendor Number</b></td>
					<td >
					<input type='text' name='Vendor_Number' style='width:145' id='Vendor_Number'>
					</td>
				</tr>
				<tr>&nbsp;</tr>
				
				<tr>
					<td>
					<p class="EWLabel122"><input type = "radio" name ="Introduction" id ="Introduction" value = "Introduction" align='left' style="width: 14px" onClick="chkradio('i')">Introduction Date<font color="RED">*</font></p></td>
					</tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date_Into" readonly type="text"  id="From_Date_Into" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date_Into" readonly type="text"  id="To_Date_Into" >
					
					</td>

				</tr>
				<tr>&nbsp;</tr>
				
				<tr>
					<td>
					<p class="EWLabel122"><input type = "radio" name ="Interface" id ="Interface" value = "Interface" align='left' style="width: 14px" onClick="chkradio('d')">Interface Date<font color="RED">*</font></p></td>
					</tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date_Inter" readonly type="text"  id="From_Date_Inter" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date_Inter" readonly type="text"  id="To_Date_Inter" >
					
					</td>

				</tr>
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID<font color="RED">*</font></b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>

				
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>
	
			
			</form>
</body>
</Html>	 




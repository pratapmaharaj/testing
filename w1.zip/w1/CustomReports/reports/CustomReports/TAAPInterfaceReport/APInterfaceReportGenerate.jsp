<%@ include file="customized.process" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.sql.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="com.tcsta.util.PathUtil" %>

<HTML>
<HEAD>
<TITLE>AP Interface Report</TITLE>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="/../../../omniflow/scripts/wfgeneral.js">
</script>

<body >
<%!

 public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }
%>

<%
WriteLog("AP_Interface","sOutputXML ::> sOutputXML : IN APAgingGenerate") ;

	String sProcessDefId=null;
	String sProcedureName=null;
	String sColumnHeaders=null;
	String sReportName=null;
	String sFileName=null;
	String sNumberOfColumns=null;
	String sProcedureNameKey=null;
	String sColumnHeadersKey=null;
	String sFileNameKey=null;
	String sNumberOfColumnsKey=null;
	String sHeaderKey=null;
	String sHeaderPresentKey=null;
	String sDBMappedColsKey=null;
	String sHeaderValue=null;
	String sHeaderPresentValue=null;
	String sCabinetName=null;	
	String sDBMappedCols=null;
	String sFieldValuesKey=null;
	String sFieldValues=null;
	String sFieldValuesReport="";
	String sUserMailID=null;
	String sFilePath=null;
	String sFilePathKey=null;
	String UserNames = "" ;
	
	sReportName	=request.getParameter("ReportName");
	sUserMailID=request.getParameter("UserEmailID");
	sReportName	=sReportName.toUpperCase();
	
	WriteLog("AP_Interface","sReportName : "+sReportName) ;
	WriteLog("AP_Interface","sUserMailID : "+sUserMailID) ;

	sProcedureNameKey=sReportName +"_PROCEDURENAME" ;
	WriteLog("AP_Interface","sProcedureNameKey : "+sProcedureNameKey) ;
	
	sColumnHeadersKey=sReportName+"_COLUMNHEADERS";
	
	WriteLog("AP_Interface","sColumnHeadersKey : "+sColumnHeadersKey) ;
	sFileNameKey=sReportName+"_FILENAME";

	WriteLog("AP_Interface","sFileNameKey : "+sFileNameKey) ;

	sNumberOfColumnsKey=sReportName+"_NUMBEROFCOLUMNS";

	WriteLog("AP_Interface","sNumberOfColumnsKey : "+sNumberOfColumnsKey) ;

	sHeaderPresentKey=sReportName+"_HEADERPRESENT";

	WriteLog("AP_Interface","sHeaderPresentKey : "+sHeaderPresentKey) ;
	
	sHeaderKey=sReportName+"_HEADER";

	WriteLog("AP_Interface","sHeaderKey : "+sHeaderKey) ;
	
	sDBMappedColsKey=sReportName+"_DBMAPPEDCOLS";
	WriteLog("AP_Interface","sDBMappedColsKey : "+sDBMappedColsKey) ;
	sFieldValuesKey=sReportName+"_FIELDVALUES";

	WriteLog("AP_Interface","sFieldValuesKey : "+sFieldValuesKey) ;
	
	sFilePathKey=sReportName+"_PATH";
	
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAAPInterfaceReport.ini";
	//String sRootPathini=application.getRealPath("")+File.separator+"reports"+File.separator+"GMACReports"+File.separator+"ApprovalProcessInterfaceReport" + File.separator + "reports.ini";
	Properties ini = new Properties();
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("AP_Interface","Unable to read AP_Interface.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("AP_Interface","Unable to close the AP_Interface.ini file");
						}
					}
				}
	

	//WriteLog("AP_Interface","sOutputXML ::> sFieldValuesKey : "+sFieldValuesKey);
	
	
	String pathName = "" ;
	pathName = ini.getProperty(sReportName +"_PATH");
	sProcessDefId=ini.getProperty("PROCESSDEFID");
	
	sCabinetName=ini.getProperty("CABINETNAME");
	sProcedureName=ini.getProperty(sProcedureNameKey);
	
	sColumnHeaders=ini.getProperty(sColumnHeadersKey);
	
	sFileName=ini.getProperty(sFileNameKey);
	
	sNumberOfColumns=ini.getProperty(sNumberOfColumnsKey);
	
	sHeaderPresentValue=ini.getProperty(sHeaderPresentKey);
	
	sDBMappedCols=ini.getProperty(sDBMappedColsKey);
	
	sFieldValues=ini.getProperty(sFieldValuesKey);
	
	sFilePath=ini.getProperty(sFilePathKey);
WriteLog("AP_Interface","sHeaderPresentValue"+sHeaderPresentValue);
WriteLog("AP_Interface","sCabinetName"+sCabinetName);
WriteLog("AP_Interface","sProcedureName"+sProcedureName);
WriteLog("AP_Interface","sFileName"+sFileName);
WriteLog("AP_Interface","sNumberOfColumns"+sNumberOfColumns);
WriteLog("AP_Interface","sHeaderPresentValue"+sHeaderPresentValue);
WriteLog("AP_Interface","sDBMappedCols"+sDBMappedCols);


	if(sHeaderPresentValue.equals("YES")) 
	{
		sHeaderValue=ini.getProperty(sHeaderKey);
	}

	String sCabname=null;
	String sSessionId = null;
	String sJtsIp = null;
	String sUserName = null;
	String sReportProcedureName=null;
	String sReportTableName=null;
	String sOutputXML="";
	String sInputXML = "";
	String maincode = "";
	String Totalrec = "0";
	String url = "";
	String Status="";
	String sStr_ServerType="";
	String sInputXml="";
	double fPercentage=0;
		
	String sColumnNamesArr[]=split(sColumnHeaders,',');
	String sDBMappedColsArr[]=split(sDBMappedCols,',');
	String sFinalColumns[]=split(sColumnHeaders,',');
	
	for(int i=0;i<sColumnNamesArr.length;i++)
	{
		if(sColumnNamesArr[i].indexOf("~D")!=-1)
			sFinalColumns[i]=sColumnNamesArr[i].substring(0,sColumnNamesArr[i].length()-2);

	}

	String sFieldNamesDB[]=split(sFieldValues,'#');

	for(int i=0;i<sFieldNamesDB.length;i++)
	{
		sFieldValuesReport=sFieldValuesReport+sFieldNamesDB[i]+',';
	}
	sFieldValuesReport=sFieldValuesReport.substring(0,sFieldValuesReport.length()-1);

	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("AP_Interface","sRootPathDBini="+sRootPathDBini);
	
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("AP_Interface","Unable to read AP_Interface.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("AP_Interface","Unable to close the AP_Interface.ini file");
						}
					}
				}
				
	String driverName = null;

	String connectionUrl=ini.getProperty("CONNECTIONSTRING");
	driverName = ini.getProperty("DRIVERNAME");
	WriteLog("AP_Interface"," output "+connectionUrl);
	
	String From_Date_Into=request.getParameter("From_Date_Into");
	if(From_Date_Into.equals("undefined"))
	{
		From_Date_Into="";
	}
	String To_Date_Into=request.getParameter("To_Date_Into");
	if(To_Date_Into.equals("undefined"))
	{
		To_Date_Into="";
	}
	String From_Date_Inter=request.getParameter("From_Date_Inter");
	if(From_Date_Inter.equals("undefined"))
	{
		From_Date_Inter="";
	}
	String To_Date_Inter=request.getParameter("To_Date_Inter");
	if(To_Date_Inter.equals("undefined"))
	{
		To_Date_Inter="";
	}
	String Document_Category=request.getParameter("Document_Category");
	String Vendor_Name=request.getParameter("Vendor_Name");
	String Vendor_Number=request.getParameter("Vendor_Number");

	
	WriteLog("AP_Interface","APILCRGenerate.jsp?From_Date_Into="+From_Date_Into+"&To_Date_Into="+To_Date_Into+"&Document_Category="+Document_Category+"&Vendor_Name="+Vendor_Name+"&Vendor_Number="+Vendor_Number+"&From_Date_Inter="+From_Date_Inter+"&To_Date_Inter="+To_Date_Inter+"mailid-->"+sUserMailID+"filename-->"+sFileName+"patrh--->"+sFilePath);	
	String sRowXml="";
	
	int iJtsPort = 0;
	boolean bError=false;
	
//	connectionUrl = connectionUrl+";"+"databaseName="+sCabinetName+";user="+dbuserName+";password="+dbpass;
	CallableStatement callableStatement = null;
	Connection conn=null;
	String getDBUSERByUserIdSql = "{call "+sProcedureName+"(?,?,?,?,?,?,?,?,?,?,?)}";

	String output = "" ;
	WriteLog("AP_Interface","From_Date_Into "+From_Date_Into);
	WriteLog("AP_Interface","To_Date_Into "+To_Date_Into);
	WriteLog("AP_Interface","Document_Category "+Document_Category);
	WriteLog("AP_Interface","Vendor_Name "+Vendor_Name);
	WriteLog("AP_Interface","Vendor_Number "+Vendor_Number);
	WriteLog("AP_Interface","From_Date_Inter"+From_Date_Inter);
	WriteLog("AP_Interface","To_Date_Inter"+To_Date_Inter);
	WriteLog("AP_Interface","sUserMailID"+sUserMailID);
	
	
			
	try{
			Class.forName(driverName);
			conn = DriverManager.getConnection(connectionUrl);
			callableStatement = conn.prepareCall(getDBUSERByUserIdSql);
			callableStatement.setString(1, From_Date_Into);
			callableStatement.setString(2, To_Date_Into);
			callableStatement.setString(3, Document_Category);
			callableStatement.setString(4, Vendor_Name);
			callableStatement.setString(5, Vendor_Number);
			callableStatement.setString(6, From_Date_Inter);
			callableStatement.setString(7, To_Date_Inter);
			callableStatement.setString(8, sUserMailID);
			callableStatement.setString(9, sFileName);
			callableStatement.setString(10, sFilePath);
			callableStatement.registerOutParameter(11, java.sql.Types.VARCHAR);
			callableStatement.execute();

			output = callableStatement.getString(11);
			WriteLog("AP_Interface"," output "+output);
			
	}
	catch(SQLException ignore)
	{
		%>
									<script>alert("Some Error please check logs");</script>
									<%
		WriteLog("AP_Interface"," WFSession Data Fetch Exception:::::: "+ignore.toString());
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		bError= true;
		
	}
	finally {
 
	if (callableStatement != null) {
        try {
            callableStatement.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
}
	if(!bError)
	{

		WriteLog("AP_Interface"," output:::::: "+output);
		try
		{

			if(output.equals(""))
			{
				bError= true;
					%>
					<script>alert("Error in Executing Procedure:");</script>
					<%
				//maincode=sOutputXML.substring(sOutputXML.indexOf("<MainCode>")+10 , sOutputXML.indexOf("</MainCode>"));
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+output+"</b></font><center>");
				
				
			}
			else
			{
				
					try
							{
								 if(Integer.parseInt(output) == 0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
							log("AP_Interface "+ig.toString());
							%>
									<script>alert("Some Error please check logs");</script>
									<%
								out.println(ig.toString());
												
							}
			}
		}
		
		catch(Exception exp)
		{
			%>
									<script>alert("Some Error please check logs");</script>
									<%
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
			log("AP_Interface "+exp.toString());
		}
		
	}

%>
        
  /*          
   AP_POTENTIAL_DUPLICATE_REPORT 'All~','','','03/JAN/2014','24/FEB/2014','WI_Name,Document_Category,Vendor_Name,Vendor_Number,Invoice_Number,Invoice_Date,Total_Invoice_Amount','aa@gnma.com','//10.33.192.139/XLS-File/Yogesh/Manual','Introduction',''      
 
*/        
CREATE PROCEDURE AP_POTENTIAL_DUPLICATE_REPORT        
(        
@DocumentCategory  VARCHAR(200),         
@VendorName  VARCHAR(200),     
@VendorNumber  VARCHAR(200),        
@DateRangeFrom  VARCHAR(100),        
@DateRangeTo  VARCHAR(100),        
@Fields varchar(8000),        
@EmailID varchar (100) ,        
@FilePath  varchar(200),        
@FileName  varchar(200),        
@RowCount INT OUTPUT        
)        
        
AS          
SET NOCOUNT ON        
Begin          
 declare        
 @WhereQuery varchar(2000),        
 @Query varchar(5000),        
 @Tables varchar(200),        
 @DocumentCategoryReport varchar(200),        
 @VendorNameReport varchar(200),    
 @VendorNumberReport varchar(200),     
 @OrderBy varchar(300)  ,        
 @status_temp varchar(8000)         
        
 set @WhereQuery =''        
 set @Query =''          
 set @Tables =''          
 set @DocumentCategoryReport =''          
 set @VendorNameReport =''          
 set @VendorNumberReport =''     
 set @OrderBy =''          
 set @RowCount =0          
 set @status_temp =''          
        
 if Object_ID('#AP_TEMP_TABLE_Potential_Duplicate') is not null          
 begin          
  print 'Table dropped'          
  exec('drop table #AP_TEMP_TABLE_Potential_Duplicate')          
 end        
        
 CREATE TABLE #AP_TEMP_TABLE_Potential_Duplicate (       
  WI_Name VARCHAR(100),              
  Document_Category VARCHAR(100),       
  Vendor_Name VARCHAR(100),        
  Vendor_Number VARCHAR(100),      
  Invoice_Number  VARCHAR(100),     
  Invoice_Date  VARCHAR(100),      
  Total_Invoice_Amount  VARCHAR(100)    
)         
         
 BEGIN        
  set @FileName=@FilePath+'/'+@EmailID+'_'+@FileName+'_'+convert(varchar,getdate(),104)+'.xls'          
  set @OrderBy=' order by WI_Name'          
  set @WhereQuery='where Potential_Duplicate=''Yes'''           
  set @Tables='WNS_TA_AP_EXT_Table with(nolock)'        
        
        
  if(rtrim(ltrim(@DateRangeFrom))<>'')          
  BEGIN          
  SET @DateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@DateRangeFrom,121)))))         
  END          
  if(rtrim(ltrim(@DateRangeTo))<>'')        
  BEGIN          
  SET @DateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@DateRangeTo,121)))))        
  END      
          
  if(rtrim(ltrim(@DateRangeFrom))<>'' AND rtrim(ltrim(@DateRangeTo))<>'')        
 BEGIN        
  set @WhereQuery=@WhereQuery+' AND Registration_Date between '''+rtrim(ltrim(@DateRangeFrom))+''' AND '''+ rtrim(ltrim(@DateRangeTo))+''''        
 END      
         
 --vendor request type     
if(rtrim(ltrim(@VendorName))<>'')         
 BEGIN         
  --Added to Check for only 1 parameter         
  if(len(@VendorName)=charindex('~',@VendorName))         
  BEGIN         
   set @VendorNameReport=ltrim(rtrim(substring(@VendorName,0,len(@VendorName))))         
   set @WhereQuery=@WhereQuery+' AND Vendor_Name='''+@VendorNameReport+''''         
  END         
        
  --Added to Check for only 1 parameter           
  else         
  BEGIN         
   -----While loop ends         
   while (charindex('~',@VendorName)>1)         
   BEGIN         
    set @VendorNameReport = @VendorNameReport + ''''+ltrim(rtrim(SUBSTRING(@VendorName,1,Charindex('~',@VendorName)-1)))+''''+','         
    set @VendorName=ltrim(rtrim(Substring(@VendorName,Charindex('~',@VendorName)+len('~'),len(@VendorName))))         
   END         
        
   set @VendorNameReport=substring(@VendorNameReport,0,len(@VendorNameReport))         
   set @WhereQuery=@WhereQuery+' AND Vendor_Name in('+@VendorNameReport+')'         
  END         
 END      
    
if(rtrim(ltrim(@VendorNumber))<>'')         
 BEGIN         
  --Added to Check for only 1 parameter         
  if(len(@VendorNumber)=charindex('~',@VendorNumber))         
  BEGIN         
   set @VendorNumberReport=ltrim(rtrim(substring(@VendorNumber,0,len(@VendorNumber))))         
   set @WhereQuery=@WhereQuery+' AND Vendor_Number='''+@VendorNumberReport+''''         
  END         
        
  --Added to Check for only 1 parameter           
  else         
  BEGIN         
   -----While loop ends         
   while (charindex('~',@VendorNumber)>1)         
   BEGIN         
    set @VendorNumberReport = @VendorNumberReport + ''''+ltrim(rtrim(SUBSTRING(@VendorNumber,1,Charindex('~',@VendorNumber)-1)))+''''+','         
    set @VendorNumber=ltrim(rtrim(Substring(@VendorNumber,Charindex('~',@VendorNumber)+len('~'),len(@VendorNumber))))         
   END         
        
   set @VendorNumberReport=substring(@VendorNumberReport,0,len(@VendorNumberReport))         
   set @WhereQuery=@WhereQuery+' AND Vendor_Number in('+@VendorNumberReport+')'         
  END         
 END       
 --vendor request type     
if(rtrim(ltrim(@DocumentCategory))<>'')     
BEGIN    
 if(rtrim(ltrim(@DocumentCategory))<>'All~')                          
 BEGIN                          
  if(len(@DocumentCategory)=charindex('~',@DocumentCategory))                          
  BEGIN        
   print '1111'        
   set @DocumentCategoryReport=ltrim(rtrim(substring(@DocumentCategory,0,len(@DocumentCategory))))                          
   print @DocumentCategoryReport                  
   if (rtrim(ltrim(@DocumentCategory))<>'')                
   begin        
    set @WhereQuery=@WhereQuery+' and Document_Category ='''+@DocumentCategoryReport+''''                          
   end        
  End        
  else        
  BEGIN        
   print '2222'        
   while (charindex('~',@DocumentCategory)>1)                          
   BEGIN                         
    set @DocumentCategoryReport = @DocumentCategoryReport + ''''+ltrim(rtrim(SUBSTRING(@DocumentCategory,1,Charindex('~',@DocumentCategory)-1)))+''''+','                          
    set @DocumentCategory=ltrim(rtrim(Substring(@DocumentCategory,Charindex('~',@DocumentCategory)+len('~'),len(@DocumentCategory))))                          
    print @DocumentCategoryReport         
   END                     
   set @DocumentCategoryReport=SUBSTRING(@DocumentCategoryReport,0,len(@DocumentCategoryReport))           
   print @DocumentCategoryReport            
   print @DocumentCategory                    
   print '11111111'        
   print @DocumentCategoryReport            
   set @WhereQuery=@WhereQuery+' and Document_Category in('+@DocumentCategoryReport+')'                             
  END                          
 END        
 END       
          
        
set @WhereQuery = @WhereQuery+' and Document_Category <> '' and Vendor_Name<> and Vendor_Number<>'''      
print @WhereQuery        
        
 SET @Query='SELECT '+@Fields+' from '+ @Tables + @WhereQuery + @OrderBy        
 --print @Query          
 --exec(@Query)        
         
 set @Query='insert into #AP_TEMP_TABLE_Potential_Duplicate '+ @Query        
 print  @Query        
        
 print '----'          
 print @Query          
 exec(@Query)        
         
         
 select @RowCount=count(*) from #AP_TEMP_TABLE_Potential_Duplicate        
 PRINT  @RowCount         
 if(@RowCount=0)        
 Begin        
  drop table #AP_TEMP_TABLE_Potential_Duplicate        
 End        
 else           
 Begin          
  if Object_ID ('NG_TEMP_AUTOMAIL') is not null           
  BEGIN           
   exec('drop table NG_TEMP_AUTOMAIL')           
  END        
  PRINT '000000'          
  Exec('Create table NG_TEMP_AUTOMAIL (Header varchar(8000),ROw_Index [int] identity(1,1) not null)')           
  exec('Insert into NG_TEMP_AUTOMAIL           
  Select ''<html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>          
  <table border=1>         
  <tr>         
  <td class=headerbold>Workitem Name</td>''+        
  ''<td class=headerbold>Document category</td>''+       
  ''<td class=headerbold>Vendor Name</td>''+         
  ''<td class=headerbold>Vendor Number</td>''+         
  ''<td class=headerbold>Invoice Number</td>''+       
  ''<td class=headerbold>Invoice Date</td>''+      
  ''<td class=headerbold>Invoice Amount</td>''+         
  +''</tr></font>''           
          
  UNION ALL           
       
  Select ''<tr> <td align=left style=mso-number-format:\\@>''+ISNULL([Wi_Name],'''')+''</td>''+        
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Document_Category],'''')+''</td>''+       
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Name],'''')+''</td>''+         
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Number],'''')+''</td>''+         
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Invoice_Number],'''')+''</td>''+        
  ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Invoice_Date],''''),120)+''</td>'' +       
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Total_Invoice_Amount],'''')+''</td>''    
  from #AP_TEMP_TABLE_Potential_Duplicate')         
        
  select @status_temp='</tr></table><table><tr><td><b>DATE RANGE</b></td></tr>'           
  select @status_temp=@status_temp+'</table>'        
  exec('insert into NG_TEMP_AUTOMAIL select '''+@status_temp+'''   ')           
        
  update NG_TEMP_AUTOMAIL set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yy>&nbsp</td>')        
        
  SET @Query='Master..xp_Cmdshell ''bcp "select Header FROM GMAC..NG_TEMP_AUTOMAIL order by row_index asc" queryout "'+@FileName+'" -c -T'',no_output'         
        
  exec(@Query)        
        
  insert into NG_AutoMail_Status values('Potential Duplicate Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL)        
  --select @RowCount           
  --drop table #AP_TEMP_TABLE_Potential_Duplicate          
  drop table NG_TEMP_AUTOMAIL         
  End         
END          
 select @RowCount         
 End 

<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="java.lang.String.*"%>
<%@ page import="java.lang.Object"%>
<%@ page import="java.lang.Exception"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<HTML>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<HEAD>
<TITLE>AP Potential Duplicate Report</TITLE>
</HEAD>

<FRAMESET ROWS="100%,0%" >
	<FRAME SRC="PotentialDuplicateReport.jsp?ReportName=POTENTIALDUPLICATEREPORT" NAME="frmHeader" frameborder=no noresize scrolling=Yes>
	<FRAME SRC="" NAME="POTENTIALDUPLICATEREPORT" frameborder=no scrolling=no>
	
</FRAMESET>
</html>


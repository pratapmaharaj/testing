<!-- 
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-TA_CM
Module : GMAC-TA_CM
File Name : TAEPPRODUCTIVITYREPORTMain.jsp
Author :   
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date Change By Change Description (Bug No. (If Any))
(DD/MM/YYYY)
----------------------------------------------------------------------------------------------------
 -->

<HTML>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<HEAD>
<TITLE>TAEP Productivity Report</TITLE>
</HEAD>

<FRAMESET ROWS="100%,0%" >
	<FRAME SRC="EPProductivityReport.jsp" NAME="frmHeader" frameborder=no noresize scrolling=Yes>
	<FRAME SRC="" NAME="TAEPPRODUCTIVITYREPORT" frameborder=no scrolling=no>
	
</FRAMESET>
</html>


/*
WNS_TA_APVS_PRODUCTIVITY_REPORT 'All~','01/MAR/2014','28/MAR/2014','','','All~','Wi_ExitTime,UserName,current_work_step,a.Wi_Name,Registration_Date,Vendor_Request_Type,Vendor_type,Priority,Vendor_Name,Vendor_Number,Payment_Terms,Vendor_Status,Address_Line_1,Address_Line_2,City_Address_Line_3,State_Code,Postal_code,Additional_Comments,Approvers_Comments,Approval_Decision,Wi_EntryTime,cast(Wi_ExitTime as varchar(30)) as Wi_ExitTime1,(datediff(DD,Wi_EntryTime,Wi_ExitTime)) as Aging',' aaa@qqq.com','//10.33.200.82/crebsfs/CR_EBS_APPS_MODEL/Omniflow/Reports/VS/TAVSProductivityReport','' 
   
*/ 

ALTER PROCEDURE WNS_TA_APVS_PRODUCTIVITY_REPORT 
(
@QueueName  VARCHAR(200),      
@RegDateRangeFrom  VARCHAR(100),      
@RegDateRangeTo  VARCHAR(100),      
@QueueDateRangeFrom  VARCHAR(100),      
@QueueDateRangeTo  VARCHAR(100),      
@UserName varchar(1000),      
@Fields varchar(8000),
@EmailID varchar(200),      
@path    nvarchar(250) ,   
@RowCount varchar(200) OUTPUT      
)      
      
AS      
declare      
 @WhereQuery varchar(2000),      
 @Query varchar(5000),      
 @QueryHistory varchar(5000),      
 @QueryFinal varchar(5000),      
 @Tables varchar(200),      
 @QueueNameReport varchar(200),      
 @UserNameReport varchar(1000),      
 @OrderBy varchar(300),      
 @OrderByFinal varchar(300),
 @FileName varchar(200),      
 @USERNAMESUM varchar(100),      
 @ACTIVITYNAME varchar(100), 
 @WI_PROCESSED varchar(100), 
 @AVG_TIME varchar(100),      
 @status_temp varchar(8000),  
 @DataBaseName varchar(60),      
 @quName nvarchar(250),      
 @userN nvarchar(250) ,      
 @qname nvarchar(250),      
 @uname nvarchar(3000)      

 Set nocount on      
 BEGIN

 select @DataBaseName=DB_name()      
 if Object_ID('APVS_TEMP_TABLE_Productivity') is not null
 begin
  print 'Table dropped'
  exec('drop table APVS_TEMP_TABLE_Productivity')
 end 
      
 if Object_ID('APVSProductivitysummary') is not null
 begin
  print 'Table dropped'
  exec('drop table APVSProductivitysummary')
 end 
      
 CREATE TABLE APVS_TEMP_TABLE_Productivity (
 WI_EXITTIME NVARCHAR(100),      
 USERNAME NVARCHAR(1000),      
 ACTIVITYNAME NVARCHAR(100),      
 WI_NAME NVARCHAR(100),
 Registration_Date varchar(100),      
 Vendor_Request_Type NVARCHAR(100), 
 Vendor_type NVARCHAR(200),
 PRIORITY NVARCHAR(12), 
 VENDOR_NAME NVARCHAR(100),      
 VENDOR_NUMBER NVARCHAR(100),  
 Payment_Terms NVARCHAR(100),      
 Vendor_Status NVARCHAR(10),      
 Address_Line_1 NVARCHAR(100),
 Address_Line_2 NVARCHAR(100), 
 City_Address_Line_3  NVARCHAR(100),
 State_Code NVARCHAR(10), 
 Postal_code NVARCHAR(10),
 Additional_Comments nvarchar(512),
 Approvers_Comments NVARCHAR(512), 
 Approval_Decision NVARCHAR(100),   
 Wi_EntryTime NVARCHAR(100),  
 WI_EXITTIME1 NVARCHAR(100),      
 AGING NVARCHAR(100)      
 )      

  --Temporary Table

  --create temporary summary table  
  Create Table APVSProductivitysummary      
  (      
  USERNAME varchar(100),      
  ACTIVITYNAME varchar(100), 
  WI_PROCESSED varchar(100), 
  AVG_TIME varchar(100)  
  )      

 set @FileName=@path+'/'+@EmailID+'_VS_Productivity_Report_'+convert(varchar,getdate(),104)+'.xls'
 set @WhereQuery='WHERE '      
 set @QueueNameReport=''
 set @UserNameReport=''      
 set @RowCount ='0'      
 set @OrderBy=' order by b.UserName,current_work_step,b.wi_name,b.wi_exittime'      
 set @OrderByFinal=' order by UserName,current_work_step,wi_name,wi_exittime' 
 set @qname = ''      
 set @uname = '' 
print @FileName
 print 'Obtained Users '+@UserName      
 print 'Obtained Queues'+@QueueName
 set @Tables='WNS_TA_APVS_EXT_Table a with(nolock),WNS_TA_APVS_EntryExitTable b with(nolock )'
 set @WhereQuery=@WhereQuery+' a.wi_name=b.wi_name '      
      
 if(rtrim(ltrim(@RegDateRangeFrom))<>'')      
 BEGIN      
  SET @RegDateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@RegDateRangeFrom,121)))))
 END      
      
 if(rtrim(ltrim(@RegDateRangeTo))<>'')      
 BEGIN      
  SET @RegDateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@RegDateRangeTo,121)))))
 END      
      
 if(rtrim(ltrim(@QueueDateRangeFrom))<>'')      
 BEGIN      
  SET @QueueDateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@QueueDateRangeFrom,121)))))
 END      
 if(rtrim(ltrim(@QueueDateRangeTo))<>'')      
 BEGIN      
  SET @QueueDateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@QueueDateRangeTo,121))))) 
 END      
  ----UserName Addition      
 /*
  if(len(@UserName)=charindex('~',@UserName))      
  BEGIN      
   set @UserNameReport=ltrim(rtrim(substring(@UserName,0,len(@UserName))))      
   if(@UserName<>'') 
   begin
    set @WhereQuery=@WhereQuery+' AND b.UserName='''+@UserNameReport+''''      
    --set @userN = @UserNameReport      
   END      
  end      
  else
  BEGIN
   while (charindex('~',@UserName)>1)      
   BEGIN      
    set @UserNameReport = @UserNameReport + ''''+ltrim(rtrim(SUBSTRING(@UserName,1,Charindex('~',@UserName)-1)))+''''+','      
    set @UserName=ltrim(rtrim(Substring(@UserName,Charindex('~',@UserName)+len('~'),len(@UserName))))
    --set @userN = @userN + ''''+ltrim(rtrim(SUBSTRING(@UserName,1,Charindex('~',@UserName)-1)))+','      
   END      
   set @UserNameReport=substring(@UserNameReport,0,len(@UserNameReport))      
   --set @userN = substring(@UserNameReport,0,len(@UserNameReport))      
   if(@UserName<>'') 
   begin
    set @WhereQuery=@WhereQuery+' AND b.UserName in('+@UserNameReport+')'      
   end 
 print @UserNameReport      
  END      
  ----UserName Addition      
      
 */      
      
 if(rtrim(ltrim(@UserName))<>'All~')      
 BEGIN
  if(len(@UserName)=charindex('~',@UserName))
  BEGIN
   set @uname=ltrim(rtrim(substring(@UserName,0,len(@UserName))))      
   set @UserNameReport=ltrim(rtrim(substring(@UserName,0,len(@UserName))))      
   --set @quName = @quName+','+ltrim(rtrim(substring(@QueueName,0,len(@QueueName))))      
   set @WhereQuery=@WhereQuery+' AND b.UserName='''+@UserNameReport+''''      
  END      
  else      
  BEGIN
  while (charindex('~',@UserName)>1) 
  BEGIN      
   set @uname = @uname+ltrim(rtrim(SUBSTRING(@UserName,1,Charindex('~',@UserName)-1)))+','      
   set @UserNameReport = @UserNameReport + ''''+ltrim(rtrim(SUBSTRING(@UserName,1,Charindex('~',@UserName)-1)))+''''+','      
   set @UserName=ltrim(rtrim(Substring(@UserName,Charindex('~',@UserName)+len('~'),len(@UserName))))
   --set @quName=@quName +','+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+','      
  END      
      
  set @UserNameReport=substring(@UserNameReport,0,len(@UserNameReport))      
  set @WhereQuery=@WhereQuery+' AND b.UserName in('+@UserNameReport+')'      
 END      
 END   
      
----UserName Addition
      
      
 if(rtrim(ltrim(@QueueName))<>'All~')      
 BEGIN
  if(len(@QueueName)=charindex('~',@QueueName))
  BEGIN  
   set @qname=ltrim(rtrim(substring(@QueueName,0,len(@QueueName))))      
   set @QueueNameReport=ltrim(rtrim(substring(@QueueName,0,len(@QueueName))))      
   --set @quName = @quName+','+ltrim(rtrim(substring(@QueueName,0,len(@QueueName))))      
   set @WhereQuery=@WhereQuery+' AND current_work_step='''+@QueueNameReport+''''      
  END      
  else      
  BEGIN
   while (charindex('~',@QueueName)>1) 
   BEGIN      
    set @qname = @qname+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+','      
    set @QueueNameReport = @QueueNameReport + ''''+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+''''+','      
    set @QueueName=ltrim(rtrim(Substring(@QueueName,Charindex('~',@QueueName)+len('~'),len(@QueueName))))
    --set @quName=@quName +','+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+','      
   END      
      
   set @QueueNameReport=substring(@QueueNameReport,0,len(@QueueNameReport))      
   set @WhereQuery=@WhereQuery+' AND current_work_step in('+@QueueNameReport+')'      
  END      
 END      

 --reg Date
 if(rtrim(ltrim(@RegDateRangeFrom))<>'' AND rtrim(ltrim(@RegDateRangeTo))<>'')      
 BEGIN      
  set @WhereQuery=@WhereQuery+' AND Registration_Date between '''+rtrim(ltrim(@RegDateRangeFrom))+''' AND '''+ rtrim(ltrim(@RegDateRangeTo))+''''      
 END      
 --reg date
      
 --q date      
 if(rtrim(ltrim(@QueueDateRangeFrom))<>'' AND rtrim(ltrim(@QueueDateRangeTo))<>'')      
 BEGIN      
  set @WhereQuery=@WhereQuery+' AND Entry_Time between '''+rtrim(ltrim(@QueueDateRangeFrom))+''' AND '''+ rtrim(ltrim(@QueueDateRangeTo))+''''      
 END
 --q date
      
 print @Fields

 SET @Query='SELECT '+@Fields+' from '+ @Tables + @WhereQuery + @OrderBy      

  print '----'      
  print  @Query
  set @QueryHistory=@Query      

 --set @QueryHistory=Replace(@QueryHistory,'WNS_TA_APVS_EntryExitTable','WNS_TA_APVS_EntryExitTable_History')      

 --print @QueryHistory 
 set @Query='insert into APVS_TEMP_TABLE_Productivity '+ @Query      
 --set @QueryHistory='insert into APVS_TEMP_TABLE_Productivity '+@QueryHistory      
 print  @Query
 --print @QueryHistory      
 exec(@Query)

 --exec(@QueryHistory)      

 set @QueryFinal='select Wi_ExitTime,UserName,activityname,Wi_Name,Registration_Date,Vendor_Request_Type,Vendor_type,Priority,Vendor_Name,Vendor_Number,Payment_Terms,Vendor_Status,Address_Line_1,Address_Line_2,City_Address_Line_3,State_Code,Postal_code,Additional_Comments,Approvers_Comments,Approval_Decision,Wi_EntryTime,wi_exittime1,isnull(datediff(DD,Registration_Date,Wi_ExitTime),''0'') as AGING from APVS_TEMP_TABLE_Productivity with(nolock) '+@OrderByFinal      
 print @QueryFinal      

 --exec(@QueryFinal)

 SET @Query='insert into APVSProductivitysummary(USERNAME,ACTIVITYNAME,WI_PROCESSED,AVG_TIME)'      
 SET @QueryHistory='select USERNAME,ACTIVITYNAME,count(ACTIVITYNAME)as WI_PROCESSED,avg(convert(float,aging))as AVG_TIME from APVS_TEMP_TABLE_Productivity group by USERNAME,ACTIVITYNAME order by username'      
 set @Query=@Query+@QueryHistory      
 print(@Query)      
 exec (@Query) 
 select @RowCount=count(*) from APVSProductivitysummary with(nolock)      
 if(@RowCount=0)      
 Begin      
  drop table APVSProductivitysummary      
 End
 print 'dfsdsd' 
 ------------      
 select @RowCount=count(*) from APVS_TEMP_TABLE_Productivity with(nolock)      
 if(@RowCount=0)
 Begin
  drop table APVS_TEMP_TABLE_Productivity
 End
 else
 Begin  
  if Object_ID ('APVS_TEMP_TABLE_Productivity_EXCEL') is not null
  BEGIN
   exec('drop table APVS_TEMP_TABLE_Productivity_EXCEL')
  END 

  Exec('Create table APVS_TEMP_TABLE_Productivity_EXCEL (Header varchar(8000),ROw_Index [int] identity(1,1) not null)')  
  Exec('Insert into APVS_TEMP_TABLE_Productivity_EXCEL
  Select ''<html> <style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>
  <table border=1>      
  <tr align="left"><td colspan=18 class=headerbold align="left">      
  <center> 
   Vendor Setup Productivity Report </center></td></tr>
  <tr align="left"><td colspan=22 class=headerbold> Registration Date From : '+@RegDateRangeFrom+'</td></tr>
  <tr align="left"><td colspan=22 class=headerbold> Registration Date To : '+@RegDateRangeTo+'</td></tr>
  <tr align="left"><td colspan=22 class=headerbold> Queue Date From : '+@QueueDateRangeFrom+'</td></tr>
  <tr align="left"><td colspan=22 class=headerbold> Queue Date To : '+@QueueDateRangeTo+'</td></tr>
  <tr align="left"><td colspan=22 class=headerbold> Queue Name : '+@qname+'</td></tr>      
  <tr align="left"><td colspan=22 class=headerbold> User Name : '+@uname+'</td></tr></center>
  </table>  <br>   <table border=1><tr><td class=headerbold>Date</td>''+
 ''<td class=headerbold>User Name</td>''+ 
 ''<td class=headerbold>Queue Name</td>''+ 
 ''<td class=headerbold>Workitem Name</td>''+ 
 ''<td class=headerbold>Registration Date</td>''+ 
 ''<td class=headerbold>Vendor Request Type</td>''+ 
 ''<td class=headerbold>Vendor Type</td>''+      
 ''<td class=headerbold>Priority</td>''+      
 ''<td class=headerbold>Vendor Name</td>''+  
 ''<td class=headerbold>Vendor Number</td>''+
 ''<td class=headerbold>Payment Terms</td>''+  
 ''<td class=headerbold>Vendor Status</td>''+
 ''<td class=headerbold>Address Line 1</td>''+  
 ''<td class=headerbold>Address Line 2</td>''+  
 ''<td class=headerbold>City Address Line 3</td>''+ 
 ''<td class=headerbold>State Code</td>''+
 ''<td class=headerbold>Postal Code</td>''+ 
 ''<td class=headerbold>Additional Comments</td>''+ 
 ''<td class=headerbold>Approvers Comments</td>''+  
 ''<td class=headerbold>Approval Decision</td>''+ 
 ''<td class=headerbold>Queue Entry Date</td>''+ 
 ''<td class=headerbold>Queue Exit Date</td>''+ 
 ''<td class=headerbold>Aging (In Days)</td>'' + 
 ''</tr></font>''      
      
 UNION ALL

 Select ''<tr><td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Wi_ExitTime],''''),120)+''</td>''+  
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([UserName],'''')+''</td>''+ 
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([activityname],'''')+''</td>''+ 
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Wi_Name],'''')+''</td>''+
 ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Registration_Date],''''),120)+''</td>''+ 
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Request_Type],'''')+''</td>''+ 
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_type],'''')+''</td>''+ 
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Priority],'''')+''</td>''+ 
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Name],'''')+''</td>''+  
 ''<td align=left style=mso-number-format:\@>''+ISNULL([Vendor_Number],'''')+''</td>''+      
 ''<td align=left style=mso-number-format:\@>''+ISNULL([Payment_Terms],'''')+''</td>''+   
 ''<td align=left style=mso-number-format:\@>''+ISNULL([Vendor_Status],'''')+''</td>''+
 ''<td align=left style=mso-number-format:\@>''+ISNULL([Address_Line_1],'''')+''</td>''+      
 ''<td align=left style=mso-number-format:\@>''+ISNULL([Address_Line_2],'''')+''</td>''+      
 ''<td align=left style=mso-number-format:\@>''+ISNULL([City_Address_Line_3],'''')+''</td>''+
 ''<td align=left style=mso-number-format:\@>''+ISNULL([State_Code],'''')+''</td>''+
 ''<td align=left style=mso-number-format:\@>''+ISNULL([Postal_code],'''')+''</td>''+      
 ''<td align=left style=mso-number-format:\@>''+ISNULL([Additional_Comments],'''')+''</td>''+      
 ''<td align=left style=mso-number-format:\@>''+ISNULL([Approvers_Comments],'''')+''</td>''+
 ''<td align=left style=mso-number-format:\@>''+ISNULL([Approval_Decision],'''')+''</td>''+      
 ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([Wi_EntryTime],''''),120)+''</td>''+  
 ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([WI_EXITTIME1],''''),120)+''</td>''+      
 ''<td align=left style=mso-number-format:\@>''+ISNULL([AGING],'''')+''</td></tr>''   
 from APVS_TEMP_TABLE_Productivity')      

 --print @Query      
 --exec(@Query)


 select @status_temp='<tr></tr></tr></table><html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style><table border=1><tr><td class=headerbold><b>USER</b></td>'+'<td class=headerbold><b>QUEUE</b></td><td class=headerbold><b>Workitems Processed</b></td><td class=headerbold><b>Average Time(In Minutes)</b></td></tr>' 
      
 DECLARE APVSProductivitysummary_Cursor CURSOR FAST_FORWARD FOR
 Select USERNAME,ACTIVITYNAME,WI_PROCESSED,AVG_TIME from APVSProductivitysummary  
 OPEN APVSProductivitysummary_Cursor 
 FETCH NEXT FROM APVSProductivitysummary_Cursor INTO  @USERNAMESUM,@ACTIVITYNAME,@WI_PROCESSED,@AVG_TIME
 WHILE @@FETCH_STATUS = 0  
 Begin      
  select @status_temp=@status_temp+'<tr><td>'+convert(varchar(100),@USERNAMESUM)+'</td><td>'+convert(varchar(100),@ACTIVITYNAME)+'</td><td>'+convert(varchar(100),@WI_PROCESSED)+'</td><td>'+convert(varchar(100),@AVG_TIME)+'</td></tr>'
  FETCH NEXT FROM APVSProductivitysummary_Cursor INTO @USERNAMESUM,@ACTIVITYNAME,@WI_PROCESSED,@AVG_TIME      
 End      

 close APVSProductivitysummary_Cursor 
 Deallocate APVSProductivitysummary_Cursor
 select @status_temp=@status_temp+'</table>' 
 exec('insert into APVS_TEMP_TABLE_Productivity_EXCEL select '''+@status_temp+'''')      
      
 update APVS_TEMP_TABLE_Productivity_EXCEL set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yy>&nbsp</td>')
      
 SET @Query='Master..xp_Cmdshell ''bcp "select Header FROM '+@DataBaseName+'..APVS_TEMP_TABLE_Productivity_EXCEL order by row_index asc" queryout "'+@FileName+'" -c -T'',no_output'

 --select * from  APVS_TEMP_TABLE_Productivity_EXCEL  
 exec(@Query)      

 insert into NG_AutoMail_Status values('TA VS Productivity Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL)  

 drop table APVSProductivitysummary      
 --drop table #APVS_TEMP_TABLE_Productivity      
 drop table APVS_TEMP_TABLE_Productivity_EXCEL 


 End
 select @RowCount

 End 
 
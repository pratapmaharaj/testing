
<%@ include file="customized.process" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="java.sql.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>
<HTML>
<HEAD>
<TITLE>Vendor Setup Productivity Report</TITLE>
</HEAD>

<link href="/webdesktop/CustomForms/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>

<body >

<%!
int iIndexingCount=0;
int iApprovalCount=0;
int iProcessingCount=0;
int iSplitWICount=0;
int iRescanWICount=0;
int iCancelWICount=0;
int iPendingResolutionCount=0;
int iValidationCount=0;
int iUserCount[];
String sQueuesForm[];

 public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }


%>

<%

	Connection conn = null;
	Statement st;
	String connectionUrl =""; 
	boolean empty=true;

	String sProcessDefId=null;
	String sProcedureName=null;
	String sColumnHeaders=null;
	String sReportName=null;
	String sFileName=null;
	String sNumberOfColumns=null;
	String sProcedureNameKey=null;
	String sColumnHeadersKey=null;
	String sFileNameKey=null;
	String sNumberOfColumnsKey=null;
	String sHeaderKey=null;
	String sHeaderPresentKey=null;
	String sDBMappedColsKey=null;
	String sHeaderValue=null;
	String sHeaderPresentValue=null;
	String sCabinetName=null;	
	String sDBMappedCols=null;
	String sFieldValuesKey=null;
	String sFieldValues=null;
	String sFieldValuesReport="";
	String sUserNamesXML="";
	String sUserMailID=null;
	String sPathNameKey = "" ;
	sUserMailID=request.getParameter("UserEmailID");//added by nilesh
	sReportName	=request.getParameter("ReportName");
	sReportName	=sReportName.toUpperCase();

	sPathNameKey=sReportName +"_REPORTPATH";
	sProcedureNameKey=sReportName +"_PROCEDURENAME";
	sColumnHeadersKey=sReportName+"_COLUMNHEADERS";
	sFileNameKey=sReportName+"_FILENAME";
	sNumberOfColumnsKey=sReportName+"_NUMBEROFCOLUMNS";
	sHeaderPresentKey=sReportName+"_HEADERPRESENT";
	sHeaderKey=sReportName+"_HEADER";
	sDBMappedColsKey=sReportName+"_DBMAPPEDCOLS";
	sFieldValuesKey=sReportName+"_FIELDVALUES";


	WriteLog("APVS_ProdcutivityReport"," sInputXML FORM GENERTA 150");
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAVSProductivityReport.ini";

	Properties ini = new Properties();
	
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("APVS_ProdcutivityReport","Unable to read APVS_ProdcutivityReport.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("APVS_ProdcutivityReport","Unable to close the APVS_ProdcutivityReport.ini file");
						}
					}
				}
				

	sProcedureName=ini.getProperty(sProcedureNameKey);

	sPathNameKey = ini.getProperty(sPathNameKey);
	
	sColumnHeaders=ini.getProperty(sColumnHeadersKey);
	
	sFileName=ini.getProperty(sFileNameKey);
	
	sNumberOfColumns=ini.getProperty(sNumberOfColumnsKey);
	
	sHeaderPresentValue=ini.getProperty(sHeaderPresentKey);
	
	sDBMappedCols=ini.getProperty(sDBMappedColsKey);
	
	sFieldValues=ini.getProperty(sFieldValuesKey);

	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("APVS_ProdcutivityReport","sRootPathDBini="+sRootPathDBini);
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("APVS_ProdcutivityReport","Unable to read APVS_ProdcutivityReport.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("APVS_ProdcutivityReport","Unable to close the APVS_ProdcutivityReport.ini file");
						}
					}
				}
	

	String driverName = null;
	driverName=ini.getProperty("DRIVERNAME");
	connectionUrl=ini.getProperty("CONNECTIONSTRING");
	WriteLog("APVS_ProdcutivityReport","driverName="+driverName+",conString="+connectionUrl);

	CallableStatement callableStatement = null;

	WriteLog("APVS_ProdcutivityReport"," output "+connectionUrl);

	if(sHeaderPresentValue.equals("YES")) 
	{
		sHeaderValue=ini.getProperty(sHeaderKey);
	}

	String sCabname=null;
	String sSessionId = null;
	String sJtsIp = null;
	String sUserName = null;
	String sReportProcedureName=null;
	String sReportTableName=null;
	String sTempQueues=null;
 	String sStr_ServerType=null;
	String sQueueName=request.getParameter("QueueName");
	String sRegFromDate=request.getParameter("RegDateRangeFrom");
	String sRegToDate=request.getParameter("RegDateRangeTo");
	String sQueueFromDate=request.getParameter("QueueDateRangeFrom");
	String sQueueToDate=request.getParameter("QueueDateRangeTo");
	String sUserNames=request.getParameter("UserNames");

	int iQueueCount[]=new int[8];

	String sOutputXML="";
	String sInputXML = "";
	String maincode = "";
	String Totalrec = "0";

	String url = "";
	String Status="";
	String sInputXml="";
	double fPercentage=0;
	String sColumnNamesArr[]=split(sColumnHeaders,',');
	String sFinalColumns[]=split(sColumnHeaders,',');
	String sDBMappedColsArr[]=split(sDBMappedCols,',');



	for(int i=0;i<sColumnNamesArr.length;i++)
	{
		if(sColumnNamesArr[i].indexOf("~D")!=-1)
			sFinalColumns[i]=sColumnNamesArr[i].substring(0,sColumnNamesArr[i].length()-2);

	}
	//Aging implementation

		//sFieldValues=sFieldValues.replaceAll("#",",");
		String sFieldNamesDB[]=split(sFieldValues,'#');

		for(int i=0;i<sFieldNamesDB.length;i++)
		{
			sFieldValuesReport=sFieldValuesReport+sFieldNamesDB[i]+',';
		}
		
	sFieldValuesReport=sFieldValuesReport.substring(0,sFieldValuesReport.length()-1);
	WriteLog("APVS_ProdcutivityReport"," sInputXML FORM GENERTA 264::> sFieldValuesReport : "+sFieldValuesReport);
	//Aging Implementation
	
	String sRowXml="";

	int iJtsPort = 0;
	boolean bError=false;

	String getDBUSERByUserIdSql = "{call "+sProcedureName+" (?,?,?,?,?,?,?,?,?,?)}";
	String output = "" ;
	WriteLog("APVS_ProdcutivityReport"," getDBUSERByUserIdSql "+getDBUSERByUserIdSql);
	try
	{
		WriteLog("APVS_ProdcutivityReport"," sInputXML FORM GENERTA 264::> sQueueName : "+sQueueName);
		WriteLog("APVS_ProdcutivityReport"," sInputXML FORM GENERTA 264::> sRegFromDate : "+sRegFromDate);
		WriteLog("APVS_ProdcutivityReport"," sInputXML FORM GENERTA 264::> sRegToDate : "+sRegToDate);
		WriteLog("APVS_ProdcutivityReport"," sInputXML FORM GENERTA 264::> sQueueFromDate : "+sQueueFromDate);
		WriteLog("APVS_ProdcutivityReport"," sInputXML FORM GENERTA 264::> sQueueToDate : "+sQueueToDate);
		WriteLog("APVS_ProdcutivityReport"," sInputXML FORM GENERTA 264::> sUserNames : "+sUserNames);
		WriteLog("APVS_ProdcutivityReport"," sInputXML FORM GENERTA 264::> Params : "+sProcedureName+" '"+sQueueName+"','"+sRegFromDate+"','"+sRegToDate+"','"+sQueueFromDate+"','"+sQueueToDate+"','"+sUserNames+"','"+sFieldValuesReport+"',' "+sUserMailID+"','"+sPathNameKey+"','' ");

			Class.forName(driverName);
			conn = DriverManager.getConnection(connectionUrl);
			callableStatement = conn.prepareCall(getDBUSERByUserIdSql);
			callableStatement.setString(1, sQueueName);
			callableStatement.setString(2, sRegFromDate);
			callableStatement.setString(3, sRegToDate);
			callableStatement.setString(4, sQueueFromDate);
			callableStatement.setString(5, sQueueToDate);
			callableStatement.setString(6, sUserNames);
			callableStatement.setString(7, sFieldValuesReport);
			callableStatement.setString(8, sUserMailID);
			callableStatement.setString(9, sPathNameKey);
			callableStatement.registerOutParameter(10, java.sql.Types.VARCHAR);
			callableStatement.execute();

			output = callableStatement.getString(10);
			WriteLog("APVS_ProdcutivityReport"," sInputXML FORM GENERTA 264::> output : "+output);
			
			WriteLog("APVS_ProdcutivityReport"," sInputXML FORM GENERTA 264::> output : ");

	}
	catch(SQLException ignore)
	{
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		bError= true;
		WriteLog("VS_QueueStatus"," WFSession Data Fetch Exception:::::: "+ignore.toString());
			%>
				<script>alert("Error While Generating Report");</script>
			<%
	}
	finally {
 
	if (callableStatement != null) {
        try {
            callableStatement.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
	}

	if(!bError)
	{

		WriteLog("APVS_ProdcutivityReport"," output:::::: "+output);
		try
		{

			if(output.equals(""))
			{
				bError= true;
				//maincode=sOutputXML.substring(sOutputXML.indexOf("<MainCode>")+10 , sOutputXML.indexOf("</MainCode>"));
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+output+"</b></font><center>");
			}
			else
			{
				
					try
							{
								 if(Integer.parseInt(output) == 0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
								out.println(ig.toString());
								%>
									<script>alert("Error While Generating Report");</script>
								<%
								WriteLog("APVS_ProdcutivityReport"," Error:::::: "+ig.toString());
							}
			}
		}
		
		catch(Exception exp)
		{
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
			log("APVS_ProdcutivityReport"+exp.toString());
			%>
				<script>alert("Error While Generating Report");</script>
			<%
			WriteLog("APVS_ProdcutivityReport"," Error:::::: "+exp.toString());
		}
		
	}
	
%>
</body>
</html>

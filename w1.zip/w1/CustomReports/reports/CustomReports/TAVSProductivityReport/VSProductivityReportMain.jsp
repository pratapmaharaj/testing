

<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="java.lang.String.*"%>
<%@ page import="java.lang.Object"%>
<%@ page import="java.lang.Exception"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<HTML>

<link href="/webdesktop/CustomForms/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>

<HEAD>
<TITLE>Vendor Setup Productivity Report</TITLE><!-- Change No:Res_20 -->
</HEAD>

<FRAMESET ROWS="100%,0%" >
<FRAME SRC="VSProductivityReport.jsp?ReportName=PRODUCTIVITYREPORT" NAME="frmHeader" frameborder=no noresize scrolling=Yes>
	<FRAME SRC="" NAME="PRODUCTIVITYREPORT" frameborder=no scrolling=no>
	
</FRAMESET>
</html>


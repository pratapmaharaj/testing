
<%@ include file="customized.process" %>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>
<%@ page import="java.sql.*"%>

<HTML>
<HEAD>
<TITLE>Vendor Setup Report</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>
</HEAD>

<link href="/webdesktop/CustomForms/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>
<script src="../../GMAC/Scripts/Common.js"></script>
<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
}
</style>

 <%

	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAVSProductivityReport.ini";
	Properties ini = new Properties();
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("APVS_ProdcutivityReport","Unable to read APVS_ProdcutivityReport.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("APVS_ProdcutivityReport","Unable to close the APVS_ProdcutivityReport.ini file");
						}
					}
				}

	Connection conn = null;
	ResultSet rs = null;
	String sUserName1 = "" ;
	String connectionUrl = "" ;
	String sApproverName="";
	String sGroupname     =ini.getProperty("GROUPNAMES");
	String sTempGroupName ="'"+sGroupname.replaceAll(",","','")+"'";
	sGroupname     =sGroupname.replaceAll(",","~");

	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("APVS_ProdcutivityReport","sRootPathDBini="+sRootPathDBini);
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("APVS_ProdcutivityReport","Unable to read APVS_ProdcutivityReport.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("APVS_ProdcutivityReport","Unable to close the APVS_ProdcutivityReport.ini file");
						}
					}
				}
	

	String driverName = null;
	driverName=ini.getProperty("DRIVERNAME");
	connectionUrl=ini.getProperty("CONNECTIONSTRING");
	WriteLog("APVS_ProdcutivityReport","driverName="+driverName+",conString="+connectionUrl);

	WriteLog("APVS_ProdcutivityReport"," connectionUrl "+connectionUrl);

	String query="select distinct b.username from pdbgroupmember a,pdbuser b where a.groupindex in(select groupindex from pdbgroup where groupname in ("+sTempGroupName+")) and a.userindex=b.userindex and a.userindex<>1 order by b.username desc" ;
	Statement stmt = null ;
	WriteLog("APVS_ProdcutivityReport"," query "+query);

	try
	{
		Class.forName(driverName);
		conn = DriverManager.getConnection(connectionUrl);
		stmt = conn.createStatement();
		rs = stmt.executeQuery(query);

		while (rs.next()) 
		{
			sUserName1 = rs.getString("username")+"~"+sUserName1;
		}
	}
	catch(SQLException e)
	{
		out.println("Exception:" + e.toString());
	}
	finally {
	if (rs != null) {
        try {
            rs.close();
        } catch (SQLException e) { }
    }
	
	if (stmt != null) {
        try {
            stmt.close();
        } catch (SQLException e) {}
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
}

%>


<script>
	var userList = "" ;
	var FromDate = new Date();
	var type = '';
	var allWindows = new Array();
	var win; // new window object
	$(document).ready(function(){$('#From_Date_Reg').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", disabled: true,
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date_Queue').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", disabled: true,
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date_Reg').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", disabled: true,
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#From_Date_Queue').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", disabled: true,
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	
	});
	/*functions echeck,ValidateForm added by nilesh*/
	function echeck(str)
	{

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}

function ValidateForm(emailID){
//	var emailID=document.frmSample.txtEmail
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }

function ChangeDateTag(obj)
{
	alert(obj);
	var InsertVal='';
	for(iterate=0;iterate<obj.length;iterate++)
	{
		if(obj.options[iterate].selected==true)
		{
			InsertVal=InsertVal+obj.options[iterate].value+'/';
		}
	}
	InsertVal=InsertVal.substring(0,InsertVal.length-1);
	var Table=document.getElementById('newgen');
	var lastRow = Table.rows.length;
	if (lastRow > 0) Table.deleteRow(lastRow - 1);
	while(InsertVal.indexOf('_')!=-1)
	{
		InsertVal=InsertVal.replace('_',' ');
	}
	var Row=Table.insertRow(0);
	var Cell=Row.insertCell();
	Cell.className="EWLabelBoldNew";
	Cell.innerHTML=InsertVal;
}

function compToday(Date_To)
{
	var todaysDate = new Date(); 
	var dd = todaysDate.getDate() ;
	var mm = todaysDate.getMonth()+1 ;
	var yy = todaysDate.getFullYear() ;

	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));

	var Date_To_date=Number(Date_To.substring(0,Date_To.indexOf("/")));	

	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));

	if(Date_To_month=="JAN")
			Date_To_month="1";
		else if(Date_To_month=="FEB")
			Date_To_month="2";
		else if(Date_To_month=="MAR")
			Date_To_month="3";
		else if(Date_To_month=="APR")
			Date_To_month="4";
		else if(Date_To_month=="MAY")
			Date_To_month="5";
		else if(Date_To_month=="JUN")
			Date_To_month="6";
		else if(Date_To_month=="JUL")
			Date_To_month="7";
		else if(Date_To_month=="AUG")
			Date_To_month="8";
		else if(Date_To_month=="SEP")
			Date_To_month="9";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";

	if(Date_To_year>yy)
	{
		return false;
	}
	else if(Date_To_year<yy)
	{
		//if(Date_From_month>Date_To_month)
		//{
		//alert("To Date can not be less than From Date.");
		//return false;
		//}
		 if(mm==Date_To_month)
		{
			if(Date_To_date>dd)
			{
				return false;
			}
		}
	}
	else if(Date_To_year==yy)
	{
		if(mm<Date_To_month)
		{
		return false;
		}
		else if(mm==Date_To_month)
		{
			if(Date_To_date>dd)
			{
				return false;
			}
		}
	}
return true ;
}
function DateComparator(Date_To,Date_From)
{	
	if(!compToday(Date_To))
	{
		alert("To Date can not be Future Date.");
		return false ;
	}

	if(!compToday(Date_From))
	{
		alert("From Date can not be Future Date.");
		return false ;
	}
	//alert(dd+" "+mm+" "+yy) ;
	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));	
	var Date_From_month=Date_From.substring(Date_From.indexOf("/")+1,Date_From.lastIndexOf("/"));

	/*converting ToDate month to number */
	if(Date_To_month=="JAN")
			Date_To_month="01";
		else if(Date_To_month=="FEB")
			Date_To_month="02";
		else if(Date_To_month=="MAR")
			Date_To_month="03";
		else if(Date_To_month=="APR")
			Date_To_month="04";
		else if(Date_To_month=="MAY")
			Date_To_month="05";
		else if(Date_To_month=="JUN")
			Date_To_month="06";
		else if(Date_To_month=="JUL")
			Date_To_month="07";
		else if(Date_To_month=="AUG")
			Date_To_month="08";
		else if(Date_To_month=="SEP")
			Date_To_month="09";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";


	/*converting FromDate month to number */
		if(Date_From_month=="JAN")
			Date_From_month="01";
		else if(Date_From_month=="FEB")
			Date_From_month="02";
		else if(Date_From_month=="MAR")
			Date_From_month="03";
		else if(Date_From_month=="APR")
			Date_From_month="04";
		else if(Date_From_month=="MAY")
			Date_From_month="05";
		else if(Date_From_month=="JUN")
			Date_From_month="06";
		else if(Date_From_month=="JUL")
			Date_From_month="07";
		else if(Date_From_month=="AUG")
			Date_From_month="08";
		else if(Date_From_month=="SEP")
			Date_From_month="09";
		else if(Date_From_month=="OCT")
			Date_From_month="10";
		else if(Date_From_month=="NOV")
			Date_From_month="11";
		else if(Date_From_month=="DEC")
			Date_From_month="12";

	var Date_To_date=Number(Date_To.substring(0,Date_To.indexOf("/")));	
	var Date_From_date=Number(Date_From.substring(0,Date_From.indexOf("/")));

	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));
	var Date_From_year=Number(Date_From.substring(Date_From.lastIndexOf("/")+1,Date_From.length));

	if(Date_To_year<Date_From_year)
	{
		alert("To Date cannot be less than From  Date.");
		return false;
	}
	else if(Date_To_year>Date_From_year)
	{
		//if(Date_From_month>Date_To_month)
		//{
		//alert("To Date can not be less than From Date.");
		//return false;
		//}
		 if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{
				
				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}
	else if(Date_To_year==Date_From_year)
	{
	
		if(Date_From_month>Date_To_month)
		{
		alert("To Date can not be less than From Date.");
		return false;
		}
		else if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{

				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}

	var toDate = new Date(Date_To_month+"/"+Date_To_date+"/"+Date_To_year);
	var fromDate = new Date(Date_From_month+"/"+Date_From_date+"/"+Date_From_year);
	var oneDay=1000*60*60*24;

	var dateDiff=Math.ceil((toDate.getTime()-fromDate.getTime())/oneDay);
	if(dateDiff>90)
	{
		alert('Date Range can not be greater than 90 days.');
		return false;
	}
return true;
}


function FillGroupUserCombo()
{
	
	
	
	var sGroupname='<%=sGroupname%>';
	var UserNames='<%=sUserName1%>';
	userList = UserNames ;
	var UserNameArray=UserNames.split('~');
	
	for (var j=0;j<UserNameArray.length-1;j++)
	{
		optn=document.createElement("option");	
		req=document.getElementById("User");
		optn.text=UserNameArray[j];
		optn.value=UserNameArray[j];	
		req.options.add(optn);	
	}

}

function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";
	sDate	= window.showModalDialog('/processmanager/reports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');
	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
	

}
function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	strResult=strdate+"/"+strMonth+"/"+stryear;
	return strResult;
}


	
	
	function openreport()
	{	
		var QueueName="";
		var RegDateRangeFrom="";
		var RegDateRangeTo="";
		var QueueDateRangeFrom="";
		var QueueDateRangeTo="";
		var GroupName='<%=sUserName1%>';
		var UserNameForm="";
		var FinalUserNames="";
		var UserEmailID="";
		var UserNames='<%=sUserName1%>';

		UserEmailID=document.getElementById('EMail-ID').value;
		
		if(document.getElementById('Registration').checked)
		{
			RegDateRangeFrom=document.forms["textForm"].From_Date_Reg.value;
			RegDateRangeTo=document.forms["textForm"].To_Date_Reg.value;	
		}
		if(document.getElementById('Queue_Date').checked)
		{
			QueueDateRangeFrom=document.forms["textForm"].From_Date_Queue.value;
			QueueDateRangeTo=document.forms["textForm"].To_Date_Queue.value;	
		}


		for(var i=0;i<document.forms["textForm"].Queue.length;i++)
		{
			if(document.forms["textForm"].Queue[i].selected)
			{
				
				QueueName=QueueName+document.forms["textForm"].Queue[i].value+'~';
				
			}
		}
		
		///For Users

		for(var l=0;l<document.forms["textForm"].User.length;l++)
		{
			if(document.forms["textForm"].User[l].selected)
			{
				
				UserNameForm=UserNameForm+document.forms["textForm"].User[l].value+'~';
				
			}
		}

		///For Users

		if(GroupName=="\'\'")
		{
			GroupName="";
		}

		if(UserNameForm=="~")
		{
			UserNameForm="";
		}

		var sTest=QueueName.split('~');
		var sGroups=GroupName.split('~');
		var sUsers=UserNameForm.split('~');
		
		if(QueueName=='')
		{
			alert("Please select an appropriate Queue Name");
			return false;
		}
		if(document.getElementById('Registration').checked)
		{
			if(RegDateRangeFrom=='')
			{
				alert("Please select an appropriate From Date");
				return false;
			}
			if(RegDateRangeTo=='')
			{
				alert("Please select an appropriate To Date");
				return false;
			}
		}
		else if(document.getElementById('Queue_Date').checked)
		{
			if(QueueDateRangeFrom=='')
			{
				alert("Please select an appropriate From Date");
				return false;
			}
			if(QueueDateRangeTo=='')
			{
				alert("Please select an appropriate To Date");
				return false;
			}
		}
		else
		{
			alert("Please Specify the type of Date Range (Registration/Queue Entry Date). ");
			return false ;
		}
		
		if(UserNameForm.indexOf("All")!=-1 && sUsers.length>2)
		{
			alert("No other User can be chosen after choosing All.");
			return false;
			//QueueName='All~';
		}  

		if(UserNameForm==userList)
		{
			UserNameForm='All~';
		}
		if(UserNameForm=="")
		{
			UserNameForm='All~';
		}
//alert(UserNameForm) ;

		if(QueueName.indexOf("All")!=-1 && sTest.length>2)
		{
			alert("No other Queue Name can be chosen after choosing All");
			return false;
			//QueueName='All~';
		}  

		if(QueueName=='Introduction~VendorSetup~PendingResolution~Cancel~QC~VendorApproval~UpdateVendorChanges~ChangeQC~GEACInterface~')
		{
			QueueName='All~';
		}

			if(sUsers!="")
			{
					FinalUserNames=UserNameForm;
			}
			else
			{
				FinalUserNames = "All~" ;
			}

			/*Added by nilesh-Function is called for  comparing dates*/
		if(RegDateRangeTo!='' && RegDateRangeFrom!='')
		{
			if(!DateComparator(RegDateRangeTo,RegDateRangeFrom))
			{
				return false;
			}
		}
		else if(QueueDateRangeTo!='' && QueueDateRangeFrom!='')
		{
		if(!DateComparator(QueueDateRangeTo,QueueDateRangeFrom))
		{
		return false;
		}
		}

			/*added by nilesh for email validation*/
		if(UserEmailID=='')
		{
			alert("Please enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
				return false ;
			}
		}
			//document.getElementById("test").value = "VSProductivityReportGenerate.jsp?&QueueName="+QueueName+"&RegDateRangeFrom="+RegDateRangeFrom+"&RegDateRangeTo="+RegDateRangeTo+"&QueueDateRangeFrom="+QueueDateRangeFrom+"&QueueDateRangeTo="+QueueDateRangeTo+"&ReportName=<%=request.getParameter("ReportName")%>&UserNames="+FinalUserNames+"&UserEmailID="+UserEmailID ;
			//alert("VSProductivityReportGenerate.jsp?&QueueName="+QueueName+"&RegDateRangeFrom="+RegDateRangeFrom+"&RegDateRangeTo="+RegDateRangeTo+"&QueueDateRangeFrom="+QueueDateRangeFrom+"&QueueDateRangeTo="+QueueDateRangeTo+"&ReportName=<%=request.getParameter("ReportName")%>&UserNames="+FinalUserNames+"&UserEmailID="+UserEmailID)
			if((UserEmailID!='')&&(QueueName!='')&&(RegDateRangeFrom!='')&&(RegDateRangeTo !=''))
			{
				
			//OpenRedict-Fix
    //window.top.PRODUCTIVITYREPORT.location.href="VSProductivityReportGenerate.jsp?&QueueName="+QueueName+"&RegDateRangeFrom="+RegDateRangeFrom+"&RegDateRangeTo="+RegDateRangeTo+"&QueueDateRangeFrom="+QueueDateRangeFrom+"&QueueDateRangeTo="+QueueDateRangeTo+"&ReportName=<%=request.getParameter("ReportName")%>&UserNames="+FinalUserNames+"&UserEmailID="+UserEmailID;
	var URI = "VSProductivityReportGenerate.jsp?&QueueName="+QueueName+"&RegDateRangeFrom="+RegDateRangeFrom+"&RegDateRangeTo="+RegDateRangeTo+"&QueueDateRangeFrom="+QueueDateRangeFrom+"&QueueDateRangeTo="+QueueDateRangeTo+"&ReportName=<%=request.getParameter("ReportName")%>&UserNames="+FinalUserNames+"&UserEmailID="+UserEmailID;
	var StrOpenWin=strip_tags(URI,"");
	window.top.PRODUCTIVITYREPORT.location.href=StrOpenWin;
			
			}
			else if ((UserEmailID!='')&&(QueueName!='')&&(QueueDateRangeFrom!='')&&(QueueDateRangeTo !=''))
			{
				//OpenRedict-Fix
    //window.top.PRODUCTIVITYREPORT.location.href="VSProductivityReportGenerate.jsp?&QueueName="+QueueName+"&RegDateRangeFrom="+RegDateRangeFrom+"&RegDateRangeTo="+RegDateRangeTo+"&QueueDateRangeFrom="+QueueDateRangeFrom+"&QueueDateRangeTo="+QueueDateRangeTo+"&ReportName=<%=request.getParameter("ReportName")%>&UserNames="+FinalUserNames+"&UserEmailID="+UserEmailID;
	var URI = "VSProductivityReportGenerate.jsp?&QueueName="+QueueName+"&RegDateRangeFrom="+RegDateRangeFrom+"&RegDateRangeTo="+RegDateRangeTo+"&QueueDateRangeFrom="+QueueDateRangeFrom+"&QueueDateRangeTo="+QueueDateRangeTo+"&ReportName=<%=request.getParameter("ReportName")%>&UserNames="+FinalUserNames+"&UserEmailID="+UserEmailID;
	var StrOpenWin=strip_tags(URI,"");
	window.top.PRODUCTIVITYREPORT.location.href=StrOpenWin;
				
			}
	}

	function DisableOtherCombo(Mode)
	{	
		if(Mode=='U')
		{
			if(document.textForm.Group.value=="")
			{
				
				document.textForm.User.disabled=false;
			}
			else
			{
				document.textForm.User.disabled=true;
			}
		}
		else
		{
			if(document.textForm.User.value=="")
			{
				
				document.textForm.Group.disabled=false;
			}
			else
			{
				document.textForm.Group.disabled=true;
			}
			
		}
		
	}
	
	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}
	

 function disbFields()
 {
 	document.getElementById('From_Date_Queue').value='';
	document.getElementById('To_Date_Queue').value='';
	document.getElementById('From_Date_Reg').value='';
	document.getElementById('To_Date_Reg').value='';
	//document.getElementById('From_Date_IMG_Queue').disabled=true;
	//document.getElementById('To_Date_IMG_Queue').disabled=true;
	//document.getElementById('From_Date_IMG_Reg').disabled=true;
	//document.getElementById('To_Date_IMG_Reg').disabled=true;

 	document.getElementById('From_Date_Queue').style.backgroundColor='grey';
	document.getElementById('To_Date_Queue').style.backgroundColor='grey';
	document.getElementById('From_Date_Reg').style.backgroundColor='grey';
	document.getElementById('To_Date_Reg').style.backgroundColor='grey';

 }
function chkradio(obj)
{
	if(obj == 'r')
	{
		if(document.getElementById('Queue_Date').checked == true) 
		{
			document.getElementById('Queue_Date').checked = false;
		}
		document.getElementById('From_Date_Queue').value='';
		document.getElementById('To_Date_Queue').value='';
		document.getElementById('From_Date_Queue').style.backgroundColor='grey';
		document.getElementById('To_Date_Queue').style.backgroundColor='grey';
		//document.getElementById('From_Date_IMG_Queue').disabled=true;
		//document.getElementById('To_Date_IMG_Queue').disabled=true;
		//document.getElementById('From_Date_IMG_Reg').disabled=false;
		//document.getElementById('To_Date_IMG_Reg').disabled=false;
		document.getElementById('From_Date_Reg').style.backgroundColor='white';
		document.getElementById('To_Date_Reg').style.backgroundColor='white';
		$('#From_Date_Reg').datepicker("enable");
			$('#To_Date_Reg').datepicker("enable");
			$('#To_Date_Queue').datepicker("disable");
			$('#From_Date_Queue').datepicker("disable");
	}
	else if(obj == 'q')
	{
		if(document.getElementById('Registration').checked == true) 
		{
			document.getElementById('Registration').checked = false;
		}
		document.getElementById('From_Date_Queue').style.backgroundColor='white';
		document.getElementById('To_Date_Queue').style.backgroundColor='white';
		document.getElementById('From_Date_Reg').style.backgroundColor='grey';
		document.getElementById('To_Date_Reg').style.backgroundColor='grey';
		//document.getElementById('From_Date_IMG_Reg').disabled=true;
		//document.getElementById('To_Date_IMG_Reg').disabled=true;
		document.getElementById('From_Date_Reg').value='';
		document.getElementById('To_Date_Reg').value='';
		$('#From_Date_Reg').datepicker("disable");
			$('#To_Date_Reg').datepicker("disable");
			$('#To_Date_Queue').datepicker("enable");
			$('#From_Date_Queue').datepicker("enable");
		//document.getElementById('From_Date_IMG_Queue').disabled=false;
		//document.getElementById('To_Date_IMG_Queue').disabled=false;
	}

}
</script>

<body topmargin="0" leftmargin="5" onload="disbFields();FillGroupUserCombo();" onunload="UnloadReportWindow();">

			<form name='textForm' method=post>


			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">Vendor Setup Productivity Report</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This report will provide user wise productivity statistics, i.e., number of workitems processed in various queues.
</td></tr>
<tr><td class="EWLabel1">Select All Queues if report is to be generated for viewing the workitems present across different worksteps, else select the specific Queue, multiple selections are again acceptable.
</td></tr><tr><td class="EWLabel1">Select a set of Users for whom the productivity has to be calculated.<br>
Select the requisite date range for generating the report for the same.</td>
</tr><tr><td class="EWLabel1"><b> Queue Name and Date Range are Mandatory.</b></td>
				</tr>
			</table>

			

			<table border="0" width="90%" cellspacing="1" align="center">
<td colspan = 2 class="EWLabel1"><font color="RED">*</font> <b>Fields are Mandatory<b><BR>
				 <tr>
					<td class="EWLabel1" align="left" width='20%'><b>Queue <font color="RED">*</font></b></font></td>
					<td width='25%' colspan=3>
					<select name="Queue" multiple>
					<option value="All">All</option>
					<option value="Introduction">Introduction</option>
					<option value="VendorSetup">VendorSetup</option>
					<option value="PendingResolution">PendingResolution</option>
					<option value="Cancel">Cancel</option>
					<option value="QC">QC</option>
					<option value="VendorApproval">VendorApproval</option>
					<option value="UpdateVendorChanges">UpdateVendorChanges</option>
					<option value="ChangeQC">ChangeQC</option>
					<option value="GEACInterface">GEACInterface</option>
					</select>
					</td>
				</tr>

				</tr>
				<tr>
					<td class="EWLabel1" align="left" width='20%'><b>User 
					<td width='25%' colspan=3>
						<!--id given by megha-->
						<select class='TextFieldColor'  id="User" name="User" multiple>
						<option value="All">All</option>

						</select>
					
					</td>

				</tr>
				<tr>&nbsp;</tr>
				 <tr>
				 <tr>
				 <td class="EWLabel1">
					<input type = "radio" class="text" name ="Registration" id ="Registration" value = "Registration" class="EWLabel1" onClick="chkradio('r')"> <font color='Blue'><b>&nbsp;&nbsp;Registration Date <font color="RED">*</font></b>
					</font>
					</td>
				</tr>
				<tr>
				<td class="EWLabel1" align="left" width='10%'><table id='newgen'></table><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
				<td>
					<input class='TextFieldColorDate' name="From_Date_Reg" readonly type="text"  id="From_Date_Reg" >
					
				</td>
				<td class="EWLabel1" align="left" width='2%'><b>&nbsp;To:</b></td>
				<td width='35%'><input class='TextFieldColorDate' name="To_Date_Reg" readonly type="text"  id="To_Date_Reg" >
					
				</td>
				</tr>
				</tr>
				
				<tr>
				 <tr>
				 <td class="EWLabel1">
					<input type = "radio" class="EWLabel1" name ="Queue_Date" id ="Queue_Date" value = "Queue_Date" onClick="chkradio('q')"><font color='Blue'><b>&nbsp;&nbsp;&nbsp;Queue Entry Date <font color="RED">*</font><b></td>
					</tr>
					<tr>
					<td class="EWLabel1" align="left" width='10%'><table id='newgen'></table><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='35%'>
					<input class='TextFieldColorDate' name="From_Date_Queue" readonly type="text"  id="From_Date_Queue" >
					
					</td>
					<td class="EWLabel1" align="left" width='2%'><b>&nbsp;To:</b></td>
					<td width='35%'><input class='TextFieldColorDate' name="To_Date_Queue" readonly type="text"  id="To_Date_Queue" >
					
					</td>
					</tr>

				</tr>

			<tr>&nbsp;</tr>
				<tr width=100%>
					<td width="30%" class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID <font color="RED">*</font></b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>

				
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>

			</form>
</body>
</Html>	 




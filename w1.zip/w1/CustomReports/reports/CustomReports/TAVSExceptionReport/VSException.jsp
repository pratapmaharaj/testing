 <%@ include file="customized.process" %>

<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.text.*"%>

<HTML>
<HEAD>
<TITLE>Vendor Setup Exception Report</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>
</HEAD>

<link href="/webdesktop/CustomForms/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>
<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
}
</style>
<script>
	var allWindows = new Array();
	$(document).ready(function(){$('#From_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date",
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	
	});
	var win; // new window object
	/*functions echeck,ValidateForm added by nilesh*/
	function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}

function ValidateForm(emailID){
//	var emailID=document.frmSample.txtEmail
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }


function compToday(Date_To)
{
	var todaysDate = new Date(); 
	var dd = todaysDate.getDate() ;
	var mm = todaysDate.getMonth()+1 ;
	var yy = todaysDate.getFullYear() ;

	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));

	var Date_To_date=Number(Date_To.substring(0,Date_To.indexOf("/")));	

	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));

	if(Date_To_month=="JAN")
			Date_To_month="1";
		else if(Date_To_month=="FEB")
			Date_To_month="2";
		else if(Date_To_month=="MAR")
			Date_To_month="3";
		else if(Date_To_month=="APR")
			Date_To_month="4";
		else if(Date_To_month=="MAY")
			Date_To_month="5";
		else if(Date_To_month=="JUN")
			Date_To_month="6";
		else if(Date_To_month=="JUL")
			Date_To_month="7";
		else if(Date_To_month=="AUG")
			Date_To_month="8";
		else if(Date_To_month=="SEP")
			Date_To_month="9";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";

	if(Date_To_year>yy)
	{
		return false;
	}
	else if(Date_To_year<yy)
	{
		//if(Date_From_month>Date_To_month)
		//{
		//alert("To Date can not be less than From Date.");
		//return false;
		//}
		 if(mm==Date_To_month)
		{
			if(Date_To_date>dd)
			{
				return false;
			}
		}
	}
	else if(Date_To_year==yy)
	{
		if(mm<Date_To_month)
		{
		return false;
		}
		else if(mm==Date_To_month)
		{
			if(Date_To_date>dd)
			{
				return false;
			}
		}
	}
return true ;
}

function DateComparator(Date_To,Date_From)
{	
	if(!compToday(Date_From))
	{
		alert("From Date can not be Future Date.");
		return false ;
	}
	if(!compToday(Date_To))
	{
		alert("To Date can not be Future Date.");
		return false ;
	}

	//alert(dd+" "+mm+" "+yy) ;
	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));	
	var Date_From_month=Date_From.substring(Date_From.indexOf("/")+1,Date_From.lastIndexOf("/"));

	/*converting ToDate month to number */
	if(Date_To_month=="JAN")
			Date_To_month="01";
		else if(Date_To_month=="FEB")
			Date_To_month="02";
		else if(Date_To_month=="MAR")
			Date_To_month="03";
		else if(Date_To_month=="APR")
			Date_To_month="04";
		else if(Date_To_month=="MAY")
			Date_To_month="05";
		else if(Date_To_month=="JUN")
			Date_To_month="06";
		else if(Date_To_month=="JUL")
			Date_To_month="07";
		else if(Date_To_month=="AUG")
			Date_To_month="08";
		else if(Date_To_month=="SEP")
			Date_To_month="09";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";


	/*converting FromDate month to number */
		if(Date_From_month=="JAN")
			Date_From_month="01";
		else if(Date_From_month=="FEB")
			Date_From_month="02";
		else if(Date_From_month=="MAR")
			Date_From_month="03";
		else if(Date_From_month=="APR")
			Date_From_month="04";
		else if(Date_From_month=="MAY")
			Date_From_month="05";
		else if(Date_From_month=="JUN")
			Date_From_month="06";
		else if(Date_From_month=="JUL")
			Date_From_month="07";
		else if(Date_From_month=="AUG")
			Date_From_month="08";
		else if(Date_From_month=="SEP")
			Date_From_month="09";
		else if(Date_From_month=="OCT")
			Date_From_month="10";
		else if(Date_From_month=="NOV")
			Date_From_month="11";
		else if(Date_From_month=="DEC")
			Date_From_month="12";
	
	var Date_To_date=Number(Date_To.substring(0,Date_To.indexOf("/")));	
	var Date_From_date=Number(Date_From.substring(0,Date_From.indexOf("/")));

	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));
	var Date_From_year=Number(Date_From.substring(Date_From.lastIndexOf("/")+1,Date_From.length));

	var inputTo = Date_To_date+''+Date_To_month+''+Date_To_year ;
	var inputFrom = Date_From_date+''+Date_From_month+''+Date_From_year ;


	if(Date_To_year<Date_From_year)
	{
		alert("To Date cannot be less than From  Date.");
		return false;
	}
	else if(Date_To_year>Date_From_year)
	{
		//if(Date_From_month>Date_To_month)
		//{
		//alert("To Date can not be less than From Date.");
		//return false;
		//}
		 if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{
				
				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}


	else if(Date_To_year==Date_From_year)
	{
	
		if(Date_From_month>Date_To_month)
		{
		alert("To Date can not be less than From Date.");
		return false;
		}
		else if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{

				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}
	var toDate = new Date(Date_To_month+"/"+Date_To_date+"/"+Date_To_year);
	var fromDate = new Date(Date_From_month+"/"+Date_From_date+"/"+Date_From_year);
	var oneDay=1000*60*60*24;

	var dateDiff=Math.ceil((toDate.getTime()-fromDate.getTime())/oneDay);
	if(dateDiff>90)
	{
		alert('Date Range can not be greater than 90 days.');
		return false;
	}
return true;
}


	
	
function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
var sDate="";
       sDate	= window.showModalDialog('/processmanager/reports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');



	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
	

}
function ChangeDateTag(obj)
{
	var InsertVal='';
	for(iterate=0;iterate<obj.length;iterate++)
	{
		if(obj.options[iterate].selected==true)
		{
			InsertVal=InsertVal+obj.options[iterate].value+'/';
		}
	}
	InsertVal=InsertVal.substring(0,InsertVal.length-1);
	var Table=document.getElementById('newgen');
	var lastRow = Table.rows.length;
	if (lastRow > 0) Table.deleteRow(lastRow - 1);
	while(InsertVal.indexOf('_')!=-1)
	{
		InsertVal=InsertVal.replace('_',' ');
	}
	var Row=Table.insertRow(0);
	var Cell=Row.insertCell();
	Cell.className="EWLabelBoldNew";
	//Cell.innerHTML=InsertVal;
}
function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	strResult=strdate+"/"+strMonth+"/"+stryear;
	return strResult;
}


	function openreport()
	{			
		
		var QueueName="";
		var VendorType="";
		var VendorName = document.getElementById("Vendor_Name").value ;
		var VendorNumber = document.getElementById("Vendor_Number").value ;
		var Exp="";
		var bExpSelected=false;
		var bQueueNameSelected=false;
		var bVendorTypeSelected=false;
		DateRangeFrom=document.forms["textForm"].From_Date.value;
		DateRangeTo=document.forms["textForm"].To_Date.value;

		var UserEmailID=document.getElementById('EMail-ID').value;//added by nilesh
		
		for(var i=0;i<document.forms["textForm"].Queue.length;i++)
		{
			if(document.forms["textForm"].Queue[i].selected)
			{
			QueueName=QueueName+document.forms["textForm"].Queue[i].value+'~';
			
			}
		}

		for(var i=0;i<document.forms["textForm"].Vendor_Type.length;i++)
			{
				if(document.forms["textForm"].Vendor_Type[i].selected)
				{
					VendorType=VendorType+document.forms["textForm"].Vendor_Type[i].value+'~';
				}
			}

		for(var i=0;i<document.forms["textForm"].ExceptionType.length;i++)
		{
			if(document.forms["textForm"].ExceptionType[i].selected)
			{
			Exp=Exp+document.forms["textForm"].ExceptionType[i].value+'~';
			
			}
		}
		
		
		var sTestVendorType=VendorType.split('~');
		var sTestQueueName=QueueName.split('~');
		var sTestExp=Exp.split('~');

		if(Exp=='')
		{
			Exp = "All~" ;
		}
		if(DateRangeFrom=='')
		{
			alert("Please select an appropriate From Date");
			return false;
		}
		if(DateRangeTo=='')
		{
			alert("Please select an appropriate To Date");
			return false;
		}
		
		if ((DateRangeFrom=="" && DateRangeTo!="") || (DateRangeFrom!="" && DateRangeTo==""))
		{
			alert("Enter the complete Date Range.");
			return false;
		}
		
		if(VendorType.indexOf("All")!=-1 && sTestVendorType.length>2)
		{
			alert("No other Vendor Type can be chosen after choosing All");
			return false;
		} 
		
		if(QueueName.indexOf("All")!=-1 && sTestQueueName.length>2)
		{
			alert("No other Queue Name can be chosen after choosing All");
			return false;
			//DocumentType='All~';
		} 

		if(Exp.indexOf("All")!=-1 && sTestExp.length>2)
		{
			alert("No other Exception can be chosen after choosing All");
			return false;
			//Exp='All~';
		} 

		if(VendorType=='Policyholder vendors~Escheatment vendors~Tax vendors~PO vendors~Licensing and filing fee vendors~Non PO Vendors~')
		{
			VendorType='Policyholder vendors~Escheatment vendors~Tax vendors~PO vendors~Licensing and filing fee vendors~Non PO Vendors~';
		}
		if(VendorType=='')
		{
			VendorType='All~';
		}
		if(QueueName=='Cancel~PendingResolution~')
		{
			QueueName='Cancel~PendingResolution~';
		}
		
		if(Exp=='Missing Vendor Information~Missing W9~Cancel Duplicate~')
		{
			Exp='Missing Vendor Information~Missing W9~Cancel Duplicate~';
		}

		if(VendorName=="")
		{
			VendorName="" ;
		}

		if(VendorNumber=="")
		{
			VendorNumber="" ;
		}

		if(QueueName=="")
		{
			QueueName = "" ;
		}
		if(!DateComparator(DateRangeTo,DateRangeFrom))
		{
		return false;
		}
		
		if(UserEmailID=='')
		{
			alert("Please enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
				return false ;
			}
		}

		//alert("VSExceptionGenerate.jsp?FromDates="+DateRangeFrom+"&ToDate="+DateRangeTo+"&Exp="+Exp+"&UserEmailID="+UserEmailID+"&VendorType="+VendorType+"&QueueName="+QueueName+"&ReportName=<%=request.getParameter("ReportName")%>"+"&VendorNumber="+VendorNumber+"&VendorName="+VendorName ) ;
		if(UserEmailID!='')
			{//window.top.TCIException.location.href="TCIExceptionGenerate.jsp?DocumentType="+DocumentType+"&sExp="+sExp+"&FromDates="+DateRangeFrom+"&ToDate="+DateRangeTo+"&ReportName=<%=request.getParameter("ReportName")%>&UserEmailID="+UserEmailID;
		
			//OpenRedict-Fix
    //window.top.EXCEPTION.location.href="VSExceptionGenerate.jsp?FromDates="+DateRangeFrom+"&ToDate="+DateRangeTo+"&Exp="+Exp+"&UserEmailID="+UserEmailID+"&VendorType="+VendorType+"&QueueName="+QueueName+"&ReportName=EXCEPTION&VendorNumber="+escape(VendorNumber)+"&VendorName="+escape(VendorName) ;
	var URI = "VSExceptionGenerate.jsp?FromDates="+DateRangeFrom+"&ToDate="+DateRangeTo+"&Exp="+Exp+"&UserEmailID="+UserEmailID+"&VendorType="+VendorType+"&QueueName="+QueueName+"&ReportName=EXCEPTION&VendorNumber="+escape(VendorNumber)+"&VendorName="+escape(VendorName);
	var StrOpenWin=strip_tags(URI,"");
	window.top.EXCEPTION.location.href=StrOpenWin;
			
			
			}
}
	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}

</script>


<body topmargin="0" leftmargin="5" onload="" onunload="UnloadReportWindow();">
			<form name='textForm' method=post>
			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">Vendor Setup Exception Report</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This report will provide the time for pending exceptions.
</td></tr>
<tr><td class="EWLabel1">Select All Exception Types if report is to be generated for all the Exception Types available, else select the specific Exception Type, multiple selections are acceptable.
</td></tr><tr><td class="EWLabel1">Select the requisite date range for generating the report for the same.<br>
<b>Exception Name and Date Range are mandatory.</b></td>
				</tr>
			</table>
			<table border="0" width="95%" cellspacing="1" align="center">
<td colspan = 2 class="EWLabel1"><font color="RED">*</font> <b>Fields are Mandatory<b><BR>
				 <tr>
					<td class="EWLabel1" align="left" width='20%'><b>Queue</b></td>
					<td width='45%' colspan=3>
					<select style='width:65%' name="Queue" multiple>
					<option value="All">All</option>
					<option value="Cancel">Cancel</option>
					<option value="PendingResolution">PendingResolution</option>
					</select>
					</td>
				</tr>
				<tr width=100%>
					<td class="EWLabel1" align="left" width=180><b>Vendor Type</b></td>
					<td width='45%' colspan=3>
					<select style='width:65%' name="Vendor_Type" multiple>
					<option value="All">All</option>
					<option value="Policyholder vendors">Policyholder vendors</option>
					<option value="Escheatment vendors">Escheatment vendors</option>
					<option value="Tax vendors">Tax vendors</option>
					<option value="PO vendors">PO vendors</option>
					<option value="Licensing and filing fee vendors">Licensing & filing fee vendors</option>
					<option value="Non PO Vendors">Non PO Vendors</option>
					</select>
					</td>
				</tr>
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Exception Name</b></td>
					<td width='45%' colspan=3>
					<select style='width:65%' class='TextFieldColor' name="ExceptionType" multiple >
					<option value="All">ALL</option>
					<option value="Missing Vendor Information">Missing Vendor Information</option>
					<option value="Missing W9">Missing W9</option>
					<option value="Cancel Duplicate">Cancel Duplicate</option>
					</select>
					</td>
				</tr>
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Vendor Name</b></td>
					<td width='100%' colspan=3>
						<input name="Vendor_Name" id="Vendor_Name" type="text"  maxLength=40 class='TextFieldColorLight'>
					</td>
				</tr>
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Vendor Number</b></td>
					<td width='35%' colspan=3>
					<!--id given by megha-->
						<input name="Vendor_Number" id="Vendor_Number" type="text"  maxLength=40 class='TextFieldColorLight'>
					</td>
				</tr>
				<tr>&nbsp;</tr>
				 <tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>Date Range <font color="RED">*</font> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date"  type="text" readonly id="From_Date" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date" readonly type="text"  id="To_Date" >
					
					</td>

				</tr>


				<!--Added by nilesh for additional E-mail ID field display -->
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID <font color="RED">*</font></b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>

				
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>
	

			</form>

</body>
</Html>	 

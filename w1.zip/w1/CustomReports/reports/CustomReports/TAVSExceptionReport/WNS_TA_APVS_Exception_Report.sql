/*
WNS_TA_APVS_Exception_Report '','All~','All~','','','01/FEB/2014','08/MAR/2014','current_work_step,a.WI_Name,Introduction_Type,Registration_Date,Vendor_Request_Type,Vendor_type,Priority,Vendor_Name,Vendor_Number,Payment_Terms,Vendor_Status,Address_Line_1,
  
Address_Line_2,City_Address_Line_3,State_Code,Postal_code,Optional_Address_1,Optional_Address_2,Vendor_Email_ID,Combined_Single_Payment,Tax_ID_Number,SSN_Number,V_1099_Code,V_1099_Payee_Name,ACH,Bank_Account_Payment_Code,Code,Account_Number,Exception_Type
  
,W9_Indicator,Approval_Decision,b.ActionDatetime,Exception_Raising_Comments,b.UserName,1,1,Additional_Comments','test@123.com','//10.33.192.139/XLS-File/Yogesh/ExceptionReport','WNS_TA_APVS_Exception_Report',''     
       
*/

alter PROCEDURE WNS_TA_APVS_Exception_Report
(
@QueueName  VARCHAR(200),
@VendorType  VARCHAR(200),
@Exp  VARCHAR(200),
@VendorName  VARCHAR(200),
@VendorNumber VARCHAR(200),
@DateRangeFrom  VARCHAR(50),
@DateRangeTo  VARCHAR(50),
@Fields varchar(8000),
@EmailID varchar(200),
@FilePath varchar(200),
@FileName varchar(200),            
@RowCount varchar(200) OUTPUT
)
AS
declare
 @WhereQuery    varchar(2000),
 @Query    varchar(5000),
 @Query1   varchar(5000),
 @Querysum varchar(5000),
 @Tables   varchar(200),
 @VendorNameReport     varchar(200),
 @QueueNameReport varchar(200),
 @VendorTypeReport varchar(200),
 @VendorTypeTemp varchar(200),        
 @QueueTypeTemp varchar(200),         
 @ExceptionTemp varchar(200),        
 @VendorNumberReport  varchar(200),
 @ExpReport     varchar(200),
 @OrderBy varchar(300), 
 @Disp_ExceptionName varchar(100),
 @Count_Exception varchar(100),
 @status_temp varchar(8000),
 @dbname varchar(60)

BEGIN 
 Set nocount on 
 set @FileName=@FilePath+'/'+@EmailID+'_'+@FileName+'_'+convert(varchar,getdate(),104)+'.xls'
 set @WhereQuery='WHERE '
 set @ExpReport=''
 set @QueueNameReport=''
 set @VendorTypeReport=''
 set @VendorTypeTemp=''          
 set @VendorNumberReport=''             
 set @QueueTypeTemp = ''        
 set @RowCount='0'             
 set @ExceptionTemp =''        
 set @OrderBy=' order by a.WI_Name'        
          

 print  @FileName

 Create Table #TA_APVS_Exception_Report_Temp 
 (
  Current_Work_Step   varchar(150),
  WI_Name             varchar(150),
  Introduction_Type   varchar(100),
  Registration_Date   varchar(100),
  Vendor_Request_Type varchar(500),
  Vendor_type         varchar(500),
  Priority            varchar(500),
  Vendor_Name         varchar(500),
  Vendor_Number       varchar(500),
  Payment_Terms     varchar(500),
  Vendor_Status     varchar(500),
  Address_Line_1      varchar(500),
  Address_Line_2      varchar(500),
  City_Address_Line_3 varchar(500),
  State_Code   varchar(500),
  Postal_code   varchar(500),
  Optional_Address_1 varchar(500),
  Optional_Address_2 varchar(500),
  Vendor_Email_ID  varchar(500),
  Combined_Single_Payment varchar(500),
  Tax_ID_Number       varchar(500),
  SSN_Number   varchar(500),
  V_1099_Code   varchar(500),
  V_1099_Payee_Name varchar(500),
  ACH     varchar(500),
  Bank_Account_Payment_Code varchar(500),
  Code    varchar(500),
  Account_Number  varchar(500),       
  Exception_Type  varchar(500),
  W9_Indicator       varchar(500),
  Approval_Decision   varchar(500),
  ExceptionRaisedDatetime varchar(100),
  Exception_Raising_Comments  varchar(2000),
  RaisedByUser varchar(550),
  AgingDays varchar(50), 
  AgingHrs varchar(50) ,  
  Additional_Comments  varchar(2000)

 )

 --create temporary summary table
 Create Table #TCISummaryException
 (
 Disp_ExceptionName varchar(1000),
 Count_Exception varchar(100)
 )

 set @Tables='WNS_TA_APVS_EXT_Table a with(nolock) ,exceptiontable b with(nolock) '

 set @WhereQuery=@WhereQuery+' a.WI_Name=b.Processinstanceid and b.actionid=''9'' and b.processdefid=''16'''

 if(rtrim(ltrim(@DateRangeFrom))<>'')
  SET @DateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@DateRangeFrom,121))))) 
 if(rtrim(ltrim(@DateRangeTo))<>'')
  SET @DateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@DateRangeTo,121))))) 

 print @DateRangeFrom
 print @QueueName
 -- Add Document Type
 if(rtrim(ltrim(@QueueName))<>'All~')
 BEGIN
	 --Added to Check for only 1 parameter
	if(len(@QueueName)=charindex('~',@QueueName))
	BEGIN
		set @QueueTypeTemp=ltrim(rtrim(substring(@QueueName,0,len(@QueueName))))        
		set @QueueNameReport=ltrim(rtrim(substring(@QueueName,0,len(@QueueName))))
		print '------'
		print @QueueNameReport
		set @WhereQuery=@WhereQuery+' AND current_work_step='''+@QueueNameReport+''''
	END
	--Added to Check for only 1 parameter  
	else
	BEGIN
		-----While loop ends
		while (charindex('~',@QueueName)>1)
		BEGIN
			set @QueueTypeTemp = @QueueTypeTemp +ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+','        
			set @QueueNameReport = @QueueNameReport + ''''+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+''''+','
			set @QueueName=ltrim(rtrim(Substring(@QueueName,Charindex('~',@QueueName)+len('~'),len(@QueueName))))
		END
		set @QueueNameReport=substring(@QueueNameReport,0,len(@QueueNameReport))
		set @WhereQuery=@WhereQuery+' AND current_work_step in('+@QueueNameReport+')'
	END
 END

 print 'After Doc Type '+@WhereQuery
 -- Add Process Type
 if(rtrim(ltrim(@VendorType))<>'All~')
 BEGIN
  --Added to Check for only 1 parameter
  if(len(@VendorType)=charindex('~',@VendorType))
  BEGIN
   set @VendorTypeTemp=ltrim(rtrim(substring(@VendorType,0,len(@VendorType))))             
   set @VendorTypeReport=ltrim(rtrim(substring(@VendorType,0,len(@VendorType))))             
   set @WhereQuery=@WhereQuery+' AND Vendor_Type='''+@VendorTypeReport+''''
  END

  --Added to Check for only 1 parameter  
  else
  BEGIN
   -----While loop ends
   while (charindex('~',@VendorType)>1)
   BEGIN
    set @VendorTypeTemp = @VendorTypeTemp +ltrim(rtrim(SUBSTRING(@VendorType,1,Charindex('~',@VendorType)-1)))+','
    set @VendorTypeReport = @VendorTypeReport + ''''+ltrim(rtrim(SUBSTRING(@VendorType,1,Charindex('~',@VendorType)-1)))+''''+','
    set @VendorType=ltrim(rtrim(Substring(@VendorType,Charindex('~',@VendorType)+len('~'),len(@VendorType))))
   END
          
   set @VendorTypeReport=substring(@VendorTypeReport,0,len(@VendorTypeReport))            
   set @WhereQuery=@WhereQuery+' AND Vendor_Type in('+@VendorTypeReport+')'
  END
 END
            
print @VendorTypeTemp          
 print 'After Process Type '+@WhereQuery
 if(rtrim(ltrim(@Exp))<>'All~')
 BEGIN
  print 'Individual Exception '+@Exp
  --Added to Check for only 1 parameter
  if(len(@Exp)=charindex('~',@Exp))
  BEGIN
 set @ExceptionTemp=ltrim(rtrim(substring(@Exp,0,len(@Exp))))        
   set @ExpReport=ltrim(rtrim(substring(@Exp,0,len(@Exp))))  
   set @WhereQuery=@WhereQuery+' AND Exception_Type='''+@ExpReport+''''
  END 
  --Added to Check for only 1 parameter
  else
  BEGIN
   print @Exp
   while (charindex('~',@Exp)>1)
   BEGIN
    set @ExceptionTemp = @ExceptionTemp +ltrim(rtrim(SUBSTRING(@Exp,1,Charindex('~',@Exp)-1)))+','         
    set @ExpReport = @ExpReport + ''''+ltrim(rtrim(SUBSTRING(@Exp,1,Charindex('~',@Exp)-1)))+''''+','
    set @Exp=ltrim(rtrim(Substring(@Exp,Charindex('~',@Exp)+len('~'),len(@Exp))))
   END
   set @ExpReport=substring(@ExpReport,0,len(@ExpReport))

   set @WhereQuery=@WhereQuery+' AND Exception_Type in('+@ExpReport+')'
  END
  END
 else
 begin
  set @WhereQuery=@WhereQuery+' AND Exception_Type != '''''
 end

 /*if(rtrim(ltrim(@VendorName))<>'All~')
 BEGIN
  print 'Individual Exception '+@VendorName
  --Added to Check for only 1 parameter
  if(len(@VendorName)=charindex('~',@VendorName))
  BEGIN
   set @VendorNameReport=ltrim(rtrim(substring(@VendorName,0,len(@VendorName))))  
   set @WhereQuery=@WhereQuery+' AND Vendor_Name='''+@VendorNameReport+''''
  END 
  --Added to Check for only 1 parameter
  else
  BEGIN
   print @VendorName
   while (charindex('~',@VendorName)>1)
   BEGIN
    set @VendorNameReport = @VendorNameReport + ''''+ltrim(rtrim(SUBSTRING(@VendorName,1,Charindex('~',@VendorName)-1)))+''''+','
    set @VendorName=ltrim(rtrim(Substring(@VendorName,Charindex('~',@VendorName)+len('~'),len(@VendorName))))
   END
   set @VendorNameReport=substring(@VendorNameReport,0,len(@VendorNameReport))

   set @WhereQuery=@WhereQuery+' AND Vendor_Name in('+@VendorNameReport+')'
  END
  END
*/          
if(@VendorNumber<>'')          
BEGIN          
  if(charindex('%',@VendorNumber)>=1)          
  BEGIN          
    print '1111'          
    set @WhereQuery=@WhereQuery+' AND Vendor_Number like '''+@VendorNumber+'%'''          
    print @WhereQuery          
  END          
  ELSE          
  BEGIN          
   print '2222'          
    set @WhereQuery=@WhereQuery+' AND Vendor_Number ='''+@VendorNumber+''''          
  END          
END           
          
print @WhereQuery          
if(@VendorName<>'')          
BEGIN          
  if(charindex('%',@VendorName)>=1)          
  BEGIN          
    print '1111'          
    set @WhereQuery=@WhereQuery+' AND Vendor_Name like '''+@VendorName+'%'''          
    print @WhereQuery          
  END          
  ELSE          
  BEGIN          
   print '2222'          
    set @WhereQuery=@WhereQuery+' AND Vendor_Name ='''+@VendorName+''''          
  END          
END           
          
print 'aaaaaaa'          
print @WhereQuery        
 /*           
 if(rtrim(ltrim(@VendorNumber))<>'All~')
 BEGIN
  print 'Individual Exception '+@VendorNumber
  --Added to Check for only 1 parameter
  if(len(@VendorNumber)=charindex('~',@VendorNumber))
  BEGIN
   set @VendorNumberReport=ltrim(rtrim(substring(@VendorNumber,0,len(@VendorNumber))))  
   set @WhereQuery=@WhereQuery+' AND Vendor_Number='''+@VendorNumberReport+''''
  END 
  --Added to Check for only 1 parameter
  else
  BEGIN
   print @VendorNumber
   while (charindex('~',@VendorNumber)>1)
   BEGIN
    set @VendorNumberReport = @VendorNumberReport + ''''+ltrim(rtrim(SUBSTRING(@VendorNumber,1,Charindex('~',@VendorNumber)-1)))+''''+','
    set @VendorNumber=ltrim(rtrim(Substring(@VendorNumber,Charindex('~',@VendorNumber)+len('~'),len(@VendorNumber))))
   END
   set @VendorNumberReport=substring(@VendorNumberReport,0,len(@VendorNumberReport))

   set @WhereQuery=@WhereQuery+' AND Vendor_Number in('+@VendorNumberReport+')'
  END
  END
    */          
 print 'After Adding Exception Name '+@WhereQuery

 if(rtrim(ltrim(@DateRangeFrom))<>'' AND rtrim(ltrim(@DateRangeTo))<>'')
 BEGIN
  set @WhereQuery=@WhereQuery+' AND b.actiondatetime between '''+rtrim(ltrim(@DateRangeFrom))+''' AND '''+ rtrim(ltrim(@DateRangeTo))+''''
 END
 print 'After Adding Date Range '+@WhereQuery

 SET @Query=' insert into #TA_APVS_Exception_Report_Temp(Current_Work_Step,WI_Name,Introduction_Type,Registration_Date ,Vendor_Request_Type, Vendor_type ,Priority,Vendor_Name,Vendor_Number, Payment_Terms , Vendor_Status , Address_Line_1 ,Address_Line_2 ,City_Address_Line_3 ,State_Code,Postal_code,Optional_Address_1,Optional_Address_2,Vendor_Email_ID,Combined_Single_Payment,Tax_ID_Number,SSN_Number,V_1099_Code,V_1099_Payee_Name,ACH,Bank_Account_Payment_Code,Code,Account_Number,Exception_Type,W9_Indicator,Approval_Decision ,ExceptionRaisedDatetime,Exception_Raising_Comments,RaisedByUser ,AgingDays,AgingHrs,Additional_Comments)'   
 SET @Query1=' SELECT '+@Fields+' from '+ @Tables + @WhereQuery + @OrderBy 
 seT  @Query=@Query + @Query1

 print 'Final SQL '+@Query
 exec(@Query)

 delete from #TA_APVS_Exception_Report_Temp where WI_Name in ( select processinstanceid from exceptiontable, #TA_APVS_Exception_Report_Temp where wi_name=processinstanceid and actionid='10')
 exec('update #TA_APVS_Exception_Report_Temp set
 AgingHrs = isnull(datediff(hh,ExceptionRaisedDatetime,convert(varchar,getdate(),121)),''0''),
 AgingDays = cast((isnull(datediff(hh,ExceptionRaisedDatetime,convert(varchar,getdate(),121)),''0''))/24.0 as numeric(10,2))')


 SET @Query='insert into #TCISummaryException(Disp_ExceptionName,Count_Exception) '
 SET @Querysum='select case exception_type when''Missing Vendor Information''then ''Missing Vendor Information Exception:''when''Missing W9''then ''Missing W9 Exception:''
 when''Cancel Duplicate''then ''Cancel Duplicate Exception:''
 else ''Exception'' end as Disp_exceptionname, count(*) as  
 count_exception from #TA_APVS_Exception_Report_Temp group by exception_type'

 set @Query=@Query+@Querysum
 print 'Exception Count '+@Query
 exec (@Query)

 select @RowCount=count(*) from #TA_APVS_Exception_Report_Temp with(nolock)

 if(@RowCount=0)  
 Begin  
  print 'No Record Found #TA_APVS_Exception_Report_Temp'
  --drop table #TA_APVS_Exception_Report_Temp  
 End  
 else  
 begin 
  print 'Report Records '+@RowCount
  if Object_ID ('TA_TEMP_AUTOMAIL') is not null  
  BEGIN    
  exec('drop table TA_TEMP_AUTOMAIL')    
  END

  Exec('Create table TA_TEMP_AUTOMAIL (Header varchar(8000),ROw_Index int IDENTITY(1,1) PRIMARY KEY)')           

  Exec('Insert into TA_TEMP_AUTOMAIL  
  Select ''<html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>
  <table border=1>
   <tr align="left"><td colspan=37 class=headerbold><center>Vendor Setup Exception Report</center></td></tr> 
   <tr align="left"><td colspan=37 class=headerbold> From : '+@DateRangeFrom+'</td></tr>   
   <tr align="left"><td colspan=37 class=headerbold> To : '+@DateRangeTo+'</td></tr>          
   <tr align="left"><td colspan=37 class=headerbold> Queue Name : '+@QueueTypeTemp+'</td></tr>        
 <tr align="left"><td colspan=37 class=headerbold> Vendor Type : '+@VendorTypeTemp+'</td></tr>        
 <tr align="left"><td colspan=37 class=headerbold> Exception : '+@ExceptionTemp+'</td></tr>         
 <tr align="left"><td colspan=37 class=headerbold> Vendor Number : '+@VendorNumber+'</td></tr>          
 <tr align="left"><td colspan=37 class=headerbold> Vendor Name : '+@VendorName+'</td></tr>    
   </table>  <br>  
  <table border=1><tr><td class=headerbold>Current Queue</td>''+
  ''<td class=headerbold>WI Name</td>''+           
  ''<td class=headerbold>Introduction Type</td>''+
  ''<td class=headerbold>Registration Date</td>''+
  ''<td class=headerbold>Vendor Request Type</td>''+
  ''<td class=headerbold>Vendor Type</td>''+
  ''<td class=headerbold>Priority</td>''+
  ''<td class=headerbold>Vendor Name</td>''+
  ''<td class=headerbold>Vendor Number</td>''+
  ''<td class=headerbold>Payment Terms</td>''+
  ''<td class=headerbold>Status</td>''+
  ''<td class=headerbold>Address Line 1</td>''+
  ''<td class=headerbold>Address Line 2</td>''+
  ''<td class=headerbold>City Address Line 3</td>''+
  ''<td class=headerbold>State Code</td>''+
  ''<td class=headerbold>Postal code</td>''+
  ''<td class=headerbold>Optional Address 1</td>''+
  ''<td class=headerbold>Optional Address 2</td>''+
  ''<td class=headerbold>Vendor Email ID</td>''+
  ''<td class=headerbold>Combined or Single</td>''+
  ''<td class=headerbold>Tax ID</td>''+
  ''<td class=headerbold>SSN Number</td>''+
  ''<td class=headerbold>1099 Code</td>''+
  ''<td class=headerbold>1099 Payee Name</td>''+
  ''<td class=headerbold>ACH</td>''+
  ''<td class=headerbold>BAP Code</td>''+
  ''<td class=headerbold>ABA Number</td>''+
  ''<td class=headerbold>Account Number</td>''+
  ''<td class=headerbold>Exception Type</td>''+
  ''<td class=headerbold>W9 Indicator</td>''+
  ''<td class=headerbold>Approval Decision</td>''+
  ''<td class=headerbold>Exception Raised Date</td>''+
  ''<td class=headerbold>Exception Raised Comments</td>''+
  ''<td class=headerbold>Raised By User</td>''+
  ''<td class=headerbold>Aging In Days</td>''+
  ''<td class=headerbold>Aging In Hrs</td>''+
  ''<td class=headerbold>Additional Comments</td>''+
  +''</tr></font>''

  UNION ALL
 
  Select ''<tr><td align=left style=mso-number-format:\\@>''+ISNULL([Current_Work_Step],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([WI_Name],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Introduction_Type],'''')+''</td>''+
  ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(25),ISNULL([Registration_Date],''''),120)+''</td>''+ 
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Request_Type],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_type],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Priority],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Vendor_Name],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Number],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Payment_Terms],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Vendor_Status],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Address_Line_1],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Address_Line_2],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([City_Address_Line_3],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([State_Code],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Postal_code],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Optional_Address_1],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Optional_Address_2],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Vendor_Email_ID],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Combined_Single_Payment],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Tax_ID_Number],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\\@>''+ISNULL([SSN_Number],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([V_1099_Code],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([V_1099_Payee_Name],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([ACH],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Bank_Account_Payment_Code],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([code],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Account_Number],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Exception_Type],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([W9_Indicator],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Approval_Decision],'''')+''</td>''+
  ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>''+CONVERT(CHAR(19),ISNULL([ExceptionRaisedDatetime],''''),120)+''</td>''+ 
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Exception_Raising_Comments],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([RaisedByUser],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([AgingDays],'''')+''</td>''+     
  ''<td align=left style=mso-number-format:\@>''+ISNULL([AgingHrs],'''')+''</td>''+
  ''<td align=left style=mso-number-format:\@>''+ISNULL([Additional_Comments],'''')+''</td>''
  from #TA_APVS_Exception_Report_Temp')

 select @status_temp='<tr></tr></tr></table><html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style><table border=1><tr>'+'<td class=headerbold><b>Exception Name </b></td><td class=headerbold><b>Exception Count</b></td></tr>'    

  DECLARE TASummaryException_Cursor CURSOR FAST_FORWARD FOR 
  Select Disp_ExceptionName,Count_Exception from #TCISummaryException       
  OPEN TASummaryException_Cursor    
  FETCH NEXT FROM TASummaryException_Cursor INTO  @Disp_ExceptionName,@Count_Exception  
  WHILE @@FETCH_STATUS = 0
  Begin
   select @status_temp=@status_temp+'<tr><td>'+convert(varchar(100),@Disp_ExceptionName)+'</td><td>'+convert(varchar(100),@Count_Exception)+'</td></tr>'
   FETCH NEXT FROM TASummaryException_Cursor INTO @Disp_ExceptionName,@Count_Exception
  End

  close TASummaryException_Cursor    
  Deallocate TASummaryException_Cursor 
  select @status_temp=@status_temp+'</table>'  
  exec('insert into TA_TEMP_AUTOMAIL select '''+@status_temp+'''   ') 

  update TA_TEMP_AUTOMAIL set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>&nbsp</td>')    
  select @dbname = DB_NAME()
  print @dbname
  SET @Query='Master..xp_Cmdshell ''bcp "select Header FROM '+@dbname+'..TA_TEMP_AUTOMAIL order by row_index asc " queryout "'+@FileName+'" -c -T'',no_output'  
  exec(@Query) 
   
  insert into NG_AutoMail_Status values('TA VS Exception Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL) 
  
  --drop table #TCISummaryException
  --drop table #TA_APVS_Exception_Report_Temp 
  drop table TA_TEMP_AUTOMAIL 

 end    
  select @RowCount
END 

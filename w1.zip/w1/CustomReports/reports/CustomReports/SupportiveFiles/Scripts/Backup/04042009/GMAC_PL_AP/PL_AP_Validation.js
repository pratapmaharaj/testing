/*
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-GMAC
Module : GMAC-PLMIC
File Name : PL_AP_Validation.js
Author :   Tarit Gupta
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date Change By Change Description (Bug No. (If Any))
(DD/MM/YYYY)
----------------------------------------------------------------------------------------------------
*/
function load()
{	
	
	
	var objwi=window.top.wi_object;
    var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
	var sWname=objwi.workstep_name.toUpperCase();
	
			
			if (sWname.toUpperCase()=="WORK INTRODUCTION")
				{	
					
					objDataForm.Process.focus();
					
					//alert(objwi.attribute_list["Previous_Wrk_Step"]);
					if(objwi.attribute_list["Process"].value!="" )
						{
						
						objDataForm.Process.value=objwi.attribute_list["Process"].value;

						}
						
					if(objDataForm.Document_Type.type=='select-one')
					{
					FillDocTypesCombo();
					}
					
					if(objwi.attribute_list["Document_Type"].value!="")
						{
						
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;
							
						}

					if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						}
						if(objwi.attribute_list["Special_Handling"].value!="" )
						{

						objDataForm.Special_Handling.value=objwi.attribute_list["Special_Handling"].value;

						}




				}



  

			if (sWname.toUpperCase()=="INDEXING")
				{	
					
					objDataForm.Process.focus();
					
					//alert(objwi.attribute_list["Previous_Wrk_Step"]);
					if(objwi.attribute_list["Process"].value!="" )
						{
						
						objDataForm.Process.value=objwi.attribute_list["Process"].value;

						}
					if(objDataForm.Document_Type.type=='select-one')
					{
					FillDocTypesCombo();
					}
					
					if(objwi.attribute_list["Document_Type"].value!="")
						{
						
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;
							
						}

					if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
					
					
						if(objwi.attribute_list["Special_Handling"].value!="" )
						{

						objDataForm.Special_Handling.value=objwi.attribute_list["Special_Handling"].value;

						}
						if(objwi.attribute_list["CompanyName"].value!="" )
						{

						objDataForm.CompanyName.value=objwi.attribute_list["CompanyName"].value;

						}
						if(objwi.attribute_list["CompanyCode"].value!="" )
						{

						objDataForm.CompanyCode.value=objwi.attribute_list["CompanyCode"].value;

						}
						
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma_SBR(objwi.attribute_list["Amount"]);
						

						}
						
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						
						if(objwi.attribute_list["Priority"].value!="" )
						{
						
						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						if(objwi.attribute_list["Intro_Type"].value=="BH" && objwi.attribute_list["Priority"].value=="Urgent")
							objDataForm.Priority.disabled=true;

						}
						

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}
						if(objwi.attribute_list["Validation"].value!="" )
						{

						objDataForm.Validation.value=objwi.attribute_list["Validation"].value;

						}
						if(objwi.attribute_list["Validation_Comments"].value!="" )
						{

						objDataForm.Validation_Comments.value=objwi.attribute_list["Validation_Comments"].value;

						}
						if(objwi.attribute_list["Split_Resolution_Comments"].value!="" )
						{

						objDataForm.Split_Resolution_Comments.value=objwi.attribute_list["Split_Resolution_Comments"].value;

						}
						if(objwi.attribute_list["No_Of_WI_Created"].value!="" )
						{

						objDataForm.No_Of_WI_Created.value=objwi.attribute_list["No_Of_WI_Created"].value;

						}
						if(objwi.attribute_list["WI_Serial_Number"].value!="" )
						{

						objDataForm.WI_Serial_Number.value=objwi.attribute_list["WI_Serial_Number"].value;

						}
						if(objwi.attribute_list["Cancel_Decision_Comments"].value!="" )
						{

						objDataForm.Cancel_Decision_Comments.value=objwi.attribute_list["Cancel_Decision_Comments"].value;

						}
						
						if(!loadcheckboxes())
						{
							return false;
						}

				}




			if (sWname.toUpperCase()=="PROCESSING")
				{	
						
						objDataForm.Process.focus();
							//alert(objwi.attribute_list["Previous_Wrk_Step"]);
					if(objwi.attribute_list["Process"].value!="" )
						{
						
						objDataForm.Process.value=objwi.attribute_list["Process"].value;

						}
					
					if(objDataForm.Document_Type.type=='select-one')
					{
					FillDocTypesCombo();
					}
					
					if(objwi.attribute_list["Document_Type"].value!="" )
						{
						
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;
							
						}

					if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
					
					
						if(objwi.attribute_list["Special_Handling"].value!="" )
						{

						objDataForm.Special_Handling.value=objwi.attribute_list["Special_Handling"].value;

						}
						if(objwi.attribute_list["CompanyName"].value!="" )
						{

						objDataForm.CompanyName.value=objwi.attribute_list["CompanyName"].value;

						}
						if(objwi.attribute_list["CompanyCode"].value!="" )
						{

						objDataForm.CompanyCode.value=objwi.attribute_list["CompanyCode"].value;

						}
						
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{
							
						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma_SBR(objwi.attribute_list["Amount"]);
						

						}
						
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						
						if(objwi.attribute_list["Priority"].value!="" )
						{
						
						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						if(objwi.attribute_list["Intro_Type"].value=="BH" && objwi.attribute_list["Priority"].value=="Urgent")
							objDataForm.Priority.disabled=true;

						}
						
						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						if(objwi.attribute_list["SAP_Document_Number"].value!="" )
						{

						objDataForm.SAP_Document_Number.value=objwi.attribute_list["SAP_Document_Number"].value;

						}
						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}
						if(objwi.attribute_list["Validation"].value!="" )
						{

						objDataForm.Validation.value=objwi.attribute_list["Validation"].value;

						}
						if(objwi.attribute_list["Validation_Comments"].value!="" )
						{

						objDataForm.Validation_Comments.value=objwi.attribute_list["Validation_Comments"].value;

						}
						if(objwi.attribute_list["Split_Resolution_Comments"].value!="" )
						{

						objDataForm.Split_Resolution_Comments.value=objwi.attribute_list["Split_Resolution_Comments"].value;

						}
						if(objwi.attribute_list["No_Of_WI_Created"].value!="" )
						{

						objDataForm.No_Of_WI_Created.value=objwi.attribute_list["No_Of_WI_Created"].value;

						}
						if(objwi.attribute_list["WI_Serial_Number"].value!="" )
						{

						objDataForm.WI_Serial_Number.value=objwi.attribute_list["WI_Serial_Number"].value;

						}
						if(objwi.attribute_list["Cancel_Decision_Comments"].value!="" )
						{

						objDataForm.Cancel_Decision_Comments.value=objwi.attribute_list["Cancel_Decision_Comments"].value;

						}
						
						if(!loadcheckboxes())
						{
							return false;
						}

				}

			if (sWname.toUpperCase()=="RESCAN_WI")
				{	
						
						
						if(objwi.attribute_list["Process"].value!="")
						{
						
						objDataForm.Process.value=objwi.attribute_list["Process"].value;

						}
						
						if(objwi.attribute_list["Document_Type"].value!="")
						{
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;

						}
						if(objwi.attribute_list["Special_Handling"].value!="")
						{
						
						objDataForm.Special_Handling.value=objwi.attribute_list["Special_Handling"].value;

						}
						
						
						if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
						
						if(objwi.attribute_list["CompanyName"].value!="" )
						{

						objDataForm.CompanyName.value=objwi.attribute_list["CompanyName"].value;

						}
						if(objwi.attribute_list["CompanyCode"].value!="" )
						{

						objDataForm.CompanyCode.value=objwi.attribute_list["CompanyCode"].value;

						}
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma(objwi.attribute_list["Amount"]);
						

						}
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						}

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						if(objwi.attribute_list["SAP_Document_Number"].value!="" )
						{

						objDataForm.SAP_Document_Number.value=objwi.attribute_list["SAP_Document_Number"].value;

						}

						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}
					
						makeDateButtonDisb();
						if(!loadcheckboxes())
							{
								return false;
							}
							if(!loadClrCheckboxes())
							
							{
								return false;
							}

							for (var i=0;i<objDataForm.elements.length ;i++ )
								{
									if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
										{

										disablecheckbox(objDataForm.elements[i].name);
										
										}
								}

				}
	


				
					if (sWname.toUpperCase()=="PENDING_RESOLUTION")
				{	
					
						

						if(objwi.attribute_list["Process"].value!="")
						{
						
						objDataForm.Process.value=objwi.attribute_list["Process"].value;

						}
						
						if(objwi.attribute_list["Document_Type"].value!="")
						{
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;

						}
						if(objwi.attribute_list["Special_Handling"].value!="")
						{
						
						objDataForm.Special_Handling.value=objwi.attribute_list["Special_Handling"].value;

						}
						
						
						if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
						
						if(objwi.attribute_list["CompanyName"].value!="" )
						{

						objDataForm.CompanyName.value=objwi.attribute_list["CompanyName"].value;

						}
						if(objwi.attribute_list["CompanyCode"].value!="" )
						{

						objDataForm.CompanyCode.value=objwi.attribute_list["CompanyCode"].value;

						}
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma(objwi.attribute_list["Amount"]);
						

						}
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						}

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						if(objwi.attribute_list["SAP_Document_Number"].value!="" )
						{

						objDataForm.SAP_Document_Number.value=objwi.attribute_list["SAP_Document_Number"].value;

						}

						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}
						if(objwi.attribute_list["Forward_To"].value!="" )
						{

						objDataForm.Forward_To.value=objwi.attribute_list["Forward_To"].value;

						}
						
						
						makeDateButtonDisb();

						//alert("pending load");
						
						if(!loadcheckboxes())
							{
								return false;
							}
						if(!loadClrCheckboxes())
							
							{
								return false;
							}
							
						for (var i=0;i<objDataForm.elements.length ;i++ )
						{
							if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
								{

								disablecheckbox(objDataForm.elements[i].name);
								
								}
						}


						objDataForm.Forward_To.focus();
			
				}


					if (sWname.toUpperCase()=="CANCEL_WI")
						{	
					
						
						if(objwi.attribute_list["Process"].value!="")
						{
						
						objDataForm.Process.value=objwi.attribute_list["Process"].value;

						}
						
						if(objwi.attribute_list["Document_Type"].value!="")
						{
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;

						}
						if(objwi.attribute_list["Special_Handling"].value!="")
						{
						
						objDataForm.Special_Handling.value=objwi.attribute_list["Special_Handling"].value;

						}
						
						
						if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
						
						if(objwi.attribute_list["CompanyName"].value!="" )
						{

						objDataForm.CompanyName.value=objwi.attribute_list["CompanyName"].value;

						}
						if(objwi.attribute_list["CompanyCode"].value!="" )
						{

						objDataForm.CompanyCode.value=objwi.attribute_list["CompanyCode"].value;

						}
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma(objwi.attribute_list["Amount"]);
						

						}
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						}

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						if(objwi.attribute_list["SAP_Document_Number"].value!="" )
						{

						objDataForm.SAP_Document_Number.value=objwi.attribute_list["SAP_Document_Number"].value;

						}

						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}
						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						
						if(objwi.attribute_list["Cancel_Decision"].value!="" )
						{

						objDataForm.Cancel_Decision.value=objwi.attribute_list["Cancel_Decision"].value;

						}
						if(objwi.attribute_list["Cancel_Decision_Comments"].value!="" )
						{

						objDataForm.Cancel_Decision_Comments.value=objwi.attribute_list["Cancel_Decision_Comments"].value;

						}

						
						makeDateButtonDisb();

						if(!loadcheckboxes())
							{
								return false;
							}
						if(!loadClrCheckboxes())
							
							{
								return false;
							}
						for (var i=0;i<objDataForm.elements.length ;i++ )
						{
							if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
								{

								disablecheckbox(objDataForm.elements[i].name);
								
								}
						}

						objDataForm.Cancel_Decision.focus();
							
				}



				if (sWname.toUpperCase()=="SPLIT_DOCS")
						{	
					
						if(objwi.attribute_list["Process"].value!="")
						{
						
						objDataForm.Process.value=objwi.attribute_list["Process"].value;

						}
						
						if(objwi.attribute_list["Document_Type"].value!="")
						{
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;

						}
						if(objwi.attribute_list["Special_Handling"].value!="")
						{
						
						objDataForm.Special_Handling.value=objwi.attribute_list["Special_Handling"].value;

						}
						
						
						if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
						
						if(objwi.attribute_list["CompanyName"].value!="" )
						{

						objDataForm.CompanyName.value=objwi.attribute_list["CompanyName"].value;

						}
						if(objwi.attribute_list["CompanyCode"].value!="" )
						{

						objDataForm.CompanyCode.value=objwi.attribute_list["CompanyCode"].value;

						}
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma(objwi.attribute_list["Amount"]);
						

						}
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						}

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						if(objwi.attribute_list["SAP_Document_Number"].value!="" )
						{

						objDataForm.SAP_Document_Number.value=objwi.attribute_list["SAP_Document_Number"].value;

						}

						
							
						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}
						if(objwi.attribute_list["Split_Doc_Decision"].value!="" )
						{

						objDataForm.Split_Doc_Decision.value=objwi.attribute_list["Split_Doc_Decision"].value;

						}
						//alert("in split");
						if(objwi.attribute_list["Split_Resolution_Comments"].value!="" )
						{

						objDataForm.Split_Resolution_Comments.value=objwi.attribute_list["Split_Resolution_Comments"].value;

						}
						if(objwi.attribute_list["No_Of_WI_Created"].value!="" )
						{

						objDataForm.No_Of_WI_Created.value=objwi.attribute_list["No_Of_WI_Created"].value;

						}
						if(objwi.attribute_list["WI_Serial_Number"].value!="" )
						{

						objDataForm.WI_Serial_Number.value=objwi.attribute_list["WI_Serial_Number"].value;

						}
								
						
						makeDateButtonDisb();

						if(!loadcheckboxes())
							{
								return false;
							}
						if(!loadClrCheckboxes())
							
							{
								return false;
							}
						for (var i=0;i<objDataForm.elements.length ;i++ )
						{
							if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
								{

								disablecheckbox(objDataForm.elements[i].name);
								
								}
						}

					}



					if (sWname.toUpperCase()=="VALIDATION")
						{	
					
						

						objDataForm.Process.focus();
					
					//alert(objwi.attribute_list["Previous_Wrk_Step"]);
					if(objwi.attribute_list["Process"].value!="" )
						{
						
						objDataForm.Process.value=objwi.attribute_list["Process"].value;

						}
					
					
					if(objwi.attribute_list["Document_Type"].value!="")
						{
						
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;
							
						}

					if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
					
					
						if(objwi.attribute_list["Special_Handling"].value!="" )
						{

						objDataForm.Special_Handling.value=objwi.attribute_list["Special_Handling"].value;

						}
						if(objwi.attribute_list["CompanyName"].value!="" )
						{

						objDataForm.CompanyName.value=objwi.attribute_list["CompanyName"].value;

						}
						if(objwi.attribute_list["CompanyCode"].value!="" )
						{

						objDataForm.CompanyCode.value=objwi.attribute_list["CompanyCode"].value;

						}
						
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma_SBR(objwi.attribute_list["Amount"]);
						

						}
						
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;
						
						}
						

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						if(objwi.attribute_list["SAP_Document_Number"].value!="" )
						{

						objDataForm.SAP_Document_Number.value=objwi.attribute_list["SAP_Document_Number"].value;

						}
						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						
						if(objwi.attribute_list["Validation"].value!="" )
						{

						objDataForm.Validation.value=objwi.attribute_list["Validation"].value;

						}
						if(objwi.attribute_list["Validation_Comments"].value!="" )
						{

						objDataForm.Validation_Comments.value=objwi.attribute_list["Validation_Comments"].value;

						}
						//alert("in split");
						
						makeDateButtonDisb();
						objDataForm.Validation.focus();
					}
					if (sWname.toUpperCase()=="SPECIAL_HANDLING")
						{	
					
						
						
						objDataForm.Process.focus();
					
					//alert(objwi.attribute_list["Previous_Wrk_Step"]);
					if(objwi.attribute_list["Process"].value!="" )
						{
						
						objDataForm.Process.value=objwi.attribute_list["Process"].value;

						}
					
					
					if(objwi.attribute_list["Document_Type"].value!="")
						{
						
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;
							
						}

					if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
					
					
						if(objwi.attribute_list["Special_Handling"].value!="" )
						{

						objDataForm.Special_Handling.value=objwi.attribute_list["Special_Handling"].value;

						}
						if(objwi.attribute_list["CompanyName"].value!="" )
						{

						objDataForm.CompanyName.value=objwi.attribute_list["CompanyName"].value;

						}
						if(objwi.attribute_list["CompanyCode"].value!="" )
						{

						objDataForm.CompanyCode.value=objwi.attribute_list["CompanyCode"].value;

						}
						
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma_SBR(objwi.attribute_list["Amount"]);
						

						}
						
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;
						
						}
						

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						if(objwi.attribute_list["SAP_Document_Number"].value!="" )
						{

						objDataForm.SAP_Document_Number.value=objwi.attribute_list["SAP_Document_Number"].value;

						}
						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						
						if(objwi.attribute_list["Validation"].value!="" )
						{

						objDataForm.Validation.value=objwi.attribute_list["Validation"].value;

						}
						if(objwi.attribute_list["Validation_Comments"].value!="" )
						{

						objDataForm.Validation_Comments.value=objwi.attribute_list["Validation_Comments"].value;

						}
						//alert("in split");
						
						makeDateButtonDisb();
						
					}


					if (sWname.toUpperCase()=="CHECK_DETAILS_UPDATE")
						{	
					
						
						if(objwi.attribute_list["Process"].value!="" )
						{
						
						objDataForm.Process.value=objwi.attribute_list["Process"].value;

						}
					
					
					if(objwi.attribute_list["Document_Type"].value!="")
						{
						
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;
							
						}

					if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
					
					
						if(objwi.attribute_list["Special_Handling"].value!="" )
						{

						objDataForm.Special_Handling.value=objwi.attribute_list["Special_Handling"].value;

						}
						if(objwi.attribute_list["CompanyName"].value!="" )
						{

						objDataForm.CompanyName.value=objwi.attribute_list["CompanyName"].value;

						}
						if(objwi.attribute_list["CompanyCode"].value!="" )
						{

						objDataForm.CompanyCode.value=objwi.attribute_list["CompanyCode"].value;

						}
						
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma_SBR(objwi.attribute_list["Amount"]);
						

						}
						
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;
						
						}
						

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						if(objwi.attribute_list["SAP_Document_Number"].value!="" )
						{

						objDataForm.SAP_Document_Number.value=objwi.attribute_list["SAP_Document_Number"].value;

						}
						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						
						if(objwi.attribute_list["Validation"].value!="" )
						{

						objDataForm.Validation.value=objwi.attribute_list["Validation"].value;

						}
						if(objwi.attribute_list["Validation_Comments"].value!="" )
						{

						objDataForm.Validation_Comments.value=objwi.attribute_list["Validation_Comments"].value;

						}
						
						if(objwi.attribute_list["Check_Number"].value!="" )
						{

						objDataForm.Check_Number.value=objwi.attribute_list["Check_Number"].value;

						}
						objDataForm.Check_Number.focus();

						if(objwi.attribute_list["Check_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Check_Date.value=retdate;
						

						}
						//alert("in split");
						
						makeDateButtonDisb();
						
					}
			

	//}


		
			if (sWname.toUpperCase()=="QUERY" || sWname.toUpperCase()=="WORK EXIT")
					{	
					
						
						if(objwi.attribute_list["Process"].value!="" )
						{
						
						objDataForm.Process.value=objwi.attribute_list["Process"].value;

						}
					
					
					if(objwi.attribute_list["Document_Type"].value!="")
						{
						
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;
							
						}

					if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
					
					
						if(objwi.attribute_list["Special_Handling"].value!="" )
						{

						objDataForm.Special_Handling.value=objwi.attribute_list["Special_Handling"].value;

						}
						if(objwi.attribute_list["CompanyName"].value!="" )
						{

						objDataForm.CompanyName.value=objwi.attribute_list["CompanyName"].value;

						}
						if(objwi.attribute_list["CompanyCode"].value!="" )
						{

						objDataForm.CompanyCode.value=objwi.attribute_list["CompanyCode"].value;

						}
						
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma_SBR(objwi.attribute_list["Amount"]);
						

						}
						
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;
						
						}
						

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						if(objwi.attribute_list["SAP_Document_Number"].value!="" )
						{

						objDataForm.SAP_Document_Number.value=objwi.attribute_list["SAP_Document_Number"].value;

						}
						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Split_Doc_Decision"].value!="" )
						{

						objDataForm.Split_Doc_Decision.value=objwi.attribute_list["Split_Doc_Decision"].value;

						}
						if(objwi.attribute_list["Split_Resolution_Comments"].value!="" )
						{

						objDataForm.Split_Resolution_Comments.value=objwi.attribute_list["Split_Resolution_Comments"].value;

						}
						if(objwi.attribute_list["No_Of_WI_Created"].value!="" )
						{

						objDataForm.No_Of_WI_Created.value=objwi.attribute_list["No_Of_WI_Created"].value;

						}
						if(objwi.attribute_list["Cancel_Decision"].value!="" )
						{

						objDataForm.Cancel_Decision.value=objwi.attribute_list["Cancel_Decision"].value;

						}
						if(objwi.attribute_list["Cancel_Decision_Comments"].value!="" )
						{

						objDataForm.Cancel_Decision_Comments.value=objwi.attribute_list["Cancel_Decision_Comments"].value;

						}
						
						
						if(objwi.attribute_list["Validation"].value!="" )
						{

						objDataForm.Validation.value=objwi.attribute_list["Validation"].value;

						}
						if(objwi.attribute_list["Validation_Comments"].value!="" )
						{

						objDataForm.Validation_Comments.value=objwi.attribute_list["Validation_Comments"].value;

						}
						
						
						if(objwi.attribute_list["Check_Number"].value!="" )
						{

						objDataForm.Check_Number.value=objwi.attribute_list["Check_Number"].value;

						}
						objDataForm.Check_Number.focus();

						if(objwi.attribute_list["Check_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Check_Date.value=retdate;
						

						}
						if(objwi.attribute_list["Forward_To"].value!="" )
						{

						objDataForm.Forward_To.value=objwi.attribute_list["Forward_To"].value;

						}


						//alert("in split");
						
						makeDateButtonDisb();
					}


	if(sWname.toUpperCase()=="PROCESSING" || sWname.toUpperCase()=="INDEXING")
	{
		disablefield_VName("Vendor_Name");
	}

//Added for SBR_18 by Santul
isFormLoaded=true;
//Added for SBR_18 by Santul

}



function loadClrCheckboxes()
{
	 var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
	 var objWI_objwi=window.top.wi_object;
	 for (var i=0;i<objDataForm.elements.length ;i++ )
	 {
		 var sAttrName=objDataForm.elements[i].name.substring(3);
		 if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="clr" )
		 {
			
			
			if(objWI_objwi.attribute_list[sAttrName].value=="1" || objWI_objwi.attribute_list[sAttrName].value=="2")
				objDataForm.elements[i].disabled=false;			
			if(objWI_objwi.attribute_list[sAttrName].value=="2")			
				objDataForm.elements[i].checked=true;			
			if(objWI_objwi.attribute_list[sAttrName].value=="0" || objWI_objwi.attribute_list[sAttrName].value=="")
				objDataForm.elements[i].disabled=true;
		 }
	 }
	 return true;
}
			


 function disablecheckbox(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).className="EWTableCheckTextDisb";

	//objDataForm(field).className="EWTableCheckTextDisb";
	objDataForm(field).disabled=true;
	//objDataForm(field).className="EWTableCheckTextDisb";
	
}
function disablechecked(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).checked=false;
}
function enablecheckbox(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).disabled=false;
	
}
function makeDateButtonDisb()
		{
		var objDataForm= window.parent.frames["left"].document.forms["dataform"];
		objDataForm.SearchVName.disabled=true;
		document.getElementById('Date_IMG').disabled=true;
		document.getElementById('Date_IMG1').disabled=true;
		document.getElementById('Date_IMG2').disabled=true;
		}

function SetTabIndex()
{
	try
	{	//alert("in set tab index");
       var objdataForm =document.forms["dataform"];
	   var TabSet=0;
	   var TotalElements=objdataForm.elements.length;
	   
		var imgindx1=12;
		 var imgindx2=15;
		  var imgindx3=17;
		  

	   //alert("Workstepname: "+window.top.wi_object.workstep_name);
	   for(var i=0;i<TotalElements;i++)
		{           
		   //alert(objdataForm.elements[i].name);
			//alert(objdataForm.elements[i].tabIndex);

		  if(i==imgindx1)
		   { 		//alert(objdataForm.elements[i].name);
			    TabSet=TabSet+1;
				document.getElementById('Date_IMG').tabIndex=TabSet;
				//alert(document.getElementById('Reconciliation_Date_From_IMG').tabIndex);
				//alert("img "+TabSet);				
		   }
		   //alert();
		   if(i==imgindx2)
		   {	//alert(objdataForm.elements[i].name);
                TabSet=TabSet+1;
				document.getElementById('Date_IMG1').tabIndex=TabSet;
				//alert(document.getElementById('Reconciliation_Date_To_IMG').tabIndex);
				//alert("img "+TabSet);	
		   }
		   if(i==imgindx2)
		   {	//alert(objdataForm.elements[i].name);
                TabSet=TabSet+1;
				document.getElementById('Date_IMG2').tabIndex=TabSet;
				//alert(document.getElementById('Reconciliation_Date_To_IMG').tabIndex);
				//alert("img "+TabSet);	
		   }
		   if(objdataForm.elements[i].type=='text')
		   {
			   if(!objdataForm.elements[i].readOnly)
			   {   
				   
				   TabSet=TabSet+1;
				   objdataForm.elements[i].tabIndex=TabSet;
				   //alert(objdataForm.elements[i].name+"--"+TabSet);
			   }
			   else
			   {
				   objdataForm.elements[i].tabIndex="";
			   }
		    }
			else if(objdataForm.elements[i].type=='select-one')
			{
			   if(!objdataForm.elements[i].disabled)
				{			   
                   TabSet=TabSet+1;
				   objdataForm.elements[i].tabIndex=TabSet;	
				  // alert(objdataForm.elements[i].name+"--"+TabSet);
				}
				else
				{
					objdataForm.elements[i].tabIndex="";
				}
			}
			else if(objdataForm.elements[i].type=='button')
			{
				if(!objdataForm.elements[i].disabled)
				{  
					TabSet=TabSet+1;
				    objdataForm.elements[i].tabIndex=TabSet;
					//alert(objdataForm.elements[i].name+"--"+TabSet);
				}
				else
				{
					objdataForm.elements[i].tabIndex="";
				}
			}			
		    
		}
       
	}
	catch(e)
	{
		alert("Error in SetTabIndex: ");
	}
}


////Added on 12th June 2008(Santul Sharma)

function DisableFields()
{
	var objwi=window.top.wi_object;
	var sWname=objwi.workstep_name.toUpperCase();
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	
	if(objDataForm.Split_Doc_Decision.value=="Reject")
	{
		disablefield("No_Of_WI_Created");
		disablefield("WI_Serial_Number");
	}
	else
	{
		enablefield("No_Of_WI_Created");
		enablefield("WI_Serial_Number");
		
	}
	return true;
}
function enablefield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=false;
	objDataForm(field).className="TextFieldColor";
	
}

function disablefield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorDisb";
	objDataForm(field).value="";
}

function enablefield_VName(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=false;
	objDataForm(field).className="TextFieldColorLight";
	
}

function disablefield_VName(field)
{
	
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorLightDisb";
	//objDataForm(field).value="";
}

////Added on 12th June 2008(Santul Sharma)



function FillDocTypesCombo()
{
	
	var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
	var objwi=window.top.wi_object;
	var sWname=objwi.workstep_name.toUpperCase();
	var optn;
	var req;
	
	if(sWname.toUpperCase()=="WORK INTRODUCTION")
	{
	DocType='Non PO Invoice~PO Invoice~Credit Memo~Debit Note~Bonus Payments~PCards~Payment Request~Query~';
	}
	else
	{
	DocType='Non PO Invoice~PO Invoice~Credit Memo~Debit Note~Bonus Payments~PCards~Payment Request~Query~Other~';
	}

	if(document.getElementById("Document_Type").length!=1)
	{
	document.getElementById("Document_Type").length=1;
	
	}
	if(document.dataform.Process.value=='')
	{
		document.getElementById("Document_Type").length=1;
		//document.dataform.Special_Handling.disabled=false;
	}
	var userArray=DocType.split('~');
	if(document.dataform.Process.value!='')
	{
		for (var j=0;j<userArray.length-1;j++)
			{
				optn=document.createElement("option");	
				req=document.getElementById("Document_Type");
				optn.text=userArray[j];
				optn.value=userArray[j];	
				if(req.type=="select-one" )
				req.options.add(optn);
			} 
			
	}
	}
	
function loadcheckboxes()
{
	 //alert("tesi");
	 var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
	 var objWI_objwi=window.top.wi_object;
	 for (var i=0;i<objDataForm.elements.length ;i++ )
	 {
		 var sAttrName=objDataForm.elements[i].name.substring(3);
		
		 if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" && (objWI_objwi.attribute_list[sAttrName].value==1 || objWI_objwi.attribute_list[sAttrName].value==2))
		 {
			objDataForm.elements[i].checked=true;
		 }
	 }
	
	return true;
}

function OperationChangeCompname()
{
	
var objDataForm=document.forms["dataform"];
var comboCompnamevalue="";
comboCompnamevalue=objDataForm.tempjoinedstring.value;
var CompInfo=comboCompnamevalue.split(',');

if(objDataForm.Vendor_Name.value!="" || objDataForm.Vendor_ID.value!="")
	{
	objDataForm.Vendor_Name.value="";
	objDataForm.Vendor_ID.value="";

	}
	for(var i=1;i<CompInfo.length;i++)
	{
		
		var tempCompName=CompInfo[i].substring(0,CompInfo[i].indexOf("="));
		
		if(objDataForm.CompanyName.value=="")
		{
			objDataForm.CompanyName.value="";
			objDataForm.CompanyCode.value="";
		}
		else
		{
			if(objDataForm.CompanyName.value==tempCompName)
			{
				objDataForm.CompanyCode.value=CompInfo[i].substring(CompInfo[i].indexOf("=")+1,CompInfo[i].length);
			}
		}
	}
}

function OperationChangeCompcode()
{  
	
var objWI_Obj=window.top.wi_object;
var objDataForm=document.forms["dataform"];
var comboCompCode=objDataForm.tempjoinedstring.value;
var CompInfo=comboCompCode.split(',');
	
	if(objDataForm.Vendor_Name.value!="" || objDataForm.Vendor_ID.value!="")
	{
	objDataForm.Vendor_Name.value="";
	objDataForm.Vendor_ID.value="";

	}
	for(var i=1;i<CompInfo.length;i++)
	{
		
		var tempCompCode=CompInfo[i].substring(CompInfo[i].indexOf("=")+1,CompInfo[i].length);
		
		
		if(objDataForm.CompanyCode.value=="")
		{
			objDataForm.CompanyCode.value="";
			objDataForm.CompanyName.value="";

		}
		else
		{
			if(objDataForm.CompanyCode.value==tempCompCode)
			{
				objDataForm.CompanyName.value=CompInfo[i].substring(0,CompInfo[i].indexOf("="));
			}
		}
	}


}


 function setExcpChkBoxes()
 {
	var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
	 var objwi=window.top.wi_object;
	 
		if(objDataForm.Document_Type.value=="" || objDataForm.Document_Category.value=="" || objDataForm.Process.value=="")
		{
			for (var i=0;i<objDataForm.elements.length ;i++ )
			{
			if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
				{
					disablecheckbox(objDataForm.elements[i].name);
					disablechecked(objDataForm.elements[i].name);

				}
			}

		}
	else
	 {
		
		if((objDataForm.Document_Category.value=="Archival"))
		{

			
			enablecheckbox("chkExcp_Bad_Image");
			enablecheckbox("chkExcp_Duplicate");
			enablecheckbox("chkExcp_Multiple_Documents");
			enablecheckbox("chkExcp_New_Vendor_Setup");
			

			disablecheckbox("chkExcp_Blocked_Payment");
			disablechecked("chkExcp_Blocked_Payment");

			disablecheckbox("chkExcp_Missing_Incorrect_Approval");
			disablechecked("chkExcp_Missing_Incorrect_Approval");

			disablecheckbox("chkExcp_Not_An_Invoice");
			disablechecked("chkExcp_Not_An_Invoice");

			disablecheckbox("chkExcp_Missing_PO");
			disablechecked("chkExcp_Missing_PO");

			disablecheckbox("chkExcp_Incorrect_Coding");
			disablechecked("chkExcp_Incorrect_Coding");
			
			
			disablecheckbox("chkExcp_Blocked_Payment");
			disablechecked("chkExcp_Blocked_Payment");
		

		}
		
			else
			{
				
				
				if(objDataForm.Document_Type.value=="Non PO Invoice" || objDataForm.Document_Type.value=="Debit Note"  || objDataForm.Document_Type.value=="Payment Request" || objDataForm.Document_Type.value=="PO Invoice" || objDataForm.Document_Type.value=="Credit Memo")
						{
								
										enablecheckbox("chkExcp_Bad_Image");
										enablecheckbox("chkExcp_Duplicate");
										enablecheckbox("chkExcp_Multiple_Documents");
										enablecheckbox("chkExcp_Missing_Incorrect_Approval");
										enablecheckbox("chkExcp_Incorrect_Coding");
										enablecheckbox("chkExcp_New_Vendor_Setup");
										disablecheckbox("chkExcp_Blocked_Payment");
										disablechecked("chkExcp_Blocked_Payment");
											
										
										
										if(objDataForm.Document_Type.value=="PO Invoice" || objDataForm.Document_Type.value=="Credit Memo")
										{
										enablecheckbox("chkExcp_Missing_PO");
										if(objDataForm.Document_Type.value=="PO Invoice")
											{
											enablecheckbox("chkExcp_Blocked_Payment");
											}
										
										}
										else
											{
											disablecheckbox("chkExcp_Missing_PO");
											disablechecked("chkExcp_Missing_PO");
											disablecheckbox("chkExcp_Blocked_Payment");
											disablechecked("chkExcp_Blocked_Payment");
											}
								disablecheckbox("chkExcp_Not_An_Invoice");
								disablechecked("chkExcp_Not_An_Invoice");
						}
					else if(objDataForm.Document_Type.value=="PCards")
						{
						
						enablecheckbox("chkExcp_Bad_Image");
						enablecheckbox("chkExcp_Duplicate");
						enablecheckbox("chkExcp_Multiple_Documents");
						enablecheckbox("chkExcp_Missing_Incorrect_Approval");
						enablecheckbox("chkExcp_Incorrect_Coding");
						
						
						
						disablecheckbox("chkExcp_Not_An_Invoice");
						disablechecked("chkExcp_Not_An_Invoice");
						
						disablecheckbox("chkExcp_Missing_PO");
						disablechecked("chkExcp_Missing_PO");
						
						disablecheckbox("chkExcp_New_Vendor_Setup");
						disablechecked("chkExcp_New_Vendor_Setup");
						disablecheckbox("chkExcp_Blocked_Payment");
						disablechecked("chkExcp_Blocked_Payment");
						
						
						}
					else if(objDataForm.Document_Type.value=="Other" || objDataForm.Document_Type.value=="Query")
					{
					
						if(objDataForm.Document_Type.value=="Query")
						{
						enablecheckbox("chkExcp_Bad_Image");
						
						enablecheckbox("chkExcp_Multiple_Documents");
						
						}
						else
						{
						disablecheckbox("chkExcp_Bad_Image");
						disablechecked("chkExcp_Bad_Image");
						}
						enablecheckbox("chkExcp_Not_An_Invoice");

						disablecheckbox("chkExcp_Missing_PO");
						disablechecked("chkExcp_Missing_PO");
						disablecheckbox("chkExcp_Missing_Incorrect_Approval");
						disablechecked("chkExcp_Missing_Incorrect_Approval");
						disablecheckbox("chkExcp_Incorrect_Coding");
						disablechecked("chkExcp_Incorrect_Coding");
						disablecheckbox("chkExcp_Duplicate");
						disablechecked("chkExcp_Duplicate");
						if(objDataForm.Document_Type.value=="Other")
						{
						disablecheckbox("chkExcp_Multiple_Documents");
						disablechecked("chkExcp_Multiple_Documents");
						}
						disablecheckbox("chkExcp_New_Vendor_Setup");
						disablechecked("chkExcp_New_Vendor_Setup");

					}
				
	 }

 }
 }

function PLMIC_setDueDate()
{

var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
if(objDataForm.Invoice_Date.value=="")
	{
objDataForm.Due_Date.value="";
	}
	if(objDataForm.Due_Date.value!="")
	{
	objDataForm.Due_Date.value="";
	}

var tempInvDate=new Date(objDataForm.Invoice_Date.value);

tempInvDate=tempInvDate.setDate(tempInvDate.getDate()+30);

var tempInvDate1=new Date(tempInvDate);
var tempDate=tempInvDate1.getDate();
var tempMonth=Number(tempInvDate1.getMonth()+1);
//var tempMonth=Number(tempInvDate1.getMonth());
var tempYear=Number(tempInvDate1.getYear());
if(tempMonth>=1 && tempMonth<=9)
	{
	tempMonth=tempMonth.toString();
	tempMonth="0"+tempMonth;
	}
if(tempDate>=1 && tempDate<=9)
	{
	//tempDate=tempDate.toString();
	tempDate="0"+tempDate;
	}
if(tempYear<=99)
	{
	
	tempYear=1900+tempYear;

	}
	
var tempdueDate=tempMonth+'/'+tempDate+'/'+tempYear;

objDataForm.Due_Date.value=tempdueDate;

}



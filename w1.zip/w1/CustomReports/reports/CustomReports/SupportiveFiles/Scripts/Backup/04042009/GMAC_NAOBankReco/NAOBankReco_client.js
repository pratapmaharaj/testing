/*
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-GMAC
Module : GMAC-PLMIC
File Name : NAOBankReco_client.js
Author :   Tarit Gupta
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date Change By Change Description (Bug No. (If Any))
(DD/MM/YYYY)
----------------------------------------------------------------------------------------------------
*/
		
	function NAOBANKRECO_Save()
	{

		
		var objwi=window.top.wi_object;
		var objDataForm= window.parent.frames["left"].document.forms["dataform"];
		var sWname=objwi.workstep_name.toUpperCase();
		
		
		if(!combos(objwi,objDataForm))
		{
			return false;
		}
		
		if (sWname.toUpperCase()=="PROCESSING")
		{
			if(!Save_Comma_Amt_NAOBANKRECO())	
			{
				return false;
			}
			NAOBANKRECO_SetMailID();
		}
		return true;

	}



	function NAOBANKRECO_Introduce()

	{
		var objDataForm= window.parent.frames["left"].document.forms["dataform"];
		//var Date_From=objDataForm.Reconciliation_Date_From.value;
		//var Date_To=objDataForm.Reconciliation_Date_To;
		
		
		if(!NAOBANKRECO_Save())
		{
		return false;
		}
		
		if(!NAOBANKRECO_checkmandatory_Save())
		{
		return false;

		}
		
		if(!Check_Mandatory_Doctype())
		return false;

		

		if(!NAOBANKRECO_checkmandatory_doctype())
		{
			return false;
		}
		
	return true;
	

	}

	function NAOBANKRECO_checkmandatory_doctype()
	{

		try
		{
				var objDataForm= window.parent.frames["left"].document.forms["dataform"];
				var objwi=window.top.wi_object;
				var sWname=objwi.workstep_name.toUpperCase();
				var Bank_Stat=false;
				var Sap_Report=false;
				var Recon_Wrk_Sheet=false;
				var ATOM_Report=false;
				var Others=false;
				
				
				//alert("ftrgrtrhy6ju7 "+window.parent.frames['right'].document.frames['doctypes_center'].document.forms["textForm"].doctype);
				var length=window.parent.frames['right'].document.frames['doctypes_center'].document.forms["textForm"].doctype.length;
				if(length!=" ")
				{	

					var objDocType=window.parent.frames['right'].document.frames['doctypes_center'].document.forms["textForm"].doctype;
					
					for(var i=0 ; i<objDocType.length ;i++)
					{ 

						var doctype=objDocType.options[i].outerText;

						

						if(doctype.substring(0,13)=="BankStatement")
						{ 
							Bank_Stat=true;
						}
						if(doctype.substring(0,9)=="SAPReport")
						{ 
							Sap_Report=true;
						}
						//  
						if(doctype.substring(0,22)=="ReconciliationWrkSheet")
						{ 
							Recon_Wrk_Sheet=true;
						}
						if(doctype.substring(0,6)=="Others")
						{ 
							Others=true;
						}
						if(doctype.substring(0,10)=="ATOMReport")
						{ 
							ATOM_Report=true;
						}

						
									
					} 
					
					
					if(Bank_Stat!=true)
					{
						alert("Please import Bank Statement Document.");
						return false;
					}
						
					if(Sap_Report!=true)
					{
						alert("Please import SAP Report Document");
						return false;
					}

					if(ATOM_Report!=true)
					{
						alert("Please import ATOM Report Document");
						return false;
					}

					if(sWname.toUpperCase()=="PROCESSING" && Recon_Wrk_Sheet!=true)
					{
						alert("Please import Reconciliation Work Sheet Document");
						return false;
					}
						
						

				}

	}
	catch(e)
	{}
	return true;

}


function NAOBANKRECO_Done()
{   

			//alert("in done");
			var objwi=window.top.wi_object;
			var sWname=objwi.workstep_name.toUpperCase();
			var objDataForm= window.parent.frames["left"].document.forms["dataform"];
			//var From_Date=objDataForm.Reconciliation_Date_From.value;
			//var To_Date=objDataForm.Reconciliation_Date_To.value;

			
			
			if(!NAOBANKRECO_Save())
			{
				return false;
			}
					
			if(!NAOBANKRECO_checkmandatory_Save())
			{
			return false;

			}
			
			if(!NAOBANKRECO_SaveAtDone())
			{
				return false;
			}

			
	
		return true;
		
		//return false;

}


function NAOBANKRECO_checkmandatory_Save()
{

	var objwi=window.top.wi_object;
	var sWname=objwi.workstep_name.toUpperCase();
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];

	if (sWname.toUpperCase()=="WORK INTRODUCTION")
	{	
		if(!NAOBANKRECO_Work_Intro_checkmandatory_Save(objDataForm))
		{
			return false;
		}
	}
	if (sWname.toUpperCase()=="PROCESSING")
	{	
		if(!NAOBANKRECO_Processing_checkmandatory_Save(objDataForm))
		{
			return false;
		}
		
		if(!NAOBANKRECO_checkmandatory_doctype())
		{
				return false;
		}
				
		if(!Check_Mandatory_Doctype())
		{
				return false;
		}
	}
	
	if (sWname.toUpperCase()=="MANAGER_APPROVAL")
	{	
		if(!NAOBANKRECO_Approval_checkmandatory_Save(objDataForm))
		{
			return false;
		}
	}
	
				
return true;


}


function NAOBANKRECO_Work_Intro_checkmandatory_Save(objDataForm)
{
				
				
				if(objDataForm.Reconciliation_type.value=="" )
					{
						alert("Select the Reconciliation type.");
						objDataForm.Reconciliation_type.focus();
						return false;
					}
					
					if(objDataForm.Reconciliation_Date_From.value=="" )
					{
						alert("Reconciliation Date From can not be blank.");
						objDataForm.Reconciliation_Date_From.select();
						window.parent.frames["left"].document.getElementById("Reconciliation_Date_From_IMG").focus();
						//objDataForm.Invoice_Date.focus();
						return false;
					}
					
						if(!ChkFutureDate(objDataForm.Reconciliation_Date_From,"Reconciliation Date From"))
							return false;
						
					if(objDataForm.Reconciliation_Date_To.value=="" )
					{
						alert("Reconciliation Date To can not be blank.");
						objDataForm.Reconciliation_Date_To.select();
						window.parent.frames["left"].document.getElementById("Reconciliation_Date_To_IMG").focus();
						//objDataForm.Invoice_Date.focus();
						return false;
					}
					
					if(objDataForm.Bank_Name.value=="")
					{
						alert("Select an appropriate Bank Name");
						objDataForm.Bank_Name.focus();
						//objDataForm.Invoice_Date.focus();
						return false;
					}
					
					if(objDataForm.Bank_Acc_Number.value=="" )
					{
						alert("Bank Account Number can not be blank.");
						objDataForm.Bank_Acc_Number.focus();
						return false;
					}
						
					
							if(!ChkFutureDate(objDataForm.Reconciliation_Date_To,"Reconciliation Date To"))
							return false;
						
						
						//var Reconciliation_Date_To=objDataForm.Reconciliation_Date_To.value;
						//var Reconciliation_Date_From=objDataForm.Reconciliation_Date_From.value;
						if(!(DateComparator_NAOBANKRECO(objDataForm.Reconciliation_Date_To,objDataForm.Reconciliation_Date_From)))
						{
							return false;
						}
															
						
	return true;
	
	
}

function NAOBANKRECO_Processing_checkmandatory_Save(objDataForm)

	{
				
				
				
				if(objDataForm.Reconciliation_type.value=="" )
					{
						alert("Select Reconciliation type.");
						objDataForm.Reconciliation_type.focus();
						return false;
					}
					if(objDataForm.Reconciliation_Date_From.value=="" )
					{
						alert("Enter the Reconciliation_Date_From.");
						objDataForm.Reconciliation_Date_From.select();
						window.parent.frames["left"].document.getElementById("Reconciliation_Date_From_IMG").focus();
						//objDataForm.Invoice_Date.focus();
						return false;
					}
						
						if(!ChkFutureDate(objDataForm.Reconciliation_Date_From,"Reconciliation Date From"))
							return false;
						if(objDataForm.Reconciliation_Date_To.value=="" )
					{
						alert("Reconciliation Date To can not be blank.");
						objDataForm.Reconciliation_Date_To.select();
						window.parent.frames["left"].document.getElementById("Reconciliation_Date_To_IMG").focus();
						//objDataForm.Invoice_Date.focus();
						return false;
					}
							if(!ChkFutureDate(objDataForm.Reconciliation_Date_To,"Reconciliation Date To"))
							return false;
						//var Reconciliation_Date_To=objDataForm.Reconciliation_Date_To.value;
						//var Reconciliation_Date_From=objDataForm.Reconciliation_Date_From.value;	
						if(!(DateComparator_NAOBANKRECO(objDataForm.Reconciliation_Date_To,objDataForm.Reconciliation_Date_From)))
						{
							return false;
						}
					
					
					
					if(objDataForm.Bank_Acc_Number.value=="" )
					{
						alert("Bank Account Number can not be blank.");
						objDataForm.Bank_Acc_Number.focus();
						return false;
					}
					if(objDataForm.Bank_Name.value=="" )
					{
						alert("Kindly select an appropriate Bank Name.");
						objDataForm.Bank_Name.focus();
						return false;
					}
					
					
					if(objDataForm.fBank_Statement_Balance.value=="")
					{
						alert("Bank Statement Balance can not be blank.");
						objDataForm.fBank_Statement_Balance.focus();
						return false;
					}

					if(objDataForm.fSAP_Bank_Ledger_Balance.value=="")
					{
						alert("SAP Bank Ledger Balance can not be blank.");
						objDataForm.fSAP_Bank_Ledger_Balance.focus();
						return false;
					}
					
						
			return true;
}

function NAOBANKRECO_Validation_checkmandatory_Save(objDataForm)
{
				if(objDataForm.Validation.value=="" )
					{
						alert("Select the Validation.");
						objDataForm.Validation.focus();
						return false;
					}
				if(objDataForm.Validation_Comments.value=="" && objDataForm.Validation.value=="Fail" )
					{
						alert("Validation Comments can not be blank.");
						objDataForm.Validation_Comments.focus();
						return false;
					}


return true;
}

function NAOBANKRECO_Approval_checkmandatory_Save(objDataForm)
{

					if(objDataForm.Approval_Decision.value=="")//Bug No:NAOBANKRECO_AP_22
					{
						alert("Select the Managerial Approval Decision.");
						objDataForm.Approval_Decision.focus();
						return false;
					}
					if(objDataForm.Mgr_Approval_Comments.value=="" && objDataForm.Approval_Decision.value=="Reject" )
					{
						alert("Manager Approval Comments can not be blank.");
						objDataForm.Mgr_Approval_Comments.focus();
						return false;
					}
return true;

}
function NAOBANKRECO_Semp_Approval_checkmandatory_Save(objDataForm)
{

			if(objDataForm.Semp_Approval.value=="" )//Bug No:NAOBANKRECO_AP_22
					{
						alert("Select the Approval.");
						objDataForm.Semp_Approval.focus();
						return false;
					}
				if(objDataForm.Semp_Approval_Comments.value=="" && objDataForm.Semp_Approval.value=="Reject" )
					{
						alert("Approval Comments can not be blank.");
						objDataForm.Semp_Approval_Comments.focus();
						return false;
					}
			return true;

}


		


	function isModified(oldVal,newVal)
	{
	
	 if(oldVal.value!=newVal)
	 {
	  oldVal.value=newVal;
	  
	  oldVal.modified_flag=true;
	 }
	}


	function NAOBANKRECO_SaveAtDone()
	{
		var sWname=window.top.wi_object.workstep_name.toUpperCase();
		var objwi=window.top.wi_object;
		var objDataForm= window.parent.frames["left"].document.forms["dataform"];
		var sWiName=objwi.attribute_list["WorkItemName"].value;
		var sSplitVal=sWiName.split('-');
		var iWINo=parseFloat(sSplitVal[1]);
		var sPreviousWorkStep="";


		ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\NAOBANKRECO\\NAOBANKRECO_Done_Data.jsp","sWiName="+encodeURIComponent(sWiName)+"&sENTRYDATETIME="+window.top.wi_object.attribute_list["EntryDateTime"].value+"&sCurrentWorkStep="+sWname);
		//alert(iAjaxMainCode);
		if (iAjaxMainCode=="15")
		{
		alert('Error in updating NAOBANKRECO Done .');
		return false;
		}
		else if (sAjaxReturnValue!="Success")
		{
		alert('Error in updating NAOBANKRECO Done .');
		return false;
		}
		return true;

	}

	function NAOBANKRECO_SetMailID()
	{
		
		var sWname=window.top.wi_object.workstep_name.toUpperCase();
		var objwi=window.top.wi_object;
		var objDataForm= window.parent.frames["left"].document.forms["dataform"];
		var sWiName=objwi.attribute_list["WorkItemName"].value;
		var sSplitVal=sWiName.split('-');
		var iWINo=parseFloat(sSplitVal[1]);
		var sPreviousWorkStep="";

		
		ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\NAOBANKRECO\\NAOBANKRECO_SetMail_ID.jsp","sBankName="+encodeURIComponent(objDataForm.Bank_Name.value));
		//alert(iAjaxMainCode);
		if (iAjaxMainCode=="15")
		{
			alert('An error has occured.');
			return false;
		}
		else if (sAjaxReturnValue=="")
		{
			alert("No E-Mail ID found for the selected bank,the E-Mail alert won't be sent");
			//return false;
		}
		//alert("Required Value : "+sAjaxReturnValue);
		isModified(objwi.attribute_list['SendMailTo'],sAjaxReturnValue);
		return true;
	}
		



		function Save_Comma_Amt_NAOBANKRECO()
		{
			
			var sWname=window.top.wi_object.workstep_name.toUpperCase();
			var objwi=window.top.wi_object;
			var objDataForm= window.parent.frames["left"].document.forms["dataform"];
			if(sWname.toUpperCase()=="PROCESSING")
			{
				
				if(objDataForm.fBank_Statement_Balance.value!="" )
				{
					
					var temp=objDataForm.fBank_Statement_Balance.value;
					var temp1=RemoveComma_SBR(temp);
					isModified(objwi.attribute_list['Bank_Statement_Balance'],temp1);
				}
				else
				{
					isModified(objwi.attribute_list['Bank_Statement_Balance'],"");//Bug No:NAOBANKRECO_PR_23
				}


				if(objDataForm.fSAP_Bank_Ledger_Balance.value!="" )
				{
					var temp=objDataForm.fSAP_Bank_Ledger_Balance.value;
					var temp1=RemoveComma_SBR(temp);
					isModified(objwi.attribute_list['SAP_Bank_Ledger_Balance'],temp1);

				}
				else
				{
					isModified(objwi.attribute_list['SAP_Bank_Ledger_Balance'],"");//Bug No:NAOBANKRECO_PR_23
				}

				

				

			}		

		return true;
		}


function DateComparator_NAOBANKRECO(Reconciliation_Date_To,Reconciliation_Date_From)
{	//alert("DateComparator function");
	var Date_To=Reconciliation_Date_To.value;
	var Date_From=Reconciliation_Date_From.value;
	
	var Date_To_month=Number(Date_To.substring(Date_To.indexOf("0"),Date_To.indexOf("/")));	
	var Date_From_month=Number(Date_From.substring(Date_From.indexOf("0"),Date_From.indexOf("/")));
	
	var Date_To_date=Number(Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/")));
	var Date_From_date=Number(Date_From.substring(Date_From.indexOf("/")+1,Date_From.lastIndexOf("/")));
	
	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));
	var Date_From_year=Number(Date_From.substring(Date_From.lastIndexOf("/")+1,Date_From.length));
	

	if(Date_To_year<Date_From_year)
	{
		alert("To Reconcillation Date can not be less than From Reconcillation Date.");
		Reconciliation_Date_To.select();
		window.parent.frames["left"].document.getElementById("Reconciliation_Date_To_IMG").focus();
		return false;
	}
	else if(Date_To_year>=Date_From_year)
	{
		if(Date_From_month>Date_To_month)
		{
			alert("To Reconcillation Date can not be less than From Reconcillation Date.");
		Reconciliation_Date_To.select();
		window.parent.frames["left"].document.getElementById("Reconciliation_Date_To_IMG").focus();
		return false;
		}
		else if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{
				alert("To Reconcillation Date can not be less than From Reconcillation Date.");
		Reconciliation_Date_To.select();
		window.parent.frames["left"].document.getElementById("Reconciliation_Date_To_IMG").focus();
		return false;
			}
		}
	}
return true;
}

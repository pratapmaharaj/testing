/* 
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-GMAC
Module : GMAC-PLMIC
File Name : PL_AP_client.js
Author :   Tarit Gupta
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date			Change By		Change Description (Bug No. (If Any))
(DD/MM/YYYY)

02/09/2008		Bhawna Gupta	PLMIC_01
02/09/2008		Bhawna Gupta	PLMIC_02
11/09/2008		Bhawna Gupta	PLMIC_03
11/09/2008		Bhawna Gupta	PLMIC_04
18/09/2008		Bhawna Gupta	PLMIC_05
31/10/2008		Tarit Gupta		Comm_03
----------------------------------------------------------------------------------------------------
*/
var sRaisedExp="0";


			function PLMIC_Done()
			{   
				
				var objwi=window.top.wi_object;
				
				var objDataForm= window.parent.frames["left"].document.forms["dataform"];
				var sWname=window.top.wi_object.workstep_name.toUpperCase();
				
				
				
				if(sWname.toUpperCase()=="RESCAN_WI" || sWname.toUpperCase()=="PENDING_RESOLUTION" || sWname.toUpperCase()=="CANCEL_WI" || sWname.toUpperCase()=="SPLIT_DOCS")
					{
					if(!PLMIC_Save('D'))
						{
						return false;
						}
					}
				else if(!PLMIC_Save())
					{
						return false;
					}
					
				if(!PLMIC_checkmandatory_Save())
					{
						return false;
					
					}
					
		

				if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING")
					{
						
						if((objDataForm.Document_Type.value=="Other" || objDataForm.Document_Type.value=="Query") && sRaisedExp=="0")
							{
								
								var Confirm = confirm("Document type is selected as "+objDataForm.Document_Type.value+",Do you want to cancel the Work Item");
		
								if(Confirm)
								isModified(objwi.attribute_list["Excp_Not_An_Invoice"],"1");
								else
								{	
									objDataForm.Document_Type.focus();
									return false;
								}
							}//Comm_03 Added by Tarit as on 31-10-08
						else if(objwi.attribute_list["Intro_Type"].value!="BH" && objDataForm.chkExcp_Bad_Image.checked==true)
							{
							
							window.parent.frames["left"].document.getElementById("tab1").style.display='none';
							window.parent.frames["left"].document.getElementById("tab2").style.display='block';
							alert("Can not raise Bad Image Exception as Work item has been introducted Manually");
							return false;
							}
							//Comm_03 Added by Tarit as on 31-10-08

							if(sRaisedExp!="1")
							{

								if(!PLMIC_fetch_Vname_InvoiceNo())
								{
								return false;
								}
								//if(objDataForm.Vendor_Name_Hidden.value!='Y')
								if(Fetch_Vendor_Data())
								{
									if(!PLMIC_fetch_Vname_CompName())
									{
									return false;
									}
								}
							}
							//PLMIC_05 Added by Bhawna as on 17-09-08
							if(sWname.toUpperCase()=="INDEXING" && objDataForm.Vendor_Name.value!="" && objDataForm.Vendor_ID.value!="" && objDataForm.chkExcp_New_Vendor_Setup.checked==true)
								{
								window.parent.frames["left"].document.getElementById("tab1").style.display='none';
								window.parent.frames["left"].document.getElementById("tab2").style.display='block';
								alert("Can not raise New Vendor Setup Exception as Vendor Name and Vendor ID are not empty");
								return false;
								}
							else if(sWname.toUpperCase()=="PROCESSING" && objDataForm.chkExcp_New_Vendor_Setup.checked==true)
								{
								objDataForm.Vendor_Name.value="";
								objDataForm.Vendor_ID.value="";
								}
							
							//PLMIC_05 Added by Tarit as on 17-09-08
								
						
					}
					
					if(sWname.toUpperCase()=="VALIDATION")

						{
								if(objDataForm.Validation.value=="Fail" )
									{					
										objDataForm.Priority.value="Urgent";
										isModified(objwi.attribute_list["PriorityLevel"],"3");
										
										
									}
						}
					
				
						
						
					//alert("at 54");
					if(!PLMIC_Check_For_Route_Exception())
						{
					
							return false;
						}
					
					
					
					
					
					if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING" || sWname.toUpperCase()=="RESCAN_WI" || sWname.toUpperCase()=="PENDING_RESOLUTION" || sWname.toUpperCase()=="CANCEL_WI" || sWname.toUpperCase()=="SPLIT_DOCS")
					{
					
					if(!PLMIC_UpdateExpData())
						{

						return false;
						}

					}

					if(!PLMIC_SaveAtDone())
						{
							return false;
						}
						
					
			return true;
			
			//return false;
			
			}


	function PLMIC_setfilter(objDataForm,objwi)
	{
		
	
	isModified(objwi.attribute_list["qException"],"");
	//var qExp=objwi.attribute_list["qException"].value;
	var qExp="";
	
	if(objDataForm.chkExcp_Missing_Incorrect_Approval.checked==true)
		qExp=qExp+"A";
	if(objDataForm.chkExcp_New_Vendor_Setup.checked==true)
		qExp=qExp+"B";
	if(objDataForm.chkExcp_Incorrect_Coding.checked==true)
		qExp=qExp+"C";
	if(objDataForm.chkExcp_Missing_PO.checked==true)
		qExp=qExp+"D";
	
	if(objDataForm.chkExcp_Blocked_Payment.checked==true)
		qExp=qExp+"E";
	
	isModified(objwi.attribute_list["qException"],qExp);
	//alert(objwi.attribute_list["qException"].value);
		
	return true;
	}

	
	function PLMIC_Save(sMode)
		{
			
			
			var objwi=window.top.wi_object;
			var objDataForm= window.parent.frames["left"].document.forms["dataform"];
			var sWname=window.top.wi_object.workstep_name.toUpperCase();
			
		
		
			if(!combos(objwi,objDataForm))
				{
				return false;
				}
	
			
				if(sWname.toUpperCase()!="WORK INTRODUCTION")
				{
					//if(objDataForm.TempAmount.value!="" )
					//	{
					
						objwi.attribute_list['Amount'].value=RemoveComma_PLMIC();
						objwi.attribute_list['Amount'].modified_flag=true;
			
				
						
					//	}	
				}	
			
				
				
			
			if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING")
							{
			
								sRaisedExp =PLMIC_checkboxRaised(objwi,objDataForm);
								
								if(!PLMIC_setfilter(objDataForm,objwi))
								{
								return false;								
								}
									
								if(objDataForm.Priority.value=="Urgent")
								{
								//alert("sff:"+objwi.attribute_list["PriorityLevel"]);
								isModified(objwi.attribute_list["PriorityLevel"],"3");
								}
								else
								isModified(objwi.attribute_list["PriorityLevel"],"1");
								
								
							}
							

			if(sWname.toUpperCase()=="RESCAN_WI" || sWname.toUpperCase()=="PENDING_RESOLUTION" || sWname.toUpperCase()=="CANCEL_WI" || sWname.toUpperCase()=="SPLIT_DOCS")
				{ 
				sRaisedExp =PLMIC_checkboxRaised(objwi,objDataForm);
				if(!PLMIC_checkboxClear(objwi,objDataForm,sMode))
					{	
					return false;
					}

				}
			
		return true;
		
		
		}

function PLMIC_Introduce()

{
	//alert("resap_client:60");
	var objwi=window.top.wi_object;
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	if(!PLMIC_Save())
		{
		return false;
		}
		
		
	if(!PLMIC_checkmandatory_Save())
		{
		  return false;
			  
		}
	if(!Check_Mandatory_Doctype())
		return false;

	/*if(!PLMIC_checkmandatory_doctype())
		return false;
	*/

	if(objDataForm.Priority.value=="Urgent")
		{
		//alert("sff:"+objwi.attribute_list["PriorityLevel"]);
		isModified(objwi.attribute_list["PriorityLevel"],"3");
		}
		
	return true;

}

function PLMIC_checkmandatory_Save()

{ 
	var objwi=window.top.wi_object;
	var sWname=objwi.workstep_name.toUpperCase();
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	
		if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING" || sWname.toUpperCase()=="CANCEL_WI" || sWname.toUpperCase()=="PENDING_RESOLUTION" || sWname.toUpperCase()=="RESCAN_WI" || sWname.toUpperCase()=="SPLIT_DOCS")
		{
			//alert("Just Before");
			if(window.parent.frames["left"].document.getElementById('tab2').style.display=="block")
				{
					window.parent.frames["left"].document.getElementById('tab2').style.display="none";
					window.parent.frames["left"].document.getElementById('tab1').style.display="block";
				}
			
		}

		if(sWname.toUpperCase()=="WORK INTRODUCTION")
		{		
			
			if(!(PLMIC_checkmandatory_Work_Intro(objDataForm)))
			{
               return false; 
			}
		}
	
	if(sWname.toUpperCase()=="INDEXING")

		{
			
			if(!(PLMIC_checkmandatory_Indexing(objDataForm)))
			{
			   
               return false; 
			}
			
		}	
	if(sWname.toUpperCase()=="PROCESSING")

		{


			 if(!(PLMIC_checkmandatory_Processing(objDataForm)))
				{
				return false;
				}
		}	

	if(sWname.toUpperCase()=="CANCEL_WI")

		{
			 if(!(PLMIC_checkmandatory_Cancel_Wi(objDataForm)))
				{
				return false;
				}
		}
		if(sWname.toUpperCase()=="PENDING_RESOLUTION")

		{
			 
			 if(!(PLMIC_checkmandatory_Pending_Resolution(objDataForm)))
				{
				return false;
				}
		}

		
		if(sWname.toUpperCase()=="RESCAN_WI")
		{
			 if(!(PLMIC_checkmandatory_Rescan_Wi(objDataForm)))
				{
				return false;
				}
		}
		
		if(sWname.toUpperCase()=="SPLIT_DOCS")

		{
			 if(!(PLMIC_checkmandatory_Split_Docs(objDataForm)))
				{
				return false;
				}
		}
		if(sWname.toUpperCase()=="VALIDATION")

		{
			
			 if(!(PLMIC_checkmandatory_Validation(objDataForm)))
				{
				return false;
				}
		}
		if(sWname.toUpperCase()=="CHECK_DETAILS_UPDATE")

		{
			
			 if(!(PLMIC_checkmandatory_Chk_Detail_Update(objDataForm)))
				{
				return false;
				}
		}	


return true;


}



function PLMIC_checkmandatory_Work_Intro(objDataForm)
	{
					
					if(objDataForm.Process.value=="" )
					{
						alert("Select the Process.");
						objDataForm.Process.focus();
						return false;
					}	
					if(objDataForm.Document_Type.value=="" )
					{
						alert("Select the Document Type.");
						objDataForm.Document_Type.focus();
						return false;
					}	
										
					if(objDataForm.Special_Handling.value=="" )
					{
							alert("Select the Special Handling.");
							objDataForm.Special_Handling.focus();
							return false;
					}
					if(objDataForm.Priority.value=="" )
					{
						alert("Select the Priority.");
						objDataForm.Priority.focus();
						return false;
					}
					
				return true;


	}

function PLMIC_checkmandatory_Indexing(objDataForm)
	{
			var objwi=window.top.wi_object;
					
					

					if(objDataForm.Process.value=="" )
					{
						alert("Select the Process.");

						objDataForm.Process.focus();
						return false;
					}
					
					if(objDataForm.Document_Category.value=="Archival" && objDataForm.Document_Type.value=="Other" )
					{
						alert("Document type can not be Other as Document Category is Archival.");
						objDataForm.Document_Type.focus();
						return false;
					}	
					if(objDataForm.Document_Type.value=="" )
					{
						alert("Select the Document Type.");

						objDataForm.Document_Type.focus();
						return false;
					}

					//Added by bhawna for PLMIC_04 on 11-sep-2008
					if(objDataForm.Document_Type.value!="Other")
		{
					if(objDataForm.Document_Category.value=="" )
					{
						alert("Select the Document Category.");

						objDataForm.Document_Category.focus();
						return false;
					}	
					if(sRaisedExp!="1")
						{
							
							if(objDataForm.Special_Handling.value=="" )
							{
							alert("Select the Special Handling.");
							objDataForm.Special_Handling.focus();
							return false;
							}
							if(objDataForm.CompanyName.value=="" )
							{
							alert("Company Name can not be blank.");
							objDataForm.CompanyName.focus();
							return false;
							}
							if(objDataForm.CompanyCode.value=="" )
							{
							alert("Company Code can not be blank.");
							objDataForm.CompanyCode.focus();
							return false;
							}

							if(objDataForm.Vendor_Name.value=="" )
							{
							alert("Vendor Name can not be blank.");
							objDataForm.Vendor_Name.focus();
							return false;
							}
							if(objDataForm.Vendor_ID.value=="" )
							{
							alert("Vendor ID number can not be blank.");
							objDataForm.Vendor_ID.focus();
							return false;
							}


							if(objDataForm.Invoice_Number.value=="" )
							{
							alert("Invoice Number can not be blank.");
							objDataForm.Invoice_Number.focus();
							return false;
							}
							if(objDataForm.Invoice_Date.value=="" )
							{
							alert("Invoice Date can not be blank.");
							objDataForm.Invoice_Date.select();
							window.parent.frames["left"].document.getElementById("Date_IMG").focus();
							//objDataForm.Invoice_Date.focus();
							return false;
							}

							if(objDataForm.TempAmount.value=="" )
							{
							alert("Amount can not be blank.");

							objDataForm.TempAmount.focus();
							return false;
							}

							if(objDataForm.Received_Date.value=="" )
							{
							alert("Received Date can not be blank.");

							objDataForm.Received_Date.select();
							window.parent.frames["left"].document.getElementById("Date_IMG1").focus();
							//objDataForm.Received_Date.focus();
							return false;
							}
							if(objDataForm.Due_Date.value=="" )
							{
							alert("Due Date can not be blank.");


							objDataForm.Due_Date.select();
							window.parent.frames["left"].document.getElementById("Date_IMG2").focus();
							//objDataForm.Due_Date.focus();
							return false;
							}

							if(objDataForm.Priority.value=="")
							{
							alert("Select the Priority.");

							objDataForm.Priority.focus();

							return false;
							}
						}
	}

					if(objDataForm.Exception_Comments.value=="" && sRaisedExp=="1")
					{
						
									
						window.parent.frames["left"].document.getElementById("tab1").style.display='none';
						window.parent.frames["left"].document.getElementById("tab2").style.display='block';
						alert("Exception Comments can not be blank.");
						objDataForm.Exception_Comments.focus();

						return false;
					}
					
														
				return true;

	}

function PLMIC_checkmandatory_Processing(objDataForm)
	{
				if(objDataForm.Process.value=="" )
					{
						alert("Select the Process.");

						objDataForm.Process.focus();
						return false;
					}
					
					if(objDataForm.Document_Category.value=="Archival" && objDataForm.Document_Type.value=="Other" )
					{
						alert("Document type can not be Other as Document Category is Archival.");
						objDataForm.Document_Type.focus();
						return false;
					}	
					if(objDataForm.Document_Type.value=="" )
					{
						alert("Select the Document Type.");

						objDataForm.Document_Type.focus();
						return false;
					}
					//Added by bhawna for PLMIC_04 on 11-sep-2008
		if(objDataForm.Document_Type.value!="Other")
		{
					if(objDataForm.Document_Category.value=="" )
					{
						alert("Select the Document Category.");

						objDataForm.Document_Category.focus();
						return false;
					}	
					
					if(sRaisedExp!="1")
					{

							if(objDataForm.Special_Handling.value=="" )
							{
							alert("Select the Special Handling.");
							objDataForm.Special_Handling.focus();
							return false;
							}
							

							if(objDataForm.CompanyName.value=="" )
							{
							alert("Company Name can not be blank.");
							objDataForm.CompanyName.focus();
							return false;
							}
							if(objDataForm.CompanyCode.value=="" )
							{
							alert("Company Code can not be blank.");
							objDataForm.CompanyCode.focus();
							return false;
							}

							if(objDataForm.Vendor_Name.value=="" )
							{
							alert("Vendor Name can not be blank.");
							objDataForm.Vendor_Name.focus();
							return false;
							}
							if(objDataForm.Vendor_ID.value=="" )
							{
							alert("Vendor ID number can not be blank.");
							objDataForm.Vendor_ID.focus();
							return false;
							}


							if(objDataForm.Invoice_Number.value=="" )
							{
							alert("Invoice Number can not be blank.");
							objDataForm.Invoice_Number.focus();
							return false;
							}
							if(objDataForm.Invoice_Date.value=="" )
							{
							alert("Invoice Date can not be blank.");
							objDataForm.Invoice_Date.select();
							window.parent.frames["left"].document.getElementById("Date_IMG").focus();
							//objDataForm.Invoice_Date.focus();
							return false;
							}

							if(objDataForm.TempAmount.value=="" )
							{
							alert("Amount can not be blank.");

							objDataForm.TempAmount.focus();
							return false;
							}
							if(objDataForm.SAP_Document_Number.value=="" )
							{
								alert("SAP Document Number can not be blank.");
								objDataForm.SAP_Document_Number.focus();
								return false;
							}

							if(objDataForm.Received_Date.value=="" )
							{
								alert("Received Date can not be blank.");
								objDataForm.Received_Date.select();
								window.parent.frames["left"].document.getElementById("Date_IMG1").focus();
								//objDataForm.Received_Date.focus();
								return false;
							}
							if(objDataForm.Due_Date.value=="" )
							{
								alert("Due Date can not be blank.");
								objDataForm.Due_Date.select();
								window.parent.frames["left"].document.getElementById("Date_IMG2").focus();
								//objDataForm.Due_Date.focus();
								return false;
							}

							if(objDataForm.Priority.value=="")
							{
							alert("Select the Priority.");

							objDataForm.Priority.focus();

							return false;
							}
					}
		}
					if(objDataForm.Exception_Comments.value=="" && sRaisedExp=="1")
					{
						
									
						window.parent.frames["left"].document.getElementById("tab1").style.display='none';
						window.parent.frames["left"].document.getElementById("tab2").style.display='block';
						alert("Exception Comments can not be blank.");
						objDataForm.Exception_Comments.focus();

						return false;
					}

		
	return true;

	}
	
	function PLMIC_checkmandatory_Rescan_Wi(objDataForm)

		{
			var sxception=PLMIC_checkallexcepcleared(objDataForm);

			if(sxception=="1") 
			{
				
				window.parent.frames["left"].document.getElementById("tab1").style.display='none';
				window.parent.frames["left"].document.getElementById("tab2").style.display='block';
				alert("Please Clear All Raised Exceptions");
				return false;
			}

			

			if(sxception=="0" && objDataForm.Exception_Resol_Comments.value=="")
			{
					
					window.parent.frames["left"].document.getElementById("tab1").style.display='none';
					window.parent.frames["left"].document.getElementById("tab2").style.display='block';
					alert("Exception Resolution Comments can not be blank.");
					objDataForm.Exception_Resol_Comments.focus();
					return false;
			}
		
			
			return true;
		}
		

	function PLMIC_checkmandatory_Cancel_Wi(objDataForm)

		{
			
			var sxception=PLMIC_checkallexcepcleared(objDataForm);

			if(objDataForm.Cancel_Decision.value=="" )
			{
					

					window.parent.frames["left"].document.getElementById("tab1").style.display='block';
					window.parent.frames["left"].document.getElementById("tab2").style.display='none';
					alert("Select the Cancel Decision.");
					objDataForm.Cancel_Decision.focus();
					return false;
			}

			if(objDataForm.Cancel_Decision.value=="Reject" && objDataForm.Cancel_Decision_Comments.value=="")
			{
					alert("Cancel Decision Comments can not be blank.");
					objDataForm.Cancel_Decision_Comments.focus();
					return false;
			}
			
			

			if(sxception=="1" && objDataForm.Cancel_Decision.value!="Approved") 
			{
				
				window.parent.frames["left"].document.getElementById("tab1").style.display='none';
				window.parent.frames["left"].document.getElementById("tab2").style.display='block';
				alert("Please Clear All Raised Exceptions");
				return false;
			}
			
			

			if(objDataForm.Cancel_Decision.value!="Approved" && objDataForm.Exception_Resol_Comments.value=="")
			{
					
					window.parent.frames["left"].document.getElementById("tab1").style.display='none';
					window.parent.frames["left"].document.getElementById("tab2").style.display='block';
					alert("Exception Resolution Comments can not be blank.");
					objDataForm.Exception_Resol_Comments.focus();
					return false;
			}
		
			

				return true;

		}

		function PLMIC_checkmandatory_Pending_Resolution(objDataForm)
			{
			var sxception=PLMIC_checkallexcepcleared(objDataForm);
			
			if(sxception=="1") 
			{
				
				window.parent.frames["left"].document.getElementById("tab1").style.display='none';
				window.parent.frames["left"].document.getElementById("tab2").style.display='block';
				alert("Please Clear All Raised Exceptions");
				return false;
			}
			
			if(objDataForm.Exception_Resol_Comments.value=="")
			{
			
					
					window.parent.frames["left"].document.getElementById("tab1").style.display='none';
					window.parent.frames["left"].document.getElementById("tab2").style.display='block';
					alert("Exception Resolution Comments can not be blank.");
					objDataForm.Exception_Resol_Comments.focus();
					return false;
			}
		
			
			if(objDataForm.Forward_To.value=="" )
			{
					window.parent.frames["left"].document.getElementById("tab1").style.display='block';
					window.parent.frames["left"].document.getElementById("tab2").style.display='none';
					alert("Select the Forward To.");
					objDataForm.Forward_To.focus();
					return false;
			}
			return true;
			}

function PLMIC_checkmandatory_Split_Docs(objDataForm)
{
			var sxception=PLMIC_checkallexcepcleared(objDataForm);

			
			if(objDataForm.Split_Doc_Decision.value=="" )
				{
					alert("Select the Split Doc Decision.");
					objDataForm.Split_Doc_Decision.focus();
					return false;
				}
				if(objDataForm.No_Of_WI_Created.value=="" && objDataForm.Split_Doc_Decision.value=="Accept" )
				{
					alert("No Of WI Created can not be blank.");
					objDataForm.No_Of_WI_Created.focus();
					return false;
				}
				if(objDataForm.WI_Serial_Number.value=="" && objDataForm.Split_Doc_Decision.value=="Accept" )
				{
					alert("WI Serial Number can not be blank.");
					objDataForm.WI_Serial_Number.focus();
					return false;
				}
				if(objDataForm.Split_Doc_Decision.value=="Accept" && parseInt(objDataForm.No_Of_WI_Created.value)=="0")
			{
					
					
					window.parent.frames["left"].document.getElementById("tab1").style.display='block';
					window.parent.frames["left"].document.getElementById("tab2").style.display='none';
					alert("No of Workitems created cannot be zero.");
					objDataForm.No_Of_WI_Created.focus();
					return false;
			}

				

		if(sxception=="1") 
			{
				
				window.parent.frames["left"].document.getElementById("tab1").style.display='none';
				window.parent.frames["left"].document.getElementById("tab2").style.display='block';
				alert("Please Clear All Raised Exceptions");
				return false;
			}
			if(objDataForm.Exception_Resol_Comments.value=="")
			{
					
					window.parent.frames["left"].document.getElementById("tab1").style.display='none';
					window.parent.frames["left"].document.getElementById("tab2").style.display='block';
					alert("Exception Resolution Comments can not be blank.");
					objDataForm.Exception_Resol_Comments.focus();
					return false;
			}
			
			
		
			

return true;

}
 function PLMIC_checkmandatory_Validation(objDataForm)
 {
 
			 if(objDataForm.Validation.value=="" )
				{
					alert("Select the Validation.");
					objDataForm.Validation.focus();
					return false;
				}
				if(objDataForm.Validation_Comments.value=="" && objDataForm.Validation.value=="Fail")
				{
					alert("Validation Comments can not be blank.");
					objDataForm.Validation_Comments.focus();
					return false;
				}
				if(!PLMIC_checkmandatory_doctype())
				return false;
 return true;
 
 
 }

 function PLMIC_checkmandatory_Chk_Detail_Update(objDataForm)

{
				if(objDataForm.Check_Number.value=="" )
				{
					alert("Check Number can not be blank.");
					objDataForm.Check_Number.focus();
					return false;
				}
				if(objDataForm.Check_Date.value=="" )
				{
					
					objDataForm.Check_Date.select();
					alert("Check Date can not be blank.");
					//alert(window.parent.frames["left"].document.getElementById("Date_IMG3"));
					window.parent.frames["left"].document.getElementById("Date_IMG3").focus();
					return false;
				}

return true;
}



function isModified(oldVal,newVal)
	{
		//alert(" is in modified");
	 if(oldVal.value!=newVal)
	 {
	  oldVal.value=newVal;
	  
	  oldVal.modified_flag=true;
	 }
	}

function PLMIC_fnSelectVName()
	{
		
		if(document.dataform.CompanyName.value=='')
		{
			alert("Kindly select the Company Name First");
			document.dataform.CompanyName.focus(true);
			return false;

		}
		
		var sFeatures="dialogHeight:500px; dialogWidth:575px; status:no; dialogHide:no;";
		var sVendorInfo=window.showModalDialog("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\PLMIC\\SearchVenderNameMain.jsp?CompanyNameURL="+(document.dataform.CompanyName.value)+"",'',sFeatures);
		
		if(sVendorInfo!=undefined)
		{
			var sVendorData= sVendorInfo.split('\025');
			document.dataform.Vendor_ID.value=sVendorData[0];
			if(sVendorData[2]=='Y')
			{
				//document.dataform.Vendor_Name.readonly=false;  
				//document.dataform.Vendor_Name.className="TextFieldColorLight";
				enablefield_VName("Vendor_Name");
				document.dataform.Vendor_Name.value="";
				//document.dataform.Vendor_Name_Hidden.value='Y';

				
			}
			else
			{	
				disablefield_VName("Vendor_Name");
				document.dataform.Vendor_Name.value=sVendorData[1];
			}
			
		}
	}

function PLMIC_checkboxRaised(objWI_objwi,objDataForm)
{	
	var flag=0;            
	for (var i=0;i<objDataForm.elements.length ;i++ )
	 {
		var sAttrName=objDataForm.elements[i].name.substring(3);
		
		if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
		{
			
			if(objDataForm.elements[i].disabled ==false && objDataForm.elements[i].checked)
			{
				
				isModified(objWI_objwi.attribute_list[sAttrName],"1");
				flag=1;
			}
			 else if(objDataForm.elements[i].disabled ==false)
			{			 
				
				isModified(objWI_objwi.attribute_list[sAttrName],"");
				
			}
		}
		
	 }
	
	return flag;
	
}

function PLMIC_checkboxClear(objWI_objwi,objDataForm,sMode)
{		
	var flag=0;            
	for (var i=0;i<objDataForm.elements.length ;i++ )
	 {
		var sAttrName=objDataForm.elements[i].name.substring(3);
		
		if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="clr" )
		{
			
			
			if(objDataForm.elements[i].disabled ==false && objDataForm.elements[i].checked)
			{				
				if(sMode=="D")
					isModified(objWI_objwi.attribute_list[sAttrName],"0");
				else
					isModified(objWI_objwi.attribute_list[sAttrName],"2");
			}
			else if(objWI_objwi.attribute_list[sAttrName].value==2)
			{
				isModified(objWI_objwi.attribute_list[sAttrName],"1");
			}
			
		}
		
	 }
	
	return true;
	
}
function PLMIC_getExceptionList(objDataForm,sWname)
{	
	var stringtosend="";
		for ( i=0; i < objDataForm.elements.length ; i++)
		{	
			if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].checked==true )
			{	if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING")
				{
				
				 stringtosend += "~" + objDataForm.elements[i].name + "-" +"0";
				}
				else if(sWname.toUpperCase()=="RESCAN_WI" || sWname.toUpperCase()=="PENDING_RESOLUTION" || sWname.toUpperCase()=="CANCEL_WI" || sWname.toUpperCase()=="SPLIT_DOCS")
				{
					
				if(objDataForm.elements[i].name.substring(objDataForm.elements[i].name,3)=="clr")
				 stringtosend += "~" + objDataForm.elements[i].name + "-" +"1";
				if(objDataForm.elements[i].name.substring(objDataForm.elements[i].name,3)=="chk" && objDataForm.elements[i].disabled==false)
					stringtosend += "~" + objDataForm.elements[i].name + "-" +"0";
				}

			}
		}
		
		
	return stringtosend.substring(1,stringtosend.length);	
}

function PLMIC_UpdateExpData()
{
	
	var objwi=window.top.wi_object;
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
    var sWname=objwi.workstep_name.toUpperCase();
	var sWiName=objwi.attribute_list["WorkItemName"].value;
	var scheckedboxes=PLMIC_getExceptionList(objDataForm,sWname);

	
		if (scheckedboxes!="")
			{
			
				try
					{
												
						if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING")
						{	
								
							var ExceptionRasiedcomments=trim(objDataForm.Exception_Comments.value);
						
							
							ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\PLMIC\\PLMIC_Exp_Data.jsp","sProcessinstanceid="+encodeURIComponent(sWiName)+"&sWrkStepname="+encodeURIComponent(sWname)+"&sExpData="+encodeURIComponent(scheckedboxes)+"&sExceptionRasiedcomments="+encodeURIComponent(ExceptionRasiedcomments)+"&sExceptionRAISEDDATETIME="+encodeURIComponent("")+"&sExceptionResolvedcomments="+encodeURIComponent(""));	
						
						}
						else if(sWname.toUpperCase()=="RESCAN_WI" || sWname.toUpperCase()=="PENDING_RESOLUTION" || sWname.toUpperCase()=="CANCEL_WI" || sWname.toUpperCase()=="SPLIT_DOCS")
						{
							
							var ExceptionClearcomments=trim(objDataForm.Exception_Resol_Comments.value);
	
						
						ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\PLMIC\\PLMIC_Exp_Data.jsp","sProcessinstanceid="+encodeURIComponent(sWiName)+"&sWrkStepname="+encodeURIComponent(sWname)+"&sExpData="+encodeURIComponent(scheckedboxes)+"&sExceptionRasiedcomments="+encodeURIComponent("")+"&sExceptionRAISEDDATETIME="+encodeURIComponent("")+"&sExceptionResolvedcomments="+encodeURIComponent(ExceptionClearcomments));	

						}
					
						if (iAjaxMainCode=="15")
							{
							alert('Error in updating Exception Details.');
							return false;
							}
						else if (sAjaxReturnValue!="Success")
							{
						alert('Error in updating Exception Details.');
						return false;
							}
					
					}
					catch(e)
					{
					alert('Error in updating Exception Details.');
					
					return false;
					}
			}
     return true;  
}
function PLMIC_checkallexcepcleared(objDataForm)
{
	var flag=0;  
	for ( i=0; i < objDataForm.elements.length ; i++)
		{
			 if(objDataForm.elements[i].type=="checkbox")
			{
				
				
				if(objDataForm.elements[i].name.substring(objDataForm.elements[i].name,3)=="clr" && objDataForm.elements[i].disabled==false)
				{	
					
					if(objDataForm.elements[i].checked==false)
					flag =1;
					
				}
			}
		}
		return flag;
}

function PLMIC_SaveAtDone()
{
		

	var sWname=window.top.wi_object.workstep_name.toUpperCase();
	var objwi=window.top.wi_object;
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var sWiName=objwi.attribute_list["WorkItemName"].value;
	var sSplitVal=sWiName.split('-');
	var iWINo=parseFloat(sSplitVal[1]);
	var sPreviousWorkStep="";
	if(sWname.toUpperCase()=="WORK INTRODUCTION")
		sPreviousWorkStep=null;
	else
		sPreviousWorkStep=window.top.wi_object.attribute_list["Previous_Wrk_Step"].value;

	ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\PLMIC\\PLMIC_Done_Data.jsp","sWiName="+encodeURIComponent(sWiName)+"&sENTRYDATETIME="+window.top.wi_object.attribute_list["EntryDateTime"].value+"&sCurrentWorkStep="+sWname+"&sPreviousWorkStep="+sPreviousWorkStep);
	//alert(iAjaxMainCode);
	if (iAjaxMainCode=="15")
		{
			alert('Error in updating PLMIC Done .');
			return false;
		}
	else if (sAjaxReturnValue!="Success")
		{
			alert('Error in updating PLMIC Done .');
			return false;
		}
return true;

}
			
			
function PLMIC_Check_For_Route_Exception()		
		{	

			

		var sWname=window.top.wi_object.workstep_name.toUpperCase();
		var objDataForm= window.parent.frames["left"].document.forms["dataform"];

		if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING")
		{
			
			
			if((objDataForm.chkExcp_Bad_Image.checked==true) && (objDataForm.chkExcp_New_Vendor_Setup.checked==true || objDataForm.chkExcp_Not_An_Invoice.checked==true || objDataForm.chkExcp_Missing_Incorrect_Approval.checked==true || objDataForm.chkExcp_Duplicate.checked==true || objDataForm.chkExcp_Multiple_Documents.checked==true || objDataForm.chkExcp_Incorrect_Coding.checked==true || objDataForm.chkExcp_Blocked_Payment.checked==true || objDataForm.chkExcp_Multiple_Documents.checked==true || objDataForm.chkExcp_Missing_PO.checked==true))
			{
			window.parent.frames["left"].document.getElementById("tab1").style.display='none';
			window.parent.frames["left"].document.getElementById("tab2").style.display='block';
			alert("Exception of different category can not be raised simultaneously,Please select similar category of exception to proceed.");
			return false;
			}
			else if((objDataForm.chkExcp_New_Vendor_Setup.checked==true || objDataForm.chkExcp_Missing_Incorrect_Approval.checked==true  || objDataForm.chkExcp_Incorrect_Coding.checked==true || objDataForm.chkExcp_Missing_PO.checked==true || objDataForm.chkExcp_Blocked_Payment.checked==true) && (objDataForm.chkExcp_Duplicate.checked==true || objDataForm.chkExcp_Not_An_Invoice.checked==true || objDataForm.chkExcp_Multiple_Documents.checked==true))
			{
			window.parent.frames["left"].document.getElementById("tab1").style.display='none';
			window.parent.frames["left"].document.getElementById("tab2").style.display='block';
			alert("Exception of different category can not be raised simultaneously,Please select similar category of exception to proceed.");
			return false;
			}
			else if((objDataForm.chkExcp_Not_An_Invoice.checked==true || objDataForm.chkExcp_Duplicate.checked==true) && (objDataForm.chkExcp_New_Vendor_Setup.checked==true || objDataForm.chkExcp_Missing_Incorrect_Approval.checked==true || objDataForm.chkExcp_Blocked_Payment.checked==true || objDataForm.chkExcp_Missing_PO.checked==true || objDataForm.chkExcp_Multiple_Documents.checked==true))
			{
			
			window.parent.frames["left"].document.getElementById("tab1").style.display='none';
			window.parent.frames["left"].document.getElementById("tab2").style.display='block';
			alert("Exception of different category can not be raised simultaneously,Please select similar category of exception to proceed.");
			return false;
			}
			
			else if((objDataForm.chkExcp_Multiple_Documents.checked==true) && (objDataForm.chkExcp_New_Vendor_Setup.checked==true || objDataForm.chkExcp_Missing_Incorrect_Approval.checked==true || objDataForm.chkExcp_Missing_PO.checked==true || objDataForm.chkExcp_Blocked_Payment.checked==true || objDataForm.chkExcp_Duplicate.checked==true || objDataForm.chkExcp_Not_An_Invoice.checked==true))
			{
			window.parent.frames["left"].document.getElementById("tab1").style.display='none';
			window.parent.frames["left"].document.getElementById("tab2").style.display='block';
			alert("Exception of different category can not be raised simultaneously,Please select similar category of exception to proceed.");
			return false;
			}
			

		}
		return true;
	}

	function RemoveComma_PLMIC()
{
		var objDataForm=window.parent.frames["left"].document.forms["dataform"];
		var sTransactionAmount=objDataForm.TempAmount.value;
		var sAmount="";
		for (var i=0; i<sTransactionAmount.length; i++)
		{
			if(sTransactionAmount.substring(i,i+1)!=",")
				sAmount =sAmount + sTransactionAmount.substring(i, i+1);
		}
		return sAmount;

}


function PLMIC_fetch_Vname_InvoiceNo()

{
//alert("fetch_Vname_InvoiceNo");
	var objwi=window.top.wi_object;
	var sWname=objwi.workstep_name.toUpperCase();
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var sVname=trim(objDataForm.Vendor_Name.value);
	var sInvoice_No=trim(objDataForm.Invoice_Number.value);
	var sWiName=objwi.attribute_list["WI_Name"].value;
	//Added by bhawna 11-09-2008 for PLMIC_03
	var sVendorID=trim(objDataForm.Vendor_ID.value);
	var sFeatures="dialogHeight:500px; dialogWidth:575px; status:no; dialogHide:no;";
ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\PLMIC\\PLMIC_fetch_Vname_InvoiceNo.jsp","sVname="+encodeURIComponent(sVname)+"&sInvoice_No="+encodeURIComponent(sInvoice_No)+"&sWiName="+encodeURIComponent(sWiName)+"&sVendorID="+encodeURIComponent(sVendorID));



	
	
	if(sAjaxReturnValue=="Fail")
		{
		var Confirm = confirm("Duplicate Vendor Name and Invoice Number,Do you want to cancel the Work Item.");
		
				if(Confirm)
				isModified(objwi.attribute_list["Excp_Duplicate"],"1");
				else
					return false;
		}




return true;
}


function Fetch_Vendor_Data()
{

	var objwi=window.top.wi_object;
	var sWname=objwi.workstep_name.toUpperCase();
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var sVname=trim(objDataForm.Vendor_Name.value);
	var sVendorId=trim(objDataForm.Vendor_ID.value);
	var sCompanyName=trim(objDataForm.CompanyName.value);
	var sWiName=objwi.attribute_list["WI_Name"].value;
	
	
//Changed by Bhawna	 for PLMIC_05 on 23 Sep 2008
//ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\PLMIC\\Retrieve_CompName.jsp","VendorName="+encodeURIComponent(sVname)+"&VendorID="+encodeURIComponent(sVendorId));
ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\PLMIC\\Retrieve_CompName.jsp","VendorName="+encodeURIComponent(sVname)+"&VendorID="+encodeURIComponent(sVendorId)+"&CompanyName="+encodeURIComponent(sCompanyName));

	

	//if(sCompanyName!=sAjaxReturnValue)
	if(sAjaxReturnValue=="Found")
	{
		
		window.parent.frames["left"].document.getElementById("tab1").style.display='block';
		window.parent.frames["left"].document.getElementById("tab2").style.display='none';
		return true;
	}
	else
	{
		return false;
	}

return true;
}

function PLMIC_fetch_Vname_CompName()

{

	var objwi=window.top.wi_object;
	var sWname=objwi.workstep_name.toUpperCase();
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var sVname=trim(objDataForm.Vendor_Name.value);
	var sVendorId=trim(objDataForm.Vendor_ID.value);
	var sCompanyName=trim(objDataForm.CompanyName.value);
	var sWiName=objwi.attribute_list["WI_Name"].value;
	
	
//Changed by Bhawna	 for PLMIC_05 on 23 Sep 2008
//ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\PLMIC\\Retrieve_CompName.jsp","VendorName="+encodeURIComponent(sVname)+"&VendorID="+encodeURIComponent(sVendorId));
ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\PLMIC\\Retrieve_CompName.jsp","VendorName="+encodeURIComponent(sVname)+"&VendorID="+encodeURIComponent(sVendorId)+"&CompanyName="+encodeURIComponent(sCompanyName));

	

	//if(sCompanyName!=sAjaxReturnValue)
	if(sAjaxReturnValue!="Success")
	{
		alert("Mismatch in the selected Company Name Retrieved and the Vendor Data");
		window.parent.frames["left"].document.getElementById("tab1").style.display='block';
		window.parent.frames["left"].document.getElementById("tab2").style.display='none';
		objDataForm.CompanyName.focus(true);
		return false;
	}

return true;
}


function PLMIC_checkmandatory_doctype()
		{

			try
			{
				var objDataForm= window.parent.frames["left"].document.forms["dataform"];
				var objwi=window.top.wi_object;
				var sWname=objwi.workstep_name.toUpperCase();
				var VendorSetupForm=false;
				var SpecialHandlingForm=false;
				
				
				
				var length=window.parent.frames['right'].document.frames['doctypes_center'].document.forms["textForm"].doctype.length;
				if(length!=" ")
				{	

					var objDocType=window.parent.frames['right'].document.frames['doctypes_center'].document.forms["textForm"].doctype;
					
					for(var i=0 ; i<objDocType.length ;i++)
					{ 
						
						var doctype=objDocType.options[i].outerText;

						

							if(doctype.substring(0,19)=="SpecialHandlingForm")
							{ 
							SpecialHandlingForm=true;
							
							}
							
							
					}
					//Changed by Bhawna for PLMIC_01 & PLMIC_02
							if(SpecialHandlingForm!=true && trim(objDataForm.Validation.value)=="Pass" && trim(objDataForm.Special_Handling.value)=="Yes")
								{
								alert("Please Import Special Handling Form.");
								return false;
								}
					//Changed by Bhawna for PLMIC_01 & PLMIC_02
				}
			}
			catch(e)
				{}
			return true;
		}
	
		


/* 
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-GMAC
Module : GMAC-NAOCM
File Name : NAOCashMgmt_Validation.js
Author :   Tarit Gupta
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date			Change By		Change Description (Bug No. (If Any))
(DD/MM/YYYY)	

21/10/2008		Tarit Gupta		NAOCM_03 :Rec Date should be current date.
17/10/2008		Tarit Gupta		NCM_PR_2_6:Wire Transfer Reference was non ediable
17/10/2008		Tarit Gupta		NCM_PR_3_8:Processor decision should by editable
23/10/2008		Tarit Gupta		NAOCM_04 :Processor Decision should be disabled the first time
----------------------------------------------------------------------------------------------------
*/
function load()
{	
	var objwi=window.top.wi_object;
    var objDataForm=window.parent.frames["left"].document.forms["dataform"];
	var sWname = objwi.workstep_name.toUpperCase();
	

			if (sWname.toUpperCase()=="CREATE_REQUEST")
			{	
				if(objwi.attribute_list["Process"].value!="" )
				{

				objDataForm.Process.value=objwi.attribute_list["Process"].value;

				}
				if(objDataForm.Process.value=='NAO')
				{
					enablecombofield('Request_Type');
					//enablecombofield('Priority');
					objDataForm.Request_Type.focus();
					
					
				}
				else
				{
					disablecombofield('Request_Type');
					//disablecombofield('Priority');

				}
				

				if(objwi.attribute_list["Request_Type"].value!="" )
				{

				objDataForm.Request_Type.value=objwi.attribute_list["Request_Type"].value;

				}

				if(objwi.attribute_list["Request_Date"].value!="" )
				{

				var retdate=convertdatenew(objwi.attribute_list['Request_Date'].value);
				objDataForm.Request_Date.value=retdate;
				}
				else 
				{
					NAOCM_CalRecDate(objDataForm.Request_Date);//NAOCM_03 Added by Tarit as on 21-10-08
				}
				/*if(objwi.attribute_list["Priority"].value!="" )
				{

				objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

				}*/



			}
			else if(sWname.toUpperCase()=="PROCESS_REQUEST")
					{
						
						//alert(objDataForm.Comments);
						objDataForm.Comments.value=objwi.attribute_list["Comments"].value;
						if(objwi.attribute_list["Process"].value!="" )
						{

							objDataForm.Process.value=objwi.attribute_list["Process"].value;

						}						
						//alert(objwi.attribute_list["Process"].value);

						if(objDataForm.Process.value=='NAO')
						{	
							enablecombofield('Request_Type');
							//enablecombofield('Priority');
							enablefield('Recipient');
							//enablelefield('Insight_Reference_Number');
							
							enablecombofield('Processor_Decision');
							disablefield('Payee');
							disablefield('Bank_Name');
							disablecombofield('Reject_WI');							
							objDataForm.Request_Type.focus();
							
							
						}
						else if(objDataForm.Process.value=='MIC')
						{
							//alert("1");
							disablecombofield('Processor_Decision');
							disablecombofield('Request_Type');
							//disablecombofield('Priority');
							disablefield('Recipient');
							enablefield('Payee');
							enablefield('Bank_Name');
							disablefield('Insight_Reference_Number');							
							//enablefield('Comments');                            
							//enablecombofield('Reject_WI');

						}
						else
						{
							enablecombofield('Request_Type');
							//enablecombofield('Priority');
							enablefield('Payee');
							enablefield('Bank_Name');
							enablefield('Recipient');
							enablelefield('Insight_Reference_Number');							
							enablefield('Comments');
							enablecombofield('Processor_Decision');
							enablecombofield('Reject_WI');

						}
						//alert("2 "+objwi.attribute_list["Processor_Decision"].value);
						if(objwi.attribute_list["Request_Type"].value!="" && objDataForm.Process.value=='NAO')
						{

							objDataForm.Request_Type.value=objwi.attribute_list["Request_Type"].value;

						}
										
		
						Common_load(objDataForm,objwi,sWname);
						//alert("3 "+objwi.attribute_list["Processor_Decision"].value);
						if(objwi.attribute_list["Recent_Approvers"].value!="")
						{
							loadfields(objDataForm);
						}
						else if(objDataForm.Request_Type.type=='select-one' && objDataForm.Process.value=='NAO')
						{
							
							OnchangeRequest(objDataForm.Request_Type,objDataForm);
						}
						//alert("4 "+objwi.attribute_list["Processor_Decision"].value);
							
							
					}
					
					else if(sWname.toUpperCase()=="VALIDATION")
					{
						if(objwi.attribute_list["Process"].value!="" )
						{
							objDataForm.Process.value=objwi.attribute_list["Process"].value;
						}
						if(objwi.attribute_list["Request_Type"].value!="" && objDataForm.Process.value=='NAO')
						{
							objDataForm.Request_Type.value=objwi.attribute_list["Request_Type"].value;
						}
						Common_load(objDataForm,objwi,sWname);
					}
					
			else if(sWname.toUpperCase()=="WNS_MGR_APPROVAL")
					{
						if(objwi.attribute_list["Process"].value!="" )
						{
							objDataForm.Process.value=objwi.attribute_list["Process"].value;
						}
						if(objwi.attribute_list["Request_Type"].value!="" && objDataForm.Process.value=='NAO')
						{
							objDataForm.Request_Type.value=objwi.attribute_list["Request_Type"].value;
						}
						Common_load(objDataForm,objwi,sWname);
					}
			else if (sWname.toUpperCase()=="PENDING" || sWname.toUpperCase()=="COMM_IMP_REPORT" || sWname.toUpperCase()=="QUERY" || sWname.toUpperCase()=="WORK EXIT")
					{	
						if(objwi.attribute_list["Process"].value!="" )
						{
							objDataForm.Process.value=objwi.attribute_list["Process"].value;
						}
						if(objwi.attribute_list["Request_Type"].value!="" && objDataForm.Process.value=='NAO')
						{
							objDataForm.Request_Type.value=objwi.attribute_list["Request_Type"].value;
						}
						Common_load(objDataForm,objwi,sWname);
					
					 if(objwi.attribute_list["Confirmation_Call_Made"].value!="")
							{

							objDataForm.Confirmation_Call_Made.value=objwi.attribute_list["Confirmation_Call_Made"].value;

							}
			
			
			
			
					}
					
					
isFormLoaded=true;
return true;

}

function Common_load(objDataForm,objwi,sWname)
{
		
		
		

		if(objwi.attribute_list["Request_Date"].value!="" )
		{

		var retdate=convertdatenew(objwi.attribute_list['Request_Date'].value);
		objDataForm.Request_Date.value=retdate;
		}
		/*if(objwi.attribute_list["Priority"].value!=""  && objDataForm.Process.value=='NAO')
		{

		objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

		}*/

		if(objwi.attribute_list["Bank_Acc_Number"].value!="")
		{

		objDataForm.Bank_Acc_Number.value=objwi.attribute_list["Bank_Acc_Number"].value;

		}
		//onchangedoctype(objDataForm);

		if(objwi.attribute_list["Amount"].value!="")
		{
		//alert(objwi.attribute_list["Amount"].value);
		objDataForm.fAmount.value=DollarAmount_commaNeg(objwi.attribute_list["Amount"]);

		}

		if(objwi.attribute_list["Recipient"].value!="" && objDataForm.Process.value=='NAO')
		{

		objDataForm.Recipient.value=objwi.attribute_list["Recipient"].value;

		}


		
		if(objwi.attribute_list["Wire_Transfer_Reference"].value!="" )
		{	
			objDataForm.Wire_Transfer_Reference.value=objwi.attribute_list["Wire_Transfer_Reference"].value;
		}
		
		

		if(objwi.attribute_list["Insight_Reference_Number"].value!="" && objDataForm.Process.value=='NAO')
		{
		

		objDataForm.Insight_Reference_Number.value=objwi.attribute_list["Insight_Reference_Number"].value;
	

		}
		if(objwi.attribute_list["Payee"].value!="" && objDataForm.Process.value=='MIC')
		{
		

		objDataForm.Payee.value=objwi.attribute_list["Payee"].value;
	

		}  
		if(objwi.attribute_list["Bank_Name"].value!="" && objDataForm.Process.value=='MIC')
		{
		

		objDataForm.Bank_Name.value=objwi.attribute_list["Bank_Name"].value;
	

		}  
//NCM_PR_3_8 Changed by Tarit as on 17-10-08
		if(objwi.attribute_list["Processor_Decision"].value!="" && objDataForm.Process.value=='NAO')
		{

		objDataForm.Processor_Decision.value=objwi.attribute_list["Processor_Decision"].value;

		}
		
		if(objwi.attribute_list["Reject_WI"].value!="" && objDataForm.Process.value=='MIC')
		{

		objDataForm.Reject_WI.value=objwi.attribute_list["Reject_WI"].value;

		}
//NCM_PR_3_8 Changed by Tarit as on 17-10-08
		if(objwi.attribute_list["Comments"].value!="" && objDataForm.Process.value=='NAO')
		{

		objDataForm.Comments.value=objwi.attribute_list["Comments"].value;

		}
		if(objwi.attribute_list["Recent_Approvers"].value!="" && objDataForm.Process.value=='NAO')
		{

		objDataForm.Recent_Approvers.value=objwi.attribute_list["Recent_Approvers"].value;

		}
		if(objwi.attribute_list["Validation"].value!="")
		{

		objDataForm.Validation.value=objwi.attribute_list["Validation"].value;

		}
		if(objwi.attribute_list["Validation_Comments"].value!="")
		{

		objDataForm.Validation_Comments.value=objwi.attribute_list["Validation_Comments"].value;

		}
		if(sWname.toUpperCase()!="VALIDATION")
			{
				if(objwi.attribute_list["WNS_Manager_Approval"].value!="")
				{
					
					objDataForm.WNS_Manager_Approval.value=objwi.attribute_list["WNS_Manager_Approval"].value;
					
				}
				if(objwi.attribute_list["WNS_Manager_Approval_Comments"].value!="")
				{
					
					objDataForm.WNS_Manager_Approval_Comments.value=objwi.attribute_list["WNS_Manager_Approval_Comments"].value;
					
				}
			}

}

function OnchangeRequest(Req,dataform)
{
	//NCM_PR_2_6 Changed by Tarit 17-10-08
	//Change No:NAOCM_04 Changed by Tarit Gupta 23-10-2008
	//disablecombofield("Processor_Decision");
	var objwi=window.top.wi_object;
	var objDataForm=window.parent.frames["left"].document.forms["dataform"];
	if(Req.value=="Nuvell Operational Funding" || Req.value=="Nuvell Daily Settlement")
		{
		//disablecombofield("Processor_Decision");
		//disablefield("Recipient");
		disablefield("Wire_Transfer_Reference");
		disablefield("Insight_Reference_Number");
		}
	else if(Req.value=="Wire Payment")
		{
		
		//enablefield("Recipient");
		enablefield("Wire_Transfer_Reference");
		disablefield("Insight_Reference_Number");
		if(objwi.attribute_list["Wire_Transfer_Reference"].value!="")
		{
			objDataForm.Wire_Transfer_Reference.value=objwi.attribute_list["Wire_Transfer_Reference"].value;
		}
		
		//disablecombofield("Processor_Decision");

		}
	else
		{
		//enablecombofield("Processor_Decision");
		//enablefield("Recipient");
		enablefield("Wire_Transfer_Reference");
		enablefield("Insight_Reference_Number");
		if(objwi.attribute_list["Wire_Transfer_Reference"].value!="")
		{
			objDataForm.Wire_Transfer_Reference.value=objwi.attribute_list["Wire_Transfer_Reference"].value;
		}
		if(objwi.attribute_list["Insight_Reference_Number"].value!="")
		{
			objDataForm.Insight_Reference_Number.value=objwi.attribute_list["Insight_Reference_Number"].value;
		}
			
		}
	
//NCM_PR_2_6 Changed by Tarit 17-10-08

}


function loadfields(objDataForm)
{
	
if(objDataForm.Recent_Approvers.value!="")
	{
		ReadOnlyCombo("Process");
		ReadOnlyCombo("Request_Type");
		disablelightdatefield("Request_Date");
		document.getElementById('imgdate').disabled=true;
		//ReadOnlyCombo("Priority");
		ReadOnly("Bank_Acc_Number");
		ReadOnly("fAmount");
		ReadOnly("Recipient");
		ReadOnly("Wire_Transfer_Reference");
		ReadOnly("Insight_Reference_Number");
			
	}
	/*else
	{
	enablecombofield("Request_Type");
	enabledatefield("Request_Date");
	document.getElementById('imgdate').disabled=false;
	enablecombofield("Priority");
	enablefield("Recipient");
	enablefield("Bank_Acc_Number");
	enablefield("fAmount");
	enablefield("Wire_Transfer_Reference");
	enablefield("Insight_Reference_Number");
	}*/


}
function disablelightdatefield(field)
{
	
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorDisbDate";
	
	
}


function ReadOnly(field)
{
	
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorDisb";
	
}

function ReadOnlyCombo(field)
{

var objDataForm= window.parent.frames["left"].document.forms["dataform"];
objDataForm(field).disabled=true;
objDataForm(field).className="TextFieldColorDisb";
//objDataForm(field).getContent("box/text").setStyle("color", "red");

//objDataForm(field).setStyle("color","red");
//alert("objname:"+objDataForm(field).name);
//alert("color:"+objDataForm(field).style.fontcolor);



}

function enablefield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=false;
	objDataForm(field).className="TextFieldColor";
	objDataForm(field).value="";
	
}

function disablefield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorDisb";
	objDataForm(field).value="";
}
function enablecombofield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).disabled=false;
	objDataForm(field).className="TextFieldColor";
	objDataForm(field).value="";
	
}

function disablecombofield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).disabled=true;
	objDataForm(field).className="TextFieldColorDisb";
	objDataForm(field).value="";
}
 function enabledatefield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=false;
	objDataForm(field).className="TextFieldColorDate";
	objDataForm(field).value="";
	
}

function disabledatefield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorDisbDate";
	objDataForm(field).value="";
}
function NAOCM_CalRecDate(temp)
{
				
				
				tempReqDate=temp.value;
				var sDateSeparator="/";
				var tempRecDate=new Date();
				var tempMonth=tempRecDate.getMonth()+1;
				var tempDate=tempRecDate.getDate();
				if(tempMonth>=1 && tempMonth<=9)
					{
					tempMonth=tempMonth.toString();
					tempMonth="0"+tempMonth;
					}
				if(tempDate>=1 && tempDate<=9)
					{
					//tempDate=tempDate.toString();
					tempDate="0"+tempDate;
					}
				var tempformRecdate=tempMonth+'/'+tempDate+'/'+tempRecDate.getYear();
				temp.value=tempformRecdate;
				
				
}

function DisableFormFields()
{
	
	var objwi=window.top.wi_object;
    var objDataForm=window.parent.frames["left"].document.forms["dataform"];
	var sWname=objwi.workstep_name.toUpperCase();
	if(objDataForm.Process.value=='MIC')
	{
		disablecombofield('Request_Type');
		//disablecombofield('Priority');
		
		if(sWname=='PROCESS_REQUEST')
		{
			enablefield('Payee');
			enablefield('Bank_Name');
			disablefield('Recipient');
			disablefield('Insight_Reference_Number');
			//disablefield('Comments');
			disablecombofield('Processor_Decision');
			//enablecombofield('Reject_WI');

		}
	}
	else if(objDataForm.Process.value=='NAO')
	{
		enablecombofield('Request_Type');
		//enablecombofield('Priority');
		if(sWname=='PROCESS_REQUEST')
		{
			disablefield('Payee');
			disablefield('Bank_Name');
			enablefield('Recipient');
			enablefield('Insight_Reference_Number');
			enablefield('Comments');
			enablecombofield('Processor_Decision');
			disablecombofield('Reject_WI');

		}
	}
	else
	{
		enablecombofield('Request_Type');
		//enablecombofield('Priority');
		if(sWname=='PROCESS_REQUEST')
		{
			enablefield('Payee');
			enablefield('Bank_Name');
			enablefield('Recipient');
			enablefield('Insight_Reference_Number');
			enablefield('Comments');
			enablecombofield('Processor_Decision');
			enablecombofield('Reject_WI');

		}

	}
	
}


  




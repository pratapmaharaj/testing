

/*		Product   : Omniflow
    Application  : Web desktop
    Module   : WNS-GMAC-SBR
    File   : Semperian_client.js
    Written By  : Tarit Gupta
    Purpose   :
    Change History  :
 Problem No  Correction Date  Changed By     Comments
 ----------  ---------------  --------- 
 Bug No:SBR_AP_22				Tarit		If the workitem has been re-routed from the Validation Queue and the reconciliation type is changed,the editable fields should change accordingly
 Bug No:SBR_PR_23				Tarit		If the Bank Statement Balance text box is populated with special characters the Other Adjustments text box should not show any inappropriate value		
 Bug No:SBR_PR_24				Tarit		If the Bank Statement Balance text box is populated with digits whose length is more than 13 characters then the Other Adjustments text box should be emptied
 Bug No:SBR_PR_25				Tarit		The workitem after being completed successfully from the SBR_Approval queue should be visible in the workitem list of the WNS Approval queue when this queue is selected from the main dropdown in omniflow.
 Bug No:SBR_1					Tarit		Reconcillation From Date should be lesser than Reconcillation To Date.
 Bug No:SBR_2					Tarit		System is allowing user to submit the workitem with "Doc_1178" document type in Check reconcillation. It should not allow to submit Check Recom workitem with Doc_1178 document type.
 Change No : SBR_15				Bhawna		Change in formula for calculating Other adjustments
 Bug No : SBR_16				Bhawna		Bug in formula for calculating Adjustments

 */
		
	function SBR_Save()
	{

		
		var objwi=window.top.wi_object;
		var objDataForm= window.parent.frames["left"].document.forms["dataform"];
		var sWname=objwi.workstep_name.toUpperCase();
		//alert("test");
		if(!combos(objwi,objDataForm))
		{
		return false;
		}

		if (sWname.toUpperCase()=="PROCESSING")
			{
			if(!Save_Comma_Amt())	
			{
			return false;
			}
			}


		return true;

	}



	function SBR_Introduce()

	{
		var objDataForm= window.parent.frames["left"].document.forms["dataform"];
		//var Date_From=objDataForm.Reconciliation_Date_From.value;
		//var Date_To=objDataForm.Reconciliation_Date_To;
		
		if(!SBR_Save())
		{
		return false;
		}
		if(!SBR_checkmandatory_Save())
		{
		return false;

		}
		
		
		

		if(!Check_Mandatory_Doctype())
		return false;

		if(!SBR_checkmandatory_doctype())
		{
		return false;

		}
	return true;

	}

		function SBR_checkmandatory_doctype()
		{

			try
			{
				var objDataForm= window.parent.frames["left"].document.forms["dataform"];
				var objwi=window.top.wi_object;
				var sWname=objwi.workstep_name.toUpperCase();
				var Bank_Stat=false;
				var Sap_Report=false;
				var EOS_Report=false;
				var Doc_1178=false;
				
				//alert("ftrgrtrhy6ju7 "+window.parent.frames['right'].document.frames['doctypes_center'].document.forms["textForm"].doctype);
				var length=window.parent.frames['right'].document.frames['doctypes_center'].document.forms["textForm"].doctype.length;
				if(length!=" ")
				{	

					var objDocType=window.parent.frames['right'].document.frames['doctypes_center'].document.forms["textForm"].doctype;
					for(var i=0 ; i<objDocType.length ;i++)
					{ 

						var doctype=objDocType.options[i].outerText;


					//	if(objDataForm.Reconciliation_type.value=="Bank Account Reconciliation")
					//	{
							if(doctype.substring(0,14)=="Bank_Statement")
							{ 
							Bank_Stat=true;

							}
							


							if(doctype.substring(0,10)=="SAP_Report")
							{ 
							Sap_Report=true;

							}
							
							if(doctype.substring(0,10)=="EOS_Report")
							{ 
							EOS_Report=true;

							}
							

							//if (sWname.toUpperCase()=="PROCESSING")
							//	{
									if(doctype.substring(0,8)=="Doc_1178")
									{ 
									Doc_1178=true;
									}
									
							//	}	


					//	}
								
					/*	else if(objDataForm.Reconciliation_type.value=="Check Reconciliation")
						{
							
							if(doctype.substring(0,10)=="EOS_Report")
							{ 

							EOS_Report=true;
							}


							if(doctype.substring(0,10)=="SAP_Report")
							{ 
							Sap_Report=true;
							}
							
							if(doctype.substring(0,14)=="Bank_Statement")
							{ 
							Bank_Stat=true;

							}
							//if (sWname.toUpperCase()=="PROCESSING")
								//{
									if(doctype.substring(0,8)=="Doc_1178")
									{ 
									Doc_1178=true;

									}
								//}	


						}*/


					} 

					if(objDataForm.Reconciliation_type.value=="Bank Account Reconciliation")
					{

						//if (sWname.toUpperCase()=="PROCESSING")
						//{
							if(Doc_1178!=true)
							{
							alert("Please import Document 1178.");
							return false;
							}
						//}
						if(EOS_Report==true)
						{
						alert("Can not Import EOS Report for Reconciliation Type Bank Account.");
						return false;
						}
						
						if(Bank_Stat==true && Sap_Report==true)
						return true;
						else if(Bank_Stat==false && Sap_Report==false)
						{
						alert("Please import Bank Statement and SAP Report.");
						return false;
						}
						else if(Bank_Stat==true && Sap_Report==false) 
						{
						alert("Please import SAP Report.");
						return false;						
						}
						else if(Bank_Stat==false && Sap_Report==true) 
						{
						alert("Please import Bank Statement.");
						return false;						
						}

						
									


					}
					else if(objDataForm.Reconciliation_type.value=="Check Reconciliation")
					{
						
						if(Bank_Stat==true)
						{
						alert("Can not import Bank Statement for Reconciliation type Check.");
						return false;	
						}

						//Bug SBR_2 added by Tarit Gupta
						if(Doc_1178==true)
							{
							alert("Can not import Document 1178 for Reconciliation type Check.");
							return false;
							}
						
						if(EOS_Report==true && Sap_Report==true)
						return true;
						else if(EOS_Report==false && Sap_Report==false)
						{
						alert("Please import EOS Report and SAP Report.");
						return false;
						}
						else if(EOS_Report==true && Sap_Report==false) 
						{//alert("rrr "+Sap_Report);
						alert("Please import SAP Report.");
						return false;						
						}
						else if(EOS_Report==false && Sap_Report==true) 
						{
						alert("Please import EOS Report.");
						return false;						
						}

						//if (sWname.toUpperCase()=="PROCESSING")
						//{
							
						//}


					}


				}

				}
				catch(e)
				{}
			return true;

		}


		function SBR_Done()
		{   

			//alert("in done");
			var objwi=window.top.wi_object;
			var sWname=objwi.workstep_name.toUpperCase();
			var objDataForm= window.parent.frames["left"].document.forms["dataform"];
			//var From_Date=objDataForm.Reconciliation_Date_From.value;
			//var To_Date=objDataForm.Reconciliation_Date_To.value;

			
			
			if(!SBR_Save())
			{
			return false;
			}
						
			if(!SBR_checkmandatory_Save())
			{
			return false;

			}
		/*if (sWname.toUpperCase()=="PROCESSING")
			{
			
			var FormDate=objDataForm.Reconciliation_Date_From.value;
			ChkFutureDate(FormDate);
			
			}*/
			
			
				
				/*if(!SBR_Save_GL_Bal())
				{
				return false;
				}*/
				
				/*if(!fetchBalance('D'))
				{
				return false;

				}*/
			
			

		/*	else if(sWname.toUpperCase()=="VALIDATION" || sWname.toUpperCase()=="WNS_MGR_APPROVAL" || sWname.toUpperCase()=="SEMP_MGR_APPROVAL")
			{
				if(objDataForm.Reconciliation_type.value=="Bank Account Reconciliation")
				{
						if(!fetchBalance_Approval('D'))
							return false;

				}


			}*/
			


					
			if(!SBR_SaveAtDone())
			{

			return false;
			}
	
		return true;
		//return false;

		}

/*function Chk_Other_Adj(objDataForm)
{
	

	var Bank_Stat_Bal=objDataForm.fBank_Statement_Balance.value;
	var Bank_Stat_GL_Bal=objDataForm.fBank_Statement_GL_Balance.value;
	var Bal_Forward_Escheats=objDataForm.fBalance_Forward_Escheats.value;
	var Cur_Period_Escheats=objDataForm.fCurrent_Period_Escheats.value;

	Bank_Stat_Bal=RemoveComma_SBR(Bank_Stat_Bal);
	
	
	Bank_Stat_GL_Bal=RemoveComma_SBR(Bank_Stat_GL_Bal);
	
	Bal_Forward_Escheats=RemoveComma_SBR(Bal_Forward_Escheats);
	
	Cur_Period_Escheats=RemoveComma_SBR(Cur_Period_Escheats);
	
	var old_value=RemoveComma_SBR(objDataForm.fOther_Adjustments.value);
	var temp1=parseFloat(Bank_Stat_Bal)-parseFloat(Bank_Stat_GL_Bal);
	var temp2=parseFloat(Bal_Forward_Escheats)+parseFloat(Cur_Period_Escheats);
	var new_value=parseFloat(temp1)-parseFloat(temp2);
	if(old_value!=new_value)
	{
	alert("Mismatch in the Other Adjustment total please click on fetch again");
	return false;
	}

return true;
}*/

function Calculate_Other_Adjt()

{

	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var Bank_Stat_Bal=objDataForm.fBank_Statement_Balance.value;
	var Bank_Stat_GL_Bal=objDataForm.fBank_Statement_GL_Balance.value;
	var Bal_Forward_Escheats=objDataForm.fBalance_Forward_Escheats.value;
	var Cur_Period_Escheats=objDataForm.fCurrent_Period_Escheats.value;
	var tempOtherAdjt=objDataForm.fOther_Adjustments.value;
	//var old_value=objDataForm.fOther_Adjustments.value;
	//alert(old_value);

	/*if(objDataForm.fOther_Adjustments.value!="")
	{
	
	old_value=RemoveComma_SBR(old_value);
	}
	if(Bank_Stat_Bal=="" && Bank_Stat_GL_Bal=="" && Bal_Forward_Escheats=="" && Cur_Period_Escheats=="")
	{
	alert("Please enter Bank Statement Balance,Bank Statement GL Balance,Balance Forward Escheats,Current Period Escheats to fetch Other Adjustments.");
	objDataForm.fBank_Statement_Balance.focus();
	return false;
	}
	
	if(Bank_Stat_Bal=="")
	{
		alert("Please enter Bank Statement Balance to fetch Other Adjustments.");
		
		return false;

	}
	if(Bank_Stat_GL_Bal=="")
	{
		alert("Please enter Bank Statement GL Balance to fetch Other Adjustments.");
		objDataForm.fBank_Statement_GL_Balance.focus();
		return false;

	}
	if(Bal_Forward_Escheats=="")
	{
		alert("Please enter Balance Forward Escheats to fetch Other Adjustments.");
		objDataForm.fBalance_Forward_Escheats.focus();
		return false;

	}
	if(Cur_Period_Escheats=="")
	{
		alert("Please Current Period Escheats to fetch Other Adjustments.");
		objDataForm.fCurrent_Period_Escheats.focus();
		return false;

	}

	*/
	Bank_Stat_Bal=RemoveComma_SBR(Bank_Stat_Bal);
	Bank_Stat_GL_Bal=RemoveComma_SBR(Bank_Stat_GL_Bal);
	Bal_Forward_Escheats=RemoveComma_SBR(Bal_Forward_Escheats);
	Cur_Period_Escheats=RemoveComma_SBR(Cur_Period_Escheats);
	tempOtherAdjt=RemoveComma_SBR(tempOtherAdjt);
	
	
	
/*	var temp1=parseFloat(parseFloat(Bank_Stat_Bal)-parseFloat(Bank_Stat_GL_Bal));
	if(temp1.toString().indexOf(".")<>-1)
	{
		var temp=temp1.toString().substring(0,temp1.toString().indexOf("."));
		//alert(temp);
		//alert("Temp1:"+temp1.toPrecision(temp.length+2));
		temp1=temp1.toPrecision(temp.length+2);
	}
	var temp2=parseFloat(parseFloat(Bal_Forward_Escheats)+parseFloat(Cur_Period_Escheats));
	if(temp2.toString().indexOf(".")<>-1)
	{
		var temp5=temp2.toString().substring(0,temp2.toString().indexOf("."));
		temp2=temp2.toPrecision(temp5.length+2);
	}
	var temp3=parseFloat(parseFloat(temp1)-parseFloat(temp2));*/
//	var temp1=parseFloat(Bank_Stat_Bal)+parseFloat(Bank_Stat_GL_Bal)+parseFloat(Bal_Forward_Escheats)+parseFloat(Cur_Period_Escheats)+parseFloat(tempOtherAdjt);
	var temp1=parseFloat(Bank_Stat_Bal);
//SBR_15 Changed by Bhawna as on 19-08-08
	temp1=parseFloat(temp1)+parseFloat(Bank_Stat_GL_Bal);
		if(temp1.toString().indexOf(".")!=-1)
	{
		var temp5=temp1.toString().substring(0,temp1.toString().indexOf("."));
		temp1=temp1.toPrecision(temp5.length+2);

	}
	
	temp1=parseFloat(temp1)+parseFloat(Bal_Forward_Escheats);
	
		if(temp1.toString().indexOf(".")!=-1)
	{
		var temp5=temp1.toString().substring(0,temp1.toString().indexOf("."));
	
		temp1=temp1.toPrecision(temp5.length+2);

	}
	
	temp1=parseFloat(temp1)+parseFloat(Cur_Period_Escheats);
		if(temp1.toString().indexOf(".")!=-1)
	{
		var temp5=temp1.toString().substring(0,temp1.toString().indexOf("."));
		temp1=temp1.toPrecision(temp5.length+2);

	}

	temp1=parseFloat(temp1)+parseFloat(tempOtherAdjt);
		if(temp1.toString().indexOf(".")!=-1)
	{
		var temp5=temp1.toString().substring(0,temp1.toString().indexOf("."));
		temp1=temp1.toPrecision(temp5.length+2);

	}

/*	if(temp1.toString().indexOf(".")!=-1)
	{
		var temp5=temp1.toString().substring(0,temp1.toString().indexOf("."));
		temp1=temp1.toPrecision(temp5.length+2);

	}*/

	if(parseFloat(temp1)!=0)
		{
			//objDataForm.fOther_Adjustments.value=temp3;
			alert("Bank Statement Balance + Bank Statement GL Balance + Balance Forward Escheats + Current Period Escheats + Other Adjustment should be equal to zero.");
			objDataForm.fOther_Adjustments.focus();
			objDataForm.fOther_Adjustments.select();
			return false;
		}
		
	//SBR_15 Changed by Bhawna as on 19-08-08
	
	/*else
	{
	objDataForm.fOther_Adjustments.value=temp3; //Bug No:SBR_PR_24
	objDataForm.fOther_Adjustments.value=DollarAmount_commaNeg(objDataForm.fOther_Adjustments);//Bug No:SBR_PR_25
	}*/
	
	
return true;
	
	

}

function Calculate_Other_Adjt_new()

{

	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var Bank_Stat_Bal=objDataForm.fBank_Statement_Balance.value;
	var Bank_Stat_GL_Bal=objDataForm.fBank_Statement_GL_Balance.value;
	var Bal_Forward_Escheats=objDataForm.fBalance_Forward_Escheats.value;
	var Cur_Period_Escheats=objDataForm.fCurrent_Period_Escheats.value;
	var tempOtherAdjt=objDataForm.fOther_Adjustments.value;
	//var old_value=objDataForm.fOther_Adjustments.value;
	//alert(old_value);

	/*if(objDataForm.fOther_Adjustments.value!="")
	{
	
	old_value=RemoveComma_SBR(old_value);
	}
	if(Bank_Stat_Bal=="" && Bank_Stat_GL_Bal=="" && Bal_Forward_Escheats=="" && Cur_Period_Escheats=="")
	{
	alert("Please enter Bank Statement Balance,Bank Statement GL Balance,Balance Forward Escheats,Current Period Escheats to fetch Other Adjustments.");
	objDataForm.fBank_Statement_Balance.focus();
	return false;
	}
	
	if(Bank_Stat_Bal=="")
	{
		alert("Please enter Bank Statement Balance to fetch Other Adjustments.");
		
		return false;

	}
	if(Bank_Stat_GL_Bal=="")
	{
		alert("Please enter Bank Statement GL Balance to fetch Other Adjustments.");
		objDataForm.fBank_Statement_GL_Balance.focus();
		return false;

	}
	if(Bal_Forward_Escheats=="")
	{
		alert("Please enter Balance Forward Escheats to fetch Other Adjustments.");
		objDataForm.fBalance_Forward_Escheats.focus();
		return false;

	}
	if(Cur_Period_Escheats=="")
	{
		alert("Please Current Period Escheats to fetch Other Adjustments.");
		objDataForm.fCurrent_Period_Escheats.focus();
		return false;

	}

	*/
	Bank_Stat_Bal=RemoveComma_SBR(Bank_Stat_Bal);
	Bank_Stat_GL_Bal=RemoveComma_SBR(Bank_Stat_GL_Bal);
	Bal_Forward_Escheats=RemoveComma_SBR(Bal_Forward_Escheats);
	Cur_Period_Escheats=RemoveComma_SBR(Cur_Period_Escheats);
	tempOtherAdjt=RemoveComma_SBR(tempOtherAdjt);

	
	var temp1=parseFloat(parseFloat(Bank_Stat_Bal)+parseFloat(Bank_Stat_GL_Bal));

	if(temp1.toString().indexOf(".")!=-1)
	{
		var temp=temp1.toString().substring(0,temp1.toString().indexOf("."));
	
		temp1=temp1.toPrecision(temp.length+2);
	}

	var temp2=parseFloat(parseFloat(Bal_Forward_Escheats)+parseFloat(Cur_Period_Escheats));

	if(temp2.toString().indexOf(".")!=-1)
	{
		var temp5=temp2.toString().substring(0,temp2.toString().indexOf("."));

		temp2=temp2.toPrecision(temp5.length+2);
	}

	
	var temp3=parseFloat(parseFloat(temp1)+parseFloat(temp2));

	if(temp3.toString().indexOf(".")!=-1)
	{
		var temp6=temp3.toString().substring(0,temp3.toString().indexOf("."));

		temp3=temp3.toPrecision(temp6.length+2);
	}

	if(temp3!=tempOtherAdjt)
		{
			//objDataForm.fOther_Adjustments.value=temp3;
			alert("Other Adjustment should be equals to=(Bank Statement Balance+ Bank Statement GL Balance) + ( Balance Forward Escheats + Current Period Escheats)");
			objDataForm.fOther_Adjustments.focus();
			objDataForm.fOther_Adjustments.select();
			return false;
		}
		
	
	
	/*else
	{
	objDataForm.fOther_Adjustments.value=temp3; //Bug No:SBR_PR_24
	objDataForm.fOther_Adjustments.value=DollarAmount_commaNeg(objDataForm.fOther_Adjustments);//Bug No:SBR_PR_25
	}*/
	
	
return true;
	
	

}


function SBR_checkmandatory_Save()
{

	var objwi=window.top.wi_object;
	var sWname=objwi.workstep_name.toUpperCase();
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	if (sWname.toUpperCase()=="WORK INTRODUCTION")
			{	
				if(!SBR_Work_Intro_checkmandatory_Save(objDataForm))
				{
				
				return false;
				}
			}
	if (sWname.toUpperCase()=="PROCESSING")
			{	
				if(!SBR_Processing_checkmandatory_Save(objDataForm))
				{

				return false;
				}
				if(objDataForm.Reconciliation_type.value=="Bank Account Reconciliation")
						{
						if(!Calculate_Other_Adjt())
						{
						return false;
						}
						}
				else if(objDataForm.Reconciliation_type.value=="Check Reconciliation")
				{
					if(!Cal_Adjustments())
					{
						return false;		
					}
				}
				if(!SBR_checkmandatory_doctype())
				{
				return false;
				}
				
				if(!Check_Mandatory_Doctype())
				{
				return false;
				
				}
			}
	if (sWname.toUpperCase()=="VALIDATION")
			{	
				if(!SBR_Validation_checkmandatory_Save(objDataForm))
				{

				return false;
				}
			}

	if (sWname.toUpperCase()=="WNS_MGR_APPROVAL")
			{	
				if(!SBR_Approval_checkmandatory_Save(objDataForm))
				{

				return false;
				}
			}
	if (sWname.toUpperCase()=="SEMP_MGR_APPROVAL")
			{	
				if(!SBR_Semp_Approval_checkmandatory_Save(objDataForm))
				{

				return false;
				}
			}
				
return true;


}


/*function SBR_checkmandatory_Processing_doctype()
{
try
			{
				var objDataForm= window.parent.frames["left"].document.forms["dataform"];
				var Doc_1178=false;
				var length=window.parent.frames['right'].document.frames['doctypes_center'].document.forms["textForm"].doctype.length;
				if(length!=" ")
				{	

					var objDocType=window.parent.frames['right'].document.frames['doctypes_center'].document.forms["textForm"].doctype;
					for(var i=0 ; i<objDocType.length ;i++)
					{ 

						var doctype=objDocType.options[i].outerText;


						if(objDataForm.Reconciliation_type.value=="Bank Account Reconciliation")
						{
							if(doctype.substring(0,8)=="Doc_1178")
							{ 
							Doc_1178=true;

							}
						}
						

					}
					if(objDataForm.Reconciliation_type.value=="Bank Account Reconciliation")
						{
					if(Doc_1178!=true)
						{
						alert("Please import Document 1178.");
						return false;
						}
						}
				}

			}catch(e)
				{}



return true;
}*/



function SBR_Work_Intro_checkmandatory_Save(objDataForm)
	{
				
				
				if(objDataForm.Reconciliation_type.value=="" )
					{
						alert("Select the Reconciliation type.");
						objDataForm.Reconciliation_type.focus();
						return false;
					}
					if(objDataForm.Reconciliation_Date_From.value=="" )
					{
						alert("Reconciliation Date From can not be blank.");
						objDataForm.Reconciliation_Date_From.select();
						window.parent.frames["left"].document.getElementById("Reconciliation_Date_From_IMG").focus();
						//objDataForm.Invoice_Date.focus();
						return false;
					}
						if(!ChkFutureDate(objDataForm.Reconciliation_Date_From,"Reconciliation Date From"))
							return false;
					if(objDataForm.Reconciliation_Date_To.value=="" )
					{
						alert("Reconciliation Date To can not be blank.");
						objDataForm.Reconciliation_Date_To.select();
						window.parent.frames["left"].document.getElementById("Reconciliation_Date_To_IMG").focus();
						//objDataForm.Invoice_Date.focus();
						return false;
					}

					
							if(!ChkFutureDate(objDataForm.Reconciliation_Date_To,"Reconciliation Date To"))
							return false;
						
						
						//var Reconciliation_Date_To=objDataForm.Reconciliation_Date_To.value;
						//var Reconciliation_Date_From=objDataForm.Reconciliation_Date_From.value;
						if(!(DateComparator(objDataForm.Reconciliation_Date_To,objDataForm.Reconciliation_Date_From)))
						{
							return false;
						}
															
						
	return true;
	
	
	}

function SBR_Processing_checkmandatory_Save(objDataForm)

	{
				
				
				
				if(objDataForm.Reconciliation_type.value=="" )
					{
						alert("Select Reconciliation type.");
						objDataForm.Reconciliation_type.focus();
						return false;
					}
					if(objDataForm.Reconciliation_Date_From.value=="" )
					{
						alert("Enter the Reconciliation_Date_From.");
						objDataForm.Reconciliation_Date_From.select();
						window.parent.frames["left"].document.getElementById("Reconciliation_Date_From_IMG").focus();
						//objDataForm.Invoice_Date.focus();
						return false;
					}
						
						if(!ChkFutureDate(objDataForm.Reconciliation_Date_From,"Reconciliation Date From"))
							return false;
						if(objDataForm.Reconciliation_Date_To.value=="" )
					{
						alert("Reconciliation Date To can not be blank.");
						objDataForm.Reconciliation_Date_To.select();
						window.parent.frames["left"].document.getElementById("Reconciliation_Date_To_IMG").focus();
						//objDataForm.Invoice_Date.focus();
						return false;
					}
							if(!ChkFutureDate(objDataForm.Reconciliation_Date_To,"Reconciliation Date To"))
							return false;
						//var Reconciliation_Date_To=objDataForm.Reconciliation_Date_To.value;
						//var Reconciliation_Date_From=objDataForm.Reconciliation_Date_From.value;	
						if(!(DateComparator(objDataForm.Reconciliation_Date_To,objDataForm.Reconciliation_Date_From)))
						{
							return false;
						}
					
					
					
					if(objDataForm.Bank_Account_Number.value=="" )
					{
						alert("Bank Account Number can not be blank.");
						objDataForm.Bank_Account_Number.focus();
						return false;
					}
					if(objDataForm.fBank_Statement_Balance.value=="" && objDataForm.Reconciliation_type.value=="Bank Account Reconciliation")
					{
						alert("Bank Statement Balance can not be blank.");
						objDataForm.fBank_Statement_Balance.focus();
						return false;
					}
	
					if(objDataForm.fBank_Statement_GL_Balance.value=="")
					{
						alert("Bank Statement GL Balance can not be blank.");
						objDataForm.fBank_Statement_GL_Balance.focus();
						return false;
					}
					if(objDataForm.fBalance_Forward_Escheats.value=="" && objDataForm.Reconciliation_type.value=="Bank Account Reconciliation" )
					{
						alert("Forward Escheats can not be blank."); 
						objDataForm.fBalance_Forward_Escheats.focus();
						return false;
					}
					if(objDataForm.fCurrent_Period_Escheats.value=="" && objDataForm.Reconciliation_type.value=="Bank Account Reconciliation" )
					{
						alert("Current Period Escheats can not be blank.");
						objDataForm.fCurrent_Period_Escheats.focus();
						return false;
					}
					if(objDataForm.fOther_Adjustments.value=="" && objDataForm.Reconciliation_type.value=="Bank Account Reconciliation" )
					{
						alert("Other Adjustments can not be blank.");
						objDataForm.fOther_Adjustments.focus();
						return false;
					}
					//Removed by Tarit gupta as on 07-07-08
					/*if(objDataForm.fTotal_Check_GL_Balance.value=="" && objDataForm.Reconciliation_type.value=="Bank Account Reconciliation" )
					{
						alert("Please fetch Total Check GL Balance for selected period.");
						objDataForm.fTotal_Check_GL_Balance.focus();
						return false;
					}*/
					//Removed by Tarit gupta as on 07-07-08
					if(objDataForm.fCheck_Outstanding.value=="" && objDataForm.Reconciliation_type.value=="Check Reconciliation" )
					{
						alert("Check Outstanding can not be blank.");
						objDataForm.fCheck_Outstanding.focus();
						return false;
					}
					if(objDataForm.fEscheat_Total.value=="" && objDataForm.Reconciliation_type.value=="Check Reconciliation" )
					{
						alert("Escheat Total can not be blank.");
						objDataForm.fEscheat_Total.focus();
						return false;
					}
					if(objDataForm.fAdjustments.value=="" && objDataForm.Reconciliation_type.value=="Check Reconciliation" )
					{
						alert("Adjustments can not be blank.");
						objDataForm.fAdjustments.focus();
						return false;
					}
					/*if(objDataForm.fCheck_GL_Balance.value=="" && objDataForm.Reconciliation_type.value=="Check Reconciliation" )
					{
						alert("Check GL Balance can not be blank.");
						objDataForm.fCheck_GL_Balance.focus();
						return false;
					}*/

					
						
			return true;
	}

function SBR_Validation_checkmandatory_Save(objDataForm)
{
				if(objDataForm.Validation.value=="" )
					{
						alert("Select the Validation.");
						objDataForm.Validation.focus();
						return false;
					}
				if(objDataForm.Validation_Comments.value=="" && objDataForm.Validation.value=="Fail" )
					{
						alert("Validation Comments can not be blank.");
						objDataForm.Validation_Comments.focus();
						return false;
					}


return true;
}

function SBR_Approval_checkmandatory_Save(objDataForm)
{

			if(objDataForm.WNS_Approval.value=="" )//Bug No:SBR_AP_22
					{
						alert("Select the Approval.");
						objDataForm.WNS_Approval.focus();
						return false;
					}
				if(objDataForm.WNS_Approval_Comments.value=="" && objDataForm.WNS_Approval.value=="Reject" )
					{
						alert("Approval Comments can not be blank.");
						objDataForm.WNS_Approval_Comments.focus();
						return false;
					}
			return true;

}
function SBR_Semp_Approval_checkmandatory_Save(objDataForm)
{

			if(objDataForm.Semp_Approval.value=="" )//Bug No:SBR_AP_22
					{
						alert("Select the Approval.");
						objDataForm.Semp_Approval.focus();
						return false;
					}
				if(objDataForm.Semp_Approval_Comments.value=="" && objDataForm.Semp_Approval.value=="Reject" )
					{
						alert("Approval Comments can not be blank.");
						objDataForm.Semp_Approval_Comments.focus();
						return false;
					}
			return true;

}


		



/*function SBR_Save_GL_Bal()
{

	
	var sWname=window.top.wi_object.workstep_name.toUpperCase();
	var objwi=window.top.wi_object;
	var Wi_Name=objwi.attribute_list["WorkItemName"].value;
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var From_Date=objDataForm.Reconciliation_Date_From.value;
	var To_Date=objDataForm.Reconciliation_Date_To.value;
	var GL_Bal=objDataForm.fCheck_GL_Balance.value;
	GL_Bal=RemoveComma_SBR(GL_Bal);
	
	if(sWname.toUpperCase()=="PROCESSING")

	{

		if(objDataForm.Reconciliation_type.value=="Check Reconciliation")
		{
			ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\SBR\\SBR_Save_GL_Bal.jsp","&sFrom_Date="+encodeURIComponent(From_Date)+"&sTo_Date="+encodeURIComponent(To_Date)+"&sGL_Bal="+encodeURIComponent(GL_Bal)+"&Wi_Name="+encodeURIComponent(Wi_Name));
			//alert(iAjaxMainCode);
			if (iAjaxMainCode=="15")
			{
			alert('Error in updating GL Balance .');
			return false;
			}
			else if (sAjaxReturnValue!="Success")
			{
			alert('Error in updating GL Balance .');
			return false;
			}
		}
		
	}
return true;

}*/
//Removed by Tarit gupta as on 07-07-08
/*function fetchBalance(sMode)
{
	//alert(sMode);
	
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var sWname=window.top.wi_object.workstep_name.toUpperCase();
	var From_Date=objDataForm.Reconciliation_Date_From.value;
	var To_Date=objDataForm.Reconciliation_Date_To.value;
	var OldGLBal=objDataForm.fTotal_Check_GL_Balance.value;
	OldGLBal=RemoveComma_SBR(OldGLBal);

	if(sWname.toUpperCase()=="PROCESSING")
	{
		if(objDataForm.Reconciliation_type.value=="Bank Account Reconciliation")
		{
			ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\SBR\\SBR_fetch_GL_Bal.jsp","&sFrom_Date="+encodeURIComponent(From_Date)+"&sTo_Date="+encodeURIComponent(To_Date));
			if (iAjaxMainCode=="15")
			{
			alert('Error in fetching Total Check GL Balance.');
			return false;
			}
			else if (iAjaxMainCode!="0")
			{
			alert('Error in fetching Total Check GL Balance.');
			return false;
			}


			if(sAjaxReturnValue!="")
			{
				var values=sAjaxReturnValue.split('^');
				//alert(sAjaxReturnValue);
				//alert(values[0]);
				//alert(values[1]);
				//alert(values[2]);
				var NewGlBal=values[0];

				if(From_Date!=trim(values[1]) || To_Date!=trim(values[2]))
				{
				alert("Mismatch in seleted period for Total Check GL Balance.Please select correct period to fetch.");
				objDataForm.fTotal_Check_GL_Balance.value="";
				return false;
				}
				else if(sMode=='D') 
				{
					if(OldGLBal!="")
					{
					if(OldGLBal!=NewGlBal)
					{

					alert("Mismatch in seleted period and fetched Total Check GL Balance.Please select correct period to fetch for Total Check GL Balance.");
					return false;
					}
					}
				}
				else
				{
				objDataForm.fTotal_Check_GL_Balance.value=trim(values[0]);
				objDataForm.fTotal_Check_GL_Balance.value=DollarAmount_commaNeg(objDataForm.fTotal_Check_GL_Balance);
				}
			}
			else
			{
			alert("Mismatch in seleted period for Total Check GL Balance.Please select correct period to fetch.");
			return false;

			}
		}


	}

	return true;
	
}
function fetchBalance_Approval(sMode)
{
	//alert(sMode);
	
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var sWname=window.top.wi_object.workstep_name.toUpperCase();
	var From_Date=objDataForm.Reconciliation_Date_From.value;
	var To_Date=objDataForm.Reconciliation_Date_To.value;
	var OldGLBal=objDataForm.fTotal_Check_GL_Balance.value;
	OldGLBal=RemoveComma_SBR(OldGLBal);
	var Confirm;

	//if(sWname.toUpperCase()=="PROCESSING")
	//{
	//	if(objDataForm.Reconciliation_type.value=="Bank Account Reconciliation")
	//	{
			ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\SBR\\SBR_fetch_GL_Bal.jsp","&sFrom_Date="+encodeURIComponent(From_Date)+"&sTo_Date="+encodeURIComponent(To_Date));
			if (iAjaxMainCode=="15")
			{
			alert('Internal server error.Please try again later.');
			return false;
			}
			else if (iAjaxMainCode!="0")
			{
			alert('Internal server error.Please try again later.');
			return false;
			}


			if(sAjaxReturnValue!="")
			{
				var values=sAjaxReturnValue.split('^');
				//alert(sAjaxReturnValue);
				//alert(values[0]);
				//alert(values[1]);
				//alert(values[2]);
				var NewGlBal=values[0];

				if(From_Date!=trim(values[1]) || To_Date!=trim(values[2]))
				{
					
					Confirm = confirm("Mismatch in Total Check GL Balance.Do you want to proceed?(Y/N)");
					if(!Confirm)
						{
						return false;
						}
					//objDataForm.fTotal_Check_GL_Balance.value="";
					
				}
				else if(sMode=='D') 
				{
					if(OldGLBal!="")
					{
					if(OldGLBal!=NewGlBal)
					{
					
					Confirm = confirm("Mismatch in Total Check GL Balance.Do you want to proceed?(Y/N)");
					if(!Confirm)
						{
						return false;
						}
					
					}
					}
				}
				
			}
			else
			{
			Confirm = confirm("Mismatch in Total Check GL Balance.Do you want to proceed?(Y/N)");
					if(!Confirm)
						{
						return false;
						}

			}
		//}


	//}

	return true;
	
}

*/
//Removed by Tarit gupta as on 07-07-08

	function isModified(oldVal,newVal)
	{
	
	 if(oldVal.value!=newVal)
	 {
	  oldVal.value=newVal;
	  
	  oldVal.modified_flag=true;
	 }
	}


	function SBR_SaveAtDone()
	{
		var sWname=window.top.wi_object.workstep_name.toUpperCase();
		var objwi=window.top.wi_object;
		var objDataForm= window.parent.frames["left"].document.forms["dataform"];
		var sWiName=objwi.attribute_list["WorkItemName"].value;
		var sSplitVal=sWiName.split('-');
		var iWINo=parseFloat(sSplitVal[1]);
		var sPreviousWorkStep="";


		ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\SBR\\SBR_Done_Data.jsp","sWiName="+encodeURIComponent(sWiName)+"&sENTRYDATETIME="+window.top.wi_object.attribute_list["EntryDateTime"].value+"&sCurrentWorkStep="+sWname);
		//alert(iAjaxMainCode);
		if (iAjaxMainCode=="15")
		{
		alert('Error in updating SBR Done .');
		return false;
		}
		else if (sAjaxReturnValue!="Success")
		{
		alert('Error in updating SBR Done .');
		return false;
		}
		return true;

	}


		function Save_Comma_Amt()
		{
			
			var sWname=window.top.wi_object.workstep_name.toUpperCase();
			var objwi=window.top.wi_object;
			var objDataForm= window.parent.frames["left"].document.forms["dataform"];
			if(sWname.toUpperCase()=="PROCESSING")
			{
				
				if(objDataForm.fBank_Statement_Balance.value!="" )
				{
					
				var temp=objDataForm.fBank_Statement_Balance.value;
				var temp1=RemoveComma_SBR(temp);
				isModified(objwi.attribute_list['Bank_Statement_Balance'],temp1);
				}
				else
				{
				isModified(objwi.attribute_list['Bank_Statement_Balance'],"");//Bug No:SBR_PR_23
				}

				if(objDataForm.fBank_Statement_GL_Balance.value!="" )
				{
				var temp=objDataForm.fBank_Statement_GL_Balance.value;
				var temp1=RemoveComma_SBR(temp);
				isModified(objwi.attribute_list['Bank_Statement_GL_Balance'],temp1);

				}
				else
				{

				isModified(objwi.attribute_list['Bank_Statement_GL_Balance'],"");//Bug No:SBR_PR_23
				}

				if(objDataForm.fBalance_Forward_Escheats.value!="" )
				{
				var temp=objDataForm.fBalance_Forward_Escheats.value;
				var temp1=RemoveComma_SBR(temp);
				isModified(objwi.attribute_list['Balance_Forward_Escheats'],temp1);

				}
				else
				{

				isModified(objwi.attribute_list['Balance_Forward_Escheats'],"");//Bug No:SBR_PR_23
				}

				if(objDataForm.fCurrent_Period_Escheats.value!="" )
				{
				var temp=objDataForm.fCurrent_Period_Escheats.value;
				var temp1=RemoveComma_SBR(temp);
				isModified(objwi.attribute_list['Current_Period_Escheats'],temp1);
				}
				else
				{

				isModified(objwi.attribute_list['Current_Period_Escheats'],"");//Bug No:SBR_PR_23
				}

				if(objDataForm.fOther_Adjustments.value!="" )
				{
				var temp=objDataForm.fOther_Adjustments.value;
				var temp1=RemoveComma_SBR(temp);
				isModified(objwi.attribute_list['Other_Adjustments'],temp1);

				}
				else
				{

				isModified(objwi.attribute_list['Other_Adjustments'],"");//Bug No:SBR_PR_23
				}

				//Removed as on 07-07-08 by tarit gupta
				/*if(objDataForm.fTotal_Check_GL_Balance.value!="" )
				{
				var temp=objDataForm.fTotal_Check_GL_Balance.value;
				var temp1=RemoveComma_SBR(temp);
				isModified(objwi.attribute_list['Total_Check_GL_Balance'],temp1);
				}
				else
				{
				isModified(objwi.attribute_list['Total_Check_GL_Balance'],"");//Bug No:SBR_PR_23
				}*/
				//Removed as on 07-07-08 by tarit gupta
				if(objDataForm.fCheck_Outstanding.value!="" )
				{
				var temp=objDataForm.fCheck_Outstanding.value;
				var temp1=RemoveComma_SBR(temp);
				isModified(objwi.attribute_list['Check_Outstanding'],temp1);
				}
				else
				{
				isModified(objwi.attribute_list['Check_Outstanding'],"");//Bug No:SBR_PR_23
				}

				if(objDataForm.fEscheat_Total.value!="" )
				{
				var temp=objDataForm.fEscheat_Total.value;
				var temp1=RemoveComma_SBR(temp);
				isModified(objwi.attribute_list['Escheat_Total'],temp1);
				}
				else
				{
				isModified(objwi.attribute_list['Escheat_Total'],"");//Bug No:SBR_PR_23
				}

				if(objDataForm.fAdjustments.value!="" )
				{
				var temp=objDataForm.fAdjustments.value;
				var temp1=RemoveComma_SBR(temp);
				isModified(objwi.attribute_list['Adjustments'],temp1);
				}
				else
				{
				isModified(objwi.attribute_list['Adjustments'],"");//Bug No:SBR_PR_23
				}

				/*if(objDataForm.fCheck_GL_Balance.value!="" )
				{
				var temp=objDataForm.fCheck_GL_Balance.value;
				var temp1=RemoveComma_SBR(temp);
				isModified(objwi.attribute_list['Check_GL_Balance'],temp1);
				}
				else
				{
				isModified(objwi.attribute_list['Check_GL_Balance'],"");//Bug No:SBR_PR_23
				}*/

			}		

		return true;
		}

//Added for SBR_1 by Tarit Gupta
function DateComparator(Reconciliation_Date_To,Reconciliation_Date_From)
{	//alert("DateComparator function");
	var Date_To=Reconciliation_Date_To.value;
	var Date_From=Reconciliation_Date_From.value;
	
	var Date_To_month=Number(Date_To.substring(Date_To.indexOf("0"),Date_To.indexOf("/")));	
	var Date_From_month=Number(Date_From.substring(Date_From.indexOf("0"),Date_From.indexOf("/")));
	
	var Date_To_date=Number(Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/")));
	var Date_From_date=Number(Date_From.substring(Date_From.indexOf("/")+1,Date_From.lastIndexOf("/")));
	
	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));
	var Date_From_year=Number(Date_From.substring(Date_From.lastIndexOf("/")+1,Date_From.length));
	

	if(Date_To_year<Date_From_year)
	{
		alert("To Reconcillation Date can not be less than From Reconcillation Date.");
		Reconciliation_Date_To.select();
		window.parent.frames["left"].document.getElementById("Reconciliation_Date_To_IMG").focus();
		return false;
	}
	else if(Date_To_year>=Date_From_year)
	{
		if(Date_From_month>Date_To_month)
		{
			alert("To Reconcillation Date can not be less than From Reconcillation Date.");
		Reconciliation_Date_To.select();
		window.parent.frames["left"].document.getElementById("Reconciliation_Date_To_IMG").focus();
		return false;
		}
		else if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{
				alert("To Reconcillation Date can not be less than From Reconcillation Date.");
		Reconciliation_Date_To.select();
		window.parent.frames["left"].document.getElementById("Reconciliation_Date_To_IMG").focus();
		return false;
			}
		}
	}
return true;
}


function Cal_Adjustments_old()
{

	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var fBank_Statement_GL_Balance=objDataForm.fBank_Statement_GL_Balance.value;
	var fCheck_Outstanding=objDataForm.fCheck_Outstanding.value;
	var tempAdjustments=objDataForm.fAdjustments.value;

	fBank_Statement_GL_Balance=RemoveComma_SBR(fBank_Statement_GL_Balance);
	fCheck_Outstanding=RemoveComma_SBR(fCheck_Outstanding);
	tempAdjustments=RemoveComma_SBR(tempAdjustments);
	
	
	var temp=parseFloat(fBank_Statement_GL_Balance)-parseFloat(fCheck_Outstanding);
	if(tempAdjustments!=temp)
	{
	alert("Adjustment should be equals to : Bank Statement GL Balance- Check Outstanding.");
	objDataForm.fAdjustments.focus();
	objDataForm.fAdjustments.select();
	return false;
	}
	
	return true;	

}

function Cal_Adjustments()
{

	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var fBank_Statement_GL_Balance=objDataForm.fBank_Statement_GL_Balance.value;
	var fCheck_Outstanding=objDataForm.fCheck_Outstanding.value;
	var tempAdjustments=objDataForm.fAdjustments.value;

	fBank_Statement_GL_Balance=RemoveComma_SBR(fBank_Statement_GL_Balance);
	fCheck_Outstanding=RemoveComma_SBR(fCheck_Outstanding);
	tempAdjustments=RemoveComma_SBR(tempAdjustments);
	
	
	var temp1=parseFloat(fBank_Statement_GL_Balance)-parseFloat(fCheck_Outstanding);
	//SBR_16 Changed by Tarit as on 22-08-08
	//	alert(" befor fixed temp1"+temp1);
	//SBR_17 Changed by Bhawna as on 26-08-08
	
	temp1=temp1.toFixed(2);

	/*if(temp1.toString().indexOf(".")!=-1)
	{
		if(temp1.toString().charAt(0)=="-")
		{
		var temp2=temp1.toString().substring(1,temp1.toString().indexOf("."));
		}
		else
		{
			var temp2=temp1.toString().substring(0,temp1.toString().indexOf("."));

		}
	alert("before temp2"+temp2);
		if(temp2=="0")
		{
			alert("inside if"+temp2.length);
			temp1=temp1.toPrecision(temp2.length+1);
		}
		else
		{
			alert("inside else");
			temp1=temp1.toPrecision(temp2.length+2);
		}

	}*/
	//SBR_16 Changed by Tarit as on 22-08-08

	//alert("eval"+eval(temp1));
//	alert(temp1+"tempAdjustments:"+tempAdjustments);
//	alert("parseFloat"+parseFloat(temp1));
	if(tempAdjustments!=temp1)
	{
	alert("Adjustment should be equals to : Bank Statement GL Balance- Check Outstanding.");
	objDataForm.fAdjustments.focus();
	objDataForm.fAdjustments.select();
	return false;
	}

	return true;	
	
	

}
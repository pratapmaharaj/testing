/* 
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-GMAC
Module : GMAC-SBR
File Name : Semperian_client.js
Author :   Tarit Gupta
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date			Change By		Change Description (Bug No. (If Any))
(DD/MM/YYYY)

27/10/2008		Santul Sharma	NAO_11
27/10/2008		Santul Sharma	NAO_12
---------------------------------------------------------------------------------------------------
*/
var sExcpName=[];
var sSubject=[];
var sBodyText=[];
	
function load()
{	
	
	
	var objwi=window.top.wi_object;
    var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
	var sWname=objwi.workstep_name.toUpperCase();
	var sPreviousWorkStep=window.top.wi_object.attribute_list["Previous_Wrk_Step"].value;
			
			if (sWname.toUpperCase()=="WORK INTRODUCTION")
				{	
					
				
							
					if(objDataForm.Document_Type.type=='select-one')
					{
					FillDocTypesCombo();
					}
					if(objwi.attribute_list["Document_Type"].value!="")
						{
						
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;
							
						}

					 if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						}
						
				}



  

			if (sWname.toUpperCase()=="INDEXING")
				{	
						
					
					if(objDataForm.Document_Type.type=='select-one')
					{
					FillDocTypesCombo();
					}
					
					if(objwi.attribute_list["Document_Type"].value!="")
						{
						
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;
							
						}

					if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
					
					
						if(objwi.attribute_list["CompanyName"].value!="" )
						{

						objDataForm.CompanyName.value=objwi.attribute_list["CompanyName"].value;

						}
						if(objwi.attribute_list["CompanyCode"].value!="" )
						{

						objDataForm.CompanyCode.value=objwi.attribute_list["CompanyCode"].value;

						}
						
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma_SBR(objwi.attribute_list["Amount"]);
						

						}
						
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						
						if(objwi.attribute_list["Priority"].value!="" )
						{
						
						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						if(objwi.attribute_list["Intro_Type"].value=="BH" && objwi.attribute_list["Priority"].value=="Urgent")
							objDataForm.Priority.disabled=true;

						}
						/*if (sPreviousWorkStep.toUpperCase()!="WORK INTRODUCTION")
						{	

							if(objwi.attribute_list["Processor_EmailId"].value!="" )
							{

							objDataForm.Processor_EmailId.value=objwi.attribute_list["Processor_EmailId"].value;

							}
						}*/

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}
						if(objwi.attribute_list["Split_Resolution_Comments"].value!="" )
						{

						objDataForm.Split_Resolution_Comments.value=objwi.attribute_list["Split_Resolution_Comments"].value;

						}
						if(objwi.attribute_list["No_Of_WI_Created"].value!="" )
						{

						objDataForm.No_Of_WI_Created.value=objwi.attribute_list["No_Of_WI_Created"].value;

						}
						if(objwi.attribute_list["WI_Serial_Number"].value!="" )
						{

						objDataForm.WI_Serial_Number.value=objwi.attribute_list["WI_Serial_Number"].value;

						}
						if(objwi.attribute_list["Cancel_Decision_Comments"].value!="" )
						{

						objDataForm.Cancel_Decision_Comments.value=objwi.attribute_list["Cancel_Decision_Comments"].value;

						}

						//	alert("bhawna2222");
						if(objwi.attribute_list["AllToEmailIds"].value!="" )
						{

						objDataForm.AllToEmailIds.value=objwi.attribute_list["AllToEmailIds"].value;

						}
						if(objwi.attribute_list["AllCCEmailIds"].value!="" )
						{

						objDataForm.AllCCEmailIds.value=objwi.attribute_list["AllCCEmailIds"].value;

						}
						if(objwi.attribute_list["SubjectLine"].value!="" )
						{

						objDataForm.SubjectLine.value=objwi.attribute_list["SubjectLine"].value;

						}
						if(objwi.attribute_list["BodyText"].value!="" )
						{

						objDataForm.BodyText.value=objwi.attribute_list["BodyText"].value;

						}
						
						loadFormEmailids(objDataForm,objwi);
						if(!loadcheckboxes())
						{
							return false;
						}
						
						LoadForExcpEmail();
					
				}




			if (sWname.toUpperCase()=="PROCESSING")
				{	
						
					if(objDataForm.Document_Type.type=='select-one')
					{
					FillDocTypesCombo();
					}
					
					if(objwi.attribute_list["Document_Type"].value!="")
						{
						
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;
							
						}

					if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
					
						if(objwi.attribute_list["CompanyName"].value!="" )
						{

						objDataForm.CompanyName.value=objwi.attribute_list["CompanyName"].value;

						}
						if(objwi.attribute_list["CompanyCode"].value!="" )
						{

						objDataForm.CompanyCode.value=objwi.attribute_list["CompanyCode"].value;

						}
						
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma_SBR(objwi.attribute_list["Amount"]);
						

						}
						
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;
						if(objwi.attribute_list["Intro_Type"].value=="BH" && objwi.attribute_list["Priority"].value=="Urgent")
							objDataForm.Priority.disabled=true;


						}
						
						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						if(objwi.attribute_list["SAP_Document_Number"].value!="" )
						{

						objDataForm.SAP_Document_Number.value=objwi.attribute_list["SAP_Document_Number"].value;

						}
						if(objwi.attribute_list["Validation_Comments"].value!="" )
						{

						objDataForm.Validation_Comments.value=objwi.attribute_list["Validation_Comments"].value;

						}

					/*if (sPreviousWorkStep.toUpperCase()!="INDEXING")
						{	
							
							if(objwi.attribute_list["Processor_EmailId"].value!="" )
							{

							objDataForm.Processor_EmailId.value=objwi.attribute_list["Processor_EmailId"].value;

							}
						}*/

						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}
						if(objwi.attribute_list["Split_Resolution_Comments"].value!="" )
						{

						objDataForm.Split_Resolution_Comments.value=objwi.attribute_list["Split_Resolution_Comments"].value;

						}
						if(objwi.attribute_list["No_Of_WI_Created"].value!="" )
						{

						objDataForm.No_Of_WI_Created.value=objwi.attribute_list["No_Of_WI_Created"].value;

						}
						if(objwi.attribute_list["WI_Serial_Number"].value!="" )
						{

						objDataForm.WI_Serial_Number.value=objwi.attribute_list["WI_Serial_Number"].value;

						}
						if(objwi.attribute_list["Cancel_Decision_Comments"].value!="" )
						{

						objDataForm.Cancel_Decision_Comments.value=objwi.attribute_list["Cancel_Decision_Comments"].value;

						}
						
						if(objwi.attribute_list["AllToEmailIds"].value!="" )
						{

						objDataForm.AllToEmailIds.value=objwi.attribute_list["AllToEmailIds"].value;

						}
						if(objwi.attribute_list["AllCCEmailIds"].value!="" )
						{

						objDataForm.AllCCEmailIds.value=objwi.attribute_list["AllCCEmailIds"].value;

						}
						if(objwi.attribute_list["SubjectLine"].value!="" )
						{

						objDataForm.SubjectLine.value=objwi.attribute_list["SubjectLine"].value;

						}
						if(objwi.attribute_list["BodyText"].value!="" )
						{

						objDataForm.BodyText.value=objwi.attribute_list["BodyText"].value;

						}
						
						loadFormEmailids(objDataForm,objwi);
						if(!loadcheckboxes())
						{
							return false;
						}
						
						LoadForExcpEmail();
				}

			if (sWname.toUpperCase()=="RESCAN_WI")
				{	
						
						
						
						if(objwi.attribute_list["Document_Type"].value!="")
						{
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;

						}
											
						if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
						
						if(objwi.attribute_list["CompanyName"].value!="" )
						{

						objDataForm.CompanyName.value=objwi.attribute_list["CompanyName"].value;

						}
						if(objwi.attribute_list["CompanyCode"].value!="" )
						{

						objDataForm.CompanyCode.value=objwi.attribute_list["CompanyCode"].value;

						}
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma(objwi.attribute_list["Amount"]);
						

						}
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						}

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						if(objwi.attribute_list["SAP_Document_Number"].value!="" )
						{

						objDataForm.SAP_Document_Number.value=objwi.attribute_list["SAP_Document_Number"].value;

						}
						if(objwi.attribute_list["Processor_EmailId"].value!="" )
						{

						objDataForm.Processor_EmailId.value=objwi.attribute_list["Processor_EmailId"].value;
						
						}

						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}
					
						makeDateButtonDisb();
						if(!loadcheckboxes())
							{
								return false;
							}
							if(!loadClrCheckboxes())
							
							{
								return false;
							}

							for (var i=0;i<objDataForm.elements.length ;i++ )
								{
									if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
										{

										disablecheckbox(objDataForm.elements[i].name);
										
										}
								}

				}
	


				
					if (sWname.toUpperCase()=="PENDING_RESOLUTION")
				{	
					
						
						if(objwi.attribute_list["Document_Type"].value!="")
						{
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;

						}
												
						if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
						
						if(objwi.attribute_list["CompanyName"].value!="" )
						{

						objDataForm.CompanyName.value=objwi.attribute_list["CompanyName"].value;

						}
						if(objwi.attribute_list["CompanyCode"].value!="" )
						{

						objDataForm.CompanyCode.value=objwi.attribute_list["CompanyCode"].value;

						}
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma(objwi.attribute_list["Amount"]);
						

						}
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						}

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						if(objwi.attribute_list["SAP_Document_Number"].value!="" )
						{

						objDataForm.SAP_Document_Number.value=objwi.attribute_list["SAP_Document_Number"].value;

						}
						if(objwi.attribute_list["Processor_EmailId"].value!="" )
						{

						objDataForm.Processor_EmailId.value=objwi.attribute_list["Processor_EmailId"].value;
						
						}
						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}
						if(objwi.attribute_list["Forward_To"].value!="" )
						{

						objDataForm.Forward_To.value=objwi.attribute_list["Forward_To"].value;

						}
						
						if(objwi.attribute_list["FollowUpDate"].value!="" )
						{
								var retdate=convertdatenew(objwi.attribute_list['FollowUpDate'].value);
								objDataForm.FollowUpDate.value=retdate;
								
						
						}
						
						if(objwi.attribute_list["FollowUpReqd"].value!="" )
						{

						objDataForm.FollowUpReqd.value=objwi.attribute_list["FollowUpReqd"].value;
						
						}
						//chkFollowupReq(objDataForm.FollowUpReqd);
						
						if(objwi.attribute_list["FollowUpType"].value!="" )
						{

						objDataForm.FollowUpType.value=objwi.attribute_list["FollowUpType"].value;

						}
						if(objwi.attribute_list["AllToEmailIds"].value!="" )
						{

						objDataForm.AllToEmailIds.value=objwi.attribute_list["AllToEmailIds"].value;

						}
						if(objwi.attribute_list["AllCCEmailIds"].value!="" )
						{

						objDataForm.AllCCEmailIds.value=objwi.attribute_list["AllCCEmailIds"].value;

						}
						if(objwi.attribute_list["SubjectLine"].value!="" )
						{

						objDataForm.SubjectLine.value=objwi.attribute_list["SubjectLine"].value;

						}
						if(objwi.attribute_list["BodyText"].value!="" )
						{

						objDataForm.BodyText.value=objwi.attribute_list["BodyText"].value;

						}
						
						
						
						
						
						loadFormEmailids(objDataForm,objwi);
						
						
						
						
						if(!loadcheckboxes())
							{
								return false;
							}
						
						LoadForExcpEmail();
						
						
						
						if(objDataForm.FollowUpReqd.value!="Yes")
							{
							if(!loadClrCheckboxes())
								
								{
									return false;
								}
							
							}
						else
						{
							populate_Mails_Fields();
						}
						//for New Vendor Setup Exception
						if(objDataForm.chkExcp_New_Vendor_Setup.checked==true && objDataForm.chkExcp_Missing_Incorrect_Approval.checked==false && objDataForm.chkExcp_Missing_PO.checked==false && objDataForm.chkExcp_Incorrect_Coding.checked==false && objDataForm.chkExcp_Cost_Quality_Variance.checked==false && objDataForm.chkExcp_Goods_Recpt_Varification.checked==false && objDataForm.chkExcp_Miscellaneous.checked==false)
							{
								objDataForm.FollowUpReqd.value="";
								objDataForm.FollowUpReqd.disabled=true;
								objDataForm.FollowUpReqd.className="TextFieldColorDisb";
							}

						
						
						for (var i=0;i<objDataForm.elements.length ;i++ )
						{
							if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
								{
								
								disablecheckbox(objDataForm.elements[i].name);
							/*	if(objDataForm.elements[i].checked==true)
									{
									Check_ChkBox(objDataForm.elements[i]);
									}*/
								}
						}

						

						

						objDataForm.Forward_To.focus();
						
					//	DisEmailFd();
			
				}


					if (sWname.toUpperCase()=="CANCEL_WI")
						{	
					
						
						if(objwi.attribute_list["Document_Type"].value!="")
						{
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;

						}
												
						if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
						
						if(objwi.attribute_list["CompanyName"].value!="" )
						{

						objDataForm.CompanyName.value=objwi.attribute_list["CompanyName"].value;

						}
						if(objwi.attribute_list["CompanyCode"].value!="" )
						{

						objDataForm.CompanyCode.value=objwi.attribute_list["CompanyCode"].value;

						}
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma(objwi.attribute_list["Amount"]);
						

						}
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						}

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						if(objwi.attribute_list["SAP_Document_Number"].value!="" )
						{

						objDataForm.SAP_Document_Number.value=objwi.attribute_list["SAP_Document_Number"].value;

						}
						if(objwi.attribute_list["Processor_EmailId"].value!="" )
						{

						objDataForm.Processor_EmailId.value=objwi.attribute_list["Processor_EmailId"].value;
						
						}

						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}
						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						
						if(objwi.attribute_list["Cancel_Decision"].value!="" )
						{

						objDataForm.Cancel_Decision.value=objwi.attribute_list["Cancel_Decision"].value;

						}
						if(objwi.attribute_list["PhysicalDocsSent"].value!="" )
						{

						objDataForm.PhysicalDocsSent.value=objwi.attribute_list["PhysicalDocsSent"].value;

						}
						if(objwi.attribute_list["Cancel_Decision_Comments"].value!="" )
						{

						objDataForm.Cancel_Decision_Comments.value=objwi.attribute_list["Cancel_Decision_Comments"].value;

						}
						DisablePhyField();
						
						makeDateButtonDisb();

						if(!loadcheckboxes())
							{
								return false;
							}
						if(!loadClrCheckboxes())
							
							{
								return false;
							}
						for (var i=0;i<objDataForm.elements.length ;i++ )
						{
							if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
								{

								disablecheckbox(objDataForm.elements[i].name);
								
								}
						}

						objDataForm.Cancel_Decision.focus();
							
				}



				if (sWname.toUpperCase()=="SPLIT_DOCS")
						{	
					
						
						if(objwi.attribute_list["Document_Type"].value!="")
						{
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;

						}
											
						if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
						
						if(objwi.attribute_list["CompanyName"].value!="" )
						{

						objDataForm.CompanyName.value=objwi.attribute_list["CompanyName"].value;

						}
						if(objwi.attribute_list["CompanyCode"].value!="" )
						{

						objDataForm.CompanyCode.value=objwi.attribute_list["CompanyCode"].value;

						}
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma(objwi.attribute_list["Amount"]);
						

						}
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						}

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						if(objwi.attribute_list["SAP_Document_Number"].value!="" )
						{

						objDataForm.SAP_Document_Number.value=objwi.attribute_list["SAP_Document_Number"].value;

						}

						if(objwi.attribute_list["Processor_EmailId"].value!="" )
						{

						objDataForm.Processor_EmailId.value=objwi.attribute_list["Processor_EmailId"].value;
						
						}
							
						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}
						if(objwi.attribute_list["Split_Doc_Decision"].value!="" )
						{

						objDataForm.Split_Doc_Decision.value=objwi.attribute_list["Split_Doc_Decision"].value;

						}
						//alert("in split");
						if(objwi.attribute_list["Split_Resolution_Comments"].value!="" )
						{

						objDataForm.Split_Resolution_Comments.value=objwi.attribute_list["Split_Resolution_Comments"].value;

						}
						if(objwi.attribute_list["No_Of_WI_Created"].value!="" )
						{

						objDataForm.No_Of_WI_Created.value=objwi.attribute_list["No_Of_WI_Created"].value;

						}
						if(objwi.attribute_list["WI_Serial_Number"].value!="" )
						{

						objDataForm.WI_Serial_Number.value=objwi.attribute_list["WI_Serial_Number"].value;

						}
								
						
						makeDateButtonDisb();

						if(!loadcheckboxes())
							{
								return false;
							}
						if(!loadClrCheckboxes())
							
							{
								return false;
							}
						for (var i=0;i<objDataForm.elements.length ;i++ )
						{
							if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
								{

								disablecheckbox(objDataForm.elements[i].name);
								
								}
						}

					}



					if (sWname.toUpperCase()=="VALIDATION")
						{	
					
											
					if(objwi.attribute_list["Document_Type"].value!="")
						{
						
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;
							
						}

					if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
										
						
						if(objwi.attribute_list["CompanyName"].value!="" )
						{

						objDataForm.CompanyName.value=objwi.attribute_list["CompanyName"].value;

						}
						if(objwi.attribute_list["CompanyCode"].value!="" )
						{

						objDataForm.CompanyCode.value=objwi.attribute_list["CompanyCode"].value;

						}
						
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma_SBR(objwi.attribute_list["Amount"]);
						

						}
						
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;
						
						}
						

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						if(objwi.attribute_list["SAP_Document_Number"].value!="" )
						{

						objDataForm.SAP_Document_Number.value=objwi.attribute_list["SAP_Document_Number"].value;

						}
						if(objwi.attribute_list["Processor_EmailId"].value!="" )
						{

						objDataForm.Processor_EmailId.value=objwi.attribute_list["Processor_EmailId"].value;
						
						}
						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						
						if(objwi.attribute_list["Validation"].value!="" )
						{

						objDataForm.Validation.value=objwi.attribute_list["Validation"].value;

						}
						if(objwi.attribute_list["Validation_Comments"].value!="" )
						{

						objDataForm.Validation_Comments.value=objwi.attribute_list["Validation_Comments"].value;

						}
						//alert("in split");
						
						makeDateButtonDisb();
						objDataForm.Validation.focus();
					}
					


					
			

	//}


		
			if (sWname.toUpperCase()=="QUERY" || sWname.toUpperCase()=="WORK EXIT")
					{	
					
					
					
					if(objwi.attribute_list["Document_Type"].value!="")
						{
						
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;
							
						}

					if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
					
						if(objwi.attribute_list["CompanyName"].value!="" )
						{

						objDataForm.CompanyName.value=objwi.attribute_list["CompanyName"].value;

						}
						if(objwi.attribute_list["CompanyCode"].value!="" )
						{

						objDataForm.CompanyCode.value=objwi.attribute_list["CompanyCode"].value;

						}
						
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma_SBR(objwi.attribute_list["Amount"]);
						

						}
						
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;
						
						}
						

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						//Bug No:NAO_12 By Santul Sharma
						
						if(objwi.attribute_list["SAP_Document_Number"].value!="" )
						{

						objDataForm.SAP_Document_Number.value=objwi.attribute_list["SAP_Document_Number"].value;

						}
						//Bug No:NAO_12 By Santul Sharma
						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Processor_EmailId"].value!="" )
						{

						objDataForm.Processor_EmailId.value=objwi.attribute_list["Processor_EmailId"].value;
						
						}
						if(objwi.attribute_list["Split_Doc_Decision"].value!="" )
						{

						objDataForm.Split_Doc_Decision.value=objwi.attribute_list["Split_Doc_Decision"].value;

						}
						if(objwi.attribute_list["Split_Resolution_Comments"].value!="" )
						{

						objDataForm.Split_Resolution_Comments.value=objwi.attribute_list["Split_Resolution_Comments"].value;

						}
						if(objwi.attribute_list["No_Of_WI_Created"].value!="" )
						{

						objDataForm.No_Of_WI_Created.value=objwi.attribute_list["No_Of_WI_Created"].value;

						}
						if(objwi.attribute_list["Cancel_Decision"].value!="" )
						{

						objDataForm.Cancel_Decision.value=objwi.attribute_list["Cancel_Decision"].value;

						}
						if(objwi.attribute_list["Cancel_Decision_Comments"].value!="" )
						{

						objDataForm.Cancel_Decision_Comments.value=objwi.attribute_list["Cancel_Decision_Comments"].value;

						}
						
						
						if(objwi.attribute_list["Validation"].value!="" )
						{

						objDataForm.Validation.value=objwi.attribute_list["Validation"].value;

						}
						if(objwi.attribute_list["Validation_Comments"].value!="" )
						{

						objDataForm.Validation_Comments.value=objwi.attribute_list["Validation_Comments"].value;

						}
						if(objwi.attribute_list["Forward_To"].value!="" )
						{

						objDataForm.Forward_To.value=objwi.attribute_list["Forward_To"].value;

						}
						if(objwi.attribute_list["FollowUpDate"].value!="" )
						{
								var retdate=convertdatenew(objwi.attribute_list['FollowUpDate'].value);
								objDataForm.FollowUpDate.value=retdate;
								
						
						}
						
						if(objwi.attribute_list["FollowUpReqd"].value!="" )
						{

						objDataForm.FollowUpReqd.value=objwi.attribute_list["FollowUpReqd"].value;
						
						}
						//chkFollowupReq(objDataForm.FollowUpReqd);
						
						if(objwi.attribute_list["FollowUpType"].value!="" )
						{

						objDataForm.FollowUpType.value=objwi.attribute_list["FollowUpType"].value;

						}
						if(objwi.attribute_list["AllToEmailIds"].value!="" )
						{

						objDataForm.AllToEmailIds.value=objwi.attribute_list["AllToEmailIds"].value;

						}
						if(objwi.attribute_list["AllCCEmailIds"].value!="" )
						{

						objDataForm.AllCCEmailIds.value=objwi.attribute_list["AllCCEmailIds"].value;

						}
						if(objwi.attribute_list["SubjectLine"].value!="" )
						{

						objDataForm.SubjectLine.value=objwi.attribute_list["SubjectLine"].value;

						}
						if(objwi.attribute_list["BodyText"].value!="" )
						{

						objDataForm.BodyText.value=objwi.attribute_list["BodyText"].value;

						}
						

						//alert("in split");
						
						makeDateButtonDisb();
					}
//Change No:NAO_11
if (sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING")
	{
		disablefield_VName("Vendor_Name");
	}
//Added for SBR_18 by Santul
//alert("bhawna");
isFormLoaded=true;
//Added for SBR_18 by Santul

}



function loadClrCheckboxes()
{
	 var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
	 var objWI_objwi=window.top.wi_object;
	 for (var i=0;i<objDataForm.elements.length ;i++ )
	 {
		 var sAttrName=objDataForm.elements[i].name.substring(3);
		 if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="clr" )
		 {
			
			
			if(objWI_objwi.attribute_list[sAttrName].value=="1" || objWI_objwi.attribute_list[sAttrName].value=="2")
				objDataForm.elements[i].disabled=false;			
			if(objWI_objwi.attribute_list[sAttrName].value=="2")			
				objDataForm.elements[i].checked=true;			
			if(objWI_objwi.attribute_list[sAttrName].value=="0" || objWI_objwi.attribute_list[sAttrName].value=="")
				objDataForm.elements[i].disabled=true;
		 }
	 }
	 return true;
}
			
function followupdisablecheckbox(field)
{
var objDataForm= window.parent.frames["left"].document.forms["dataform"];
objDataForm(field).className="EWTableCheckTextDisb";
objDataForm(field).disabled=true;
objDataForm(field).checked=false;

}

 function disablecheckbox(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).className="EWTableCheckTextDisb";

	//objDataForm(field).className="EWTableCheckTextDisb";
	objDataForm(field).disabled=true;
	//objDataForm(field).className="EWTableCheckTextDisb";
	
}
function disablechecked(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).checked=false;
}
function enablecheckbox(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).disabled=false;
	
}

function enablefield_VName(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=false;
	objDataForm(field).className="TextFieldColorLight";
	
}

function disablefield_VName(field)
{
	
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorLightDisb";
	//objDataForm(field).value="";
}



function makeDateButtonDisb()
		{
		var objDataForm= window.parent.frames["left"].document.forms["dataform"];
		objDataForm.SearchVName.disabled=true;
		document.getElementById('Date_IMG').disabled=true;
		document.getElementById('Date_IMG1').disabled=true;
		document.getElementById('Date_IMG2').disabled=true;
		}

function SetTabIndex()
{
	try
	{	//alert("in set tab index");
       var objdataForm =document.forms["dataform"];
	   var TabSet=0;
	   var TotalElements=objdataForm.elements.length;
	   
		var imgindx1=10;
		 var imgindx2=13;
		  var imgindx3=15;
		  

	  
	   for(var i=0;i<TotalElements;i++)
		{           
		   

		  if(i==imgindx1)
		   { 		
			    TabSet=TabSet+1;
				document.getElementById('Date_IMG').tabIndex=TabSet;
				
		   }
		 
		   if(i==imgindx2)
		   {	
                TabSet=TabSet+1;
				document.getElementById('Date_IMG1').tabIndex=TabSet;
				
		   }
		   if(i==imgindx2)
		   {	
                TabSet=TabSet+1;
				document.getElementById('Date_IMG2').tabIndex=TabSet;
				
		   }
		   if(objdataForm.elements[i].type=='text')
		   {
			   if(!objdataForm.elements[i].readOnly)
			   {   
				   
				   TabSet=TabSet+1;
				   objdataForm.elements[i].tabIndex=TabSet;
				 
			   }
			   else
			   {
				   objdataForm.elements[i].tabIndex="";
			   }
		    }
			else if(objdataForm.elements[i].type=='select-one')
			{
			   if(!objdataForm.elements[i].disabled)
				{			   
                   TabSet=TabSet+1;
				   objdataForm.elements[i].tabIndex=TabSet;	
				 
				}
				else
				{
					objdataForm.elements[i].tabIndex="";
				}
			}
			else if(objdataForm.elements[i].type=='button')
			{
				if(!objdataForm.elements[i].disabled)
				{  
					TabSet=TabSet+1;
				    objdataForm.elements[i].tabIndex=TabSet;
				
				}
				else
				{
					objdataForm.elements[i].tabIndex="";
				}
			}			
		    
		}
       
	}
	catch(e)
	{
		alert("Error in SetTabIndex: ");
	}
}




function DisableFields()
{
	var objwi=window.top.wi_object;
	var sWname=objwi.workstep_name.toUpperCase();
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	
	if(objDataForm.Split_Doc_Decision.value=="Reject")
	{
		disablefield("No_Of_WI_Created");
		disablefield("WI_Serial_Number");
	}
	else
	{
		enablefield("No_Of_WI_Created");
		enablefield("WI_Serial_Number");
		
	}
	return true;
}
function enablefield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=false;
	objDataForm(field).className="TextFieldColor";
	
}

function disablefield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorDisb";
	objDataForm(field).value="";
}

function FillDocTypesCombo()
{
	
	var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
	var objwi=window.top.wi_object;
	var sWname=objwi.workstep_name.toUpperCase();
	
	

	if(sWname.toUpperCase()=="WORK INTRODUCTION")
	{
	DocType='Non PO Invoice~PO Invoice~Credit Memo~Debit Note~Check Request~';
	}
	else
	{
	DocType='Non PO Invoice~PO Invoice~Credit Memo~Debit Note~Check Request~Other~';
	
	}
	if(document.getElementById("Document_Type").length!=1)
	{
	document.getElementById("Document_Type").length=1;
	
	}

	var userArray=DocType.split('~');
	
		for (var j=0;j<userArray.length-1;j++)
			{
				optn=document.createElement("option");	
				req=document.getElementById("Document_Type");
				optn.text=userArray[j];
				optn.value=userArray[j];
				//alert(req);
				//if(typeof req.options!='undefined')// || typeof req.options!='null' || typeof req.options!=null)
				if(req.type=="select-one" )
				req.options.add(optn);	
			} 
			
	
	}
	
function loadcheckboxes()
{
	//alert("santul");
	 var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
	 var objWI_objwi=window.top.wi_object;
	 var checkFlag=false;
	 for (var i=0;i<objDataForm.elements.length ;i++ )
	 {
		 var sAttrName=objDataForm.elements[i].name.substring(3);
	
		 if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" && (objWI_objwi.attribute_list[sAttrName].value==1 || objWI_objwi.attribute_list[sAttrName].value==2))
		 {
			objDataForm.elements[i].checked=true;
			
		 }
		 
	 }
	 /*if(checkFlag==true)
		{
		EnableEmailFd();
		}*/
	//alert("santul1");
	return true;
}

function OperationChangeCompname()
{
	
var objDataForm=document.forms["dataform"];
var comboCompnamevalue="";
comboCompnamevalue=objDataForm.tempjoinedstring.value;
var CompInfo=comboCompnamevalue.split(',');

if(objDataForm.Vendor_Name.value!="")
	{
	objDataForm.Vendor_Name.value="";
	objDataForm.Vendor_ID.value="";

	}
	for(var i=1;i<CompInfo.length;i++)
	{
		
		var tempCompName=CompInfo[i].substring(0,CompInfo[i].indexOf("="));
		
		if(objDataForm.CompanyName.value=="")
		{
			objDataForm.CompanyName.value="";
			objDataForm.CompanyCode.value="";
		}
		else
		{
			if(objDataForm.CompanyName.value==tempCompName)
			{
				objDataForm.CompanyCode.value=CompInfo[i].substring(CompInfo[i].indexOf("=")+1,CompInfo[i].length);
			}
		}
	}
}

function OperationChangeCompcode()
{  
	
var objWI_Obj=window.top.wi_object;
var objDataForm=document.forms["dataform"];
var comboCompCode=objDataForm.tempjoinedstring.value;
var CompInfo=comboCompCode.split(',');
	
	if(objDataForm.Vendor_Name.value!="")
	{
	objDataForm.Vendor_Name.value="";
	objDataForm.Vendor_ID.value="";

	}
	for(var i=1;i<CompInfo.length;i++)
	{
		
		var tempCompCode=CompInfo[i].substring(CompInfo[i].indexOf("=")+1,CompInfo[i].length);
		
		
		if(objDataForm.CompanyCode.value=="")
		{
			objDataForm.CompanyCode.value="";
			objDataForm.CompanyName.value="";

		}
		else
		{
			if(objDataForm.CompanyCode.value==tempCompCode)
			{
				objDataForm.CompanyName.value=CompInfo[i].substring(0,CompInfo[i].indexOf("="));
			}
		}
	}


}


 function setExcpChkBoxes()
 {
	var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
	 var objwi=window.top.wi_object;
	 
		if(objDataForm.Document_Type.value=="" || objDataForm.Document_Category.value=="")
		{
			for (var i=0;i<objDataForm.elements.length ;i++ )
			{
			if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
				{
					disablecheckbox(objDataForm.elements[i].name);
					disablechecked(objDataForm.elements[i].name);

				}
			}
			DisEmailFd();

		}
	else
	 {
		
		if((objDataForm.Document_Category.value=="Archival"))
		{

			
			enablecheckbox("chkExcp_Bad_Image");
			enablecheckbox("chkExcp_Duplicate");
			enablecheckbox("chkExcp_Multiple_Documents");
			enablecheckbox("chkExcp_New_Vendor_Setup");
			enablecheckbox("chkExcp_Miscellaneous");
			//enablecheckbox("chkExcp_Missing_Incorrect_Approval");
			//enablecheckbox("chkExcp_Incorrect_Coding");
			//enablecheckbox("chkExcp_Cost_Quality_Variance");
			

			
			
			disablecheckbox("chkExcp_Not_An_Invoice");
			disablechecked("chkExcp_Not_An_Invoice");
			disablecheckbox("chkExcp_Missing_PO");
			disablechecked("chkExcp_Missing_PO");
			disablecheckbox("chkExcp_Goods_Recpt_Varification");
			disablechecked("chkExcp_Goods_Recpt_Varification");
			disablecheckbox("chkExcp_Missing_Incorrect_Approval");
			disablechecked("chkExcp_Missing_Incorrect_Approval");
			disablecheckbox("chkExcp_Incorrect_Coding");
			disablechecked("chkExcp_Incorrect_Coding");
			disablecheckbox("chkExcp_Cost_Quality_Variance");
			disablechecked("chkExcp_Cost_Quality_Variance");
			
			if(objDataForm.chkExcp_Miscellaneous.checked==true)
			{
			objDataForm.AllToEmailIds.disabled=false;
			objDataForm.AllToEmailIds.className="TextFieldColor";
			objDataForm.AllCCEmailIds.disabled=false;
			objDataForm.AllCCEmailIds.className="TextFieldColor";
			enablefield("SubjectLine");
			enablefield("BodyText");
			}
			else
			{
				DisEmailFd();
			}

			


		}
		
			else
			{
				
				
				if(objDataForm.Document_Type.value=="Non PO Invoice" || objDataForm.Document_Type.value=="Debit Note"   || objDataForm.Document_Type.value=="PO Invoice" || objDataForm.Document_Type.value=="Check Request" || objDataForm.Document_Type.value=="Credit Memo")
						{
								
										enablecheckbox("chkExcp_Bad_Image");
										enablecheckbox("chkExcp_Duplicate");
										enablecheckbox("chkExcp_Multiple_Documents");
										enablecheckbox("chkExcp_Missing_Incorrect_Approval");
										enablecheckbox("chkExcp_New_Vendor_Setup");
										enablecheckbox("chkExcp_Cost_Quality_Variance");
										enablecheckbox("chkExcp_Incorrect_Coding");
										enablecheckbox("chkExcp_Miscellaneous");
										
										if(objDataForm.Document_Type.value=="Non PO Invoice" || objDataForm.Document_Type.value=="Check Request")
											{
											enablecheckbox("chkExcp_Goods_Recpt_Varification");
											}
											else
											{
											disablecheckbox("chkExcp_Goods_Recpt_Varification");
											disablechecked("chkExcp_Goods_Recpt_Varification");
											}

										
										if(objDataForm.Document_Type.value=="Check Request" || objDataForm.Document_Type.value=="PO Invoice")
											{
												enablecheckbox("chkExcp_Missing_PO");
												
													
											}
										else
											{
											disablecheckbox("chkExcp_Missing_PO");
											disablechecked("chkExcp_Missing_PO");
											}
										
									

										
								disablecheckbox("chkExcp_Not_An_Invoice");
								disablechecked("chkExcp_Not_An_Invoice");
					if(objDataForm.chkExcp_Miscellaneous.checked==true || objDataForm.chkExcp_Missing_Incorrect_Approval.checked==true || objDataForm.chkExcp_Incorrect_Coding.checked==true || objDataForm.chkExcp_Missing_PO.checked==true || objDataForm.chkExcp_Cost_Quality_Variance.checked==true  || objDataForm.chkExcp_Goods_Recpt_Varification.checked==true || objDataForm.chkExcp_Miscellaneous.checked==true)
						{
						objDataForm.AllToEmailIds.disabled=false;
						objDataForm.AllToEmailIds.className="TextFieldColor";
						objDataForm.AllCCEmailIds.disabled=false;
						objDataForm.AllCCEmailIds.className="TextFieldColor";
						enablefield("SubjectLine");
						enablefield("BodyText");
						}
					else
					{
					DisEmailFd();
					}


						}
					else if(objDataForm.Document_Type.value=="Other")
					{
					
						
						enablecheckbox("chkExcp_Not_An_Invoice");
						
						disablecheckbox("chkExcp_Bad_Image");
						disablechecked("chkExcp_Bad_Image");
						disablecheckbox("chkExcp_Missing_PO");
						disablechecked("chkExcp_Missing_PO");
						disablecheckbox("chkExcp_Missing_Incorrect_Approval");
						disablechecked("chkExcp_Missing_Incorrect_Approval");
						disablecheckbox("chkExcp_Incorrect_Coding");
						disablechecked("chkExcp_Incorrect_Coding");
						disablecheckbox("chkExcp_Duplicate");
						disablechecked("chkExcp_Duplicate");
						disablecheckbox("chkExcp_Multiple_Documents");
						disablechecked("chkExcp_Multiple_Documents");
						disablecheckbox("chkExcp_New_Vendor_Setup");
						disablechecked("chkExcp_New_Vendor_Setup");
						disablecheckbox("chkExcp_Goods_Recpt_Varification");
						disablechecked("chkExcp_Goods_Recpt_Varification");
						disablecheckbox("chkExcp_Cost_Quality_Variance");
						disablechecked("chkExcp_Cost_Quality_Variance");
						disablecheckbox("chkExcp_Miscellaneous");
						disablechecked("chkExcp_Miscellaneous");
						
						DisEmailFd();

					}
				
	 }

 }
 }

 function NAOAP_setDueDate()
{

var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
if(objDataForm.Invoice_Date.value=="")
	{
objDataForm.Due_Date.value="";
	}
	if(objDataForm.Due_Date.value!="")
	{
	objDataForm.Due_Date.value="";
	}

var tempInvDate=new Date(objDataForm.Invoice_Date.value);

tempInvDate=tempInvDate.setDate(tempInvDate.getDate()+30);

var tempInvDate1=new Date(tempInvDate);
var tempDate=tempInvDate1.getDate();
var tempMonth=Number(tempInvDate1.getMonth()+1);
//var tempMonth=Number(tempInvDate1.getMonth());
var tempYear=Number(tempInvDate1.getYear());
if(tempMonth>=1 && tempMonth<=9)
	{
	tempMonth=tempMonth.toString();
	tempMonth="0"+tempMonth;
	}
if(tempDate>=1 && tempDate<=9)
	{
	//tempDate=tempDate.toString();
	tempDate="0"+tempDate;
	}
if(tempYear<=99)
	{
	
	tempYear=1900+tempYear;

	}
	
var tempdueDate=tempMonth+'/'+tempDate+'/'+tempYear;

objDataForm.Due_Date.value=tempdueDate;

}

function Check_ChkBox(ExcpName)
{
	
		var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
		var objwi=window.top.wi_object;
		var sWname=objwi.workstep_name.toUpperCase();
		var excpChecked=false;
		var OtherExpChk=false;
		

		if(ExcpName.checked==true)
		{
			
			EnableEmailFd();

			for (var i=0;i<objDataForm.elements.length ;i++ )
			{
				var sAttrName=objDataForm.elements[i].name.substring(3);
				if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" &&
				objDataForm.elements[i].checked==true)
				{
					
					if(objDataForm.elements[i].name!=ExcpName.name && (objDataForm.elements[i].name=="chkExcp_Missing_Incorrect_Approval" || objDataForm.elements[i].name=="chkExcp_Missing_PO" || objDataForm.elements[i].name=="chkExcp_Cost_Quality_Variance" || objDataForm.elements[i].name=="chkExcp_Goods_Recpt_Varification" || objDataForm.elements[i].name=="chkExcp_Incorrect_Coding" || objDataForm.elements[i].name=="chkExcp_Miscellaneous"))
					{
					OtherExpChk=true;
					break;
					}


				}
			}
		if(sExcpName.length!="")
				{	
				for (var expCount=0;expCount<=5 ;expCount++)
					{
					
					if(trim(ExcpName.name.substring(3,ExcpName.name.length).toUpperCase())==trim(sExcpName[expCount].toUpperCase()))
						{

							
							if(OtherExpChk==false)
							{
								if(objDataForm.SubjectLine.value.indexOf('\n')!=-1)
								{
									objDataForm.SubjectLine.value="";
								}
								if(objDataForm.BodyText.value=="")
								{
									objDataForm.BodyText.value=sBodyText[expCount];
								}
								if(objDataForm.SubjectLine.value=="")
								{	
									objDataForm.SubjectLine.value=sSubject[expCount];
								}
							}


						}

					}
				}

			}
		else
		{
				if(objDataForm.chkExcp_Missing_Incorrect_Approval.checked==true || objDataForm.chkExcp_Incorrect_Coding.checked==true || objDataForm.chkExcp_Missing_PO.checked==true || objDataForm.chkExcp_Cost_Quality_Variance.checked==true || objDataForm.chkExcp_Goods_Recpt_Varification.checked==true || objDataForm.chkExcp_Miscellaneous.checked==true)
				{

				excpChecked=true;

				}

			/*	for (var i=0;i<objDataForm.elements.length ;i++ )
				{
					var sAttrName=objDataForm.elements[i].name.substring(3);
					if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" &&
					objDataForm.elements[i].checked==true)
						{
						//alert("test "+objDataForm.elements[i].name);
							if(objDataForm.elements[i].name=="chkExcp_Missing_Incorrect_Approval" || objDataForm.elements[i].name=="chkExcp_Missing_PO" || objDataForm.elements[i].name=="chkExcp_Cost_Quality_Variance" || objDataForm.elements[i].name=="chkExcp_Goods_Recpt_Varification" || objDataForm.elements[i].name=="chkExcp_Incorrect_Coding" || objDataForm.elements[i].name=="chkExcp_Miscellaneous")
							{
							Check_ChkBox(objDataForm.elements[i]);
							}
					// excpChecked=true;

						}

				}*/
				
				if(excpChecked==false)
				{
				DisEmailFd();
				}
				}

		return true;

}

//added by bhawna
/*
function Check_ChkBox_new(ExcpName)
{
	
		var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
		var objwi=window.top.wi_object;
		var sWname=objwi.workstep_name.toUpperCase();
		var excpChecked=false;
		var OtherExpChk=false;

		if(ExcpName.checked==true)
		{
			
			objDataForm.AllToEmailIds.disabled=false;
			objDataForm.AllToEmailIds.className="TextFieldColor";
			objDataForm.AllCCEmailIds.disabled=false;
			objDataForm.AllCCEmailIds.className="TextFieldColor";
			enablefield("SubjectLine");
			enablefield("BodyText");

			for (var i=0;i<objDataForm.elements.length ;i++ )
			{
				var sAttrName=objDataForm.elements[i].name.substring(3);
				if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" &&
				objDataForm.elements[i].checked==true)
				{
					//alert("test "+objDataForm.elements[i].name);
					if(objDataForm.elements[i].name!=ExcpName.name && (objDataForm.elements[i].name=="chkExcp_Missing_Incorrect_Approval" || objDataForm.elements[i].name=="chkExcp_Missing_PO" || objDataForm.elements[i].name=="chkExcp_Cost_Quality_Variance" || objDataForm.elements[i].name=="chkExcp_Goods_Recpt_Varification" || objDataForm.elements[i].name=="chkExcp_Incorrect_Coding" || objDataForm.elements[i].name=="chkExcp_Miscellaneous"))
					{
					OtherExpChk=true;
					}


				}
			}
		if(sWname.toUpperCase()=="PENDING_RESOLUTION")
			{
			OtherExpChk=false;
			
			}

			if(sExcpName.length!="")
				{	
				for (var expCount=0;expCount<=5 ;expCount++)
					{
					//alert(" sExcpName "+sExcpName[expCount].toUpperCase());
					//alert("exception name"+ExcpName.name.substring(3,ExcpName.name.length).toUpperCase());
						if(trim(ExcpName.name.substring(3,ExcpName.name.length).toUpperCase())==trim(sExcpName[expCount].toUpperCase()))
						{


							if(OtherExpChk==false)
							{
						//	alert("Pending1 : "+objDataForm.BodyText.value);
							if(objDataForm.BodyText.value=="")
							objDataForm.BodyText.value=sBodyText[expCount];
							if(objDataForm.SubjectLine.value=="")
							objDataForm.SubjectLine.value=sSubject[expCount];
							
							}


						}

					}
				}

			}
		else
		{
				if(objDataForm.chkExcp_Missing_Incorrect_Approval.checked==true || objDataForm.chkExcp_Incorrect_Coding.checked==true || objDataForm.chkExcp_Missing_PO.checked==true || objDataForm.chkExcp_Cost_Quality_Variance.checked==true || objDataForm.chkExcp_Goods_Recpt_Varification.checked==true || objDataForm.chkExcp_Miscellaneous.checked==true)
				{

				excpChecked=true;

				}

				for (var i=0;i<objDataForm.elements.length ;i++ )
				{
					var sAttrName=objDataForm.elements[i].name.substring(3);
					if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" &&
					objDataForm.elements[i].checked==true)
						{
						//alert("test "+objDataForm.elements[i].name);
							if(objDataForm.elements[i].name=="chkExcp_New_Vendor_Setup" || objDataForm.elements[i].name=="chkExcp_Missing_Incorrect_Approval" || objDataForm.elements[i].name=="chkExcp_Missing_PO" || objDataForm.elements[i].name=="chkExcp_Cost_Quality_Variance" || objDataForm.elements[i].name=="chkExcp_Goods_Recpt_Varification" || objDataForm.elements[i].name=="chkExcp_Incorrect_Coding" || objDataForm.elements[i].name=="chkExcp_Miscellaneous")
							{
							Check_ChkBox(objDataForm.elements[i]);
							}
					// excpChecked=true;

						}

				}
				
				if(excpChecked==false)
				{
				DisEmailFd();
				}
				}

		return true;

}
*/
function populate_Mails_Fields()
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var SubjectLine=objDataForm.SubjectLine.value;
	
	if(objDataForm.FollowUpReqd.value=="Yes")
	{
			EnableEmailFd();
			objDataForm.FollowUpType.disabled=false;
			objDataForm.FollowUpType.className="TextFieldColor";
			for (var i=0;i<objDataForm.elements.length ;i++ )
			{
				if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="clr")
				{
					followupdisablecheckbox(objDataForm.elements[i].name);
				}
			}
		for (var i=0;i<objDataForm.elements.length ;i++ )
		{
			if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
			{
							
			
				if(objDataForm.elements[i].checked==true)
				{
						if(sExcpName.length!="")
						{	
							for (var expCount=0;expCount<=5 ;expCount++)
							{
							if(trim(objDataForm.elements[i].name.substring(3,objDataForm.elements[i].name.length).toUpperCase())==trim(sExcpName[expCount].toUpperCase()))
								{
								
										if(SubjectLine.indexOf('\n')!=-1)
											SubjectLine="";
										if(objDataForm.BodyText.value=="")
											objDataForm.BodyText.value=sBodyText[expCount];
										if(objDataForm.SubjectLine.value=="")
											objDataForm.SubjectLine.value=sSubject[expCount];
										break;
																	
								}

							}
						}
						
				} 
			}
		}
	}
	else
	{
	
		DisEmailFd();
		objDataForm.FollowUpType.value="";
		objDataForm.FollowUpType.disabled=true;
		objDataForm.FollowUpType.className="TextFieldColorDisb";
		loadClrCheckboxes_Followup();
	}


}


	


function DisEmailFd()
{
	
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm.AllToEmailIds.disabled=true;
	objDataForm.AllToEmailIds.className="TextFieldColorDisb";
	objDataForm.AllToEmailIds.value="";

	objDataForm.AllCCEmailIds.disabled=true;
	objDataForm.AllCCEmailIds.className="TextFieldColorDisb";
	objDataForm.AllCCEmailIds.value="";

	//08/12/2008
	objDataForm.SubjectLine.value="";
	objDataForm.BodyText.value="";
	//08/12/2008
	disablefield("SubjectLine");
	disablefield("BodyText");


	return true;
}

function LoadForExcpEmail()
{
	
	try
	{
					
		ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\NAOAP\\ExceptionDetail.jsp","");	
		var rowValues=sAjaxReturnValue.split('~');
		for(var i=0;i<rowValues.length;i++)
		{
			var colValues=rowValues[i].split('^');
			sExcpName[i]=colValues[0];
			sSubject[i]=colValues[1];
			sBodyText[i]=colValues[2];
		
		}
	}

	catch(e)
	{
			alert('Error in updating Exception Details.');
			return false;
	}


}

function loadFormEmailids(objDataForm,objwi)
{
var tempToMailid=[];
var tempCCMailid=[];
var tempToMailid=objwi.attribute_list["AllToEmailIds"].value.split(',');
var tempCCMailid=objwi.attribute_list["AllCCEmailIds"].value.split(',');
for(var i=0;i<tempToMailid.length;i++)
	{	
		var temp=tempToMailid[i];
		
		for(var j=0;j<objDataForm.AllToEmailIds.length;j++)
		{
		if(temp==objDataForm.AllToEmailIds[j].value)
			{
			objDataForm.AllToEmailIds[j].selected=true;
			}
		else
			continue;
		}
		

	}
	
for(var i=0;i<tempCCMailid.length;i++)
	{	
		var temp1=tempCCMailid[i];
		
		for(var j=0;j<objDataForm.AllCCEmailIds.length;j++)
		{
		if(temp1==objDataForm.AllCCEmailIds[j].value)
			{
			objDataForm.AllCCEmailIds[j].selected=true;
			}
		else
			continue;
		}
		

	}
}

/*function chkFollowupReq(followupReq)
{


var objDataForm= window.parent.frames["left"].document.forms["dataform"];
if(followupReq.value.toUpperCase()=="YES" )
	{
			for (var i=0;i<objDataForm.elements.length ;i++ )
			{
				if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="clr")
				{
				followupdisablecheckbox(objDataForm.elements[i].name);
				
				}
			}
				objDataForm.AllToEmailIds.disabled=false;
				objDataForm.AllToEmailIds.className="TextFieldColor";
				objDataForm.AllCCEmailIds.disabled=false;
				objDataForm.AllCCEmailIds.className="TextFieldColor";
				enablefield("SubjectLine");
				enablefield("BodyText");
				objDataForm.FollowUpType.disabled=false;
				objDataForm.FollowUpType.className="TextFieldColor";

				disablefield("Exception_Resol_Comments");
				
				for (var i=0;i<objDataForm.elements.length ;i++ )
						{
							if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
								{
								
								disablecheckbox(objDataForm.elements[i].name);
								if(objDataForm.elements[i].checked==true)
									{
									Check_ChkBox(objDataForm.elements[i]);
									}
								}
						}
	}
	else
	{
		
	
	loadClrCheckboxes();
	objDataForm.FollowUpType.value="";
	objDataForm.FollowUpType.disabled=true;
	objDataForm.FollowUpType.className="TextFieldColorDisb";
	enablefield("Exception_Resol_Comments");
	DisEmailFd();
	}


}*/


function DisablePhyField()
{
	
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var objwi=window.top.wi_object;
	if(objDataForm.Cancel_Decision.value=="Approved" && objwi.attribute_list["Intro_Type"].value=="BH")
	{
		objDataForm.PhysicalDocsSent.disabled=false;
		objDataForm.PhysicalDocsSent.className='TextFieldColor';

	}
	else
	{
	objDataForm.PhysicalDocsSent.disabled=true;
	objDataForm.PhysicalDocsSent.selectedIndex=0;
	objDataForm.PhysicalDocsSent.className='TextFieldColorDisb';
	}
}
function EnableEmailFd()
{
	
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm.AllToEmailIds.disabled=false;
	objDataForm.AllToEmailIds.className="TextFieldColor";
	objDataForm.AllCCEmailIds.disabled=false;
	objDataForm.AllCCEmailIds.className="TextFieldColor";
	enablefield("SubjectLine");
	enablefield("BodyText");
}

function loadClrCheckboxes_Followup()
{
	 var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
	 var objWI_objwi=window.top.wi_object;
	 for (var i=0;i<objDataForm.elements.length ;i++ )
	 {
		 var sAttrName=objDataForm.elements[i].name.substring(3);
		 if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="clr" )
		 {
			
			
			if(objWI_objwi.attribute_list[sAttrName].value=="1" || objWI_objwi.attribute_list[sAttrName].value=="2")
				objDataForm.elements[i].disabled=false;			
			//if(objWI_objwi.attribute_list[sAttrName].value=="2")			
			//	objDataForm.elements[i].checked=true;			
			if(objWI_objwi.attribute_list[sAttrName].value=="0" || objWI_objwi.attribute_list[sAttrName].value=="")
				objDataForm.elements[i].disabled=true;
		 }
	 }
	 return true;
}


/*
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-GMAC
Module : GMAC-ResAP
File Name : ResAP_client.js
Author :   Tarit Gupta
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date			Change By		Change Description (Bug No. (If Any))
(DD/MM/YYYY)

19/06/2008		Bhawna Gupta	Res_3
21/08/2008		Bhawna Gupta	Res_27
22/08/2008		Bhawna Gupta	Res_29
06/08/2008		Bhawna Gupta	Res_18
31/10/2008		Tarit Gupta		Comm_03
----------------------------------------------------------------------------------------------------
*/





var sRaisedExp="0";


			function ResAP_Done()
			{   
				//alert("in done");
				
				var objwi=window.top.wi_object;
				
				var objDataForm= window.parent.frames["left"].document.forms["dataform"];
				var sWname=window.top.wi_object.workstep_name.toUpperCase();

				//added by bhawna 11-06-2008
				/*
					if(sWname.toUpperCase()=="RESCAN_WI" || sWname.toUpperCase()=="PENDING_RESOLUTION" || sWname.toUpperCase()=="CANCEL_WI")
				*/
				if(sWname.toUpperCase()=="RESCAN_WI" || sWname.toUpperCase()=="PENDING_RESOLUTION" || sWname.toUpperCase()=="CANCEL_WI" || sWname.toUpperCase()=="SPLIT_DOCS")
					{
					if(!ResAP_Save('D'))
						{
						return false;
						}
					}
				else if(!ResAP_Save())
					{
						return false;
					}
					
				if(!ResAP_checkmandatory_Save())
					{
						return false;
					
					}
					
				
			//alert("sRaisedExp "+sRaisedExp);


				

				//alert("ddf "+sRaisedExp);

				if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING")
					{
						
						if(objDataForm.Document_Type.value=="Other" && sRaisedExp=="0")
							{
								
								var Confirm = confirm("Document type is selected as other,Do you want to cancel the Work Item");
		
								if(Confirm)
								isModified(objwi.attribute_list["Excp_Not_An_Invoice"],"1");
								else
								{	
									objDataForm.Document_Type.focus();
									return false;
								}
							}//Comm_03 Added by Tarit as on 31-10-08
						else if(objwi.attribute_list["Intro_Type"].value!="BH" && objDataForm.chkExcp_Bad_Image.checked==true)
							{
							window.parent.frames["left"].document.getElementById("tab1").style.display='none';
							window.parent.frames["left"].document.getElementById("tab2").style.display='block';
							alert("Can not raise Bad Image Exception as Work item has been introducted Manually");
							return false;
							}
							//Comm_03 Added by Tarit as on 31-10-08
								
								if(sRaisedExp!="1")
									{
									
										if(!fetch_Vname_InvoiceNo())
										{
											return false;
										}
										///Added on 10th June 2008

										/*
										if(objDataForm.AP_Business_Unit.value!=objDataForm.BusinessUnitModalDialog.value)
										{
											alert("Kindly select the appropriate AP Business Unit value");
											objDataForm.AP_Business_Unit.focus(true);
											return false;
										}
										*/
										
											if(!fetch_Vname_BusinessUnit())
											{
												return false;
											}
										
									}
						//////Added on 16th June 2008(Tarit Gupta)
						if(objDataForm.chkExcp_Client.checked && (objDataForm.chkExcp_Bad_Image.checked ||objDataForm.chkExcp_New_Vendor_Setup.checked || objDataForm.chkExcp_Missing_Incorrect_Approval.checked || objDataForm.chkExcp_Missing_Documentation.checked || objDataForm.chkExcp_Invalid_Cost_Center_Account.checked || objDataForm.chkExcp_Fixed_Asset_Coding.checked || objDataForm.chkExcp_Not_An_Invoice.checked || objDataForm.chkExcp_Not_An_Invoice.checked || objDataForm.chkExcp_Duplicate.checked || objDataForm.chkExcp_Multiple_Documents.checked))
							{
							if(window.parent.frames["left"].document.getElementById('tab2').style.display=="none")
								{
							window.parent.frames["left"].document.getElementById("tab1").style.display='none';
							window.parent.frames["left"].document.getElementById("tab2").style.display='block';
								}
								alert("Can not raise other Exceptions as Client Exception is raised.");
							return false;
							}
					//////Added on 16th June 2008(Tarit Gupta)
					
								///Added on 10th June 2008
					}
					
					
					if(sWname.toUpperCase()=="VALIDATION")

						{
								if(objDataForm.Validation.value=="Fail" )
									{					
										objDataForm.Priority.value="Urgent";//Bug No:Res_3
										isModified(objwi.attribute_list["PriorityLevel"],"3");
										
										
									}
									
									if((parseFloat(objwi.attribute_list['Amount'].value))<=100000)
											isModified(objwi.attribute_list["RouteFlag"],"Y");
									else
											isModified(objwi.attribute_list["RouteFlag"],"N");
									
									
									
									
						}
					
				
						

						
					
					if(!Check_For_Route_Exception())
						{
					
							return false;
						}
					
							
					/*if(sWname.toUpperCase()=="RESCAN_WI" || sWname.toUpperCase()=="PENDING_RESOLUTION" || sWname.toUpperCase()=="CANCEL_WI" || sWname.toUpperCase()=="SPLIT_DOCS")
					{
						
						var sxception=checkallexcepcleared(objDataForm);

						if(sxception=="1") 
						{
						
						alert("Please Clear All Raised Exceptions");
						
							
								window.parent.frames["left"].document.getElementById("tab1").style.display='none';
								window.parent.frames["left"].document.getElementById("tab2").style.display='block';
								return false;
						}
									
					}*/
					
					if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING" || sWname.toUpperCase()=="RESCAN_WI" || sWname.toUpperCase()=="PENDING_RESOLUTION" || sWname.toUpperCase()=="CANCEL_WI" || sWname.toUpperCase()=="SPLIT_DOCS")
					{
					
					if(!UpdateExpData())
						{

						return false;
						}

					}
					if(!ResAp_SaveAtDone())
						{
							return false;
						}
					
					
					if (sWname.toUpperCase()=="PENDING_RESOLUTION")
							{	
					
							objwi.attribute_list["qException"].value="";
									
							}

						
					//alert("not an invoice "+objwi.attribute_list["Excp_Not_An_Invoice"].value);
					//alert("last "+sRaisedExp);
		
					
			return true;
			//return false;
			
			}


	function set_exp_for_filter(objDataForm,objwi)
	{
	
	objwi.attribute_list["qException"].value="";
	var qExp=objwi.attribute_list["qException"].value;
	if(objDataForm.chkExcp_Missing_Incorrect_Approval.checked==true)
		qExp=qExp+"A";
	if(objDataForm.chkExcp_New_Vendor_Setup.checked==true)
		qExp=qExp+"B";
	if(objDataForm.chkExcp_Missing_Documentation.checked==true)
		qExp=qExp+"C";
	if(objDataForm.chkExcp_Invalid_Cost_Center_Account.checked==true)
		qExp=qExp+"D";
	if(objDataForm.chkExcp_Fixed_Asset_Coding.checked==true)
		qExp=qExp+"E";
	if(objDataForm.chkExcp_Client.checked==true)
		qExp=qExp+"F";
	isModified(objwi.attribute_list["qException"],qExp);
	//alert(objwi.attribute_list["qException"].value);
		
	return true;
	}

	
	function ResAP_Save(sMode)
		{
			
			
			var objwi=window.top.wi_object;
			var objDataForm= window.parent.frames["left"].document.forms["dataform"];
			var sWname=window.top.wi_object.workstep_name.toUpperCase();
		
			
			if(!combos(objwi,objDataForm))
				{
				return false;
				}
	
				
				if(sWname.toUpperCase()!="WORK INTRODUCTION")
				{
					//if(objDataForm.TempAmount.value!="" )
					//	{
					
						objwi.attribute_list['Amount'].value=RemoveComma_ResAP();
						objwi.attribute_list['Amount'].modified_flag=true;
			
				
						
					//	}	
				}	
				
				
			
			if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING")
				{
			
				sRaisedExp =checkboxRaised(objwi,objDataForm);
		
				
				}
			if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING")
							{
								
								if(!(set_exp_for_filter(objDataForm,objwi)))
								{
								return false;								
								}
								if(trim(objDataForm.Priority.value)=="Urgent")
								{
								//alert("sff:"+objwi.attribute_list["PriorityLevel"]);
								isModified(objwi.attribute_list["PriorityLevel"],"3");
								}
								else
								isModified(objwi.attribute_list["PriorityLevel"],"1");
								
							}

			if(sWname.toUpperCase()=="RESCAN_WI" || sWname.toUpperCase()=="PENDING_RESOLUTION" || sWname.toUpperCase()=="CANCEL_WI" || sWname.toUpperCase()=="SPLIT_DOCS")
				{ 
				sRaisedExp =checkboxRaised(objwi,objDataForm);
				if(!checkboxClear(objwi,objDataForm,sMode))
					{	
					return false;
					}

				}
				
		return true;
		
		
		}

function ResAP_Introduce()

{
	//alert("resap_client:60");
	var objwi=window.top.wi_object;
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	if(!ResAP_Save())
		{
		return false;
		}
		
		
	if(!ResAP_checkmandatory_Save())
		{
		  return false;
			  
		}
	if(!Check_Mandatory_Doctype())
		return false;
	if(trim(objDataForm.Priority.value)=="Urgent")
		{
		//alert("sff:"+objwi.attribute_list["PriorityLevel"]);
		isModified(objwi.attribute_list["PriorityLevel"],"3");
		}
		
	return true;

}

function ResAP_checkmandatory_Save()

{ 
	var objwi=window.top.wi_object;
	var sWname=objwi.workstep_name.toUpperCase();
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	
		if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING" || sWname.toUpperCase()=="CANCEL_WI" || sWname.toUpperCase()=="PENDING_RESOLUTION" || sWname.toUpperCase()=="RESCAN_WI" || sWname.toUpperCase()=="SPLIT_DOCS")
		{
			//alert("Just Before");
			if(window.parent.frames["left"].document.getElementById('tab2').style.display=="block")
				{
					window.parent.frames["left"].document.getElementById('tab2').style.display="none";
					window.parent.frames["left"].document.getElementById('tab1').style.display="block";
				}
			
		}

		if(sWname.toUpperCase()=="WORK INTRODUCTION")
		{		
			
			if(!(ResAP_checkmandatory_Work_Intro(objDataForm)))
			{
               return false; 
			}
		}
	
	if(sWname.toUpperCase()=="INDEXING")

		{
			
			//alert("Raised Value : "+sRaisedExp);

					////Remove on 16th June 2008(Tarit Gupta)
					/////Added on 11th June 2008(Santul Sharma)
					
					/*if(sRaisedExp=="1")
					{
						if(objDataForm.Exception_Comments.value=="")
						{
							alert("Kindly enter the Exception Raise Comments");
							window.parent.frames["left"].document.getElementById('tab2').style.display="block";
							window.parent.frames["left"].document.getElementById('tab1').style.display="none";
							objDataForm.Exception_Comments.focus(true);
							return false;
						}
						else
						{
							return true;
						}
					}*/

					/////Added on 11th June 2008(Santul Sharma)
					////Remove on 16th June 2008(Tarit Gupta)

			
			if(!(ResAP_checkmandatory_Indexing(objDataForm)))
			{
			   
               return false; 
			}
			
		}	
	if(sWname.toUpperCase()=="PROCESSING")

		{

					////Remove on 16th June 2008(Tarit Gupta)
					/////Added on 11th June 2008(Santul Sharma)

					//alert("sRaisedExp : "+sRaisedExp);
					
					/*if(sRaisedExp=="1")
					{
						if(objDataForm.Exception_Comments.value=="")
						{
							alert("Kindly enter the Exception Raise Comments");
							window.parent.frames["left"].document.getElementById('tab2').style.display="block";
							window.parent.frames["left"].document.getElementById('tab1').style.display="none";
							objDataForm.Exception_Comments.focus(true);
							return false;
						}
						else
						{
							return true;
						}
					}*/

					/////Added on 11th June 2008(Santul Sharma)
					////Remove on 16th June 2008(Tarit Gupta)



			 if(!(ResAP_checkmandatory_Processing(objDataForm)))
				{
				return false;
				}
		}	

	if(sWname.toUpperCase()=="CANCEL_WI")

		{
			 if(!(ResAP_checkmandatory_Cancel_Wi(objDataForm)))
				{
				return false;
				}
		}
		if(sWname.toUpperCase()=="PENDING_RESOLUTION")

		{
			 
			 if(!(ResAP_checkmandatory_Pending_Resolution(objDataForm)))
				{
				return false;
				}
		}

		////Uncommented on 12th June 2008(Santul Sharma)
		if(sWname.toUpperCase()=="RESCAN_WI")
		{
			 if(!(ResAP_checkmandatory_Rescan_Wi(objDataForm)))
				{
				return false;
				}
		}
		////Uncommented on 12th June 2008(Santul Sharma)
		if(sWname.toUpperCase()=="SPLIT_DOCS")

		{
			 if(!(ResAP_checkmandatory_Split_Docs(objDataForm)))
				{
				return false;
				}
		}
		if(sWname.toUpperCase()=="VALIDATION")

		{
			
			 if(!(ResAP_checkmandatory_Validation(objDataForm)))
				{
				return false;
				}
		}
		if(sWname.toUpperCase()=="APPROVAL")

		{
			
			 if(!(ResAP_checkmandatory_Approval(objDataForm)))
				{
				return false;
				}
		}	


return true;


}



function ResAP_checkmandatory_Work_Intro(objDataForm)
	{
					if(objDataForm.Document_Type.value=="" )
					{
						alert("Select the Document Type.");
						objDataForm.Document_Type.focus();
						return false;
					}	
					if(objDataForm.Priority.value=="" )
					{
						alert("Select the Priority.");
						objDataForm.Priority.focus();
						return false;
					}
				return true;


	}

function ResAP_checkmandatory_Indexing(objDataForm)
	{
			var objwi=window.top.wi_object;
					
					

					if(objDataForm.Document_Category.value=="Archival" && objDataForm.Document_Type.value=="Other" )
					{
						alert("Document type can not be Other as Document Category is Archival.");
						objDataForm.Document_Type.focus();
						return false;
					}	
					if(objDataForm.Document_Type.value=="" )
					{
						alert("Select the Document Type.");

						objDataForm.Document_Type.focus();
						return false;
					}
			//Added by bhawna for PLMIC_04 on 11-sep-2008
		if(objDataForm.Document_Type.value!="Other")
		{
					if(objDataForm.Document_Category.value=="" )
					{
						alert("Select the Document Category.");

						objDataForm.Document_Category.focus();
						return false;
					}	
				
				if(sRaisedExp!="1")
					{
					
					if(trim(objDataForm.Setid.value)=="" )
					{
						alert("Select the Setid.");
						
						objDataForm.Setid.focus();
						return false;
					}
					
					if(trim(objDataForm.AP_Business_Unit.value)=="" )
					{
						alert("Select AP Business Unit.");
						objDataForm.AP_Business_Unit.focus();
						return false;
					}
					if(trim(objDataForm.Vendor_Name.value)=="" )
					{
						alert("Vendor Name can not be blank.");
						objDataForm.SearchVName.focus();
						return false;
					}
					if(trim(objDataForm.Vendor_ID.value)=="" )
					{
						alert("Vendor ID number can not be blank.");
						objDataForm.Vendor_ID.focus();
						return false;
					}
					
					
					if(trim(objDataForm.Invoice_Number.value)=="" )
					{
						alert("Invoice Number can not be blank.");
						objDataForm.Invoice_Number.focus();
						return false;
					}
					if(trim(objDataForm.Invoice_Date.value)=="" )
					{
						alert("Invoice Date can not be blank.");
						objDataForm.Invoice_Date.select();
						window.parent.frames["left"].document.getElementById("Date_IMG").focus();
						//objDataForm.Invoice_Date.focus();
						return false;
					}
					
					if(trim(objDataForm.TempAmount.value)=="" )
					{
						alert("Amount can not be blank.");

						objDataForm.TempAmount.focus();
						return false;
					}
					
					if(trim(objDataForm.Received_Date.value)=="" )
					{
						alert("Received Date can not be blank.");

						objDataForm.Received_Date.select();
						window.parent.frames["left"].document.getElementById("Date_IMG1").focus();
						//objDataForm.Received_Date.focus();
						return false;
					}
					if(trim(objDataForm.Due_Date.value)=="" )
					{
						alert("Due Date can not be blank.");

						
						objDataForm.Due_Date.select();
						window.parent.frames["left"].document.getElementById("Date_IMG2").focus();
						//objDataForm.Due_Date.focus();
						return false;
					}
					if(objDataForm.Priority.value=="" )
					{
						alert("Select the Priority.");

						objDataForm.Priority.focus();

						return false;
					}
					}
		}
					if(trim(objDataForm.Exception_Comments.value)=="" && sRaisedExp=="1")
					{
						alert("Exception Comments can not be blank.");
									
						window.parent.frames["left"].document.getElementById("tab1").style.display='none';
						window.parent.frames["left"].document.getElementById("tab2").style.display='block';

						objDataForm.Exception_Comments.focus();

						return false;
					}
					
														
				return true;

	}

function ResAP_checkmandatory_Processing(objDataForm)
	{
		if(objDataForm.Document_Type.value=="" )
		{
			alert("Select the Document Type.");
			objDataForm.Document_Type.focus();
			return false;
		}
			
	
		if(objDataForm.Document_Category.value=="Archival" && objDataForm.Document_Type.value=="Other" )
		{
			alert("Document type can not be Other as Document Category is Archival.");
			objDataForm.Document_Category.focus();
			return false;
		}
		//Added by bhawna for PLMIC_04 on 11-sep-2008
		if(objDataForm.Document_Type.value!="Other")
		{
	
		if(sRaisedExp!="1")
		{
			if(objDataForm.Document_Category.value=="" )
		{
			alert("Select the Document Category.");
			objDataForm.Document_Category.focus();
			return false;
		}	
		if(trim(objDataForm.Setid.value)=="" )
		{
			alert("Select Setid.");
			objDataForm.Setid.focus();
			return false;
		}
		if(trim(objDataForm.AP_Business_Unit.value)=="" )
		{
			alert("Enter the AP Business Unit.");
			objDataForm.AP_Business_Unit.focus();
			return false;
		}
		if(trim(objDataForm.Vendor_Name.value)=="" )
		{
			alert("Vendor Name can not be blank.");
			objDataForm.SearchVName.focus();
			return false;
		}
		if(trim(objDataForm.Vendor_ID.value)=="" )
		{
			alert("Vendor ID can not be blank.");
			objDataForm.Vendor_ID.focus();
			return false;
		}
		
		if(trim(objDataForm.Invoice_Number.value)=="" )
		{
			alert("Select Invoice Number.");
			objDataForm.Invoice_Number.focus();
			return false;
		}
		if(trim(objDataForm.Invoice_Date.value)=="" )
		{
			alert("Invoice Date can not be blank.");
			objDataForm.Invoice_Date.select();
			window.parent.frames["left"].document.getElementById("Date_IMG").focus();
			//objDataForm.Invoice_Date.focus();
			return false;
		}
		
		if(trim(objDataForm.TempAmount.value)=="" )
		{
			alert("Amount can not be blank.");
			objDataForm.TempAmount.focus();
			return false;
		}
		
		if(trim(objDataForm.Received_Date.value)=="" )
		{
			alert("Received Date can not be blank.");
			objDataForm.Received_Date.select();
			window.parent.frames["left"].document.getElementById("Date_IMG1").focus();
			//objDataForm.Received_Date.focus();
			return false;
		}
		if(trim(objDataForm.Due_Date.value)=="" )
		{
			alert("Due Date can not be blank.");
			objDataForm.Due_Date.select();
			window.parent.frames["left"].document.getElementById("Date_IMG2").focus();
			//objDataForm.Due_Date.focus();
			return false;
		}
		if(objDataForm.Priority.value=="" )
		{
			alert("Select the Priority.");
			objDataForm.Priority.focus();
			return false;
		}
		if(trim(objDataForm.PS_Voucher_ID.value)=="" )
		{
			alert("PS Voucher ID can not be blank.");
			objDataForm.PS_Voucher_ID.focus();
			return false;
		}
		
		}
		}
		if(trim(objDataForm.Exception_Comments.value)=="" && sRaisedExp=="1")
			{
				window.parent.frames["left"].document.getElementById("tab1").style.display='none';
				window.parent.frames["left"].document.getElementById("tab2").style.display='block';
				alert("Exception Comments can not be blank.");

				objDataForm.Exception_Comments.focus();

				return false;
			}

		
	return true;

	}
	////Uncommented on 12th June 2008(Santul Sharma)
	function ResAP_checkmandatory_Rescan_Wi(objDataForm)

		{
			var sxception=checkallexcepcleared(objDataForm);

			if(sxception=="1") 
			{
				alert("Please Clear All Raised Exceptions");
				window.parent.frames["left"].document.getElementById("tab1").style.display='none';
				window.parent.frames["left"].document.getElementById("tab2").style.display='block';
				return false;
			}

			////Added on 12th June 2008(Santul Sharma)


			if(sxception=="0" && trim(objDataForm.Exception_Resol_Comments.value)=="")
			{
					alert("Exception Resolution Comments can not be blank.");
					window.parent.frames["left"].document.getElementById("tab1").style.display='none';
					window.parent.frames["left"].document.getElementById("tab2").style.display='block';
					objDataForm.Exception_Resol_Comments.focus();
					return false;
			}
		
			////Added on 12th June 2008(Santul Sharma)
			return true;
		}
		////Uncommented on 12th June 2008(Santul Sharma)

	function ResAP_checkmandatory_Cancel_Wi(objDataForm)

		{
			
			var sxception=checkallexcepcleared(objDataForm);

			if(objDataForm.Cancel_Decision.value=="" )
			{
					alert("Select the Cancel Decision.");

					window.parent.frames["left"].document.getElementById("tab1").style.display='block';
					window.parent.frames["left"].document.getElementById("tab2").style.display='none';
					objDataForm.Cancel_Decision.focus();
					return false;
			}

			if(objDataForm.Cancel_Decision.value=="Reject" && trim(objDataForm.Cancel_Decision_Comments.value)=="")
			{
					alert("Cancel Decision Comments can not be blank.");
					objDataForm.Cancel_Decision_Comments.focus();
					return false;
			}
			
			////Uncommented on 12th June 2008(Santul Sharma)

			if(sxception=="1" && objDataForm.Cancel_Decision.value!="Approved") 
			{
				
				window.parent.frames["left"].document.getElementById("tab1").style.display='none';
				window.parent.frames["left"].document.getElementById("tab2").style.display='block';
				alert("Please Clear All Raised Exceptions");
				return false;
			}
			
			////Uncommented on 12th June 2008(Santul Sharma)
			
			

			////Added on 11th June 2008(Santul Sharma)

			if(objDataForm.Cancel_Decision.value!="Approved" && trim(objDataForm.Exception_Resol_Comments.value)=="")
			{
					alert("Exception Resolution Comments can not be blank.");
					window.parent.frames["left"].document.getElementById("tab1").style.display='none';
					window.parent.frames["left"].document.getElementById("tab2").style.display='block';
					objDataForm.Exception_Resol_Comments.focus();
					return false;
			}
		
			////Added on 11th June 2008(Santul Sharma)


				return true;

		}

		function ResAP_checkmandatory_Pending_Resolution(objDataForm)
			{
			var sxception=checkallexcepcleared(objDataForm);
			
			if(sxception=="1") 
			{
				
				window.parent.frames["left"].document.getElementById("tab1").style.display='none';
				window.parent.frames["left"].document.getElementById("tab2").style.display='block';
				alert("Please Clear All Raised Exceptions");
				return false;
			}
			/*if(sxception=="0" && objDataForm.Exception_Resol_Comments.value=="")
			{
				window.parent.frames["left"].document.getElementById("tab1").style.display='none';
				window.parent.frames["left"].document.getElementById("tab2").style.display='block';
				alert("Exception Resol Comments can not be blank.");
				objDataForm.Exception_Resol_Comments.focus();
				return false;
			}*/
			////Added on 11th June 2008(Santul Sharma)

				///Change 16th June 2008(Tarit Gupta)
			if(trim(objDataForm.Exception_Resol_Comments.value)=="")
			{
			///Change 16th June 2008(Tarit Gupta)
					
					alert("Exception Resolution Comments can not be blank.");
					window.parent.frames["left"].document.getElementById("tab1").style.display='none';
					window.parent.frames["left"].document.getElementById("tab2").style.display='block';
					objDataForm.Exception_Resol_Comments.focus();
					return false;
			}
		
			////Added on 11th June 2008(Santul Sharma)
			if(trim(objDataForm.Forward_To.value)=="" )
			{
					window.parent.frames["left"].document.getElementById("tab1").style.display='block';
					window.parent.frames["left"].document.getElementById("tab2").style.display='none';
					alert("Select the Forward To.");
					objDataForm.Forward_To.focus();
					return false;
			}
			return true;
			}

function ResAP_checkmandatory_Split_Docs(objDataForm)
{
			var sxception=checkallexcepcleared(objDataForm);

			
			if(objDataForm.Split_Doc_Decision.value=="" )
				{
					alert("Select the Split Doc Decision.");
					objDataForm.Split_Doc_Decision.focus();
					return false;
				}
				if(trim(objDataForm.No_Of_WI_Created.value)=="" && objDataForm.Split_Doc_Decision.value=="Accept" )
				{
					alert("No Of WI Created can not be blank.");
					objDataForm.No_Of_WI_Created.focus();
					return false;
				}
				if(trim(objDataForm.WI_Serial_Number.value)=="" && objDataForm.Split_Doc_Decision.value=="Accept" )
				{
					alert("WI Serial Number can not be blank.");
					objDataForm.WI_Serial_Number.focus();
					return false;
				}
				if(objDataForm.Split_Doc_Decision.value=="Accept" && parseInt(objDataForm.No_Of_WI_Created.value)=="0")
			{
					
					alert("No of Workitems created cannot be zero.");
					window.parent.frames["left"].document.getElementById("tab1").style.display='block';
					window.parent.frames["left"].document.getElementById("tab2").style.display='none';
					objDataForm.No_Of_WI_Created.focus();
					return false;
			}

				////Added on 11th June 2008(Santul Sharma)

		if(sxception=="1") 
			{
				alert("Please Clear All Raised Exceptions");
				window.parent.frames["left"].document.getElementById("tab1").style.display='none';
				window.parent.frames["left"].document.getElementById("tab2").style.display='block';
				return false;
			}
			if(trim(objDataForm.Exception_Resol_Comments.value)=="")
			{
					alert("Exception Resolution Comments can not be blank.");
					window.parent.frames["left"].document.getElementById("tab1").style.display='none';
					window.parent.frames["left"].document.getElementById("tab2").style.display='block';
					objDataForm.Exception_Resol_Comments.focus();
					return false;
			}
			
			
		
			////Added on 11th June 2008(Santul Sharma)

return true;

}
 function ResAP_checkmandatory_Validation(objDataForm)
 {
 
			 if(trim(objDataForm.Validation.value)=="" )
				{
					alert("Select the Validation.");
					objDataForm.Validation.focus();
					return false;
				}
				if(trim(objDataForm.Validation_Comments.value)=="" && trim(objDataForm.Validation.value)=="Fail")//Change No:Res_18
				{
					alert("Validation Comments can not be blank.");
					objDataForm.Validation_Comments.focus();
					return false;
				}
 return true;
 
 
 }

 function ResAP_checkmandatory_Approval(objDataForm)

{
				if(objDataForm.Approval.value=="" )
				{
					alert("Select Approval decision.");
					objDataForm.Approval.focus();
					return false;
				}
				if(trim(objDataForm.Approval_Comments.value)=="" && trim(objDataForm.Approval.value)=="No")
				{
					alert("Approval Comments can not be blank.");
					objDataForm.Approval_Comments.focus();
					return false;
				}

return true;
}



function isModified(oldVal,newVal)
	{
		//alert(" is in modified");
	 if(oldVal.value!=newVal)
	 {
	  oldVal.value=newVal;
	  
	  oldVal.modified_flag=true;
	 }
	}

function fnSelectVName()
	{
		
		if(document.dataform.AP_Business_Unit.value=='')
		{
			alert("Kindly select the AP Business Unit First");
			document.dataform.AP_Business_Unit.focus(true);
			return false;

		}

		var sFeatures="dialogHeight:500px; dialogWidth:575px; status:no; dialogHide:no;";
		var sVendorInfo=window.showModalDialog("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\ResAP\\SearchVenderNameMain.jsp?BusinessUnitURL='"+document.dataform.AP_Business_Unit.value+"'",'',sFeatures);
		//alert("sVendorInfo"+sVendorInfo);
		if(sVendorInfo!=undefined)
		{
			var sVendorData= sVendorInfo.split('\025');
			document.dataform.Vendor_ID.value=sVendorData[0];
			//alert("sVendorData[1] "+sVendorData[1]);
			document.dataform.Vendor_Name.value=sVendorData[1];
			//document.dataform.BusinessUnitModalDialog.value=sVendorData[2];
		}
	}

function checkboxRaised(objWI_objwi,objDataForm)
{	
	var flag=0;            ///to indicate no exception is checked but if one is checked then set flag as 1
	for (var i=0;i<objDataForm.elements.length ;i++ )
	 {
		var sAttrName=objDataForm.elements[i].name.substring(3);
		//alert("vhk cancel");
		if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
		{
			
			if(objDataForm.elements[i].disabled ==false && objDataForm.elements[i].checked)
			{
				//alert("exp name"+objDataForm.elements[i].name);
				isModified(objWI_objwi.attribute_list[sAttrName],"1");
				flag=1;
			}
			 else if(objDataForm.elements[i].disabled ==false)
			{			 
				//alert(objWI_objwi.attribute_list[sAttrName].name); 
				isModified(objWI_objwi.attribute_list[sAttrName],"");
				
			}
		}
		
	 }
	
	return flag;
	
}

function checkboxClear(objWI_objwi,objDataForm,sMode)
{		
	var flag=0;            ///to indicate no exception is checked but if one is checked then set flag as 1
	for (var i=0;i<objDataForm.elements.length ;i++ )
	 {
		var sAttrName=objDataForm.elements[i].name.substring(3);
		//alert(objDataForm.elements[i].name.substring(0,3));
		if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="clr" )
		{
			
			//alert("---"+sMode);
			if(objDataForm.elements[i].disabled ==false && objDataForm.elements[i].checked)
			{				
				if(sMode=="D")
					isModified(objWI_objwi.attribute_list[sAttrName],"0");
				else
					isModified(objWI_objwi.attribute_list[sAttrName],"2");
			}
			else if(objWI_objwi.attribute_list[sAttrName].value==2)
			{
				isModified(objWI_objwi.attribute_list[sAttrName],"1");
			}
			//	isModified(objWI_objwi.attribute_list[sAttrName],"");
		}
		
	 }
	
	return true;
	
}
function getExceptionList(objDataForm,sWname)
{	
	var stringtosend="";
		for ( i=0; i < objDataForm.elements.length ; i++)
		{	
			if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].checked==true )
			{	if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING")
				{
				// alert(objDataForm.elements[i].name);
				 stringtosend += "~" + objDataForm.elements[i].name + "-" +"0";
				}
				else if(sWname.toUpperCase()=="RESCAN_WI" || sWname.toUpperCase()=="PENDING_RESOLUTION" || sWname.toUpperCase()=="CANCEL_WI" || sWname.toUpperCase()=="SPLIT_DOCS")
				{
					
				if(objDataForm.elements[i].name.substring(objDataForm.elements[i].name,3)=="clr")
				 stringtosend += "~" + objDataForm.elements[i].name + "-" +"1";
				if(objDataForm.elements[i].name.substring(objDataForm.elements[i].name,3)=="chk" && objDataForm.elements[i].disabled==false)
					stringtosend += "~" + objDataForm.elements[i].name + "-" +"0";
				}

			}
		}
		
		//alert(stringtosend.substring(1,stringtosend.length));
	return stringtosend.substring(1,stringtosend.length);	
}

function UpdateExpData()
{
	
	var objwi=window.top.wi_object;
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
    var sWname=objwi.workstep_name.toUpperCase();
	var sWiName=objwi.attribute_list["WorkItemName"].value;
	var scheckedboxes=getExceptionList(objDataForm,sWname);

	//alert(scheckedboxes);
	
//alert(scheckedboxes);
		if (scheckedboxes!="")
			{
			
				try
					{
												
						if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING")
						{	
								
							var ExceptionRasiedcomments=trim(objDataForm.Exception_Comments.value);
						
							
							ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\ResAP\\ResAP_Exp_Data.jsp","sProcessinstanceid="+encodeURIComponent(sWiName)+"&sWrkStepname="+encodeURIComponent(sWname)+"&sExpData="+encodeURIComponent(scheckedboxes)+"&sExceptionRasiedcomments="+encodeURIComponent(ExceptionRasiedcomments)+"&sExceptionRAISEDDATETIME="+encodeURIComponent("")+"&sExceptionResolvedcomments="+encodeURIComponent(""));	
						
						}
						else if(sWname.toUpperCase()=="RESCAN_WI" || sWname.toUpperCase()=="PENDING_RESOLUTION" || sWname.toUpperCase()=="CANCEL_WI" || sWname.toUpperCase()=="SPLIT_DOCS")
						{
							
							var ExceptionClearcomments=trim(objDataForm.Exception_Resol_Comments.value);
	
						//alert("994");
						//alert("Data : "+scheckedboxes);
						ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\ResAP\\ResAP_Exp_Data.jsp","sProcessinstanceid="+encodeURIComponent(sWiName)+"&sWrkStepname="+encodeURIComponent(sWname)+"&sExpData="+encodeURIComponent(scheckedboxes)+"&sExceptionRasiedcomments="+encodeURIComponent("")+"&sExceptionRAISEDDATETIME="+encodeURIComponent("")+"&sExceptionResolvedcomments="+encodeURIComponent(ExceptionClearcomments));	

						}
						//alert("at 135");
					//alert("iAjaxMainCode"+iAjaxMainCode);
					//alert("sAjaxReturnValue"+sAjaxReturnValue);
						if (iAjaxMainCode=="15")
							{
							alert('Error in updating Exception Details.');
							return false;
							}
						else if (sAjaxReturnValue!="Success")
							{
						alert('Error in updating Exception Details.');
						return false;
							}
					
					}
					catch(e)
					{
					alert('Error in updating Exception Details.');
					//alert(e.toString());
					return false;
					}
			}
     return true;  
}
function checkallexcepcleared(objDataForm)
{
	var flag=0;  // If flag is zero then user has not checked any of the raised exception else if he has cleared all raised exp then we set flag as 1
	for ( i=0; i < objDataForm.elements.length ; i++)
		{
			 if(objDataForm.elements[i].type=="checkbox")
			{
				//alert(objDataForm.elements[i].name.substring(objDataForm.elements[i].name,3));
				
				if(objDataForm.elements[i].name.substring(objDataForm.elements[i].name,3)=="clr" && objDataForm.elements[i].disabled==false)
				{	//alert(objDataForm.elements[i].disabled);
					
					if(objDataForm.elements[i].checked==false)
					flag =1; //this means that there is at least 1 clr checkbox that is checked 
					
				}
			}
		}
		return flag;
}

function ResAp_SaveAtDone()
{
		//alert("save at done");

	var sWname=window.top.wi_object.workstep_name.toUpperCase();
	var objwi=window.top.wi_object;
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var sWiName=objwi.attribute_list["WorkItemName"].value;
	var sSplitVal=sWiName.split('-');
	var iWINo=parseFloat(sSplitVal[1]);
	var sPreviousWorkStep="";
	
	if(sWname.toUpperCase()=="WORK INTRODUCTION")
		sPreviousWorkStep=null;
	else
		sPreviousWorkStep=window.top.wi_object.attribute_list["Previous_Wrk_Step"].value;

	//if(sWname.toUpperCase()=="INTRODUCTION")
	//	sPreviousWorkStep=null;
	//else
	//	sPreviousWorkStep=window.top.wi_object.attribute_list["Previous_Wrk_Step"].value;
	//ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\WNSEA\\AP\\AP_Done_Data.jsp","iWINo="+encodeURIComponent(iWINo)+"&sWiName="+encodeURIComponent(sWiName)+"&sCurrentDateTime="+window.top.wi_object.attribute_list["CurrentDateTime"].value+"&sENTRYDATETIME="+window.top.wi_object.attribute_list["EntryDateTime"].value+"&sCurrentWorkStep="+sWname+"&sUerID="+encodeURIComponent(objDataForm.User_Name.value)+"&sPreviousWorkStep="+encodeURIComponent(sPreviousWorkStep));
	//alert(objDataForm.User_Name.value);
	//alert(sWiName);
	//alert(window.top.wi_object.attribute_list["EntryDateTime"].value);
	//alert(sWiName);
	
	ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\ResAP\\ResAP_Done_Data.jsp","sWiName="+encodeURIComponent(sWiName)+"&sENTRYDATETIME="+window.top.wi_object.attribute_list["EntryDateTime"].value+"&sCurrentWorkStep="+sWname+"&sPreviousWorkStep="+sPreviousWorkStep);
	//alert(iAjaxMainCode);
	if (iAjaxMainCode=="15")
		{
			alert('Error in updating ResAP Done .');
			return false;
		}
	else if (sAjaxReturnValue!="Success")
		{
			alert('Error in updating ResAP Done .');
			return false;
		}
return true;

}
			
			
function Check_For_Route_Exception()		
		{	

			

		var sWname=window.top.wi_object.workstep_name.toUpperCase();
		var objDataForm= window.parent.frames["left"].document.forms["dataform"];

		if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING")
		{
			
			
			if((objDataForm.chkExcp_Bad_Image.checked==true) && (objDataForm.chkExcp_New_Vendor_Setup.checked==true || objDataForm.chkExcp_Not_An_Invoice.checked==true || objDataForm.chkExcp_Missing_Incorrect_Approval.checked==true || objDataForm.chkExcp_Missing_Documentation.checked==true || objDataForm.chkExcp_Invalid_Cost_Center_Account.checked==true || objDataForm.chkExcp_Fixed_Asset_Coding.checked==true || objDataForm.chkExcp_Duplicate.checked==true || objDataForm.chkExcp_Multiple_Documents.checked==true))
			{
			window.parent.frames["left"].document.getElementById("tab1").style.display='none';
			window.parent.frames["left"].document.getElementById("tab2").style.display='block';
			alert("Exception of different category can not be raised simultaneously,Please select similar category of exception to proceed.");
			return false;
			}
			else if((objDataForm.chkExcp_New_Vendor_Setup.checked==true || objDataForm.chkExcp_Missing_Incorrect_Approval.checked==true || objDataForm.chkExcp_Missing_Documentation.checked==true || objDataForm.chkExcp_Invalid_Cost_Center_Account.checked==true || objDataForm.chkExcp_Fixed_Asset_Coding.checked==true) && (objDataForm.chkExcp_Duplicate.checked==true || objDataForm.chkExcp_Not_An_Invoice.checked==true || objDataForm.chkExcp_Multiple_Documents.checked==true))
			{
			window.parent.frames["left"].document.getElementById("tab1").style.display='none';
			window.parent.frames["left"].document.getElementById("tab2").style.display='block';
			alert("Exception of different category can not be raised simultaneously,Please select similar category of exception to proceed.");
			return false;
			}
			else if((objDataForm.chkExcp_Not_An_Invoice.checked==true || objDataForm.chkExcp_Duplicate.checked==true) && (objDataForm.chkExcp_New_Vendor_Setup.checked==true || objDataForm.chkExcp_Missing_Incorrect_Approval.checked==true || objDataForm.chkExcp_Missing_Documentation.checked==true || objDataForm.chkExcp_Invalid_Cost_Center_Account.checked==true || objDataForm.chkExcp_Fixed_Asset_Coding.checked==true || objDataForm.chkExcp_Multiple_Documents.checked==true))
			{
			
			window.parent.frames["left"].document.getElementById("tab1").style.display='none';
			window.parent.frames["left"].document.getElementById("tab2").style.display='block';
			alert("Exception of different category can not be raised simultaneously,Please select similar category of exception to proceed.");
			return false;
			}
			
			else if((objDataForm.chkExcp_Multiple_Documents.checked==true) && (objDataForm.chkExcp_New_Vendor_Setup.checked==true || objDataForm.chkExcp_Missing_Incorrect_Approval.checked==true || objDataForm.chkExcp_Missing_Documentation.checked==true || objDataForm.chkExcp_Invalid_Cost_Center_Account.checked==true || objDataForm.chkExcp_Fixed_Asset_Coding.checked==true || objDataForm.chkExcp_Duplicate.checked==true || objDataForm.chkExcp_Not_An_Invoice.checked==true || objDataForm.chkExcp_Duplicate.checked==true ))
			{
			window.parent.frames["left"].document.getElementById("tab1").style.display='none';
			window.parent.frames["left"].document.getElementById("tab2").style.display='block';
			alert("Exception of different category can not be raised simultaneously,Please select similar category of exception to proceed.");
			return false;
			}
			

		}
		return true;
	}

	function RemoveComma_ResAP()
{
		var objDataForm=window.parent.frames["left"].document.forms["dataform"];
		var sTransactionAmount=objDataForm.TempAmount.value;
		var sAmount="";
		for (var i=0; i<sTransactionAmount.length; i++)
		{
			if(sTransactionAmount.substring(i,i+1)!=",")
				sAmount =sAmount + sTransactionAmount.substring(i, i+1);
		}
		return sAmount;

}


function fetch_Vname_InvoiceNo()

{
//alert("fetch_Vname_InvoiceNo");
	var objwi=window.top.wi_object;
	var sWname=objwi.workstep_name.toUpperCase();
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var sVname=trim(objDataForm.Vendor_Name.value);
	var sInvoice_No=trim(objDataForm.Invoice_Number.value);
	var sWiName=objwi.attribute_list["WI_Name"].value;
		//Added by Bhawna 11-09-2008 for PLMIC_03
	var sVendorID=trim(objDataForm.Vendor_ID.value);
	
ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\ResAP\\ResAP_fetch_Vname_InvoiceNo.jsp","sVname="+encodeURIComponent(sVname)+"&sInvoice_No="+encodeURIComponent(sInvoice_No)+"&sWiName="+encodeURIComponent(sWiName)+"&sVendorID="+encodeURIComponent(sVendorID));

	//alert("sAjaxReturnValue111"+sAjaxReturnValue);
	if(sAjaxReturnValue=="Fail")
		{
		var Confirm = confirm("Duplicate Vendor Name and Invoice Number,Do you want to cancel the Work Item.");
		
				if(Confirm)
				isModified(objwi.attribute_list["Excp_Duplicate"],"1");
				else
					return false;
		}




return true;
}


function fetch_Vname_BusinessUnit()

{
//alert("Custom Function");
	var objwi=window.top.wi_object;
	var sWname=objwi.workstep_name.toUpperCase();
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var sVname=trim(objDataForm.Vendor_Name.value);
	var sVendorId=trim(objDataForm.Vendor_ID.value);
	var sBusinessUnit=trim(objDataForm.AP_Business_Unit.value);
	var sWiName=objwi.attribute_list["WI_Name"].value;
	
	
ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\ResAP\\Retrieve_Business_Unit.jsp","APBusinessUnit="+encodeURIComponent(sBusinessUnit)+"&VendorName="+encodeURIComponent(sVname)+"&VendorID="+encodeURIComponent(sVendorId)+"&WIName="+encodeURIComponent(sWiName));//Bug No:Res_1

	//alert("Comparison Value Required : "+sAjaxReturnValue);
	

	if(sBusinessUnit!=sAjaxReturnValue)//Bug No:Res_27,Res_29
	{
		alert("Mismatch in the selected AP Business Unit and the Vendor Data"); //Bug No:Res_2
		window.parent.frames["left"].document.getElementById("tab1").style.display='block';
		window.parent.frames["left"].document.getElementById("tab2").style.display='none';
		objDataForm.AP_Business_Unit.focus(true);
		return false;
	}
	/*	
		if(sAjaxReturnValue=="Fail")
		{
		var Confirm = confirm("Duplicate Vendor Name and Invoice Number,Do you want to cancel the Work Item.");
		
				if(Confirm)
				isModified(objwi.attribute_list["Excp_Duplicate"],"1");
				else
					return false;
		}
	
	*/



return true;
}



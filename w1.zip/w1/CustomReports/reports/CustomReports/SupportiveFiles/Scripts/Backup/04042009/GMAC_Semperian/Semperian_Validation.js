/*
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : WNS-GMAC-SBR
Module : 
File Name : 
Author :   Tarit
Date written (DD/MM/YYYY) : 
Description : This JS File Contains load functions for all Workstep which is further included in all jsp forms
----------------------------------------------------------------------------------------------------

CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date Change By Change Description (Bug No. (If Any))
(DD/MM/YYYY)
----------------------------------------------------------------------------------------------------
*/ 
function load()
{	
	
	var objwi=window.top.wi_object;
    var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
	var sWname=objwi.workstep_name.toUpperCase();

	
	
			
			if (sWname.toUpperCase()=="WORK INTRODUCTION")
			{	

				objDataForm.Reconciliation_type.focus();

				if(objwi.attribute_list["Reconciliation_type"].value!="" )
				{

				objDataForm.Reconciliation_type.value=objwi.attribute_list["Reconciliation_type"].value;

				}

				if(objwi.attribute_list["Reconciliation_Date_From"].value!="" )
				{

				var retdate=convertdatenew(objwi.attribute_list['Reconciliation_Date_From'].value);
				objDataForm.Reconciliation_Date_From.value=retdate;
				}
				if(objwi.attribute_list["Reconciliation_Date_To"].value!="" )
				{

				//objDataForm.Reconciliation_Date_To.value=objwi.attribute_list["Reconciliation_Date_To"].value;
				var retdate=convertdatenew(objwi.attribute_list['Reconciliation_Date_To'].value);
				objDataForm.Reconciliation_Date_To.value=retdate;
				}




			}
  



			if (sWname.toUpperCase()=="PROCESSING")
			{	


				objDataForm.Reconciliation_type.focus();

				//alert(objwi.attribute_list["Reconciliation_type"].value);
				if(objwi.attribute_list["Reconciliation_type"].value!="")
				{

				objDataForm.Reconciliation_type.value=objwi.attribute_list["Reconciliation_type"].value;

				}
				if(objwi.attribute_list["Reconciliation_Date_From"].value!="" )
				{

				var retdate=convertdatenew(objwi.attribute_list['Reconciliation_Date_From'].value);
				objDataForm.Reconciliation_Date_From.value=retdate;
				}
				if(objwi.attribute_list["Reconciliation_Date_To"].value!="" )
				{

				//objDataForm.Reconciliation_Date_To.value=objwi.attribute_list["Reconciliation_Date_To"].value;
				var retdate=convertdatenew(objwi.attribute_list['Reconciliation_Date_To'].value);
				objDataForm.Reconciliation_Date_To.value=retdate;
				}

				if(objwi.attribute_list["Bank_Account_Number"].value!="")
				{

				objDataForm.Bank_Account_Number.value=objwi.attribute_list["Bank_Account_Number"].value;

				}
				//onchangedoctype(objDataForm);

				if(objwi.attribute_list["Bank_Statement_Balance"].value!="")
				{

				objDataForm.fBank_Statement_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Bank_Statement_Balance"]);

				}

				if(objwi.attribute_list["Bank_Statement_GL_Balance"].value!="")
				{

				objDataForm.fBank_Statement_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Bank_Statement_GL_Balance"]);

				}



				if(objwi.attribute_list["Balance_Forward_Escheats"].value!="" )
				{

				objDataForm.fBalance_Forward_Escheats.value=DollarAmount_commaNeg(objwi.attribute_list["Balance_Forward_Escheats"]);

				}


				if(objwi.attribute_list["Current_Period_Escheats"].value!="" )
				{

				objDataForm.fCurrent_Period_Escheats.value=DollarAmount_commaNeg(objwi.attribute_list["Current_Period_Escheats"]);

				}  

				if(objwi.attribute_list["Other_Adjustments"].value!="" )
				{

				objDataForm.fOther_Adjustments.value=DollarAmount_commaNeg(objwi.attribute_list["Other_Adjustments"]);

				}   


				
				//Removed by Tarit gupta as on 07-07-08
				/*if(objwi.attribute_list["Total_Check_GL_Balance"].value!="" )
				{

				objDataForm.fTotal_Check_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Total_Check_GL_Balance"]);


				}*/

				//Removed by Tarit gupta as on 07-07-08

				if(objwi.attribute_list["Check_Outstanding"].value!="" )
				{

				objDataForm.fCheck_Outstanding.value=DollarAmount_commaNeg(objwi.attribute_list["Check_Outstanding"]);


				}


				if(objwi.attribute_list["Escheat_Total"].value!="" )
				{

				objDataForm.fEscheat_Total.value=DollarAmount_commaNeg(objwi.attribute_list["Escheat_Total"]);


				}

				if(objwi.attribute_list["Adjustments"].value!="" )
				{

				objDataForm.fAdjustments.value=DollarAmount_commaNeg(objwi.attribute_list["Adjustments"]);


				}


				/*if(objwi.attribute_list["Check_GL_Balance"].value!="" )
				{



				objDataForm.fCheck_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Check_GL_Balance"]);


				} */

				if(objwi.attribute_list["Comments"].value!="" )
				{

				objDataForm.Comments.value=objwi.attribute_list["Comments"].value;


				} 
				if(objwi.attribute_list["Validation_Comments"].value!="" )
				{

				objDataForm.Validation_Comments.value=objwi.attribute_list["Validation_Comments"].value;


				} 

				if(objwi.attribute_list["WNS_Approval_Comments"].value!="")
				{

				objDataForm.WNS_Approval_Comments.value=objwi.attribute_list["WNS_Approval_Comments"].value;


				} 
				
				if(objwi.attribute_list["Semp_Approval_Comments"].value!="")
				{

				objDataForm.Semp_Approval_Comments.value=objwi.attribute_list["Semp_Approval_Comments"].value;


				} 




			}


				
				if (sWname.toUpperCase()=="VALIDATION")
				{	

					

					if(objwi.attribute_list["Reconciliation_type"].value!="")
					{

					objDataForm.Reconciliation_type.value=objwi.attribute_list["Reconciliation_type"].value;
					//alert(objDataForm.Reconciliation_type.value);

					}
					//alert(objDataForm.Reconciliation_type.value);

					if(objwi.attribute_list["Reconciliation_Date_From"].value!="" )
					{

					var retdate=convertdatenew(objwi.attribute_list['Reconciliation_Date_From'].value);
					objDataForm.Reconciliation_Date_From.value=retdate;
					}
					if(objwi.attribute_list["Reconciliation_Date_To"].value!="" )
					{

					//objDataForm.Reconciliation_Date_To.value=objwi.attribute_list["Reconciliation_Date_To"].value;
					var retdate=convertdatenew(objwi.attribute_list['Reconciliation_Date_To'].value);
					objDataForm.Reconciliation_Date_To.value=retdate;
					}

					if(objwi.attribute_list["Bank_Account_Number"].value!="")
					{

					objDataForm.Bank_Account_Number.value=objwi.attribute_list["Bank_Account_Number"].value;

					}
					//onchangedoctype(objDataForm);

					if(objwi.attribute_list["Bank_Statement_Balance"].value!="")
					{

					objDataForm.fBank_Statement_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Bank_Statement_Balance"]);

					}

					if(objwi.attribute_list["Bank_Statement_GL_Balance"].value!="")
					{

					objDataForm.fBank_Statement_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Bank_Statement_GL_Balance"]);

					}



					if(objwi.attribute_list["Balance_Forward_Escheats"].value!="" )
					{

					objDataForm.fBalance_Forward_Escheats.value=DollarAmount_commaNeg(objwi.attribute_list["Balance_Forward_Escheats"]);

					}


					if(objwi.attribute_list["Current_Period_Escheats"].value!="" )
					{

					objDataForm.fCurrent_Period_Escheats.value=DollarAmount_commaNeg(objwi.attribute_list["Current_Period_Escheats"]);

					}  

					if(objwi.attribute_list["Other_Adjustments"].value!="" )
					{

					objDataForm.fOther_Adjustments.value=DollarAmount_commaNeg(objwi.attribute_list["Other_Adjustments"]);

					}   


					//Removed by Tarit gupta as on 07-07-08
				/*if(objwi.attribute_list["Total_Check_GL_Balance"].value!="" )
				{

				objDataForm.fTotal_Check_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Total_Check_GL_Balance"]);


				}*/

				//Removed by Tarit gupta as on 07-07-08


					if(objwi.attribute_list["Check_Outstanding"].value!="" )
					{

					objDataForm.fCheck_Outstanding.value=DollarAmount_commaNeg(objwi.attribute_list["Check_Outstanding"]);


					}


					if(objwi.attribute_list["Escheat_Total"].value!="" )
					{

					objDataForm.fEscheat_Total.value=DollarAmount_commaNeg(objwi.attribute_list["Escheat_Total"]);


					}

					if(objwi.attribute_list["Adjustments"].value!="" )
					{

					objDataForm.fAdjustments.value=DollarAmount_commaNeg(objwi.attribute_list["Adjustments"]);


					}


					/*if(objwi.attribute_list["Check_GL_Balance"].value!="" )
				{



				objDataForm.fCheck_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Check_GL_Balance"]);


				} */


					if(objwi.attribute_list["Comments"].value!="" )
					{

					objDataForm.Comments.value=objwi.attribute_list["Comments"].value;


					} 

					if(objwi.attribute_list["Validation"].value!="" )
					{

					objDataForm.Validation.value=objwi.attribute_list["Validation"].value;


					} 
					if(objwi.attribute_list["Validation_Comments"].value!="" )
					{

					objDataForm.Validation_Comments.value=objwi.attribute_list["Validation_Comments"].value;


					} 
					objDataForm.Validation.focus();
				}





					

			if (sWname.toUpperCase()=="WNS_MGR_APPROVAL")
			{	

			//alert("in approval");
				objDataForm.WNS_Approval.focus();


				if(objwi.attribute_list["Reconciliation_type"].value!="")
				{

				objDataForm.Reconciliation_type.value=objwi.attribute_list["Reconciliation_type"].value;
				//alert(objDataForm.Reconciliation_type.value);

				}
				//alert(objDataForm.Reconciliation_type.value);

				if(objwi.attribute_list["Reconciliation_Date_From"].value!="" )
				{

				var retdate=convertdatenew(objwi.attribute_list['Reconciliation_Date_From'].value);
				objDataForm.Reconciliation_Date_From.value=retdate;
				}
				if(objwi.attribute_list["Reconciliation_Date_To"].value!="" )
				{

				//objDataForm.Reconciliation_Date_To.value=objwi.attribute_list["Reconciliation_Date_To"].value;
				var retdate=convertdatenew(objwi.attribute_list['Reconciliation_Date_To'].value);
				objDataForm.Reconciliation_Date_To.value=retdate;
				}

				if(objwi.attribute_list["Bank_Account_Number"].value!="")
				{

				objDataForm.Bank_Account_Number.value=objwi.attribute_list["Bank_Account_Number"].value;

				}
				//onchangedoctype(objDataForm);

				if(objwi.attribute_list["Bank_Statement_Balance"].value!="")
				{

				objDataForm.fBank_Statement_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Bank_Statement_Balance"]);

				}

				if(objwi.attribute_list["Bank_Statement_GL_Balance"].value!="")
				{

				objDataForm.fBank_Statement_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Bank_Statement_GL_Balance"]);

				}



				if(objwi.attribute_list["Balance_Forward_Escheats"].value!="" )
				{

				objDataForm.fBalance_Forward_Escheats.value=DollarAmount_commaNeg(objwi.attribute_list["Balance_Forward_Escheats"]);

				}


				if(objwi.attribute_list["Current_Period_Escheats"].value!="" )
				{

				objDataForm.fCurrent_Period_Escheats.value=DollarAmount_commaNeg(objwi.attribute_list["Current_Period_Escheats"]);

				}  

				if(objwi.attribute_list["Other_Adjustments"].value!="" )
				{

				objDataForm.fOther_Adjustments.value=DollarAmount_commaNeg(objwi.attribute_list["Other_Adjustments"]);

				}   


				//Removed by Tarit gupta as on 07-07-08
				/*if(objwi.attribute_list["Total_Check_GL_Balance"].value!="" )
				{

				objDataForm.fTotal_Check_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Total_Check_GL_Balance"]);


				}*/

				//Removed by Tarit gupta as on 07-07-08


				if(objwi.attribute_list["Check_Outstanding"].value!="" )
				{

				objDataForm.fCheck_Outstanding.value=DollarAmount_commaNeg(objwi.attribute_list["Check_Outstanding"]);


				}


				if(objwi.attribute_list["Escheat_Total"].value!="" )
				{

				objDataForm.fEscheat_Total.value=DollarAmount_commaNeg(objwi.attribute_list["Escheat_Total"]);


				}

				if(objwi.attribute_list["Adjustments"].value!="" )
				{

				objDataForm.fAdjustments.value=DollarAmount_commaNeg(objwi.attribute_list["Adjustments"]);


				}


				/*if(objwi.attribute_list["Check_GL_Balance"].value!="" )
				{



				objDataForm.fCheck_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Check_GL_Balance"]);


				} */


				if(objwi.attribute_list["Comments"].value!="" )
				{

				objDataForm.Comments.value=objwi.attribute_list["Comments"].value;


				} 

				if(objwi.attribute_list["Validation"].value!="" )
				{

				objDataForm.Validation.value=objwi.attribute_list["Validation"].value;


				} 
				if(objwi.attribute_list["Validation_Comments"].value!="" )
				{

				objDataForm.Validation_Comments.value=objwi.attribute_list["Validation_Comments"].value;


				} 
				if(objwi.attribute_list["Semp_Approval_Comments"].value!="")
				{

				objDataForm.Semp_Approval_Comments.value=objwi.attribute_list["Semp_Approval_Comments"].value;


				} 

				if(objwi.attribute_list["WNS_Approval"].value!="" )
				{

				objDataForm.WNS_Approval.value=objwi.attribute_list["WNS_Approval"].value;


				} 
				if(objwi.attribute_list["WNS_Approval_Comments"].value!="")
				{

				objDataForm.WNS_Approval_Comments.value=objwi.attribute_list["WNS_Approval_Comments"].value;


				} 



			}

		if (sWname.toUpperCase()=="SEMP_MGR_APPROVAL")
			{	

			//alert("in approval");
				objDataForm.Semp_Approval.focus();


				if(objwi.attribute_list["Reconciliation_type"].value!="")
				{

				objDataForm.Reconciliation_type.value=objwi.attribute_list["Reconciliation_type"].value;
				//alert(objDataForm.Reconciliation_type.value);

				}
				//alert(objDataForm.Reconciliation_type.value);

				if(objwi.attribute_list["Reconciliation_Date_From"].value!="" )
				{

				var retdate=convertdatenew(objwi.attribute_list['Reconciliation_Date_From'].value);
				objDataForm.Reconciliation_Date_From.value=retdate;
				}
				if(objwi.attribute_list["Reconciliation_Date_To"].value!="" )
				{

				//objDataForm.Reconciliation_Date_To.value=objwi.attribute_list["Reconciliation_Date_To"].value;
				var retdate=convertdatenew(objwi.attribute_list['Reconciliation_Date_To'].value);
				objDataForm.Reconciliation_Date_To.value=retdate;
				}

				if(objwi.attribute_list["Bank_Account_Number"].value!="")
				{

				objDataForm.Bank_Account_Number.value=objwi.attribute_list["Bank_Account_Number"].value;

				}
				//onchangedoctype(objDataForm);

				if(objwi.attribute_list["Bank_Statement_Balance"].value!="")
				{

				objDataForm.fBank_Statement_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Bank_Statement_Balance"]);

				}

				if(objwi.attribute_list["Bank_Statement_GL_Balance"].value!="")
				{

				objDataForm.fBank_Statement_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Bank_Statement_GL_Balance"]);

				}



				if(objwi.attribute_list["Balance_Forward_Escheats"].value!="" )
				{

				objDataForm.fBalance_Forward_Escheats.value=DollarAmount_commaNeg(objwi.attribute_list["Balance_Forward_Escheats"]);

				}


				if(objwi.attribute_list["Current_Period_Escheats"].value!="" )
				{

				objDataForm.fCurrent_Period_Escheats.value=DollarAmount_commaNeg(objwi.attribute_list["Current_Period_Escheats"]);

				}  

				if(objwi.attribute_list["Other_Adjustments"].value!="" )
				{

				objDataForm.fOther_Adjustments.value=DollarAmount_commaNeg(objwi.attribute_list["Other_Adjustments"]);

				}   


				//Removed by Tarit gupta as on 07-07-08
				/*if(objwi.attribute_list["Total_Check_GL_Balance"].value!="" )
				{

				objDataForm.fTotal_Check_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Total_Check_GL_Balance"]);


				}*/

				//Removed by Tarit gupta as on 07-07-08


				if(objwi.attribute_list["Check_Outstanding"].value!="" )
				{

				objDataForm.fCheck_Outstanding.value=DollarAmount_commaNeg(objwi.attribute_list["Check_Outstanding"]);


				}


				if(objwi.attribute_list["Escheat_Total"].value!="" )
				{

				objDataForm.fEscheat_Total.value=DollarAmount_commaNeg(objwi.attribute_list["Escheat_Total"]);


				}

				if(objwi.attribute_list["Adjustments"].value!="" )
				{

				objDataForm.fAdjustments.value=DollarAmount_commaNeg(objwi.attribute_list["Adjustments"]);


				}


				/*if(objwi.attribute_list["Check_GL_Balance"].value!="" )
				{



				objDataForm.fCheck_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Check_GL_Balance"]);


				} */


				if(objwi.attribute_list["Comments"].value!="" )
				{

				objDataForm.Comments.value=objwi.attribute_list["Comments"].value;


				} 

				if(objwi.attribute_list["Validation"].value!="" )
				{

				objDataForm.Validation.value=objwi.attribute_list["Validation"].value;


				} 
				if(objwi.attribute_list["Validation_Comments"].value!="" )
				{

				objDataForm.Validation_Comments.value=objwi.attribute_list["Validation_Comments"].value;


				} 

				if(objwi.attribute_list["WNS_Approval"].value!="" )
				{

				objDataForm.WNS_Approval.value=objwi.attribute_list["WNS_Approval"].value;


				} 
				if(objwi.attribute_list["WNS_Approval_Comments"].value!="")
				{

				objDataForm.WNS_Approval_Comments.value=objwi.attribute_list["WNS_Approval_Comments"].value;


				} 
				
				if(objwi.attribute_list["Semp_Approval"].value!="" )
				{

				objDataForm.Semp_Approval.value=objwi.attribute_list["Semp_Approval"].value;


				} 
				if(objwi.attribute_list["Semp_Approval_Comments"].value!="")
				{

				objDataForm.Semp_Approval_Comments.value=objwi.attribute_list["Semp_Approval_Comments"].value;


				} 



			}


			

		if (sWname.toUpperCase()=="QUERY" || sWname.toUpperCase()=="WORK EXIT")
		{	


			if(objwi.attribute_list["Reconciliation_type"].value!="")
			{

			objDataForm.Reconciliation_type.value=objwi.attribute_list["Reconciliation_type"].value;
			//alert(objDataForm.Reconciliation_type.value);

			}
			//alert(objDataForm.Reconciliation_type.value);

			if(objwi.attribute_list["Reconciliation_Date_From"].value!="" )
			{

			var retdate=convertdatenew(objwi.attribute_list['Reconciliation_Date_From'].value);
			objDataForm.Reconciliation_Date_From.value=retdate;
			}
			if(objwi.attribute_list["Reconciliation_Date_To"].value!="" )
			{

			//objDataForm.Reconciliation_Date_To.value=objwi.attribute_list["Reconciliation_Date_To"].value;
			var retdate=convertdatenew(objwi.attribute_list['Reconciliation_Date_To'].value);
			objDataForm.Reconciliation_Date_To.value=retdate;
			}

			if(objwi.attribute_list["Bank_Account_Number"].value!="")
			{

			objDataForm.Bank_Account_Number.value=objwi.attribute_list["Bank_Account_Number"].value;

			}
			//onchangedoctype(objDataForm);

			if(objwi.attribute_list["Bank_Statement_Balance"].value!="")
			{

			objDataForm.fBank_Statement_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Bank_Statement_Balance"]);

			}

			if(objwi.attribute_list["Bank_Statement_GL_Balance"].value!="")
			{

			objDataForm.fBank_Statement_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Bank_Statement_GL_Balance"]);

			}



			if(objwi.attribute_list["Balance_Forward_Escheats"].value!="" )
			{

			objDataForm.fBalance_Forward_Escheats.value=DollarAmount_commaNeg(objwi.attribute_list["Balance_Forward_Escheats"]);

			}


			if(objwi.attribute_list["Current_Period_Escheats"].value!="" )
			{

			objDataForm.fCurrent_Period_Escheats.value=DollarAmount_commaNeg(objwi.attribute_list["Current_Period_Escheats"]);

			}  

			if(objwi.attribute_list["Other_Adjustments"].value!="" )
			{

			objDataForm.fOther_Adjustments.value=DollarAmount_commaNeg(objwi.attribute_list["Other_Adjustments"]);

			}   


			//Removed by Tarit gupta as on 07-07-08
				/*if(objwi.attribute_list["Total_Check_GL_Balance"].value!="" )
				{

				objDataForm.fTotal_Check_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Total_Check_GL_Balance"]);


				}*/

				//Removed by Tarit gupta as on 07-07-08


			if(objwi.attribute_list["Check_Outstanding"].value!="" )
			{

			objDataForm.fCheck_Outstanding.value=DollarAmount_commaNeg(objwi.attribute_list["Check_Outstanding"]);


			}


			if(objwi.attribute_list["Escheat_Total"].value!="" )
			{

			objDataForm.fEscheat_Total.value=DollarAmount_commaNeg(objwi.attribute_list["Escheat_Total"]);


			}

			if(objwi.attribute_list["Adjustments"].value!="" )
			{

			objDataForm.fAdjustments.value=DollarAmount_commaNeg(objwi.attribute_list["Adjustments"]);


			}


			/*if(objwi.attribute_list["Check_GL_Balance"].value!="" )
				{



				objDataForm.fCheck_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Check_GL_Balance"]);


				} */


			if(objwi.attribute_list["Comments"].value!="" )
			{

			objDataForm.Comments.value=objwi.attribute_list["Comments"].value;


			} 

			if(objwi.attribute_list["Validation"].value!="" )
			{

			objDataForm.Validation.value=objwi.attribute_list["Validation"].value;


			} 
			if(objwi.attribute_list["Validation_Comments"].value!="" )
			{

			objDataForm.Validation_Comments.value=objwi.attribute_list["Validation_Comments"].value;


			} 

			if(objwi.attribute_list["WNS_Approval"].value!="" )
			{

			objDataForm.WNS_Approval.value=objwi.attribute_list["WNS_Approval"].value;


			} 
			if(objwi.attribute_list["WNS_Approval_Comments"].value!="")
			{

			objDataForm.WNS_Approval_Comments.value=objwi.attribute_list["WNS_Approval_Comments"].value;


			}
			if(objwi.attribute_list["Semp_Approval"].value!="" )
				{

				objDataForm.Semp_Approval.value=objwi.attribute_list["Semp_Approval"].value;


				} 
				if(objwi.attribute_list["Semp_Approval_Comments"].value!="")
				{

				objDataForm.Semp_Approval_Comments.value=objwi.attribute_list["Semp_Approval_Comments"].value;


				} 



		}


	}





function onchangedoctype()
{
var objDataForm= window.parent.frames["left"].document.forms["dataform"];
var objwi=window.top.wi_object;
//alert(objDataForm.Reconciliation_type.value);

if(objDataForm.Reconciliation_type.value=="Bank Account Reconciliation")
	{
	
	
	enablefield("fBank_Statement_Balance");
	enablefield("fBank_Statement_GL_Balance");
	enablefield("fBalance_Forward_Escheats");
	enablefield("fCurrent_Period_Escheats");
	
	//Remove by Tarit Gupta as on 07-07-08
	//disablelightBARdatefield("fOther_Adjustments");
	//Remove by Tarit Gupta as on 07-07-08
	
	//Added by Tarit Gupta as on 07-07-08
	enablefield("fOther_Adjustments");
	//Added by Tarit Gupta as on 07-07-08

	//disablelightBARdatefield("fTotal_Check_GL_Balance");

	disablefield("fCheck_Outstanding");
	disablefield("fEscheat_Total");
	disablefield("fAdjustments");
	//disablelightfield("fCheck_GL_Balance");
	//objDataForm.fetchGLBal.disabled=false;
	//objDataForm.fetchAdjustments.disabled=false;

		/*if(objwi.attribute_list["Bank_Statement_Balance"].value!="")
		{

		objDataForm.fBank_Statement_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Bank_Statement_Balance"]);

		}

		if(objwi.attribute_list["Bank_Statement_GL_Balance"].value!="")
		{

		objDataForm.fBank_Statement_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Bank_Statement_GL_Balance"]);

		}



		if(objwi.attribute_list["Balance_Forward_Escheats"].value!="" )
		{

		objDataForm.fBalance_Forward_Escheats.value=DollarAmount_commaNeg(objwi.attribute_list["Balance_Forward_Escheats"]);

		}


		if(objwi.attribute_list["Current_Period_Escheats"].value!="" )
		{

		objDataForm.fCurrent_Period_Escheats.value=DollarAmount_commaNeg(objwi.attribute_list["Current_Period_Escheats"]);

		}  

		if(objwi.attribute_list["Other_Adjustments"].value!="" )
		{

		objDataForm.fOther_Adjustments.value=DollarAmount_commaNeg(objwi.attribute_list["Other_Adjustments"]);

		}   


		if(objwi.attribute_list["Total_Check_GL_Balance"].value!="" )
		{

		objDataForm.fTotal_Check_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Total_Check_GL_Balance"]);


		}*/
	

	}
if(objDataForm.Reconciliation_type.value=="Check Reconciliation")
	{
	
	
	enablefield("fCheck_Outstanding");
	enablefield("fEscheat_Total");
	enablefield("fAdjustments");
	//Added by Tarit Gupta as on 07-07-08
	enablefield("fBank_Statement_GL_Balance");
	//Added by Tarit Gupta as on 07-07-08
	//disablelightCRfield("fCheck_GL_Balance");

	disablefield("fBank_Statement_Balance");
	
	//Remove by Tarit Gupta as on 07-07-08
	
	//disablefield("fBank_Statement_GL_Balance");
	
	//Remove by Tarit Gupta as on 07-07-08
	
	disablefield("fBalance_Forward_Escheats");
	disablefield("fCurrent_Period_Escheats");
	//Remove by Tarit Gupta as on 07-07-08
	//disablelightdatefield("fOther_Adjustments");
	//Remove by Tarit Gupta as on 07-07-08
	//Added by Tarit Gupta as on 07-07-08
	disablefield("fOther_Adjustments");
	//Added by Tarit Gupta as on 07-07-08
	//disablelightdatefield("fTotal_Check_GL_Balance");
	//objDataForm.fetchGLBal.disabled=true;
	//objDataForm.fetchAdjustments.disabled=true;
		
	/*	if(objwi.attribute_list["Check_Outstanding"].value!="" )
		{

		objDataForm.fCheck_Outstanding.value=DollarAmount_commaNeg(objwi.attribute_list["Check_Outstanding"]);


		}


		if(objwi.attribute_list["Escheat_Total"].value!="" )
		{

		objDataForm.fEscheat_Total.value=DollarAmount_commaNeg(objwi.attribute_list["Escheat_Total"]);


		}

		if(objwi.attribute_list["Adjustments"].value!="" )
		{

		objDataForm.fAdjustments.value=DollarAmount_commaNeg(objwi.attribute_list["Adjustments"]);


		}


		if(objwi.attribute_list["Check_GL_Balance"].value!="" )
		{



		objDataForm.fCheck_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Check_GL_Balance"]);


		} */
	
	}
if(objDataForm.Reconciliation_type.value=="")
	{
	
	disablefield("fCheck_Outstanding");
	disablefield("fEscheat_Total");
	disablefield("fAdjustments");
	//disablelightfield("fCheck_GL_Balance");

	disablefield("fBank_Statement_Balance");
	disablefield("fBank_Statement_GL_Balance");
	disablefield("fBalance_Forward_Escheats");
	disablefield("fCurrent_Period_Escheats");
	disablelightdatefield("fOther_Adjustments");
	//disablelightdatefield("fTotal_Check_GL_Balance");
	//objDataForm.fetchGLBal.disabled=true;
	
	}
}

function disablelightCRfield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorLightDisbExt";
	//objDataForm(field).value="";
	
}
function disablelightBARdatefield(field)
{
	//alert("dff");
	//alert(field);
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorLightDisb";
	
}

function readonly(field)
{
var objDataForm= window.parent.frames["left"].document.forms["dataform"];
objDataForm(field).className="TextFieldColor";


}
function enablefield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=false;
	objDataForm(field).className="TextFieldColor";
	
}

function disablefield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorDisb";
	objDataForm(field).value="";
}

function enablecombofield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).disabled=false;
	objDataForm(field).className="TextFieldColor";
	
}

function disablecombofield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).disabled=true;
	objDataForm(field).className="TextFieldColorDisb";
}
 function enabledatefield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).className="TextFieldColorDate";
	
}

function disabledatefield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorDisbDate";
	objDataForm(field).value="";
}

function enablelightfield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).className="TextFieldColorDate";
	
}

function disablelightdatefield(field)
{
	//alert("dff");
	//alert(field);
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorDisbDate";
	objDataForm(field).value="";
	
}
function disablelightfield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorDisb";
	objDataForm(field).value="";
	
}



/*

function Cal_Chek_GL_Bal(obj)
{

	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var Check_Outstanding=objDataForm.fCheck_Outstanding.value;
	var Adjustments=objDataForm.fAdjustments.value;

	if(Check_Outstanding=="" || Adjustments=="")
	{
	objDataForm.fCheck_GL_Balance.value="";
	}
	if(!checknegative(obj))
	{
	return false;	
	}
	if(!floattest_commaNeg(obj,13,2))
	{
	objDataForm.fOther_Adjustments.value="";
	return false;
	}
	if(!DollarAmount_commaNeg(obj))
	{
	return false;
	}

	Check_Outstanding=RemoveComma_SBR(Check_Outstanding);
	Adjustments=RemoveComma_SBR(Adjustments);
	if(Check_Outstanding!="" && Adjustments!="")
	{
	objDataForm.fCheck_GL_Balance.value=parseFloat(Check_Outstanding)+parseFloat(Adjustments);
	objDataForm.fCheck_GL_Balance.value=DollarAmount_commaNeg(objDataForm.fCheck_GL_Balance);
	}
	else
	objDataForm.fCheck_GL_Balance.value="";

	if(objDataForm.fCheck_GL_Balance.value!="")
	{
	objDataForm.fCheck_GL_Balance.value=DollarAmount_commaNeg(objDataForm.fCheck_GL_Balance);
	}
		

}
*/

function SetTabIndex()
{
	try
	{	//alert("in set tab index");
       var objdataForm =document.forms["dataform"];
	   var TabSet=0;
	   var TotalElements=objdataForm.elements.length;
	   
		var imgindx1=1;
		 var imgindx2=2;
	   //alert("Workstepname: "+window.top.wi_object.workstep_name);
	   for(var i=0;i<TotalElements;i++)
		{           
		   //alert(objdataForm.elements[i].name);
			//alert(objdataForm.elements[i].tabIndex);

		  if(i==imgindx1)
		   { 		//alert(objdataForm.elements[i].name);
			    TabSet=TabSet+1;
				document.getElementById('Reconciliation_Date_From_IMG').tabIndex=TabSet;
				//alert(document.getElementById('Reconciliation_Date_From_IMG').tabIndex);
				//alert("img "+TabSet);				
		   }
		   //alert();
		   if(i==imgindx2)
		   {	//alert(objdataForm.elements[i].name);
                TabSet=TabSet+1;
				document.getElementById('Reconciliation_Date_To_IMG').tabIndex=TabSet;
				//alert(document.getElementById('Reconciliation_Date_To_IMG').tabIndex);
				//alert("img "+TabSet);	
		   }
		   if(objdataForm.elements[i].type=='text')
		   {
			   if(!objdataForm.elements[i].readOnly)
			   {   
				   
				   TabSet=TabSet+1;
				   objdataForm.elements[i].tabIndex=TabSet;
				   //alert(objdataForm.elements[i].name+"--"+TabSet);
			   }
			   else
			   {
				   objdataForm.elements[i].tabIndex="";
			   }
		    }
			else if(objdataForm.elements[i].type=='select-one')
			{
			   if(!objdataForm.elements[i].disabled)
				{			   
                   TabSet=TabSet+1;
				   objdataForm.elements[i].tabIndex=TabSet;	
				  // alert(objdataForm.elements[i].name+"--"+TabSet);
				}
				else
				{
					objdataForm.elements[i].tabIndex="";
				}
			}
			else if(objdataForm.elements[i].type=='button')
			{
				if(!objdataForm.elements[i].disabled)
				{  
					TabSet=TabSet+1;
				    objdataForm.elements[i].tabIndex=TabSet;
					//alert(objdataForm.elements[i].name+"--"+TabSet);
				}
				else
				{
					objdataForm.elements[i].tabIndex="";
				}
			}			
		    
		}
       
	}
	catch(e)
	{
		alert("Error in SetTabIndex: ");
	}
}

function chk_other_adj(obj)
{

var objDataForm= window.parent.frames["left"].document.forms["dataform"];
/*var temp="";
if((parseFloat(obj.value))!=0)
	{
		//alert("nonzero");
		for (var count=0;count<obj.value.length ;count++ )
		{
			if(obj.value.charAt(count)!="0")
			{
				temp=temp+obj.value.charAt(count);
			}
		}
		obj.value=temp;
	}*/
if(objDataForm.fBank_Statement_Balance.value=="" || objDataForm.fBank_Statement_GL_Balance.value=="" || objDataForm.fBalance_Forward_Escheats.value=="" || objDataForm.fCurrent_Period_Escheats.value=="")
	{
	
	objDataForm.fOther_Adjustments.value="";
	
	}
}


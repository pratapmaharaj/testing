/* 
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-GMAC
Module : GMAC-NAOCM
File Name : NAOCashMgmt_Client.js
Author :   Tarit Gupta
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date			Change By		Change Description (Bug No. (If Any))
(DD/MM/YYYY)	

21/10/2008		Tarit Gupta		NAOCM_03 :Rec Date should be current date.
23/10/2008		Tarit Gupta		NAOCM_04 :Processor Decision should be disabled the first time

----------------------------------------------------------------------------------------------------
*/
function NAOCM_Save()
	{
		//alert("1");
		var objwi=window.top.wi_object;
		var objDataForm= window.parent.frames["left"].document.forms["dataform"];
		var sWname=objwi.workstep_name.toUpperCase();
		if(!combos(objwi,objDataForm))
		{
			return false;
		}
		else if (sWname.toUpperCase()=="PROCESS_REQUEST")
			{
				if(objDataForm.fAmount.value!="" )
				{
					
				var temp=objDataForm.fAmount.value;
				var temp1=RemoveComma_SBR(temp);
				isModified(objwi.attribute_list['Amount'],temp1);
				}
			}
		
		return true;

	}
function NAOCM_Check_Mandatory_Doctype()
{
	

 try
	{ 
	 var length=window.parent.frames['right'].document.frames['doctypes_center'].document.forms["textForm"].doctype;//Change No:Res_15
	 var objwi=window.top.wi_object;
     //alert(window.parent.frames['right'].document.frames['doctypes_center'].document.forms["textForm"].doctype);
	  if(window.parent.frames['right'].document.frames['doctypes_center'].document.forms["textForm"].doctype==undefined)
		{
		  if(window.parent.frames['left'].document.forms["dataform"].Request_Type.value=='Nuvell Operational Funding' || window.parent.frames['left'].document.forms["dataform"].Request_Type.value=='Nuvell Daily Settlement')
		  {
				return true;
		  }
		  else
		  {
				alert("No Document is associated with the Workitem.");
				return false;
		  }
		}
	return true;	
	}
catch(e)
    {}
}

function NAOCM_Introduce()

	{
		
		var objwi=window.top.wi_object;
		var objDataForm= window.parent.frames["left"].document.forms["dataform"];
		var sWname=objwi.workstep_name.toUpperCase();
		
		if(!NAOCM_Save())
		{
				return false;
		}
		else if(!NAOCM_checkmandatory_Save(objDataForm,objwi,sWname))
		{
			return false;
		}
			
		else if(!(NAOCM_ChkRecDate(objDataForm.Request_Date))) //NAOCM_03 Added by Tarit as on 21-10-08
		{
			return false;
		}
		else if(!NAOCM_Check_Mandatory_Doctype())
		{
			return false;
		}
		
		else if(!NAOCM_checkmandatory_doctype(objDataForm,objwi,sWname))
		{
			return false;

		}
		
	
	return true;

	}
function NAOCM_Done()
{
		var objwi=window.top.wi_object;
		var objDataForm= window.parent.frames["left"].document.forms["dataform"];
		var sWname=objwi.workstep_name.toUpperCase();
		if(!NAOCM_Save())
		{		
			return false;
		}
		//alert("000"+NAOCM_checkmandatory_Save(objDataForm,objwi,sWname))
		if(!NAOCM_checkmandatory_Save(objDataForm,objwi,sWname))
		{		
			return false;
		}
		else if(!NAOCM_SaveAtDone(objDataForm,objwi,sWname))
		{
		//alert("3");
			return false;
		}
		else if(!fetchReqType(objDataForm,objwi,sWname))
		{
		//alert("4");
			return false;
		}
		else if(!ValidateRejectWI())
		{
		//alert("5");
			return false;
		}
	
		
		
return true;

}

function NAOCM_checkmandatory_Save(objDataForm,objwi,sWname)
{
    //alert(sWname.toUpperCase()=="PROCESS_REQUEST");	
	if(sWname.toUpperCase()=="CREATE_REQUEST")
		{
			if(objDataForm.Due_Date.value=="" )
			{
					alert("Due Date cannot be blank.");
					objDataForm.Due_Date.focus();
					return false;
			}// Added by Beno on 22-Jan-2009			
			if(!(NAOCM_checkmandatory_Work_Intro(objDataForm)))
			{
				   return false; 
			}
		}
	else if(sWname.toUpperCase()=="PROCESS_REQUEST")
		{	

			if(!(NAOCM_checkmandatory_PROCESS_REQUEST(objDataForm)))
				{
				   return false; 
				}
			else if(!NAOCM_Check_Mandatory_Doctype())
			{
				return false;
			}
			else if(!NAOCM_checkmandatory_doctype(objDataForm,objwi,sWname))
			{
			return false;

			}
			else if(!SaveApprvlnameCount(objDataForm,objwi,sWname))
				{
					return false;
				
				}
		
		}
	else if(sWname.toUpperCase()=="VALIDATION")
		{
		if(!(NAOCM_checkmandatory_Validation(objDataForm)))
				{
				   return false; 
				}
		}
	else if(sWname.toUpperCase()=="WNS_MGR_APPROVAL")
		{
		if(!(NAOCM_checkmandatory_WNS_Approval(objDataForm)))
				{
				   return false; 
				}
		}
	else if(sWname.toUpperCase()=="COMM_IMP_REPORT")
		{
		if(!(NAOCM_checkmandatory_COMM_IMP_REPORT(objDataForm)))
				{
				   return false; 
				}
		else if(!NAOCM_checkmandatory_doctype(objDataForm,objwi,sWname))
			{
			return false;

			}
		}

return true;
}



function NAOCM_checkmandatory_doctype(objDataForm,objwi,sWname)
{
	try
	{

	
	var RequestForm=false;
	var BankStatement=false;
	var ATOMReport=false;
	var BankReport=false;
	var SettlementDocument=false;
	var InsightReport=false;
	var FundTransferDocument=false;
	var objwi=window.top.wi_object;
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var sWname=objwi.workstep_name.toUpperCase();
	var length;

	if(sWname.toUpperCase()=='CREATE_REQUEST' && objDataForm.Request_Type.value.indexOf('Nuvell')!=-1)
	{
		return true;
	}
	else if(sWname.toUpperCase()!='CREATE_REQUEST' && objDataForm.Request_Type.value.indexOf('Nuvell')!=-1 && window.parent.frames['right'].document.frames['doctypes_center'].document.forms["textForm"].doctype==undefined)
	{
		alert("Kindly Import the Bank Statement Form.");
		return false;
	}
	else
	{
		length=window.parent.frames['right'].document.frames['doctypes_center'].document.forms["textForm"].doctype.length;
	}
	
	if(length!=" ")
	{	
		var objDocType=window.parent.frames['right'].document.frames['doctypes_center'].document.forms["textForm"].doctype;

		
		
			for(var i=0 ; i<objDocType.length ;i++)
			{ 
				var doctype=objDocType.options[i].outerText;
				
				if (sWname.toUpperCase()=="CREATE_REQUEST")
				{	
					if(doctype.substring(0,15)=="WireRequestForm")
					{ 
						RequestForm=true;
					}
					if(objDataForm.Process.value=='MIC')
					{
						if(doctype.substring(0,13)=="BankStatement")
						{ 
							BankStatement=true;
						}
						if(doctype.substring(0,10)=="ATOMReport")
						{ 
							ATOMReport=true;
						}
						if(doctype.substring(0,13)=="InsightReport")
						{ 
							InsightReport=true;
						}
						if(doctype.substring(0,18)=="SettlementDocument")
						{ 
							SettlementDocument=true;
						}
						if(doctype.substring(0,20)=="FundTransferDocument")
						{ 
							FundTransferDocument=true;
						}
						

					}
				}
			
				else if(sWname.toUpperCase()=="PROCESS_REQUEST")
				{
					
					if(doctype.substring(0,15)=="WireRequestForm")
					{ 
						RequestForm=true;
					}
					if(objDataForm.Process.value=='NAO')
					{
						if(doctype.substring(0,13)=="BankStatement")
						{ 
							BankStatement=true;
						}
						else if(doctype.substring(0,10)=="ATOMReport")
						{ 
							ATOMReport=true;
						}
						else if(doctype.substring(0,10)=="BankReport")
						{ 
							BankReport=true;
						}
						else if(doctype.substring(0,18)=="SettlementDocument")
						{ 
							SettlementDocument=true;
						}
					}
					if(objDataForm.Process.value=='MIC')
					{
						if(doctype.substring(0,10)=="BankReport")
						{ 
							BankReport=true;
						}
						if(doctype.substring(0,13)=="BankStatement")
						{ 
							BankStatement=true;
						}
						if(doctype.substring(0,10)=="ATOMReport")
						{ 
							ATOMReport=true;
						}
						if(doctype.substring(0,13)=="InsightReport")
						{ 
							InsightReport=true;
						}
						if(doctype.substring(0,18)=="SettlementDocument")
						{ 
							SettlementDocument=true;
						}
						if(doctype.substring(0,20)=="FundTransferDocument")
						{ 
							FundTransferDocument=true;
						}

					}
				}
			else if(sWname.toUpperCase()=="COMM_IMP_REPORT")
					{
						if(doctype.substring(0,13)=="InsightReport")
							{ 
								InsightReport=true;
							}
					}
				
			}



			if (sWname.toUpperCase()=="CREATE_REQUEST")
				{	
					if(objDataForm.Process.value=='NAO' && (objDataForm.Request_Type.value!='Nuvell Operational Funding' || objDataForm.Request_Type.value!='Nuvell Daily Settlement'))
					{
						if(RequestForm!=true)
						{
							alert("Please import Wire Request Form.");
							return false;
						}
					}
					if(objDataForm.Process.value=='MIC')
					{
						if(RequestForm!=true)
						{
							alert("Please import Wire Request Form.");
							return false;
						}
						if(BankStatement==true)
						{ 
							alert("Cannot import Bank Statement Form for MIC Process.");
							return false;
						}
						if(ATOMReport==true)
						{ 
							alert("Cannot import ATOM Report Document for MIC Process.");
							return false;
						}
						if(InsightReport==true)
						{ 
							alert("Cannot import Insight Report Document for MIC Process.");
							return false;
							
						}
						if(SettlementDocument==true)
						{ 
							alert("Cannot import Settlement Document for MIC Process.");
							return false;
							
						}
						if(FundTransferDocument==true)
						{ 
							alert("Cannot import Fund Transfer Document for MIC Process.");
							return false;
						}

					}
				}
			else if(sWname.toUpperCase()=="PROCESS_REQUEST")
			{
				if(objDataForm.Process.value=='NAO')
				{
					if(objDataForm.Request_Type.value.indexOf('Nuvell')==-1)
					{
						if(RequestForm!=true)
						{
							alert("Please import Wire Request Form.");
							return false;
						}
					}
					else if(BankStatement==false &&(objDataForm.Request_Type.value=="Nuvell Operational Funding" || objDataForm.Request_Type.value=="Nuvell Daily Settlement"))
					{
						alert("Please import Bank Statement Document.");
						return false;
					}
					else if(BankReport==false &&(objDataForm.Request_Type.value=="Nuvell Operational Funding" || objDataForm.Request_Type.value=="Nuvell Daily Settlement"))
					{
						alert("Please import Bank Report Document.");
						return false;
					}
					else if(ATOMReport==false &&(objDataForm.Request_Type.value=="Wire Payment" || objDataForm.Request_Type.value=="Internal Request" || objDataForm.Request_Type.value=="Executive Office Request" || objDataForm.Request_Type.value=="Field Office Request"))
					{
						alert("Please import ATOM Report Document.");
						return false;
					}
					else if(SettlementDocument==false &&objDataForm.Request_Type.value=="Nuvell Daily Settlement")
					{
						alert("Please import Settlement Document Document.");
						return false;
					}
				}
				if(objDataForm.Process.value=='MIC' && objDataForm.Reject_WI.value!='Yes')
					{
						if(BankStatement==true)
						{ 
							alert("Cannot import Bank Statement Form for MIC Process.");
							return false;
						}
						if(ATOMReport==true)
						{ 
							alert("Cannot import ATOM Report Document for MIC Process.");
							return false;
						}
						if(InsightReport==true)
						{ 
							alert("Cannot import Insight Report Document for MIC Process.");
							return false;
							
						}
						if(SettlementDocument==true)
						{ 
							alert("Cannot import Settlement Document for MIC Process.");
							return false;
							
						}
						if(FundTransferDocument==true)
						{ 
							alert("Cannot import Fund Transfer Document for MIC Process.");
							return false;
						}
						if(RequestForm!=true)
						{
							alert("Please import Wire Request Form.");
							return false;
						}
						if(BankReport!=true)
						{
							alert("Please import Bank Report Document.");
							return false;
						}
						

					}
			
			}
		/*	else if(sWname.toUpperCase()=="COMM_IMP_REPORT")
			{
			if(InsightReport==false &&(objDataForm.Request_Type.value=="Internal Request" || objDataForm.Request_Type.value=="Executive Office Request" || objDataForm.Request_Type.value=="Field Office Request"))
				{
				alert("Please import Insight Report Document.");
				return false;
				}
		
			}  */
	
	
		

	}

	}
	catch(e)
	{}
	return true;

}

function isModified(oldVal,newVal)
	{
	if(oldVal.value!=newVal)
	 {
	  oldVal.value=newVal;
	  
	  oldVal.modified_flag=true;
	 }
	}

function NAOCM_checkmandatory_Work_Intro(objDataForm)
{				
				if(objDataForm.Process.value=="")
					{
						alert("Select the Process.");
						objDataForm.Process.focus();
						return false;
					}
				if(objDataForm.Request_Type.value=="" && objDataForm.Process.value=='NAO')
					{
						alert("Select the Request Type.");
						objDataForm.Request_Type.focus();
						return false;
					}
				else if(objDataForm.Request_Date.value=="" )
					{
						alert("Request Date cannot be blank.");
						objDataForm.Request_Date.focus();
						return false;
					}
				/*else if(objDataForm.Priority.value==""  && objDataForm.Process.value=='NAO')
					{
						alert("Select the Priority.");
						objDataForm.Priority.focus();
						return false;
					}*/
				
			
				
	return true;

}

function NAOCM_checkmandatory_PROCESS_REQUEST(objDataForm)
{
	
		if(objDataForm.Reject_WI.value!='Yes')
		{		
			if(!(NAOCM_checkmandatory_Work_Intro(objDataForm)))
			{
				   return false; 
			}
			 if(objDataForm.Bank_Acc_Number.value=="" )
			{
					alert("Bank Account Number can not be blank..");
					objDataForm.Bank_Acc_Number.focus();
					return false;
			}
			else if(objDataForm.fAmount.value=="" )
			{
					alert("Amount can not be blank.");
					objDataForm.fAmount.focus();
					return false;
			}	
			
			if(objDataForm.Process.value=='NAO' && objDataForm.Recipient.value=="" && (objDataForm.Request_Type.value=="Wire Payment" || objDataForm.Request_Type.value=="Internal Request" || objDataForm.Request_Type.value=="Executive Office Request" || objDataForm.Request_Type.value=="Field Office Request") )
			{
					alert("Recipient Number can not be blank.");
					objDataForm.Recipient.focus();
					return false;
			}
			/*if(objDataForm.Process.value=='NAO')
			{
				if(objDataForm.Wire_Transfer_Reference.value=="" && (objDataForm.Request_Type.value=="Wire Payment" || objDataForm.Request_Type.value=="Internal Request" || objDataForm.Request_Type.value=="Executive Office Request" || objDataForm.Request_Type.value=="Field Office Request"))
				{
							alert("Wire Transfer Reference can not be blank.");
							objDataForm.Wire_Transfer_Reference.focus();
							return false;
				}
			}
			else if(objDataForm.Process.value=='MIC')
			{
				if(objDataForm.Wire_Transfer_Reference.value=="")
				{
							alert("Wire Transfer Reference can not be blank.");
							objDataForm.Wire_Transfer_Reference.focus();
							return false;
				}

			}*/
			
				/*
				if(objDataForm.Process.value=='NAO' && objDataForm.Insight_Reference_Number.value=="" && (objDataForm.Request_Type.value=="Internal Request" || objDataForm.Request_Type.value=="Executive Office Request" || objDataForm.Request_Type.value=="Field Office Request"))
				{
					alert("Insight Reference Number can not be blank.");
					objDataForm.Insight_Reference_Number.focus();
					return false;
				}
				*/
				if(objDataForm.Process.value=='MIC')
				{
					if(objDataForm.Wire_Transfer_Reference.value=="")
					{
						alert("Wire Transfer Reference can not be blank.");
						objDataForm.Wire_Transfer_Reference.focus();
						return false;
					}

				}
				if(objDataForm.Process.value=='MIC' && objDataForm.Payee.value=="")
				{
					alert("Payee can not be blank.");
					objDataForm.Payee.focus();
					return false;
				}
				if(objDataForm.Process.value=='MIC' && objDataForm.Bank_Name.value=="")
				{
					alert("Bank Name can not be blank.");
					objDataForm.Bank_Name.focus();
					return false;
				}
				//Change No:NAOCM_04 by Tarit Gupta
				if(objDataForm.Process.value=='NAO' && objDataForm.Processor_Decision.value=="" && objDataForm.Processor_Decision.disabled==false)
				{
					alert("Select Processor Decision .");
					objDataForm.Processor_Decision.focus();
					return false;
				}
				//Commented By Deependra 1/14/2009
				/*if(objDataForm.Process.value=='MIC' && objDataForm.Reject_WI.value=="" && objDataForm.Reject_WI.disabled==false)
				{
					alert("Select Reject WI Decision .");
					objDataForm.Reject_WI.focus();
					return false;
				}//*/

				//Change No:NAOCM_04 by Tarit Gupta
				if(objDataForm.Process.value=='NAO' && objDataForm.Comments.value=="")
				{
					alert("Comments cannot be blank.");
					objDataForm.Comments.focus();
					return false;
				}
		}
	
		
		/*else if(!(NAOCM_CalRecDate(objDataForm.Request_Date,"D")))
				{
				return false;
				}*/

		/*else if(objDataForm.Processor_Decision.value=="" && (objDataForm.Request_Type.value=="Internal Request" || objDataForm.Request_Type.value=="Executive Office Request" || objDataForm.Request_Type.value=="Field Office Request"))
			{
				alert("Select Processor Decision .");
				objDataForm.Processor_Decision.focus();
				return false;
			}
		else if(objDataForm.Processor_Decision.value=="" && objDataForm.Recent_Approvers.value!="")
			{
				alert("Select Processor Decision .");
				objDataForm.Processor_Decision.focus();
				return false;
			}*/
return true;
}
function NAOCM_checkmandatory_Validation(objDataForm)
	{
				if(trim(objDataForm.Validation.value)=="")
				{
						alert("Select the Validation.");
						objDataForm.Validation.focus();
						return false;
				}
				if(trim(objDataForm.Validation_Comments.value)=="" && trim(objDataForm.Validation.value)=="Fail")
				{
						alert("Validation Comments can not be blank.");
						objDataForm.Validation_Comments.focus();
						return false;
				}
 return true;
	}
function NAOCM_checkmandatory_WNS_Approval(objDataForm)

{
				if(objDataForm.WNS_Manager_Approval.value=="" )
				{
					alert("Select Approval decision.");
					objDataForm.WNS_Manager_Approval.focus();
					return false;
				}
				if(trim(objDataForm.WNS_Manager_Approval_Comments.value)=="" && trim(objDataForm.WNS_Manager_Approval.value)=="Reject")
				{
					alert("Approval Comments can not be blank.");
					objDataForm.WNS_Manager_Approval_Comments.focus();
					return false;
				}

return true;
}

function NAOCM_checkmandatory_COMM_IMP_REPORT(objDataForm)
{
				if(objDataForm.Confirmation_Call_Made.value=="" )
				{
					alert("Select Confirmation Call Made.");
					objDataForm.Confirmation_Call_Made.focus();
					return false;
				}
				else
				{
					if(objDataForm.Confirmation_Call_Made.value=='No')
					{
						alert('The workitem cannot be completed until the Confirmation Call has been made,kindly save the details and close the workdesk');
						return false;
					}
				}
				
return true;
}
function SaveApprvlnameCount(objDataForm,objwi,sWname)
{
	var stempRecentApprover=objwi.attribute_list["Recent_Approvers"].value;
	var Current_User=objDataForm.CurrentUser.value;
	var suserFlag=false;
	var sUsers="";
	
//	if(objDataForm.Processor_Decision.value!="Reject")
//	{
		if(stempRecentApprover=="")
		{
			isModified(objwi.attribute_list['Recent_Approvers'],Current_User);
			return true;
		}
		else if(stempRecentApprover.indexOf('#')==-1)
		{
			if(stempRecentApprover==Current_User)
			{
				
				//alert("Work item has already been approved by you,you can not submitt the work item.");
				alert("Workitem cannot be re-submitted by the same user.");
				return false;
				
			}
			else
			{
				stempRecentApprover=stempRecentApprover+'#'+objDataForm.CurrentUser.value;
			}
		}
		else
		{
			sUsers=stempRecentApprover.split('#');
				for(var i=0;i<sUsers.length;i++)
				{
					if(sUsers[i]==Current_User)
					{
						suserFlag=true;
						break;

					}

				}
				if(suserFlag==false)
				{
					stempRecentApprover=stempRecentApprover+'#'+objDataForm.CurrentUser.value;

				}
				else
				{
					//alert("Work item has already been approved by you,you can not submitt the work item.");
					alert("Workitem cannot be re-submitted by the same user.");
					return false;
				}

		}
		isModified(objwi.attribute_list['Recent_Approvers'],stempRecentApprover);
	//}
return true;
		


}


/*function SaveApprvlnameCount(objDataForm,objwi,sWname)
{

var temp2="";
var Aprvl=false;
var tempdatabase="";
var temp="";
var formfield="";
var Current_User="";
	if(sWname.toUpperCase()=="PROCESS_REQUEST")
	{
		
			temp=objwi.attribute_list["Recent_Approvers"].value;
			formfield=objDataForm.Recent_Approvers.value;
			Current_User=objDataForm.CurrentUser.value;
			if(temp.indexOf('#')!=-1)
			{
				tempdatabase=temp.split('#');
				for(var i=0;i<tempdatabase.length;i++)
				{
					if(tempdatabase[i]==Current_User)
						{
							 Aprvl=true;
							 break;
						}
						else
							continue;
				}
			}
			else
			{
				
				if(temp==Current_User)
					Aprvl=true;
			}
			
			if(Aprvl==false)
			{
			if(temp!="")
				{
					
					var temp1=formfield+'#'+Current_User;
					
					isModified(objwi.attribute_list['Recent_Approvers'],temp1);
				}
			else
				{
				isModified(objwi.attribute_list['Recent_Approvers'],Current_User);
				}
			}
			else 
			{
			alert("Work item has already been approved by you,you can not submitt the work item.");
			return false;
			}
			
	}

return true;
}*/
function NAOCM_SaveAtDone(objDataForm,objwi,sWname)
	{
		
		var sWiName=objwi.attribute_list["WorkItemName"].value;
		var sSplitVal=sWiName.split('-');
		var iWINo=parseFloat(sSplitVal[1]);
		var sPreviousWorkStep="";
	
		if(sWname.toUpperCase()=="CREATE_REQUEST")
			sPreviousWorkStep=null;
		else
			sPreviousWorkStep=window.top.wi_object.attribute_list["Previous_Wrk_Step"].value;


		ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\NAOCM\\NAOCM_Done_Data.jsp","sWiName="+encodeURIComponent(sWiName)+"&sENTRYDATETIME="+window.top.wi_object.attribute_list["EntryDateTime"].value+"&sCurrentWorkStep="+sWname+"&sPreviousWorkStep="+sPreviousWorkStep);
		//alert(iAjaxMainCode);
		if (iAjaxMainCode=="15")
		{
		alert('Error in updating SBR Done .');
		return false;
		}
		else if (sAjaxReturnValue!="Success")
		{
		alert('Error in updating SBR Done .');
		return false;
		}
		
		return true;
	
	}


function fetchReqType(objDataForm,objwi,sWname)
{
	
	try
	{
		if(objDataForm.Process.value=='NAO')
		{
			var Reqtype=objDataForm.Request_Type.value;
			if(objDataForm.Recent_Approvers.value=="")
			{
				ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\NAOCM\\RequestTypeDetail.jsp","Reqtype="+encodeURIComponent(Reqtype));	
				var AprvlReq=sAjaxReturnValue;
				AprvlReq=parseInt(AprvlReq);
				isModified(objwi.attribute_list['approval_count'],AprvlReq);
				if(AprvlReq!=0)
				{
					isModified(objwi.attribute_list['Approval_Complete'],"N");
				}
			}
			
			else if(parseInt(objwi.attribute_list["approval_count"].value)==1)
			{
				isModified(objwi.attribute_list['Approval_Complete'],"Y");
				isModified(objwi.attribute_list['approval_count'],"0");
				//alert("No more approval required.");
				//return false;
			}
			else
			{	
				temp2=parseInt(objwi.attribute_list["approval_count"].value);
				temp2=parseInt(temp2)-1;
				isModified(objwi.attribute_list['approval_count'],temp2);
				isModified(objwi.attribute_list['Approval_Complete'],"N");
			}
		}
				
		
	}

	catch(e)
	{
			alert('Error in updating Request Type Details.');
			return false;
	}
	
return true;

}

function NAOCM_ChkRecDate(ReqDate)
{
				tempReqDate=ReqDate.value;
				var sDateSeparator="/";
				var tempRecDate=new Date();
				var tempMonth=tempRecDate.getMonth()+1;
				var tempDate=tempRecDate.getDate();
				if(tempMonth>=1 && tempMonth<=9)
					{
					tempMonth=tempMonth.toString();
					tempMonth="0"+tempMonth;
					}
				if(tempDate>=1 && tempDate<=9)
					{
					//tempDate=tempDate.toString();
					tempDate="0"+tempDate;
					}
				var tempformRecdate=tempMonth+'/'+tempDate+'/'+tempRecDate.getYear();
				
				var fReqMth=Number(tempReqDate.substring(0,tempReqDate.indexOf(sDateSeparator)));
				var fReqDate=Number(tempReqDate.substring(tempReqDate.indexOf(sDateSeparator)+1,tempReqDate.lastIndexOf(sDateSeparator)));
				var fReqYr=Number(tempReqDate.substring(tempReqDate.lastIndexOf(sDateSeparator)+1,tempReqDate.length));
					if(fReqYr<tempRecDate.getYear())
					{
						alert("Request Date can not be previous Date.");
						ReqDate.select();
						return false;
					}
					else if(fReqYr>=tempRecDate.getYear())
					{
						if(fReqMth<tempMonth)
						{
							alert("Request Date can not be previous Date.");
							ReqDate.select();
							return false;
						}
						else if(fReqMth==tempMonth)
						{
							if(fReqDate<tempDate)
							{
								alert("Request Date can not be previous Date.");
								ReqDate.select();
								return false;
							}
						}
					}
	return true;

}

function ValidateRejectWI()
{
	
	var objwi=window.top.wi_object;
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var sWname=objwi.workstep_name.toUpperCase();
	

	if(sWname.toUpperCase()=='PROCESS_REQUEST')
	{
		var Current_User=objDataForm.CurrentUser.value;
		var Current_User_Comp;
		if(objDataForm.Process.value=='NAO')
		{
			if(objDataForm.Processor_Decision.value=='Reject')
			{
				if(objDataForm.Recent_Approvers.value=='')
				{
					alert("The Initial Processor cannot reject the Workitem");
					return false;
				}
				else if(objDataForm.Recent_Approvers.value!='')
				{
					
					if(objwi.attribute_list["Rejection_Status"].value=='')
					{
						
						isModified(objwi.attribute_list['Rejection_Status'],Current_User+'~N');
						//isModified(objwi.attribute_list['Rejection_Status'],'N');

						if(objwi.attribute_list["approval_count"].value=='0' && objwi.attribute_list["Approval_Complete"].value=='Y')
						{
							isModified(objwi.attribute_list['approval_count'],parseInt('1'));
							isModified(objwi.attribute_list['Approval_Complete'],'N');
							
						}
						
					}
					else if(objwi.attribute_list["Rejection_Status"].value.indexOf('~')!=-1)
					{
						Current_User_Comp=objwi.attribute_list['Rejection_Status'].value.substring(0,objwi.attribute_list['Rejection_Status'].value.indexOf('~'));
						//if(objDataForm.Recent_Approvers.value.indexOf(Current_User_Comp)!=-1)
						if(Current_User_Comp==Current_User)
						{
							alert("The workitem cannot be rejected twice by the same user");
							return false;
						}
						else
						{
							
							isModified(objwi.attribute_list['Rejection_Status'],'Y');
							isModified(objwi.attribute_list['approval_count'],parseInt('0'));
							isModified(objwi.attribute_list['Approval_Complete'],'Y');
							
						}

					}

				}
			}
			else if(objDataForm.Processor_Decision.value=='Approve' && objwi.attribute_list['Rejection_Status'].value.indexOf('~')!=-1)
			{
				
				isModified(objwi.attribute_list['Rejection_Status'],'N');
				isModified(objwi.attribute_list['approval_count'],parseInt('0'));
				isModified(objwi.attribute_list['Approval_Complete'],'Y');
			}
			else if(objDataForm.Processor_Decision.value=='Approve' && objwi.attribute_list['Rejection_Status'].value=='')
			{
				if(objwi.attribute_list['approval_count'].value=='0' && objwi.attribute_list['Approval_Complete'].value=='Y')
				{
					isModified(objwi.attribute_list['Rejection_Status'],'N');
				}
			}
			
		}
	}
	
	return true;
}


/*
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : WNS-GMAC
Module : WNS-GMAC-ResAP
File Name : ResAP_Validation.js
Author :   Tarit
Date written (DD/MM/YYYY) : 
Description : This JS File Contains load functions for all Workstep which is further included in all jsp forms
----------------------------------------------------------------------------------------------------

CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date Change By Change Description (Bug No. (If Any))
(DD/MM/YYYY)
Bug No:ResAP_CWA_7:Set id value was not populating on the form
Change No:Res_11:Vendor Name and Vendor ID Number should be  blank when user changes AP Business Unit.
----------------------------------------------------------------------------------------------------

*/ 
function load()
{	
	
	
	var objwi=window.top.wi_object;
    var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
	var sWname=objwi.workstep_name.toUpperCase();
	
	
			
			if (sWname.toUpperCase()=="WORK INTRODUCTION")
				{	
					
					objDataForm.Document_Type.focus();
					
					//alert(objwi.attribute_list["Previous_Wrk_Step"]);
					if(objwi.attribute_list["Document_Type"].value!="" )
						{
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;

						}

					if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						}



				}
  

			if (sWname.toUpperCase()=="INDEXING")
				{	
					//alert(objwi.attribute_list["PriorityLevel"].value);
						objDataForm.Document_Type.focus();

						if(objwi.attribute_list["Document_Type"].value!="" )
						{

						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;
						//alert(objDataForm.Document_Type.value);

						}
						//alert(objDataForm.Document_Type);
						//alert(objwi.attribute_list["Document_Type"].value);
						//alert(objDataForm.Document_Type.value);
						if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
						if(objwi.attribute_list["Setid"].value!="" )
						{

						objDataForm.Setid.value=objwi.attribute_list["Setid"].value;

						}
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						if(objwi.attribute_list["AP_Business_Unit"].value!="" )
						{

						objDataForm.AP_Business_Unit.value=objwi.attribute_list["AP_Business_Unit"].value;

						}
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma_SBR(objwi.attribute_list["Amount"]);
						

						}
						
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Priority"].value!="" )
						{
						
						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						if(objwi.attribute_list["Intro_Type"].value=="BH" && objwi.attribute_list["Priority"].value=="Urgent")
							objDataForm.Priority.disabled=true;

						}

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						if(objwi.attribute_list["Validation"].value!="" )
						{

						objDataForm.Validation.value=objwi.attribute_list["Validation"].value;

						}
						if(objwi.attribute_list["Validation_Comments"].value!="" )
						{

						objDataForm.Validation_Comments.value=objwi.attribute_list["Validation_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}
						if(objwi.attribute_list["Split_Resolution_Comments"].value!="" )
						{

						objDataForm.Split_Resolution_Comments.value=objwi.attribute_list["Split_Resolution_Comments"].value;

						}
						if(objwi.attribute_list["No_Of_WI_Created"].value!="" )
						{

						objDataForm.No_Of_WI_Created.value=objwi.attribute_list["No_Of_WI_Created"].value;

						}
						if(objwi.attribute_list["WI_Serial_Number"].value!="" )
						{

						objDataForm.WI_Serial_Number.value=objwi.attribute_list["WI_Serial_Number"].value;

						}
						if(objwi.attribute_list["Cancel_Decision_Comments"].value!="" )
						{

						objDataForm.Cancel_Decision_Comments.value=objwi.attribute_list["Cancel_Decision_Comments"].value;

						}
						
						if(!loadcheckboxes())
						{
							return false;
						}

				}

				if (sWname.toUpperCase()=="PROCESSING")
				{	
						
						//alert("in proces");
						objDataForm.Document_Type.focus();

						if(objwi.attribute_list["Document_Type"].value!="")
						{

						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;

						}
						if(objwi.attribute_list["Document_Category"].value!="")
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
						if(objwi.attribute_list["Setid"].value!="")
						{

						objDataForm.Setid.value=objwi.attribute_list["Setid"].value;

						}
						
						if(objwi.attribute_list["Vendor_ID"].value!="")
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						
						if(objwi.attribute_list["Vendor_Name"].value!="")
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						
						if(objwi.attribute_list["AP_Business_Unit"].value!="")
						{

						objDataForm.AP_Business_Unit.value=objwi.attribute_list["AP_Business_Unit"].value;

						}
						
						
						
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma_SBR(objwi.attribute_list["Amount"]);
						

						}
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;
						if(objwi.attribute_list["Intro_Type"].value=="BH" && objwi.attribute_list["Priority"].value=="Urgent")
							objDataForm.Priority.disabled=true;


						}

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}

						if(objwi.attribute_list["PS_Voucher_ID"].value!="" )
						{

						objDataForm.PS_Voucher_ID.value=objwi.attribute_list["PS_Voucher_ID"].value;

						}
						if(objwi.attribute_list["Validation"].value!="" )
						{

						objDataForm.Validation.value=objwi.attribute_list["Validation"].value;

						}
						if(objwi.attribute_list["Validation_Comments"].value!="" )
						{

						objDataForm.Validation_Comments.value=objwi.attribute_list["Validation_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}
						if(objwi.attribute_list["Split_Resolution_Comments"].value!="" )
						{

						objDataForm.Split_Resolution_Comments.value=objwi.attribute_list["Split_Resolution_Comments"].value;

						}
						if(objwi.attribute_list["No_Of_WI_Created"].value!="" )
						{

						objDataForm.No_Of_WI_Created.value=objwi.attribute_list["No_Of_WI_Created"].value;

						}
						if(objwi.attribute_list["WI_Serial_Number"].value!="" )
						{

						objDataForm.WI_Serial_Number.value=objwi.attribute_list["WI_Serial_Number"].value;

						}
						if(objwi.attribute_list["Cancel_Decision_Comments"].value!="" )
						{

						objDataForm.Cancel_Decision_Comments.value=objwi.attribute_list["Cancel_Decision_Comments"].value;

						}
						
						if(!loadcheckboxes())
						{
							return false;
						}

				}


				if (sWname.toUpperCase()=="RESCAN_WI")
				{	
						
						
						if(objwi.attribute_list["Document_Type"].value!="")
						{
						
						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;

						}
						
						
						if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
						if(objwi.attribute_list["Setid"].value!="" )
						{

						objDataForm.Setid.value=objwi.attribute_list["Setid"].value;

						}
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						if(objwi.attribute_list["AP_Business_Unit"].value!="" )
						{

						objDataForm.AP_Business_Unit.value=objwi.attribute_list["AP_Business_Unit"].value;

						}
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma_SBR(objwi.attribute_list["Amount"]);
						

						}
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						}

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						/*if(objwi.attribute_list["PS_Voucher_ID"].value!="" )
						{

						objDataForm.PS_Voucher_ID.value=objwi.attribute_list["PS_Voucher_ID"].value;

						}*/

						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}
					
						makeDateButtonDisb();
						disablecheckbox("chkExcp_Bad_Image");
						disablechecked("chkExcp_Bad_Image");
					
					

						if(!loadcheckboxes())
							{
								return false;
							}
							if(!loadClrCheckboxes())
							
							{
								return false;
							}
				}
	


				
				if (sWname.toUpperCase()=="PENDING_RESOLUTION")
				{	
					
						

						if(objwi.attribute_list["Document_Type"].value!="" )
						{

						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;

						}
						if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
						if(objwi.attribute_list["Setid"].value!="" )
						{

						objDataForm.Setid.value=objwi.attribute_list["Setid"].value;

						}
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						if(objwi.attribute_list["AP_Business_Unit"].value!="" )
						{

						objDataForm.AP_Business_Unit.value=objwi.attribute_list["AP_Business_Unit"].value;

						}
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma_SBR(objwi.attribute_list["Amount"]);
						

						}
						if(objwi.attribute_list["Received_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						}

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						

						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}
						if(objwi.attribute_list["Forward_To"].value!="" )
						{

						objDataForm.Forward_To.value=objwi.attribute_list["Forward_To"].value;

						}
						
						
						makeDateButtonDisb();

						//alert("pending load");
						
						if(!loadcheckboxes())
							{
								return false;
							}
						if(!loadClrCheckboxes())
							
							{
								return false;
							}
							
						for (var i=0;i<objDataForm.elements.length ;i++ )
						{
							if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
								{

								disablecheckbox(objDataForm.elements[i].name);
								
								}
						}


						objDataForm.Forward_To.focus();
			
				}



					if (sWname.toUpperCase()=="CANCEL_WI")
						{	
					
						objDataForm.Document_Type.focus();

						if(objwi.attribute_list["Document_Type"].value!="" )
						{

						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;

						}
						if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
						if(objwi.attribute_list["Setid"].value!="" )//Bug No:ResAP_CWA_7
						{

						objDataForm.Setid.value=objwi.attribute_list["Setid"].value;

						}
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						if(objwi.attribute_list["AP_Business_Unit"].value!="" )
						{

						objDataForm.AP_Business_Unit.value=objwi.attribute_list["AP_Business_Unit"].value;

						}
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma_SBR(objwi.attribute_list["Amount"]);
						

						}
						
						if(objwi.attribute_list["Received_Date"].value!="" )
						{
							
						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
						
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						}
						

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						
							
						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}
						if(objwi.attribute_list["Cancel_Decision"].value!="" )
						{

						objDataForm.Cancel_Decision.value=objwi.attribute_list["Cancel_Decision"].value;

						}
						if(objwi.attribute_list["Cancel_Decision_Comments"].value!="" )
						{

						objDataForm.Cancel_Decision_Comments.value=objwi.attribute_list["Cancel_Decision_Comments"].value;

						}

						
						makeDateButtonDisb();

						if(!loadcheckboxes())
							{
								return false;
							}
						if(!loadClrCheckboxes())
							
							{
								return false;
							}
						for (var i=0;i<objDataForm.elements.length ;i++ )
						{
							if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
								{

								disablecheckbox(objDataForm.elements[i].name);
								
								}
						}

						objDataForm.Cancel_Decision.focus();
							
				}


				if (sWname.toUpperCase()=="SPLIT_DOCS")
						{	
					
						objDataForm.Document_Type.focus();

						if(objwi.attribute_list["Document_Type"].value!="" )
						{

						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;

						}
						if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
						if(objwi.attribute_list["Setid"].value!="" )
						{

						objDataForm.Setid.value=objwi.attribute_list["Setid"].value;

						}
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						if(objwi.attribute_list["AP_Business_Unit"].value!="" )
						{

						objDataForm.AP_Business_Unit.value=objwi.attribute_list["AP_Business_Unit"].value;

						}
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma_SBR(objwi.attribute_list["Amount"]);
						

						}
						
						
						if(objwi.attribute_list["Received_Date"].value!="" )
						{
							
						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
					
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						}
						//alert("in cancel");

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						
							
						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}
						if(objwi.attribute_list["Split_Doc_Decision"].value!="" )
						{

						objDataForm.Split_Doc_Decision.value=objwi.attribute_list["Split_Doc_Decision"].value;

						}
						//alert("in split");
						if(objwi.attribute_list["Split_Resolution_Comments"].value!="" )
						{

						objDataForm.Split_Resolution_Comments.value=objwi.attribute_list["Split_Resolution_Comments"].value;

						}
						if(objwi.attribute_list["No_Of_WI_Created"].value!="" )
						{

						objDataForm.No_Of_WI_Created.value=objwi.attribute_list["No_Of_WI_Created"].value;

						}
						if(objwi.attribute_list["WI_Serial_Number"].value!="" )
						{

						objDataForm.WI_Serial_Number.value=objwi.attribute_list["WI_Serial_Number"].value;

						}
								
						
						makeDateButtonDisb();

						if(!loadcheckboxes())
							{
								return false;
							}
						if(!loadClrCheckboxes())
							
							{
								return false;
							}
						for (var i=0;i<objDataForm.elements.length ;i++ )
						{
							if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
								{

								disablecheckbox(objDataForm.elements[i].name);
								
								}
						}

					}

					if (sWname.toUpperCase()=="VALIDATION")
						{	
					
						

						if(objwi.attribute_list["Document_Type"].value!="" )
						{

						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;

						}
						if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
						if(objwi.attribute_list["Setid"].value!="" )
						{

						objDataForm.Setid.value=objwi.attribute_list["Setid"].value;

						}
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						if(objwi.attribute_list["AP_Business_Unit"].value!="" )
						{

						objDataForm.AP_Business_Unit.value=objwi.attribute_list["AP_Business_Unit"].value;

						}
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma_SBR(objwi.attribute_list["Amount"]);
						

						}
						if(objwi.attribute_list["PS_Voucher_ID"].value!="" )
						{

						objDataForm.PS_Voucher_ID.value=objwi.attribute_list["PS_Voucher_ID"].value;

						}
						
						
						if(objwi.attribute_list["Received_Date"].value!="" )
						{
							
						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
					
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						}
						//alert("in cancel");

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						
							
						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
					/*	if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}*/
						if(objwi.attribute_list["Validation"].value!="" )
						{

						objDataForm.Validation.value=objwi.attribute_list["Validation"].value;

						}
						if(objwi.attribute_list["Validation_Comments"].value!="" )
						{

						objDataForm.Validation_Comments.value=objwi.attribute_list["Validation_Comments"].value;

						}
						//alert("in split");
						
						makeDateButtonDisb();
						objDataForm.Validation.focus();
					}

					if (sWname.toUpperCase()=="APPROVAL")
						{	
					
						

						if(objwi.attribute_list["Document_Type"].value!="" )
						{

						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;

						}
						if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
						if(objwi.attribute_list["Setid"].value!="" )
						{

						objDataForm.Setid.value=objwi.attribute_list["Setid"].value;

						}
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						if(objwi.attribute_list["AP_Business_Unit"].value!="" )
						{

						objDataForm.AP_Business_Unit.value=objwi.attribute_list["AP_Business_Unit"].value;

						}
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma_SBR(objwi.attribute_list["Amount"]);
						

						}
						if(objwi.attribute_list["PS_Voucher_ID"].value!="" )
						{

						objDataForm.PS_Voucher_ID.value=objwi.attribute_list["PS_Voucher_ID"].value;

						}
						
						
						if(objwi.attribute_list["Received_Date"].value!="" )
						{
							
						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
					
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						}
						//alert("in cancel");

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						
							
						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
					/*	if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}*/
						if(objwi.attribute_list["Validation"].value!="" )
						{

						objDataForm.Validation.value=objwi.attribute_list["Validation"].value;

						}
						if(objwi.attribute_list["Validation_Comments"].value!="" )
						{

						objDataForm.Validation_Comments.value=objwi.attribute_list["Validation_Comments"].value;

						}

						if(objwi.attribute_list["Approval"].value!="" )
						{

						objDataForm.Approval.value=objwi.attribute_list["Approval"].value;

						}
						if(objwi.attribute_list["Approval_Comments"].value!="" )
						{

						objDataForm.Approval_Comments.value=objwi.attribute_list["Approval_Comments"].value;

						}
						//alert("in split");
						
						makeDateButtonDisb();
						objDataForm.Approval.focus();
					}
			

			if (sWname.toUpperCase()=="QUERY" || sWname.toUpperCase()=="WORK EXIT")
						{	
					
						

						if(objwi.attribute_list["Document_Type"].value!="" )
						{

						objDataForm.Document_Type.value=objwi.attribute_list["Document_Type"].value;

						}
						if(objwi.attribute_list["Document_Category"].value!="" )
						{

						objDataForm.Document_Category.value=objwi.attribute_list["Document_Category"].value;

						}
						if(objwi.attribute_list["Setid"].value!="" )
						{

						objDataForm.Setid.value=objwi.attribute_list["Setid"].value;

						}
						if(objwi.attribute_list["Vendor_ID"].value!="" )
						{

						objDataForm.Vendor_ID.value=objwi.attribute_list["Vendor_ID"].value;

						}
						if(objwi.attribute_list["Vendor_Name"].value!="" )
						{

						objDataForm.Vendor_Name.value=objwi.attribute_list["Vendor_Name"].value;

						}
						if(objwi.attribute_list["AP_Business_Unit"].value!="" )
						{

						objDataForm.AP_Business_Unit.value=objwi.attribute_list["AP_Business_Unit"].value;

						}
						if(objwi.attribute_list["Invoice_Number"].value!="" )
						{

						objDataForm.Invoice_Number.value=objwi.attribute_list["Invoice_Number"].value;

						}
						if(objwi.attribute_list["Invoice_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Invoice_Date'].value);
						objDataForm.Invoice_Date.value=retdate;

						}
						if(objwi.attribute_list["Amount"].value!="" )
						{

						objDataForm.TempAmount.value=dollarAmount_comma_SBR(objwi.attribute_list["Amount"]);
						

						}
						if(objwi.attribute_list["PS_Voucher_ID"].value!="" )
						{

						objDataForm.PS_Voucher_ID.value=objwi.attribute_list["PS_Voucher_ID"].value;

						}
						
						
						if(objwi.attribute_list["Received_Date"].value!="" )
						{
							
						var retdate=convertdatenew(objwi.attribute_list['Received_Date'].value);
						objDataForm.Received_Date.value=retdate;
						
						}
					
						if(objwi.attribute_list["Due_Date"].value!="" )
						{

						var retdate=convertdatenew(objwi.attribute_list['Due_Date'].value);
						objDataForm.Due_Date.value=retdate;
						
						}
						
						if(objwi.attribute_list["Priority"].value!="" )
						{

						objDataForm.Priority.value=objwi.attribute_list["Priority"].value;

						}
						//alert("in cancel");

						if(objwi.attribute_list["Invoice_Description"].value!="" )
						{

						objDataForm.Invoice_Description.value=objwi.attribute_list["Invoice_Description"].value;

						}
						
							
						if(objwi.attribute_list["Exception_Comments"].value!="" )
						{

						objDataForm.Exception_Comments.value=objwi.attribute_list["Exception_Comments"].value;

						}
						if(objwi.attribute_list["Exception_Resol_Comments"].value!="" )
						{

						objDataForm.Exception_Resol_Comments.value=objwi.attribute_list["Exception_Resol_Comments"].value;

						}
						if(objwi.attribute_list["Validation"].value!="" )
						{

						objDataForm.Validation.value=objwi.attribute_list["Validation"].value;

						}
						if(objwi.attribute_list["Validation_Comments"].value!="" )
						{

						objDataForm.Validation_Comments.value=objwi.attribute_list["Validation_Comments"].value;

						}

						if(objwi.attribute_list["Approval"].value!="" )
						{

						objDataForm.Approval.value=objwi.attribute_list["Approval"].value;

						}
						if(objwi.attribute_list["Approval_Comments"].value!="" )
						{

						objDataForm.Approval_Comments.value=objwi.attribute_list["Approval_Comments"].value;

						}
						if(objwi.attribute_list["Split_Doc_Decision"].value!="" )
						{

						objDataForm.Split_Doc_Decision.value=objwi.attribute_list["Split_Doc_Decision"].value;

						}
						if(objwi.attribute_list["Split_Resolution_Comments"].value!="" )
						{

						objDataForm.Split_Resolution_Comments.value=objwi.attribute_list["Split_Resolution_Comments"].value;

						}
						if(objwi.attribute_list["No_Of_WI_Created"].value!="" )
						{

						objDataForm.No_Of_WI_Created.value=objwi.attribute_list["No_Of_WI_Created"].value;

						}
						if(objwi.attribute_list["WI_Serial_Number"].value!="" )
						{

						objDataForm.WI_Serial_Number.value=objwi.attribute_list["WI_Serial_Number"].value;

						}
						if(objwi.attribute_list["Cancel_Decision"].value!="" )
						{

						objDataForm.Cancel_Decision.value=objwi.attribute_list["Cancel_Decision"].value;

						}
						if(objwi.attribute_list["Cancel_Decision_Comments"].value!="" )
						{

						objDataForm.Cancel_Decision_Comments.value=objwi.attribute_list["Cancel_Decision_Comments"].value;

						}


						//alert("in split");
						
						makeDateButtonDisb();
					}


//Added for SBR_18 by Santul
isFormLoaded=true;
//Added for SBR_18 by Santul

	}


function loadcheckboxes()
{
	 //alert("tesi");
	 var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
	 var objWI_objwi=window.top.wi_object;
	 for (var i=0;i<objDataForm.elements.length ;i++ )
	 {
		 var sAttrName=objDataForm.elements[i].name.substring(3);
		// alert(sAttrName);
		// alert(objWI_objwi.attribute_list['Excp_Bad_Image'].value);

		//alert("Checkbox Type : "+objDataForm.elements[i].type);
		//alert("CheckBox Name : "+objDataForm.elements[i].name.substring(0,3));
		//alert("Database Value : "+objWI_objwi.attribute_list[sAttrName].value);
		 if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" && (objWI_objwi.attribute_list[sAttrName].value==1 || objWI_objwi.attribute_list[sAttrName].value==2))
		 {
			objDataForm.elements[i].checked=true;
		 }
	 }
	 //alert("inside loadcheckboxes: ");
	return true;
}

function loadClrCheckboxes()
{
	 var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
	 var objWI_objwi=window.top.wi_object;
	 for (var i=0;i<objDataForm.elements.length ;i++ )
	 {
		 var sAttrName=objDataForm.elements[i].name.substring(3);
		 if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="clr" )
		 {
			
			
			if(objWI_objwi.attribute_list[sAttrName].value=="1" || objWI_objwi.attribute_list[sAttrName].value=="2")
				objDataForm.elements[i].disabled=false;			
			if(objWI_objwi.attribute_list[sAttrName].value=="2")			
				objDataForm.elements[i].checked=true;			
			if(objWI_objwi.attribute_list[sAttrName].value=="0" || objWI_objwi.attribute_list[sAttrName].value=="")
				objDataForm.elements[i].disabled=true;
		 }
	 }
	 return true;
}
			
 function setExcpChkBoxes()
 {
	 //alert("setExcpChkBoxes");
	 var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
	 var objwi=window.top.wi_object;

	 if(objDataForm.Document_Type.value=="" && objDataForm.Document_Category.value=="")
	 {
		for (var i=0;i<objDataForm.elements.length ;i++ )
	    {
			if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
			{
				disablecheckbox(objDataForm.elements[i].name);
				disablechecked(objDataForm.elements[i].name);

			}
		}

	 }
	else if((objDataForm.Document_Category.value=="Archival") && (objDataForm.Document_Type.value=="Invoice" || objDataForm.Document_Type.value=="Credit Note" || objDataForm.Document_Type.value=="Debit Note" ||objDataForm.Document_Type.value=="Other"))
	 {
		enablecheckbox("chkExcp_Bad_Image");
		enablecheckbox("chkExcp_Duplicate");
		enablecheckbox("chkExcp_Multiple_Documents");
		enablecheckbox("chkExcp_New_Vendor_Setup");
		enablecheckbox("chkExcp_Fixed_Asset_Coding");
		//////Added on 16th June 2008(Tarit Gupta)
		enablecheckbox("chkExcp_Client");
		//////Added on 16th June 2008(Tarit Gupta)
		
		disablecheckbox("chkExcp_Missing_Incorrect_Approval");
		disablechecked("chkExcp_Missing_Incorrect_Approval");
		disablecheckbox("chkExcp_Missing_Documentation");
		disablechecked("chkExcp_Missing_Documentation");
		disablecheckbox("chkExcp_Not_An_Invoice");
		disablechecked("chkExcp_Not_An_Invoice");
		disablecheckbox("chkExcp_Invalid_Cost_Center_Account");
		disablechecked("chkExcp_Invalid_Cost_Center_Account");
		
		if(objDataForm.Document_Type.value=="Other")
		 {
		disablecheckbox("chkExcp_Invalid_Cost_Center_Account");
		disablechecked("chkExcp_Invalid_Cost_Center_Account");
		
		}



	 }
	else if((objDataForm.Document_Category.value=="Unprocessed") && (objDataForm.Document_Type.value==""))
	 {
	
			for (var i=0;i<objDataForm.elements.length ;i++ )
			{
				if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
				{
					disablecheckbox(objDataForm.elements[i].name);
					disablechecked(objDataForm.elements[i].name);
				
				}
			}
	
	
	}
		
	else if(objDataForm.Document_Type.value=="Invoice" || objDataForm.Document_Type.value=="Credit Note" || objDataForm.Document_Type.value=="Debit Note" )
	  
	 {
		for (var i=0;i<objDataForm.elements.length ;i++ )
			{
				if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
				{
					enablecheckbox(objDataForm.elements[i].name);
				
				}
			}
	 
	 
	 }

	else if (objDataForm.Document_Type.value=="Other")
	 {
		
		for (var i=0;i<objDataForm.elements.length ;i++ )
	    {
			if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
			{
				
				disablecheckbox(objDataForm.elements[i].name);
				disablechecked(objDataForm.elements[i].name);
				
			}
		}
		enablecheckbox("chkExcp_Not_An_Invoice");
		
	 }


 }

 function disablecheckbox(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).className="EWTableCheckTextDisb";

	//objDataForm(field).className="EWTableCheckTextDisb";
	objDataForm(field).disabled=true;
	//objDataForm(field).className="EWTableCheckTextDisb";
	
}
function disablechecked(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).checked=false;
}
function enablecheckbox(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).disabled=false;
	
}
function makeDateButtonDisb()
		{
		var objDataForm= window.parent.frames["left"].document.forms["dataform"];
		objDataForm.SearchVName.disabled=true;
		document.getElementById('Date_IMG').disabled=true;
		document.getElementById('Date_IMG1').disabled=true;
		document.getElementById('Date_IMG2').disabled=true;
		}

function SetTabIndex()
{
	try
	{	//alert("in set tab index");
       var objdataForm =document.forms["dataform"];
	   var TabSet=0;
	   var TotalElements=objdataForm.elements.length;
	   
		var imgindx1=10;
		 var imgindx2=13;
		  var imgindx3=15;

	   //alert("Workstepname: "+window.top.wi_object.workstep_name);
	   for(var i=0;i<TotalElements;i++)
		{           
		   //alert(objdataForm.elements[i].name);
			//alert(objdataForm.elements[i].tabIndex);

		  if(i==imgindx1)
		   { 		//alert(objdataForm.elements[i].name);
			    TabSet=TabSet+1;
				document.getElementById('Date_IMG').tabIndex=TabSet;
				//alert(document.getElementById('Reconciliation_Date_From_IMG').tabIndex);
				//alert("img "+TabSet);				
		   }
		   //alert();
		   if(i==imgindx2)
		   {	//alert(objdataForm.elements[i].name);
                TabSet=TabSet+1;
				document.getElementById('Date_IMG1').tabIndex=TabSet;
				//alert(document.getElementById('Reconciliation_Date_To_IMG').tabIndex);
				//alert("img "+TabSet);	
		   }
		   if(i==imgindx2)
		   {	//alert(objdataForm.elements[i].name);
                TabSet=TabSet+1;
				document.getElementById('Date_IMG2').tabIndex=TabSet;
				//alert(document.getElementById('Reconciliation_Date_To_IMG').tabIndex);
				//alert("img "+TabSet);	
		   }
		   if(objdataForm.elements[i].type=='text')
		   {
			   if(!objdataForm.elements[i].readOnly)
			   {   
				   
				   TabSet=TabSet+1;
				   objdataForm.elements[i].tabIndex=TabSet;
				   //alert(objdataForm.elements[i].name+"--"+TabSet);
			   }
			   else
			   {
				   objdataForm.elements[i].tabIndex="";
			   }
		    }
			else if(objdataForm.elements[i].type=='select-one')
			{
			   if(!objdataForm.elements[i].disabled)
				{			   
                   TabSet=TabSet+1;
				   objdataForm.elements[i].tabIndex=TabSet;	
				  // alert(objdataForm.elements[i].name+"--"+TabSet);
				}
				else
				{
					objdataForm.elements[i].tabIndex="";
				}
			}
			else if(objdataForm.elements[i].type=='button')
			{
				if(!objdataForm.elements[i].disabled)
				{  
					TabSet=TabSet+1;
				    objdataForm.elements[i].tabIndex=TabSet;
					//alert(objdataForm.elements[i].name+"--"+TabSet);
				}
				else
				{
					objdataForm.elements[i].tabIndex="";
				}
			}			
		    
		}
       
	}
	catch(e)
	{
		alert("Error in SetTabIndex: ");
	}
}


////Added on 12th June 2008(Santul Sharma)

function DisableFields()
{
	var objwi=window.top.wi_object;
	var sWname=objwi.workstep_name.toUpperCase();
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	//Remove on 16th june(Tarit Gupta)
	//alert(objDataForm.Split_Doc_Decision.value);
	//Remove on 16th june(Tarit Gupta)
	if(objDataForm.Split_Doc_Decision.value=="Reject")
	{
		disablefield("No_Of_WI_Created");
		disablefield("WI_Serial_Number");
	}
	else
	{
		enablefield("No_Of_WI_Created");
		enablefield("WI_Serial_Number");
		
	}
	return true;
}
function enablefield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=false;
	objDataForm(field).className="TextFieldColor";
	
}

function disablefield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorDisb";
	objDataForm(field).value="";
}
////Added on 12th June 2008(Santul Sharma)
function ClearVnameVid()//Change No:Res_11
{

var objDataForm= window.parent.frames["left"].document.forms["dataform"];
if(objDataForm.Vendor_Name.value!="")
	{
	objDataForm.Vendor_Name.value="";
	objDataForm.Vendor_ID.value="";


	}
}

function ResAP_setDueDate()
{

var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
if(objDataForm.Invoice_Date.value=="")
	{
objDataForm.Due_Date.value="";
	}
	if(objDataForm.Due_Date.value!="")
	{
	objDataForm.Due_Date.value="";
	}

var tempInvDate=new Date(objDataForm.Invoice_Date.value);

tempInvDate=tempInvDate.setDate(tempInvDate.getDate()+30);

var tempInvDate1=new Date(tempInvDate);
var tempDate=tempInvDate1.getDate();
var tempMonth=Number(tempInvDate1.getMonth()+1);
//var tempMonth=Number(tempInvDate1.getMonth());
var tempYear=Number(tempInvDate1.getYear());
if(tempMonth>=1 && tempMonth<=9)
	{
	tempMonth=tempMonth.toString();
	tempMonth="0"+tempMonth;
	}
if(tempDate>=1 && tempDate<=9)
	{
	//tempDate=tempDate.toString();
	tempDate="0"+tempDate;
	}
if(tempYear<=99)
	{
	
	tempYear=1900+tempYear;

	}
	
var tempdueDate=tempMonth+'/'+tempDate+'/'+tempYear;

objDataForm.Due_Date.value=tempdueDate;

}

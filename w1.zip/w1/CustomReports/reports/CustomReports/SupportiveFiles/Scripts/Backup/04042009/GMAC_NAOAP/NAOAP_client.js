/* 
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-GMAC
Module : GMAC-SBR
File Name : Semperian_client.js
Author :   Tarit Gupta
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date			Change By		Change Description (Bug No. (If Any))
(DD/MM/YYYY)

04/09/2008		Tarit Gupta		NaoAP_IN_25
01/10/2008		Tarit Gupta		NAOAP_04
20/10/2008		Tarit Gupta		NAOAP_09  BodyText in mail to include Invoice details
27/10/2008		Santul Sharma	NAO_11
31/10/2008		Tarit Gupta		Comm_03
----------------------------------------------------------------------------------------------------
*/



var sRaisedExp="0";
var ToFlag=false;
var CCFlag=false;



			function NAOAP_Done()
			{   
				
				
				var objwi=window.top.wi_object;
				
				var objDataForm= window.parent.frames["left"].document.forms["dataform"];
				var sWname=window.top.wi_object.workstep_name.toUpperCase();
				
				if(sWname.toUpperCase()=='PENDING_RESOLUTION' || sWname.toUpperCase()=='INDEXING' || sWname.toUpperCase()=='PROCESSING')
				{
					if(objDataForm.SubjectLine.value.indexOf('\n')!=-1)
					{
						CheckForEnter(objDataForm.SubjectLine);	
					}


				}
				if(!NAOAP_checkmandatory_Save())
					{
						return false;
					
					}
				else if(sWname.toUpperCase()=="RESCAN_WI" || sWname.toUpperCase()=="PENDING_RESOLUTION" || sWname.toUpperCase()=="CANCEL_WI" || sWname.toUpperCase()=="SPLIT_DOCS")
					{
						if(!NAOAP_Save('D'))
						{
							return false;
						}
					}
				else if(!NAOAP_Save())
					{
						return false;
					}
					
				//Added on 08/12/2008
			/*	if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING" || sWname.toUpperCase()=="PENDING_RESOLUTION")
				{
					if(objDataForm.SubjectLine.value!='')
					{
						if(objDataForm.SubjectLine.value.indexOf('\n')!=-1)
						{
							alert("You cannot Press Enter in the Subject Line");
							return false;
						}
					}
				}  */
				//Added on 08/12/2008
			

				if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING")
					{

					
						
						if((trim(objDataForm.Document_Type.value)=="Other" || trim(objDataForm.Document_Type.value)=="Query") && sRaisedExp=="0")
							{
								//NAOAP_04:Added by Tarit as on 1st Oct
								var Confirm = confirm("Document type is selected as "+objDataForm.Document_Type.value+",Do you want to cancel the Work Item");
		
								if(Confirm)
								isModified(objwi.attribute_list["Excp_Not_An_Invoice"],"1");
								else
								{	
									objDataForm.Document_Type.focus();
									return false;
								}
								//NAOAP_04:Added by Tarit as on 1st Oct
							}//Comm_03 Added by Tarit as on 31-10-08
						else if(objwi.attribute_list["Intro_Type"].value!="BH" && objDataForm.chkExcp_Bad_Image.checked==true)
							{
							window.parent.frames["left"].document.getElementById("tab1").style.display='none';
							window.parent.frames["left"].document.getElementById("tab2").style.display='block';
							alert("Can not raise Bad Image Exception as Work item has been introducted Manually");
							return false;
							}
							//Comm_03 Added by Tarit as on 31-10-08
						
							else if(sRaisedExp!="1")
							{

								
								if(!NAOAP_fetch_Vname_InvoiceNo())
								{
								return false;
								}
								if(Fetch_Vendor_Data())
								{
									if(!fetch_Vname_CompName_NAOAP())
									{
									return false;
									}
								}
							}
							//NAO_09 Added by bhawna as on 10/20/2008
							if(!prepareMailBody())
								return false;
							//NAO_09 Added by bhawna as on 10/20/2008
								
						
					}
					
					if(sWname.toUpperCase()=="VALIDATION")

						{
								if(trim(objDataForm.Validation.value)=="Fail" )
									{					
										objDataForm.Priority.value="Urgent";
										isModified(objwi.attribute_list["PriorityLevel"],"3");
										
										
									}
						}
					
				if(sWname.toUpperCase()=="PENDING_RESOLUTION")
				{ 
				if(!(SaveReminder(objwi,objDataForm)))
					return false;
				if(!prepareMailBody())
					return false;

				}
			
						
						
					//alert("at 54");
					if(!Check_For_Route_Exception_NAOAP())
						{
					
							return false;
						}
					
					
					
					
					
					if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING" || sWname.toUpperCase()=="RESCAN_WI" || sWname.toUpperCase()=="PENDING_RESOLUTION" || sWname.toUpperCase()=="CANCEL_WI" || sWname.toUpperCase()=="SPLIT_DOCS")
					{
					
					if(!NAOAP_UpdateExpData())
						{

						return false;
						}

					}

					if(!NAOAP_SaveAtDone())
						{
							return false;
						}
						
				
			return true;
			//return false;
			
			}


	function NAOAP_setfilter(objDataForm,objwi)
	{
		
	
	isModified(objwi.attribute_list["qException"],"");
	//var qExp=objwi.attribute_list["qException"].value;
	var qExp="";
	
	if(objDataForm.chkExcp_Missing_Incorrect_Approval.checked==true)
		qExp=qExp+"A";
	if(objDataForm.chkExcp_New_Vendor_Setup.checked==true)
		qExp=qExp+"B";
	if(objDataForm.chkExcp_Incorrect_Coding.checked==true)
		qExp=qExp+"C";
	if(objDataForm.chkExcp_Missing_PO.checked==true)
		qExp=qExp+"D";
	
	if(objDataForm.chkExcp_Goods_Recpt_Varification.checked==true)
		qExp=qExp+"E";
	if(objDataForm.chkExcp_Cost_Quality_Variance.checked==true)
		qExp=qExp+"F";
	
	isModified(objwi.attribute_list["qException"],qExp);
	
		
	return true;
	}

	
	function NAOAP_Save(sMode)
		{
			
			
			var objwi=window.top.wi_object;
			var objDataForm= window.parent.frames["left"].document.forms["dataform"];
			var sWname=window.top.wi_object.workstep_name.toUpperCase();
			
		
		
			if(!combos(objwi,objDataForm))
				{
				return false;
				}
				
			
				if(sWname.toUpperCase()!="WORK INTRODUCTION")
				{
					
					
						objwi.attribute_list['Amount'].value=RemoveComma_NAOAP();
						objwi.attribute_list['Amount'].modified_flag=true;
			
				}	
			
				
				
			
			if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING")
							{
			
								sRaisedExp =NAOAP_checkboxRaised(objwi,objDataForm);
								
								if(!NAOAP_setfilter(objDataForm,objwi))
								{
								return false;								
								}
																
								if(trim(objDataForm.Priority.value)=="Urgent")
								{
								//alert("sff:"+objwi.attribute_list["PriorityLevel"]);
								isModified(objwi.attribute_list["PriorityLevel"],"3");
								}
								else
								isModified(objwi.attribute_list["PriorityLevel"],"1");
								
								
							}
					
			if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING" || sWname.toUpperCase()=="PENDING_RESOLUTION")
					{
						if(!NAOAP_SaveEmailinfo(objwi,objDataForm))
						{
						return false;	
						}
					}		

			if(sWname.toUpperCase()=="RESCAN_WI" || sWname.toUpperCase()=="PENDING_RESOLUTION" || sWname.toUpperCase()=="CANCEL_WI" || sWname.toUpperCase()=="SPLIT_DOCS")
				{ 
				sRaisedExp =NAOAP_checkboxRaised(objwi,objDataForm);
				if(!NAOAP_checkboxClear(objwi,objDataForm,sMode))
					{	
					return false;
					}
				

				}
			
			
		return true;
		
		
		}

function NAOAP_Introduce()

{
	//alert("resap_client:60");
	var objwi=window.top.wi_object;
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	if(!NAOAP_Save())
		{
		return false;
		}
		
		
	if(!NAOAP_checkmandatory_Save())
		{
		  return false;
			  
		}
	if(!Check_Mandatory_Doctype())
		return false;
		


	if(trim(objDataForm.Priority.value)=="Urgent")
		{
		
		isModified(objwi.attribute_list["PriorityLevel"],"3");
		}
		
	return true;

}

function NAOAP_checkmandatory_Save()

{ 
	var objwi=window.top.wi_object;
	var sWname=objwi.workstep_name.toUpperCase();
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	sRaisedExp =NAOAP_checkboxRaised(objwi,objDataForm);
	
		if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING" || sWname.toUpperCase()=="CANCEL_WI" || sWname.toUpperCase()=="PENDING_RESOLUTION" || sWname.toUpperCase()=="RESCAN_WI" || sWname.toUpperCase()=="SPLIT_DOCS")
		{
			//alert("Just Before");
			if(window.parent.frames["left"].document.getElementById('tab2').style.display=="block")
				{
					window.parent.frames["left"].document.getElementById('tab2').style.display="none";
					window.parent.frames["left"].document.getElementById('tab1').style.display="block";
				}
			
		}

		if(sWname.toUpperCase()=="WORK INTRODUCTION")
		{		
			
			if(!(NAOAP_checkmandatory_Work_Intro(objDataForm)))
			{
               return false; 
			}
		}
	
	if(sWname.toUpperCase()=="INDEXING")

		{	

			if(!NAOAP_SaveEmailinfo(objwi,objDataForm))
						{
						return false;	
						}
			
			if(!(NAOAP_checkmandatory_Indexing(objDataForm)))
			{
			   
               return false; 
			}
			
		}	
	if(sWname.toUpperCase()=="PROCESSING")

		{
				if(!NAOAP_SaveEmailinfo(objwi,objDataForm))
						{
						return false;	
						}

			 if(!(NAOAP_checkmandatory_Processing(objDataForm)))
				{
				return false;
				}
		}	

	if(sWname.toUpperCase()=="CANCEL_WI")

		{
			 if(!(NAOAP_checkmandatory_Cancel_Wi(objDataForm)))
				{
				return false;
				}
		}
		if(sWname.toUpperCase()=="PENDING_RESOLUTION")

		{	
				
				if(!NAOAP_SaveEmailinfo(objwi,objDataForm))
						{
						return false;	
						}
			 
			 if(!(NAOAP_checkmandatory_Pending_Resolution(objDataForm)))
				{
				return false;
				}
		}
		

	
		if(sWname.toUpperCase()=="RESCAN_WI")
		{
			 if(!(NAOAP_checkmandatory_Rescan_Wi(objDataForm)))
				{
				return false;
				}
		}
	
		if(sWname.toUpperCase()=="SPLIT_DOCS")

		{
			 if(!(NAOAP_checkmandatory_Split_Docs(objDataForm)))
				{
				return false;
				}
		}
		if(sWname.toUpperCase()=="VALIDATION")

		{
			
			 if(!(NAOAP_checkmandatory_Validation(objDataForm)))
				{
				return false;
				}
		}
		

return true;


}



function NAOAP_checkmandatory_Work_Intro(objDataForm)
	{
					
					if(trim(objDataForm.Document_Type.value)=="" )
					{
						alert("Select the Document Type.");
						objDataForm.Document_Type.focus();
						return false;
					}	
					if(trim(objDataForm.Priority.value)=="" )
					{
						alert("Select the Priority.");
						objDataForm.Priority.focus();
						return false;
					}
					
					
				return true;


	}

function NAOAP_checkmandatory_Indexing(objDataForm)
	{
			var objwi=window.top.wi_object;
					
					
					
					if(trim(objDataForm.Document_Category.value)=="Archival" && trim(objDataForm.Document_Type.value)=="Other" )
					{
						alert("Document type can not be Other as Document Category is Archival.");
						objDataForm.Document_Type.focus();
						return false;
					}	
					if(trim(objDataForm.Document_Type.value)=="" )
					{
						alert("Select the Document Type.");

						objDataForm.Document_Type.focus();
						return false;
					}
		//Added by bhawna for PLMIC_04 on 11-sep-2008
					if(objDataForm.Document_Type.value!="Other")
		{
					if(trim(objDataForm.Document_Category.value)=="" )
					{
						alert("Select the Document Category.");

						objDataForm.Document_Category.focus();
						return false;
					}	
					if(sRaisedExp!="1")
						{
							
							if(trim(objDataForm.CompanyName.value)=="" )
							{
							alert("Company Name can not be blank.");
							objDataForm.CompanyName.focus();
							return false;
							}
							if(trim(objDataForm.CompanyCode.value)=="" )
							{
							alert("Company Code can not be blank.");
							objDataForm.CompanyCode.focus();
							return false;
							}

							if(trim(objDataForm.Vendor_Name.value)=="" )
							{
							alert("Vendor Name can not be blank.");
							objDataForm.Vendor_Name.focus();
							return false;
							}
							if(trim(objDataForm.Vendor_ID.value)=="" )
							{
							alert("Vendor ID number can not be blank.");
							objDataForm.Vendor_ID.focus();
							return false;
							}


							if(trim(objDataForm.Invoice_Number.value)=="" )
							{
							alert("Invoice Number can not be blank.");
							objDataForm.Invoice_Number.focus();
							return false;
							}
							if(trim(objDataForm.Invoice_Date.value)=="" )
							{
							alert("Invoice Date can not be blank.");
							objDataForm.Invoice_Date.select();
							window.parent.frames["left"].document.getElementById("Date_IMG").focus();
							//objDataForm.Invoice_Date.focus();
							return false;
							}

							if(trim(objDataForm.TempAmount.value)=="" )
							{
							alert("Amount can not be blank.");

							objDataForm.TempAmount.focus();
							return false;
							}

							if(trim(objDataForm.Received_Date.value)=="" )
							{
							alert("Received Date can not be blank.");

							objDataForm.Received_Date.select();
							window.parent.frames["left"].document.getElementById("Date_IMG1").focus();
							//objDataForm.Received_Date.focus();
							return false;
							}
							if(trim(objDataForm.Due_Date.value)=="" )
							{
							alert("Due Date can not be blank.");


							objDataForm.Due_Date.select();
							window.parent.frames["left"].document.getElementById("Date_IMG2").focus();
							//objDataForm.Due_Date.focus();
							return false;
							}

							if(trim(objDataForm.Priority.value)=="")
							{
							alert("Select the Priority.");

							objDataForm.Priority.focus();

							return false;
							}
						}
		}
				
				if(ToFlag==false && sRaisedExp=="1" && objDataForm.AllToEmailIds.disabled==false)
					{
						
									
						window.parent.frames["left"].document.getElementById("tab1").style.display='none';
						window.parent.frames["left"].document.getElementById("tab2").style.display='block';
						alert("Please Select To EmailIds.");
						objDataForm.AllToEmailIds.focus();

						return false;
					}
					
				/*	if(CCFlag==false && sRaisedExp=="1" && objDataForm.AllCCEmailIds.disabled==false)
					{
						
									
						window.parent.frames["left"].document.getElementById("tab1").style.display='none';
						window.parent.frames["left"].document.getElementById("tab2").style.display='block';
						alert("Please Select CC EmailIds.");
						objDataForm.AllCCEmailIds.focus();

						return false;
					}
					*/
					if(trim(objDataForm.SubjectLine.value)=="" && sRaisedExp=="1" && objDataForm.SubjectLine.readOnly==false)
					{
						
									
						window.parent.frames["left"].document.getElementById("tab1").style.display='none';
						window.parent.frames["left"].document.getElementById("tab2").style.display='block';
						alert("Subject Line can not be blank.");
						objDataForm.SubjectLine.focus();

						return false;
					}
					if(trim(objDataForm.BodyText.value)=="" && sRaisedExp=="1" && objDataForm.BodyText.readOnly==false)
					{
						
									
						window.parent.frames["left"].document.getElementById("tab1").style.display='none';
						window.parent.frames["left"].document.getElementById("tab2").style.display='block';
						alert("Body Text can not be blank.");
						objDataForm.BodyText.focus();

						return false;
					}
					
					if(trim(objDataForm.Exception_Comments.value)=="" && sRaisedExp=="1")
					{
						
									
						window.parent.frames["left"].document.getElementById("tab1").style.display='none';
						window.parent.frames["left"].document.getElementById("tab2").style.display='block';
						alert("Exception Comments can not be blank.");
						objDataForm.Exception_Comments.focus();

						return false;
					}
					
														
				return true;

	}

function NAOAP_checkmandatory_Processing(objDataForm)
	{
					
					if(trim(objDataForm.Document_Category.value)=="Archival" && trim(objDataForm.Document_Type.value)=="Other" )
					{
						alert("Document type can not be Other as Document Category is Archival.");
						objDataForm.Document_Type.focus();
						return false;
					}	
					if(trim(objDataForm.Document_Type.value)=="" )
					{
						alert("Select the Document Type.");

						objDataForm.Document_Type.focus();
						return false;
					}
					//Added by bhawna for PLMIC_04 on 11-sep-2008
		if(objDataForm.Document_Type.value!="Other")
		{
					if(trim(objDataForm.Document_Category.value)=="" )
					{
						alert("Select the Document Category.");

						objDataForm.Document_Category.focus();
						return false;
					}	
					
					if(sRaisedExp!="1")
					{

							

							if(trim(objDataForm.CompanyName.value)=="" )
							{
							alert("Company Name can not be blank.");
							objDataForm.CompanyName.focus();
							return false;
							}
							if(trim(objDataForm.CompanyCode.value)=="" )
							{
							alert("Company Code can not be blank.");
							objDataForm.CompanyCode.focus();
							return false;
							}

							if(trim(objDataForm.Vendor_Name.value)=="" )
							{
							alert("Vendor Name can not be blank.");
							objDataForm.Vendor_Name.focus();
							return false;
							}
							if(trim(objDataForm.Vendor_ID.value)=="" )
							{
							alert("Vendor ID number can not be blank.");
							objDataForm.Vendor_ID.focus();
							return false;
							}


							if(trim(objDataForm.Invoice_Number.value)=="" )
							{
							alert("Invoice Number can not be blank.");
							objDataForm.Invoice_Number.focus();
							return false;
							}
							if(trim(objDataForm.Invoice_Date.value)=="" )
							{
							alert("Invoice Date can not be blank.");
							objDataForm.Invoice_Date.select();
							window.parent.frames["left"].document.getElementById("Date_IMG").focus();
							//objDataForm.Invoice_Date.focus();
							return false;
							}

							if(trim(objDataForm.TempAmount.value)=="" )
							{
							alert("Amount can not be blank.");

							objDataForm.TempAmount.focus();
							return false;
							}
							if(trim(objDataForm.SAP_Document_Number.value)=="" )
							{
								alert("SAP Document Number can not be blank.");
								objDataForm.SAP_Document_Number.focus();
								return false;
							}

							if(trim(objDataForm.Received_Date.value)=="" )
							{
								alert("Received Date can not be blank.");
								objDataForm.Received_Date.select();
								window.parent.frames["left"].document.getElementById("Date_IMG1").focus();
								//objDataForm.Received_Date.focus();
								return false;
							}
							if(trim(objDataForm.Due_Date.value)=="" )
							{
								alert("Due Date can not be blank.");
								objDataForm.Due_Date.select();
								window.parent.frames["left"].document.getElementById("Date_IMG2").focus();
								//objDataForm.Due_Date.focus();
								return false;
							}

							if(trim(objDataForm.Priority.value)=="")
							{
							alert("Select the Priority.");

							objDataForm.Priority.focus();

							return false;
							}
					}
		}
					
					if(ToFlag==false && sRaisedExp=="1" && objDataForm.AllToEmailIds.disabled==false)
					{
						
									
						window.parent.frames["left"].document.getElementById("tab1").style.display='none';
						window.parent.frames["left"].document.getElementById("tab2").style.display='block';
						alert("Please Select To EmailIds.");
						objDataForm.AllToEmailIds.focus();

						return false;
					}
					
				/*	if(CCFlag==false && sRaisedExp=="1" && objDataForm.AllCCEmailIds.disabled==false)
					{
						
									
						window.parent.frames["left"].document.getElementById("tab1").style.display='none';
						window.parent.frames["left"].document.getElementById("tab2").style.display='block';
						alert("Please Select CC EmailIds.");
						objDataForm.AllCCEmailIds.focus();

						return false;
					}
					*/
					if(trim(objDataForm.SubjectLine.value)=="" && sRaisedExp=="1" && objDataForm.SubjectLine.readOnly==false)
					{
						
									
						window.parent.frames["left"].document.getElementById("tab1").style.display='none';
						window.parent.frames["left"].document.getElementById("tab2").style.display='block';
						alert("Subject Line can not be blank.");
						objDataForm.SubjectLine.focus();

						return false;
					}
					if(trim(objDataForm.BodyText.value)=="" && sRaisedExp=="1" && objDataForm.BodyText.readOnly==false)
					{
						
									
						window.parent.frames["left"].document.getElementById("tab1").style.display='none';
						window.parent.frames["left"].document.getElementById("tab2").style.display='block';
						alert("Body Text can not be blank.");
						objDataForm.BodyText.focus();

						return false;
					}
					
					
					
					
					if(trim(objDataForm.Exception_Comments.value)=="" && sRaisedExp=="1")
					{
						
									
						window.parent.frames["left"].document.getElementById("tab1").style.display='none';
						window.parent.frames["left"].document.getElementById("tab2").style.display='block';
						alert("Exception Comments can not be blank.");
						objDataForm.Exception_Comments.focus();

						return false;
					}

		
	return true;

	}
	
	function NAOAP_checkmandatory_Rescan_Wi(objDataForm)

		{
			var sxception=NAOAP_checkallexcepcleared(objDataForm);

			if(sxception=="1") 
			{
				
				window.parent.frames["left"].document.getElementById("tab1").style.display='none';
				window.parent.frames["left"].document.getElementById("tab2").style.display='block';
				alert("Please Clear All Raised Exceptions");
				return false;
			}

		


			if(sxception=="0" && objDataForm.Exception_Resol_Comments.value=="")
			{
					
					window.parent.frames["left"].document.getElementById("tab1").style.display='none';
					window.parent.frames["left"].document.getElementById("tab2").style.display='block';
					alert("Exception Resolution Comments can not be blank.");
					objDataForm.Exception_Resol_Comments.focus();
					return false;
			}
		
			
			return true;
		}
		

	function NAOAP_checkmandatory_Cancel_Wi(objDataForm)

		{
			
			var sxception=NAOAP_checkallexcepcleared(objDataForm);
			var objwi=window.top.wi_object;

			if(trim(objDataForm.Cancel_Decision.value)=="" )
			{
					

					window.parent.frames["left"].document.getElementById("tab1").style.display='block';
					window.parent.frames["left"].document.getElementById("tab2").style.display='none';
					alert("Select the Cancel Decision.");
					objDataForm.Cancel_Decision.focus();
					return false;
			}

			if(trim(objDataForm.Cancel_Decision.value)=="Reject" && trim(objDataForm.Cancel_Decision_Comments.value)=="")
			{
					alert("Cancel Decision Comments can not be blank.");
					objDataForm.Cancel_Decision_Comments.focus();
					return false;
			}
			
			

			if(sxception=="1" && trim(objDataForm.Cancel_Decision.value)!="Approved") 
			{
				
				window.parent.frames["left"].document.getElementById("tab1").style.display='none';
				window.parent.frames["left"].document.getElementById("tab2").style.display='block';
				alert("Please Clear All Raised Exceptions");
				return false;
			}
			
			if(trim(objDataForm.Cancel_Decision.value)!="Approved" && trim(objDataForm.Exception_Resol_Comments.value)=="")
			{
					
					window.parent.frames["left"].document.getElementById("tab1").style.display='none';
					window.parent.frames["left"].document.getElementById("tab2").style.display='block';
					alert("Exception Resolution Comments can not be blank.");
					objDataForm.Exception_Resol_Comments.focus();
					return false;
			}

			if(trim(objDataForm.Cancel_Decision.value)=="Approved" && trim(objDataForm.PhysicalDocsSent.value)=="" && objwi.attribute_list["Intro_Type"].value=="BH")
			{
					window.parent.frames["left"].document.getElementById("tab2").style.display='none';
					window.parent.frames["left"].document.getElementById("tab1").style.display='block';
					
					alert("Please select Physical Document Sent.");
					objDataForm.PhysicalDocsSent.focus();
					return false;
			}
		
			


				return true;

		}

		function NAOAP_checkmandatory_Pending_Resolution(objDataForm)
			{
			var sxception=NAOAP_checkallexcepcleared(objDataForm);
			var objwi=window.top.wi_object;
			if(trim(objDataForm.FollowUpReqd.value)=="" && objDataForm.FollowUpReqd.disabled==false && sxception=="1" )
					{
						
									
						window.parent.frames["left"].document.getElementById("tab1").style.display='none';
						window.parent.frames["left"].document.getElementById("tab2").style.display='block';
						alert("Please either clear all exceptions or select Follow up Required.");
						objDataForm.FollowUpReqd.focus();

						return false;
					}
			else if(sxception=="1")
				{
				window.parent.frames["left"].document.getElementById("tab1").style.display='none';
				window.parent.frames["left"].document.getElementById("tab2").style.display='block';
				alert("Please clear all exceptions.");
				return false;
			
				}
			else if(trim(objDataForm.FollowUpReqd.value)=="Yes" && objwi.attribute_list["AllFollowUps"].value=="Escalation" && objDataForm.FollowUpReqd.disabled==false)
				{
						window.parent.frames["left"].document.getElementById("tab1").style.display='none';
						window.parent.frames["left"].document.getElementById("tab2").style.display='block';
						alert("Can not Select Follow up Required as 'Yes' as Esclation has already been raised .");
						objDataForm.FollowUpReqd.focus();

						return false;
			
				}
			
			if(trim(objDataForm.FollowUpReqd.value)=="Yes")
				{
				if(!PrevfollowupCheck(objDataForm))
					{
					return false;
					}
				}
			//alert("TempEmailids"+TempEmailids);
			//alert("TempEmailids11"+sRaisedExp);
			//alert("TempEmailids22"+objDataForm.AllToEmailIds.disabled);

				if(ToFlag==false && objDataForm.AllToEmailIds.disabled==false)
					{
						
									
						window.parent.frames["left"].document.getElementById("tab1").style.display='none';
						window.parent.frames["left"].document.getElementById("tab2").style.display='block';
						alert("Please Select To EmailIds.");
						objDataForm.AllToEmailIds.focus();

						return false;
					}
					
				/*	if(CCFlag==false && objDataForm.AllCCEmailIds.disabled==false)
					{
						
									
						window.parent.frames["left"].document.getElementById("tab1").style.display='none';
						window.parent.frames["left"].document.getElementById("tab2").style.display='block';
						alert("Please Select CC EmailIds.");
						objDataForm.AllCCEmailIds.focus();

						return false;
					}
					*/
					if(trim(objDataForm.SubjectLine.value)=="" && objDataForm.SubjectLine.readOnly==false)
					{
						
									
						window.parent.frames["left"].document.getElementById("tab1").style.display='none';
						window.parent.frames["left"].document.getElementById("tab2").style.display='block';
						alert("Subject Line can not be blank.");
						objDataForm.SubjectLine.focus();

						return false;
					}
					
					if(trim(objDataForm.BodyText.value)=="" && objDataForm.BodyText.readOnly==false)
					{
						
									
						window.parent.frames["left"].document.getElementById("tab1").style.display='none';
						window.parent.frames["left"].document.getElementById("tab2").style.display='block';
						alert("Body Text can not be blank.");
						objDataForm.BodyText.focus();

						return false;
					}
			
			
			if(sxception=="1" && trim(objDataForm.FollowUpReqd.value)=="No") 
			{
				
				window.parent.frames["left"].document.getElementById("tab1").style.display='none';
				window.parent.frames["left"].document.getElementById("tab2").style.display='block';
				alert("Please Clear All Raised Exceptions");
				return false;
			}
			
			if(trim(objDataForm.Exception_Resol_Comments.value)=="" && trim(objDataForm.FollowUpReqd.value)!="Yes")
			{
			
					
					
					window.parent.frames["left"].document.getElementById("tab1").style.display='none';
					window.parent.frames["left"].document.getElementById("tab2").style.display='block';
					alert("Exception Resolution Comments can not be blank.");
					objDataForm.Exception_Resol_Comments.focus();
					return false;
			}
			if(trim(objDataForm.Forward_To.value)=="" && trim(objDataForm.FollowUpReqd.value)!="Yes")
			{
					window.parent.frames["left"].document.getElementById("tab1").style.display='block';
					window.parent.frames["left"].document.getElementById("tab2").style.display='none';
					alert("Select the Forward To.");
					objDataForm.Forward_To.focus();
					return false;
			}
		return true;
			}

function NAOAP_checkmandatory_Split_Docs(objDataForm)
{
			var sxception=NAOAP_checkallexcepcleared(objDataForm);

			
			if(trim(objDataForm.Split_Doc_Decision.value)=="" )
				{
					alert("Select the Split Doc Decision.");
					objDataForm.Split_Doc_Decision.focus();
					return false;
				}
				if(trim(objDataForm.No_Of_WI_Created.value)=="" && trim(objDataForm.Split_Doc_Decision.value)=="Accept" )
				{
					alert("No Of WI Created can not be blank.");
					objDataForm.No_Of_WI_Created.focus();
					return false;
				}
				if(trim(objDataForm.WI_Serial_Number.value)=="" && trim(objDataForm.Split_Doc_Decision.value)=="Accept" )
				{
					alert("WI Serial Number can not be blank.");
					objDataForm.WI_Serial_Number.focus();
					return false;
				}
				if(trim(objDataForm.Split_Doc_Decision.value)=="Accept" && parseInt(objDataForm.No_Of_WI_Created.value)=="0")
			{
					
					
					window.parent.frames["left"].document.getElementById("tab1").style.display='block';
					window.parent.frames["left"].document.getElementById("tab2").style.display='none';
					alert("No of Workitems created cannot be zero.");
					objDataForm.No_Of_WI_Created.focus();
					return false;
			}

				

		if(sxception=="1") 
			{
				
				window.parent.frames["left"].document.getElementById("tab1").style.display='none';
				window.parent.frames["left"].document.getElementById("tab2").style.display='block';
				alert("Please Clear All Raised Exceptions");
				return false;
			}
			if(trim(objDataForm.Exception_Resol_Comments.value)=="")
			{
					
					window.parent.frames["left"].document.getElementById("tab1").style.display='none';
					window.parent.frames["left"].document.getElementById("tab2").style.display='block';
					alert("Exception Resolution Comments can not be blank.");
					objDataForm.Exception_Resol_Comments.focus();
					return false;
			}
			
			
		
			

return true;

}
 function NAOAP_checkmandatory_Validation(objDataForm)
 {
 
			 if(trim(objDataForm.Validation.value)=="")
				{
					alert("Select the Validation.");
					objDataForm.Validation.focus();
					return false;
				}
				if(trim(objDataForm.Validation_Comments.value)=="" && trim(objDataForm.Validation.value)=="Fail")
				{
					alert("Validation Comments can not be blank.");
					objDataForm.Validation_Comments.focus();
					return false;
				}
				
 return true;
 
 
 }

 



function isModified(oldVal,newVal)
	{
		
	 if(oldVal.value!=newVal)
	 {
	  oldVal.value=newVal;
	  
	  oldVal.modified_flag=true;
	 }
	}

function NAOAP_fnSelectVName()
	{
		
		if(trim(document.dataform.CompanyName.value)=='')
		{
			alert("Kindly select the Company Name First");
			document.dataform.CompanyName.focus(true);
			return false;

		}

		var sFeatures="dialogHeight:500px; dialogWidth:575px; status:no; dialogHide:no;";
		var sVendorInfo=window.showModalDialog("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\NAOAP\\SearchVenderNameMain.jsp?CompanyNameURL="+encodeURIComponent(document.dataform.CompanyName.value)+"",'',sFeatures);
		
		if(sVendorInfo!=undefined)
		{
			var sVendorData= sVendorInfo.split('\025');
			document.dataform.Vendor_ID.value=sVendorData[0];
			//Change No:NAO_11
			if(sVendorData[2]=='Y')
			{
				//document.dataform.Vendor_Name.readonly=false;  
				//document.dataform.Vendor_Name.className="TextFieldColorLight";
				enablefield_VName("Vendor_Name");
				document.dataform.Vendor_Name.value="";
				//document.dataform.Vendor_Name_Hidden.value='Y';

				
			}
			else
			{	
				disablefield_VName("Vendor_Name");
				document.dataform.Vendor_Name.value=sVendorData[1];
			}
			
		}
	}

function NAOAP_checkboxRaised(objWI_objwi,objDataForm)
{	
	var flag=0;            ///to indicate no exception is checked but if one is checked then set flag as 1
	for (var i=0;i<objDataForm.elements.length ;i++ )
	 {
		var sAttrName=objDataForm.elements[i].name.substring(3);
		
		if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="chk" )
		{
			
			if(objDataForm.elements[i].disabled ==false && objDataForm.elements[i].checked)
			{
				
				isModified(objWI_objwi.attribute_list[sAttrName],"1");
				flag=1;
			}
			 else if(objDataForm.elements[i].disabled ==false)
			{			 
				
				isModified(objWI_objwi.attribute_list[sAttrName],"");
				
			}
		}
		
	 }
	
	return flag;
	
}

function NAOAP_checkboxClear(objWI_objwi,objDataForm,sMode)
{		
	var flag=0;            ///to indicate no exception is checked but if one is checked then set flag as 1
	for (var i=0;i<objDataForm.elements.length ;i++ )
	 {
		var sAttrName=objDataForm.elements[i].name.substring(3);
		
		if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].name.substring(0,3)=="clr" )
		{
			
			
			if(objDataForm.elements[i].disabled ==false && objDataForm.elements[i].checked)
			{				
				if(sMode=="D")
					isModified(objWI_objwi.attribute_list[sAttrName],"0");
				else
					isModified(objWI_objwi.attribute_list[sAttrName],"2");
			}
			else if(objWI_objwi.attribute_list[sAttrName].value==2)
			{
				isModified(objWI_objwi.attribute_list[sAttrName],"1");
			}
			//	isModified(objWI_objwi.attribute_list[sAttrName],"");
		}
		
	 }
	
	return true;
	
}
function NAOAP_getExceptionList(objDataForm,sWname)
{	
	var stringtosend="";
		for ( i=0; i < objDataForm.elements.length ; i++)
		{	
			if(objDataForm.elements[i].type=="checkbox" && objDataForm.elements[i].checked==true )
			{	if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING")
				{
				
				 stringtosend += "~" + objDataForm.elements[i].name + "-" +"0";
				}
				else if(sWname.toUpperCase()=="RESCAN_WI" || sWname.toUpperCase()=="PENDING_RESOLUTION" || sWname.toUpperCase()=="CANCEL_WI" || sWname.toUpperCase()=="SPLIT_DOCS")
				{
					
				if(objDataForm.elements[i].name.substring(objDataForm.elements[i].name,3)=="clr")
				 stringtosend += "~" + objDataForm.elements[i].name + "-" +"1";
				if(objDataForm.elements[i].name.substring(objDataForm.elements[i].name,3)=="chk" && objDataForm.elements[i].disabled==false)
					stringtosend += "~" + objDataForm.elements[i].name + "-" +"0";
				}

			}
		}
		
		
	return stringtosend.substring(1,stringtosend.length);	
}

function NAOAP_UpdateExpData()
{
	
	var objwi=window.top.wi_object;
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
    var sWname=objwi.workstep_name.toUpperCase();
	var sWiName=objwi.attribute_list["WorkItemName"].value;
	var scheckedboxes=NAOAP_getExceptionList(objDataForm,sWname);

		if (scheckedboxes!="")
			{
			
				try
					{
												
						if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING")
						{	
								
							var ExceptionRasiedcomments=trim(objDataForm.Exception_Comments.value);
						
							
							ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\NAOAP\\NAOAP_Exp_Data.jsp","sProcessinstanceid="+encodeURIComponent(sWiName)+"&sWrkStepname="+encodeURIComponent(sWname)+"&sExpData="+encodeURIComponent(scheckedboxes)+"&sExceptionRasiedcomments="+encodeURIComponent(ExceptionRasiedcomments)+"&sExceptionRAISEDDATETIME="+encodeURIComponent("")+"&sExceptionResolvedcomments="+encodeURIComponent(""));	
						
						}
						else if(sWname.toUpperCase()=="RESCAN_WI" || sWname.toUpperCase()=="PENDING_RESOLUTION" || sWname.toUpperCase()=="CANCEL_WI" || sWname.toUpperCase()=="SPLIT_DOCS")
						{
							
							var ExceptionClearcomments=trim(objDataForm.Exception_Resol_Comments.value);
					
					ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\NAOAP\\NAOAP_Exp_Data.jsp","sProcessinstanceid="+encodeURIComponent(sWiName)+"&sWrkStepname="+encodeURIComponent(sWname)+"&sExpData="+encodeURIComponent(scheckedboxes)+"&sExceptionRasiedcomments="+encodeURIComponent("")+"&sExceptionRAISEDDATETIME="+encodeURIComponent("")+"&sExceptionResolvedcomments="+encodeURIComponent(ExceptionClearcomments));

						}
						
						if (iAjaxMainCode=="15")
							{
							alert('Error in updating Exception Details.');
							return false;
							}
						else if (sAjaxReturnValue!="Success")
							{
						alert('Error in updating Exception Details.');
						return false;
							}
					
					}
					catch(e)
					{
					alert('Error in updating Exception Details.');
					//alert(e.toString());
					return false;
					}
			}
     return true;  
}
function NAOAP_checkallexcepcleared(objDataForm)
{
	var flag=0;  // If flag is zero then user has not checked any of the raised exception else if he has cleared all raised exp then we set flag as 1
	for ( i=0; i < objDataForm.elements.length ; i++)
		{
			 if(objDataForm.elements[i].type=="checkbox")
			{
				
				
				if(objDataForm.elements[i].name.substring(objDataForm.elements[i].name,3)=="clr" && objDataForm.elements[i].disabled==false)
				{	
					
					if(objDataForm.elements[i].checked==false)
					flag =1; //this means that there is at least 1 clr checkbox that is checked 
					
				}
			}
		}
		return flag;
}

function NAOAP_SaveAtDone()
{
	

	var sWname=window.top.wi_object.workstep_name.toUpperCase();
	var objwi=window.top.wi_object;
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var sWiName=objwi.attribute_list["WorkItemName"].value;
	var sSplitVal=sWiName.split('-');
	var iWINo=parseFloat(sSplitVal[1]);
	var sPreviousWorkStep="";
	if(sWname.toUpperCase()=="WORK INTRODUCTION")
		sPreviousWorkStep=null;
	else
		sPreviousWorkStep=window.top.wi_object.attribute_list["Previous_Wrk_Step"].value;
ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\NAOAP\\NAOAP_Done_Data.jsp","sWiName="+encodeURIComponent(sWiName)+"&sENTRYDATETIME="+window.top.wi_object.attribute_list["EntryDateTime"].value+"&sCurrentWorkStep="+sWname+"&sPreviousWorkStep="+sPreviousWorkStep);

	if (iAjaxMainCode=="15")
		{
			alert('Error in updating NAOAP Done .');
			return false;
		}
	else if (sAjaxReturnValue!="Success")
		{
			alert('Error in updating NAOAP Done .');
			return false;
		}
return true;

}
			
			
function Check_For_Route_Exception_NAOAP()		
		{	

			

		var sWname=window.top.wi_object.workstep_name.toUpperCase();
		var objDataForm= window.parent.frames["left"].document.forms["dataform"];

		if(sWname.toUpperCase()=="INDEXING" || sWname.toUpperCase()=="PROCESSING")
		{
			
			
			if((objDataForm.chkExcp_Bad_Image.checked==true) && (objDataForm.chkExcp_New_Vendor_Setup.checked==true || objDataForm.chkExcp_Not_An_Invoice.checked==true || objDataForm.chkExcp_Missing_Incorrect_Approval.checked==true || objDataForm.chkExcp_Duplicate.checked==true || objDataForm.chkExcp_Multiple_Documents.checked==true || objDataForm.chkExcp_Incorrect_Coding.checked==true || objDataForm.chkExcp_Cost_Quality_Variance.checked==true || objDataForm.chkExcp_Multiple_Documents.checked==true || objDataForm.chkExcp_Missing_PO.checked==true || objDataForm.chkExcp_Goods_Recpt_Varification.checked==true))
			{
			window.parent.frames["left"].document.getElementById("tab1").style.display='none';
			window.parent.frames["left"].document.getElementById("tab2").style.display='block';
			alert("Exception of different category can not be raised simultaneously,Please select similar category of exception to proceed.");
			return false;
			}
			else if((objDataForm.chkExcp_New_Vendor_Setup.checked==true || objDataForm.chkExcp_Missing_Incorrect_Approval.checked==true  || objDataForm.chkExcp_Incorrect_Coding.checked==true || objDataForm.chkExcp_Cost_Quality_Variance.checked==true || objDataForm.chkExcp_Goods_Recpt_Varification.checked==true || objDataForm.chkExcp_Missing_PO.checked==true) && (objDataForm.chkExcp_Duplicate.checked==true || objDataForm.chkExcp_Not_An_Invoice.checked==true || objDataForm.chkExcp_Multiple_Documents.checked==true))
			{
			window.parent.frames["left"].document.getElementById("tab1").style.display='none';
			window.parent.frames["left"].document.getElementById("tab2").style.display='block';
			alert("Exception of different category can not be raised simultaneously,Please select similar category of exception to proceed.");
			return false;
			}
			else if((objDataForm.chkExcp_Not_An_Invoice.checked==true || objDataForm.chkExcp_Duplicate.checked==true) && (objDataForm.chkExcp_New_Vendor_Setup.checked==true || objDataForm.chkExcp_Missing_Incorrect_Approval.checked==true || objDataForm.chkExcp_Goods_Recpt_Varification.checked==true || objDataForm.chkExcp_Missing_PO.checked==true || objDataForm.chkExcp_Multiple_Documents.checked==true || objDataForm.chkExcp_Cost_Quality_Variance.checked==true))
			{
			
			window.parent.frames["left"].document.getElementById("tab1").style.display='none';
			window.parent.frames["left"].document.getElementById("tab2").style.display='block';
			alert("Exception of different category can not be raised simultaneously,Please select similar category of exception to proceed.");
			return false;
			}
			
			else if((objDataForm.chkExcp_Multiple_Documents.checked==true) && (objDataForm.chkExcp_New_Vendor_Setup.checked==true || objDataForm.chkExcp_Missing_Incorrect_Approval.checked==true || objDataForm.chkExcp_Missing_PO.checked==true || objDataForm.chkExcp_Cost_Quality_Variance.checked==true || objDataForm.chkExcp_Duplicate.checked==true || objDataForm.chkExcp_Not_An_Invoice.checked==true || objDataForm.chkExcp_Goods_Recpt_Varification.checked==true))
			{
			window.parent.frames["left"].document.getElementById("tab1").style.display='none';
			window.parent.frames["left"].document.getElementById("tab2").style.display='block';
			alert("Exception of different category can not be raised simultaneously,Please select similar category of exception to proceed.");
			return false;
			}
			

		}
		return true;
	}

function RemoveComma_NAOAP()
	{
			var objDataForm=window.parent.frames["left"].document.forms["dataform"];
			var sTransactionAmount=trim(objDataForm.TempAmount.value);
			var sAmount="";
			for (var i=0; i<sTransactionAmount.length; i++)
			{
				if(sTransactionAmount.substring(i,i+1)!=",")
					sAmount =sAmount + sTransactionAmount.substring(i, i+1);
			}
			return sAmount;

	}


function NAOAP_fetch_Vname_InvoiceNo()

{
//alert("fetch_Vname_InvoiceNo");
	var objwi=window.top.wi_object;
	var sWname=objwi.workstep_name.toUpperCase();
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var sVname=trim(objDataForm.Vendor_Name.value);
	var sInvoice_No=trim(objDataForm.Invoice_Number.value);
	var sWiName=objwi.attribute_list["WI_Name"].value;
	var samount=RemoveComma_NAOAP();
	//Added by Santul 10-09-2008 for PLMIC_03
	var sVendorID=trim(objDataForm.Vendor_ID.value);
	//Added by Santul 10-09-2008 for PLMIC_03
	var sFeatures="dialogHeight:500px; dialogWidth:575px; status:no; dialogHide:no;";
	
	ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\NAOAP\\NAOAP_fetch_Vname_InvoiceNo.jsp","sVname="+encodeURIComponent(sVname)+"&sInvoice_No="+encodeURIComponent(sInvoice_No)+"&sWiName="+encodeURIComponent(sWiName)+"&samount="+encodeURIComponent(samount)+"&sVendorID="+encodeURIComponent(sVendorID));
	
	if(sAjaxReturnValue=="Fail")
	{	//Bug No:NaoAP_IN_25
		var Confirm = confirm("Duplicate Vendor Name and Invoice Number and Amount,Do you want to cancel the Work Item.");

		if(Confirm)
			isModified(objwi.attribute_list["Excp_Duplicate"],"1");
		else
			return false;
	}




return true;
}


function fetch_Vname_CompName_NAOAP()

{

	var objwi=window.top.wi_object;
	var sWname=objwi.workstep_name.toUpperCase();
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var sVname=trim(objDataForm.Vendor_Name.value);
	var sVendorId=trim(objDataForm.Vendor_ID.value);
	var sCompanyName=trim(objDataForm.CompanyName.value);
	
	
	if(sCompanyName!="" && sVname!="")
		{


		ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\NAOAP\\Retrieve_CompName.jsp","VendorName="+encodeURIComponent(sVname)+"&VendorID="+encodeURIComponent(sVendorId)+"&CompanyName="+encodeURIComponent(sCompanyName));

			if(sAjaxReturnValue!="Success")
			{
				alert("Mismatch in the selected Company Name Retrieved and the Vendor Data");
				window.parent.frames["left"].document.getElementById("tab1").style.display='block';
				window.parent.frames["left"].document.getElementById("tab2").style.display='none';
				objDataForm.CompanyName.focus(true);
				return false;
			}
		}

return true;
}
function NAOAP_SaveEmailinfo(objwi,objDataForm)
{
var TempEmailids="";
var TempCCEmailids="";

//alert("objDataForm "+objDataForm.AllToEmailIds.length);
if(objDataForm.AllToEmailIds.disabled==false && objDataForm.AllCCEmailIds.disabled==false)
			{
				for(var i=0;i<objDataForm.AllToEmailIds.length;i++)
				{


					if(objDataForm.AllToEmailIds[i].selected && objDataForm.AllToEmailIds[i].value!="")
						{
						TempEmailids=TempEmailids+objDataForm.AllToEmailIds[i].value+',';
						}
				}
				TempCCEmailids=TempCCEmailids+objwi.dynamicConst_list['CONST_General_CC_Mail_ID'].Value+',';
				for(var i=0;i<objDataForm.AllCCEmailIds.length;i++)
				{
					if(objDataForm.AllCCEmailIds[i].selected && objDataForm.AllCCEmailIds[i].value!="")
					{
					TempCCEmailids=TempCCEmailids+objDataForm.AllCCEmailIds[i].value+',';
					}
				}
				
				if(TempEmailids!="")
				{
				TempEmailids=TempEmailids.substring(0,TempEmailids.length-1);
				ToFlag=true;
				}
				if(TempCCEmailids!="")
				{
				TempCCEmailids=TempCCEmailids.substring(0,TempCCEmailids.length-1);
				CCFlag=true;
				}

				
				isModified(objwi.attribute_list["AllToEmailIds"],TempEmailids);
				isModified(objwi.attribute_list["AllCCEmailIds"],TempCCEmailids);
			}
	else
	{
		
		isModified(objwi.attribute_list["AllToEmailIds"],"");
		isModified(objwi.attribute_list["AllCCEmailIds"],"");
	}





return true;

}

function SaveReminder(objwi,objDataForm)
{


if(objDataForm.FollowUpType.value!="")
isModified(objwi.attribute_list["AllFollowUps"],objDataForm.FollowUpType.value);
/*if(objwi.attribute_list["AllFollowUps"].value!="")
	{
	//var tempFollowup=objwi.attribute_list["AllFollowUps"].value+','+objDataForm.FollowUpType.value;
	 //tempFollowup=tempFollowup.substring(0,tempFollowup.length-1);
	isModified(objwi.attribute_list["AllFollowUps"],tempFollowup);
	}
else
	{
	alert("sel "+objDataForm.FollowUpType.value);
	isModified(objwi.attribute_list["AllFollowUps"],objDataForm.FollowUpType.value);
	//objwi.attribute_list["AllFollowUps"].value=objDataForm.FollowUpType.value;
	}
		*/				
return true;

}

function PrevfollowupCheck(objDataForm)
{
	var objwi=window.top.wi_object;
	var tempAllfollowup=objwi.attribute_list["AllFollowUps"].value;

	
	if(objDataForm.FollowUpType.value=="" && tempAllfollowup!="Escalation")
	{
	window.parent.frames["left"].document.getElementById("tab1").style.display='none';
	window.parent.frames["left"].document.getElementById("tab2").style.display='block';
	alert("Please select Follow up type.");
	objDataForm.FollowUpType.focus();

	return false;
	}
	else if(tempAllfollowup=="" && (objDataForm.FollowUpType.value=="Reminder2" || objDataForm.FollowUpType.value=="Escalation"))
	{
	window.parent.frames["left"].document.getElementById("tab1").style.display='none';
	window.parent.frames["left"].document.getElementById("tab2").style.display='block';
	alert("Please select Reminder1 as Follow up type.");
	objDataForm.FollowUpType.focus();
	return false;
	}
	else if(tempAllfollowup=="Reminder1" && (objDataForm.FollowUpType.value=="Escalation" || objDataForm.FollowUpType.value=="Reminder1"))
	{
	window.parent.frames["left"].document.getElementById("tab1").style.display='none';
	window.parent.frames["left"].document.getElementById("tab2").style.display='block';
	alert("Please select Reminder2 as Follow up type.");
	objDataForm.FollowUpType.focus();
	return false;
	
	}
	else if(tempAllfollowup=="Reminder2" && (objDataForm.FollowUpType.value=="Reminder2" || objDataForm.FollowUpType.value=="Reminder1"))
	{
	window.parent.frames["left"].document.getElementById("tab1").style.display='none';
	window.parent.frames["left"].document.getElementById("tab2").style.display='block';
	alert("Please select Esclation as Follow up type.");
	objDataForm.FollowUpType.focus();
	return false;
	}
	else if(tempAllfollowup=="Escalation")
	{
	window.parent.frames["left"].document.getElementById("tab1").style.display='none';
	window.parent.frames["left"].document.getElementById("tab2").style.display='block';
	alert("Can not select Follow up type further.");
	objDataForm.FollowUpType.focus();
	return false;
	
	}

	
	


return true;
}

function Fetch_Vendor_Data()
{

	var objwi=window.top.wi_object;
	var sWname=objwi.workstep_name.toUpperCase();
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var sVname=trim(objDataForm.Vendor_Name.value);
	var sVendorId=trim(objDataForm.Vendor_ID.value);
	var sCompanyName=trim(objDataForm.CompanyName.value);
	var sWiName=objwi.attribute_list["WI_Name"].value;
	
	
//Changed by Bhawna	 for PLMIC_05 on 23 Sep 2008
//ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\PLMIC\\Retrieve_CompName.jsp","VendorName="+encodeURIComponent(sVname)+"&VendorID="+encodeURIComponent(sVendorId));
ServerRequest("..\\..\\..\\..\\webdesktop\\CustomForms\\GMAC\\NAOAP\\Retrieve_CompName.jsp","VendorName="+encodeURIComponent(sVname)+"&VendorID="+encodeURIComponent(sVendorId)+"&CompanyName="+encodeURIComponent(sCompanyName));

	

	//if(sCompanyName!=sAjaxReturnValue)
	if(sAjaxReturnValue=="Found")
	{
		
		window.parent.frames["left"].document.getElementById("tab1").style.display='block';
		window.parent.frames["left"].document.getElementById("tab2").style.display='none';
		return true;
	}
	else
	{
		return false;
	}

return true;
}

function prepareMailBody()
{
	var objwi=window.top.wi_object;
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var sMailBody="";
	if(objDataForm.chkExcp_Incorrect_Coding.checked==true || objDataForm.chkExcp_Missing_Incorrect_Approval.checked==true || objDataForm.chkExcp_Goods_Recpt_Varification.checked==true || objDataForm.chkExcp_Missing_PO.checked==true)
	{
		
		sMailBody=sMailBody+trim(objDataForm.BodyText.value)+"\n"+"Voucher details: "+"\n"+"Invoice #: "+ objDataForm.Invoice_Number.value+"\n"+"Invoice Date : "+ objDataForm.Invoice_Date.value+"\n"+"Invoice Amount : "+ objDataForm.TempAmount.value+"\n"+"Due Date : "+ objDataForm.Due_Date.value+"\n"+"Vendor Name : "+ objDataForm.Vendor_Name.value+"\n"+"Vendor ID : "+ objDataForm.Vendor_ID.value+"\n"+"Company Code : "+ objDataForm.CompanyCode.value;
		
		isModified(objwi.attribute_list["Mailbody"],sMailBody);
		
	}
	else
	{
		isModified(objwi.attribute_list["Mailbody"],trim(objDataForm.BodyText.value));

	}

	return true;


}

function escapeVal(textarea,replaceWith)
{ 

	textarea.value = escape(textarea.value); 

	for(i=0; i<textarea.value.length; i++)
	{ 

	if(textarea.value.indexOf("%0D%0A") > -1)
	{ 
		textarea.value=textarea.value.replace("%0D%0A",replaceWith)
	}
	else if(textarea.value.indexOf("%0A") > -1)
	{ 

		textarea.value=textarea.value.replace("%0A",replaceWith)
	}
	else if(textarea.value.indexOf("%0D") > -1)
	{ 
		textarea.value=textarea.value.replace("%0D",replaceWith)
	}

}

textarea.value=unescape(textarea.value);
return textarea.value;
}

function CheckForEnter(object)
{

	var objwi=window.top.wi_object;
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var sWname=window.top.wi_object.workstep_name.toUpperCase();
	var SubjectLine=objDataForm.SubjectLine.value;
	
	if(window.event.keyCode==13 || SubjectLine.indexOf('\n')!=-1)
	{
		//alert("Enter cannot be used in the Subject Line");
		
		/*for(var i=0;i<objDataForm.elements.length;i++)
		{
			
			if(objDataForm.elements[i].type=='checkbox' && objDataForm.elements[i].checked==true)
			{
				objDataForm.elements[i].checked=false;
								
			}
		}*/
		//SubjectLine=SubjectLine.replace('\n', '', 'g');
		//SubjectLine=SubjectLine.replace(new RegExp( "\n", "g" ),"...");
		SubjectLine=escapeVal(objDataForm.SubjectLine,'');
		
		/*DisEmailFd();
		if(sWname.toUpperCase()=='PENDING_RESOLUTION')
		{
			loadcheckboxes();
			populate_Mails_Fields();
				
		}
		
		return false;*/
	}
	return true;
}
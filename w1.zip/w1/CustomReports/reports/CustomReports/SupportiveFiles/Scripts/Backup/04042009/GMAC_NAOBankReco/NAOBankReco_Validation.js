/*
----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group : Application �Projects
Product / Project : Omniflow/WNS-GMAC
Module : GMAC-PLMIC
File Name : NAOBankReco_Validation.js
Author :   Tarit Gupta
----------------------------------------------------------------------------------------------------
 
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date			Change By		Change Description (Bug No. (If Any))
(DD/MM/YYYY)

16/09/2008		Bhawna Gupta	NBR_01

----------------------------------------------------------------------------------------------------
*/
function load()
{	
	
	var objwi=window.top.wi_object;
    var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
	var sWname=objwi.workstep_name.toUpperCase();

	
			
			
			if (sWname.toUpperCase()=="WORK INTRODUCTION")
			{	
				//FillBankNameCombo();
				objDataForm.Reconciliation_type.focus();

				if(objwi.attribute_list["Reconciliation_type"].value!="" )
				{

				objDataForm.Reconciliation_type.value=objwi.attribute_list["Reconciliation_type"].value;

				}

				if(objwi.attribute_list["Reconciliation_Date_From"].value!="" )
				{

				var retdate=convertdatenew(objwi.attribute_list['Reconciliation_Date_From'].value);
				objDataForm.Reconciliation_Date_From.value=retdate;
				}
				else//Addded by Tarit as on 11-08-09
				{
				//objDataForm.Reconciliation_Date_From;
				CalRecDate(objDataForm.Reconciliation_Date_From);
				
				}
				// Addded by Tarit as on 11-08-09
				if(objwi.attribute_list["Reconciliation_Date_To"].value!="" )
				{
				
				
				var retdate=convertdatenew(objwi.attribute_list['Reconciliation_Date_To'].value);
				objDataForm.Reconciliation_Date_To.value=retdate;
				}
				else//NAO_01 Addded by Tarit as on 16-08-09
				{
				//objDataForm.Reconciliation_Date_From;
				CalRecDate(objDataForm.Reconciliation_Date_To);
				
				}

				if(objwi.attribute_list["Bank_Name"].value!="" )
				{	
					objDataForm.Bank_Name.value=objwi.attribute_list["Bank_Name"].value;
				}

				if(objwi.attribute_list["Bank_Acc_Number"].value!="" )
				{
					objDataForm.Bank_Acc_Number.value=objwi.attribute_list["Bank_Acc_Number"].value;
				}




			}
  



			if (sWname.toUpperCase()=="PROCESSING")
			{	

				//FillBankNameCombo();
				objDataForm.Reconciliation_type.focus();

				//alert(objwi.attribute_list["Reconciliation_type"].value);
				if(objwi.attribute_list["Reconciliation_type"].value!="")
				{

				objDataForm.Reconciliation_type.value=objwi.attribute_list["Reconciliation_type"].value;

				}
				if(objwi.attribute_list["Reconciliation_Date_From"].value!="" )
				{

				var retdate=convertdatenew(objwi.attribute_list['Reconciliation_Date_From'].value);
				objDataForm.Reconciliation_Date_From.value=retdate;
				}
				else//Addded by Tarit as on 11-08-09
				{
				//objDataForm.Reconciliation_Date_From;
				CalRecDate(objDataForm.Reconciliation_Date_From);
				
				}
				//Addded by Tarit as on 11-08-09
				if(objwi.attribute_list["Reconciliation_Date_To"].value!="" )
				{
				
				//objDataForm.Reconciliation_Date_To.value=objwi.attribute_list["Reconciliation_Date_To"].value;
				var retdate=convertdatenew(objwi.attribute_list['Reconciliation_Date_To'].value);
				objDataForm.Reconciliation_Date_To.value=retdate;
				}
				else//NAO_01 Addded by Tarit as on 16-08-09
				{
				//objDataForm.Reconciliation_Date_From;
				CalRecDate(objDataForm.Reconciliation_Date_To);
				
				}

				if(objwi.attribute_list["Bank_Acc_Number"].value!="")
				{

					objDataForm.Bank_Acc_Number.value=objwi.attribute_list["Bank_Acc_Number"].value;

				}
				if(objwi.attribute_list["Bank_Name"].value!="")
				{
					
					objDataForm.Bank_Name.value=objwi.attribute_list["Bank_Name"].value;

				}

				if(objwi.attribute_list["Bank_Statement_Balance"].value!="")
				{

					objDataForm.fBank_Statement_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Bank_Statement_Balance"]);

				}

				if(objwi.attribute_list["SAP_Bank_Ledger_Balance"].value!="")
				{

					objDataForm.fSAP_Bank_Ledger_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["SAP_Bank_Ledger_Balance"]);

				}

				if(objwi.attribute_list["Comments"].value!="" )
				{

					objDataForm.Comments.value=objwi.attribute_list["Comments"].value;

				} 
				if(objwi.attribute_list["Mgr_Approval_Comments"].value!="" )
				{

				objDataForm.Mgr_Approval_Comments.value=objwi.attribute_list["Mgr_Approval_Comments"].value;

				} 
				



			}


				
				

			if (sWname.toUpperCase()=="MANAGER_APPROVAL" || sWname.toUpperCase()=="QUERY" || sWname.toUpperCase()=="WORK EXIT")
			{	

			
				

				if(objwi.attribute_list["Reconciliation_type"].value!="")
				{

				objDataForm.Reconciliation_type.value=objwi.attribute_list["Reconciliation_type"].value;
				//alert(objDataForm.Reconciliation_type.value);

				}
				//alert(objDataForm.Reconciliation_type.value);

				if(objwi.attribute_list["Reconciliation_Date_From"].value!="" )
				{

				var retdate=convertdatenew(objwi.attribute_list['Reconciliation_Date_From'].value);
				objDataForm.Reconciliation_Date_From.value=retdate;
				}
				if(objwi.attribute_list["Reconciliation_Date_To"].value!="" )
				{

				//objDataForm.Reconciliation_Date_To.value=objwi.attribute_list["Reconciliation_Date_To"].value;
				var retdate=convertdatenew(objwi.attribute_list['Reconciliation_Date_To'].value);
				objDataForm.Reconciliation_Date_To.value=retdate;
				}
				
				if(objwi.attribute_list["Bank_Name"].value!="")
				{

				objDataForm.Bank_Name.value=objwi.attribute_list["Bank_Name"].value;

				}

				if(objwi.attribute_list["Bank_Acc_Number"].value!="")
				{

				objDataForm.Bank_Acc_Number.value=objwi.attribute_list["Bank_Acc_Number"].value;

				}
				//onchangedoctype(objDataForm);

				if(objwi.attribute_list["Bank_Statement_Balance"].value!="")
				{

				objDataForm.fBank_Statement_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Bank_Statement_Balance"]);

				}

				if(objwi.attribute_list["SAP_Bank_Ledger_Balance"].value!="")
				{

				objDataForm.fSAP_Bank_Ledger_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["SAP_Bank_Ledger_Balance"]);

				}


				if(objwi.attribute_list["Comments"].value!="" )
				{

				objDataForm.Comments.value=objwi.attribute_list["Comments"].value;


				} 

				if(objwi.attribute_list["Approval_Decision"].value!="" )
				{

				objDataForm.Approval_Decision.value=objwi.attribute_list["Approval_Decision"].value;


				} 
				if(objwi.attribute_list["Mgr_Approval_Comments"].value!="" )
				{

				objDataForm.Mgr_Approval_Comments.value=objwi.attribute_list["Mgr_Approval_Comments"].value;

				} 
				


			}



//Added for SBR_18 by Santul
isFormLoaded=true;
//Added for SBR_18 by Santul

}





function onchangedoctype()
{
var objDataForm= window.parent.frames["left"].document.forms["dataform"];
var objwi=window.top.wi_object;
//alert(objDataForm.Reconciliation_type.value);

if(objDataForm.Reconciliation_type.value=="Bank Account Reconciliation")
	{
	
	
	enablefield("fBank_Statement_Balance");
	enablefield("fBank_Statement_GL_Balance");
	enablefield("fBalance_Forward_Escheats");
	enablefield("fCurrent_Period_Escheats");
	
	//Remove by Tarit Gupta as on 07-07-08
	//disablelightBARdatefield("fOther_Adjustments");
	//Remove by Tarit Gupta as on 07-07-08
	
	//Added by Tarit Gupta as on 07-07-08
	enablefield("fOther_Adjustments");
	//Added by Tarit Gupta as on 07-07-08

	//disablelightBARdatefield("fTotal_Check_GL_Balance");

	disablefield("fCheck_Outstanding");
	disablefield("fEscheat_Total");
	disablefield("fAdjustments");
	//disablelightfield("fCheck_GL_Balance");
	//objDataForm.fetchGLBal.disabled=false;
	//objDataForm.fetchAdjustments.disabled=false;

		/*if(objwi.attribute_list["Bank_Statement_Balance"].value!="")
		{

		objDataForm.fBank_Statement_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Bank_Statement_Balance"]);

		}

		if(objwi.attribute_list["Bank_Statement_GL_Balance"].value!="")
		{

		objDataForm.fBank_Statement_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Bank_Statement_GL_Balance"]);

		}



		if(objwi.attribute_list["Balance_Forward_Escheats"].value!="" )
		{

		objDataForm.fBalance_Forward_Escheats.value=DollarAmount_commaNeg(objwi.attribute_list["Balance_Forward_Escheats"]);

		}


		if(objwi.attribute_list["Current_Period_Escheats"].value!="" )
		{

		objDataForm.fCurrent_Period_Escheats.value=DollarAmount_commaNeg(objwi.attribute_list["Current_Period_Escheats"]);

		}  

		if(objwi.attribute_list["Other_Adjustments"].value!="" )
		{

		objDataForm.fOther_Adjustments.value=DollarAmount_commaNeg(objwi.attribute_list["Other_Adjustments"]);

		}   


		if(objwi.attribute_list["Total_Check_GL_Balance"].value!="" )
		{

		objDataForm.fTotal_Check_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Total_Check_GL_Balance"]);


		}*/
	

	}
if(objDataForm.Reconciliation_type.value=="Check Reconciliation")
	{
	
	
	enablefield("fCheck_Outstanding");
	enablefield("fEscheat_Total");
	enablefield("fAdjustments");
	//Added by Tarit Gupta as on 07-07-08
	enablefield("fBank_Statement_GL_Balance");
	//Added by Tarit Gupta as on 07-07-08
	//disablelightCRfield("fCheck_GL_Balance");

	disablefield("fBank_Statement_Balance");
	
	//Remove by Tarit Gupta as on 07-07-08
	
	//disablefield("fBank_Statement_GL_Balance");
	
	//Remove by Tarit Gupta as on 07-07-08
	
	disablefield("fBalance_Forward_Escheats");
	disablefield("fCurrent_Period_Escheats");
	//Remove by Tarit Gupta as on 07-07-08
	//disablelightdatefield("fOther_Adjustments");
	//Remove by Tarit Gupta as on 07-07-08
	//Added by Tarit Gupta as on 07-07-08
	disablefield("fOther_Adjustments");
	//Added by Tarit Gupta as on 07-07-08
	//disablelightdatefield("fTotal_Check_GL_Balance");
	//objDataForm.fetchGLBal.disabled=true;
	//objDataForm.fetchAdjustments.disabled=true;
		
	/*	if(objwi.attribute_list["Check_Outstanding"].value!="" )
		{

		objDataForm.fCheck_Outstanding.value=DollarAmount_commaNeg(objwi.attribute_list["Check_Outstanding"]);


		}


		if(objwi.attribute_list["Escheat_Total"].value!="" )
		{

		objDataForm.fEscheat_Total.value=DollarAmount_commaNeg(objwi.attribute_list["Escheat_Total"]);


		}

		if(objwi.attribute_list["Adjustments"].value!="" )
		{

		objDataForm.fAdjustments.value=DollarAmount_commaNeg(objwi.attribute_list["Adjustments"]);


		}


		if(objwi.attribute_list["Check_GL_Balance"].value!="" )
		{



		objDataForm.fCheck_GL_Balance.value=DollarAmount_commaNeg(objwi.attribute_list["Check_GL_Balance"]);


		} */
	
	}
if(objDataForm.Reconciliation_type.value=="")
	{
	
	disablefield("fCheck_Outstanding");
	disablefield("fEscheat_Total");
	disablefield("fAdjustments");
	//disablelightfield("fCheck_GL_Balance");

	disablefield("fBank_Statement_Balance");
	disablefield("fBank_Statement_GL_Balance");
	disablefield("fBalance_Forward_Escheats");
	disablefield("fCurrent_Period_Escheats");
	disablelightdatefield("fOther_Adjustments");
	//disablelightdatefield("fTotal_Check_GL_Balance");
	//objDataForm.fetchGLBal.disabled=true;
	
	}
}

function disablelightCRfield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorLightDisbExt";
	//objDataForm(field).value="";
	
}
function disablelightBARdatefield(field)
{
	//alert("dff");
	//alert(field);
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorLightDisb";
	
}

function readonly(field)
{
var objDataForm= window.parent.frames["left"].document.forms["dataform"];
objDataForm(field).className="TextFieldColor";


}
function enablefield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=false;
	objDataForm(field).className="TextFieldColor";
	
}

function disablefield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorDisb";
	objDataForm(field).value="";
}

function enablecombofield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).disabled=false;
	objDataForm(field).className="TextFieldColor";
	
}

function disablecombofield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).disabled=true;
	objDataForm(field).className="TextFieldColorDisb";
}
 function enabledatefield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).className="TextFieldColorDate";
	
}

function disabledatefield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorDisbDate";
	objDataForm(field).value="";
}

function enablelightfield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).className="TextFieldColorDate";
	
}

function disablelightdatefield(field)
{
	//alert("dff");
	//alert(field);
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorDisbDate";
	objDataForm(field).value="";
	
}
function disablelightfield(field)
{
	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	objDataForm(field).readOnly=true;
	objDataForm(field).className="TextFieldColorDisb";
	objDataForm(field).value="";
	
}



/*

function Cal_Chek_GL_Bal(obj)
{

	var objDataForm= window.parent.frames["left"].document.forms["dataform"];
	var Check_Outstanding=objDataForm.fCheck_Outstanding.value;
	var Adjustments=objDataForm.fAdjustments.value;

	if(Check_Outstanding=="" || Adjustments=="")
	{
	objDataForm.fCheck_GL_Balance.value="";
	}
	if(!checknegative(obj))
	{
	return false;	
	}
	if(!floattest_commaNeg(obj,13,2))
	{
	objDataForm.fOther_Adjustments.value="";
	return false;
	}
	if(!DollarAmount_commaNeg(obj))
	{
	return false;
	}

	Check_Outstanding=RemoveComma_SBR(Check_Outstanding);
	Adjustments=RemoveComma_SBR(Adjustments);
	if(Check_Outstanding!="" && Adjustments!="")
	{
	objDataForm.fCheck_GL_Balance.value=parseFloat(Check_Outstanding)+parseFloat(Adjustments);
	objDataForm.fCheck_GL_Balance.value=DollarAmount_commaNeg(objDataForm.fCheck_GL_Balance);
	}
	else
	objDataForm.fCheck_GL_Balance.value="";

	if(objDataForm.fCheck_GL_Balance.value!="")
	{
	objDataForm.fCheck_GL_Balance.value=DollarAmount_commaNeg(objDataForm.fCheck_GL_Balance);
	}
		

}
*/

function SetTabIndex()
{
	try
	{	//alert("in set tab index");
       var objdataForm =document.forms["dataform"];
	   var TabSet=0;
	   var TotalElements=objdataForm.elements.length;
	   
		var imgindx1=1;
		 var imgindx2=2;
	   //alert("Workstepname: "+window.top.wi_object.workstep_name);
	   for(var i=0;i<TotalElements;i++)
		{           
		   //alert(objdataForm.elements[i].name);
			//alert(objdataForm.elements[i].tabIndex);

		  if(i==imgindx1)
		   { 		//alert(objdataForm.elements[i].name);
			    TabSet=TabSet+1;
				document.getElementById('Reconciliation_Date_From_IMG').tabIndex=TabSet;
				//alert(document.getElementById('Reconciliation_Date_From_IMG').tabIndex);
				//alert("img "+TabSet);				
		   }
		   //alert();
		   if(i==imgindx2)
		   {	//alert(objdataForm.elements[i].name);
                TabSet=TabSet+1;
				document.getElementById('Reconciliation_Date_To_IMG').tabIndex=TabSet;
				//alert(document.getElementById('Reconciliation_Date_To_IMG').tabIndex);
				//alert("img "+TabSet);	
		   }
		   if(objdataForm.elements[i].type=='text')
		   {
			   if(!objdataForm.elements[i].readOnly)
			   {   
				   
				   TabSet=TabSet+1;
				   objdataForm.elements[i].tabIndex=TabSet;
				   //alert(objdataForm.elements[i].name+"--"+TabSet);
			   }
			   else
			   {
				   objdataForm.elements[i].tabIndex="";
			   }
		    }
			else if(objdataForm.elements[i].type=='select-one')
			{
			   if(!objdataForm.elements[i].disabled)
				{			   
                   TabSet=TabSet+1;
				   objdataForm.elements[i].tabIndex=TabSet;	
				  // alert(objdataForm.elements[i].name+"--"+TabSet);
				}
				else
				{
					objdataForm.elements[i].tabIndex="";
				}
			}
			else if(objdataForm.elements[i].type=='button')
			{
				if(!objdataForm.elements[i].disabled)
				{  
					TabSet=TabSet+1;
				    objdataForm.elements[i].tabIndex=TabSet;
					//alert(objdataForm.elements[i].name+"--"+TabSet);
				}
				else
				{
					objdataForm.elements[i].tabIndex="";
				}
			}			
		    
		}
       
	}
	catch(e)
	{
		alert("Error in SetTabIndex: ");
	}
}

function chk_other_adj(obj)
{

var objDataForm= window.parent.frames["left"].document.forms["dataform"];
/*var temp="";
if((parseFloat(obj.value))!=0)
	{
		//alert("nonzero");
		for (var count=0;count<obj.value.length ;count++ )
		{
			if(obj.value.charAt(count)!="0")
			{
				temp=temp+obj.value.charAt(count);
			}
		}
		obj.value=temp;
	}*/
if(objDataForm.fBank_Statement_Balance.value=="" || objDataForm.fBank_Statement_GL_Balance.value=="" || objDataForm.fBalance_Forward_Escheats.value=="" || objDataForm.fCurrent_Period_Escheats.value=="")
	{
	
	objDataForm.fOther_Adjustments.value="";
	
	}
}
function CalRecDate(temp)
{
				var tempRecDate=new Date();
				var tempMonth=tempRecDate.getMonth()+1;
				var tempDate=tempRecDate.getDate();
				if(tempMonth>=1 && tempMonth<=9)
					{
					tempMonth=tempMonth.toString();
					tempMonth="0"+tempMonth;
					}
				if(tempDate>=1 && tempDate<=9)
					{
					//tempDate=tempDate.toString();
					tempDate="0"+tempDate;
					}
				var tempformRecdate=tempMonth+'/'+tempDate+'/'+tempRecDate.getYear();
				temp.value=tempformRecdate;
				
}

function SetReconDateto()//Bug No:NBR_01
{
var objDataForm=  window.parent.frames["left"].document.forms["dataform"];
if(objDataForm.Reconciliation_Date_From.value!="")
	{
	objDataForm.Reconciliation_Date_To.value=objDataForm.Reconciliation_Date_From.value;
	
	}
}



<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*,java.sql.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*"%>

<HTML>
<HEAD>
<TITLE>AP Queue Status Report</TITLE>
<link href="/webdesktop/components/viewer/resources/bootstrap/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/jquery-ui.js"></script>
<script language="JavaScript" src="../../../../components/viewer/resources/bootstrap/js/moment.js"></script>


</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
<script language="JavaScript" src="../../../omniflow/scripts/security.js"></script>
<style>

.ui-widget {font-size:0.8em}
.ui-datepicker {
	width:17em;
	
}
</style>

<script>
	var allWindows = new Array();
	var win; // new window object
		$(document).ready(function(){$('#From_Date_Reg').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", disabled: true,
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date_Reg').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", disabled: true,
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#From_Date_Q').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", disabled: true,
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	$('#To_Date_Q').datepicker({dateFormat : "dd/M/yy",maxDate: '0', changeYear: true,showOn: 'button',buttonImage:"/webdesktop/CustomReports/reports/GMAC/Calendar/images/Calendar.gif",buttonImageOnly: true, buttonText:"Click to select Date", disabled: true,
	monthNamesShort:['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']});
	});
	/*functions echeck,ValidateForm added by nilesh*/
	function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false;
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false;
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false;
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false;
		 }

 		 return true;					
	}
//---Added by Chetan
function ShowCalendar(obj)
{	
	textForm.all[obj].value =  "";
	var xaxis;
	var yaxis;
	xaxis = event.screenX;
	yaxis = event.screenY;
	var sDate="";

	sDate	= window.showModalDialog('/processmanager/reports/GMACReports/GMAC/Calendar/Calendar.htm',textForm.all[obj].value+'@@', 'dialogLeft:' + xaxis + 'px;dialogTop:' + yaxis + 'px;dialogHeight:210px;dialogWidth:265px;center:No;help:No;scroll:No;resizable:No;status:No;');




	if(sDate!="")
	{
	tempdate=convertdate(sDate);
	textForm.all[obj].value = tempdate;
	}
}

function convertdate(sLocalDate)
{
	
	var sDateSeparator="/";
	var strResult;
	var nBegIndex=sLocalDate.indexOf(sDateSeparator);
	
	 
	var strtempdate = sLocalDate.substring(sLocalDate.indexOf(sDateSeparator)+1,sLocalDate.lastIndexOf(sDateSeparator));
	var strdate = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
	
	var stryear = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
	
	var strMonth="";
	if(strtempdate=="01")
			strMonth="JAN";
		else if(strtempdate=="02")
			strMonth="FEB";
		else if(strtempdate=="03")
			strMonth="MAR";
		else if(strtempdate=="04")
			strMonth="APR";
		else if(strtempdate=="05")
			strMonth="MAY";
		else if(strtempdate=="06")
			strMonth="JUN";
		else if(strtempdate=="07")
			strMonth="JUL";
		else if(strtempdate=="08")
			strMonth="AUG";
		else if(strtempdate=="09")
			strMonth="SEP";
		else if(strtempdate=="10")
			strMonth="OCT";
		else if(strtempdate=="11")
			strMonth="NOV";
		else if(strtempdate=="12")
			strMonth="DEC";

	

	strResult=strdate+"/"+strMonth+"/"+stryear;
	return strResult;
}

function convertMonth(strMonth)
{
		if(strMonth=="JAN")
			strMonth="00";
		else if(strMonth=="FEB")
			strMonth="01";
		else if(strMonth=="MAR")
			strMonth="02";
		else if(strMonth=="APR")
			strMonth="03";
		else if(strMonth=="MAY")
			strMonth="04";
		else if(strMonth=="JUN")
			strMonth="05";
		else if(strMonth=="JUL")
			strMonth="06";
		else if(strMonth=="AUG")
			strMonth="07";
		else if(strMonth=="SEP")
			strMonth="08";
		else if(strMonth=="OCT")
			strMonth="09";
		else if(strMonth=="NOV")
			strMonth="10";
		else if(strMonth=="DEC")
			strMonth="11";
	   return strMonth;
}

function DateComparator(Date_To,Date_From)
{	

	var Date_To_month=Date_To.substring(Date_To.indexOf("/")+1,Date_To.lastIndexOf("/"));	
	var Date_From_month=Date_From.substring(Date_From.indexOf("/")+1,Date_From.lastIndexOf("/"));

	/*converting ToDate month to number */
	if(Date_To_month=="JAN")
			Date_To_month="01";
		else if(Date_To_month=="FEB")
			Date_To_month="02";
		else if(Date_To_month=="MAR")
			Date_To_month="03";
		else if(Date_To_month=="APR")
			Date_To_month="04";
		else if(Date_To_month=="MAY")
			Date_To_month="05";
		else if(Date_To_month=="JUN")
			Date_To_month="06";
		else if(Date_To_month=="JUL")
			Date_To_month="07";
		else if(Date_To_month=="AUG")
			Date_To_month="08";
		else if(Date_To_month=="SEP")
			Date_To_month="09";
		else if(Date_To_month=="OCT")
			Date_To_month="10";
		else if(Date_To_month=="NOV")
			Date_To_month="11";
		else if(Date_To_month=="DEC")
			Date_To_month="12";


	/*converting FromDate month to number */
		if(Date_From_month=="JAN")
			Date_From_month="01";
		else if(Date_From_month=="FEB")
			Date_From_month="02";
		else if(Date_From_month=="MAR")
			Date_From_month="03";
		else if(Date_From_month=="APR")
			Date_From_month="04";
		else if(Date_From_month=="MAY")
			Date_From_month="05";
		else if(Date_From_month=="JUN")
			Date_From_month="06";
		else if(Date_From_month=="JUL")
			Date_From_month="07";
		else if(Date_From_month=="AUG")
			Date_From_month="08";
		else if(Date_From_month=="SEP")
			Date_From_month="09";
		else if(Date_From_month=="OCT")
			Date_From_month="10";
		else if(Date_From_month=="NOV")
			Date_From_month="11";
		else if(Date_From_month=="DEC")
			Date_From_month="12";
	
	var Date_To_date=Number(Date_To.substring(Date_To.indexOf("0"),Date_To.indexOf("/")));	
	var Date_From_date=Number(Date_From.substring(Date_From.indexOf("0"),Date_From.indexOf("/")));

		
	var Date_To_year=Number(Date_To.substring(Date_To.lastIndexOf("/")+1,Date_To.length));
	var Date_From_year=Number(Date_From.substring(Date_From.lastIndexOf("/")+1,Date_From.length));

		

	if(Date_To_year<Date_From_year)
	{
		alert("To Date cannot be less than From  Date.");
		return false;
	}


	else if(Date_To_year>Date_From_year)
	{
		
		//if(Date_From_month>Date_To_month)
		//{
		//alert("To Date can not be less than From Date.");
		//return false;
		//}
		 if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{
				
				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}


	else if(Date_To_year==Date_From_year)
	{
	
		if(Date_From_month>Date_To_month)
		{
		alert("To Date can not be less than From Date.");
		return false;
		}
		else if(Date_From_month==Date_To_month)
		{
			if(Date_To<Date_From)
			{

				alert("To Date can not be less than From Date.");
				return false;
			}
		}
	}
return true;
}
	
function ValidateForm(emailID){
//	var emailID=document.frmSample.txtEmail
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false;
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false;
	}
	return true;
 }
 

	
function openreport()
{	

		var sQueue="";
		var bQueueSelected=false;
		var docselected=false;
		var UserEmailID=document.getElementById('EMail-ID').value;//added by nilesh
		var RegDateRangeFrom="";
		var RegDateRangeTo="";
		var QDateRangeFrom="";
		var QDateRangeTo="";
		var DocumentCategory="";
		var VendorNumber="";
		var VendorName="";
		var sDocCat="";
		//alert(document.forms["textForm"].Queue.length);
		
		for(var i=0;i<document.forms["textForm"].Queue.length;i++)
		{
			if(document.forms["textForm"].Queue[i].selected)
			{
				sQueue=sQueue+document.forms["textForm"].Queue[i].value+'~';
				bQueueSelected=true;
			}

		}
		//alert(bQueueSelected);
		if(!bQueueSelected)
		{
			alert("Please Select Queue.");
			return false;
		}
		for(var i=0;i<document.forms["textForm"].Document_Category.length;i++)
		{
			if(document.forms["textForm"].Document_Category[i].selected)
			{
				
				DocumentCategory=DocumentCategory+document.forms["textForm"].Document_Category[i].value+'~';
				docselected=true;
				
			}
		}
		//alert(sQueue);
		//alert(DocumentCategory);
		if(docselected){
		sDocCat=DocumentCategory.split('~');
				}
				
				
				
			if(document.getElementById('Registration').checked)
		{
			RegDateRangeFrom=document.forms["textForm"].From_Date_Reg.value;
			RegDateRangeTo=document.forms["textForm"].To_Date_Reg.value;	
		}
		if(document.getElementById('Queue_Date').checked)
		{
			QDateRangeFrom=document.forms["textForm"].From_Date_Q.value;
			QDateRangeTo=document.forms["textForm"].To_Date_Q.value;	
		}

			VendorNumber=document.forms["textForm"].Vendor_Number.value;
			VendorName=document.forms["textForm"].Vendor_Name.value;
		
		
		
			var sTestQueue=sQueue.split('~');
			

		//---------------------------------------------------
		
		
		/*if(!document.getElementById('Registration').checked && !document.getElementById('Queue_Date').checked)
		{
		alert("Please select queue Entry Date range or Registration Date range");
		return false;
		}
		else{
		if(document.getElementById('Registration').checked){
		if(RegDateRangeFrom=='')
		{
			alert("Please select an appropriate Registration FromDate");
				return false;
		}
		if(RegDateRangeTo==''){
			alert("Please select an appropriate Registration ToDate");
				return false;
		}
		}
		
		if(document.getElementById('Queue_Date').checked){
		if(QDateRangeFrom=='')
		{
			alert("Please select an appropriate Queue FromDate");
				return false;
		}
		if(QDateRangeTo==''){
			alert("Please select an appropriate Queue ToDate");
				return false;
		}
		}
		}*/

		if(sQueue.indexOf("All")!=-1 && sTestQueue.length>2)
		{
			alert("No other Queue Name can be chosen after choosing All");
			return false;
			//sQueue='All~';

		}
		if(DocumentCategory.indexOf("All")!=-1 && sDocCat.length>2)
		{
			alert("No other Document Category can be chosen after choosing All");
			return false;
			//QueueName='All~';
		}
		
		
		if(sQueue=='Processing~Approval~ApprovalException~Cancel~Coding~GEACINTERFACE~JournalEntry~PendingPayment~PolicyHolderPayment~QC~Rescan~Split~PendingResolution~')
		{
			sQueue='All~';
			
		}
		if(DocumentCategory=='PO Invoices~Non PO Invoices~Policy Holder Payments~Escheatment~Credit Memo~Statement~Others~')
		{
			DocumentCategory='All~';
			}
		
		if(!DateComparator(RegDateRangeTo,RegDateRangeFrom))
		{
		return false;
		}
		else if(!DateComparator(QDateRangeTo,QDateRangeFrom))
		{
		return false;
		}
		
		if(UserEmailID=='')
		{
			alert("Kindly enter a valid E-Mail ID");
			return false;

		}
		else
		{
			if(!ValidateForm(document.getElementById('EMail-ID')))
			{
				UserEmailID='';
				
			}
		}
	if(document.getElementById('Registration').checked)
		{
		 if((UserEmailID!='')&&(RegDateRangeTo!="")&&(RegDateRangeFrom!="")&&(sQueue!=""))
			{	
			var query="APQueueStatusGenerate.jsp?sQueue="+sQueue+"&DocumentCategory="+DocumentCategory+"&VendorNumber="+VendorNumber+"&VendorName="+VendorName+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID;
			
			//alert(query);
			//OpenRedict-Fix
			
			//window.top.APPROVALPROCESSQUEUESTATUS.location.href="APQueueStatusGenerate.jsp?sQueue="+sQueue+"&DocumentCategory="+DocumentCategory+"&VendorNumber="+VendorNumber+"&VendorName="+VendorName+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID;
			
			var URI = "APQueueStatusGenerate.jsp?sQueue="+sQueue+"&DocumentCategory="+DocumentCategory+"&VendorNumber="+VendorNumber+"&VendorName="+VendorName+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID;
			var StrOpenWin=strip_tags(URI,"");
			window.top.APPROVALPROCESSQUEUESTATUS.location.href=StrOpenWin;
			}
		}
	else if(document.getElementById('Queue_Date').checked)
	{
	 if((UserEmailID!='')&&(QDateRangeTo!="")&&(QDateRangeFrom!="")&&(sQueue!=""))
			{	
			var query="APQueueStatusGenerate.jsp?sQueue="+sQueue+"&DocumentCategory="+DocumentCategory+"&VendorNumber="+VendorNumber+"&VendorName="+VendorName+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID;
		//	alert(query);
			
			//OpenRedict-Fix
			//window.top.APPROVALPROCESSQUEUESTATUS.location.href="APQueueStatusGenerate.jsp?sQueue="+sQueue+"&DocumentCategory="+DocumentCategory+"&VendorNumber="+VendorNumber+"&VendorName="+VendorName+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID;
			
			var URI = "APQueueStatusGenerate.jsp?sQueue="+sQueue+"&DocumentCategory="+DocumentCategory+"&VendorNumber="+VendorNumber+"&VendorName="+VendorName+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID;
			var StrOpenWin=strip_tags(URI,"");
			window.top.APPROVALPROCESSQUEUESTATUS.location.href=StrOpenWin;
			}
	}
	else
	{
	 if(UserEmailID!='')
			{	
			var query="APQueueStatusGenerate.jsp?sQueue="+sQueue+"&DocumentCategory="+DocumentCategory+"&VendorNumber="+VendorNumber+"&VendorName="+VendorName+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID;
		//	alert(query);
		
		//OpenRedict-Fix
		
			//window.top.APPROVALPROCESSQUEUESTATUS.location.href="APQueueStatusGenerate.jsp?sQueue="+sQueue+"&DocumentCategory="+DocumentCategory+"&VendorNumber="+VendorNumber+"&VendorName="+VendorName+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID;
			
			var URI = "APQueueStatusGenerate.jsp?sQueue="+sQueue+"&DocumentCategory="+DocumentCategory+"&VendorNumber="+VendorNumber+"&VendorName="+VendorName+"&ReportName=<%=request.getParameter("ReportName")%>&RegFromDate="+RegDateRangeFrom+"&RegToDate="+RegDateRangeTo+"&QFromDate="+QDateRangeFrom+"&QToDate="+QDateRangeTo+"&UserEmailID="+UserEmailID;
			var StrOpenWin=strip_tags(URI,"");
			window.top.APPROVALPROCESSQUEUESTATUS.location.href=StrOpenWin;
			
			}
	}      
		
		
  }

	
	function UnloadReportWindow()
	{
		if(win!=null)
			win.close();
	}

	//malkeet
	function chkradio(obj)
	{
		if(obj == 'r')
		{
			if(document.getElementById('Queue_Date').checked == true) 
			{
				document.getElementById('Queue_Date').checked = false;
			}
			document.getElementById('From_Date_Q').value='';
			document.getElementById('To_Date_Q').value='';
			document.getElementById('From_Date_Q').style.background='Gray';
			document.getElementById('To_Date_Q').style.background='Gray';
			//document.getElementById('From_Date_IMG_Queue').disabled=true;
			//document.getElementById('To_Date_IMG_Queue').disabled=true;
			//document.getElementById('From_Date_IMG_Reg').disabled=false;
			//document.getElementById('To_Date_IMG_Reg').disabled=false;
			document.getElementById('From_Date_Reg').style.background='White';
			document.getElementById('To_Date_Reg').style.background='White';
			$('#From_Date_Reg').datepicker("enable");
			$('#To_Date_Reg').datepicker("enable");
			$('#To_Date_Q').datepicker("disable");
			$('#From_Date_Q').datepicker("disable");
		}
		else if(obj == 'q')
		{
			if(document.getElementById('Registration').checked == true) 
			{
				document.getElementById('Registration').checked = false;
			}
			document.getElementById('From_Date_Q').style.background='White';
			document.getElementById('To_Date_Q').style.background='White';
			document.getElementById('From_Date_Reg').style.background='Gray';
			document.getElementById('To_Date_Reg').style.background='Gray';
			//document.getElementById('From_Date_IMG_Reg').disabled=true;
			//document.getElementById('To_Date_IMG_Reg').disabled=true;
			document.getElementById('From_Date_Reg').value='';
			document.getElementById('To_Date_Reg').value='';
			$('#From_Date_Reg').datepicker("disable");
			$('#To_Date_Reg').datepicker("disable");
			$('#To_Date_Q').datepicker("enable");
			$('#From_Date_Q').datepicker("enable");

			//document.getElementById('From_Date_IMG_Queue').disabled=false;
			//document.getElementById('To_Date_IMG_Queue').disabled=false;
		}

	}
	
	function disbFields()
 {
 	document.getElementById('From_Date_Q').value='';
	document.getElementById('To_Date_Q').value='';
	document.getElementById('From_Date_Reg').value='';
	document.getElementById('To_Date_Reg').value='';
	//document.getElementById('From_Date_IMG_Queue').disabled=true;
	//document.getElementById('To_Date_IMG_Queue').disabled=true;
	//document.getElementById('From_Date_IMG_Reg').disabled=true;
	//document.getElementById('To_Date_IMG_Reg').disabled=true;

 	document.getElementById('From_Date_Q').style.background='Gray';
	document.getElementById('To_Date_Q').style.background='Gray';
	document.getElementById('From_Date_Reg').style.background='Gray';
	document.getElementById('To_Date_Reg').style.background='Gray';

 }
</script>

<body topmargin="0" leftmargin="5" onunload="UnloadReportWindow(); "  onload="disbFields();">

			<form name='textForm' method=post>


			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="90%"><img src="/webdesktop/CustomReports/omniflow/en_us/images/logo.gif" width="125" height="50" alt="logo.gif (3013 bytes)"></td>
				</tr>
				<tr>
					<td class="EWSubHeader" colspan="2">TA AP QUEUE STATUS REPORT</td>
				</tr>
				<tr>  
					<td valign="center" width="100%" colspan=2 class="EWLabel1"><b>Report Criteria :</b></td></tr><tr><td></td></tr><tr><td></td></tr><tr><td class="EWLabel1">This report will show the number of un processed work items in the selected queue along with other Indexing details. The Report will provide the current information only. It is not possible to retrive the status in a future date/time. Process Owner / Supervisor can save the generated report for their future references.
</td></tr><tr><td class="EWLabel1"> 
Select All as the Vendor Types if the report has to be generated for the entire spectrum of the avalilable Vendor Type, else select the specific Vendor Type, multiple selections are acceptable.
</td></tr><tr><td class="EWLabel1">Select All Queues if report is to be generated for viewing the workitems present across different worksteps, else select the specific Queue, multiple selections are acceptable.<br>
Select All Vendor Request Types if report is to be generated for viewing the workitems present across all Vendor Request Types, else select the specific Vendor Request Types, multiple selections are acceptable.
Enter the requisiste date range.You can enter either Registration Date Range or Queue Entry Date Range.
</td></tr>
<tr><td class="EWLabel1"><b>Date Range and Queue Name is mandatory.</b>
</td></tr>
			<td>
		<br/>
					<p style="color: red; font-size: 10pt">Note:  * fields are mandatory.</p>

				</td>
				
			</table>

		

			<table border="0" width="95%" cellspacing="1" align="center">
			
				<tr>
					<td class="EWLabel1" align="left" width='20%'><b>Queue<font color="RED">*</font></b></font></td>
					<td width='25%' colspan=3>
					<select style='width:45%' name="Queue" multiple>
					<option value="All">All</option>
					<option value="Processing">Processing</option>
					<option value="PolicyHolderPayment">PolicyHolderPayment</option>
					<option value="PendingResolution">Pending Resolution</option>
					<option value="Rescan">Rescan</option>
					<option value="Split">Split</option>
					<option value="Cancel">Cancel</option>
					<option value="QC">QC</option>
					<option value="Coding">Coding</option>
					<option value="Approval">Approval</option>
					<option value="ApprovalException">ApprovalException</option>
					<option value="GEACINTERFACE">GEAC INTERFACE</option>
					<option value="JournalEntry">JournalEntry</option>
					<option value="PendingPayment">PendingPayment</option>
				
					</select>
					</td>
				</tr>
				
				 <tr>
					<td class="EWLabel1" align="left" width='20%'><b>Document Category</b></font></td>
					<td width='25%' colspan=3>
					<select style='width:45%' name="Document_Category" multiple>
					<option value="All">All</option>
					<option value="PO Invoices">PO Invoices</option>
					<option value="Non PO Invoices">Non PO Invoices</option>
					<option value="Policy Holder Payments">PH Payments</option>
					<option value="Escheatment">Escheatment</option>
					<option value="Credit Memo">Credit Memo</option>
					<option value="Statement">Statement</option>
					<option value="Others">Others</option>
					
				
					</select>
					</td>
				</tr>

				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Vendor Name</b></td>
					<td >
					<input type='text' name='Vendor_Name' style='width:145' id='Vendor_Name'>
					</td>
				</tr>
				
				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Vendor Number</b></td>
					<td >
					<input type='text' name='Vendor_Number' style='width:145' id='Vendor_Number'>
					</td>
				</tr>
				
				 
                <!-- Added by Chetan for displaying Date range from and to field...-->
				<tr>
					<td>
					<p class="EWLabel122" ><input type = "radio" name ="Registration" id ="Registration" value = "Registration" align='left' style="width: 10px" onClick="chkradio('r')">&nbsp;Registration Date<font color="RED"></font></p></td>
					</tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date_Reg" readonly type="text"  id="From_Date_Reg" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date_Reg" readonly type="text"  id="To_Date_Reg" >
					
					</td>

				</tr>
				
				<tr>
					<td>
					<p class="EWLabel122" ><input type = "radio" name ="Queue_Date" id ="Queue_Date" value = "Queue_Date"align='left' style="width: 10px" onClick="chkradio('q')">&nbsp;Queue Entry Date<font color="RED"></font></p></td>
					</tr>
					<td class="EWLabel1" align="left" width='20%'><table id='newgen'></table><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:</b></td>
					<td width='25%'>
					<input class='TextFieldColorDate' name="From_Date_Q" type="text" readonly id="From_Date_Q" >
					
					</td><td class="EWLabel1" align="left" width='5%'><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:</b></td>
					<td width='25%'><input class='TextFieldColorDate' name="To_Date_Q" type="text" readonly id="To_Date_Q" >
					
					</td>

				</tr>
				<!-- --------------------------------------------------- -->
				<!--added by nilesh for displaying Emaild field -->

				<tr>&nbsp;</tr>
				<tr width=100%>
					<td width=180 class="EWLabel1" align="left" width='20%'><b>Enter valid EMail-ID<font color="RED">*</font></b></td>
					<td >
					<input type='text' name='EMail-ID' style='width:145' id='EMail-ID'>
					</td>
				</tr>
				
			</table>			
			<br>
			<table border="0" width="100%" cellspacing="1">
				<tr>    
					<td valign="center" width="100%" colspan=4><p align="center">
						<input type="button" value="Generate" name="B1" class="EWButton" onclick="openreport()">
						<input type="button" value="Cancel" name="B2" class="EWButton" onclick="window.parent.close(); return false;">
					</td>
				</tr>
			</table>
	
			
			</form>
</body>
</Html>	 




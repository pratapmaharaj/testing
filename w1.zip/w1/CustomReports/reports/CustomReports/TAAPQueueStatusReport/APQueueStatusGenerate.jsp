<%@ include file="customized.process" %>
<jsp:useBean id="wfsession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ page import="java.io.*,java.util.*"%>
<%@ page import="java.sql.*"%>
<%@ page import="java.text.*"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="com.tcsta.util.PathUtil" %>

<HTML>
<HEAD>
<TITLE>AP Queue Status Report</TITLE>
</HEAD>
<link href="/webdesktop/CustomReports/reports/GMAC/css/docstyle.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../../../omniflow/scripts/wfgeneral.js"></script>
</script>

<body >
<%!

 public static String[] split(String s, char c)
    {
        Vector vector = new Vector();
        String s1 = new String();
        for(int i = 0; i < s.length(); i++)
            if(s.charAt(i) == c)
            {
                vector.add(s1);
                s1 = new String();
            } else
            {
                s1 = s1 + s.charAt(i);
            }

        vector.add(s1);
        String as[] = new String[vector.size()];
        for(int j = 0; j < as.length; j++)
            as[j] = new String((String)vector.elementAt(j));

        return as;
    }
%>

<%
WriteLog("AP_QueueStatus","sOutputXML ::> sOutputXML : here") ;

	String sProcessDefId=null;
	String sProcedureName=null;
	String sColumnHeaders=null;
	String sReportName=null;
	String sFileName=null;
	String sNumberOfColumns=null;
	String sProcedureNameKey=null;
	String sColumnHeadersKey=null;
	String sFileNameKey=null;
	String sNumberOfColumnsKey=null;
	String sHeaderKey=null;
	String sHeaderPresentKey=null;
	String sDBMappedColsKey=null;
	String sHeaderValue=null;
	String sHeaderPresentValue=null;
	String sCabinetName=null;	
	String sDBMappedCols=null;
	String sFieldValuesKey=null;
	String sFieldValues=null;
	String sFieldValuesReport="";
	String sUserMailID=null;
	String sFilePath=null;
	String sFilePathKey=null;
	String UserNames = "" ;
	sReportName	=request.getParameter("ReportName");
	sUserMailID=request.getParameter("UserEmailID");
	sReportName	=sReportName.toUpperCase();
	WriteLog("AP_QueueStatus","sOutputXML ::> sReportName : "+sReportName) ;
	WriteLog("AP_QueueStatus","sOutputXML ::> sUserMailID : "+sUserMailID) ;

	sProcedureNameKey=sReportName +"_PROCEDURENAME" ;
	WriteLog("AP_QueueStatus","sOutputXML ::> sProcedureNameKey : "+sProcedureNameKey) ;
	sColumnHeadersKey=sReportName+"_COLUMNHEADERS";
	WriteLog("AP_QueueStatus","sOutputXML ::> sColumnHeadersKey : "+sColumnHeadersKey) ;
	sFileNameKey=sReportName+"_FILENAME";

	WriteLog("AP_QueueStatus","sOutputXML ::> sFileNameKey : "+sFileNameKey) ;

	sNumberOfColumnsKey=sReportName+"_NUMBEROFCOLUMNS";

	WriteLog("AP_QueueStatus","sOutputXML ::> sNumberOfColumnsKey : "+sNumberOfColumnsKey) ;

	sHeaderPresentKey=sReportName+"_HEADERPRESENT";

	WriteLog("AP_QueueStatus","sOutputXML ::> sHeaderPresentKey : "+sHeaderPresentKey) ;
	
	sHeaderKey=sReportName+"_HEADER";

	WriteLog("AP_QueueStatus","sOutputXML ::> sHeaderKey : "+sHeaderKey) ;
	sDBMappedColsKey=sReportName+"_DBMAPPEDCOLS";
	WriteLog("AP_QueueStatus","sOutputXML ::> sDBMappedColsKey : "+sDBMappedColsKey) ;
	sFieldValuesKey=sReportName+"_FIELDVALUES";

	WriteLog("AP_QueueStatus","sOutputXML ::> sFieldValuesKey : "+sFieldValuesKey) ;
	
	sFilePathKey=sReportName+"_FILEPATH";
	
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"TAAPQueueStatusReport.ini";
	//String sRootPathini=application.getRealPath("")+File.separator+"reports"+File.separator+"GMACReports"+File.separator+"ApprovalProcessQueueStatusReport" + File.separator + "reports.ini";
	
	Properties ini = new Properties();
	
	FileInputStream fis = null;
	
	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("AP_QueueStatus","Unable to read AP_QueueStatus.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("AP_QueueStatus","Unable to close the AP_QueueStatus.ini file");
						}
					}
				}
	
	

	//WriteLog("AP_QueueStatus","sOutputXML ::> sFieldValuesKey : "+sFieldValuesKey) ;
	/*String connectionUrl      =ini.getProperty("ConnectionUrl");
	String dbuserName = ini.getProperty("username");
	String dbpass     = ini.getProperty("password");*/
	String pathName = "" ;
	pathName = ini.getProperty(sReportName +"_FILEPATH");
	sProcessDefId=ini.getProperty("PROCESSDEFID");
	
	sCabinetName=ini.getProperty("CABINETNAME");
	sProcedureName=ini.getProperty(sProcedureNameKey);
	
	sColumnHeaders=ini.getProperty(sColumnHeadersKey);
	
	sFileName=ini.getProperty(sFileNameKey);
	
	sNumberOfColumns=ini.getProperty(sNumberOfColumnsKey);
	
	sHeaderPresentValue=ini.getProperty(sHeaderPresentKey);
	
	sDBMappedCols=ini.getProperty(sDBMappedColsKey);
	
	sFieldValues=ini.getProperty(sFieldValuesKey);
	
	sFilePath=ini.getProperty(sFilePathKey);

	if(sHeaderPresentValue.equals("YES")) 
	{
		sHeaderValue=ini.getProperty(sHeaderKey);
	}

	String sCabname=null;
	String sSessionId = null;
	String sJtsIp = null;
	String sUserName = null;
	String sReportProcedureName=null;
	String sReportTableName=null;
	
		
	/*Date CurrDate=new Date();
	
	DateFormat dt = new SimpleDateFormat("dd-MMM-yyyy");
	String sCurrdate=dt.format(CurrDate);
*/
	String sOutputXML="";
	String sInputXML = "";
	String maincode = "";
	String Totalrec = "0";

	String url = "";
	String Status="";
	String sStr_ServerType="";
	String sInputXml="";
	double fPercentage=0;
	String sColumnNamesArr[]=split(sColumnHeaders,',');
	String sDBMappedColsArr[]=split(sDBMappedCols,',');
	String sFinalColumns[]=split(sColumnHeaders,',');
	
	for(int i=0;i<sColumnNamesArr.length;i++)
	{
		if(sColumnNamesArr[i].indexOf("~D")!=-1)
			sFinalColumns[i]=sColumnNamesArr[i].substring(0,sColumnNamesArr[i].length()-2);

	}

	String sFieldNamesDB[]=split(sFieldValues,'#');

	for(int i=0;i<sFieldNamesDB.length;i++)
	{
		sFieldValuesReport=sFieldValuesReport+sFieldNamesDB[i]+',';
	}
	sFieldValuesReport=sFieldValuesReport.substring(0,sFieldValuesReport.length()-1);

	String sRegFromDate=request.getParameter("RegFromDate");
	String sRegToDate=request.getParameter("RegToDate");
	String sQFromDate=request.getParameter("QFromDate");
	String sQToDate=request.getParameter("QToDate");
	String Queue=request.getParameter("sQueue");
	String VendorNumber=request.getParameter("VendorNumber");
	String VendorName=request.getParameter("VendorName");
	String DocumentCategory=request.getParameter("DocumentCategory");
	
	String sRowXml="";
WriteLog("AP_QueueStatus","Malkeet");

	int iJtsPort = 0;
	boolean bError=false;
	//connectionUrl = connectionUrl+";"+"databaseName="+sCabinetName+";user="+dbuserName+";password="+dbpass;
	String sRootPathDBini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	WriteLog("AP_QueueStatus","sRootPathDBini="+sRootPathDBini);

	try
			{
				fis = new FileInputStream(PathUtil.normalize(sRootPathDBini));
				ini.load(fis);
			}
			catch(Exception e)
			{
				WriteLog("AP_QueueStatus","Unable to read AP_QueueStatus.ini file");
			}
		finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("AP_QueueStatus","Unable to close the AP_QueueStatust.ini file");
						}
					}
				}
	
	String driverName = null;

	String connectionUrl=ini.getProperty("CONNECTIONSTRING");
	driverName = ini.getProperty("DRIVERNAME");
	CallableStatement callableStatement = null;
	Connection conn=null;

	WriteLog("AP_QueueStatus","1212222:'"+Queue+"','"+VendorNumber+"','"+VendorName+"','"+DocumentCategory+"','"+sRegFromDate+"','"+sRegToDate+"','"+sQFromDate+"','"+sQToDate+"','"+sFieldValuesReport+"','"+sUserMailID+"','"+pathName+"','"+sFileName+"'") ;
		
	String getDBUSERByUserIdSql = "{call "+sProcedureName+"(?,?,?,?,?,?,?,?,?,?,?,?,?)}";

	String output = "" ;
	WriteLog("AP_QueueStatus",sProcedureName);
			
	try{
			Class.forName(driverName);
			conn = DriverManager.getConnection(connectionUrl);
			callableStatement = conn.prepareCall(getDBUSERByUserIdSql);
			callableStatement.setString(1, Queue);
			callableStatement.setString(2, VendorNumber);
			callableStatement.setString(3, VendorName);
			callableStatement.setString(4, DocumentCategory);
			callableStatement.setString(5, sRegFromDate);
			callableStatement.setString(6, sRegToDate);
			callableStatement.setString(7, sQFromDate);
			callableStatement.setString(8, sQToDate);
			callableStatement.setString(9, sFieldValuesReport);
			callableStatement.setString(10, sUserMailID);
			callableStatement.setString(11, pathName);
			callableStatement.setString(12, sFileName);
			callableStatement.registerOutParameter(13, java.sql.Types.VARCHAR);
			callableStatement.execute();

			output = callableStatement.getString(13);
			WriteLog("AP_QueueStatus"," output "+output);
			
	}
	catch(SQLException ignore)
	{
		%>
									<script>alert("Some Error please check logs");</script>
									<%
		WriteLog("AP_QueueStatus"," WFSession Data Fetch Exception:::::: "+ignore.toString());
		out.println("<BR><BR><font color=blue face=arial size=2><b>&nbsp&nbsp&nbsp&nbsp"+ignore.toString()+"</b></font>");
		bError= true;
		
	}
	finally {
 
	if (callableStatement != null) {
        try {
            callableStatement.close();
        } catch (SQLException e) { }
    }
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
	}
	if(!bError)
	{

		WriteLog("AP_QueueStatus"," output:::::: "+output);
		try
		{

			if(output.equals(""))
			{
				bError= true;
					%>
					<script>alert("Error in Executing Procedure:");</script>
					<%
				//maincode=sOutputXML.substring(sOutputXML.indexOf("<MainCode>")+10 , sOutputXML.indexOf("</MainCode>"));
				out.println("<BR><BR><center><font color=blue face=arial size=2><b>Error in Executing Procedure: "+output+"</b></font><center>");
				
				
			}
			else
			{
				
					try
							{
								 if(Integer.parseInt(output) == 0)
								{
									%>
									<script>alert("No Records found for the Current Request Criteria");</script>
									<%
								}
								else
								{
									%>
									<script>alert("The Report will be delivered to your mailbox shortly");</script>
									<%

								}
								
							}
							catch(Exception ig)
							{ 
							log("AP_QueueStatus "+ig.toString());
							%>
									<script>alert("Some Error please check logs");</script>
									<%
								out.println(ig.toString());
												
							}
			}
		}
		
		catch(Exception exp)
		{
			%>
									<script>alert("Some Error please check logs");</script>
									<%
			out.println("<BR><BR><center><font color=blue face=arial size=2><b>Exception :"+exp.toString()+"</b></font></center>");
			bError= true;
			log("AP_QueueStatus "+exp.toString());
		}
		
	}

%>
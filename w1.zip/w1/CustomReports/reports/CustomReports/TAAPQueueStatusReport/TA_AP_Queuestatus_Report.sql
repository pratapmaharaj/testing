    
    
              
/*                      
  TA_AP_Queuestatus_Report 'All~','','','All~','02/FEB/2014','10/FEB/2014','','','Current_Work_Step,a.WI_Name,Introduction_Type,Registration_Date,Document_Category,Priority,Pay_Entity,Vendor_Name,ACH,AP_Check,Vendor_Number,Invoice_Number,Total_Invoice_Amo
unt,Invoice_Date,Approver_Comments,Approval_Decision,Approved_Invoice_Amount,Multi_Payment,b.Wi_EntryTime,b.Wi_ExitTime,(datediff(mi,b.Wi_ExitTime,Registration_Date)) as Aging','aaaa@aaa.com','//10.33.192.139/XLS-File/ProcessManager/reports/Gmac report/AP
/','AP_QueueStatus',''  
  
TA_AP_Queuestatus_Report 'All~','','','All~','09/FEB/2014','10/FEB/2014','','','Current_Work_Step,a.WI_Name,Introduction_Type,Registration_Date,Document_Category,Priority,Pay_Entity,Vendor_Name,ACH,AP_Check,Vendor_Number,Invoice_Number,Total_Invoice_Amoun
t,Invoice_Date,Approver_Comments,Approval_Decision,Approved_Invoice_Amount,Multi_Payment,b.Wi_EntryTime,b.Wi_ExitTime,(datediff(DD,Registration_Date,b.Wi_ExitTime)) as Aging','aa@aa.com','//10.33.192.139/XLS-File/ProcessManager/reports/Gmac report/AP/','A
P_QueueStatus'  
  
*/                    
                      
CREATE PROCEDURE [dbo].[TA_AP_Queuestatus_Report]                      
(                     
@QueueName      VARCHAR(255),                   
@VendorNumber VARCHAR(255),                     
@VendorName   VARCHAR(255),      
@DocumentCategory  VARCHAR(255),                     
@RegDateRangeFrom  VARCHAR(255),                      
@RegDateRangeTo    VARCHAR(255),                   
@QDateRangeFrom    VARCHAR(255),                   
@QDateRangeTo    VARCHAR(255),                   
@Fields         VARCHAR(8000),                  
@EmailID        varchar(200),                      
@FilePath       varchar(200),                      
@FileName       varchar(200),  
@RowCount varchar(200) OUTPUT                                          
)                      
AS                      
          
 declare                      
 @WhereQuery varchar(2000),                      
 @Query varchar(5000),                      
 @Tables varchar(200),                      
 @BkpTable varchar(200),                      
 @QueueNameReport varchar(200),                      
 @VendorTypeReport varchar(200),                     
 @VendorRequestTypeReport varchar(200),                    
 @EntryExitDetails varchar(8000),                      
 @Disp_QName varchar(100),                       
 @Count_Q varchar(100),                      
 @status_temp varchar(8000),                      
 @dbname varchar(60) ,                
 @DateRangeFrom varchar(60),                
 @DateRangeTo varchar(60),      
 @DocNameReport varchar(1000)        
                      
BEGIN                      
 Set nocount on                       
 set @FileName=@FilePath+'/'+@EmailID+'_'+@FileName+'_'+convert(varchar,getdate(),104)+'.xls'                                  
 set @WhereQuery='WHERE '                      
 set @Tables=' WNS_TA_AP_EXT_Table a with(nolock),WNS_TA_AP_EntryExitTable b with(nolock)'                             
 set @QueueNameReport=''                      
 SET @VendorTypeReport=''                  
 SET @VendorRequestTypeReport=''                
 Set @DateRangeFrom=''                
 Set @DateRangeTo=''     
 Set @RowCount=''     
 set @DocNameReport=''               
       
 Create Table #TA_AP_Queuestatus_Report_Temp                       
 (                       
   Current_Work_Step varchar(100) ,                      
   WI_Name varchar(100) ,                      
   Introduction_Type varchar(100) ,                      
   Registration_Date varchar(100) ,                      
   Document_Category varchar(100) ,       
   Priority varchar(100) ,      
   Pay_Entity varchar(100) ,      
   Vendor_Name varchar(100) ,                      
   ACH varchar(100) ,                      
   AP_Check varchar(100) ,                      
   Vendor_Number varchar(100) ,     
   Invoice_Number varchar(100),      
   Total_Invoice_Amount varchar(100) ,           
  Invoice_Date varchar(100) ,                      
   Approver_Comments varchar(100) ,      
   Approval_Decision varchar(100) ,          
   Approved_Invoice_Amount varchar(100) ,                      
   Multi_Payment varchar(100) ,                    
   Wi_EntryTime varchar(100) ,                  
   Wi_ExitTime varchar(100) ,                   
  Aging varchar(100) ,                  
                
 )                       
                      
 Create Table #APQSummaryException                       
 (                  
  Disp_QName varchar(1000),                       
  Count_Q varchar(100)             
 )                      
          
--Registration Date Range        
if(rtrim(ltrim(@RegDateRangeFrom))<>'' and rtrim(ltrim(@RegDateRangeTo))<>'')          
begin        
if(rtrim(ltrim(@RegDateRangeFrom))<>'')        
 SET @DateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@RegDateRangeFrom,121)))))        
 SET @RegDateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@RegDateRangeFrom,121)))))                  
if(rtrim(ltrim(@RegDateRangeTo))<>'')        
 SET @DateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@RegDateRangeTo,121)))))        
 SET @RegDateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@RegDateRangeTo,121)))))                
end        
else        
begin        
--Queue Date Range                   
if(rtrim(ltrim(@QDateRangeFrom))<>'')        
 SET @DateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@QDateRangeFrom,121)))))                  
 SET @QDateRangeFrom = dateadd(ms,000,dateadd(ss,00,dateadd(mi,00,dateadd(hh,00,convert(datetime,@QDateRangeFrom,121)))))        
                  
if(rtrim(ltrim(@QDateRangeTo))<>'')        
SET @DateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@QDateRangeTo,121)))))        
  SET @QDateRangeTo = dateadd(ms,998,dateadd(ss,59,dateadd(mi,59,dateadd(hh,23,convert(datetime,@QDateRangeTo,121)))))        
end        
        
print @DateRangeFrom        
print @DateRangeTo        
                  
                      
                   
 --Queue name                  
 if(rtrim(ltrim(@QueueName))<>'All~')   BEGIN                        
  while (charindex('~',@QueueName)>1)                      
  BEGIN                      
   set @QueueNameReport = @QueueNameReport + ''''+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+''''+','                      
   set @QueueName=ltrim(rtrim(Substring(@QueueName,Charindex('~',@QueueName)+len('~'),len(@QueueName))))                      
  END                      
  set @QueueNameReport=SUBSTRING(@QueueNameReport,0,len(@QueueNameReport))              
  set @WhereQuery=@WhereQuery+' Current_Work_Step in('+@QueueNameReport+')'                           
  print @WhereQuery                      
 END                      
Else                      
 BEGIN                
 set @WhereQuery=@WhereQuery+' Current_Work_Step<>''Null'''                              
-- print 'where Query----->'+@WhereQuery             
 End                      
 --print 'Queue name-------->'+@queuename               
--queuename             
  
  
if(rtrim(ltrim(@RegDateRangeFrom))<>'' AND rtrim(ltrim(@RegDateRangeTo))<>'')                                              
BEGIN                                              
 set @WhereQuery=@WhereQuery+' AND Registration_Date between '''+rtrim(ltrim(@RegDateRangeFrom))+''' AND '''+ rtrim(ltrim(@RegDateRangeTo))+''''                                              
END                         
if(rtrim(ltrim(@QDateRangeFrom))<>'' AND rtrim(ltrim(@QDateRangeTo))<>'')                                              
BEGIN                           
                   
 set @WhereQuery=@WhereQuery+' AND Wi_EntryTime between '''+rtrim(ltrim(@QDateRangeFrom))+''' AND '''+ rtrim(ltrim(@QDateRangeTo))+''''                      
END       
  
    
---Doc category          
    
    
 -- print 'doc name report -->'+@DocNameReport  
 if(rtrim(ltrim(@DocumentCategory))<>'All~')            
 BEGIN               
  if(len(@DocumentCategory)=charindex('~',@DocumentCategory))             
  BEGIN            
   set @DocNameReport=ltrim(rtrim(substring(@DocumentCategory,0,len(@DocumentCategory))))         
        
   --set @quName = @quName+','+ltrim(rtrim(substring(@QueueName,0,len(@QueueName))))            
   set @WhereQuery=@WhereQuery+' AND a.Document_Category='''+@DocNameReport+''''            
  END            
  else            
  BEGIN             
   while (charindex('~',@DocumentCategory)>1)                
   BEGIN            
  -- print 'yooo'  
 --  print 'doc name report '+@DocNameReport  
  -- print 'doc category'+@DocumentCategory  
    set @DocNameReport = @DocNameReport + ''''+ltrim(rtrim(SUBSTRING(@DocumentCategory,1,Charindex('~',@DocumentCategory)-1)))+''''+','            
    set @DocumentCategory=ltrim(rtrim(Substring(@DocumentCategory,Charindex('~',@DocumentCategory)+len('~'),len(@DocumentCategory))))             
    --set @quName=@quName +','+ltrim(rtrim(SUBSTRING(@QueueName,1,Charindex('~',@QueueName)-1)))+','            
   END            
            
   set @DocNameReport=substring(@DocNameReport,0,len(@DocNameReport))       
  -- print 'doc name report '+@DocNameReport       
   set @WhereQuery=@WhereQuery+' AND a.Document_Category in('+@DocNameReport+')'    
       
  END            
 END           
       --  print 'Where Query-->'+@WhereQuery  
 ---Doc category         
      
 ---Vendor Name          
           
 if(rtrim(ltrim(@VendorName))<>'')            
 BEGIN            
  set @WhereQuery=@WhereQuery+' AND a.Vendor_Name='''+@VendorName+''''            
 END          
           
 ---Vendor Name         
      
 ---Vendor Number         
           
 if(rtrim(ltrim(@VendorNumber))<>'')            
 BEGIN            
  set @WhereQuery=@WhereQuery+' AND a.Vendor_Number='''+@VendorNumber+''''            
 END          
           
 ---Vendor Number          
                 
----------------------------------------------------------------------------------                     
set @query='';                   
Set @Query='insert into #TA_AP_Queuestatus_Report_Temp(Current_Work_Step,WI_Name,Introduction_Type,Registration_Date,Document_Category,'+  
'Priority,Pay_Entity,Vendor_Name,ACH,AP_Check,Vendor_Number,Invoice_Number,Total_Invoice_Amount,Invoice_Date,Approver_Comments,'+  
'Approval_Decision,Approved_Invoice_Amount,Multi_Payment,Wi_EntryTime,Wi_ExitTime,Aging)'                         
          
 SET @Query=@Query+' SELECT '+@Fields+' from '+ @Tables + ' '+@WhereQuery + ' order by Current_Work_Step,a.Wi_Name '                   
 print (@Query)                      
 exec(@Query)                       
                      
                      
 --select * from #TA_AP_Queuestatus_Report_Temp    
 --Create summary                      
  Set @Query='';              
 SET @Query='insert into #APQSummaryException(Disp_QName,Count_Q) '                      
                      
                      
 set @Query=@Query+' select case Current_Work_Step                       
 when''Approval''then ''Approval :''            
 when''ApprovalException''then ''Approval Exception :''                      
 when''Cancel''then ''Cancel :''            
 when''Coding''then ''Coding :''            
 when''VendorApproval''then ''Vendor Approval :''      
when''Exit''then ''Exit :''                 
 when''QC''then ''QC :''                  
 when''GEACInterface''then ''GEAC Interface :''                      
 when''Introduction''then ''Introduction:''      
 when''JournalEntry''then ''Journal Entry:''      
 when''PendingPayment''then ''Pending Payment:''      
 when''PendingResolution''then ''Pending Resolution:''      
 when''PolicyHolderPayment''then ''Policy Holder Payment:''      
 when''Processing''then ''Processing:''      
 when''Rescan''then ''Rescan:''      
 when''Split''then ''Split :''                   
 else ''Queue Name :'' end as Disp_Qname, count(*) as                         
 count_Q from #TA_AP_Queuestatus_Report_Temp group by Current_Work_Step'                     
print 'Exception Count '+@Query                      
 exec (@Query)            
         
  
--select sum(cast (Count_Q as int)) as sum from #APQSummaryException  
select @RowCount=count(*) from #APQSummaryException with(nolock)                           
 if(@RowCount=0)                                                    
 Begin                                                    
 drop table #APQSummaryException                                                    
 End                        
 select @RowCount=count(*) from #TA_AP_Queuestatus_Report_Temp with(nolock)                               
 print @RowCount       
 --print '0000000'        
 if(@RowCount=0)                               
 Begin                               
  drop table #TA_AP_Queuestatus_Report_Temp                               
 End                      
 else                      
 begin                       
  if Object_ID ('TA_TEMP_AUTOMAIL1') is not null                          
  BEGIN                          
   exec('drop table TA_TEMP_AUTOMAIL1')                      
  END                                    
          --print '111111'            
  Exec('Create table TA_TEMP_AUTOMAIL1 (Header varchar(max),ROw_Index int IDENTITY(1,1) PRIMARY KEY)')                      
                      
   exec ('Insert into TA_TEMP_AUTOMAIL1                       
   Select ''<html><style>.headerbold{align=left style=mso-number-format:\@;COLOR: white;FONT-FAMILY: Arial;FONT-color: white;FONT-SIZE: 9pt;TEXT-DECORATION: none;FONT-WEIGHT: bold;background-color: #993300;}</style>                            
                      
   <table border=1>                      
   <tr align="left"><td colspan=33 class=headerbold>AP QUEUE STATUS REPORT</td></tr>                      
   <tr align="left"><td colspan=33 class=headerbold> From Date: '+@DateRangeFrom+'</td></tr>                      
   <tr align="left"><td colspan=33 class=headerbold> To Date : '+@DateRangeTo+'</td></tr>                   
   </table>  <br>        
   <table border=1><tr><td class=headerbold>Current Queue</td>''+        
   ''<td class=headerbold>WI Name</td>''+                      
   ''<td class=headerbold>Introduction Type</td>''+                      
   ''<td class=headerbold>Registration Date</td>''+                      
   ''<td class=headerbold>Document category</td>''+                      
   ''<td class=headerbold>Priority</td>''+      
   ''<td class=headerbold>Pay entity</td>''+       
   ''<td class=headerbold>Vendor Name</td>''+                      
   ''<td class=headerbold>ACH</td>''+                      
   ''<td class=headerbold>Check</td>''+       
   ''<td class=headerbold>Vendor ID</td>''+          
   ''<td class=headerbold>Invoice Number</td>''+                      
   ''<td class=headerbold>Invoice Amount</td>''+                      
   ''<td class=headerbold>Invoice Date</td>''+                      
   ''<td class=headerbold>Comments</td>''+                      
   ''<td class=headerbold>Approval Decision</td>''+                   
   ''<td class=headerbold>Approved Invoice Amount</td>''+                   
   ''<td class=headerbold>Multi Payment</td>''+                   
   ''<td class=headerbold>Queue Entry Date</td>''+                   
   ''<td class=headerbold>Queue exit date</td>''+                   
   ''</tr></font>''                      
   UNION ALL        
      
        
                     
   Select ''<tr><td align=left style=mso-number-format:\\@>''+ISNULL([Current_Work_Step],'''')+''</td>''+                          
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Wi_Name],'''')+''</td>''+                          
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Introduction_Type],'''')+''</td>''+                         
   ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Registration_Date],''''),120)+''</td>''+         
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Document_Category],'''')+''</td>'' +       
 ''<td align=left style=mso-number-format:\\@>''+ISNULL([Priority],'''')+''</td>'' +       
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Pay_Entity],'''')+''</td>'' +                       
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Name],'''')+''</td>'' +       
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([ACH],'''')+''</td>'' +                       
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([AP_Check],'''')+''</td>'' +          
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Vendor_Number],'''')+''</td>'' +                       
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Invoice_Number],'''')+''</td>'' +                       
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Total_Invoice_Amount],'''')+''</td>'' +       
   ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Invoice_Date],''''),120)+''</td>''+       
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Approver_Comments],'''')+''</td>'' +                       
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Approval_Decision],'''')+''</td>'' +                       
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Approved_Invoice_Amount],'''')+''</td>'' +                    
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Multi_Payment],'''')+''</td>'' +                       
    ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Wi_EntryTime],''''),120)+''</td>''+                   
    ''<td align=left style=mso-number-format:dd\\-mmm\\-yyyy hh\\-mi\\-ss>''+CONVERT(CHAR(25),ISNULL([Wi_ExitTime],''''),120)+''</td>''+                   
   ''<td align=left style=mso-number-format:\\@>''+ISNULL([Aging],'''')+''</td> ''        
    from #TA_AP_Queuestatus_Report_Temp' )             
      
      
   -- select * from TA_TEMP_AUTOMAIL1                                  
   select @status_temp='</tr></table><table><tr><td>&nbsp</td>'+'<td>&nbsp</td></tr>'                       
                      
   DECLARE APSummaryException_Cursor CURSOR FAST_FORWARD FOR                        
   Select Disp_QName,Count_Q from #APQSummaryException                       
   OPEN APSummaryException_Cursor                           
   FETCH NEXT FROM APSummaryException_Cursor INTO  @Disp_QName,@Count_Q                         
   WHILE @@FETCH_STATUS = 0                       
   Begin                       
   select @status_temp=@status_temp+'<tr><td align=left style=mso-number-format:\\@>'+convert(varchar(100),@Disp_QName)+'</td><td align=left style=mso-number-format:\\@>'+convert(varchar(100),@Count_Q)+'</td></tr>'                       
   FETCH NEXT FROM APSummaryException_Cursor INTO @Disp_QName,@Count_Q                       
  End                       
                       
  close APSummaryException_Cursor                           
  Deallocate APSummaryException_Cursor                        
                         
--print @status_temp                      
  select @status_temp=@status_temp+'</table>'          
  exec('insert into TA_TEMP_AUTOMAIL1 select '''+@status_temp+'''   ')                        
                      
 /*update TA_TEMP_AUTOMAIL1 set Header=Replace(Header,'<td align=left style=mso-number-format:dd\\-mmm\\-yyyy>1900-01-01 00:00:00</td>','<td align=left style=mso-number-format:dd\\-mmm\\-yy>&nbsp</td>') */                            
                      
  select @dbname = DB_NAME()                      
  SET @Query='Master..xp_Cmdshell ''bcp "select Header FROM '+@dbname+'..TA_TEMP_AUTOMAIL1 order by row_index asc " queryout "'+@FileName+'" -c -T'', no_output  '                        
                      
  exec(@Query)       
  insert into NG_AutoMail_Status values('APVS Queue Status Report',''+@FileName+'',''+@EmailID+'',0,getdate(),NULL)                       
    --select @RowCount                       
  drop table #APQSummaryException                       
  drop table #TA_AP_Queuestatus_Report_Temp                       
  drop table TA_TEMP_AUTOMAIL1                       
                      
 end                      
  select @RowCount                      
End 
<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: procvariablelist.jsp
Author                          : Shruti Mishra
Date written (DD/MM/YYYY)       : 04/Sep/2007
Description			: This file contains the picklist for ProcessVariable
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
(DD/MM/YYYY)
----------------------------------------------------------------------------------------------------
15/06/2007      Puneet Pahuja           Bug id 1176
23/08/2011      Anushree Jain		    Bug 27971 Security issue
14/09/2011     Anushree Jain	      Bug 28348-Provide external queue variable mapping
----------------------------------------------------------------------------------------------------
--%>
<%@ page import="java.io.*"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h" %>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f" %>
<%@ page contentType="text/html; charset=UTF-8" %>
<%@ page import="java.util.*,com.newgen.wfdesktop.session.*,com.newgen.wfdesktop.workstep.*" %>
<%@ include file="/application/commonheader.process"%>
<f:view>
    <f:loadBundle basename="pmgen" var="PMGEN"/>
    <f:loadBundle basename="pmerrorcodes" var="PMERROR"/>
    <html dir='<h:outputText value="#{PMGEN.HTML_DIR}"/>'>
        <head>
            <title>
                <h:outputText value="#{PMGEN.OMNIFLOW_DESC_TEXT_1}[#{PMGEN.WORKSTEP_PICKLIST}]" />
            </title>
            <link href='../omniflow/<h:outputText value="#{PMGEN.Path}"/>css/docstyle.css' rel="stylesheet" type="text/css">
            <script  src='../omniflow/<h:outputText value="#{PMGEN.Path}"/>scripts/constants.js'></script>
            <script  src="../omniflow/scripts/toolbar.js"></script>
            <script  src="../omniflow/scripts/wfgeneral.js"></script>
            <script  src="../omniflow/scripts/dragiframe.js"></script>
            <script  src="../omniflow/scripts/pickList.js"></script>
            <Script LANGUAGE="Javascript">
    var allWindows = new Array();
    var allPicklistWindows=new Array();
    var CurrentPickListId="ProcVariablePickList";
    var localizedPath='<h:outputText value="#{PMGEN.Path}"/>';
    var strTextFieldID = '<h:outputText value="#{param.strFormFieldText}"/>';
    var strIDFieldID='<h:outputText value="#{param.strFormFieldID}"/>';
    var strFormID ='<h:outputText value="#{param.strFormID}"/>';
    var strTextHidden='<h:outputText value="#{param.strFormFieldTextHidden}"/>';
    var strReturnNoneText='<h:outputText value="#{param.ReturnNoneValue}"/>';
    var strNoneType='<h:outputText value="#{param.NoneType}"/>';
    var strNoneID='<h:outputText value="#{param.NoneValue}"/>';
    var strCallback='<h:outputText value="#{param.CallBack}"/>';
    var strFormFieldType='<h:outputText value="#{param.strFormFieldType}"/>';
    function setValue()
    {
        var len=0;
        try
	{
            len=document.getElementById("ProcVarPicklist:picklist").length;
    	}
        catch(e)
	{
            len=-1;
	}
        var name;
        var id;
        var type;
        var flag=false;
        var strSelectedItems="";
        for(i=0;i<len;i++)
        {
            if(document.getElementById("ProcVarPicklist:picklist").options[i].selected)
            {
                if(i==0 && (strNoneType-0)>0)
                {
                    id=strNoneID;
                    if(strReturnNoneText==0)
                        name='';
                }
                flag=true;
                name=document.getElementById("ProcVarPicklist:picklist").options[i].text;
                var tempVal=document.getElementById("ProcVarPicklist:picklist").options[i].value;
                var arr=tempVal.split(":");
                id=arr[1];
                type=arr[2];
                break;
            }
        } //end for
        if(!flag)
        {
            if(len<=0)
            {
                removeIFrame(CurrentPickListId);
            }
            else
            {
                alert(NO_WORKSTEP_SELECTED);
                return false;
            }   
        }
        else
        {
            try{
                window.parent.document.getElementById(strFormID + ":" + strTextFieldID).value=name;
            }catch(e){}
            try{
                window.parent.document.getElementById(strFormID + ":" + strIDFieldID).value=id;
            }catch(e){}
            try{
                window.parent.document.getElementById(strFormID + ":" + strTextHidden).value=name;
            }catch(e){}
            try{
                window.parent.document.getElementById(strFormID + ":" + strFormFieldType).value=type;
            }catch(e){}
            try{
                if(strCallback.length>0 && Trim(strCallback).length>0)
                {
                    var Temp='window.parent.' + strCallback + '();';
                    eval(Temp);        
                }
                removeIFrame(CurrentPickListId);
            }catch(e)
            {
                removeIFrame(CurrentPickListId);
        }
    }
    }
    
 </Script>
        </head>
          <body class="PMbgcolorTransparent" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" onload="setPicklistFocus();addHandle(document.getElementById('ProcVarPicklist:toolbar'), window);" onunload='closeWindows();closePicklistWindows(CurrentPickListId);return false;'>
    
            <h:panelGrid width="100%" cellpadding="0" cellspacing="0" border="0" styleClass="PMPageBackground" style="border-collapse:collapse;border:1px solid #bbb9b9;">
                <h:form id="ProcVarPicklist">
                    <f:verbatim>
                        <input type="hidden" name="PM_UID" value="<%=pm_uid%>">
                    </f:verbatim>
                    <h:panelGrid columns="2" id="toolbar" cellpadding="0" cellspacing="0" style="border:0;border-bottom: solid 1px #989898;" columnClasses="PMWIDTH70,PMWIDTH30RIGHT" width="100%">
                        <h:outputLabel value="#{PMGEN.PROCVAR_PICKLIST}" styleClass="EWLabel1B" style="width:100%;padding-left:3px;"/>
                        <h:graphicImage title="#{PMGEN.BUTTON_CLOSE}" url="../omniflow/images/close_img.gif" onclick="removeIFrame(CurrentPickListId);" style="CURSOR: pointer;border:0;"/>
                    </h:panelGrid>
                    
                   <h:panelGrid styleClass="PMbgcolorWhite" width="100%" cellpadding="0" cellspacing="0" border="0" >
                       
                    <h:inputHidden id="hid_NoneType" value="#{wfProcVarPicklist.m_iNoneDisplay}"/>
                    <h:inputHidden id="hid_NoneID" value="#{wfProcVarPicklist.m_strNoneID}"/>
                    
                    <f:verbatim><input type=Hidden id="strFormFieldText" name="strFormFieldText" value='</f:verbatim><h:outputText value="#{param.strFormFieldText}"/><f:verbatim>'/></f:verbatim>
                    <f:verbatim><input type=Hidden id="strFormFieldID" name="strFormFieldID" value='</f:verbatim><h:outputText value="#{param.strFormFieldID}"/><f:verbatim>'/></f:verbatim>
                    <f:verbatim><input type=Hidden id="strFormFieldType" name="strFormFieldType" value='</f:verbatim><h:outputText value="#{param.strFormFieldType}"/><f:verbatim>'/></f:verbatim>
                    <f:verbatim><input type=Hidden id="strFormID" name="strFormID" value='</f:verbatim><h:outputText value="#{param.strFormID}"/><f:verbatim>'/></f:verbatim>
                    <f:verbatim><input type=Hidden id="strFormFieldTextHidden" name="strFormFieldTextHidden" value='</f:verbatim><h:outputText value="#{param.strFormFieldTextHidden}"/><f:verbatim>'/></f:verbatim>
                    <f:verbatim><input type=Hidden id="ProcessDefID" name="ProcessDefID" value='</f:verbatim><h:outputText value="#{param.ProcessDefID}"/><f:verbatim>'/></f:verbatim>
                    <f:verbatim><input type=Hidden id="ProcessName" name="ProcessName" value='</f:verbatim><h:outputText value="#{param.ProcessName}"/><f:verbatim>'/></f:verbatim>
                    <f:verbatim><input type=Hidden id="ReturnNoneValue" name="ReturnNoneValue" value='</f:verbatim><h:outputText value="#{param.ReturnNoneValue}"/><f:verbatim>'/></f:verbatim>
                    <f:verbatim><input type=Hidden id="NoneType" name="NoneType" value='</f:verbatim><h:outputText value="#{param.NoneType}"/><f:verbatim>'/></f:verbatim>
                    <f:verbatim><input type=Hidden id="NoneValue" name="NoneValue" value='</f:verbatim><h:outputText value="#{param.NoneValue}"/><f:verbatim>'/></f:verbatim>
                    <f:verbatim><input type=Hidden id="ShowSysVar" name="ShowSysVar" value='</f:verbatim><h:outputText value="#{param.ShowSysVar}"/><f:verbatim>'/></f:verbatim>
                    <%//Displaying the error message if any%>
                    
                    <h:panelGrid columns="1" cellpadding="0" cellspacing="0" columnClasses="PMWIDTH100CENTER" width="100%"  styleClass="PMMessageBorder" >
                        <h:panelGroup rendered="#{wfProcVarPicklist.m_bError}">
                            <h:graphicImage  alt="" onclick="" style="border:0;vertical-align:middle" url="../omniflow/images/errorimage.gif"> </h:graphicImage>
                            <h:outputText value="." style="width:1%;visibility:hidden"/>
                            <h:outputText id="Error" value="#{wfProcVarPicklist.m_strErrorMessage}" styleClass="PMErrorMessage" />
                        </h:panelGroup>
                    </h:panelGrid>
                    
                    <h:panelGrid columns="1" border="0" cellspacing="3" columnClasses="PMWIDTH100CENTERTOP" cellpadding="3" width="100%" rendered="#{!wfProcVarPicklist.m_bError}">
                        <h:selectOneListbox size="10"  styleClass="PMWIDTH190PIXELFORPICKLIST" ondblclick="setValue();" id="picklist"  value="" onkeydown="handlePickListEnter(event);">
                            <f:selectItems value="#{wfProcVarPicklist.m_vectSelectProcVariable}"/>
                        </h:selectOneListbox> 
                    </h:panelGrid>
                    <h:panelGrid columns="1" border="0" cellspacing="3" columnClasses="PMWIDTH100" cellpadding="3" width="100%" rendered="#{wfProcVarPicklist.m_bError}">
                        <h:selectOneListbox size="9" styleClass="PMControlText" id="picklist11" style="width:100%" value="">
                        </h:selectOneListbox> 
                    </h:panelGrid>
                  </h:panelGrid>
                    <h:outputText  style="width:100%" value="  "/>
                </h:form>
            </h:panelGrid>
        </body>
    </html>
</f:view>

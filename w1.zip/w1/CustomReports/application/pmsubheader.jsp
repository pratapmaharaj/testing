<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: pmsubheader.jsp
Author                          : Ajith Jacob
Date written (DD/MM/YYYY)       : 08/Oct/2007
Description			: This file contains the general purpose page header
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
(DD/MM/YYYY)
27 April 2007   Puneet Pahuja            Bug id 666 (rendered property added with output link)
05/10/2009      Himshikha                BUG ID PRM_8.0_017 (To restrict F5 and backspase)
13/06/1992      Dinesh Verma             Bug 46653 - Support of IE11 in ProcessManager
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h" %>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f" %>
<%@ page contentType="text/html"%>
<%@ page pageEncoding="UTF-8"%>
<%@ page import="java.util.*" %>
<f:loadBundle basename="pmgen" var="PMGEN"/>
<f:verbatim>
    <script>
        if (typeof window.event != 'undefined'){ // IE
            document.onkeydown = function() // IE
            {
                var t=event.srcElement.type;
                var kc=event.keyCode;
                if (kc == 116) {
                    window.event.keyCode = 0;         
                    return false;
                }
                else
                    return ((kc != 8 ) || ( t == 'text') || (t == 'textarea') || ( t == 'submit') ||  (t == 'password'))
            }
        }
        else{
            document.onkeypress = function(e)  // FireFox/Others 
            {
                var t=e.target.type;
                var kc=e.keyCode;
                if(kc == 116 && navigator.userAgent.toLowerCase().indexOf("firefox") > -1) {
                    e.cancelBubble = true;
                    return false;
                }
                else if ((kc != 8) || ( t == 'text' ) || (t == 'textarea') || ( t == 'submit') || (t == 'password'))
                    return true;
                else 
                    return false;
           }
        }        
    </script>    
</f:verbatim>

<h:inputHidden id="hidHelpURL" value="../omniflow/#{PMGEN.Path}help/webhelp/#{param.HelpURL}"/>
    <h:panelGrid border="0" columns="1" width="100%" columnClasses="PMWIDTH100TOP" cellpadding="0" cellspacing="0" style="padding-left:12px;padding-right:12px;">
    <h:panelGrid border="0" columns="2" width="100%" columnClasses="PMWIDTH60LEFT,PMWIDTH40RIGHT" cellpadding="0" cellspacing="0">
        <h:outputLabel id="PgHeading" value="#{param.Heading}" styleClass="PMLabelboldGrey" style="width:100%"/>
        <h:panelGrid border="0" columns="1" cellpadding="0" cellspacing="0" columnClasses="PMAlignRight" width="100%">
            <h:panelGroup>
                
                    <h:graphicImage id="cmdlink_TitleRefresh" title="#{PMGEN.BUTTON_REFRESH}" url="../omniflow/images/refresh.gif" onclick="RefreshThisPage();return false;" rendered="#{wfHeader.m_bRenderRefreshButton}" style="cursor: pointer;">
                    </h:graphicImage>
                    
                    <h:graphicImage url="../omniflow/images/sepsmall.gif" rendered="#{wfHeader.m_bRenderRefreshButton}"/>
                    
                    <h:graphicImage id="cmdlink_LinkedWorkitem" title="#{PMGEN.LINKED_WORKITEM}" onclick="ShowLinkedWorkitem();return false;" rendered="#{wfHeader.m_bRenderLinkedWorkitemButton}" url="../omniflow/images/linked.gif" style="cursor: pointer;"><%--for bug id 666--%>
                    </h:graphicImage>
                    
                    <h:graphicImage url="../omniflow/images/sepsmall.gif" rendered="#{wfHeader.m_bRenderLinkedWorkitemButton}"/>
                    
                    
                    <h:graphicImage id="cmdlink_back" title="#{PMGEN.BACKTOFILER}" onclick="backtofilter();return false;" rendered="#{wfHeader.m_bRenderBackButton}" url="../omniflow/images/back.gif" style="cursor: pointer;"><%--for bug id 666--%>
                    </h:graphicImage>
                    
                    <h:graphicImage url="../omniflow/images/sepsmall.gif" rendered="#{wfHeader.m_bRenderBackButton}"/>
                    
                    <h:graphicImage id="cmdlink_TitleSave" title="#{PMGEN.SAVE}" onclick="SaveThisPage();return false;" rendered="#{wfHeader.m_bRenderSaveButton}" url="../omniflow/images/save.gif" style="cursor: pointer;"><%--for bug id 666--%>
                    </h:graphicImage>
                    
                    <h:graphicImage url="../omniflow/images/sepsmall.gif" rendered="#{wfHeader.m_bRenderSaveButton}"/>
                    
                    <h:graphicImage id="cmdlink_TitlePrint" title="#{PMGEN.PRINT}" url="../omniflow/images/print.gif" onclick="PrintThisPage();return false;" rendered="#{wfHeader.m_bRenderPrintButton}" style="cursor: pointer;"><%--for bug id 666--%>
                    </h:graphicImage>
                    
                    <h:graphicImage url="../omniflow/images/sepsmall.gif" rendered="#{wfHeader.m_bRenderPrintButton}"/>
                    
                    <h:graphicImage id="cmdlink_TitleHelp" title="#{PMGEN.HELP}" onclick="ShowHelpFromPage(this,'hidHelpURL');return false;" rendered="#{wfHeader.m_bRenderHelpButton}" url="../omniflow/images/help.gif"  style="cursor: pointer;"><%--for bug id 666--%>            
                    </h:graphicImage>
                
            </h:panelGroup>
        </h:panelGrid>
    </h:panelGrid>
        <h:panelGroup>
            <f:verbatim>
                <hr style="width:100%;">
            </f:verbatim>
        </h:panelGroup>
    </h:panelGrid>

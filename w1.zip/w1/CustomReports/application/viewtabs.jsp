<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: viewtabs.jsp
Author                          : Puneet Pahuja
Date written (DD/MM/YYYY)       : 10/sep/2007
Description			: This file contains the main application window layout
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
(DD/MM/YYYY)
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
--%>
<%@page contentType="text/html"%>
<%@page pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsf/core" prefix="f"%>
<%@taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@page import="com.newgen.wfdesktop.session.*,java.util.*" %>

    <h:panelGrid id="maingrid" cellpadding="2" cellspacing="0" border="0" columns="2" columnClasses="PMWIDTH10TOP,PMWIDTH90TOP" width="100%" style="height:#{wfSession.m_strMinPageHeight};">
        
        <h:panelGrid columns="1" width="100%" cellpadding="3" cellspacing="0" style="height:520px;">
            
            <h:panelGroup>                
                <f:verbatim>           
                    <div id="Statistics" style="TEXT-ALIGN: center;height:65">
                    </div>
                </f:verbatim>
            </h:panelGroup>
            
            
            <h:panelGroup rendered="#{wfSession.m_bAuthorizationFlag}">                
                <f:verbatim>          
                    <div id="AdminOptions" style="TEXT-ALIGN: center;height:190">
                    </div>
                </f:verbatim>
            </h:panelGroup>
            <h:panelGroup rendered="#{!wfSession.m_bAuthorizationFlag}">                
                <f:verbatim>          
                    <div id="AdminOptions" style="TEXT-ALIGN: center;height:190">
                    </div>
                </f:verbatim>
            </h:panelGroup>
            <h:panelGroup>                
                <f:verbatim>        
                    <div id="Reports" style="TEXT-ALIGN: center;height:215">
                    </div>
                </f:verbatim>
            </h:panelGroup>
            
        </h:panelGrid>
        
        
        <h:panelGrid style="width:100%;" cellpadding="0" cellspacing="0" border="0">
            <h:panelGroup>                
                <f:verbatim>        
                    <div id="ResultContainer" style="TEXT-ALIGN: center;">
                    </div>
                </f:verbatim>
            </h:panelGroup>
        </h:panelGrid>
        
    </h:panelGrid>
    
    <h:panelGrid cellpadding="0" cellspacing="0" border="0" columns="1" columnClasses="PMWIDTH100" width="100%">        
        <%@include file="../application/footer.jsp"%>
    </h:panelGrid>
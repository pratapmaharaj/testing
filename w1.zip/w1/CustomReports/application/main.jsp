<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: main.jsp
Author                          : Puneet Pahuja
Date written (DD/MM/YYYY)       : 10/Oct/2007
Description			: This file contains the main application window
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
(DD/MM/YYYY)
02/12/2008      Vijay Kumar             Bug Id  7089
06 Aug 2008     Arup Sharma             BUG ID PRM_8.0_014 (For Time Zone)
06 Aug 2008     Arup Sharma             BUG ID PRM_8.0_014 (For BAM Reports integration)
05/10/2009      Himshikha               BUG ID PRM_8.0_017 (To restrict F5 and backspase)
04/12/2009      Indraneel               PRM_8.0_030 (Support for Export Purge Utility)
04/03/2010      Himshikha               Client time zone not going in request to open external application Webdesktop,BAM
23/08/2011      Anushree Jain		    Bug 27971 Security issue
03/10/2011      Mohd Jaseem             To route the completed workitem in flow(Bug 28560)
08/12/2011      Anushree Jain           Bug 29509 - Provide Launch Bam link
19/01/2012      Sri Prakash             Bug 29762 - support for multitenancy and seperate ini ( cablist.ini ) for cabinet registration
22/04/2013		Prince Kumar			Bug 39008   Requirement of Multiple custom link in Process manager
03/02/2014      Dinesh Verma            Bug 42992 - BAM and Process client are not opening concurrently
19/06/2014      Jaseem Ansari           Bug 46779  An unauthorized user is able to access the link for which he is not authorized.Set EXport Info and Audit log configuration link should be accessed only by admin user.
13/06/1992      Dinesh Verma            Bug 46653 - Support of IE11 in ProcessManager
17/03/2015      Bhupesh Kumar           Bug 54570 - Required to configure custom lin/SUb Custom link according to user/Group in processmanager 
06/10/2017		Saquib Islam			Bug 72327 - Following vulnerabilities reported in processmanager:
													1. Password type input with auto-complete enabled
													2. Unauthorized Read Access
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--%>
<%@page contentType="text/html"%>
<%@page pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsf/core" prefix="f"%>
<%@taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@page import="com.newgen.wfdesktop.session.*,java.util.*,com.newgen.wfdesktop.util.WFUtility, com.newgen.wfdesktop.cabinet.WFCabinetList"%>
<%@ include file="/application/commonheader.process"%>

<%
    String eToken = wfSession.getM_strTokenVal();
    if (wfSession.getM_strPwdEncrypt().equalsIgnoreCase("Y") && eToken.length() == 0) {
        String strTokenValue = WFUtility.MakeUniqueNumber();
        int index = strTokenValue.indexOf('-');
        if (index != -1) {
            strTokenValue = strTokenValue.substring(1);
        }
        wfSession.setM_strTokenVal(strTokenValue);
    }
%>

 <f:view>
     <f:loadBundle basename="pmgen" var="PMGEN"/>
     <f:loadBundle basename="pmerrorcodes" var="PMERROR"/>
<html dir='<h:outputText value="#{PMGEN.HTML_DIR}"/>'>
    <head>
	<link href='../omniflow/<h:outputText value="#{PMGEN.Path}"/>css/docstyle.css' rel="stylesheet" type="text/css">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><h:outputText value="#{PMGEN.OMNIFLOW_DESC_TEXT_1}" /></title>
        <script  src='../omniflow/<h:outputText value="#{PMGEN.Path}"/>scripts/constants.js'></script>
        <script  src="../omniflow/scripts/wfgeneral.js"></script>
	<script  src="../omniflow/scripts/toolbar.js"></script>
        <script  src="../omniflow/scripts/view.js"></script>
        <script  src="../omniflow/scripts/net.js"></script>
        <script  src="../omniflow/scripts/main.js"></script>
        <script  src="../omniflow/scripts/reportsgeneral.js"></script>
         <script  src="../omniflow/scripts/history.js"></script>
         <script  src="../omniflow/scripts/reports.js"></script>
         <script  src="../omniflow/scripts/adminoptions.js"></script>
         <script  src="../omniflow/scripts/search.js"></script>
         <script  src="../omniflow/scripts/date.js"></script>
         <script  src="../omniflow/scripts/dragiframe.js"></script>
         <script  src="../omniflow/scripts/queueprocessauth.js"></script>
         <script  src="../omniflow/scripts/exportcabinet.js"></script>
         <script  src="../omniflow/scripts/purge_criteria.js"></script>
         <script  src="../omniflow/scripts/aliasrule.js"></script>
         <script  src="../omniflow/scripts/client.js"></script>
         <script  src="../omniflow/scripts/mozillamenumain.js"></script>
         <script src="../omniflow/scripts/blowfish.js"></script>

        <link href='../omniflow/<h:outputText value="#{PMGEN.Path}"/>css/scrolling_table.css' rel="stylesheet" type="text/css">

        <Script LANGUAGE="Javascript">
            var serverUrl='<h:outputText value="#{PMGEN.OMNIFLOW_WEB_CLIENT_URL}"/>';
            var allWindows = new Array();
            var launchWindows = new Array();
            var allPicklistWindows=new Array();
            var localizedPath='<h:outputText value="#{PMGEN.Path}"/>';
            var HTML_DIR='<h:outputText value="#{PMGEN.HTML_DIR}"/>';
            var DateFormat= '<h:outputText value="#{wfSession.m_strDisplayDateFormat}"/>';
            DateFormat = DateFormat.toUpperCase();

            var serverIp='<h:outputText value="#{wfSession.m_objCabinet.m_strServerIP}"/>';
            var serverPort='<h:outputText value="#{wfSession.m_objCabinet.m_iServerPort}"/>';
            var serverType='<h:outputText value="#{wfSession.m_objCabinet.m_strServerType}"/>';
            var cabinetName='<h:outputText value="#{wfSession.m_objCabinet.m_strCabinetName}"/>';
            var cabinetType='<h:outputText value="#{wfSession.m_objCabinet.m_strCabType}"/>';
            var siteName='<h:outputText value="#{wfSession.m_objCabinet.m_strSiteName}"/>';
            var siteId='<h:outputText value="#{wfSession.m_objCabinet.m_iSiteID}"/>';
            var volName='<h:outputText value="#{wfSession.m_objCabinet.m_strVolName}"/>';
            var volumeId='<h:outputText value="#{wfSession.m_objCabinet.m_iVolumeID}"/>';
            var encoding='<h:outputText value="#{wfSession.m_objCabinet.m_strEncoding}"/>';

            var userName = '<h:outputText value="#{wfSession.m_strUserName}"/>';
            var cabName  = '<h:outputText value="#{wfSession.m_strCabName}"/>';
            var userIndex= '<h:outputText value="#{wfSession.m_iUserIndex}"/>';
            var sessionId= '<h:outputText value="#{wfSession.m_strSessionID}"/>';
            var UniqueUserId= '<h:outputText value="#{wfSession.m_strUniqueUserId}"/>';
            var SessionVariable= '<h:outputText value="#{wfSession.m_strSessionVar}"/>';
            var AllWorksteps='<h:outputText value="#{PMGEN.ALL_WORKSTEPS}"/>';
            var AllQueues='<h:outputText value="#{PMGEN.ALL_QUEUES}"/>';
            var AllGroups='<h:outputText value="#{PMGEN.ALL_GROUPS_1}"/>';
            var PreferredQueues='<h:outputText value="#{PMGEN.PREFERRED_QUEUE}"/>';
            var AllProcesses='<h:outputText value="#{PMGEN.ALL_PROCESSES_1}"/>';
            var LastSuccessLogin = '<h:outputText value="#{wfSession.m_strLastLoginDT}"/>';
            var LastFailedLogin = '<h:outputText value="#{wfSession.m_strLastFailedLoginDT}"/>';
            var FailedCount = '<h:outputText value="#{wfSession.m_iLastLoginFailedCount}"/>';
            var bEnableTimeZone = '<h:outputText value="#{wfSession.m_bEnableTimeZone}"/>';
            var iServerTimeDiff = '<h:outputText value="#{wfSession.m_iServerTZDiff}"/>';
            var iClientTimeDiff = '<h:outputText value="#{wfSession.m_iClientTZDiff}"/>';
            var bBAMReports = '<h:outputText value="#{wfSession.m_bBAMReports}"/>';
            var minPageHeight='<h:outputText value="#{wfSession.m_strMinPageHeight}"/>';
            var mRightPaneWidth='<h:outputText value="#{wfSession.m_strRightPaneWidth}"/>';
            var myMenu =<h:outputText value="#{wfSession.m_strCustomUrl}" />;
            var isAdmin='<h:outputText value="#{wfSession.m_bAdmin}"/>';
            //alert(myMenu);
            var isAdhocAtExit = '<%= WFCabinetList.getConfValue("IsAdhocAtExit", "N", wfSession.getM_strCabName()) %>';
            var dcWindow=null;
            var dcWebWindow=null;
            var dcBamWindow=null;
            var ajaxaction=null;
            var availH = window.screen.availHeight;
            var availW = window.screen.availWidth;
            var servletRef = window.top.location.href;
            var SessionCheckTimer;
             var sContextPath='<%=WFUtility.sContextPath%>';

            var launchServerUrl = "<%=WFCabinetList.getConfValue("WDContextPath","/webdesktop", wfSession.getM_strCabName())%>/login/login.jsp?CalledFrom=EXT&UserName="+encode_utf8(userName)+"&EngineName="+encode_utf8(cabName)+"&UserIndex="+userIndex+"&SessionId="+sessionId+"&ClientHeight="+availH+"&ClientWidth="+availW;
            launchServerUrl = servletRef.substring(0, servletRef.indexOf(sContextPath)) + launchServerUrl;

            var launchCustomReportsUrl = "/BAM/login/login.jsp?CalledFrom=EXT&UserId="+encode_utf8(userName)+"&UserIndex="+userIndex+"&SessionId="+sessionId+"&ClientHeight="+availH+"&ClientWidth="+availW+"&ServerIP="+encode_utf8(serverIp)+"&ServerPort="+encode_utf8(serverPort)+"&ServerType="+encode_utf8(serverType)+"&CabinetName="+encode_utf8(cabinetName)+"&CabType="+encode_utf8(cabinetType)+"&SiteName="+encode_utf8(siteName)+"&SiteID="+encode_utf8(siteId)+"&VolName="+encode_utf8(volName)+"&VolumeID="+encode_utf8(volumeId)+"&Encoding="+encode_utf8(encoding)+"&LaunchClient=Y";

            var launchBamUrl = "/bam/login/login.jsp?CalledFrom=EXT&UserId="+encode_utf8(userName)+"&CabinetName="+encode_utf8(cabName)+"&UserIndex="+userIndex+"&SessionId="+sessionId+"&LaunchClient=MP";
            launchBamUrl = servletRef.substring(0, servletRef.indexOf(sContextPath)) + launchBamUrl;

            var launchCustomReportsUrl = "/bam/login/login.jsp?CalledFrom=EXT&UserId="+encode_utf8(userName)+"&UserIndex="+userIndex+"&SessionId="+sessionId+"&ClientHeight="+availH+"&ClientWidth="+availW+"&ServerIP="+encode_utf8(serverIp)+"&ServerPort="+encode_utf8(serverPort)+"&ServerType="+encode_utf8(serverType)+"&CabinetName="+encode_utf8(cabinetName)+"&CabType="+encode_utf8(cabinetType)+"&SiteName="+encode_utf8(siteName)+"&SiteID="+encode_utf8(siteId)+"&VolName="+encode_utf8(volName)+"&VolumeID="+encode_utf8(volumeId)+"&Encoding="+encode_utf8(encoding)+"&LaunchClient=Y";
            launchCustomReportsUrl = servletRef.substring(0, servletRef.indexOf(sContextPath)) + launchCustomReportsUrl;
            //END

            if(bEnableTimeZone.toUpperCase() == "TRUE"){
                launchServerUrl += '&ClientGMTOffset='+iClientTimeDiff;
                launchCustomReportsUrl += '&ClientGMTOffset='+iClientTimeDiff;
            }

            var text = 0;
            var msgLastLogin = LAST_SUCCESS_LOGIN+LastSuccessLogin;
            var msgLastFailedLogin = LAST_FAILED_LOGIN+LastFailedLogin;
            var msgFailedLoginCount = FAILED_LOGIN_COUNT+FailedCount;

            var message=new Array();
              message[0] = msgLastLogin
              message[1] = msgLastFailedLogin
              message[2] = msgFailedLoginCount
              
            var bPwdEncrypt='<h:outputText value="#{wfSession.m_strPwdEncrypt}" />' ;
            var eToken='<h:outputText value="#{wfSession.m_strTokenVal}" />' ;

    function changeText() {
        if(document.getElementById("LoginInfoDetails")){
            if (message.length > 0) {
                //document.change.descript.value=message[text];
                
                document.getElementById("LoginInfoDetails").innerHTML = message[text];
                //alert(message[text]);
                text++;
            }
            if (text == 3) {text = 0; }
            window.setTimeout("changeText()", 10000);
        }
    }


            function handleEnterMain(e,id)
            {
                var browser=navigator.appName;
                if(browser=="Netscape")
                {

                           if(e.which == 13)
                           {

                                try
                                {
                                    document.getElementById(id).focus();
                                }
                                catch(e){
                                }

                           }
                  }

                  else
                     {
                        e=window.event;
                        if(e.keyCode == 13)
                            {
                                try
                                {
                                    document.getElementById(id).focus();
                                }
                                catch(e){
                                }
                            }

                     }
            }

       if (typeof window.event != 'undefined'){ // IE
            document.onkeydown = function() // IE
            {
                var t=event.srcElement.type;
                var kc=event.keyCode;
                if (kc == 116) {
                    window.event.keyCode = 0;
                    return false;
                }
                else
                    return ((kc != 8 ) || ( t == 'text') || (t == 'textarea') || ( t == 'submit') ||  (t == 'password'))
            }
        }
        else{
            document.onkeypress = function(e)  // FireFox/Others
            {
                var t=e.target.type;
                var kc=e.keyCode;
                if(kc == 116 && navigator.userAgent.toLowerCase().indexOf("firefox") > -1) {
                    e.cancelBubble = true;
                    return false;
                }
                else if ((kc != 8) || ( t == 'text' ) || (t == 'textarea') || ( t == 'submit') || (t == 'password'))
                    return true;
                else
                    return false;
           }
        }
        
        </Script>
    </head>
    <body topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" onload="mainOnLoad();changeText();checkSession();" onunload='closeWindows();closeLaunchWindows();return false;' background="../omniflow/images/bgimage.gif">
        <h:panelGrid width="#{wfSession.m_strMainPageWidth};" cellpadding="0" cellspacing="0" border="0" columns="1" columnClasses="PMWIDTH100CENTERTOP" style="height:100%;">
        <h:panelGrid styleClass="PMbgcolorWhite" width="100%" cellpadding="5" cellspacing="0" border="0"  style="height:100%;" columnClasses="PMWIDTH100CENTERTOP">
            <h:panelGroup>
            <jsp:include page="../application/pmheadertoolbar.jsp" />
            <h:panelGrid width="100%" cellpadding="0" cellspacing="0" border="0" styleClass="PMPageBackground">
                <jsp:include page="../application/viewtabs.jsp" />
            </h:panelGrid>
            </h:panelGroup>
        </h:panelGrid>
        </h:panelGrid>


    </body>
</html>
</f:view>

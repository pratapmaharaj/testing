<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: worksteppicklist.jsp
Author                          : Ajith Jacob
Date written (DD/MM/YYYY)       : 24/Jan/2007
Description			: This file contains the picklist for workstep.
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
(DD/MM/YYYY)
----------------------------------------------------------------------------------------------------
18/04/2007       Arup Sharma            BUG ID 628 (QueueID kept in hidden field)
01/05/2007       Puneet Pahuja          Bug id 671
15/06/2007      Puneet Pahuja           Bug id 1176
15/01/2010      Bhupesh Kumar           PRM_8.0_035 Unable Adhoc route any workitem at Exit or Discard workstep because these workstep are not coming in the list.  
23/08/2011      Anushree Jain		    Bug 27971 Security issue
----------------------------------------------------------------------------------------------------
--%>
<%@ page import="java.io.*"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h" %>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f" %>
<%@ page contentType="text/html; charset=UTF-8" %>
<%@ page import="java.util.*,com.newgen.wfdesktop.session.*,com.newgen.wfdesktop.workstep.*" %>
<%@ include file="/application/commonheader.process"%>
<f:view>
    <f:loadBundle basename="pmgen" var="PMGEN"/>
    <f:loadBundle basename="pmerrorcodes" var="PMERROR"/>
    <html dir='<h:outputText value="#{PMGEN.HTML_DIR}"/>'>
        <head>
            <title>
                <h:outputText value="#{PMGEN.OMNIFLOW_DESC_TEXT_1}[#{PMGEN.WORKSTEP_PICKLIST}]" />
            </title>
            <link href='../omniflow/<h:outputText value="#{PMGEN.Path}"/>css/docstyle.css' rel="stylesheet" type="text/css">
            <script  src='../omniflow/<h:outputText value="#{PMGEN.Path}"/>scripts/constants.js'></script>
            <script  src="../omniflow/scripts/toolbar.js"></script>
            <script  src="../omniflow/scripts/wfgeneral.js"></script>
            <script  src="../omniflow/scripts/dragiframe.js"></script>
            <script  src="../omniflow/scripts/pickList.js"></script>
            <Script LANGUAGE="Javascript">
    var allWindows = new Array();
    var allPicklistWindows=new Array();
    var CurrentPickListId="WorkstepPickList";
    var localizedPath='<h:outputText value="#{PMGEN.Path}"/>';
    var strTextFieldID = '<h:outputText value="#{param.strFormFieldText}"/>';
    var strIDFieldID='<h:outputText value="#{param.strFormFieldID}"/>';
    var strFormID ='<h:outputText value="#{param.strFormID}"/>';
    var strTextHidden='<h:outputText value="#{param.strFormFieldTextHidden}"/>';
    var strReturnNoneText='<h:outputText value="#{param.ReturnNoneValue}"/>';
    var strNoneType='<h:outputText value="#{param.NoneType}"/>';
    var strNoneID='<h:outputText value="#{param.NoneValue}"/>';
    var strCallback='<h:outputText value="#{param.CallBack}"/>';
    function setValue()
    {
        var len=0;
        try
	{
            len=document.getElementById("WorkstepPickList:picklist").length;
    	}
        catch(e)
	{
            len=-1;
	}
        var name;
        var id;
        var ids;
        var flag=false;
        var strSelectedItems="";
        for(i=0;i<len;i++)
        {
            if(document.getElementById("WorkstepPickList:picklist").options[i].selected)
            {
                name=document.getElementById("WorkstepPickList:picklist").options[i].text;
                id=document.getElementById("WorkstepPickList:picklist").options[i].value;
                if(i==0 && strNoneType>0)
                {
                    id=strNoneID;
                    if(strReturnNoneText==0)
                        name='';
                }
                flag=true;
                break;
            }
        } //end for
        if(!flag)
        {
            if(len<=0)
            {
                removeIFrame(CurrentPickListId);
            }
            else
            {
                alert(NO_WORKSTEP_SELECTED);
                return false;
            }   
        }
        else
        {
            try{
                window.parent.document.getElementById(strFormID + ":" + strTextFieldID).value=name;
                window.parent.document.getElementById(strFormID + ":" + strIDFieldID).value=id;
                window.parent.document.getElementById(strFormID + ":" + strTextHidden).value=name;
                if(strCallback.length>0 && Trim(strCallback).length>0)
                {
                    var Temp='window.parent.' + strCallback + '();';
                    eval(Temp);        
                }
                removeIFrame(CurrentPickListId);
              }catch(e){}
        }
    }
     
</Script>
        </head>
 <body class="PMbgcolorTransparent" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" onload="setPicklistFocus();addHandle(document.getElementById('WorkstepPickList:toolbar'), window);" onunload='closeWindows();closePicklistWindows(CurrentPickListId);return false;' >
    
            <h:panelGrid width="100%" cellpadding="0" cellspacing="0" border="0" styleClass="PMPageBackground" style="border-collapse:collapse;border:1px solid #bbb9b9;">
                <h:form id="WorkstepPickList">
                    <f:verbatim>
                        <input type="hidden" name="PM_UID" value="<%=pm_uid%>">
                    </f:verbatim>
                    <h:panelGrid columns="3" id="toolbar" cellpadding="0" cellspacing="0" style="border:0;border-bottom: solid 1px #989898;" columnClasses="PMWIDTH65,PMWIDTH5,PMWIDTH30RIGHT" width="100%">
                        <h:outputLabel value="#{PMGEN.WORKSTEP_PICKLIST}" styleClass="EWLabel1B" style="width:100%;padding-left:3px;"/>
                         <h:panelGroup>
                            <h:inputHidden id="hid_FirstField" value="#{wfWorkstepList.m_strFirstField}"/>
                            <h:inputHidden id="hid_LastField" value="#{wfWorkstepList.m_strLastField}"/>
                            <h:inputHidden id="hid_FirstFieldIndex" value="#{wfWorkstepList.m_strFirstFieldIndex}"/>
                            <h:inputHidden id="hid_LastFieldIndex" value="#{wfWorkstepList.m_strLastFieldIndex}"/>
                            <h:inputHidden id="hid_Action" value="#{wfWorkstepList.m_iAction}"/>
                            <h:inputHidden id="hid_NoneType" value="#{wfWorkstepList.m_iNoneDisplay}"/>
                            <h:inputHidden id="hid_NoneID" value="#{wfWorkstepList.m_strNoneID}"/>
                            
                            <f:verbatim><input type=Hidden id="strFormFieldText" name="strFormFieldText" value='</f:verbatim><h:outputText value="#{param.strFormFieldText}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="strFormFieldID" name="strFormFieldID" value='</f:verbatim><h:outputText value="#{param.strFormFieldID}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="strFormID" name="strFormID" value='</f:verbatim><h:outputText value="#{param.strFormID}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="strFormFieldTextHidden" name="strFormFieldTextHidden" value='</f:verbatim><h:outputText value="#{param.strFormFieldTextHidden}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="ProcessDefID" name="ProcessDefID" value='</f:verbatim><h:outputText value="#{param.ProcessDefID}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="ProcessName" name="ProcessName" value='</f:verbatim><h:outputText value="#{param.ProcessName}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="ReturnNoneValue" name="ReturnNoneValue" value='</f:verbatim><h:outputText value="#{param.ReturnNoneValue}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="NoneType" name="NoneType" value='</f:verbatim><h:outputText value="#{param.NoneType}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="NoneValue" name="NoneValue" value='</f:verbatim><h:outputText value="#{param.NoneValue}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="CallBack" name="CallBack" value='</f:verbatim><h:outputText value="#{param.CallBack}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="Mode" name="Mode" value='</f:verbatim><h:outputText value="#{param.Mode}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="QueueID" name="QueueID" value='</f:verbatim><h:outputText value="#{param.QueueID}"/><f:verbatim>'/></f:verbatim> 
                            <f:verbatim><input type=Hidden id="IsAdhoc" name="IsAdhoc" value='</f:verbatim><h:outputText value="#{param.IsAdhoc}"/><f:verbatim>'/></f:verbatim> 
                        </h:panelGroup>  
                        <h:graphicImage title="#{PMGEN.BUTTON_CLOSE}" url="../omniflow/images/close_img.gif" onclick="removeIFrame(CurrentPickListId);" style="CURSOR: pointer;border:0;"/>
                    </h:panelGrid>  
                   <h:panelGrid styleClass="PMbgcolorWhite" width="100%" cellpadding="0" cellspacing="0" border="0"  >
                    <h:panelGrid columns="2" border="0" cellspacing="" columnClasses="PMWIDTH35,PMWIDTH65" cellpadding="2" width="100%" >
                    <h:outputText   style="width:100%" value="#{PMGEN.SEARCH_ONFILTER}" styleClass="EWLabel1"/>
                    <h:panelGroup>
                        <h:panelGrid columns="2" border="0" cellspacing="2" columnClasses="PMWIDTH90,PMWIDTH10" cellpadding="0" width="100%">
                            <h:inputText  style="width:100%" styleClass="PMControlText" id="Workstepfilter" value="#{wfWorkstepList.m_strWorkstepPrefix}" onkeydown="handlePickListEnter(event,'WorkstepPickList:cmdlink_Search');"/>
                             <h:commandLink styleClass="EWEnabledLink" id="cmdlink_Search" action="#{wfWorkstepList.searchonfilter}">
                                <h:graphicImage alt="#{PMGEN.TITLE_SEARCH}" style="border:0" url="../omniflow/#{PMGEN.Path}images/go.gif"> </h:graphicImage>
                            </h:commandLink>
                        </h:panelGrid>
                    </h:panelGroup>
                    </h:panelGrid>
                    <%//Displaying the error message if any%>
                    <h:panelGrid columns="1" cellpadding="0" cellspacing="0" columnClasses="PMWIDTH100CENTER" width="100%"  styleClass="PMMessageBorder" >
                        <h:panelGroup rendered="#{wfWorkstepList.m_bError}">
                            <h:graphicImage  alt="" onclick="" style="border:0;vertical-align:middle" url="../omniflow/images/errorimage.gif"> </h:graphicImage>
                            <h:outputText value="." style="width:1%;visibility:hidden"/>
                            <h:outputText id="Error" value="#{wfWorkstepList.m_strErrorMessage}" styleClass="PMErrorMessage" />
                        </h:panelGroup>
                    </h:panelGrid>
                    
                    
                    <h:panelGrid columns="1" border="0" cellspacing="3" columnClasses="PMWIDTH100CENTERTOP" cellpadding="3" width="100%" rendered="#{!wfWorkstepList.m_bError}">
                        <h:selectOneListbox size="10" binding="#{wfWorkstepList.m_Misc}" styleClass="PMWIDTH190PIXELFORPICKLIST" ondblclick="setValue();" id="picklist"  value="" onkeydown="handlePickListEnter(event);">
                            <f:selectItems value="#{wfWorkstepList.m_objWorkstepList}"/>
                        </h:selectOneListbox> 
                    </h:panelGrid>
                    <h:panelGrid columns="1" border="0" cellspacing="3" columnClasses="PMWIDTH100" cellpadding="3" width="100%" rendered="#{wfWorkstepList.m_bError}">
                        <h:selectOneListbox size="9" styleClass="PMControlText" id="picklist11" style="width:100%" value="">
                        </h:selectOneListbox> 
                    </h:panelGrid>
                    <h:panelGrid columns="5" border="0" cellspacing="0"  columnClasses="PMWIDTH20,PMWIDTH20,PMWIDTH20,PMWIDTH20RIGHT,PMWIDTH20RIGHT" cellpadding="0" width="100%" rendered="#{!wfWorkstepList.m_bError}">
                        <h:outputText  style="width:100%" value="  "/>
                        <h:outputText  style="width:100%" value="  "/>
                        <h:outputText  style="width:100%" value="  "/>
                        <h:panelGroup>
                            <h:commandLink styleClass="EWEnabledLink" id="cmdlink_Previous" action="#{wfWorkstepList.previous}" tabindex="#{wfWorkstepList.m_strTabIndexForPrevious}"><%--for bug id 671--%>
                                <h:graphicImage  alt="#{PMGEN.BUTTON_PREVIOUS}" style="border:0" url="../omniflow/#{PMGEN.Path}images/prev.gif" rendered="#{wfWorkstepList.m_bEnablePreviousButton}"> </h:graphicImage>
                            </h:commandLink>
                            <h:graphicImage alt="#{PMGEN.BUTTON_PREVIOUS}" style="border:0" url="../omniflow/#{PMGEN.Path}images/prev_dis.gif" rendered="#{!wfWorkstepList.m_bEnablePreviousButton}"> </h:graphicImage>
                        </h:panelGroup>
                        <h:panelGroup>
                            <h:commandLink styleClass="EWEnabledLink" id="cmdlink_Next" action="#{wfWorkstepList.next}" tabindex="#{wfWorkstepList.m_strTabIndexForNext}"><%--for bug id 671--%>
                                <h:graphicImage  alt="#{PMGEN.BUTTON_NEXT}" style="border:0" url="../omniflow/#{PMGEN.Path}images/next.gif" rendered="#{wfWorkstepList.m_bEnableNextButton}"> </h:graphicImage>
                            </h:commandLink>
                            <h:graphicImage alt="#{PMGEN.BUTTON_NEXT}" style="border:0" url="../omniflow/#{PMGEN.Path}images/next_dis.gif" rendered="#{!wfWorkstepList.m_bEnableNextButton}"> </h:graphicImage>
                        </h:panelGroup>
                   </h:panelGrid> 
                 </h:panelGrid> 
                </h:form>
            </h:panelGrid>
        </body>
    </html>
</f:view>

<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: statistics.jsp
Author                          : Puneet Pahuja
Date written (DD/MM/YYYY)       : 10/Oct/2007
Description			: This file contains Statistics options page
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		      Change By        Change Description (Bug No. (If Any))
(DD/MM/YYYY)
*18/02/2011       Sri Prakash      PRM_9.0_004  User link coming disabled in Process Manager's Statistics section
01/11/2012    Jaseem Ansari                PRM_8.0_056|(Need to change the color code of processmanager)
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--%>
<%@page contentType="text/html"%>
<%@page pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsf/core" prefix="f"%>
<%@taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@page import="com.newgen.wfdesktop.session.*,java.util.*" %>
<f:view>
    <f:loadBundle basename="pmgen" var="PMGEN"/>
    <f:loadBundle basename="pmerrorcodes" var="PMERROR"/>
    <h:panelGrid columns="1" width="#{wfSession.m_strLeftPaneWidth}" cellpadding="0" cellspacing="0">
        <h:panelGrid columns="3" cellpadding="0" cellspacing="0" border="0" columnClasses="PMWIDTH1,PMWIDTH100,PMWIDTH1" width="100%">
            <h:graphicImage  value="../omniflow/images/green_#{PMGEN.LEFT}.gif"></h:graphicImage>
            <h:panelGrid columns="2" cellpadding="4" cellspacing="0" border="0" columnClasses="PMWIDTH70,PMWIDTH30RIGHT" width="100%" style="background-image: url('../omniflow/images/green_back.gif');">
                <h:outputLabel value="#{PMGEN.STATISTICS}" styleClass="PMWindowTitle" style="width:100%;padding-left: 3px;"/>
                <h:panelGroup>
                    <h:graphicImage  value="../omniflow/images/property.gif"></h:graphicImage>
                </h:panelGroup>
            </h:panelGrid>
            <h:graphicImage  value="../omniflow/images/green_#{PMGEN.RIGHT}.gif"></h:graphicImage>
        </h:panelGrid>
        
        <h:panelGrid columns="1" width="100%" cellpadding="0" cellspacing="0" border="1" style="border-collapse:collapse;border:1px solid #bbb9b9;">
            
            <h:panelGrid columns="2" cellpadding="0" cellspacing="0" border="0" columnClasses="PMWIDTH1,PMWIDTH99" width="100%" styleClass="PMBckColor">
                <h:graphicImage  value="../omniflow/images/arrow_bullet.gif" ></h:graphicImage>
                <h:outputLabel  value="#{PMGEN.TITLE_QUEUES}" onclick="statistics('q');" styleClass="PMLabelBoldGreen2" style="CURSOR: pointer;" onmouseover="StyleLink(this);" onmouseout="StyleNormal(this);"/>
            </h:panelGrid>
            
            <h:panelGrid columns="2" cellpadding="0" cellspacing="0" border="0" columnClasses="PMWIDTH1,PMWIDTH99" width="100%" styleClass="PMBckColor">
                <h:graphicImage  value="../omniflow/images/arrow_bullet.gif" ></h:graphicImage>
                <h:outputLabel  value="#{PMGEN.PROCESSES}" onclick="statistics('p');" styleClass="PMLabelBoldGreen2" style="CURSOR: pointer;" onmouseover="StyleLink(this);" onmouseout="StyleNormal(this);"/>
            </h:panelGrid>
            
            <h:panelGrid columns="2" cellpadding="0" cellspacing="0" border="0" columnClasses="PMWIDTH1,PMWIDTH99" width="100%" styleClass="PMBckColor">
                <h:graphicImage  value="../omniflow/images/arrow_bullet.gif" ></h:graphicImage>
                <h:outputLabel  value="#{PMGEN.USER}" onclick="statistics('u');" styleClass="PMLabelBoldGreen2" style="CURSOR: pointer;" onmouseover="StyleLink(this);" onmouseout="StyleNormal(this);" rendered="#{wfSession.m_bAdmin}"/>
                <h:outputLabel  value="#{PMGEN.USER}" onclick="statistics('u1');" styleClass="PMLabelBoldGreen2" style="CURSOR: pointer;" onmouseover="StyleLink(this);" onmouseout="StyleNormal(this);" rendered="#{!wfSession.m_bAdmin}"/>
            </h:panelGrid>            
            
        </h:panelGrid>
        
    </h:panelGrid>
    
</f:view>

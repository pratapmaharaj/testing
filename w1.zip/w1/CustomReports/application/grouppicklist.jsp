<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: grouppicklist.jsp
Author                          : Ajith Jacob
Date written (DD/MM/YYYY)       : 18/Jan/2007
Description			: This file contains the picklist for group.
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
(DD/MM/YYYY)
01/05/2007      Puneet Pahuja            Bug id 671
15/06/2007      Puneet Pahuja           Bug id 1176
 19 May 2009      Vijay Kumar/Puneet Satija    PRM_8.0_006  
23/08/2011      Anushree Jain		    Bug 27971 Security issue
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--%>
<%@ page import="java.io.*"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h" %>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f" %>
<%@ page contentType="text/html; charset=UTF-8" %>
<%@ page import="java.util.*,com.newgen.wfdesktop.session.*,com.newgen.wfdesktop.group.*" %>
<%@ include file="/application/commonheader.process"%>
<f:view>
    <f:loadBundle basename="pmgen" var="PMGEN"/>
    <f:loadBundle basename="pmerrorcodes" var="PMERROR"/>
    <html dir='<h:outputText value="#{PMGEN.HTML_DIR}"/>'>
        <head>
            <title>
                <h:outputText value="#{PMGEN.OMNIFLOW_DESC_TEXT_1}[#{PMGEN.GROUP_PICKLIST}]" />
            </title>
            <link href='../omniflow/<h:outputText value="#{PMGEN.Path}"/>css/docstyle.css' rel="stylesheet" type="text/css">
            <script  src='../omniflow/<h:outputText value="#{PMGEN.Path}"/>scripts/constants.js'></script>
            <link href='../omniflow/<h:outputText value="#{PMGEN.Path}"/>css/scrolling_table.css' rel="stylesheet" type="text/css">
            <script  src="../omniflow/scripts/toolbar.js"></script>
            <script  src="../omniflow/scripts/dragiframe.js"></script>
            <script  src="../omniflow/scripts/wfgeneral.js"></script>
            <script  src="../omniflow/scripts/pickList.js"></script>
            <Script LANGUAGE="Javascript">
    var allWindows = new Array();
    var allPicklistWindows=new Array();
    var CurrentPickListId="GroupPickList";
    var localizedPath='<h:outputText value="#{PMGEN.Path}"/>';
    var strTextFieldID = '<h:outputText value="#{param.strFormFieldText}"/>';
    var strIDFieldID='<h:outputText value="#{param.strFormFieldID}"/>';
    var strFormID ='<h:outputText value="#{param.strFormID}"/>';
    var strTextHidden='<h:outputText value="#{param.strFormFieldTextHidden}"/>';
    var strReturnNoneText='<h:outputText value="#{param.ReturnNoneValue}"/>';    
    var strNoneType='<h:outputText value="#{param.NoneType}"/>';
    var strNoneID='<h:outputText value="#{param.NoneValue}"/>';
    var strCallback='<h:outputText value="#{param.CallBack}"/>';
    var strparentFlag='<h:outputText value="#{param.parentFlag}"/>';
    var strparentIFrame='<h:outputText value="#{param.parentIFrame}"/>';
    
    function SelectedGroup(groupId,groupName)
    {
    /*alert(groupId);
    alert(groupName);*/
     if(groupId=='--1--' && strNoneType>0)
        {
            groupId=strNoneID;
            if(strReturnNoneText==0)
                groupName='';
        }
    if(strparentFlag!="true")
            {
                try
                {
                    window.parent.document.getElementById(strFormID + ":" + strTextFieldID).value=groupName;
                    window.parent.document.getElementById(strFormID + ":" + strIDFieldID).value=groupId;
                    window.parent.document.getElementById(strFormID + ":" + strTextHidden).value=groupName;
                    if(strCallback.length>0 && Trim(strCallback).length>0)
                    {
                        var Temp='window.parent.' + strCallback + '();';
                        eval(Temp);        
                    }
                    removeIFrame(CurrentPickListId);
                }catch(e){}
            }
            else if(strparentFlag=="true")
            {
                try
                {
                    iframe=window.parent.document.getElementById(strparentIFrame);	
                    iframe.contentWindow.document.getElementById(strFormID + ":" + strTextFieldID).value=groupName;
                    iframe.contentWindow.document.getElementById(strFormID + ":" + strIDFieldID).value=groupId;
                    iframe.contentWindow.document.getElementById(strFormID + ":" + strTextHidden).value=groupName;
                    if(strCallback.length>0 && Trim(strCallback).length>0)
                    {
                        var Temp='iframe.contentWindow.' + strCallback + '();';
                        eval(Temp);        
                    }
                    removeIFrame(CurrentPickListId);
                }catch(e){}
            }
    
    }
    
    
    
    
 </Script>
        </head>
      <body class="PMbgcolorTransparent" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" onload="setPicklistFocus();addHandle(document.getElementById('GroupPickList:toolbar'), window);" onunload='closeWindows();closePicklistWindows(CurrentPickListId);return false;' >
    
            <h:panelGrid width="100%" cellpadding="0" cellspacing="0" border="0" styleClass="PMPageBackground" style="border-collapse:collapse;border:1px solid #bbb9b9;">
                <h:form id="GroupPickList">
                    <f:verbatim>
                        <input type="hidden" name="PM_UID" value="<%=pm_uid%>">
                    </f:verbatim>
                   <h:panelGrid columns="3" id="toolbar" cellpadding="0" cellspacing="0" style="border:0;border-bottom: solid 1px #989898;" columnClasses="PMWIDTH65,PMWIDTH5,PMWIDTH30RIGHT" width="100%">
                         <h:outputLabel value="#{PMGEN.GROUP_PICKLIST}" styleClass="EWLabel1B" style="width:100%;padding-#{PMGEN.LEFT}:3px;"/>
                        <h:panelGroup>
                            <h:inputHidden id="hid_FirstField" value="#{wfGroupList.m_strFirstField}"/>
                            <h:inputHidden id="hid_LastField" value="#{wfGroupList.m_strLastField}"/>
                            <h:inputHidden id="hid_FirstFieldIndex" value="#{wfGroupList.m_strFirstFieldIndex}"/>
                            <h:inputHidden id="hid_LastFieldIndex" value="#{wfGroupList.m_strLastFieldIndex}"/>
                            <h:inputHidden id="hid_Action" value="#{wfGroupList.m_iAction}"/>
                            <h:inputHidden id="hid_NoneType" value="#{wfGroupList.m_iNoneDisplay}"/>
                            <h:inputHidden id="hid_NoneID" value="#{wfGroupList.m_strNoneID}"/>
                            
                            <f:verbatim><input type=Hidden id="strFormFieldText" name="strFormFieldText" value='</f:verbatim><h:outputText value="#{param.strFormFieldText}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="strFormFieldID" name="strFormFieldID" value='</f:verbatim><h:outputText value="#{param.strFormFieldID}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="strFormID" name="strFormID" value='</f:verbatim><h:outputText value="#{param.strFormID}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="strFormFieldTextHidden" name="strFormFieldTextHidden" value='</f:verbatim><h:outputText value="#{param.strFormFieldTextHidden}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="ReturnNoneValue" name="ReturnNoneValue" value='</f:verbatim><h:outputText value="#{param.ReturnNoneValue}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="NoneType" name="NoneType" value='</f:verbatim><h:outputText value="#{param.NoneType}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="NoneValue" name="NoneValue" value='</f:verbatim><h:outputText value="#{param.NoneValue}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="CallBack" name="CallBack" value='</f:verbatim><h:outputText value="#{param.CallBack}"/><f:verbatim>'/></f:verbatim>
                             <f:verbatim><input type=Hidden id="parentFlag" name="parentFlag" value='</f:verbatim><h:outputText value="#{param.parentFlag}"/><f:verbatim>'/></f:verbatim>  
                            <f:verbatim><input type=Hidden id="parentIFrame" name="parentIFrame" value='</f:verbatim><h:outputText value="#{param.parentIFrame}"/><f:verbatim>'/></f:verbatim>  
                        </h:panelGroup>
                        <h:graphicImage title="#{PMGEN.BUTTON_CLOSE}" url="../omniflow/images/close_img.gif" onclick="removeIFrame(CurrentPickListId);" style="CURSOR: pointer;border:0;"/>   
                    </h:panelGrid>
                    <h:panelGrid  styleClass="PMbgcolorWhite" width="100%" cellpadding="0" cellspacing="0" border="0"  >
                       <h:panelGrid columns="2" border="0" cellspacing="" columnClasses="PMWIDTH35,PMWIDTH65" cellpadding="2" width="100%" >
                        <h:outputText style="width:100%"  value="#{PMGEN.SEARCH_ONFILTER}" styleClass="EWLabel1"/>
                        <h:panelGroup>
                            <h:panelGrid columns="2" border="0" cellspacing="2" columnClasses="PMWIDTH90,PMWIDTH10" cellpadding="0" width="100%">
                                <h:inputText  style="width:120px" styleClass="PMControlText" id="groupfilter" value="#{wfGroupList.m_strPrefix}" onkeydown="handlePickListEnter(event,'GroupPickList:cmdlink_Search');" />
                                <h:commandLink styleClass="EWEnabledLink" id="cmdlink_Search" action="#{wfGroupList.search}" >
                                    <h:graphicImage alt="#{PMGEN.TITLE_SEARCH}" style="border:0" url="../omniflow/#{PMGEN.Path}images/go.gif"> </h:graphicImage>
                                </h:commandLink>
                            </h:panelGrid>
                        </h:panelGroup>
                    </h:panelGrid>
                    <%//Displaying the error message if any%>
                    
                    <h:panelGrid columns="1" cellpadding="0" cellspacing="0" columnClasses="PMWIDTH100CENTER" width="100%"  styleClass="PMMessageBorder" >
                        <h:panelGroup rendered="#{wfGroupList.m_bError}">
                            <h:graphicImage  alt="" onclick="" style="border:0;vertical-align:middle" url="../omniflow/images/errorimage.gif"> </h:graphicImage>
                            <h:outputText value="." style="width:1%;visibility:hidden"/>
                            <h:outputText id="Error" value="#{wfGroupList.m_strErrorMessage}" styleClass="PMErrorMessage" />
                        </h:panelGroup>
                    </h:panelGrid>

                    <h:panelGrid columns="1" border="0" cellspacing="3" columnClasses="PMWIDTH100CENTERTOP" cellpadding="3" width="100%" rendered="#{!wfGroupList.m_bError}">
                    
                    <h:panelGroup>
                    
                        <f:verbatim>
                        <div id="listContainer" class="scrollTableContainerCustomPickList" style="border-style: inset; border-Width: thin">
                            </f:verbatim>
                            <h:panelGroup>
                            
                            <h:dataTable cellpadding="0" columnClasses="PMWIDTH1BORDER,PMWIDTH99BORDER" cellspacing="0" border="0" value="#{wfGroupList.m_vectGroupList}" var="group" width="100%">
                            
                            <h:column>
                            
                            <f:verbatim>
                                <div id="divImg" onmouseover="StyleRowLink(this);" onmouseout="StyleRowNormal(this);" onclick="SelectedGroup('</f:verbatim><h:outputText value="#{group.m_strGroupId}"/><f:verbatim>','</f:verbatim><h:outputText value="#{group.m_strGroupName}"/><f:verbatim>');">
                            </f:verbatim>
                            <h:panelGroup>
                            <h:graphicImage  value="../omniflow/images/group.gif" ></h:graphicImage>                                        
                                <h:outputText value="." style="visibility:hidden" styleClass="PMLabelBoldGreen"/>
                            </h:panelGroup>
                            
                            
                            <f:verbatim>
                        </div>
                    </f:verbatim>
                    </h:column>
                    
                    <h:column>
                    
                    <f:verbatim>
                        <div id="divTitle" onmouseover="StyleRowLink(this);" onmouseout="StyleRowNormal(this);" onclick="SelectedGroup('</f:verbatim><h:outputText value="#{group.m_strGroupId}"/><f:verbatim>','</f:verbatim><h:outputText value="#{group.m_strGroupName}"/><f:verbatim>');">
                    </f:verbatim>
                    
                    <h:outputLabel id="txtname" value="#{group.m_strGroupDisplayName}" styleClass="PMLabelBoldGreen" style="CURSOR: pointer;width:90%;" title="#{group.m_strGroupName}" ></h:outputLabel>
                    
                    <f:verbatim>
                        </div>
                    </f:verbatim>
                    </h:column>
                    
                    
                    </h:dataTable>
                    </h:panelGroup>
                    <f:verbatim>
                    </div>	        
                    </f:verbatim>
                    </h:panelGroup>
                    </h:panelGrid>
                    <h:panelGrid columns="1" border="0" cellspacing="3" columnClasses="PMWIDTH100" cellpadding="3" width="100%" rendered="#{wfGroupList.m_bError}">
                        <h:selectOneListbox size="9" styleClass="PMControlText" id="picklist11" style="width:100%" value="">
                        </h:selectOneListbox> 
                    </h:panelGrid>
                    <h:panelGrid columns="5" border="0" cellspacing="0"  columnClasses="PMWIDTH20,PMWIDTH20,PMWIDTH20,PMWIDTH20RIGHT,PMWIDTH20RIGHT" cellpadding="0" width="100%" rendered="#{!wfGroupList.m_bError}">
                        <h:outputText  style="width:100%" value="  "/>
                        <h:outputText  style="width:100%" value="  "/>
                        <h:outputText  style="width:100%" value="  "/>
                        <h:panelGroup>
                            <h:commandLink styleClass="EWEnabledLink" id="cmdlink_Previous" action="#{wfGroupList.previous}" tabindex="#{wfGroupList.m_strTabIndexForPrevious}"><%--for bug id 671--%>
                                <h:graphicImage  alt="#{PMGEN.BUTTON_PREVIOUS}" style="border:0" url="../omniflow/#{PMGEN.Path}images/prev.gif" rendered="#{wfGroupList.m_bEnablePreviousButton}"> </h:graphicImage>
                            </h:commandLink>
                            <h:graphicImage alt="#{PMGEN.BUTTON_PREVIOUS}" style="border:0" url="../omniflow/#{PMGEN.Path}images/prev_dis.gif" rendered="#{!wfGroupList.m_bEnablePreviousButton}"> </h:graphicImage>
                        </h:panelGroup>
                        <h:panelGroup>
                            <h:commandLink styleClass="EWEnabledLink" id="cmdlink_Next" action="#{wfGroupList.next}" tabindex="#{wfGroupList.m_strTabIndexForNext}"><%--for bug id 671--%>
                                <h:graphicImage  alt="#{PMGEN.BUTTON_NEXT}" style="border:0" url="../omniflow/#{PMGEN.Path}images/next.gif" rendered="#{wfGroupList.m_bEnableNextButton}"> </h:graphicImage>
                            </h:commandLink>
                            <h:graphicImage alt="#{PMGEN.BUTTON_NEXT}" style="border:0" url="../omniflow/#{PMGEN.Path}images/next_dis.gif" rendered="#{!wfGroupList.m_bEnableNextButton}"> </h:graphicImage>
                        </h:panelGroup>
                        
                    </h:panelGrid>
                 </h:panelGrid>   
                </h:form>
            </h:panelGrid>
        </body>
    </html>
</f:view>

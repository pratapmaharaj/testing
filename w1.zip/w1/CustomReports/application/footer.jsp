<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: footer.jsp
Author                          : Puneet Pahuja
Date written (DD/MM/YYYY)       : 10/Oct/2007
Description			: This file contains footer page of application
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
(DD/MM/YYYY)
23/08/2011      Anushree Jain		    Bug 27971 Security issue
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h" %>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f" %>
<%@ include file="/application/commonheader.process"%>
<f:loadBundle basename="pmgen" var="PMGEN"/>
<f:loadBundle basename="pmerrorcodes" var="PMERROR"/>
<h:panelGrid width="100%" cellpadding="0" cellspacing="0" columnClasses="PMWIDTH100RIGHT" columns="1" border="0">
    <h:panelGroup>
            <f:verbatim>
                <hr width="99%">
            </f:verbatim>
        </h:panelGroup>
        <h:panelGroup>
            <h:outputLabel value="#{PMGEN.NEWGEN_COPYRIGHT_TEXT}" styleClass="PMLabelGreySmall"/>
        </h:panelGroup>
</h:panelGrid>


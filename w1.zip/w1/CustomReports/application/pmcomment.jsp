<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group                           : Phoenix
Product / Project               : Omniflow Process Manager
Module                          : Web Client
File Name                       : pmiframesubheader.jsp
Author                          : Vijay Kumar
Date written (DD/MM/YYYY)       : 01/Feb/2010
Description                     : This file contains the general purpose comment page
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
(DD/MM/YYYY)
12123           Puneet Pahuja           Focus and Handle Enter 
23/08/2011      Anushree Jain		    Bug 27971 Security issue
09/10/2013      Sandeep Tonger          Bug 42333 - Comments should not be mandatory but optional
23/09/2015      Sri Prakash             Bug 56875 - New QueueType "T" is Introduced . No worksteps can be added to this type of queue. 
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--%>
<%@page contentType="text/html"%>
<%@page pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsf/core" prefix="f"%>
<%@taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@page import="java.util.*,com.newgen.wfdesktop.cabinet.WFCabinetList" %>
<%@ include file="/application/commonheader.process"%>
<f:view>
    <f:loadBundle basename="pmgen" var="PMGEN"/>
    <f:loadBundle basename="pmerrorcodes" var="PMERROR"/>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>
        </title>
        <script  src='../omniflow/<h:outputText value="#{PMGEN.Path}"/>scripts/constants.js'></script>
        <link href='../omniflow/<h:outputText value="#{PMGEN.Path}"/>css/docstyle.css' rel="stylesheet" type="text/css">
        <script  src="../omniflow/scripts/wfgeneral.js"></script>
        <script  src="../omniflow/scripts/toolbar.js"></script>
        <script  src="../omniflow/scripts/dragiframe.js"></script>
        <script>
        var CurrentPickListId="CommentWindow";
        function validatePage()
        {
            var strCallback=document.getElementById("CallBack").value;
            var strValidate=document.getElementById("Validate").value;
            var strcommentBoxId=document.getElementById("commentBoxId").value;
            var bParentValidation=true;
            var mandateComment = '<%= WFCabinetList.getConfValue("MandateComment", "Y", wfSession.getM_strCabName()) %>';            
            try
            {
                var Temp="";
                if(strValidate.length>0)
                 {
                     Temp='window.parent.' + strValidate + '();';
                     bParentValidation=eval(Temp);
                 }
                if(bParentValidation)
                {
                    var strComments=document.getElementById("CommentForm:comments").value;
                    if(Trim(strComments).length > 0)
                    {
                        window.parent.document.getElementById(strcommentBoxId).value=strComments;
                        Temp='window.parent.' + strCallback + '();';
                        eval(Temp);
                        removeIFrame(CurrentPickListId);
                    }else
                    {
                        if(mandateComment=='N')
                        {
                            window.parent.document.getElementById(strcommentBoxId).value="";
                            Temp='window.parent.' + strCallback + '();';
                            eval(Temp);
                            removeIFrame(CurrentPickListId);                             
                        }
                        else
                        {
                            alert(COMMENTS_MADATORY);
                            document.getElementById("CommentForm:comments").focus();
                            return false;
                        }
                        
                    }
                }else
                {
                    removeIFrame(CurrentPickListId);;
                }

            }catch(ex)
            {
            }
            return true;
        }

        function onloadComments()
        {
            document.getElementById("CommentForm:comments").focus();
        }

    function onCommentKeyPress()
    {
        var browser=navigator.appName;
        if(browser=="Netscape")
        { 
            e=window.event;
            if(e.which == 13)
            {

                try
                {
                    document.getElementById('CommentForm:cmdOk').focus();
                }
                catch(e){
                }

            }
        }

        else
        {
            e=window.event;
            if(e.keyCode == 13)
            {
                try
                {
                    document.getElementById('CommentForm:cmdOk').focus();
                }
                catch(e){
                }
            }

        }
    }

        </script>
    </head>
    <body class="PMbgcolorTransparent" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" onload="addHandle(document.getElementById('CommentForm:toolbar'), window);onloadComments();" onunload='closeWindows();closePicklistWindows(CurrentPickListId);return false;'>
        <h:panelGrid width="100%" cellpadding="0" cellspacing="0" border="0" styleClass="PMPageBackground" style="border-collapse:collapse;border:1px solid #bbb9b9;">
            <h:form id="CommentForm">
                <f:verbatim>
                    <input type="hidden" name="PM_UID" value="<%=pm_uid%>">
                </f:verbatim>
                <h:panelGrid columns="3" id="toolbar" cellpadding="0" cellspacing="0" style="border:0;border-bottom: solid 1px #989898;" columnClasses="PMWIDTH65,PMWIDTH5,PMWIDTH30RIGHT" width="100%">
                    <h:outputLabel value="#{PMGEN.TITLE_COMMENTS}" styleClass="EWLabel1B" style="width:100%;padding-left:3px;"/>
                    <h:panelGroup>
                        <f:verbatim><input type=Hidden id="CallBack" name="CallBack" value='</f:verbatim><h:outputText value="#{param.CallBack}"/><f:verbatim>'/></f:verbatim>
                        <f:verbatim><input type=Hidden id="Validate" name="Validate" value='</f:verbatim><h:outputText value="#{param.Validate}"/><f:verbatim>'/></f:verbatim>
                        <f:verbatim><input type=Hidden id="commentBoxId" name="commentBoxId" value='</f:verbatim><h:outputText value="#{param.commentBoxId}"/><f:verbatim>'/></f:verbatim>
                    </h:panelGroup>
                    <h:graphicImage title="#{PMGEN.BUTTON_CLOSE}" url="../omniflow/images/close_img.gif" onclick="removeIFrame(CurrentPickListId);" style="CURSOR: pointer;border:0;"/>
                </h:panelGrid>
                <h:panelGrid styleClass="PMbgcolorWhite" width="100%" cellpadding="0" cellspacing="0" border="0"  >
                    <h:panelGroup>
                        <f:verbatim>
                         <br>
                        </f:verbatim>
                        <h:panelGrid columns="3" cellpadding="0" cellspacing="5" columnClasses="PMWIDTH10,PMWIDTH80,PMWIDTH10" width="100%">
                            <h:outputText style="width:100%"  value="  " styleClass="PMControlText"/>
                            <h:inputTextarea rows="4"  id="comments" value="" onkeydown="onCommentKeyPress(event);" style="width:100%">
                            </h:inputTextarea>
                            <h:outputText style="width:100%"  value="  " styleClass="PMControlText"/>
                        </h:panelGrid>
                        <h:panelGrid columns="4" border="0" cellspacing="5" columnClasses="PMWIDTH40,PMWIDTH10,PMWIDTH10,PMWIDTH40" cellpadding="0" width="100%" rendered="true">
                            <h:outputText style="width:100%"  value="  " styleClass="PMControlText"/>
                            <h:commandButton style="border:0;cursor:pointer;" id="cmdOk"  title="#{PMGEN.BUTTON_OK}"  image="../omniflow/#{PMGEN.Path}images/ok.gif" onclick="validatePage();return false;"/>
                            <h:commandButton style="border:0;cursor:pointer;" id="cmdCancel"  title="#{PMGEN.BUTTON_CANCEL}"  image="../omniflow/#{PMGEN.Path}images/cancel.gif" onclick="removeIFrame(CurrentPickListId);return false;"/>
                            <h:outputText style="width:100%"  value="  " styleClass="PMControlText"/>
                        </h:panelGrid>
                    </h:panelGroup>
                </h:panelGrid>
            </h:form>
        </h:panelGrid>
    </f:view>
</body>
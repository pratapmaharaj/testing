<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: feedbackform.jsp
Author                          : Vijay kumar
Date written (DD/MM/YYYY)       : 11/Jan/2008
Description			: Feedback Form 
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
(DD/MM/YYYY)
23/08/2011      Anushree Jain		    Bug 27971 Security issue
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--%>
<%@page contentType="text/html"%>
<%@page pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsf/core" prefix="f"%>
<%@taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@page import="com.newgen.wfdesktop.session.*,java.util.*" %>
<%@ include file="/application/commonheader.process"%>
<f:view>
<f:loadBundle basename="pmgen" var="PMGEN"/>
<f:loadBundle basename="pmerrorcodes" var="PMERROR"/>
<html dir='<h:outputText value="#{PMGEN.HTML_DIR}"/>'>
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>           
        <h:outputText value="#{PMGEN.OMNIFLOW_DESC_TEXT_1}[#{PMGEN.PRODUCT_FEEDBACK_FORM}]" />
    </title>
    <link href='../omniflow/<h:outputText value="#{PMGEN.Path}"/>css/docstyle.css' rel="stylesheet" type="text/css">
    <link href='../omniflow/<h:outputText value="#{PMGEN.Path}"/>css/scrolling_table.css' rel="stylesheet" type="text/css">
    <Script LANGUAGE="Javascript">
        function update_message_body ()
    {
            document . proxy_form . message_body . value =
                    document.getElementById("lblProductFeedback").value+"\n\n"
            +document.getElementById("lblOrganization").innerHTML+": \t\t"+document.getElementById("Organization").value+"\n"
            +	"\n"
            +document.getElementById("lblName").innerHTML+": \t\t"+document.getElementById("Name").value+"\n"
             +	"\n"
            +document.getElementById("lblDesignation").innerHTML+": \t\t"+document.getElementById("Designation").value+"\n"
             +	"\n"
            +document.getElementById("lblEmail").innerHTML+": \t\t"+document.getElementById("Email").value+"\n"
             +	"\n"
            +document.getElementById("lblPhoneNo").innerHTML+":\t\t"+document.getElementById("PhoneNo").value+"\n"
            +	"\n"
            
            +document.getElementById("lblQ1").innerHTML+":\t\t"
            +selectedCheckBoxValue("SatisfactionLevel_1_1")+"\t\t,"+selectedCheckBoxValueImpl("SatisfactionImp_1_1")+"\n"
            +	"\n"
            
            +document.getElementById("lblQ2").innerHTML+":\t\t"
            +selectedCheckBoxValue("SatisfactionLevel_2_1")+"\t\t,"+selectedCheckBoxValueImpl("SatisfactionImp_2_1")+"\n"
            +	"\n"
            
            +document.getElementById("lblQ3").innerHTML+":\t\t"
            +selectedCheckBoxValue("SatisfactionLevel_3_1")+"\t\t,"+selectedCheckBoxValueImpl("SatisfactionImp_3_1")+"\n"
            +	"\n"
            
            +document.getElementById("lblQ4").innerHTML+":\t\t"
            +selectedCheckBoxValue("SatisfactionLevel_4_1")+"\t\t,"+selectedCheckBoxValueImpl("SatisfactionImp_4_1")+"\n"
            +	"\n"
            
            +document.getElementById("lblQ5").innerHTML+":\t\t"
            +selectedCheckBoxValue("SatisfactionLevel_5_1")+"\t\t,"+selectedCheckBoxValueImpl("SatisfactionImp_5_1")+"\n"
            +	"\n"
            
        /*    +document.getElementById("lblQ6").innerHTML+":\t\t"
            +selectedCheckBoxValue("SatisfactionLevel_6_1")+"\t\t,"+selectedCheckBoxValueImpl("SatisfactionImp_6_1")+"\n"
            +	"\n"    */
            
            +document.getElementById("lblQ11").innerHTML+":\t\t\n"
            +document.getElementById("NotSatComments").value+"\n"
            +	"\n"
            
            +document.getElementById("lblQ12").innerHTML+":\t\t\n"
            +document.getElementById("anySuggestions").value+"\n"
            +	"\n"
            
            +document.getElementById("lblQ13").innerHTML+":\t\t\n"
            +document.getElementById("remarks").value+"\n"
            +	"\n"
            
            return true;
    }
    
    
    function selectCheckBox(ref)
    {
        if(ref.checked == true)
         {            
            var arr=ref.id.split("_");                      
            var maxelements = 5;            
            var skip = arr[2];
                        
            for (var count=1; count < maxelements+1 ; count++ )
             {
             try
                {
                if(skip != count)
                document.getElementById(arr[0]+"_"+arr[1] +"_"+count).checked=false;
                }catch(e){}
             }
        }
    
    }

    function selectedCheckBoxValueImpl(id)
    {
       ref=   document.getElementById(id);       
       var arr=ref.id.split("_");                      
       var maxelements = 4;            
       var skip = arr[2];
                        
        for (var count=1; count < maxelements+1 ; count++ )
         {
         try
            {
            if(document.getElementById(arr[0]+"_"+arr[1] +"_"+count).checked)
                {
                if(count==1)
                    return document.getElementById("lblExtremelyImportant").innerHTML;
                else if(count==2)
                  return document.getElementById("lblVeryImportant").innerHTML;
                 else if(count==3)
                return document.getElementById("lblSomewhatImportant").innerHTML;
                 else if(count==4)
                return document.getElementById("lblNotAtAllImportant").innerHTML;

             }
            }catch(e){}
         }
         

         return "";
    }
    
    function selectedCheckBoxValue(id)
    {
       ref=   document.getElementById(id);       
       var arr=ref.id.split("_");                      
       var maxelements = 5;            
       var skip = arr[2];
                        
        for (var count=1; count < maxelements+1 ; count++ )
         {
         try
            {
            if(document.getElementById(arr[0]+"_"+arr[1] +"_"+count).checked)
            {
                if(count==1)
                return document.getElementById("lblDelighted").innerHTML;
                else if(count==2)
                return document.getElementById("lblMoreThanSatisfied").innerHTML;
                 else if(count==3)
                return document.getElementById("lblSatisfied").innerHTML;
                 else if(count==4)
                return document.getElementById("lblLessThanSatisfied").innerHTML;
                 else if(count==5)
                return document.getElementById("lblDisgusted").innerHTML;
             }

            }catch(e){}
         }
         

         return "";
    }
    
    </Script>
</head>
<body topmargin="0" leftmargin="0" marginheight="0" marginwidth="0"  style="overflow:auto">
<%
Map bundleValues = null;
bundleValues = (Map)request.getAttribute("PMGEN");
String strHeading="";
String strHelpURL="";
    strHeading=(String)bundleValues.get("PRODUCT_FEEDBACK_FORM");


%>
<jsp:include page="../application/pmheader.jsp" >
    <jsp:param name="Heading" value="<%=strHeading%>"/>
</jsp:include>

<h:panelGrid width="100%" cellpadding="0" cellspacing="5" border="0" styleClass="PMPageBackground">
       
<f:verbatim>
    <BR>
</f:verbatim>

<h:panelGrid columns="2" border="0" cellspacing="0" columnClasses="PMWIDTH20,PMWIDTH80" cellpadding="0" width="100%" >
    <h:outputText id="lblOrganization" value="#{PMGEN.ORGANIZATION}" styleClass="EWLabel1"/>
    <h:inputText style="width:100%" styleClass="PMControlText" id="Organization" value=""/>
    <h:outputText id="lblName" value="#{PMGEN.NAME}" styleClass="EWLabel1"/>
    <h:inputText style="width:100%" styleClass="PMControlText" id="Name" value=""/>
    <h:outputText id="lblDesignation" value="#{PMGEN.DESIGNATION}" styleClass="EWLabel1"/>
    <h:inputText style="width:100%" styleClass="PMControlText" id="Designation" value=""/>
    <h:outputText id="lblEmail" value="#{PMGEN.EMAIL}" styleClass="EWLabel1"/>
    <h:inputText style="width:100%" styleClass="PMControlText" id="Email" value=""/>
    <h:outputText id="lblPhoneNo" value="#{PMGEN.PHONE_NO_MOBILE_NO}" styleClass="EWLabel1"/>
    <h:inputText style="width:100%" styleClass="PMControlText" id="PhoneNo" value=""/>
</h:panelGrid>
 <h:panelGrid columns="1" columnClasses="PMWIDTH100" cellpadding="3" cellspacing="3" border="0" width="100%">
   <h:outputText  style="align:justify" value="#{PMGEN.FEEDBACK_FORM_KINDALY_PUT_DESC_TEXT}"  rendered="true" styleClass="PMLabel"/> 
</h:panelGrid>

<h:panelGrid columns="4" border="1" style="border-collapse:collapse;border:1px solid #bbb9b9;" cellspacing="3" columnClasses="PMWIDTH10TOP,PMWIDTH30TOP,PMWIDTH30TOP,PMWIDTH30TOP" cellpadding="0" width="100%" >
    <h:outputText value="#{PMGEN.S_NO}" styleClass="EWLabel1"/>
    <h:outputText value="#{PMGEN.ATTRIBUTES}" styleClass="EWLabel1"/>
    <h:panelGrid columns="1" columnClasses="PMWIDTH100" cellpadding="" cellspacing="" border="0" width="100%">
        <h:outputText value="#{PMGEN.FEEDBACK_FORM_PLEASE_INDICATE_DESC_TEXT}" styleClass="EWLabel1"/>
        <h:panelGrid columns="5" columnClasses="PMWIDTH20,PMWIDTH20,PMWIDTH20,PMWIDTH20,PMWIDTH20" cellpadding="" cellspacing="2" border="1" style="border-collapse:collapse;border:1px solid #bbb9b9;" width="100%">
         <h:outputText id="lblDelighted" value="#{PMGEN.DELIGHTED}" styleClass="EWLabel1"/>
         <h:outputText id="lblMoreThanSatisfied" value="#{PMGEN.MORE_THEN_SATISFIED}" styleClass="EWLabel1"/>
         <h:outputText id="lblSatisfied" value="#{PMGEN.SATISFIED}" styleClass="EWLabel1"/>
         <h:outputText id="lblLessThanSatisfied" value="#{PMGEN.LESS_THAN_SATISFIED}" styleClass="EWLabel1"/>
         <h:outputText id="lblDisgusted" value="#{PMGEN.DISGUSTED}" styleClass="EWLabel1"/>
        </h:panelGrid>
    </h:panelGrid>
    <h:panelGrid columns="1" columnClasses="PMWIDTH100" cellpadding="" cellspacing="" border="0" width="100%">
        <h:outputText value="#{PMGEN.FEEDBACK_FORM_PLAESE_INDICATE_DESC_TEXT_2}" styleClass="EWLabel1"/>
        <h:panelGrid columns="4" columnClasses="PMWIDTH25,PMWIDTH25,PMWIDTH25,PMWIDTH25" cellpadding="" cellspacing="2" border="1" style="border-collapse:collapse;border:1px solid #bbb9b9;" width="100%">
            <h:outputText id="lblExtremelyImportant" value="#{PMGEN.EXTREMELY_IMPORTANT}" styleClass="EWLabel1"/>
            <h:outputText id="lblVeryImportant" value="#{PMGEN.VERY_IMPORTANT}" styleClass="EWLabel1"/>
            <h:outputText id="lblSomewhatImportant"value="#{PMGEN.SOMEWHAT_IMPORTANT}" styleClass="EWLabel1"/>
            <h:outputText id="lblNotAtAllImportant" value="#{PMGEN.NOT_AT_ALL_IMPORTANT}" styleClass="EWLabel1"/>
        </h:panelGrid>
    </h:panelGrid>
     
   
    <h:outputText value="#{PMGEN.ONE_BRACE}" styleClass="EWLabel1"/>
    <h:outputText id="lblQ1" value="#{PMGEN.FEEDBACK_FORM_QUESTION_1}" styleClass="EWLabel1"/>
    <h:panelGrid columns="5" columnClasses="PMWIDTH20,PMWIDTH20,PMWIDTH20,PMWIDTH20,PMWIDTH20" style="border-collapse:collapse;border:1px solid #bbb9b9;" cellpadding="" cellspacing="" border="1" width="100%">
        <h:selectBooleanCheckbox value="Delighted"   id="SatisfactionLevel_1_1"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="More than satisfied"   id="SatisfactionLevel_1_2" onclick="selectCheckBox(this);" style="width:100%"/>
        <h:selectBooleanCheckbox value="Satisfied"  id="SatisfactionLevel_1_3" style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Less than satisfied"   id="SatisfactionLevel_1_4"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Disgusted"    id="SatisfactionLevel_1_5" style="width:100%" onclick="selectCheckBox(this);"/>
        </h:panelGrid>
    <h:panelGrid columns="4" columnClasses="PMWIDTH25,PMWIDTH25,PMWIDTH25,PMWIDTH25" style="border-collapse:collapse;border:1px solid #bbb9b9;" cellpadding="" cellspacing="" border="1" width="100%">
        <h:selectBooleanCheckbox value="Extremely important"   id="SatisfactionImp_1_1"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Very important"   id="SatisfactionImp_1_2"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Somewhat important"   id="SatisfactionImp_1_3"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Not at all important"   id="SatisfactionImp_1_4"  style="width:100%" onclick="selectCheckBox(this);"/>
     </h:panelGrid>
     
     
      <h:outputText value="#{PMGEN.TWO_BRACE}" styleClass="EWLabel1"/>
    <h:outputText id="lblQ2" value="#{PMGEN.FEEDBACK_FORM_QUESTION_2}" styleClass="EWLabel1"/>
    <h:panelGrid columns="5" columnClasses="PMWIDTH20,PMWIDTH20,PMWIDTH20,PMWIDTH20,PMWIDTH20" style="border-collapse:collapse;border:1px solid #bbb9b9;" cellpadding="" cellspacing="" border="1" width="100%">
        <h:selectBooleanCheckbox value="Delighted"   id="SatisfactionLevel_2_1"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="More than satisfied"   id="SatisfactionLevel_2_2"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Satisfied"  id="SatisfactionLevel_2_3" style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Less than satisfied"   id="SatisfactionLevel_2_4"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Disgusted"    id="SatisfactionLevel_2_5" style="width:100%" onclick="selectCheckBox(this);"/>
        </h:panelGrid>
    <h:panelGrid columns="4" columnClasses="PMWIDTH25,PMWIDTH25,PMWIDTH25,PMWIDTH25" cellpadding="" style="border-collapse:collapse;border:1px solid #bbb9b9;" cellspacing="" border="1" width="100%">
        <h:selectBooleanCheckbox value="Extremely important"   id="SatisfactionImp_2_1"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Very important"   id="SatisfactionImp_2_2"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Somewhat important"   id="SatisfactionImp_2_3"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Not at all important"   id="SatisfactionImp_2_4"  style="width:100%" onclick="selectCheckBox(this);"/>
     </h:panelGrid>
     
      <h:outputText  value="#{PMGEN.THREE_BRACE}" styleClass="EWLabel1"/>
    <h:outputText id="lblQ3" value="#{PMGEN.FEEDBACK_FORM_QUESTION_3}" styleClass="EWLabel1"/>
    <h:panelGrid columns="5" columnClasses="PMWIDTH20,PMWIDTH20,PMWIDTH20,PMWIDTH20,PMWIDTH20" style="border-collapse:collapse;border:1px solid #bbb9b9;" cellpadding="" cellspacing="" border="1" width="100%">
        <h:selectBooleanCheckbox value="Delighted"   id="SatisfactionLevel_3_1"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="More than satisfied"   id="SatisfactionLevel_3_2"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Satisfied"  id="SatisfactionLevel_3_3" style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Less than satisfied"   id="SatisfactionLevel_3_4"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Disgusted"    id="SatisfactionLevel_3_5" style="width:100%" onclick="selectCheckBox(this);"/>
        </h:panelGrid>
    <h:panelGrid columns="4" columnClasses="PMWIDTH25,PMWIDTH25,PMWIDTH25,PMWIDTH25" style="border-collapse:collapse;border:1px solid #bbb9b9;" cellpadding="" cellspacing="" border="1" width="100%">
        <h:selectBooleanCheckbox value="Extremely important"   id="SatisfactionImp_3_1"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Very important"   id="SatisfactionImp_3_2"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Somewhat important"   id="SatisfactionImp_3_3"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Not at all important"   id="SatisfactionImp_3_4"  style="width:100%" onclick="selectCheckBox(this);"/>
     </h:panelGrid>
     
      <h:outputText value="#{PMGEN.FOUR_BRACE}" styleClass="EWLabel1"/>
    <h:outputText id="lblQ4" value="#{PMGEN.FEEDBACK_FORM_QUESTION_4}" styleClass="EWLabel1"/>
    <h:panelGrid columns="5" columnClasses="PMWIDTH20,PMWIDTH20,PMWIDTH20,PMWIDTH20,PMWIDTH20" cellpadding="" cellspacing="" style="border-collapse:collapse;border:1px solid #bbb9b9;" border="1" width="100%">
        <h:selectBooleanCheckbox value="Delighted"   id="SatisfactionLevel_4_1"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="More than satisfied"   id="SatisfactionLevel_4_2"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Satisfied"  id="SatisfactionLevel_4_3" style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Less than satisfied"   id="SatisfactionLevel_4_4"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Disgusted"    id="SatisfactionLevel_4_5" style="width:100%" onclick="selectCheckBox(this);"/>
        </h:panelGrid>
    <h:panelGrid columns="4" columnClasses="PMWIDTH25,PMWIDTH25,PMWIDTH25,PMWIDTH25" cellpadding="" cellspacing="" style="border-collapse:collapse;border:1px solid #bbb9b9;" border="1" width="100%">
        <h:selectBooleanCheckbox value="Extremely important"   id="SatisfactionImp_4_1"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Very important"   id="SatisfactionImp_4_2"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Somewhat important"   id="SatisfactionImp_4_3"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Not at all important"   id="SatisfactionImp_4_4"  style="width:100%" onclick="selectCheckBox(this);"/>
     </h:panelGrid>
     
     
       <h:outputText value="#{PMGEN.FIVE_BRACE}" styleClass="EWLabel1"/>
    <h:outputText id="lblQ5" value="#{PMGEN.FEEDBACK_FORM_QUESTION_5}" styleClass="EWLabel1"/>
    <h:panelGrid columns="5" columnClasses="PMWIDTH20,PMWIDTH20,PMWIDTH20,PMWIDTH20,PMWIDTH20" cellpadding="" style="border-collapse:collapse;border:1px solid #bbb9b9;" cellspacing="" border="1" width="100%">
        <h:selectBooleanCheckbox value="Delighted"   id="SatisfactionLevel_5_1"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="More than satisfied"   id="SatisfactionLevel_5_2"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Satisfied"  id="SatisfactionLevel_5_3" style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Less than satisfied"   id="SatisfactionLevel_5_4"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Disgusted"    id="SatisfactionLevel_5_5" style="width:100%" onclick="selectCheckBox(this);"/>
        </h:panelGrid>
    <h:panelGrid columns="4" columnClasses="PMWIDTH25,PMWIDTH25,PMWIDTH25,PMWIDTH25" style="border-collapse:collapse;border:1px solid #bbb9b9;" cellpadding="" cellspacing="" border="1" width="100%">
        <h:selectBooleanCheckbox value="Extremely important"   id="SatisfactionImp_5_1"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Very important"   id="SatisfactionImp_5_2"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Somewhat important"   id="SatisfactionImp_5_3"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Not at all important"   id="SatisfactionImp_5_4"  style="width:100%" onclick="selectCheckBox(this);"/>
     </h:panelGrid>
     
     
   <%--     <h:outputText value="#{PMGEN.SIX_BRACE}" styleClass="EWLabel1"/>
    <h:outputText id="lblQ6" value="#{PMGEN.FEEDBACK_FORM_QUESTION_6}" styleClass="EWLabel1"/>
    <h:panelGrid columns="5" columnClasses="PMWIDTH20,PMWIDTH20,PMWIDTH20,PMWIDTH20,PMWIDTH20" style="border-collapse:collapse;border:1px solid #bbb9b9;" cellpadding="" cellspacing="" border="1" width="100%">
        <h:selectBooleanCheckbox value="Delighted"   id="SatisfactionLevel_6_1"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="More than satisfied"   id="SatisfactionLevel_6_2"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Satisfied"  id="SatisfactionLevel_6_3" style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Less than satisfied"   id="SatisfactionLevel_6_4"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Disgusted"    id="SatisfactionLevel_6_5" style="width:100%" onclick="selectCheckBox(this);"/>
        </h:panelGrid>
    <h:panelGrid columns="4" columnClasses="PMWIDTH25,PMWIDTH25,PMWIDTH25,PMWIDTH25" cellpadding="" style="border-collapse:collapse;border:1px solid #bbb9b9;" cellspacing="" border="1" width="100%">
        <h:selectBooleanCheckbox value="Extremely important"   id="SatisfactionImp_6_1"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Very important"   id="SatisfactionImp_6_2"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Somewhat important"   id="SatisfactionImp_6_3"  style="width:100%" onclick="selectCheckBox(this);"/>
        <h:selectBooleanCheckbox value="Not at all important"   id="SatisfactionImp_6_4"  style="width:100%" onclick="selectCheckBox(this);"/>
     </h:panelGrid> --%>

   
</h:panelGrid>

<h:inputHidden  id="lblProductFeedback" value="#{PMGEN.PRODUCT_FEEDBACK_FORM}" />

<h:panelGrid columns="1" border="0" cellspacing="0" columnClasses="PMWIDTH100" cellpadding="0" width="100%" >
   <h:outputText id="lblQ11" value="#{PMGEN.FEEDBACK_FORM__DESCRIBATION_ELAROBATE}" styleClass="EWLabel1"/> 
    <h:inputTextarea cols="3" id="NotSatComments" style="width:100%" >  
    </h:inputTextarea>
</h:panelGrid>

<h:panelGrid columns="1" border="0" cellspacing="0" columnClasses="PMWIDTH100" cellpadding="0" width="100%" >
   <h:outputText id="lblQ12" value="#{PMGEN.FEEDBACK_FORM_SUGGESATION}" styleClass="EWLabel1"/> 
    <h:inputTextarea cols="3" id="anySuggestions" style="width:100%">  
    </h:inputTextarea>
</h:panelGrid>

<h:panelGrid columns="1" border="0" cellspacing="0" columnClasses="PMWIDTH100" cellpadding="0" width="100%" >
   <h:outputText id="lblQ13" value="#{PMGEN.FEEDBACK_FORM_REMARKS}" styleClass="EWLabel1"/> 
    <h:inputTextarea cols="3" id="remarks" style="width:100%">  
    </h:inputTextarea>
</h:panelGrid>

<%// Displaying the Generate button%>
<h:outputLabel value="#{PMGEN.FEEDBACK_FORM_DISCLAIMER}" styleClass="PMLabelGreySmall"/>
</h:panelGrid>
    <f:verbatim>
      <form name="proxy_form" method  ="post" enctype ="text/plain" action  ="mailto:csshead@newgen.co.in?subject=Product Feedback Form" onSubmit="return update_message_body();">
        <input type=hidden name="message_body">
       </f:verbatim> 
        <h:panelGrid columns="6" border="0" cellspacing="3" columnClasses="PMWIDTH20,PMWIDTH20,PMWIDTH10,PMWIDTH10,PMWIDTH20,PMWIDTH20" cellpadding="3" width="100%" >
    <h:outputText style="width:100%"  value="  " styleClass="PMControlText"/>
    <h:outputText style="width:100%"  value="  " styleClass="PMControlText"/>
    <h:commandButton styleClass="EWButton" id="cmdSet" image="../omniflow/#{PMGEN.Path}images/ok.gif" title="#{PMGEN.BUTTON_OK}" />
    <h:commandButton type="button" styleClass="EWButton" id="cmdCloseWindow" image="../omniflow/#{PMGEN.Path}images/cancel.gif" title="#{PMGEN.BUTTON_CANCEL}" onclick="self.close();return false;"/>
    <h:outputText style="width:100%"  value="  " styleClass="PMControlText"/>
    <h:outputText style="width:100%"  value="  " styleClass="PMControlText"/>
    
</h:panelGrid>
<f:verbatim>
    </form>
    </f:verbatim>
</body>
</html>
</f:view>

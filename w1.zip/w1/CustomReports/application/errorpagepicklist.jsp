<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: errorpagepicklist.jsp
Author                          : Ajith Jacob
Date written (DD/MM/YYYY)       : 10/Oct/2007
Description			: This file contains the error page for the picklist window
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
(DD/MM/YYYY)
23/08/2011      Anushree Jain		    Bug 27971 Security issue
10/02/2017      Jaseem Ansari               Bug 67133 - Security Issue: Fix all alerts in Process Manager reported by acunetix.
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--%>
<%@ page import="java.io.*" isErrorPage="true"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h" %>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f" %>
<%@ page contentType="text/html; charset=UTF-8" %>
<%@ page import="java.util.*" %>
<%@ include file="/application/commonheader.process"%>
<f:view>
<f:loadBundle basename="pmgen" var="PMGEN"/>
<f:loadBundle basename="pmerrorcodes" var="PMERROR"/>
<%

  Map bundleValues = null;
  bundleValues = (Map)request.getAttribute("PMERROR");
  String message="";
  String strHeading="";
  
  if(request.getParameter("HeadingID")!=null)
    strHeading=(String)bundleValues.get(request.getParameter("HeadingID"));

  if(request.getParameter("msg")!=null)
    message=request.getParameter("msg");
  
  if(request.getParameter("msgID")!=null)
    message=(String)bundleValues.get(request.getParameter("msgID"));
  
  if(message!=null && message.indexOf("?")>-1)
      message="Invalid request is made";
  
 // System.out.println("message is "+message);
%>
<html dir='<h:outputText value="#{PMGEN.HTML_DIR}"/>'>
<head>
<title>
<h:outputText value="#{PMGEN.OMNIFLOW_DESC_TEXT_1}[#{PMGEN.TITLE_FOR_ERRORPAGE}]" />
</title>
<link href='../omniflow/<h:outputText value="#{PMGEN.Path}"/>css/docstyle.css' rel="stylesheet" type="text/css">
<script  src="../omniflow/scripts/toolbar.js"></script>
<script  src="../omniflow/scripts/wfgeneral.js"></script>
<Script LANGUAGE="Javascript">
    var allWindows = new Array();
    var localizedPath='<h:outputText value="#{PMGEN.Path}"/>';
    function closewin()
    {

        var iframes = parent.document.getElementsByTagName('iframe');
              
            for( var ind = 0; iframes[ind]; ind++ ) {
       
                 var thewindow = iframes[ind].contentWindow ? iframes[ind].contentWindow : iframes[ind].window;
       
                if( thewindow == window ) {
       
                    //this is the current iframe
                    removeIFrameByRef(iframes[ind])
                     //iframes[ind].parentNode.parentNode.removeChild(iframes[ind].parentNode);
                    //and now the cell has been deleted
                }
            }
       
    }
</Script>
</head>
<body topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" onunload='closeWindows();return false;'>
<h:panelGrid width="100%" cellpadding="0" cellspacing="0" border="0" styleClass="PMPageBackground" style="border-collapse:collapse;border:1px solid #bbb9b9;">
<h:panelGrid columns="3" id="toolbar" cellpadding="0" cellspacing="0" style="border:0;border-bottom: solid 1px #989898;" columnClasses="PMWIDTH65,PMWIDTH5,PMWIDTH30RIGHT" width="100%">
    <h:outputLabel value="#{PMGEN.TITLE_FOR_ERRORPAGE}" styleClass="EWLabel1B" style="width:100%;padding-#{PMGEN.LEFT}:3px;"/>
    <h:panelGroup>
        
    </h:panelGroup>
    <h:graphicImage title="#{PMGEN.BUTTON_CLOSE}" url="../omniflow/images/close_img.gif" onclick="closewin();" style="CURSOR: pointer;border:0;"/>   
</h:panelGrid>

        <h:panelGrid width="100%" cellpadding="0" cellspacing="0" border="0">
                <h:panelGroup>
                    <f:verbatim>
                        <table width="100%" height="60%">
                        <tr>
                        <td align=center width="100%">
                    </f:verbatim>
                    <h:outputText value="" styleClass="PMErrorMessage" style="width:100%"/>
                    <f:verbatim>
                </td>
            </tr>
            <tr>
                <td align=center width="100%">
                    
                    <table>
                        <tr>
                            <td align=center width="100%">
                            </td>
                        </tr>
                        <tr>
                            <td align=center width="100%">
                                <span class="PMErrorMessage"><%=message%></span>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td align=center width="100%">
                    
                </td>
            </tr>
            <tr>
                <td align=center width="100%">
                    
                </td>
            </tr>
        </table>
 	
    </f:verbatim>
    </h:panelGroup>
    </h:panelGrid>
    <f:verbatim><br><br><br><br><br><br></f:verbatim>
</h:panelGrid>	
</body>

</html>

</f:view>
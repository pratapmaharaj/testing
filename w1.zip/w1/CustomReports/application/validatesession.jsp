<%-- 
    Document   : validatesession
    Created on : Sep 6, 2013, 10:19:06 AM
    Author     : jaseem.ansari
    Bug 42035       10/09/2013              Jaseem Ansari           Security related issue with omnidocs and omniflow integration.
    Bug 42256       04/11/2013              Jaseem Ansari           Not able to login in omnidocs from webdesktop and processmanager in WAS
--%>
<%
    String jSessionId = "";
            Cookie[] cookies = request.getCookies();
            if (cookies != null) {
                for (int i = 0; i < cookies.length; i++) {
                    if ("JSESSIONID".equalsIgnoreCase(cookies[i].getName())) {
                        jSessionId = cookies[i].getValue();
                        break;
                    }

                }
            }
            if (jSessionId.equalsIgnoreCase(request.getParameter("jsessionID"))) {
                out.println("0");
            } else {
                out.println("1");
            }
%> 

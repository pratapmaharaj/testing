<!--Added by Sweejo for GMAC Migration-->
<jsp:useBean id="wfSession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ include file="customized.process" %>
<%@ page import="java.text.*"%>
<%@ page import="java.lang.String.*"%>
<%@ page import="java.lang.Object"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="com.newgen.wfdesktop.util.*" %>
<%@ page import="ISPack.ISUtil.*,ISPack.*,java.util.*,java.io.*,Jdts.DataObject.JPDBInteger, Jdts.DataObject.JPDBISAddress,Jdts.DataObject.*,Jdts.*, java.net.*,com.newgen.wfdesktop.util.*, com.newgen.wfdesktop.session.*,com.newgen.wfdesktop.xmlapi.*, com.newgen.wfdesktop.dmsinterface.*,java.awt.*"%>

<%
	String sCabname=null;
	String sSessionId = null;
	String sUserName= null;
	String sJtsIp = null;
	String sStr_CabType = null;
	int iJtsPort = 0;
	String sStr_ServerType = null;
	int sUserIndex=0;
	boolean	 bGmacReport=false;

	String sInputXML ="";
	String sOutputXML="";

	try
	{
		sJtsIp = wfSession.getM_objCabinet().getM_strServerIP();
		sCabname = wfSession.getM_strCabName();
		sSessionId = wfSession.getM_strSessionID();
		sUserName = wfSession.getM_strUserName();
		sUserIndex=wfSession.getM_iUserIndex();
		iJtsPort = wfSession.getM_objCabinet().getM_iServerPort();
		sStr_ServerType = wfSession.getM_objCabinet().getM_strServerType();
	}
	catch(Exception ignore)
	{}
	try
	{
		sInputXML ="<?xml version=\"1.0\"?>\n"
					+ "<NGOGetGroupListExt_Input>\n"
					+ "<Option>NGOGetGroupListExt</Option>\n"
					+ "<CabinetName>"+sCabname+"</CabinetName>\n"
					+ "<UserDBId>"+sSessionId+"</UserDBId>\n"
					+"<UserIndex>"+sUserIndex+"</UserIndex>\n"
					+"<OrderBy>2</OrderBy>\n" 
					+"<SortOrder>A</SortOrder>\n"
					+"<PreviousIndex>0</PreviousIndex>\n"
					+"<LastSortField></LastSortField>\n"
					+"<NoOfRecordsToFetch>500</NoOfRecordsToFetch>\n"
					+"<MainGroupIndex>0</MainGroupIndex>\n"
					+ "</NGOGetGroupListExt_Input>";
		WriteLog("ProcessManagerCustom","sInputXML : "+sInputXML);
		sOutputXML = WFCallBroker.execute(sStr_ServerType,null,sInputXML,sJtsIp,iJtsPort,1);
		WriteLog("ProcessManagerCustom","sOutputXML : "+sOutputXML);
		if(sOutputXML.equals("") || Integer.parseInt(sOutputXML.substring(sOutputXML.indexOf("<Status>")+8 , sOutputXML.indexOf("</Status>")))!=0)
		{
			if(Integer.parseInt(sOutputXML.substring(sOutputXML.indexOf("<Status>")+8 , sOutputXML.indexOf("</Status>")))==11)
			{}
			else if (Integer.parseInt(sOutputXML.substring(sOutputXML.indexOf("<Status>")+8 , sOutputXML.indexOf("</Status>")))!=18) 
			{}
		}
		else
		{
			WFXmlResponse GroupListXmlResponse = new WFXmlResponse();
			GroupListXmlResponse.setXmlString(sOutputXML);
			WFXmlList GroupList = GroupListXmlResponse.createList("Groups","Group");					
			for(GroupList.reInitialize();GroupList.hasMoreElements(); GroupList.skip())
			{


			}
		}
		
	}	
	catch(Exception ignore)
	{}
%>
<html ltr >
<body style="margin-top:0px;margin-left:0px;margin-right:0px;">
  
<head>
<link rel="stylesheet" href="/webdesktop/faces/myFacesExtensionResource/org.apache.myfaces.renderkit.html.util.MyFacesResourceLoader/12117888/tabbedpane.HtmlTabbedPaneRenderer/defaultStyles.css" type="text/css" />

<script type="text/javascript" src="/webdesktop/faces/myFacesExtensionResource/org.apache.myfaces.renderkit.html.util.MyFacesResourceLoader/12117888/tabbedpane.HtmlTabbedPaneRenderer/dynamicTabs.js"><!--

//--></script>
<style rel="stylesheet" type="text/css"><!--
#preferencesForm__id1 .myFaces_panelTabbedPane_activeHeaderCell input,
#preferencesForm__id1 .myFaces_panelTabbedPane_pane,
#preferencesForm__id1 .myFaces_panelTabbedPane_subHeaderCell{
background-color:white;
}
-->
</style>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        
        <link href="/webdesktop/webtop/en_us/css/fixwidth.css" rel="stylesheet" type="text/css"/>
        <title>Custom Pages</title>
        
        <table width=100% border="0" cellspacing="0" cellpadding="0" style="border:5px solid white;">
        <tr>
            <td bgcolor="white" colspan=4 align="Left"><img  src="/webdesktop/webtop/images/logo.jpg"></td>
        </tr>    
        <tr>
            <td  valign="top"><img src="/webdesktop/webtop/images/bar_left.gif" style="text-align:right;" /></td>
            <td width=98% background="/webdesktop/webtop/images/middle.gif"><span class="EWWhite">Custom Pages</span></td>
            <td></td>
            <td valign="top"><img src="/webdesktop/webtop/images/bar_right.gif" style="text-align:left;" /></td>

        </tr>
        <tr>
            <td valign="top"><img src="/webdesktop/webtop/images/white_l.gif" style="text-align:right;" /></td>
            <td  width=98% background="/webdesktop/webtop/images/white_b.gif"></td>
            <td background="/webdesktop/webtop/images/white_b.gif"></td>
            <td valign="top"><img src="/webdesktop/webtop/images/white_r.gif" style="text-align:left;"/></td>
        </tr>
            <tr > 
                <td colspan=4 width=100% background="/webdesktop/webtop/images/white_u.gif" >
          <div style="width :100%; margin-top:20px; margin-left:0px;">
            <form id="preferencesForm" method="post" action="" enctype="application/x-www-form-urlencoded">
			<BR><BR>
			<table align=center>
				<tr><td>
				<table align=left>
									
					
						<tr>

							<td>
								<img src="/webdesktop/webtop/images/big_bullet.gif"><label class="EWLabelBlack">
								<a href="/processmanager/reports/GmacReport/Gmac_Reports_Main_Menu.jsp">
								<font color="Green">Gmac Reports</font></a></label>
							</td>
						</tr>
						<tr>

							<td>
								<img src="/webdesktop/webtop/images/big_bullet.gif"><label class="EWLabelBlack">
								<a href="/processmanager/reports/GmacReport/g1.JPG">
								<font color="Green">Gmac Reports</font></a></label>
							</td>
						</tr>


        
				</table>

				</td>
				</tr>
			</table>
		</form>
       </div>
      </td>
      </tr>
     </table>
        
       
    <!-- MYFACES JAVASCRIPT -->

<!-- MYFACES JAVASCRIPT -->

</body>
</html>

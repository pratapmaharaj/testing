<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: pmheadertoolbar.jsp
Author                          : Sachin Agrawal
Date written (DD/MM/YYYY)       : 3/Jan/2007
Description			: This file contains the general purpose header toolbar
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change        Description (Bug No. (If Any))
(DD/MM/YYYY)
18/01/2008      Vijay Kumar             Bug id-3576
18/03/2009       Bhupesh Kumar          PRM_8.0_001   Need to add a Custom Link in ProcessManager and call custom jsp files for maintaining master Interfaces.       
08/12/2011      Anushree Jain           Bug 29509 - Provide Launch Bam link
09/02/2012      Sri Prakash             Bug 30451 - Logo Name should be cabinet specific in processmanager
01/11/2012      Jaseem Ansari           PRM_8.0_056|(Need to change the color code of processmanager)
22/04/2013      Prince Kumar            Bug 39008       Requirement of Multiple custom link in Process manager
21/02/2014      Jaseem Ansari           Bug 43273 While launching the webdesktop and processmanager from any other module,user logged information should not be dispalayed
29/06/2015      Ashutosh Pandey         Bug 55591 - Display User's personal and family name in process manager
18/11/2015      Saquib Islam            Bug 57898 - Clicking on Custom Link not working
10/08/2016       Jaseem Ansari          Bug 63661 No option available in process manager audit log for quick search variable(action id=84) in process tab option combo
30/08/2016      Ashutosh Pandey         Bug 64060 - The Home link in process manager is not necessary, kindly remove it.
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--%>
<%@page contentType="text/html"%>
<%@page pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsf/core" prefix="f"%>
<%@taglib uri="http://java.sun.com/jsf/html" prefix="h"%> 

<h:panelGrid columns="3" columnClasses="PMWIDTH30,PMWIDTH40,PMWIDTH30RIGHT" cellpadding="0" cellspacing="0" dir="#{PMGEN.HTML_DIR}" width="100%" border="0">
    <h:outputLabel  rendered="#{!wfSession.m_bExtCalledFlag}" styleClass="PMLabelboldGrey1" style="width:100%" value="#{wfSession.m_strUserName} #{PMGEN.COMMA}#{PMGEN.WELCOME_TO} #{wfSession.m_strCabName}"/>
    <h:outputText rendered="#{!wfSession.m_bExtCalledFlag}" id="LoginInfoDetails"  value="" styleClass="PMLabelGreySmall1" style="padding-#{PMGEN.LEFT}:10px;"/>
    <h:graphicImage  rendered="#{!wfSession.m_bExtCalledFlag}" alt="#{PMGEN.OMNIFLOW_DESC_TEXT_1}" url="../omniflow/#{PMGEN.Path}images/#{wfSession.strLogoName}"></h:graphicImage>
</h:panelGrid>
<h:panelGrid columns="3" dir="#{PMGEN.HTML_DIR}" columnClasses="PMWIDTH3,PMWIDTH100,PMWIDTH5" cellpadding="0" cellspacing="0" border="0" style="background-image: url('../omniflow/images/middle.gif');" width="100%;">
 <h:graphicImage  value="../omniflow/images/bar_#{PMGEN.LEFT}.gif"></h:graphicImage>
 <h:panelGrid border="0" columns="2" width="100%" columnClasses="PMWIDTH70,PMWIDTH30" cellpadding="0" cellspacing="0">
        <h:panelGroup>
            <h:panelGrid columns="6" cellpadding="0" cellspacing="0" border="0" columnClasses="PMWIDTH10,PMWIDTH25,PMWIDTH5CENTER,PMWIDTH35,PMWIDTH3,PMWIDTH20" width="80%">
                
                <h:outputLabel rendered="true" value="#{PMGEN.QS_SEARCH}" styleClass="PMWindowTitle" style="width:100%;vertical-align:middle"/>
                
                <h:inputText id="txtVariableValue" value="" style="width:100%" styleClass="PMControlText" rendered="true" disabled="#{!wfQuickSearchVariables.m_bRenderQuickSearchControls}" onkeydown="handleEnterMain(event,'cmdGo');"/>
                
                <h:outputLabel rendered="true" value="#{PMGEN.QS_IN}" styleClass="PMWindowTitle" style="width:100%;vertical-align:middle"/>
                
                <h:selectOneMenu id="cmbAliases" value="a" style="width:100%" styleClass="PMControlText">                             
                    <f:selectItems id="varitems" value="#{wfQuickSearchVariables.m_arrAliases}" />
                </h:selectOneMenu>
                
                <h:outputLabel rendered="true" value="" style="width:100%"/>
                
                <h:commandButton id="cmdGo" image="../omniflow/#{PMGEN.Path}images/go.gif" style="cursor:pointer;border:0;" onclick="getQuickSearchResult();" disabled="#{!wfQuickSearchVariables.m_bRenderQuickSearchControls}" type="button">
	        </h:commandButton>

            </h:panelGrid>
            
        </h:panelGroup>
        
        <h:panelGroup  styleClass="PMAlignRight">
            <h:panelGrid  border="0" cellpadding="0" cellspacing="0" columns="1">
                <h:panelGrid border="0" columns="13" cellpadding="0" cellspacing="0">
                    <h:panelGrid border="0" columns="1" cellpadding="0" cellspacing="0">
                       <f:verbatim><table border="0"><tr><td nowrap valign="center">
                                       <span id="myMenuID" ></span>
                                    </td></tr></table></f:verbatim>
                   </h:panelGrid> 
                     <h:graphicImage  value="../omniflow/images/sep.gif" rendered="#{wfSession.m_bRenderLaunchBam}"></h:graphicImage>


                    <h:panelGrid border="0" columns="1" cellpadding="0" cellspacing="0" rendered="#{wfSession.m_bRenderLaunchBam}">
                        <h:outputLink styleClass="PMNOUNDERLINE">
                            <h:outputLabel id="cmdlink_LaunchBam" onclick="LaunchBam();return false;" value="#{PMGEN.LAUNCH_BAM}" styleClass="PMLTGreen1" style="white-space: nowrap;">
                            </h:outputLabel>
                        </h:outputLink>
                    </h:panelGrid>
                    
                    <h:graphicImage  value="../omniflow/images/sep.gif"></h:graphicImage>
                    
                    
                    <h:panelGrid border="0" columns="1" cellpadding="0" cellspacing="0">
                        <h:outputLink styleClass="PMNOUNDERLINE">
                            <h:outputLabel id="cmdlink_LaunchClient" onclick="LaunchClient();return false;" value="#{PMGEN.LAUNCH_CLIENT}" styleClass="PMLTGreen1" style="white-space: nowrap;">
                            </h:outputLabel>
                        </h:outputLink>
                    </h:panelGrid>
                    
                    
                    <h:graphicImage  value="../omniflow/images/sep.gif"  ></h:graphicImage>
                    <h:panelGrid border="0" columns="1" cellpadding="0" cellspacing="0"  >
                        <h:outputLink styleClass="PMNOUNDERLINE">
                            <h:outputLabel id="cmdlink_AuditLog" onclick="AuditLog();return false;" value="#{PMGEN.AUDIT_LOG}" styleClass="PMLTGreen1" style="white-space: nowrap;">
                            </h:outputLabel>
                        </h:outputLink>
                    </h:panelGrid>     
                    <h:graphicImage  value="../omniflow/images/sep.gif"></h:graphicImage>
                    <h:panelGrid border="0" columns="1" cellpadding="0" cellspacing="0">
                        <h:outputLink styleClass="PMNOUNDERLINE">
                            <h:outputLabel id="cmdlink_Search" onclick="SearchWorkitems();return false;" value="#{PMGEN.TITLE_SEARCH}" styleClass="PMLTGreen1" style="white-space: nowrap;">
                            </h:outputLabel>
                        </h:outputLink>
                    </h:panelGrid>
                    
                    <h:graphicImage  value="../omniflow/images/sep.gif" rendered="#{wfSession.m_bShowLogOut}"></h:graphicImage> 
                    
                    <h:panelGrid border="0" columns="1" cellpadding="0" cellspacing="0" rendered="#{wfSession.m_bShowLogOut}">
                        <h:outputLink styleClass="PMNOUNDERLINE">
                            <h:outputLabel id="cmdlink_Logout" onclick="Logout();return false;" value="#{PMGEN.Logout}" styleClass="PMLTGreen1" style="white-space: nowrap;">
                            </h:outputLabel>
                        </h:outputLink>
                    </h:panelGrid> 
                    
                </h:panelGrid>     
            </h:panelGrid>
        </h:panelGroup>
    </h:panelGrid>
    <h:graphicImage value="../omniflow/images/bar_#{PMGEN.RIGHT}.gif"></h:graphicImage>
	</h:panelGrid>
<h:panelGrid columns="3" width="100%" columnClasses="PMWIDTH5,PMWIDTH100,PMWIDTH5" cellpadding="0" cellspacing="0" border="0" style="background-image: url('../omniflow/images/white_b.gif');">
    <h:graphicImage  value="../omniflow/images/white_l.gif"></h:graphicImage>
     <h:outputLabel value=""/>
    <h:graphicImage  value="../omniflow/images/white_r.gif"></h:graphicImage>
</h:panelGrid>
<ilayer width=400  name="dep1" ><layer name="dep2" width=400 ></layer></ilayer><span style="position: absolute;top: 45px;RIGHT:35"  id="describe"  onMouseover="clear_delayhide()" onMouseout="resetit(event)"></span>
<script type="text/javascript">
          //  alert(document.getElementById('myMenuID'))
            var menuobj=document.getElementById? document.getElementById("describe") : document.all? document.all.describe : document.layers? document.dep1.document.dep2 : ""
           // convertIT('myMenuID');
</script>

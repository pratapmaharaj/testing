<%-- 
    Document   : OdIntegration
    Created on : May 29, 2013, 12:57:22 PM
    Author     : jaseem.ansari
--%>

<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: odweb.jsp
Author                          : Arup Sharma
Date written (DD/MM/YYYY)       : 21/04/2007
Description			: This file is used for opening the odcabinet mgmt page
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
(DD/MM/YYYY)
----------------------------------------------------------------------------------------------------
2/05/2007        Arup Sharma            BUG 558 RE
23/08/2011      Anushree Jain		    Bug 27971 Security issue
19/01/2012      Sri Prakash             Bug 29762 - support for multitenancy and seperate ini ( cablist.ini ) for cabinet registration
04/06/2013      Jaseem Ansari           Bug 39929 Change in the architecture of integration with omnidocs due to security issues
Bug 42035       10/09/2013              Jaseem Ansari           Security related issue with omnidocs and omniflow integration.
Bug 42256       04/11/2013              Jaseem Ansari           Not able to login in omnidocs from webdesktop and processmanager in WAS
28/01/2014      Jaseem Ansari           Bug 42955 Providing the backward compatibility for security related issues
03/11/2015		Jaseem Ansari			Bug 57708 - Removing the IP Adress and Port from the omnidcs urls in Processmanager
----------------------------------------------------------------------------------------------------
--%>

<%@page contentType="text/html"%>
<%@page pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsf/core" prefix="f"%>
<%@taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ include file="/application/commonheader.process"%>
<%@page import="com.newgen.wfdesktop.session.*,java.util.*, com.newgen.wfdesktop.util.*, com.newgen.wfdesktop.cabinet.*,com.newgen.encryption.DataEncryption" %>

<f:view>
<html>
<head>
<script LANGUAGE="Javascript">
      <%
     long timeStamp = System.currentTimeMillis();
     String jSessionId = "";
            Cookie[] cookies = request.getCookies();
            for (int i = 0; i < cookies.length; i++) {
                if ("JSESSIONID".equalsIgnoreCase(cookies[i].getName())) {
                    jSessionId = cookies[i].getValue();
                    break;
                }

            }
    String path = "/processmanager/application/validatesession.jsp;jsessionid=" + jSessionId + "?PM_UID="+pm_uid;
    String strSecurityFlag = WFCabinetList.getConfValue("SecurityFlag","Y" , wfSession.getM_strCabName());
     %>

function LaunchOdWeb()
{ 
	var servletRef = window.top.location.href;
        var securityflg = '<%= strSecurityFlag %>';
        var servletPath='';
        if(securityflg=='Y')
	 servletPath = servletRef.substring(0, servletRef.indexOf('<%=WFUtility.sContextPath%>')) + '<%=WFCabinetList.getConfValue("ODContextPath","/omnidocs" , wfSession.getM_strCabName())%>/login.jsp';
        else
            servletPath = servletRef.substring(0, servletRef.indexOf('<%=WFUtility.sContextPath%>')) + '<%=WFCabinetList.getConfValue("ODContextPath","/omnidocs" , wfSession.getM_strCabName())%>/ExtendSession.jsp';
	var odForm = window.document.forms[0];
	odForm.action = servletPath;
	odForm.submit();
}
</script>
</head>
<body topmargin="0" leftmargin="0" onload='LaunchOdWeb();'>
<h:form id="odForm">
    <f:verbatim>
     <input type="hidden" name="PM_UID" value="<%=pm_uid%>">
    </f:verbatim>
    <input type="hidden" name="CabinetName" value="<%=wfSession.getM_strCabName()%>"/>
    <input type="hidden" name="UserDbId" value="<%=wfSession.getM_strSessionID()%>"/>
    <input type="hidden" name="Encoding" value="<%=wfSession.getM_objCabinet().getM_strEncoding()%>"/>
    <input type="hidden" name="DataBaseType" value="<%=wfSession.getM_objCabinet().getM_strCabType()%>"/>
    <input type="hidden" name="Operation" value="ChangePassword"/>
    <input type="hidden" name="Encoding" value=""/>
    <input type="hidden" name="DataBaseType" value=""/>
    <input type="hidden" name="Option" value="<%=DataEncryption.encrypt("ExtendSession")%>">
     <input type="hidden" name="jsessionID" value="<%=DataEncryption.encrypt(jSessionId)%>">
     <input type="hidden" name="TimeStamp" value="<%=DataEncryption.encrypt(String.valueOf(timeStamp))%>">
      <input type="hidden" name="Path" value="<%=DataEncryption.encrypt(path)%>">

</h:form>
</body>
</html>
</f:view>


<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: userpicklist.jsp
Author                          : Ajith Jacob
Date written (DD/MM/YYYY)       : 18/Jan/2007
Description			: This file contains the picklist for users.
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
(DD/MM/YYYY)
01/05/2007      Puneet Pahuja           Bug id 671
15/06/2007      Puneet Pahuja           Bug id 1176
23/08/2011      Anushree Jain		    Bug 27971 Security issue
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--%>
<%@ page import="java.io.*"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h" %>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f" %>
<%@ page contentType="text/html; charset=UTF-8" %>
<%@ page import="java.util.*,com.newgen.wfdesktop.session.*,com.newgen.wfdesktop.user.*" %>
<%@ include file="/application/commonheader.process"%>
<f:view>
    <f:loadBundle basename="pmgen" var="PMGEN"/>
    <f:loadBundle basename="pmerrorcodes" var="PMERROR"/>
    <html dir='<h:outputText value="#{PMGEN.HTML_DIR}"/>'>
        <head>
            <title>
                <h:outputText value="#{PMGEN.OMNIFLOW_DESC_TEXT_1}[#{PMGEN.USER_PICKLIST}]" />
            </title>
            <link href='../omniflow/<h:outputText value="#{PMGEN.Path}"/>css/docstyle.css' rel="stylesheet" type="text/css">
            <script  src='../omniflow/<h:outputText value="#{PMGEN.Path}"/>scripts/constants.js'></script>
            <script  src="../omniflow/scripts/toolbar.js"></script>
            <script  src="../omniflow/scripts/wfgeneral.js"></script>
            <script  src="../omniflow/scripts/dragiframe.js"></script>
            <script  src="../omniflow/scripts/pickList.js"></script>
            <Script LANGUAGE="Javascript">
    var allWindows = new Array();
    var allPicklistWindows=new Array();
    var CurrentPickListId="UserPickList";
    var localizedPath='<h:outputText value="#{PMGEN.Path}"/>';
    var strTextFieldID = '<h:outputText value="#{param.strFormFieldText}"/>';
    var strIDFieldID='<h:outputText value="#{param.strFormFieldID}"/>';
    var strFormID ='<h:outputText value="#{param.strFormID}"/>';
    var strTextHidden='<h:outputText value="#{param.strFormFieldTextHidden}"/>';
    var strReturnNoneText='<h:outputText value="#{param.ReturnNoneValue}"/>';
    var strNoneType='<h:outputText value="#{param.NoneType}"/>';
    var strNoneID='<h:outputText value="#{param.NoneValue}"/>';
    var strCallback='<h:outputText value="#{param.CallBack}"/>';
       
    function setValue()
    {
        var len=0;
        try
	{
            len=document.getElementById("UserPickList:picklist").length;
    	}
        catch(e)
	{
            len=-1;
	}
        var name;
        var id;
        var value;
        var ids;
        var flag=false;
        var strSelectedItems="";
        for(i=0;i<len;i++)
        {
            if(document.getElementById("UserPickList:picklist").options[i].selected)
            {
                value = document.getElementById("UserPickList:picklist").options[i].value;
                id =  Trim(value.substring(0,value.indexOf(":")));
                name=  Trim(value.substring(value.indexOf(":")+1));
                
                if(i==0 && strNoneType>0)
                {
                    id=strNoneID;
                    if(strReturnNoneText==0)
                        name='';
                }
                flag=true;
                break;
            }
        } //end for
        if(!flag)
        {
            if(len<=0)
            {
                removeIFrame(CurrentPickListId);
            }
            else
            {
                alert(NO_USER_SELECTED);
                return false;
            }   
        }
        else
        {
            try{
                window.parent.document.getElementById(strFormID + ":" + strTextFieldID).value=name;
                window.parent.document.getElementById(strFormID + ":" + strIDFieldID).value=id;
                window.parent.document.getElementById(strFormID + ":" + strTextHidden).value=name;
                if(strCallback.length>0 && Trim(strCallback).length>0)
                {
                    var Temp='window.parent.' + strCallback + '();';
                    eval(Temp);        
                }
                 removeIFrame(CurrentPickListId);
              }catch(e){}
        }
    }
  
                         </Script>
        </head>
        <body class="PMbgcolorTransparent" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" onload="setPicklistFocus();addHandle(document.getElementById('UserPickList:toolbar'), window);" onunload='closeWindows();closePicklistWindows(CurrentPickListId);return false;'>
            
            <h:panelGrid width="100%" cellpadding="0" cellspacing="0" border="0" styleClass="PMPageBackground" style="border-collapse:collapse;border:1px solid #bbb9b9;">
                <h:form id="UserPickList">
                    <f:verbatim>
                        <input type="hidden" name="PM_UID" value="<%=pm_uid%>">
                    </f:verbatim>
                    <h:panelGrid columns="3" id="toolbar" cellpadding="0" cellspacing="0" style="border:0;border-bottom: solid 1px #989898;" columnClasses="PMWIDTH65,PMWIDTH5,PMWIDTH30RIGHT" width="100%">
                        <h:outputLabel value="#{PMGEN.USER_PICKLIST}" styleClass="EWLabel1B" style="width:100%;padding-left:3px;"/>
                        <h:panelGroup>
                            <h:inputHidden id="hid_FirstField" value="#{wfUserList.m_strFirstField}"/>
                            <h:inputHidden id="hid_LastField" value="#{wfUserList.m_strLastField}"/>
                            <h:inputHidden id="hid_FirstFieldIndex" value="#{wfUserList.m_strFirstFieldIndex}"/>
                            <h:inputHidden id="hid_LastFieldIndex" value="#{wfUserList.m_strLastFieldIndex}"/>
                            <h:inputHidden id="hid_Action" value="#{wfUserList.m_iAction}"/>
                            <h:inputHidden id="hid_NoneType" value="#{wfUserList.m_iNoneDisplay}"/>
                            <h:inputHidden id="hid_NoneID" value="#{wfUserList.m_strNoneID}"/>
                            <h:inputHidden id="HidItemID" value="#{wfUserList.m_iGroupID}"/>
                            <h:inputHidden id="HidItemName" value="#{wfUserList.m_strGroupName}"/>
                            
                            <f:verbatim><input type=Hidden id="strFormFieldText" name="strFormFieldText" value='</f:verbatim><h:outputText value="#{param.strFormFieldText}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="strFormFieldID" name="strFormFieldID" value='</f:verbatim><h:outputText value="#{param.strFormFieldID}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="strFormID" name="strFormID" value='</f:verbatim><h:outputText value="#{param.strFormID}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="strFormFieldTextHidden" name="strFormFieldTextHidden" value='</f:verbatim><h:outputText value="#{param.strFormFieldTextHidden}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="ReturnNoneValue" name="ReturnNoneValue" value='</f:verbatim><h:outputText value="#{param.ReturnNoneValue}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="NoneType" name="NoneType" value='</f:verbatim><h:outputText value="#{param.NoneType}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="NoneValue" name="NoneValue" value='</f:verbatim><h:outputText value="#{param.NoneValue}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="CallBack" name="CallBack" value='</f:verbatim><h:outputText value="#{param.CallBack}"/><f:verbatim>'/></f:verbatim>
                        </h:panelGroup>
                        <h:graphicImage title="#{PMGEN.BUTTON_CLOSE}" url="../omniflow/images/close_img.gif" onclick="removeIFrame(CurrentPickListId);" style="CURSOR: pointer;border:0;"/>
                    </h:panelGrid>
                    <h:panelGrid styleClass="PMbgcolorWhite" width="100%" cellpadding="0" cellspacing="0" border="0" >
                        
                        <h:panelGrid columns="2" border="0" cellspacing="5" columnClasses="PMWIDTH45,PMWIDTH55" cellpadding="0" width="100%" >
                            <h:panelGrid columns="1" cellpadding="0" cellspacing="0" border="0">
                                <h:selectOneRadio value="#{wfUserList.m_strOrderBy}" styleClass="EWLabel1" layout="pageDirection">
                                    <f:selectItem itemLabel="#{PMGEN.USER_ID}" itemValue="2"/>
                                    <f:selectItem itemLabel="#{PMGEN.USER_NAME}" itemValue="3"/>
                                </h:selectOneRadio>
                            </h:panelGrid>
                            
                            <h:inputText   style="width:100%" value="#{wfUserList.m_strPrefix}" styleClass="PMControlText" onkeydown="handlePickListEnter(event,'UserPickList:cmdlink_Search');"/>
                            
                        </h:panelGrid>
                        
                        <h:panelGrid columns="2" border="0" cellspacing="5" columnClasses="PMWIDTH35,PMWIDTH65" cellpadding="0" width="100%" >
                            
                            <h:outputText style="width:100%" value="#{PMGEN.GROUP_NAME}" styleClass="EWLabel1"/>
                            <h:panelGroup>
                                <h:panelGrid columns="3" border="0" cellspacing="2" columnClasses="PMWIDTH70,PMWIDTH15,PMWIDTH15" cellpadding="0" width="100%">
                                    <h:inputText rendered="true" style="width:100%" styleClass="PMControlText" id="GroupName" value="#{wfUserList.m_strGroupName}" readonly="true" tabindex="-1"/><%--for bug id 671--%>
                                    <h:commandButton  type="button" styleClass="EWButton" id="cmdPicklist_Group" image="../omniflow/images/picklist_btn.gif" onclick="ShowPickList(this,'WFGroupList','GroupName','HidItemID','HidItemName','3','0','1','','','','','','','true');return false;"/>
                                    <h:commandLink styleClass="EWEnabledLink" id="cmdlink_Search" action="#{wfUserList.search}">
                                        <h:graphicImage alt="#{PMGEN.TITLE_SEARCH}" style="border:0" url="../omniflow/#{PMGEN.Path}images/go.gif"> </h:graphicImage>
                                    </h:commandLink>
                                </h:panelGrid>
                            </h:panelGroup>
                        </h:panelGrid>
                        
                        
                        <%//Displaying the error message if any%>
                        <h:panelGrid columns="1" cellpadding="0" cellspacing="0" columnClasses="PMWIDTH100CENTER" width="100%"  styleClass="PMMessageBorder" >
                            <h:panelGroup rendered="#{wfUserList.m_bError}">
                                <h:graphicImage  alt="" onclick="" style="border:0;vertical-align:middle" url="../omniflow/images/errorimage.gif"> </h:graphicImage>
                                <h:outputText value="." style="width:1%;visibility:hidden"/>
                                <h:outputText id="Error" value="#{wfUserList.m_strErrorMessage}" styleClass="PMErrorMessage" />
                            </h:panelGroup>
                        </h:panelGrid>
                        
                        <h:panelGrid columns="1" border="0" cellspacing="3" columnClasses="PMWIDTH100CENTERTOP" cellpadding="3" width="100%" rendered="#{!wfUserList.m_bError}">
                            <h:selectOneListbox size="7" binding="#{wfUserList.m_Misc}" styleClass="PMWIDTH190PIXELFORPICKLIST" ondblclick="setValue();" id="picklist"  value="" onkeydown="handlePickListEnter(event);">
                                <f:selectItems value="#{wfUserList.m_objUserList}"/>
                            </h:selectOneListbox> 
                        </h:panelGrid>
                        <h:panelGrid columns="1" border="0" cellspacing="3" columnClasses="PMWIDTH100" cellpadding="3" width="100%" rendered="#{wfUserList.m_bError}">
                            <h:selectOneListbox size="5" styleClass="PMControlText" id="picklist11" style="width:100%" value="">
                            </h:selectOneListbox> 
                        </h:panelGrid>
                        <h:panelGrid columns="5" border="0" cellspacing="0"  columnClasses="PMWIDTH20,PMWIDTH20,PMWIDTH20,PMWIDTH20RIGHT,PMWIDTH20RIGHT" cellpadding="0" width="100%" rendered="#{!wfUserList.m_bError}">
                            <h:outputText  style="width:100%" value="  "/>
                            <h:outputText  style="width:100%" value="  "/>
                            <h:outputText  style="width:100%" value="  "/>
                            <h:panelGroup>
                                <h:commandLink styleClass="EWEnabledLink" id="cmdlink_Previous" action="#{wfUserList.previous}" tabindex="#{wfUserList.m_strTabIndexForPrevious}"><%--for bug id 671--%>
                                    <h:graphicImage  alt="#{PMGEN.BUTTON_PREVIOUS}" style="border:0" url="../omniflow/#{PMGEN.Path}images/prev.gif" rendered="#{wfUserList.m_bEnablePreviousButton}"> </h:graphicImage>
                                </h:commandLink>
                                <h:graphicImage alt="#{PMGEN.BUTTON_PREVIOUS}" style="border:0" url="../omniflow/#{PMGEN.Path}images/prev_dis.gif" rendered="#{!wfUserList.m_bEnablePreviousButton}"> </h:graphicImage>
                            </h:panelGroup>
                            <h:panelGroup>
                                <h:commandLink styleClass="EWEnabledLink" id="cmdlink_Next" action="#{wfUserList.next}" tabindex="#{wfUserList.m_strTabIndexForNext}"><%--for bug id 671--%>
                                    <h:graphicImage  alt="#{PMGEN.BUTTON_NEXT}" style="border:0" url="../omniflow/#{PMGEN.Path}images/next.gif" rendered="#{wfUserList.m_bEnableNextButton}"> </h:graphicImage>
                                </h:commandLink>
                                <h:graphicImage alt="#{PMGEN.BUTTON_NEXT}" style="border:0" url="../omniflow/#{PMGEN.Path}images/next_dis.gif" rendered="#{!wfUserList.m_bEnableNextButton}"> </h:graphicImage>
                            </h:panelGroup>
                        </h:panelGrid>
                    </h:panelGrid> 
                </h:form>
            </h:panelGrid>
        </body>
    </html>
</f:view>

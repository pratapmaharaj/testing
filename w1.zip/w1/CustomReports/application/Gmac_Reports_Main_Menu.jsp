<!-- 
----------------------------------------------------------------------------------------------------
Project			:	AAA
Module			:	AAA AP Reports
Company			:	WNS Global Services
Created By		:	Santosh Bhati
Creadted Date	:	6/17/2011
----------------------------------------------------------------------------------------------------
-->
-->
<jsp:useBean id="wfSession" class="com.newgen.wfdesktop.session.WFSession" scope="session"/>
<%@ include file="customized.process" %>
<%@ page import="java.text.*"%>
<%@ page import="java.lang.String.*"%>
<%@ page import="java.lang.Object"%>
<%@ page import="com.newgen.wfdesktop.xmlapi.*" %>
<%@ page import="com.newgen.wfdesktop.util.*" %>
<%@ page import="ISPack.ISUtil.*,ISPack.*,java.util.*,java.io.*,Jdts.DataObject.JPDBInteger, Jdts.DataObject.JPDBISAddress,Jdts.DataObject.*,Jdts.*, java.net.*,com.newgen.wfdesktop.util.*, com.newgen.wfdesktop.session.*,com.newgen.wfdesktop.xmlapi.*, com.newgen.wfdesktop.dmsinterface.*,java.awt.*"%>
<%
		WriteLog("ProcessManagerCustom","inside main page ");
%>
<meta HTTP-EQUIV="content-type" CONTENT="text/html;charset=8859_1">
<link href="../../../webdesktop/webtop/en_us/css/docstyle.css" rel="stylesheet" type="text/css">
<html>
<body>
hi
</body>
</html>
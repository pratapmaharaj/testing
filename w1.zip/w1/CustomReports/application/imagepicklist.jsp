<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: imagepicklist.jsp
Author                          : Bhupesh kumar
Date written (DD/MM/YYYY)       : 24/Apr/2007
Description			: This fileshows the image picklist  .
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
24/04/2009      Bhupesh Kumar           (PRM_7.1_015)Option for adding rule defination on queue Aliases to display in different color/images in worklist.
23/08/2011      Anushree Jain		    Bug 27971 Security issue
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--%>
<%@ page import="java.io.*"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h" %>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f" %>
<%@ page contentType="text/html; charset=UTF-8" %>
<%@ page import="java.util.*,com.newgen.wfdesktop.session.*,com.newgen.wfdesktop.user.*" %>
<%@ include file="/application/commonheader.process"%>
<f:view>
    <f:loadBundle basename="pmgen" var="PMGEN"/>
    <f:loadBundle basename="pmerrorcodes" var="PMERROR"/>
    <html dir='<h:outputText value="#{PMGEN.HTML_DIR}"/>'>
        <head>
            <title>
                <h:outputText value="#{PMGEN.OMNIFLOW_DESC_TEXT_1}[#{PMGEN.USER_PICKLIST}]" />
            </title>
            <link href='../omniflow/<h:outputText value="#{PMGEN.Path}"/>css/docstyle.css' rel="stylesheet" type="text/css">
            <script  src='../omniflow/<h:outputText value="#{PMGEN.Path}"/>scripts/constants.js'></script>
            <link href='../omniflow/<h:outputText value="#{PMGEN.Path}"/>css/scrolling_table.css' rel="stylesheet" type="text/css">
            <script  src="../omniflow/scripts/toolbar.js"></script>
            <script  src="../omniflow/scripts/wfgeneral.js"></script>
            <script  src="../omniflow/scripts/dragiframe.js"></script>
            <script  src="../omniflow/scripts/pickList.js"></script>
            <script  src="../omniflow/scripts/aliasrule.js"></script>
            <Script LANGUAGE="Javascript">
    var allWindows = new Array();
    var allPicklistWindows=new Array();
    var CurrentPickListId="ImagePickList";
    var localizedPath='<h:outputText value="#{PMGEN.Path}"/>';  
     var TargetDispId = '<h:outputText value="#{param.TargetDispId}"/>';
    var TargetHidId='<h:outputText value="#{param.TargetHidId}"/>';
                         </Script>
        </head>
        <body class="PMbgcolorTransparent" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" onload="setPicklistFocus();addHandle(document.getElementById('ImagePickList:toolbar'), window);" onunload='closeWindows();closePicklistWindows(CurrentPickListId);return false;' >
            
            <h:panelGrid width="100%" cellpadding="0" cellspacing="0" border="0" styleClass="PMPageBackground" style="border-collapse:collapse;border:1px solid #bbb9b9;">
                <h:form id="ImagePickList">
                    <f:verbatim>
                        <input type="hidden" name="PM_UID" value="<%=pm_uid%>">
                    </f:verbatim>
                    <h:panelGrid columns="3" id="toolbar" cellpadding="0" cellspacing="0" style="border:0;border-bottom: solid 1px #989898;" columnClasses="PMWIDTH65,PMWIDTH5,PMWIDTH30RIGHT" width="100%">
                        <h:outputLabel  value="#{PMGEN.IMAGE_PICKIST}" styleClass="EWLabel1B" style="width:100%;padding-#{PMGEN.LEFT}:3px;"/>
                        <h:panelGroup>
                             
                        </h:panelGroup>
                        <h:graphicImage title="#{PMGEN.BUTTON_CLOSE}" url="../omniflow/images/close_img.gif" onclick="removeIFrame(CurrentPickListId);" style="CURSOR: pointer;border:0;"/>
                    </h:panelGrid>
                    <f:verbatim>
                    <div style="height:150px;overflow :auto;" >
                    </f:verbatim>
                       <h:dataTable     border="1"  id="Imagelist" rendered="#{wfProcVarMapping.m_isRenderImageList}" width="120px;" columnClasses="PMWIDTH5,PMWIDTH95"   cellpadding="0"  cellspacing="0" value="#{wfProcVarMapping.m_imageList}" var="Imagevar" >
                
             <h:column>               
                
                 <h:selectOneRadio onclick="dataTableSelectOneRadio(this);"    >
                     <f:selectItem itemValue="#{Imagevar.imageName}"/>
                 </h:selectOneRadio>
                 
             </h:column>
             
             <h:column>               
                 
                  <h:graphicImage value="../omniflow/aliasimages/#{Imagevar.imageName}" height="16px" width="16px"  ></h:graphicImage> 
                 
             </h:column>
            </h:dataTable>   
                    <h:panelGrid columns="1" width='120px;' columnClasses="EWLabelMsg" rendered="#{!wfProcVarMapping.m_isRenderImageList}">
                    <h:outputText value="#{PMGEN.NO_IMAGE_FOUND}" ></h:outputText>
                    </h:panelGrid>
                    <f:verbatim>
                        </div>
                    </f:verbatim>                    
                </h:form>
            </h:panelGrid>
        </body>
    </html>
</f:view>

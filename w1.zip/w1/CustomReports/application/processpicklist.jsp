<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: processpicklist.jsp
Author                          : Ajith Jacob
Date written (DD/MM/YYYY)       : 16/Jan/2007
Description			: This file contains the picklist for processes.
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
(DD/MM/YYYY)
01/05/2007      Puneet Pahuja            Bug id 671
15/06/2007      Puneet Pahuja           Bug id 1176
11/05/2011      Sri prakash             PRM_9.0_006(Non supervisor user is not able to generate report because list of process is not displayed)
23/08/2011      Anushree Jain		    Bug 27971 Security issue
14/09/2011     Anushree Jain	      Bug 28348-Provide external queue variable mapping
10/04/2015     Sri Prakash            Bug 54873 -  OF 10.3:  If defined alias from quick search management, process name is not showing correct in added alias
27/07/2015     Dinesh Verma             Bug 56042 - Unable to define alias on MyQueue & Also unable to see the external Variable In QueueManagement
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--%>
<%@ page import="java.io.*"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h" %>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f" %>
<%@ page contentType="text/html; charset=UTF-8" %>
<%@ page import="java.util.*,com.newgen.wfdesktop.session.*,com.newgen.wfdesktop.process.*" %>
<%@ include file="/application/commonheader.process"%>
<f:view>
<f:loadBundle basename="pmgen" var="PMGEN"/>
<f:loadBundle basename="pmerrorcodes" var="PMERROR"/>
<html dir='<h:outputText value="#{PMGEN.HTML_DIR}"/>'>
    <head>
    <title>
        <h:outputText value="#{PMGEN.OMNIFLOW_DESC_TEXT_1}[#{PMGEN.PROCESS_PICKLIST}]" />
    </title>
    <link href='../omniflow/<h:outputText value="#{PMGEN.Path}"/>css/docstyle.css' rel="stylesheet" type="text/css">
    <script  src='../omniflow/<h:outputText value="#{PMGEN.Path}"/>scripts/constants.js'></script>
    <script  src="../omniflow/scripts/toolbar.js"></script>
    <script  src="../omniflow/scripts/wfgeneral.js"></script>
    <script  src="../omniflow/scripts/dragiframe.js"></script>
    <script  src="../omniflow/scripts/pickList.js"></script>
    <Script LANGUAGE="Javascript">
    var allWindows = new Array();
    var allPicklistWindows=new Array();
    var CurrentPickListId="ProcessPickList";
    var localizedPath='<h:outputText value="#{PMGEN.Path}"/>';
    var strTextFieldID = '<h:outputText value="#{param.strFormFieldText}"/>';
    var strIDFieldID='<h:outputText value="#{param.strFormFieldID}"/>';
    var strFormID ='<h:outputText value="#{param.strFormID}"/>';
    var strTextHidden='<h:outputText value="#{param.strFormFieldTextHidden}"/>';
    var strtat='<h:outputText value="#{param.tat}"/>';
    var strcalflag='<h:outputText value="#{param.usecal}"/>';
    var strReturnNoneText='<h:outputText value="#{param.ReturnNoneValue}"/>';    
    var strNoneType='<h:outputText value="#{param.NoneType}"/>';
    var strNoneID='<h:outputText value="#{param.NoneValue}"/>';
    var strCallback='<h:outputText value="#{param.CallBack}"/>';
    var strProcessPrefix='<h:outputText value="#{param.processprefix}"/>';
    var tatArray=<h:outputText value="#{wfProcessList.m_strTatArray}"/>;
    var setcalflagArray=<h:outputText value="#{wfProcessList.m_strTurnAroundFlag}"/>;
    var strVersionFlag='<h:outputText value="#{wfProcessList.m_strLatestVersionFlag}"/>';
    function setValue()
    {
        var len=0;
        try
	{
            len=document.getElementById("ProcessPickList:picklist").length;
    	}
        catch(e)
	{
            len=-1;
	}
        var name;
        var id;
        var ids;
        var flag=false;
        var strSelectedItems="";
        var tat='';
        var setcal='';
        for(i=0;i<len;i++)
        {
            if(document.getElementById("ProcessPickList:picklist").options[i].selected)
            {
                name=document.getElementById("ProcessPickList:picklist").options[i].text;
                id=document.getElementById("ProcessPickList:picklist").options[i].value;
                try
                {
                    tat=tatArray[i];
                    setcal=setcalflagArray[i];
                }
                catch(e)
                {
                    tat='';
                    setcal='';
                }
                if(i==0 && strNoneType>0)
                {
                    id=strNoneID;
                    if(strReturnNoneText==0)
                        name='';
                    tat='';
                    setcal='';
                }
                flag=true;
                break;
            }
        } //end for
        if(!flag)
        {
            if(len<=0)
            {
                removeIFrame(CurrentPickListId);
            }
            else
            {
                alert(NO_PROCESS_SELECTED);
                return false;
            }   
        }
        else
        {
            try{
                if(strTextFieldID.length>0)
                window.parent.document.getElementById(strFormID + ":" + strTextFieldID).value=name;
                if(strIDFieldID.length>0)
                window.parent.document.getElementById(strFormID + ":" + strIDFieldID).value=id;
                if(strTextHidden.length>0){
                if(Trim(name).indexOf(" ") != "-1" )
                window.parent.document.getElementById(strFormID + ":" + strTextHidden).value=name.substring(0,name.indexOf(" "));
                else
                window.parent.document.getElementById(strFormID + ":" + strTextHidden).value=Trim(name);
                }
                if(strtat.length>0)
                    window.parent.document.getElementById(strFormID + ":" + strtat).value=tat;
                if(strcalflag.length>0)
                    window.parent.document.getElementById(strFormID + ":" + strcalflag).value=setcal;
                if(strCallback.length>0 && Trim(strCallback).length>0)
                {
                    var Temp='window.parent.' + strCallback + '();';
                    eval(Temp);        
                }
               removeIFrame(CurrentPickListId);
              }catch(e){}
              	
        }

    }
    
  </Script>
</head>
<body class="PMbgcolorTransparent" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" onload="setPicklistFocus();addHandle(document.getElementById('ProcessPickList:toolbar'), window);" onunload='closeWindows();closePicklistWindows(CurrentPickListId);return false;' >
    
<h:panelGrid width="100%" cellpadding="0" cellspacing="0" border="0" styleClass="PMPageBackground" style="border-collapse:collapse;border:1px solid #bbb9b9;">
<h:form id="ProcessPickList">
<f:verbatim>
     <input type="hidden" name="PM_UID" value="<%=pm_uid%>">
</f:verbatim>
<h:panelGrid columns="3" id="toolbar" cellpadding="0" cellspacing="0" style="border:0;border-bottom: solid 1px #989898;" columnClasses="PMWIDTH65,PMWIDTH5,PMWIDTH30RIGHT" width="100%">
    <h:outputLabel value="#{PMGEN.PROCESS_PICKLIST}" styleClass="EWLabel1B" style="width:100%;padding-left:3px;"/>
    <h:panelGroup>
        <h:inputHidden id="hid_FirstField" value="#{wfProcessList.m_strFirstField}"/>
        <h:inputHidden id="hid_LastField" value="#{wfProcessList.m_strLastField}"/>
        <h:inputHidden id="hid_FirstFieldIndex" value="#{wfProcessList.m_strFirstFieldIndex}"/>
        <h:inputHidden id="hid_LastFieldIndex" value="#{wfProcessList.m_strLastFieldIndex}"/>
        <h:inputHidden id="hid_Action" value="#{wfProcessList.m_iAction}"/>
        <h:inputHidden id="hid_NoneType" value="#{wfProcessList.m_iNoneDisplay}"/>
        <h:inputHidden id="hid_NoneID" value="#{wfProcessList.m_strNoneID}"/>
        <h:inputHidden id="hid_QueueName" value="#{wfProcessList.m_strQueueName}"/>
        <h:inputHidden id="hid_QueueId" value="#{wfProcessList.m_strQueueID}"/>
        <h:inputHidden id="hid_stateflag" value="#{wfProcessList.m_strStateFlag}"/>
        <h:inputHidden id="hid_latestversionFlag" value="#{wfProcessList.m_strLatestVersionFlag}"/>
        <h:inputHidden id="hid_processprefix" value="#{wfProcessList.m_strProcessPrefix}"/>

        <f:verbatim><input type=Hidden id="CustomRights" name="CustomRights" value='</f:verbatim><h:outputText value="#{param.CustomRights}"/><f:verbatim>'/></f:verbatim>
        <f:verbatim><input type=Hidden id="strFormFieldText" name="strFormFieldText" value='</f:verbatim><h:outputText value="#{param.strFormFieldText}"/><f:verbatim>'/></f:verbatim>
        <f:verbatim><input type=Hidden id="strFormFieldID" name="strFormFieldID" value='</f:verbatim><h:outputText value="#{param.strFormFieldID}"/><f:verbatim>'/></f:verbatim>
        <f:verbatim><input type=Hidden id="strFormID" name="strFormID" value='</f:verbatim><h:outputText value="#{param.strFormID}"/><f:verbatim>'/></f:verbatim>
        <f:verbatim><input type=Hidden id="strFormFieldTextHidden" name="strFormFieldTextHidden" value='</f:verbatim><h:outputText value="#{param.strFormFieldTextHidden}"/><f:verbatim>'/></f:verbatim>
        <f:verbatim><input type=Hidden id="tat" name="tat" value='</f:verbatim><h:outputText value="#{param.tat}"/><f:verbatim>'/></f:verbatim>
        <f:verbatim><input type=Hidden id="ReturnNoneValue" name="ReturnNoneValue" value='</f:verbatim><h:outputText value="#{param.ReturnNoneValue}"/><f:verbatim>'/></f:verbatim>
        <f:verbatim><input type=Hidden id="NoneType" name="NoneType" value='</f:verbatim><h:outputText value="#{param.NoneType}"/><f:verbatim>'/></f:verbatim>
        <f:verbatim><input type=Hidden id="NoneValue" name="NoneValue" value='</f:verbatim><h:outputText value="#{param.NoneValue}"/><f:verbatim>'/></f:verbatim>
        <f:verbatim><input type=Hidden id="CallBack" name="CallBack" value='</f:verbatim><h:outputText value="#{param.CallBack}"/><f:verbatim>'/></f:verbatim>
        <f:verbatim><input type=Hidden id="QueueName" name="QueueName" value='</f:verbatim><h:outputText value="#{param.QueueName}"/><f:verbatim>'/></f:verbatim>
        <f:verbatim><input type=Hidden id="QueueId" name="QueueId" value='</f:verbatim><h:outputText value="#{param.QueueId}"/><f:verbatim>'/></f:verbatim>
        <f:verbatim><input type=Hidden id="stateflag" name="stateflag" value='</f:verbatim><h:outputText value="#{param.stateflag}"/><f:verbatim>'/></f:verbatim>
        <f:verbatim><input type=Hidden id="usecal" name="usecal" value='</f:verbatim><h:outputText value="#{param.usecal}"/><f:verbatim>'/></f:verbatim>  
        <f:verbatim><input type=Hidden id="latestversionFlag" name="latestversionFlag" value='</f:verbatim><h:outputText value="#{param.latestversionFlag}"/><f:verbatim>'/></f:verbatim>
        <f:verbatim><input type=Hidden id="processprefix" name="processprefix" value='</f:verbatim><h:outputText value="#{param.processprefix}"/><f:verbatim>'/></f:verbatim>
    </h:panelGroup>
    <h:graphicImage title="#{PMGEN.BUTTON_CLOSE}" url="../omniflow/images/close_img.gif" onclick="removeIFrame(CurrentPickListId);" style="CURSOR: pointer;border:0;"/>   
</h:panelGrid>                 
<h:panelGrid styleClass="PMbgcolorWhite" width="100%" cellpadding="0" cellspacing="0" border="0"  >

<h:panelGrid columns="2" border="0" cellspacing="" columnClasses="PMWIDTH35,PMWIDTH65" cellpadding="2" width="100%" >
    <h:outputText style="width:100%"  value="#{PMGEN.SEARCH_ONFILTER}" styleClass="EWLabel1"/>
    <h:panelGroup>
        <h:panelGrid columns="2" border="0" cellspacing="2" columnClasses="PMWIDTH90,PMWIDTH10" cellpadding="0" width="100%">
            <h:inputText  style="width:100%" styleClass="PMControlText" id="Processfilter" value="#{wfProcessList.m_strProcessPrefix}" onkeydown="handlePickListEnter(event,'ProcessPickList:cmdlink_Search');"/>
            <h:commandLink styleClass="EWEnabledLink" id="cmdlink_Search" action="#{wfProcessList.searchonfilter}" >
                <h:graphicImage alt="#{PMGEN.TITLE_SEARCH}" style="border:0" url="../omniflow/#{PMGEN.Path}images/go.gif"> </h:graphicImage>
            </h:commandLink>
        </h:panelGrid>
    </h:panelGroup>
</h:panelGrid>


<%//Displaying the error message if any%>

<h:panelGrid columns="1" cellpadding="0" cellspacing="0" columnClasses="PMWIDTH100CENTER" width="100%"  styleClass="PMMessageBorder" >
    <h:panelGroup rendered="#{wfProcessList.m_bError}">
        <h:graphicImage  alt="" onclick="" style="border:0;vertical-align:middle" url="../omniflow/images/errorimage.gif"> </h:graphicImage>
        <h:outputText value="." style="width:1%;visibility:hidden"/>
        <h:outputText id="Error" value="#{wfProcessList.m_strErrorMessage}" styleClass="PMErrorMessage" />
    </h:panelGroup>
</h:panelGrid>

<h:panelGrid columns="1" border="0" cellspacing="3" columnClasses="PMWIDTH100CENTERTOP" cellpadding="3" width="100%" rendered="#{!wfProcessList.m_bError}">
    <h:selectOneListbox size="10" binding="#{wfProcessList.m_Misc}" styleClass="PMWIDTH190PIXELFORPICKLIST" ondblclick="setValue();" id="picklist"  value="" onkeydown="handlePickListEnter(event);">
        <f:selectItems value="#{wfProcessList.m_objProcessList}"/>
    </h:selectOneListbox> 
</h:panelGrid>
<h:panelGrid columns="1" border="0" cellspacing="3" columnClasses="PMWIDTH100" cellpadding="3" width="100%" rendered="#{wfProcessList.m_bError}">
    <h:selectOneListbox size="8"  styleClass="PMControlText"  id="picklist1" style="width:100%" value="">            
    </h:selectOneListbox> 
</h:panelGrid>

<h:panelGrid columns="5" border="0" cellspacing="0"  columnClasses="PMWIDTH20,PMWIDTH20,PMWIDTH20,PMWIDTH20RIGHT,PMWIDTH20RIGHT" cellpadding="0" width="100%" rendered="#{!wfProcessList.m_bError}">
    <h:outputText  style="width:100%" value="  "/>
    <h:outputText  style="width:100%" value="  "/>
    <h:outputText  style="width:100%" value="  "/>
    <h:panelGroup>
        <h:commandLink styleClass="EWEnabledLink" id="cmdlink_Previous" action="#{wfProcessList.previous}" tabindex="#{wfProcessList.m_strTabIndexForPrevious}"><%--for bug id 671--%>
            <h:graphicImage  alt="#{PMGEN.BUTTON_PREVIOUS}" style="border:0" url="../omniflow/#{PMGEN.Path}images/prev.gif" rendered="#{wfProcessList.m_bEnablePreviousButton}"> </h:graphicImage>
        </h:commandLink>
        <h:graphicImage alt="#{PMGEN.BUTTON_PREVIOUS}" style="border:0" url="../omniflow/#{PMGEN.Path}images/prev_dis.gif" rendered="#{!wfProcessList.m_bEnablePreviousButton}"> </h:graphicImage>
    </h:panelGroup>
    <h:panelGroup>
        <h:commandLink styleClass="EWEnabledLink" id="cmdlink_Next" action="#{wfProcessList.next}" tabindex="#{wfProcessList.m_strTabIndexForNext}"><%--for bug id 671--%>
            <h:graphicImage  alt="#{PMGEN.BUTTON_NEXT}" style="border:0" url="../omniflow/#{PMGEN.Path}images/next.gif" rendered="#{wfProcessList.m_bEnableNextButton}"> </h:graphicImage>
        </h:commandLink>
        <h:graphicImage alt="#{PMGEN.BUTTON_NEXT}" style="border:0" url="../omniflow/#{PMGEN.Path}images/next_dis.gif" rendered="#{!wfProcessList.m_bEnableNextButton}"> </h:graphicImage>
    </h:panelGroup>
</h:panelGrid>
</h:panelGrid>
</h:form>

</h:panelGrid>

</body>
</html>
</f:view>
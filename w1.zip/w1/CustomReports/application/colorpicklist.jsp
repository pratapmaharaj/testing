<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: colorpicklist.jsp
Author                          : Bhupesh Kumar
Date written (DD/MM/YYYY)       : 21/Apr/2009
Description			: This file shows the color picklist
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
24/04/2009      Bhupesh Kumar           (PRM_7.1_015)Option for adding rule defination on queue Aliases to display in different color/images in worklist.
23/08/2011      Anushree Jain		    Bug 27971 Security issue
15/10/2014      Jaseem Ansari           Bug 50790 - Wrong iframes are getting opened in process variable mapping
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--%>
<%@ page import="java.io.*"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h" %>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f" %>
<%@ page contentType="text/html; charset=UTF-8" %>
<%@ include file="/application/commonheader.process"%>
<f:view>
  <f:loadBundle basename="pmgen" var="PMGEN"/>
 <f:loadBundle basename="pmerrorcodes" var="PMERROR"/>
    <html dir='<h:outputText value="#{PMGEN.HTML_DIR}"/>'>
        <head>
            <title>
                <h:outputText value="#{PMGEN.OMNIFLOW_DESC_TEXT_1}[#{PMGEN.TITLE_PICKIST}]" />
            </title>
            <link href='../omniflow/<h:outputText value="#{PMGEN.Path}"/>css/docstyle.css' rel="stylesheet" type="text/css">
            <script  src='../omniflow/<h:outputText value="#{PMGEN.Path}"/>scripts/constants.js'></script>
            <script  src="../omniflow/scripts/toolbar.js"></script>
            <script  src="../omniflow/scripts/wfgeneral.js"></script>
            <script  src="../omniflow/scripts/dragiframe.js"></script>
            <script  src="../omniflow/scripts/pickList.js"></script>
            <script  src="../omniflow/scripts/aliasrule.js"></script>
            <Script LANGUAGE="Javascript">
    var allWindows = new Array();
    var allPicklistWindows=new Array();
    var CurrentPickListId="ColorPicklist";
    var localizedPath='<h:outputText value="#{PMGEN.Path}"/>';    
    var TargetDispId = '<h:outputText value="#{param.TargetDispId}"/>';
    var TargetHidId='<h:outputText value="#{param.TargetHidId}"/>';
    function PopulateColors()    
    {
    var colors = new Array("#000000","#000033","#000066","#000099","#0000CC","#0000FF","#330000","#330033","#330066","#330099","#3300CC",
							"#3300FF","#660000","#660033","#660066","#660099","#6600CC","#6600FF","#990000","#990033","#990066","#990099",
							"#9900CC","#9900FF","#CC0000","#CC0033","#CC0066","#CC0099","#CC00CC","#CC00FF","#FF0000","#FF0033","#FF0066",
							"#FF0099","#FF00CC","#FF00FF","#003300","#003333","#003366","#003399","#0033CC","#0033FF","#333300","#333333",
							"#333366","#333399","#3333CC","#3333FF","#663300","#663333","#663366","#663399","#6633CC","#6633FF","#993300",
							"#993333","#993366","#993399","#9933CC","#9933FF","#CC3300","#CC3333","#CC3366","#CC3399","#CC33CC","#CC33FF",
							"#FF3300","#FF3333","#FF3366","#FF3399","#FF33CC","#FF33FF","#006600","#006633","#006666","#006699","#0066CC",
							"#0066FF","#336600","#336633","#336666","#336699","#3366CC","#3366FF","#666600","#666633","#666666","#666699",
							"#6666CC","#6666FF","#996600","#996633","#996666","#996699","#9966CC","#9966FF","#CC6600","#CC6633","#CC6666",
							"#CC6699","#CC66CC","#CC66FF","#FF6600","#FF6633","#FF6666","#FF6699","#FF66CC","#FF66FF","#009900","#009933",
							"#009966","#009999","#0099CC","#0099FF","#339900","#339933","#339966","#339999","#3399CC","#3399FF","#669900",
							"#669933","#669966","#669999","#6699CC","#6699FF","#999900","#999933","#999966","#999999","#9999CC","#9999FF",
							"#CC9900","#CC9933","#CC9966","#CC9999","#CC99CC","#CC99FF","#FF9900","#FF9933","#FF9966","#FF9999","#FF99CC",
							"#FF99FF","#00CC00","#00CC33","#00CC66","#00CC99","#00CCCC","#00CCFF","#33CC00","#33CC33","#33CC66","#33CC99",
							"#33CCCC","#33CCFF","#66CC00","#66CC33","#66CC66","#66CC99","#66CCCC","#66CCFF","#99CC00","#99CC33","#99CC66",
							"#99CC99","#99CCCC","#99CCFF","#CCCC00","#CCCC33","#CCCC66","#CCCC99","#CCCCCC","#CCCCFF","#FFCC00","#FFCC33",
							"#FFCC66","#FFCC99","#FFCCCC","#FFCCFF","#00FF00","#00FF33","#00FF66","#00FF99","#00FFCC","#00FFFF","#33FF00",
							"#33FF33","#33FF66","#33FF99","#33FFCC","#33FFFF","#66FF00","#66FF33","#66FF66","#66FF99","#66FFCC","#66FFFF",
							"#99FF00","#99FF33","#99FF66","#99FF99","#99FFCC","#99FFFF","#CCFF00","#CCFF33","#CCFF66","#CCFF99","#CCFFCC",
							"#CCFFFF","#FFFF00","#FFFF33","#FFFF66","#FFFF99","#FFFFCC","#FFFFFF");
	var total = colors.length;
	var width = 18;
	var cp_contents = "";	
	
	cp_contents += "<TABLE BORDER=1 CELLSPACING=1 CELLPADDING=0 width='100%'>";
	var use_highlight = (document.getElementById || document.all)?true:false;
	for (var i=0; i<total; i++) {
		if ((i % width) == 0) { cp_contents += "<TR>"; }
		if (use_highlight) { var mo = 'onMouseOver="ColorPicker_highlightColor(\''+colors[i]+'\',window.document)"'; }
		else { mo = ""; }
		cp_contents += '<TD BGCOLOR="'+colors[i]+'"><FONT SIZE="-3"><A HREF="#" onClick="ColorPicker_pickColor(\''+colors[i]+'\');return false;" '+mo+' STYLE="text-decoration:none;">&nbsp;&nbsp;&nbsp;</A></FONT></TD>';
		if ( ((i+1)>=total) || (((i+1) % width) == 0)) { 
			cp_contents += "</TR>";
			}
		}
	// If the browser supports dynamically changing TD cells, add the fancy stuff
	if (document.getElementById) {
		var width1 = Math.floor(width/2);
		var width2 = width = width1;
		cp_contents += "<TR><TD COLSPAN='"+width1+"' BGCOLOR='#ffffff' ID='colorPickerSelectedColor'>&nbsp;</TD><TD COLSPAN='"+width2+"' ALIGN='CENTER' ID='colorPickerSelectedColorValue' CLASS='PMControlText'>#FFFFFF</TD></TR>";
		}
	cp_contents += "</TABLE>";        
        document.getElementById("colorcontainer").innerHTML = cp_contents;
    }
    
    function ColorPicker_pickColor(color) {	
	pickColor(color);
	}
        
        // This function runs when you move your mouse over a color block, if you have a newer browser
        function ColorPicker_highlightColor(c) {
	var thedoc = (arguments.length>1)?arguments[1]:window.document;
	var d = thedoc.getElementById("colorPickerSelectedColor");
	d.style.backgroundColor = c;
	d = thedoc.getElementById("colorPickerSelectedColorValue");
	d.innerHTML = c;
	}
    
    function pickColor(color)
    {        
            try
            {
            window.parent.document.getElementById(TargetHidId).value=color; 
            }catch(e){}
            try
            {
            window.parent.document.getElementById(TargetDispId).style.backgroundColor=color;
            }catch(e){}
            
            removeIFrame(CurrentPickListId);            
        
    }
            </Script>
        </head>
       <body class="PMbgcolorTransparent" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" onload="PopulateColors();setPicklistFocus();addHandle(document.getElementById('toolbar'), window);" onunload='closeWindows();closePicklistWindows(CurrentPickListId);return false;' >
    
            <h:panelGrid width="100%" cellpadding="0" cellspacing="0" border="0" styleClass="PMPageBackground" style="border-collapse:collapse;border:1px solid #bbb9b9;">                
                     <h:panelGrid columns="2" id="toolbar" cellpadding="0" cellspacing="0" style="border:0;border-bottom: solid 1px #989898;" columnClasses="PMWIDTH70,PMWIDTH30RIGHT" width="100%">
                        <h:outputLabel value="#{PMGEN.COLOR_PICKIST}" styleClass="EWLabel1B" style="width:100%;padding-left:3px;"/>
                        <h:graphicImage title="#{PMGEN.BUTTON_CLOSE}" url="../omniflow/images/close_img.gif" onclick="removeIFrame(CurrentPickListId);" style="CURSOR: pointer;border:0;"/>
                    </h:panelGrid>
                    
                <h:panelGrid cellpadding="0" cellspacing="0" border="0" width="100%">
                        <h:panelGroup>
                            <f:verbatim>
                                <div id="colorcontainer">
                                
                                </div>
                            </f:verbatim>
                        </h:panelGroup>
                        
                    </h:panelGrid>
                
            </h:panelGrid>
        </body>
    </html>
</f:view>

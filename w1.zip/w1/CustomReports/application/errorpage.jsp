<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: errorpage.jsp
Author                          : Ajith Jacob
Date written (DD/MM/YYYY)       : 9/Jan/2007
Description			: This file contains the error page
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
(DD/MM/YYYY)
24/04/2009          Vijay Kumar         PRM_8.0_003(SSO Work)
24/06/2009          Vijay Kumar         PRM_8.0_009(Security Issue)
17/06/2011          Sri Prakash         Bug 27268 (SaaS Support ( cabinet creation through URL, redirect on logout))
23/08/2011      Anushree Jain		    Bug 27971 Security issue
19/06/2014             Jaseem Ansari      Bug 46779  An unauthorized user is able to access the link for which he is not authorized.Set EXport Info and Audit log configuration link should be accessed only by admin user.
10/07/2014             Jaseem Ansari           Bug 46906 - All the request in omniflow containing wd_uid as a parameter should be sent as a post request
06/05/2015      Ashutosh Pandey         Bug 55112 - If cabinet is not registered and process manager is launched from BAM, proper error message will be display
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--%>
<%@ page import="java.io.*" isErrorPage="true"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h" %>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f" %>
<%@ page contentType="text/html; charset=UTF-8" %>
<%@ page import="java.util.*" %>
<%@ include file="/application/commonheader.process"%>
<f:view>
<f:loadBundle basename="pmgen" var="PMGEN"/>
<f:loadBundle basename="pmerrorcodes" var="PMERROR"/>
<%

  Map bundleValues = null;
  bundleValues = (Map)request.getAttribute("PMERROR");
  String message="";
  String AjaxMessage="";
  String strHeading="";
  String timeStamp = request.getParameter("TimeStamp");
  long end = System.currentTimeMillis();
  long start = 0;
  if (timeStamp != null && !timeStamp.equals("")) {
        start = Long.parseLong(timeStamp);
  }
  long diff = end - start;
  if(diff>100000){
      AjaxMessage=(String)bundleValues.get("4021");
      message=AjaxMessage;

      }
  else{
  if(request.getParameter("HeadingID")!=null)
    strHeading=(String)bundleValues.get(request.getParameter("HeadingID"));
    
  if(request.getParameter("heading")!=null)
    strHeading=request.getParameter("heading");

  if(request.getParameter("msg")!=null)
    message=request.getParameter("msg");
  
    if(request.getParameter("msgID")!=null)
    {
        message=(String)bundleValues.get(request.getParameter("msgID"));
        if (request.getParameter("msgID").equals("-10001")) {
            if (request.getParameter("Cabinet") != null) {
                message += " (" + request.getParameter("Cabinet") + ")";
            }
        }
        //if(request.getParameter("msgID").equalsIgnoreCase("4021"))//inavlid request error
            AjaxMessage=message;
			}
        else{

            AjaxMessage = strHeading;
    }
  }
%>
<html dir='<h:outputText value="#{PMGEN.HTML_DIR}"/>'>
<head>
<title>
<h:outputText value="#{PMGEN.OMNIFLOW_DESC_TEXT_1}[#{PMGEN.TITLE_FOR_ERRORPAGE}]" />
</title>
<link href='../omniflow/<h:outputText value="#{PMGEN.Path}"/>css/docstyle.css' rel="stylesheet" type="text/css">
<script  src="../omniflow/scripts/toolbar.js"></script>
<script  src="../omniflow/scripts/wfgeneral.js"></script>
<Script LANGUAGE="Javascript">     
    var allWindows = new Array();
    var localizedPath='<h:outputText value="#{PMGEN.Path}"/>';
</Script>
</head>
<body topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" onunload='closeWindows();return false;'>
<h:form id="ErrorPage">
<f:verbatim>
     <input type="hidden" name="PM_UID" value="<%=pm_uid%>">
</f:verbatim>
<Div STYLE="display:none" id='PM_ERROR_PAGE_12345_DIV'><%=AjaxMessage%></Div>
<jsp:include page="../application/pmheader.jsp">
    <jsp:param name="Heading" value="<%=strHeading%>"/>
    <jsp:param name="HelpURL" value="Process_Manager.htm"/>
</jsp:include>
        <h:panelGrid width="100%" cellpadding="0" cellspacing="0" border="0" style="background-image: url('../omniflow/images/white_u.gif');">
                <h:panelGroup>
                    <f:verbatim>
                        <table width="100%" height="60%">
                        <tr>
                        <td align=center width="100%">
                    </f:verbatim>
                    <h:outputText value="" styleClass="PMErrorMessage" style="width:100%"/>
                    <f:verbatim>
                </td>
            </tr>
            <tr>
                <td align=center width="100%">
                    
                    <table>
                        <tr>
                            <td align=center width="100%">
                            </td>
                        </tr>
                        <tr>
                            <td style="white-space: nowrap;">
                                <img src="../omniflow/images/errorimage.gif" style="border:0;vertical-align:middle"><span style="width:1%;visibility:hidden">.</span><span class="PMErrorMessage"><%=message%></span>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    <table width="100%">
        <tr>	
            <td align=center width="100%">
                </f:verbatim>
                     <h:panelGroup rendered="#{param.msgID ne '4021' }">
                        <f:verbatim>                
                            <p align="center">
                                <hr class="PMColorOrange" width="80%" noshade >
                            </p>
                           
                            <p align="center">
                            <big><big><b><font class="PMColorOrange" >[</font></b> </big></big>
                        </f:verbatim>
                        <h:outputText styleClass="PMLabel" style="align:center" value=" #{PMERROR.FOR_SECURITY_REASON_WE_SUGGEST_YOU_TO_CLOSE_THIS_WINDOW} " />
                        <f:verbatim>

                            <big><big><b><font class="PMColorOrange" >]</font></b> </big></big>
                            </p>
                            
                        </f:verbatim>
                    </h:panelGroup>
                <%-- <h:commandButton title="#{PMGEN.BUTTON_OK}" image="../omniflow/#{PMGEN.Path}images/ok.gif" type="button" styleClass="PMButton" onclick="window.close();return false;"/> --%>
                <f:verbatim>
            </td>
        </tr>
    </table>	
    </f:verbatim>
    </h:panelGroup>
    </h:panelGrid>
</h:form>	
</body>

</html>

</f:view>
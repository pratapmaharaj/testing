<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: pmheader.jsp
Author                          : Ajith Jacob
Date written (DD/MM/YYYY)       : 10/Jan/2007
Description			: This file contains the general purpose page header
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
(DD/MM/YYYY)
27 April 2007   Puneet Pahuja            Bug id 666 (rendered property added with output link)
06 Aug 2008     Arup Sharma              BUG ID PRM_8.0_014 (For Time Zone)
05/10/2009      Himshikha               BUG ID PRM_8.0_017 (To restrict F5 and backspase)
09/02/2012      Sri Prakash             Bug 30451 - Logo Name should be cabinet specific in processmanager
13/06/1992      Dinesh Verma            Bug 46653 - Support of IE11 in ProcessManager
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h" %>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f" %>
<%@ page contentType="text/html"%>
<%@ page pageEncoding="UTF-8"%>
<%@ page import="java.util.*" %>
<f:loadBundle basename="pmgen" var="PMGEN"/>
<f:verbatim>
<script>
    var UniqueUserId= '</f:verbatim><h:outputText value="#{wfSession.m_strUniqueUserId}"/><f:verbatim>';
    var bEnableTimeZone = '</f:verbatim><h:outputText value="#{wfSession.m_bEnableTimeZone}"/><f:verbatim>';
    var iServerTimeDiff = '</f:verbatim><h:outputText value="#{wfSession.m_iServerTZDiff}"/><f:verbatim>';
    var iClientTimeDiff = '</f:verbatim><h:outputText value="#{wfSession.m_iClientTZDiff}"/><f:verbatim>';
    if (typeof window.event != 'undefined'){ // IE
            document.onkeydown = function() // IE
            {
                var t=event.srcElement.type;
                var kc=event.keyCode;
                if (kc == 116) {
                    window.event.keyCode = 0;         
                    return false;
                }
                else
                    return ((kc != 8 ) || ( t == 'text') || (t == 'textarea') || ( t == 'submit') ||  (t == 'password'))
            }
        }
        else{
            document.onkeypress = function(e)  // FireFox/Others 
            {
                var t=e.target.type;
                var kc=e.keyCode;
                if(kc == 116 && navigator.userAgent.toLowerCase().indexOf("firefox") > -1) {
                    e.cancelBubble = true;
                    return false;
                }
                else if ((kc != 8) || ( t == 'text' ) || (t == 'textarea') || ( t == 'submit') || (t == 'password'))
                    return true;
                else 
                    return false;
           }
        }
</script>
</f:verbatim>
<h:inputHidden id="hidHelpURL" value="../omniflow/#{PMGEN.Path}help/webhelp/#{param.HelpURL}"/>

<h:panelGrid columns="1" columnClasses="PMWIDTH100RIGHT" cellpadding="0" cellspacing="0" dir="#{PMGEN.HTML_DIR}" width="100%">
  <h:graphicImage rendered="#{wfSession.m_bValidSession}" alt="#{PMGEN.OMNIFLOW_DESC_TEXT_1}" url="../omniflow/#{PMGEN.Path}images/#{wfSession.strLogoName}"></h:graphicImage>
  <h:graphicImage rendered="#{!wfSession.m_bValidSession}" alt="#{PMGEN.OMNIFLOW_DESC_TEXT_1}" url="../omniflow/#{PMGEN.Path}images/logo.jpg"></h:graphicImage>
  </h:panelGrid>

<h:panelGrid columns="3" dir="#{PMGEN.HTML_DIR}" columnClasses="PMWIDTH5,PMWIDTH100,PMWIDTH5" cellpadding="0" cellspacing="0" border="0" style="background-image: url('../omniflow/images/middle.gif');">
    <h:graphicImage  value="../omniflow/images/bar_#{PMGEN.LEFT}.gif"></h:graphicImage>
    <h:panelGrid border="0" columns="2" width="100%" columnClasses="PMWIDTH100,PMWIDTH5">
        <h:outputLabel id="PgHeading" value="#{param.Heading}" styleClass="PMWindowTitle" style="white-space:nowrap;"/>
        <h:panelGroup>
            <h:panelGrid border="0" columns="7" cellpadding="0" cellspacing="0" columnClasses="PMAlignRight">
                
                <h:panelGrid border="0" columns="1" cellpadding="0" cellspacing="0" rendered="#{wfHeader.m_bRenderLinkedWorkitemButton}">
                    <h:outputLink styleClass="PMNOUNDERLINE" rendered="#{wfHeader.m_bRenderLinkedWorkitemButton}">
                        <h:outputLabel id="cmdlink_LinkedWorkitem" value="#{PMGEN.LINKED_WORKITEM}" onclick="ShowLinkedWorkitem();return false;" rendered="#{wfHeader.m_bRenderLinkedWorkitemButton}" styleClass="PMLTGreen" style="white-space: nowrap;"><%--for bug id 666--%>
                        </h:outputLabel>
                    </h:outputLink>               
                </h:panelGrid>
                
                <h:graphicImage  value="../omniflow/images/sep.gif" rendered="#{wfHeader.m_bRenderLinkedWorkitemButton}"></h:graphicImage>
                
                <h:panelGrid border="0" columns="1" cellpadding="0" cellspacing="0" rendered="#{wfHeader.m_bRenderSaveButton}">
                    <h:outputLink styleClass="PMNOUNDERLINE" rendered="#{wfHeader.m_bRenderSaveButton}">
                        <h:outputLabel id="cmdlink_TitleSave" value="#{PMGEN.SAVE}" onclick="SaveThisPage();return false;" rendered="#{wfHeader.m_bRenderSaveButton}" styleClass="PMLTGreen" style="white-space: nowrap;"><%--for bug id 666--%>
                        </h:outputLabel>
                    </h:outputLink>                
                </h:panelGrid>
                
                
                <h:graphicImage  value="../omniflow/images/sep.gif" rendered="#{wfHeader.m_bRenderSaveButton}"></h:graphicImage>
                
                <h:panelGrid border="0" columns="1" cellpadding="0" cellspacing="0" rendered="#{wfHeader.m_bRenderPrintButton}">
                    <h:outputLink styleClass="PMNOUNDERLINE" rendered="#{wfHeader.m_bRenderPrintButton}">
                        <h:outputLabel id="cmdlink_TitlePrint" value="#{PMGEN.PRINT}" onclick="PrintThisPage();return false;" rendered="#{wfHeader.m_bRenderPrintButton}" styleClass="PMLTGreen" style="white-space: nowrap;"><%--for bug id 666--%>
                        </h:outputLabel>
                    </h:outputLink>                
                </h:panelGrid>
                
                <h:graphicImage  value="../omniflow/images/sep.gif" rendered="#{wfHeader.m_bRenderPrintButton}"></h:graphicImage>
                
                <h:panelGrid border="0" columns="1" cellpadding="0" cellspacing="0" rendered="#{wfHeader.m_bRenderHelpButton}">
                    <h:outputLink styleClass="PMNOUNDERLINE" rendered="#{wfHeader.m_bRenderHelpButton}">
                        <h:outputLabel id="cmdlink_TitleHelp" value="#{PMGEN.HELP}" onclick="ShowHelpFromPage(this,'hidHelpURL');return false;" rendered="#{wfHeader.m_bRenderHelpButton}" styleClass="PMLTGreen" style="white-space: nowrap;"><%--for bug id 666--%>            
                        </h:outputLabel>
                    </h:outputLink>                
                </h:panelGrid>
                
            </h:panelGrid>
        </h:panelGroup>
    </h:panelGrid>
    <h:graphicImage value="../omniflow/images/bar_#{PMGEN.RIGHT}.gif"></h:graphicImage>
</h:panelGrid>
<h:panelGrid columns="3" width="100%" dir="#{PMGEN.HTML_DIR}" columnClasses="PMWIDTH5,PMWIDTH100,PMWIDTH5" cellpadding="0" cellspacing="0" border="0" style="background-image: url('../omniflow/images/white_b.gif');">
    <h:graphicImage  value="../omniflow/images/white_l.gif"></h:graphicImage>
    <h:outputLabel value=""/>
    <h:graphicImage  value="../omniflow/images/white_r.gif"></h:graphicImage>
</h:panelGrid>
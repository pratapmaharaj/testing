<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Genesis
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: error.jsp
Author                          : Bhupesh Kumar
Date written (DD/MM/YYYY)       : 27/03/2014
Description			: This file is used to open login page of application .
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
(DD/MM/YYYY)
 
27/03/2014      Bhupesh kumar           Bug 44069 - In case of SSO need to block login page of processmanager 
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--%>

<%@taglib prefix="f" uri="http://java.sun.com/jsf/core"%>
<%@taglib prefix="h" uri="http://java.sun.com/jsf/html"%>
<f:loadBundle basename="pmgen" var="PMGEN" />
<html>
       <f:view>
	<head>
	<title><h:outputText value="#{PMGEN.NOT_AUTHORIZE_TO_VIEW}"></h:outputText></title>
	<link href='../omniflow/<h:outputText value="#{PMGEN.Path}"/>css/docstyle.css' rel="stylesheet" type="text/css">
	</head>
     
	<body marginheight="0" marginwidth="0" topmargin="0" leftmargin="0" >

            <table width=100% border="0" cellspacing="0" cellpaddingadding="0" style="margin-top:0px;">
            <tr>
                    <td width=100% background="/webtop/images/white_u.gif">
                        <br>
                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td align="right"  width="100%"><img src="../omniflow/images/logo.jpg"></td>
                            </tr>
                            <tr><td>&nbsp;</td></tr>

                            <tr>
                                <td width="100%"><hr  >
                                </td>
                            </tr>
                            <tr>
                                <td width="90%">
                                </td>
                            </tr>
                        </table>  
                        <p class="EWErrorMessage"><h:outputLabel value="#{PMGEN.NOT_AUTHORIZE_TO_VIEW}"></h:outputLabel>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </p>

                    </td>
                </tr>
            </table>
	</body>
       
	</html>
         </f:view>

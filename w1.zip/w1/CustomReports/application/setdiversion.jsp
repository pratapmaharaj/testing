 <%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: main.jsp
Author                          : Puneet Pahuja
Date written (DD/MM/YYYY)       : 10/Oct/2007
Description			: This file contains the main application window
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
(DD/MM/YYYY)
16 Dec 2010     Bhupesh kumar/Jaseem    PRM_8.0_057:Required SetDiversion option in webdesktop
23/08/2011      Anushree Jain		Bug 27971 Security issue
 13/06/1992     Dinesh Verma            Bug 46653 - Support of IE11 in ProcessManager
03/11/2015		Jaseem Ansari			Bug 57708 - Removing the IP Adress and Port from the omnidcs urls in Processmanager
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--%>
<%@page contentType="text/html"%>
<%@page pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsf/core" prefix="f"%>
<%@taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@page import="com.newgen.wfdesktop.session.*,java.util.*" %>
<%@ include file="/application/commonheader.process"%>
 <f:view>
     <f:loadBundle basename="pmgen" var="PMGEN"/>
     <f:loadBundle basename="pmerrorcodes" var="PMERROR"/>
<html dir='<h:outputText value="#{PMGEN.HTML_DIR}"/>'>
    <head>
	<link href='../omniflow/<h:outputText value="#{PMGEN.Path}"/>css/docstyle.css' rel="stylesheet" type="text/css">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><h:outputText value="#{PMGEN.OMNIFLOW_DESC_TEXT_1}" /></title>
        <script  src='../omniflow/<h:outputText value="#{PMGEN.Path}"/>scripts/constants.js'></script>
        <script  src="../omniflow/scripts/wfgeneral.js"></script>
	<script  src="../omniflow/scripts/toolbar.js"></script>
        <script  src="../omniflow/scripts/view.js"></script>
        <script  src="../omniflow/scripts/net.js"></script>
        <script  src="../omniflow/scripts/main.js"></script>
        <script  src="../omniflow/scripts/reportsgeneral.js"></script>   
         <script  src="../omniflow/scripts/history.js"></script>
         <script  src="../omniflow/scripts/reports.js"></script>
         <script  src="../omniflow/scripts/adminoptions.js"></script>
         <script  src="../omniflow/scripts/search.js"></script>
         <script  src="../omniflow/scripts/date.js"></script>
         <script  src="../omniflow/scripts/dragiframe.js"></script>
         <script  src="../omniflow/scripts/queueprocessauth.js"></script>
         <script  src="../omniflow/scripts/exportcabinet.js"></script>
         <script  src="../omniflow/scripts/purge_criteria.js"></script>
         <script  src="../omniflow/scripts/aliasrule.js"></script>
         
        <link href='../omniflow/<h:outputText value="#{PMGEN.Path}"/>css/scrolling_table.css' rel="stylesheet" type="text/css">
        
        <Script LANGUAGE="Javascript">
            var serverUrl='<h:outputText value="#{PMGEN.OMNIFLOW_WEB_CLIENT_URL}"/>';
            var allWindows = new Array();
            var launchWindows = new Array();
            var allPicklistWindows=new Array();
            var localizedPath='<h:outputText value="#{PMGEN.Path}"/>';
            var HTML_DIR='<h:outputText value="#{PMGEN.HTML_DIR}"/>';
            var DateFormat= '<h:outputText value="#{wfSession.m_strDisplayDateFormat}"/>';
            DateFormat = DateFormat.toUpperCase();
            
            var serverIp='<h:outputText value="#{wfSession.m_objCabinet.m_strServerIP}"/>';
            var serverPort='<h:outputText value="#{wfSession.m_objCabinet.m_iServerPort}"/>';
            var serverType='<h:outputText value="#{wfSession.m_objCabinet.m_strServerType}"/>';
            var cabinetName='<h:outputText value="#{wfSession.m_objCabinet.m_strCabinetName}"/>';
            var cabinetType='<h:outputText value="#{wfSession.m_objCabinet.m_strCabType}"/>';
            var siteName='<h:outputText value="#{wfSession.m_objCabinet.m_strSiteName}"/>';
            var siteId='<h:outputText value="#{wfSession.m_objCabinet.m_iSiteID}"/>';
            var volName='<h:outputText value="#{wfSession.m_objCabinet.m_strVolName}"/>';
            var volumeId='<h:outputText value="#{wfSession.m_objCabinet.m_iVolumeID}"/>';
            var encoding='<h:outputText value="#{wfSession.m_objCabinet.m_strEncoding}"/>';
            
            var userName = '<h:outputText value="#{wfSession.m_strUserName}"/>';
            var cabName  = '<h:outputText value="#{wfSession.m_strCabName}"/>';
            var userIndex= '<h:outputText value="#{wfSession.m_iUserIndex}"/>';
            var sessionId= '<h:outputText value="#{wfSession.m_strSessionID}"/>';
            var UniqueUserId= '<h:outputText value="#{wfSession.m_strUniqueUserId}"/>';
            var SessionVariable= '<h:outputText value="#{wfSession.m_strSessionVar}"/>';
            var AllWorksteps='<h:outputText value="#{PMGEN.ALL_WORKSTEPS}"/>';
            var AllQueues=ALL_QUEUES;
            var AllGroups='<h:outputText value="#{PMGEN.ALL_GROUPS_1}"/>';
            var PreferredQueues='<h:outputText value="#{PMGEN.PREFERRED_QUEUE}"/>';
            var AllProcesses='<h:outputText value="#{PMGEN.ALL_PROCESSES_1}"/>';
            var LastSuccessLogin = '<h:outputText value="#{wfSession.m_strLastLoginDT}"/>';
            var LastFailedLogin = '<h:outputText value="#{wfSession.m_strLastFailedLoginDT}"/>';
            var FailedCount = '<h:outputText value="#{wfSession.m_iLastLoginFailedCount}"/>';
            var bEnableTimeZone = '<h:outputText value="#{wfSession.m_bEnableTimeZone}"/>';
            var iServerTimeDiff = '<h:outputText value="#{wfSession.m_iServerTZDiff}"/>';
            var iClientTimeDiff = '<h:outputText value="#{wfSession.m_iClientTZDiff}"/>';
            var bBAMReports = '<h:outputText value="#{wfSession.m_bBAMReports}"/>';
            var minPageHeight='<h:outputText value="#{wfSession.m_strMinPageHeight}"/>';
            var mRightPaneWidth='<h:outputText value="#{wfSession.m_strRightPaneWidth}"/>';
            var dcWindow=null;
            var ajaxaction=null;
            var availH = window.screen.availHeight;
            var availW = window.screen.availWidth;
            var servletRef = window.top.location.href;
            var SessionCheckTimer;
            var launchServerUrl = "/webdesktop/login/login.jsp?CalledFrom=EXT&UserName="+encode_utf8(userName)+"&EngineName="+encode_utf8(cabName)+"&UserIndex="+userIndex+"&SessionId="+sessionId+"&ClientHeight="+availH+"&ClientWidth="+availW;
            launchServerUrl = servletRef.substring(0, servletRef.indexOf("/processmanager")) + launchServerUrl;

            var launchCustomReportsUrl = "/BAM/login/login.jsp?CalledFrom=EXT&UserId="+encode_utf8(userName)+"&UserIndex="+userIndex+"&SessionId="+sessionId+"&ClientHeight="+availH+"&ClientWidth="+availW+"&ServerIP="+encode_utf8(serverIp)+"&ServerPort="+encode_utf8(serverPort)+"&ServerType="+encode_utf8(serverType)+"&CabinetName="+encode_utf8(cabinetName)+"&CabType="+encode_utf8(cabinetType)+"&SiteName="+encode_utf8(siteName)+"&SiteID="+encode_utf8(siteId)+"&VolName="+encode_utf8(volName)+"&VolumeID="+encode_utf8(volumeId)+"&Encoding="+encode_utf8(encoding)+"&LaunchClient=Y";
            launchCustomReportsUrl = servletRef.substring(0, servletRef.indexOf("/processmanager")) + launchCustomReportsUrl;
            //END
            
            var changePasswordUrl = "/omnidocs/ExtendSession.jsp?CabinetName="+encode_utf8(cabName)+"&UserDbId="+sessionId+"&Encoding="+encode_utf8(encoding)+"&DataBaseType="+encode_utf8(cabinetType)+"&Operation=ChangePassword";
            changePasswordUrl = servletRef.substring(0, servletRef.indexOf("/processmanager")) + changePasswordUrl;
            
            var text = 0;
            var msgLastLogin = LAST_SUCCESS_LOGIN+LastSuccessLogin;
            var msgLastFailedLogin = LAST_FAILED_LOGIN+LastFailedLogin;
            var msgFailedLoginCount = FAILED_LOGIN_COUNT+FailedCount;
            
            var message=new Array();
              message[0] = msgLastLogin
              message[1] = msgLastFailedLogin
              message[2] = msgFailedLoginCount              

            function changeText() {
              if (message.length > 0) {
                //document.change.descript.value=message[text];
                document.getElementById("LoginInfoDetails").innerHTML = message[text];
                //alert(message[text]);
                text++;
              }
              if (text == 3) {text = 0; }  
                window.setTimeout("changeText()", 10000); 
                }  

            
            function handleEnterMain(e,id)
            {       
                var browser=navigator.appName;
                if(browser=="Netscape")
                {

                           if(e.which == 13)
                           {       

                                try
                                {
                                    document.getElementById(id).focus();
                                }
                                catch(e){
                                }

                           }
                  }
                                
                  else
                     {      
                        e=window.event;
                        if(e.keyCode == 13)
                            {
                                try
                                {
                                    document.getElementById(id).focus();
                                }
                                catch(e){
                                }
                            }
             
                     }
            }
            
       if (typeof window.event != 'undefined'){ // IE
            document.onkeydown = function() // IE
            {
                var t=event.srcElement.type;
                var kc=event.keyCode;
                if (kc == 116) {
                    window.event.keyCode = 0;         
                    return false;
                }
                else
                    return ((kc != 8 ) || ( t == 'text') || (t == 'textarea') || ( t == 'submit') ||  (t == 'password'))
            }
        }
        else{
            document.onkeypress = function(e)  // FireFox/Others 
            {
                var t=e.target.type;
                var kc=e.keyCode;
                if(kc == 116 && navigator.userAgent.toLowerCase().indexOf("firefox") > -1) {
                    e.cancelBubble = true;
                    return false;
                }
                else if ((kc != 8) || ( t == 'text' ) || (t == 'textarea') || ( t == 'submit') || (t == 'password'))
                    return true;
                else 
                    return false;
           }
        }
        </Script>
    </head>
    <body topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" onload="statisticsDiversion('u');" >
            
            <f:verbatim>        
                <div id="ResultContainer" style="TEXT-ALIGN: center;"> 
                </div>
            </f:verbatim> 
        </body>
</html>
</f:view>    

<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: queuepicklist.jsp
Author                          : Ajith Jacob
Date written (DD/MM/YYYY)       : 15/Jan/2007
Description			: This file contains the picklist for queue.
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
(DD/MM/YYYY)
01/05/2007      Puneet Pahuja            Bug id 671
15/06/2007      Puneet Pahuja           Bug id 1176
11/12/2009      Bhupesh/Indraneel       WCL_8.0_159 Provision for  creating  alias on myqueue for different processes.
19/01/2010      Indraneel               PRM_8.0_036 Option for adding rule defination on queue Aliases to display the row color of workitem list  in webdesktop
23/08/2011      Anushree Jain		    Bug 27971 Security issue
14/09/2011     Anushree Jain	      Bug 28348-Provide external queue variable mapping
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--%>
<%@ page import="java.io.*"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h" %>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f" %>
<%@ page contentType="text/html; charset=UTF-8" %>
<%@ page import="java.util.*,com.newgen.wfdesktop.session.*,com.newgen.wfdesktop.queue.*" %>
<%@ include file="/application/commonheader.process"%>
<f:view>
    <f:loadBundle basename="pmgen" var="PMGEN"/>
    <f:loadBundle basename="pmerrorcodes" var="PMERROR"/>
    <html dir='<h:outputText value="#{PMGEN.HTML_DIR}"/>'>
        <head>
            <title>
                <h:outputText value="#{PMGEN.OMNIFLOW_DESC_TEXT_1}[#{PMGEN.QUEUE_PICKLIST}]" />
            </title>
            <link href='../omniflow/<h:outputText value="#{PMGEN.Path}"/>css/docstyle.css' rel="stylesheet" type="text/css">
            <script  src='../omniflow/<h:outputText value="#{PMGEN.Path}"/>scripts/constants.js'></script>
            <script  src="../omniflow/scripts/toolbar.js"></script>
            <script  src="../omniflow/scripts/wfgeneral.js"></script>
            <script  src="../omniflow/scripts/dragiframe.js"></script>
            <script  src="../omniflow/scripts/pickList.js"></script>
            <Script LANGUAGE="Javascript">
    var allWindows = new Array();
    var allPicklistWindows=new Array();
    var CurrentPickListId="QueuePickList";
    var localizedPath='<h:outputText value="#{PMGEN.Path}"/>';
    var strTextFieldID = '<h:outputText value="#{param.strFormFieldText}"/>';
    var strIDFieldID='<h:outputText value="#{param.strFormFieldID}"/>';
    var strFormID ='<h:outputText value="#{param.strFormID}"/>';
    var strTextHidden='<h:outputText value="#{param.strFormFieldTextHidden}"/>';
    var strReturnNoneText='<h:outputText value="#{param.ReturnNoneValue}"/>';
    var strNoneType='<h:outputText value="#{param.NoneType}"/>';
    var strNoneID='<h:outputText value="#{param.NoneValue}"/>';
    var strCallback='<h:outputText value="#{param.CallBack}"/>';
    var strTypeHidden='<h:outputText value="#{param.strFormFieldTypeHidden}"/>';
    var hidQProcessName='<h:outputText value="#{param.hidQProcessName}"/>';
    function setValue()
    {
        var len=0;
        try
	{
            len=document.getElementById("QueuePickList:picklist").length;
    	}
        catch(e)
	{
            len=-1;
	}
        var name;
        var id;
        var ids;
        var flag=false;
        var strSelectedItems="";
        var type;
        var selVal;
        var tempQProcessName=""
        for(i=0;i<len;i++)
        {
            if(document.getElementById("QueuePickList:picklist").options[i].selected)
            {
                name=document.getElementById("QueuePickList:picklist").options[i].text;
                //id=document.getElementById("QueuePickList:picklist").options[i].value;
                selVal=document.getElementById("QueuePickList:picklist").options[i].value;
                var arr=selVal.split(":");
                if(arr.length==3)
                {
                    id= arr[0];
                    type =arr[1];
                    tempQProcessName=arr[2];
                }
                else
                {
                      id= selVal;
                    type ="";
                      tempQProcessName=""
                }
                if(i==0 && strNoneType>0)
                {
                    id=strNoneID;
                    if(strReturnNoneText==0)
                        name='';
                }
                flag=true;
                break;
            }
        } //end for
        if(!flag)
        {
            if(len<=0)
            {
                removeIFrame(CurrentPickListId);
            }
            else
            {
                alert(NO_QUEUE_SELECTED);
                return false;
            }   
        }
        else
        {
            try{
                window.parent.document.getElementById(strFormID + ":" + strTextFieldID).value=name;
            }catch(ex){}
            try{
                window.parent.document.getElementById(strFormID + ":" + strIDFieldID).value=id;
            }catch(ex){}
            try{
                window.parent.document.getElementById(strFormID + ":" + strTextHidden).value=name;
            }catch(ex){}
                try{
                        window.parent.document.getElementById(strFormID + ":" + strTypeHidden).value=type;
                    }catch(ex){}
            try{
                window.parent.document.getElementById(strFormID + ":" + hidQProcessName).value=tempQProcessName;
            }catch(ex){}
            try{
                if(strCallback.length>0 && Trim(strCallback).length>0)
                {
                    var Temp='window.parent.' + strCallback + '();';
                    eval(Temp);        
                }
            }catch(e){}
            try{
                removeIFrame(CurrentPickListId);
            }catch(ex){}
        }
    }

    function setTooltip() {
        var options = document.getElementById("QueuePickList:picklist").options;
        for(var i = 0; i < options.length; i++) {
            options[i].title = options[i].innerHTML;
        }
    }
    
  </Script>
        </head>
         <body class="PMbgcolorTransparent" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" onload="setPicklistFocus();addHandle(document.getElementById('QueuePickList:toolbar'), window);setTooltip();" onunload='closeWindows();closePicklistWindows(CurrentPickListId);return false;' >
    
            <h:panelGrid width="100%" cellpadding="0" cellspacing="0" border="0" styleClass="PMPageBackground" style="border-collapse:collapse;border:1px solid #bbb9b9;">
                <h:form id="QueuePickList">
                     <f:verbatim>
                        <input type="hidden" name="PM_UID" value="<%=pm_uid%>">
                    </f:verbatim>
                     <h:panelGrid columns="3" id="toolbar" cellpadding="0" cellspacing="0" style="border:0;border-bottom: solid 1px #989898;" columnClasses="PMWIDTH65,PMWIDTH5,PMWIDTH30RIGHT" width="100%">
                        <h:outputLabel value="#{PMGEN.QUEUE_PICKLIST}" styleClass="EWLabel1B" style="width:100%;padding-#{PMGEN.LEFT}:3px;"/>
                         <h:panelGroup>
                            <h:inputHidden id="hid_FirstField" value="#{wfQueueList.m_strFirstField}"/>
                            <h:inputHidden id="hid_LastField" value="#{wfQueueList.m_strLastField}"/>
                            <h:inputHidden id="hid_FirstFieldIndex" value="#{wfQueueList.m_strFirstFieldIndex}"/>
                            <h:inputHidden id="hid_LastFieldIndex" value="#{wfQueueList.m_strLastFieldIndex}"/>
                            <h:inputHidden id="hid_Action" value="#{wfQueueList.m_iAction}"/>
                            <h:inputHidden id="hid_NoneType" value="#{wfQueueList.m_iNoneDisplay}"/>
                            <h:inputHidden id="hid_NoneID" value="#{wfQueueList.m_strNoneID}"/>
                            <h:inputHidden id="queueType" value="#{wfQueueList.m_strQueueType}"/>
                            
                            <f:verbatim><input type=Hidden id="strFormFieldText" name="strFormFieldText" value='</f:verbatim><h:outputText value="#{param.strFormFieldText}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="strFormFieldID" name="strFormFieldID" value='</f:verbatim><h:outputText value="#{param.strFormFieldID}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="strFormID" name="strFormID" value='</f:verbatim><h:outputText value="#{param.strFormID}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim> <input type=Hidden id="strFormFieldTextHidden" name="strFormFieldTextHidden" value='</f:verbatim><h:outputText value="#{param.strFormFieldTextHidden}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="ReturnNoneValue" name="ReturnNoneValue" value='</f:verbatim><h:outputText value="#{param.ReturnNoneValue}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="NoneType" name="NoneType" value='</f:verbatim><h:outputText value="#{param.NoneType}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="NoneValue" name="NoneValue" value='</f:verbatim><h:outputText value="#{param.NoneValue}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="CallBack" name="CallBack" value='</f:verbatim><h:outputText value="#{param.CallBack}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="QueueType" name="QueueType" value='</f:verbatim><h:outputText value="#{param.QueueType}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="QueueAssociation" name="QueueAssociation" value='</f:verbatim><h:outputText value="#{param.QueueAssociation}"/><f:verbatim>'/></f:verbatim>
                            <f:verbatim><input type=Hidden id="strFormFieldTypeHidden" name="strFormFieldTypeHidden" value='</f:verbatim><h:outputText value="#{param.strFormFieldTypeHidden}"/><f:verbatim>'/></f:verbatim>  
                             <f:verbatim><input type=Hidden id="hidQProcessName" name="hidQProcessName" value='</f:verbatim><h:outputText value="#{param.hidQProcessName}"/><f:verbatim>'/></f:verbatim>
                        </h:panelGroup>
                        <h:graphicImage title="#{PMGEN.BUTTON_CLOSE}" url="../omniflow/images/close_img.gif" onclick="removeIFrame(CurrentPickListId);" style="CURSOR: pointer;border:0;"/>
                    </h:panelGrid>
                    
                   
                     <h:panelGrid styleClass="PMbgcolorWhite" width="100%" cellpadding="0" cellspacing="0" border="0"  >
                    <h:panelGrid columns="2" border="0" cellspacing="" columnClasses="PMWIDTH35,PMWIDTH65" cellpadding="2" width="100%" >
                        <h:outputText   style="width:100%" value="#{PMGEN.SEARCH_ONFILTER}" styleClass="EWLabel1"/>
                        <h:panelGroup>
                            <h:panelGrid columns="2" border="0" cellspacing="2" columnClasses="PMWIDTH90,PMWIDTH10" cellpadding="0" width="100%">
                                <h:inputText  style="width:100%" styleClass="PMControlText" id="Queuefilter" value="#{wfQueueList.m_strQueuePrefix}" onkeydown="handlePickListEnter(event,'QueuePickList:cmdlink_Search');"/>
                                 <h:commandLink styleClass="EWEnabledLink" id="cmdlink_Search" action="#{wfQueueList.searchonfilter}">
                                    <h:graphicImage alt="#{PMGEN.TITLE_SEARCH}" style="border:0" url="../omniflow/#{PMGEN.Path}images/go.gif"> </h:graphicImage>
                                </h:commandLink>
                                <%--
                                <h:commandButton id="go"  onclick="NewSubmit(this);return false;" style="border:0;cursor:pointer;" image="../omniflow/#{PMGEN.Path}images/go.gif" action="#{wfQueueList.searchonfilter}" ></h:commandButton>
                               
                                --%>
                            </h:panelGrid>
                        </h:panelGroup>
                    </h:panelGrid>
                    <%//Displaying the error message if any%>
                    
                    <h:panelGrid columns="1" cellpadding="0" cellspacing="0" columnClasses="PMWIDTH100CENTER" width="100%"  styleClass="PMMessageBorder" >
                        <h:panelGroup rendered="#{wfQueueList.m_bError}">
                            <h:graphicImage  alt="" onclick="" style="border:0;vertical-align:middle" url="../omniflow/images/errorimage.gif"> </h:graphicImage>
                            <h:outputText value="." style="width:1%;visibility:hidden"/>
                            <h:outputText id="Error" value="#{wfQueueList.m_strErrorMessage}" styleClass="PMErrorMessage" />
                        </h:panelGroup>
                    </h:panelGrid>
                    
                    <h:panelGrid columns="1" border="0" cellspacing="3" columnClasses="PMWIDTH100CENTERTOP" cellpadding="3" width="100%" rendered="#{!wfQueueList.m_bError}">
                        <h:selectOneListbox size="10" binding="#{wfQueueList.m_Misc}" styleClass="PMWIDTH190PIXELFORPICKLIST" ondblclick="setValue();" id="picklist"  value="" onkeydown="handlePickListEnter(event);">
                            <f:selectItems value="#{wfQueueList.m_objQueueList}"/>
                        </h:selectOneListbox> 
                    </h:panelGrid>
                    <h:panelGrid columns="1" border="0" cellspacing="3" columnClasses="PMWIDTH100" cellpadding="3" width="100%" rendered="#{wfQueueList.m_bError}">
                        <h:selectOneListbox size="8" styleClass="PMControlText" id="picklist11" style="width:100%" value="">
                        </h:selectOneListbox> 
                    </h:panelGrid>
                    <h:panelGrid columns="5" border="0" cellspacing="0"  columnClasses="PMWIDTH20,PMWIDTH20,PMWIDTH20,PMWIDTH20RIGHT,PMWIDTH20RIGHT" cellpadding="0" width="100%" rendered="#{!wfQueueList.m_bError}">
                        <h:outputText  style="width:100%" value="  "/>
                        <h:outputText  style="width:100%" value="  "/>
                        <h:outputText  style="width:100%" value="  "/>
                        <h:panelGroup>
                            <h:commandLink styleClass="EWEnabledLink" id="cmdlink_Previous" action="#{wfQueueList.previous}" tabindex="#{wfQueueList.m_strTabIndexForPrevious}"><%--for bug id 671--%>
                                <h:graphicImage  alt="#{PMGEN.BUTTON_PREVIOUS}" style="border:0" url="../omniflow/#{PMGEN.Path}images/prev.gif" rendered="#{wfQueueList.m_bEnablePreviousButton}"> </h:graphicImage>
                            </h:commandLink>
                            <h:graphicImage alt="#{PMGEN.BUTTON_PREVIOUS}" style="border:0" url="../omniflow/#{PMGEN.Path}images/prev_dis.gif" rendered="#{!wfQueueList.m_bEnablePreviousButton}"> </h:graphicImage>
                        </h:panelGroup>
                        <h:panelGroup>
                            <h:commandLink styleClass="EWEnabledLink" id="cmdlink_Next" action="#{wfQueueList.next}" tabindex="#{wfQueueList.m_strTabIndexForNext}"><%--for bug id 671--%>
                                <h:graphicImage  alt="#{PMGEN.BUTTON_NEXT}" style="border:0" url="../omniflow/#{PMGEN.Path}images/next.gif" rendered="#{wfQueueList.m_bEnableNextButton}"> </h:graphicImage>
                            </h:commandLink>
                            <h:graphicImage alt="#{PMGEN.BUTTON_NEXT}" style="border:0" url="../omniflow/#{PMGEN.Path}images/next_dis.gif" rendered="#{!wfQueueList.m_bEnableNextButton}"> </h:graphicImage>
                        </h:panelGroup>
                    </h:panelGrid>
                 </h:panelGrid>
                </h:form>
            </h:panelGrid>
        </body>
    </html>
</f:view>

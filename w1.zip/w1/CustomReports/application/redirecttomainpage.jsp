<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: redirecttomainpage.jsp
Author                          : Vijay Kumar
Date written (DD/MM/YYYY)       : 30/April/2007
Description			: This file is used to redirect to mainpage
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
(DD/MM/YYYY)
----------------------------------------------------------------------------------------------------
22/01/2010          Vijay Kumar             PRM_8.0_037  back refresh attack.
23/08/2011      Anushree Jain		    Bug 27971 Security issue
Bug 46906       01/07/2014      Jaseem Ansari              - All the request in omniflow containing wd_uid as a parameter should be sent as a post request
----------------------------------------------------------------------------------------------------
--%>

<%@page contentType="text/html"%>
<%@page pageEncoding="UTF-8"%>
<%@ include file="/application/commonheader.process"%>
<%
    String url="../application/main.faces";
%>
<%@include file="../application/redirectPage.process"%>
     
       </body>
</html>

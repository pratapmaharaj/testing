<%--
-----------------------------------------------------------------------------------------------------
NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group				: Phoenix
Product / Project	        : Omniflow Process Manager
Module				: Web Client
File Name			: quickSearch.jsp
Author                          : Shruti Mishra
Date written (DD/MM/YYYY)       : 03/Sep/2007
Description			: This file contains code for quick search.
----------------------------------------------------------------------------------------------------
CHANGE HISTORY
----------------------------------------------------------------------------------------------------
Date		Change By               Change Description (Bug No. (If Any))
(DD/MM/YYYY)
18/01/2008      Vijay Kumar             Bug id-3576
04/03/2010      Himshikha               Bug 12198 
23/08/2011      Anushree Jain		    Bug 27971 Security issue
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--%>
<%@page contentType="text/html"%>
<%@page pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsf/core" prefix="f"%>
<%@taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@page import="com.newgen.wfdesktop.session.*,java.util.*" %>
<%@ include file="/application/commonheader.process"%>
<f:view>
<f:loadBundle basename="pmgen" var="PMGEN"/>
<f:loadBundle basename="pmerrorcodes" var="PMERROR"/>
<%
if(request.getParameter("Action")!=null) {
    if(session.getAttribute("wfQuicksearch")!=null)
        session.removeAttribute("wfQuicksearch");
}
%>
<%
Map bundleValues = null;
bundleValues = (Map)request.getAttribute("PMGEN");
String strHeading="";
strHeading=(String)bundleValues.get("ADMIN_OPTIONS")+" [ Portal Management ]";
%>
<jsp:include page="../application/pmsubheader.jsp" >
    <jsp:param name="Heading" value="<%=strHeading%>"/>
    <jsp:param name='HelpURL' value='Quick_Search_Management.htm'/>
</jsp:include>
<h:form id="quicksearch">
<h:panelGrid columns="2" cellpadding="0" cellspacing="0" border="0" columnClasses="PMWIDTH1,PMWIDTH99" width="100%">
	<h:graphicImage  value="../omniflow/images/arrow1.gif" ></h:graphicImage>
	<h:outputLabel  value="AP Checklist Management" title="AP Checklist Management" onclick="APChecklistportal();"   style="CURSOR: pointer;" onmouseover="StyleLink(this);" onmouseout="StyleNormal(this);"/>                
</h:panelGrid>
<h:panelGrid columns="2" cellpadding="0" cellspacing="0" border="0" columnClasses="PMWIDTH1,PMWIDTH99" width="100%">
	<h:graphicImage  value="../omniflow/images/arrow1.gif" ></h:graphicImage>
	<h:outputLabel  value="VS Checklist Management" title="VS Checklist Management" onclick="VSChecklistportal();"   style="CURSOR: pointer;" onmouseover="StyleLink(this);" onmouseout="StyleNormal(this);"/>                
</h:panelGrid>
<h:panelGrid columns="2" cellpadding="0" cellspacing="0" border="0" columnClasses="PMWIDTH1,PMWIDTH99" width="100%">
	<h:graphicImage  value="../omniflow/images/arrow1.gif" ></h:graphicImage>
	<h:outputLabel  value="ES Checklist Management" title="ES Checklist Management" onclick="ESChecklistportal();"   style="CURSOR: pointer;" onmouseover="StyleLink(this);" onmouseout="StyleNormal(this);"/>                
</h:panelGrid>
</h:form>
</f:view>

<%@ page import="java.io.*,java.util.*,java.text.*,java.text.DateFormat,java.text.SimpleDateFormat"%>
<%@ page import="ISPack.ISUtil.*,ISPack.*,java.util.*,java.io.*,Jdts.DataObject.JPDBInteger, Jdts.DataObject.JPDBISAddress,Jdts.DataObject.*,Jdts.*, java.net.*,com.newgen.wfdesktop.util.*, com.newgen.wfdesktop.session.*,com.newgen.wfdesktop.xmlapi.*, com.newgen.wfdesktop.dmsinterface.*,java.awt.*,java.sql.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>

<%
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	Properties ini = new Properties();
	//Unreleased Resource: Streams fix
	FileInputStream fis = null;
	try{
		// Pathmanipulation-fix
		//fis = new FileInputStream(sRootPathini);
		fis = new FileInputStream(PathUtil.normalize(sRootPathini));
		ini.load(fis);
	}
	catch(Exception e){}
	
	finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("ChildIntroduce","Unable to close the ESChildIntroduce.ini file");
						}
					}
				}
	//ini.load(new FileInputStream(sRootPathini));
	String connectionUrl = ini.getProperty("CONNECTIONSTRING");
	String driverName = null;
	driverName=ini.getProperty("DRIVERNAME");
	
	String sResult="0";
	String sMainCode="0";
	
	String CheckList = request.getParameter("CheckList");
	String Status = request.getParameter("Status");
	String QueueName = request.getParameter("QueueName");
	
       // Connection conn = null;
		//PreparedStatement pstmt=null;
        //Statement st;
        //ResultSet res;
        String sOutputXML = "";
        String cname = "";
        String cqname = "";
        //String connectionUrl = "jdbc:sqlserver://10.33.192.130:1433;" + "databaseName=emperform;user=ofuser;password=ofuser";
        Class.forName(driverName);
        
        //st = conn.createStatement();

       
				String[] nopt=QueueName.split(",");
				for (int i=0;i<nopt.length;i++)
				{
				
					Connection conn = null;
					 PreparedStatement pstmt=null;
					 PreparedStatement pstmt1=null;
					 ResultSet res;
					 sOutputXML="";
					 String sQuery = "select CheckListName,QueueName from WNS_TA_AP_CheckList_Master with (NOLOCK) where CheckListName=? and QueueName=? and reason=?";
				try {
					conn = DriverManager.getConnection(connectionUrl);
					pstmt=conn.prepareStatement(sQuery);
					pstmt.setString(1, CheckList);
					pstmt.setString(2, nopt[i]);
					pstmt.setString(3, Status);
					res=pstmt.executeQuery();
					//res = st.executeQuery(sQuery);

					if (res.next()) {
						cname = res.getString(1);
						cqname = res.getString(2);
						sOutputXML += "~" + cname + "$" + cqname;
						//System.out.println(sOutputXML);
					}
					 if (sOutputXML.equals("")) {
				
						String sQuery1="insert into WNS_TA_AP_CheckList_Master (CheckListName,reason,QueueName) values (?,?,?)";	
						
						pstmt1=conn.prepareStatement(sQuery1);
						pstmt1.setString(1, CheckList);
						pstmt1.setString(2, Status);
						pstmt1.setString(3, nopt[i]);
						int res1=pstmt.executeUpdate();
						//int res1=st.executeUpdate(sQuery1);
					}
					else
					{
						sResult="fail";
					}
				}
				catch (SQLException e) {
				}
				finally{
						  if (res != null) {
						try {
							res.close();
							} catch (SQLException e) { }
						}
						if (pstmt1 != null) {
						try {
							pstmt1.close();
						} catch (SQLException e) { }
						}
						if (pstmt != null) {
						try {
							pstmt.close();
						} catch (SQLException e) { }
						}
						if (conn != null) {
						try {
						conn.close();
						} catch (SQLException e) { }
						}
					}
        } 
		
	StringBuffer sb = new StringBuffer();
	String strxml = "";

	sb.append("<root>");
	sb.append("<detail>");
	sb.append("<MainCode>").append("<![CDATA[").append(sMainCode).append("]]>").append("</MainCode>");
	sb.append("<ReturnValue>").append("<![CDATA[").append(sResult).append("]]>").append("</ReturnValue>");
	sb.append("</detail>");
	sb.append("</root>"); 

	strxml = sb.toString();
	response.getWriter().write(strxml);
%>
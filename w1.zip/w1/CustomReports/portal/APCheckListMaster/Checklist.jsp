<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<%@ include file="./database.jsp" %>
<%@ page import="java.sql.*,java.io.*,java.util.*;" %>
<%@ page import="com.tcsta.util.PathUtil" %>
 <jsp:useBean id="list" class="java.util.TreeMap" scope="request" />
<link rel="stylesheet" href="/processmanager/portal/css/docstyle.css" TYPE="text/css"> 
<script type="text/javascript" src="tabber.js"></script>
<script type="text/javascript" src="/processmanager/portal/TableFilter/tablefilter_all.js"></script>
<link rel="stylesheet" href="/processmanager/portal/TableFilter/filtergrid.css" TYPE="text/css">
<link rel="stylesheet" href="example.css" TYPE="text/css" MEDIA="screen">
<link rel="stylesheet" href="example-print.css" TYPE="text/css" MEDIA="print">
<%!
String user="",password="";

String checklist="",CheckListName="",CheckListReason="",CheckListQueueName="";

int x=0;

%>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <title>AP CheckList Master</title>
        <link rel="stylesheet" href="images/style.css" type="text/css" charset="utf-8" />
<script type="text/javascript">

document.write('<style type="text/css">.tabber{display:none;}</style>');

function findRowNumber(){
    var rowIdx;
    var rowData= [];
    var table= document.getElementById('table1');
    var rows= table.getElementsByTagName('tr');
    var selectedRow;
    var rowCellValue;
    for(i= 0;i<rows.length;i++){
        rows[i].onclick= function(){
            rowIdx= this.rowIndex;
            selectedRow= this.cells;
            for(j= 0;j<selectedRow.length;j++){
                rowCellValue= selectedRow[j].textContent ||
                selectedRow[j].innerText;
                //rowData.push('cell '+j+': '+rowCellValue);
				rowData.push(rowCellValue);
            }
            //alert("Row #" +rowIdx+'. '+ rowData);
			document.getElementById('Checklist_slno').value=rowData[0];
			document.getElementById('CheckListName').value=rowData[1];
			document.getElementById('CheckListReason').value=rowData[2];
			document.getElementById('CheckListQueueName').value=rowData[3];
			
			document.getElementById('CheckListName').disabled=true;
			document.getElementById('CheckListQueueName').disabled=true;
        }
    }
}

function tablefilter()
{
var table3Filters = {
        //btn: true,
		//btn_text: "  >  ",
		filters_row_index: 1,
		btn_reset: true,
		paging: true,  
		paging_length: 10,
		btn_next_page_text: 'Next >',  
		btn_prev_page_text: '< Prev',  
		btn_last_page_text: 'Last >>',  
		btn_first_page_text: '<< First', 
		//on_change: false,
		rows_counter: true,  
        rows_counter_text: "Total rows: ",
        col_0: "none",
		col_1: "select",
        col_2: "select",
		col_3: "select",
		col_4: "none",
		//col_5: "none",
		loader: true,  
		loader_text: "Loading..."
		//display_all_text: " [ Show all ] ",
    }
    setFilterGrid("table1",table3Filters);
}

function validate(checklist)
{
	var checklist=document.getElementById('CheckListName').value;
	if(checklist=="")
	{
	alert("Please enter CheckList Name!");
	document.getElementById('CheckListName').focus();
	return false;
	}
	var status=document.getElementById('CheckListReason').value;
	if(status=="")
	{
	alert("Please enter Reason!");
	document.getElementById('CheckListReason').focus();
	return false;
	}
	var queuename=document.getElementById('CheckListQueueName').value;
	if(queuename=="")
	{
	alert("Please select queuename!");
	document.getElementById('CheckListQueueName').focus();
	return false;
	}
	CKECKALL();
	return true;
 }
 /*function modvalidate()
{
	var status=document.getElementById('CheckListFlag').value;
	if(status=="")
	{
	alert("Please select Status!");
	document.getElementById('CheckListFlag').focus();
	return false;
	}
	MODIFYDATA();
	window.location.reload();
	return true;
 }*/
function CKECKALL()
{
		 var q=document.location.toString();
         q=q.split("?");
         q=q[1].split("&");
         var str=""
         for(i=0;i<q.length;i++){
           tmp=q[i].split("=")
           str+=i +". querystring name is '"+tmp[0]+"' value is '"+tmp[1]+"'<br />"
		   var pm_uid=tmp[1];
		   }
	var checklist=document.getElementById('CheckListName').value;
	var status=document.getElementById('CheckListReason').value;
	//var queuename=document.getElementById('CheckListQueueName').value;
	
	var fld = document.getElementById('CheckListQueueName');
	//alert(fld);
	var queuename = [];
	for (var i = 0; i < fld.options.length; i++) {
	if (fld.options[i].selected)
	{
		queuename.push(fld.options[i].value);
	}
	//alert(queuename);
	}

	
	//alert(checklist);
	//alert(status);
	//alert(queuename);
	var RefNumber_Status = ETAServerRequest("SaveChecklist.jsp?PM_UID="+pm_uid,"&CheckList="+encodeURIComponent(checklist)+"&Status="+encodeURIComponent(status)+"&QueueName="+encodeURIComponent(queuename));
	
	//alert( "RefNumber_Status >> "+RefNumber_Status);
	if(RefNumber_Status != '0')
	{
		alert("Data Already Exists.");
		return false;
	}
	else
	{
		alert('Data Saved Successfully.');
		return true;
	}
}
function del(id)
{
	if(confirm("Do You Want to Delete this CheckList?"))
		{
		DELETEALL(id);
		}
		else
			{
				return false;
			}
}
function DELETEALL(id)
{

		 var q=document.location.toString();
         q=q.split("?");
         q=q[1].split("&");
         var str=""
         for(i=0;i<q.length;i++){
           tmp=q[i].split("=")
           str+=i +". querystring name is '"+tmp[0]+"' value is '"+tmp[1]+"'<br />"
		   var pm_uid=tmp[1];
		   }
		
    //alert(id);	
	var RefNumber_Status = ETAServerRequest("DeleteChecklist.jsp?PM_UID="+pm_uid,"&CheckList_SLNO="+encodeURIComponent(id)); 
	
	//alert( "RefNumber_Status >> "+RefNumber_Status);
	if(RefNumber_Status != '0')
	{
		alert("Some error at server end please save the checklist again.");
		return false;
	}
	else
	{
		alert('Data Deleted Successfully.');
		return true;
	}
}
function MODIFYDATA()
{
		 //MDCount=MDCount-1;
		 var q=document.location.toString();
         q=q.split("?");
         q=q[1].split("&");
         var str=""
         for(i=0;i<q.length;i++){
           tmp=q[i].split("=")
           str+=i +". querystring name is '"+tmp[0]+"' value is '"+tmp[1]+"'<br />"
		   var pm_uid=tmp[1];
		   }
	
			//var status=document.getElementById('CheckListFlag1').value;
						
			/*var cnt=document.getElementById("dropdowncount").value;
			//alert('Count');
			//alert(cnt);
			//alert(MDCount);
			//alert('Count');
			for(var i=1;i<cnt;i++)
			{
				
				var status=document.getElementById('CheckListFlag_'+i).value;
				if(MDCount==i)
				break;
				
			}*/
			
	var status=document.getElementById('CheckListReason').value;
	var id=document.getElementById('Checklist_slno').value;
	//alert(id);
	//alert(status);
	
	var RefNumber_Status = ETAServerRequest("ModifyChecklist.jsp?PM_UID="+pm_uid,"&CheckList_SLNO="+encodeURIComponent(id)+"&Status="+encodeURIComponent(status)); 
	
	//alert( "RefNumber_Status >> "+RefNumber_Status);
	if(RefNumber_Status != '0')
	{
		alert("Some error at server end please modify the checklist again.");
		return false;
	}
	else
	{
		alert('Data Modified Successfully.');
		return true;
	}
}
function ETAServerRequest(URL,sData)
{
	//alert(URL);
	//alert(sData);
 	var iAjaxMainCode="";
	var sAjaxReturnValue="" ;	
	var xmlReq = null;
	
	//alert(xmlReq);
	if (window.XMLHttpRequest)
	{
		//alert('1');	
		xmlReq = new XMLHttpRequest();
	}
	else if(window.ActiveXObject)
	{
	//alert('2');
		xmlReq = new ActiveXObject("Microsoft.XMLHTTP");	
	}
	if(xmlReq==null) 
	{
	//alert('3');
		alert("Browser is not supported");
		return;
	} 
	xmlReq.onreadystatechange = function()
    {
		if (xmlReq.readyState == 4) 
		{
			//alert("xmlReq.status : "+xmlReq.status);
			if (xmlReq.status == 200) 
			{
				var xmldoc = null;
				if ( window.ActiveXObject )
				 {   
						xmldoc = xmlReq.responseText;
						xmlHTTPResponse = xmldoc;
				}
				else
				{
						var parser = new DOMParser();
						xmldoc = parser.parseFromString( xmlReq.responseXML, "text/xml" );
				}
				//alert(sData);
				if( sData != null && sData != undefined )
				{
						var ReturnValue = RetriveData(xmldoc) ;
						//alert('santosh'+ReturnValue);
						var ReturnValueArr = ReturnValue.split(',');
						if(ReturnValueArr[0] == '0')
						{
							sAjaxReturnValue = ReturnValueArr[1];
						}
						else
						{
							alert("Unable to retrive the value !!!\nClose the browser and delete cookies by pressing CTRL + F5 !!!\nIf problem persists then your browser does not support the application !!!");
							sAjaxReturnValue = "Unsuccess";
						}
				}
			}
		}
    }
	xmlReq.open ('POST', URL, false);
	xmlReq.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	xmlReq.send(sData); 
	return sAjaxReturnValue;
}

function RetriveData (retVal)
{
	//alert('3');
	//alert(retVal);
	var isError = false;
	var xmldoc = null;
	var returnValue = "";
	if (window.ActiveXObject)
	{
	//alert('30');
		xmldoc = new ActiveXObject("microsoft.XMLDOM"); 
		xmldoc.loadXML(retVal);
	}
	else
	{
		//alert('31');
		var parser = new DOMParser();
		xmldoc = parser.parseFromString(retVal,"text/xml");
	}
	var errorsNode = xmldoc.getElementsByTagName("detail");
	if(errorsNode.length != 0)
	{
		//alert('1');
		outer:
		for(j = 0; j < errorsNode.length; j++) //Errors Node
		{
		//alert('10');
			inner:
			for(i = 0; i < errorsNode.item(j).childNodes.length; i++) //error node
			{
				//alert('100');
				var errorNode = errorsNode.item(j).childNodes.item(i);
				var tagValue = new Array();    
				var errorChild = errorsNode.item(j).childNodes.item(i);     
				if(errorChild.firstChild != null || errorChild.firstChild != undefined)
				{
				//alert('1000');
					tagValue[i] = errorChild.firstChild.nodeValue;
					if(returnValue == '')
						returnValue = tagValue[i] ;
					else
						returnValue = returnValue +","+ tagValue[i];
						//alert("11111 : > "+tagValue[i]);// see here u r getting the value  or not .
				}
				else
				{
					//alert('2');	
					tagValue[i] = "";
				}
			}
		}//end for outer
	}
	return returnValue;
}
function validateKeys_OnBlur_PO(e,act)
{
	
	var sFinalString="";
	var btypemismatch=false;
	var balert=false;
	if(e.value!=undefined)
	{
		for(var i=0;i<e.value.length;i++)
		{
			var	keychar = e.value.charAt(i);
			
			switch(act) 
			{
			   case "alpha":re = /[^a-z]+/i;break;
			   case "numeric":re = /[^0-9]+/i;break;
			   case "alphanumeric":re = /[^a-z0-9]+/i;break;
			   case "alphanumeric3":re = /[^a-z0-9-]+/i;break;
			   case "alphanumeric4":re = /[^a-z0-9-, ]+/i;break;
			   case "char":re = /[^a-z]+/i;break;
			   case "float":re= /[^0-9.]+/i;break;
			   case "floatwithcomma":re = /[^0-9.,]+/i;break;
			   case "floatnegative":re= /[^0-9.-]+/i;break;
			   case "amount":re= /[^0-9.-]+/i;break;
			   case "decimal":re = /[^0-9.]+/i;break;
		   }
		  if(!(re.test(keychar)) && keychar != "")
		  {
			sFinalString+=keychar;
		  }
		  else
		  {
			balert=true;
		  }
		}
		e.value=sFinalString;
		if(balert)
			alert('Special Characters are not allowed.');
	}
}
function fieldlimit(txtbox)
{
  var Comments = txtbox.value;
  //alert(Comments);
  if(Comments.length > 30)
  {
    alert('CheckList Name should be less than 30 characters.');    
    txtbox.value=Comments.substring(0,30);
    return false;
  }
}
</script>
</head>

<body onload="tablefilter()">
<h1><img src="logo.png" width=250 height=50></img></h1>
<FORM name="wdesk" id="wdesk:checklist" method="post" onSubmit="return validate(this);">
<table width="332" height="225" border="0" align="center" cellpadding="2" cellspacing="2">
		<tr> 
            <td class="EWSubHeader" colspan="2" align="center"><B>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;AP CHECKLIST MASTER MAINTENANCE<B></td> 
        </tr> 
        <tr> 
            <td class="EWSubHeader" colspan="2"></td> 
        </tr> 
                 <tr width=100%>	
					<td width=170 nowrap align=left  class="EWTableContentsText">CheckList Name</td>
					<td align=left class="EWTableContentsText">
					<input name="wdesk:CheckListName" id='CheckListName' type="text"  maxLength=40 class='TextFieldColorLight' onblur="validateKeys_OnBlur_PO(this,'alphanumeric4')" onkeyup="fieldlimit(this);" value="">
					</td>
				</tr>
                 <tr width=100%>	
					<td width=170 nowrap align=left  class="EWTableContentsText">CheckList Reason</td>
					<td align=left class="EWTableContentsText">
					<input name="wdesk:CheckListReason" id='CheckListReason' type="text"  maxLength=100 class='TextFieldColorLight' onblur="validateKeys_OnBlur_PO(this,'alphanumeric4')" onkeyup="fieldlimit(this);" value="">
					</td>
				</tr>
				<tr width=100%>	
					<td width=170 nowrap align=left  class="EWTableContentsText">Queue Name</td>
					<td  width=170 align=left class="EWTableContentsText">
					<select class='TextFieldColorLight'  name="wdesk:CheckListQueueName" id='CheckListQueueName' multiple="multiple">
                                <option value="QC">QC</option>
					</select>
					</td>
				</tr>
				<tr width=100%>	
					<td class="submission" colspan="2"><div align="center">
					<input type="submit" class="TextFieldColorButton" name ="Add" value ="Add">
					<!--input type="button" class="TextFieldColorButton" name="modify" value="Modify" onclick="modvalidate()" -->
					<input type="button" class="TextFieldColorButton" value="Close" onclick="window.parent.close(); return false;">
					</td>
				</tr>
				<input type="hidden" name="Checklist_slno" id ="Checklist_slno" value='<%=Checklist_slno%>'>
		</table>
		</form>
        <tr> 
        <td colspan=4> 
            <DIV width="100%" STYLE="overflow: auto; height: 180px; width=650px; border-left: 1px gray solid; border-bottom: 1px gray solid;border-right: 1px gray solid; border-top: 1px gray solid; padding:0px; margin: 0px" align="center"> 
        <table cellspacing=1 cellpadding=1 bgcolor="#ffffff" border=1 id="table1" scroll=true>
            <tr bgcolor="WHITE">
                <td width="10%" class="EWSubHeader"><div align="center"><strong>SELECT</strong></div></td>
                <td width="10%" class="EWSubHeader"><div align="center"><strong>CHECKLISTNAME </strong></div></td>
                <td width="10%" class="EWSubHeader"><div align="center"><strong>REASON </strong></div></td>
                <td width="10%" class="EWSubHeader"><div align="center"><strong>QUEUE NAME </strong></div></td>
				<td width="10%" class="EWSubHeader" colspan="2"><div align="center"><strong>ACTION</strong></div></td>
                
            </tr>
            <% int icount = 0;
			int Checklist_slno = 0;
			String driverName = null;
			String connectionUrl=ini.getProperty("CONNECTIONSTRING");
			driverName = ini.getProperty("DRIVERNAME");
			Class.forName(driverName);
			Connection con= null;
			Statement stmt= null; 
			ResultSet rs = null;
			PreparedStatement pstmt = null;
            try{
			con = DriverManager.getConnection(connectionUrl);
			stmt = con.createStatement();
			rs = stmt.executeQuery("select * from WNS_TA_AP_CheckList_Master with(nolock) order by QueueName");
			int count=1;
            while (rs.next()) {
                Checklist_slno = rs.getInt("Checklist_slno");
            %>
            <tr>
                <!--td width="10%"><div align="center"><!%=++icount%></div></td-->
				<td ><div align="center"><input type="radio" name="radio" onclick=""><font color="white"><%=rs.getInt("Checklist_slno")%></font></div></td>
                <td width="10%"><div align="center"><%=rs.getString("CheckListName")%></div></td>
                <td width="10%"><div align="center"><%=rs.getString("reason")%></div></td>
                <td width="10%"><div align="center"><%=rs.getString("QueueName")%></div></td>
				<!--td width="10%"><div align="center">
				<input type="button" class="TextFieldColorButton" name="modify" value="Modify" onclick="MODIFYDATA(<!%=Checklist_slno%>,'<!%=count%>')" ></DIV></td-->
				<td width="10%"><div align="center">
				<input type="button" class="TextFieldColorButton" name="delete" value="Delete" onclick="del(<%=Checklist_slno%>);window.location.reload();"></DIV></td>
            </tr>
            <% } }
				catch(SQLException e){}
				finally{    if (rs != null) {
        try {
            rs.close();
        } catch (SQLException e) { }
    }
	if (stmt != null) {
        try {
            stmt.close();
        } catch (SQLException e) { }
    }if (con != null) {
        try {
            con.close();
        } catch (SQLException e) { }
    }}%>	
			<!--input type="hidden" name="dropdowncount" id ="dropdowncount" value='<!%=count%>'-->			
        </table> 
		</DIV>
		</td>
		</tr>
</body>
</html>

<%@ page import="java.io.*,java.util.*,java.text.*,java.text.DateFormat,java.text.SimpleDateFormat"%>
<%@ page import="ISPack.ISUtil.*,ISPack.*,java.util.*,java.io.*,Jdts.DataObject.JPDBInteger, Jdts.DataObject.JPDBISAddress,Jdts.DataObject.*,Jdts.*, java.net.*,com.newgen.wfdesktop.util.*, com.newgen.wfdesktop.session.*,com.newgen.wfdesktop.xmlapi.*, com.newgen.wfdesktop.dmsinterface.*,java.awt.*,java.sql.*"%>
<%@ page import="com.tcsta.util.PathUtil" %>

<%
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	Properties ini = new Properties();
	//Unreleased Resource: Streams fix
	FileInputStream fis = null;
	try{
		fis = new FileInputStream(PathUtil.normalize(sRootPathini));
		ini.load(fis);
	}
	catch(Exception e){}
	finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						WriteLog("ChildIntroduce","Unable to close the ESChildIntroduce.ini file");
						}
					}
				}
	//ini.load(new FileInputStream(sRootPathini));
	//Unreleased Resource: Streams fix ends
	
	String connectionUrl = ini.getProperty("CONNECTIONSTRING");
	String driverName = null;
	driverName=ini.getProperty("DRIVERNAME");
	
	String sResult="0";
	String sMainCode="0";

	String CheckList_No = request.getParameter("CheckList_SLNO");
    int ID = Integer.parseInt(CheckList_No);
	
	Connection conn = null;
	Statement st;
	//String connectionUrl = "jdbc:sqlserver://10.33.192.130:1433;" +"databaseName=emperform;user=ofuser;password=ofuser";
	Class.forName(driverName);
	
	try
	{
		
		conn = DriverManager.getConnection(connectionUrl);
		st = conn.createStatement();
		String sQuery="delete from WNS_TA_AP_CheckList_Master where Checklist_slno="+ID+"";	
		
		int res=st.executeUpdate(sQuery);
		
		 //sResult=sQuery;
	}
	catch(SQLException e)
	{
		//out.println("1");
		sResult = "Exception : error occured for executing procedure."+e.toString();
	}
	finally
	{    
	if (st != null) {
        try {
            st.close();
        } catch (SQLException e) { }
    }
	if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) { }
    }
	}
//out.println(sResult);
	StringBuffer sb = new StringBuffer();
	String strxml = "";

	sb.append("<root>");
	sb.append("<detail>");
	sb.append("<MainCode>").append("<![CDATA[").append(sMainCode).append("]]>").append("</MainCode>");
	sb.append("<ReturnValue>").append("<![CDATA[").append(sResult).append("]]>").append("</ReturnValue>");
	sb.append("</detail>");
	sb.append("</root>"); 

	strxml = sb.toString();
	response.getWriter().write(strxml);
%>
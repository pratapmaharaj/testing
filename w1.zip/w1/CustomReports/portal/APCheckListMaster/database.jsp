<%@ page import="java.sql.*,java.io.*,java.util.*;" %>
<%@ page import="com.tcsta.util.PathUtil" %>
<%
	//String sRootPathini=application.getRealPath("")+File.separator+"portal"+ File.separator + "common.ini";
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	Properties ini = new Properties();
	FileInputStream fis = null;
	try{
		fis = new FileInputStream(PathUtil.normalize(sRootPathini));
		ini.load(fis);
	}
	catch(Exception e){}
	finally
				{
					if (fis != null) {
						try {
						fis.close();
							} 
						catch (Exception e) 
						{
						
						}
					}
				}
//	String driverName = null;

//	String connectionUrl=ini.getProperty("CONNECTIONSTRING");
//	driverName = ini.getProperty("DRIVERNAME");
	
//Class.forName(driverName);
//Connection con=DriverManager.getConnection(connectionUrl);

//Statement stmt=con.createStatement();
//Statement stmt1=con.createStatement();
//Statement stmt2=con.createStatement();
//Statement stmt3=con.createStatement();
//Statement stmt4=con.createStatement();
//Statement stmt5=con.createStatement();

//ResultSet rs,rs1,rs2,rs3,rs4,rs5;

//PreparedStatement pstmt,pstmt1,pstmt2,pstmt3,pstmt4,pstmt5;
%>
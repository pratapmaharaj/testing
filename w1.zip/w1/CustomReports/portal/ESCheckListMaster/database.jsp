<%@ page import="java.sql.*,java.io.*,java.util.*;" %>
<%
	//String sRootPathini=application.getRealPath("")+File.separator+"portal"+ File.separator + "common.ini";
	String sRootPathini=System.getProperty("user.dir")+File.separator+"configuration"+File.separator+"DBReports.ini";
	Properties ini = new Properties();
	ini.load(new FileInputStream(sRootPathini));
	String driverName = null;

	String connectionUrl=ini.getProperty("CONNECTIONSTRING");
	driverName = ini.getProperty("DRIVERNAME");
	//String connectionUrl = ini.getProperty("DatabaseConnectionURL");
	
Class.forName(driverName);
Connection con=DriverManager.getConnection(connectionUrl);

Statement stmt=con.createStatement();
Statement stmt1=con.createStatement();
Statement stmt2=con.createStatement();
Statement stmt3=con.createStatement();
Statement stmt4=con.createStatement();
Statement stmt5=con.createStatement();

ResultSet rs,rs1,rs2,rs3,rs4,rs5;

PreparedStatement pstmt,pstmt1,pstmt2,pstmt3,pstmt4,pstmt5;
%>
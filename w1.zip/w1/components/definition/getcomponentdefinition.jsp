
<%@page import="com.newgen.wfdesktop.util.WDUtility"%>
<%@ page contentType="text/xml"%>
<%@ page pageEncoding="UTF-8"%>

<%@page import="java.util.*,java.io.File,jakarta.servlet.http.*, com.newgen.wfdesktop.util.XOMAdapter,com.newgen.wfdesktop.xmlapi.WDXMLTAGS,nu.xom.*" %>
    <%
            try{
                //Get Component Definition
                File file = new File(application.getRealPath(WDXMLTAGS.ComponentXmlPath));
                XOMAdapter adapter = new XOMAdapter();
                Document componentDoc= adapter.convert(file);
                Elements compList= componentDoc.getRootElement().getChildElements(WDXMLTAGS.Component);
                
                String strDefId=request.getParameter("DefId");
                strDefId = WDUtility.escapeHtml4(strDefId);
               if(strDefId!=null && !strDefId.equalsIgnoreCase("")){
                    Nodes nodes = componentDoc.query("/Components/Component[@DefId='"+strDefId+"']");
                    Element component = (Element) nodes.get(0);
                    response.setContentType("text/xml");
                    out.print(component.toXML());
                }else{
                    out.print("Please specify query definition id");
                }
               
                out.flush();
            }
            catch(Exception ex){
                out.print("");
            }
   %>
   



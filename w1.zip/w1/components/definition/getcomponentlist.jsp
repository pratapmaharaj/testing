
<%@ page contentType="text/xml"%>
<%@ page pageEncoding="UTF-8"%>

<%@page import="java.util.*,java.io.File, jakarta.servlet.http.*,com.newgen.wfdesktop.util.XOMAdapter, com.newgen.wfdesktop.xmlapi.WDXMLTAGS,nu.xom.*" %>
    <%
            try{
                XOMAdapter adapter =new XOMAdapter();
				File file = new File(application.getRealPath(WDXMLTAGS.ComponentXmlPath));
                Document componentDoc= adapter.convert(file);
                Elements compList= componentDoc.getRootElement().getChildElements(WDXMLTAGS.Component);
                //ServletOutputStream outStream  = response.getOutputStream();
                response.setContentType("text/xml");
                Element components=new Element(WDXMLTAGS.Components);
                for(int iCount=0;iCount<compList.size();iCount++){
                    Element component =new Element(WDXMLTAGS.Component);
                    component.addAttribute(new Attribute( WDXMLTAGS.DefId,compList.get(iCount).getAttributeValue(WDXMLTAGS.DefId)));
                    component.addAttribute(new Attribute( WDXMLTAGS.name,compList.get(iCount).getAttributeValue(WDXMLTAGS.name)));
                    component.addAttribute(new Attribute( WDXMLTAGS.url,compList.get(iCount).getAttributeValue(WDXMLTAGS.url)));
                    components.appendChild(component);
                }
                //outStream.print(components.toXML().toString());
                //outStream.flush();
                //outStream.close();
                out.write(components.toXML().toString());
            }catch(Exception ex){
                com.newgen.wfdesktop.util.WDUtility.printErr(ex.getMessage(), ex);
            }
    %>
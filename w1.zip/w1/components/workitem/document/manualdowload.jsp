<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="com.newgen.wfdesktop.cabinet.WDCabinetList"%>
<%@page import ="com.newgen.wfdesktop.session.WDSession"%>
<%@page import ="java.util.ResourceBundle"%>
<%@page import ="jakarta.enterprise.inject.spi.CDI"%>

<%
    ResourceBundle genRSB = ResourceBundle.getBundle("wdgen", request.getLocale());
    String strEncoding = genRSB.getString("Encoding");
    WDSession wDSession = CDI.current().select(WDSession.class).get();
    Boolean isDownloadEnable = (Boolean) request.getAttribute("isDownloadEnable");
    String displayClass = (Boolean.TRUE.equals(isDownloadEnable)) ? "" : "wddisplaynone";
    String displayClass2 = (Boolean.TRUE.equals(isDownloadEnable)) ? "wddisplaynone" : "";
%>
<!DOCTYPE html>
<html dir="<%=genRSB.getString("HTML_DIR")%>"
      lang="<%=genRSB.getString("LangPath")%>" xml:lang="<%=genRSB.getString("LangPath")%>">
    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=<%=strEncoding%>">
        <link href="/webdesktop/resources/<%=genRSB.getString("Path")%>/css/stylesheet.css" rel="stylesheet" type="text/css">
        <script language="javascript" src="/webdesktop/resources/scripts/doctypes.js" ></script>
        <script language="javascript" src="/webdesktop/resources/scripts/workdesk.js" ></script>
        <script language="javascript" src="/webdesktop/resources/scripts/jquery.min.js" ></script>
        <script language="javascript" src="/webdesktop/resources/scripts/wdgeneral.js" ></script>
        <script language="javascript" src="/webdesktop/resources/scripts/purify.min.js" ></script>
        <script language="javascript" nonce="${requestScope.cspNonce}" >
            $(document).ready(function () {
                $('.downloadBtnLink').on('click', function () {
                    downloadClick(); 
                    return false;
                });
                $('.downloadBtnLinkDrive').on('click', function () {
                    window.parent.openInDrive(); 
                    return false;
                });
            });
        </script>
    </head>
    <body class="wdheight100" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0">
        <table width="100%" class="wdheight100 wddisplayflex wdalignitemcenter wdjustifycenter">
            <tr>
                <td class="EWMessage <%= displayClass %>" id="dldescription1" width="100%">
                    <label><%=genRSB.getString("UNABLE_TO_DISPLAY_DOCUMENT")%></label>
                </td>
            </tr>
            <tr>
                <td class="EWMessage <%= displayClass2 %>" id="dldescription2" width="100%">
                    <label><%=genRSB.getString("UNABLE_TO_DISPLAY")%></label>
                </td>
            </tr>
            <tr>
                <td class="EWLabel paddingtop6 <%= displayClass %>" id="downloaddoc"  width="100%">
                    <a href="#" class="EWTableContents downloadBtnLink"><%=genRSB.getString("LABEL_DOWNLOAD")%></a>
                    <%if (WDCabinetList.getConfValue(wDSession.getM_objCabinetInfo().getM_strCabinetName(), "GoogleIntegrated", "N").equals("Y")) {%>
                        <label class="EWMessage"><%=genRSB.getString("LABEL_OR")%></label>
                        <a href="#" class="EWTableContents downloadBtnLinkDrive"><%=genRSB.getString("OPEN_IN_DRIVE")%></a>
                    <%}%>
                </td>
            </tr>
        </table>
    </body>
</html>
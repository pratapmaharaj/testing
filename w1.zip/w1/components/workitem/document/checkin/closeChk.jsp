<%@page import ="jakarta.enterprise.inject.spi.CDI"%>
<%@page import="com.newgen.wfdesktop.session.WDSession"%>
<%@ page import="com.newgen.wfdesktop.util.WDUtility"%>
<%
    WDSession wDSession = CDI.current().select(WDSession.class).get();
%>
<html dir=${WDGEN.HTML_DIR}>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <script language=javascript src="${wDSession.m_strWebContextPath}/resources/scripts/genericpicklist.js"></script>   
        <script language=javascript src="${wDSession.m_strWebContextPath}/resources/scripts/wdgeneral.js"></script>    
        <script language=javascript src="${wDSession.m_strWebContextPath}/resources/scripts/purify.min.js"></script> 
        <script nonce="${requestScope.cspNonce}">
            var DocOrgName = '${wDINIBean.m_strDocOrgName}';
            var operation = '<%=request.getAttribute("Operation")%>';
            var docowner = '<%=request.getAttribute("docowner")%>';
            var loggedUserIndex = <%=WDUtility.escapeHtml4(wDSession.getM_objUserInfo().getM_strUserIndex())%>;
            var fromDocList = '<%=WDUtility.escapeHtml4((String)request.getAttribute("fromDocList"))%>';
            var isOpAll = '${wDINIBean.m_strisOpAll}';
            var docId = '<%=(String) request.getAttribute("DocId")%>';
            var docName = "<%=(String) request.getAttribute("docName")%>";
            var diskName = "<%=(String) request.getAttribute("diskName")%>";
            var docDisplayName = "<%=(String) request.getAttribute("docDisplayName")%>";
            var index = '<%=(String) request.getAttribute("index")%>';
            var docIndex = '<%=(String) request.getAttribute("docIndex")%>';
            var window_workdesk = getWorkitemWindowRef();
            var objCombo = window_workdesk.document.getElementById('wdesk:docCombo');
            var selIndex = -1;
            if(objCombo && objCombo.options.length > 0) {
                selIndex = objCombo.options.selectedIndex;
            }
            if (fromDocList != 'Y') {
                var showRef = window_workdesk.document.getElementById('wdesk:show');
                if (showRef && showRef.style.display == "inline")
                    window_workdesk.document.getElementById('wdesk:saveTransformationDiv').style.display = "inline";
                
                if (window_workdesk.docCheckOut != 0) {
                    window_workdesk.docCheckOut -= 1;
                }

                if (operation == 'C') {                    
                    if (objCombo) {
                        if (DocOrgName == 'Y') {
                            objCombo[selIndex].text = docName + "(" + diskName + ")";
                        } else {
                            objCombo[selIndex].text = docName;
                        }
                        objCombo[selIndex].value = docId;
                        window_workdesk.reloadapplet(docId, false, 'checkin');
                    } else {
                        if (window_workdesk && typeof window_workdesk.refreshDocPanelWrapper != 'undefined') {
                            window_workdesk.refreshDocPanelWrapper(false, '');
                        }
                    }
                    if (window_workdesk.SharingMode) {
                        window_workdesk.broadcastCheckInDocEvent(docId, docName, diskName);
                    }
                } else {
                    if (window_workdesk.document.getElementById('wdesk:docInfoJSON') != null) {
                        var tmpParsedDocJSON = parseJSONWrapper(encode_ParamValue(window_workdesk.document.getElementById('wdesk:docInfoJSON').value));
                        docInfoJSON = tmpParsedDocJSON[docIndex];
                        if (docInfoJSON.actionPanel.checkin == "1") {
                            docInfoJSON.actionPanel.checkin = "-1"
                        }
                        if (docInfoJSON.actionPanel.checkout == "-1") {
                            docInfoJSON.actionPanel.checkout = "1"
                        }
                        tmpParsedDocJSON[docIndex] = docInfoJSON;
                        window_workdesk.document.getElementById('wdesk:docInfoJSON').value = JSON.stringify(tmpParsedDocJSON).toString();
                    }
                    var checkinDiv = window_workdesk.document.getElementById('wdesk:checkinDiv');
                    if (checkinDiv) {
                        addCSS(checkinDiv,'d-none');
                        removeCSS(checkinDiv,'d-inline');
                    }
                    var checkoutDiv = window_workdesk.document.getElementById('wdesk:checkoutDiv');
                    if (checkoutDiv) {
                        removeCSS(checkoutDiv,'d-none');
                        addCSS(checkoutDiv,'d-inline');
                    }
                    
                    var tmpParsedDocJSON = getDocInfoJson(docIndex);
                    if (tmpParsedDocJSON.actionPanel.annotate == '1' && window_workdesk.showHide == 'N') {
                        if (isOpAll == "Y" && window_workdesk.opall_toolkit) {
                            window_workdesk.opall_toolkit.showNHideToolBars(true, true);
                        }
                    }
                    if (window_workdesk.SharingMode) {
                        window_workdesk.broadcastUndoCheckOutDocEvent(docId, docDisplayName, diskName);
                    }
                    
                    if (window_workdesk && typeof window_workdesk.refreshDocPanelWrapper != 'undefined') {
                        window_workdesk.refreshDocPanelWrapper(false, '');
                    }
                }
                if (loggedUserIndex == docowner && window_workdesk.document.getElementById('wdesk:deletedoc')) {
                    window_workdesk.document.getElementById('wdesk:deletedoc').style.display = 'inline';
                }
                if (typeof window_workdesk.checkInDocHook != 'undefined') {
                    window_workdesk.checkInDocHook(docIndex, docName);
                }
                window.top.close();
            } else {
                if (objCombo && objCombo[selIndex].text == docName) {
                    if (window_workdesk.document.getElementById('wdesk:show').style.display == "inline") {
                        window_workdesk.document.getElementById('wdesk:saveTransformationDiv').style.display = "inline";
                    }
                }
                if (operation == 'C') {
                    var selectedDocIndex = index;
                    if (objCombo) {
                        if (DocOrgName == 'Y') {
                            objCombo[selectedDocIndex].text = docName + "(" + diskName + ")";
                        } else {
                            objCombo[selectedDocIndex].text = docName;
                        }
                        objCombo[selectedDocIndex].value = docId;
                        window_workdesk.reloadapplet(docId, false, "checkin");
                        if (window_workdesk.SharingMode) {
                            window_workdesk.broadcastCheckInDocEvent(docId, docName, diskName);
                        }
                    } else {
                        if (window_workdesk && typeof window_workdesk.refreshDocPanelWrapper != 'undefined') {
                            window_workdesk.refreshDocPanelWrapper(false, '');
                        }
                    }
                } else {
                    if (objCombo && objCombo[objCombo.selectedIndex].value == docIndex) {
                        var checkinDiv = window_workdesk.document.getElementById('wdesk:checkinDiv');
                        if (checkinDiv) {
                            replaceCSS(checkinDiv,'d-inline','d-none');
                        }
                        var checkoutDiv = window_workdesk.document.getElementById('wdesk:checkoutDiv');
                        if (checkoutDiv) {
                            replaceCSS(checkoutDiv,'d-none','d-inline');
                        }
                        if (loggedUserIndex == docowner && window_workdesk.document.getElementById('wdesk:deletedoc')) {
                            window_workdesk.document.getElementById('wdesk:deletedoc').style.display = 'inline';
                            window.opener.document.getElementById('doclistview:doclisttable:' + index + ':ischeckin').value = "false";
                        }
                        if (window_workdesk.SharingMode) {
                            window_workdesk.broadcastUndoCheckOutDocEvent(docIndex, docDisplayName, diskName);
                        }
                    } else {
                        window.opener.document.getElementById('doclistview:doclisttable:' + index + ':ischeckin').value = "false";
                        if (loggedUserIndex == docowner && window.opener.document.getElementById('doclistview:deletedoc')) {
                            window.opener.document.getElementById('doclistview:deletedoc').style.display = 'inline';
                        }
                    }
                    if (window_workdesk && typeof window_workdesk.refreshDocPanelWrapper != 'undefined') {
                        window_workdesk.refreshDocPanelWrapper(false, '');
                    }
                }
                if (window_workdesk.docCheckOut != 0) {
                    window_workdesk.docCheckOut -= 1;
                }
                window.opener.clickLink('doclistview:refreshbtn');
                if (typeof window_workdesk.checkInDocHook != 'undefined') {
                    window_workdesk.checkInDocHook(docIndex, docName);
                }
                window.top.close();
            }
        </script>
    </head>   
    <body></body>
</html>
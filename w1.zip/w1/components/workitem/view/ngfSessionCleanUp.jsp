
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%    
    try {
        HttpSession session2 = request.getSession(false);
        String pid = com.newgen.wfdesktop.util.WDUtility.escapeHtml4(request.getParameter("pid"));
        String wid=com.newgen.wfdesktop.util.WDUtility.escapeHtml4(request.getParameter("wid"));           
        if(session2 != null){       
        session2.removeAttribute("ngform_" +pid + "_" + wid);
		session2.removeAttribute("AOCMAP_" +pid + "_" + wid);
		session2.removeAttribute("SaveFlag_" +pid + "_" + wid);
        }        
    } catch (Exception ex) {
    }
%>


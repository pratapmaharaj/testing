
Template


User can customize the view of workdesk for a particular activity using templates.

Steps to replace the default workdesk view with customized template facelet


1) Create a folder named <cabinet name>_<route Id>_<workstage id> in template folder of workdesk.war.

2) Copy file workdesk_custom.xhtml, workdesk_template.xhtml, clientwdesk.xhtml from templates folder to that folder.

3) Create your own workdesk_template.xhtml which contains the layout for the workdesk view and replace the default file with this file.(see workdesk.xhtml for sample)

4) Put the below mentioned  placeholders in place of exception, document, form, todo. These placeholders are surrounded by comments in the sample workdesk_template.xhtml .For ex,
the placeholder for To-Do list is surrounded by the <!-- todo--> and <!-- todo end--> and so on.
 

exception:

<ui:include src="../../view/expview.xhtml"/>
                    OR
<script>
    showsubMenu('#{WDGEN.TITLE_INTERFACES}','#{WDGEN.OP_WI_EXCEPTION}',"javascript:ExceptionClick()?openExceptionWin('N'):'';");
</script>

document:
<ui:include src="../../view/docview.xhtml"/>
                    OR
<script>
    showsubMenu('#{WDGEN.TITLE_INTERFACES}','#{WDGEN.TITLE_DOCTYPES}',"javascript:DocumentClick()?openDocumentWin('N'):'';");
</script>


workdesk form:

<ui:include src="../../view/formview.xhtml"/>
				OR
<script>
    showsubMenu('#{WDGEN.TITLE_INTERFACES}','#{WDGEN.TEXT_FORMVIEW}',"javascript:FormViewClick()?openForm('N'):'';");
</script>


todo:

<ui:include src="../../view/todoview.xhtml"/>
				OR
<script>
    showsubMenu('#{WDGEN.TITLE_INTERFACES}','#{WDGEN.TITLE_TODOLIST}',"javascript:ToDoListClick()?openToDOWin('N'):'';");
</script>


Note:
    1)  Order of various placeholders can be changed.
    2)  Do not make frameset in template
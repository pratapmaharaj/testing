<%-- 
    Document   : redirector
    Created on : Feb 2, 2020, 11:11:34 PM
    Author     : mohit.sharma
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
   session.invalidate();
   String userName=request.getParameter("uid");
   String callFrom=request.getParameter("callFrom");
   String url = "initializePortal.jsp";
   if(userName!=null && callFrom!=null){
       url += "?callFrom="+callFrom+"&username="+userName;
   }
   response.sendRedirect(url);
  %>
    <%@page import="com.newgen.iforms.webapp.AppTasks"%>
    <%@page import="com.newgen.iforms.webapp.AppConfiguration"%>
    <%@page import="java.io.File"%>
    <%-- 
        Document   : initializePortal
        Created on : Jul 30, 2019, 3:27:30 PM
        Author     : g.sharma
    --%>

    <%@page import="com.newgen.iforms.session.IFormSession"%>
    <%@page import="com.newgen.iforms.base.IFormCabinetList"%>
    <%@page import="com.newgen.iforms.util.CommonUtility"%>
    <%@page import="com.newgen.iforms.util.IFormINIConfiguration"%>
    <%@page import="com.newgen.iforms.controls.util.IFormConstants"%>
    <%@page contentType="text/html" pageEncoding="UTF-8"%>
    <%@page import="com.newgen.iforms.util.IFormUtility"%>
    <!DOCTYPE html>
    <%
    String sessionId="";
    if(session.getAttribute("sessionId")!=null)
        sessionId=session.getAttribute("sessionId").toString();
    AppConfiguration appConf = new AppConfiguration();
    String buildPath = application.getRealPath("/");
    IFormINIConfiguration.loadConfigurationFile(buildPath);
    appConf.setWebAppLocation(buildPath);
    appConf.loadConfigurationFile();
    session.setAttribute("AppConfigINI", appConf.getM_hINIHashMap());
    String cabinetName = AppTasks.getValueFromINI(IFormConstants.CABINET_NAME, request); 
    String formBufferPath="";
    String isNew = IFormUtility.escapeHtml4(request.getParameter("new"));
    String filterVal = IFormUtility.escapeHtml4(request.getParameter("FilterValue"));
    if( filterVal == null ){
        filterVal = "";
    }
    if(session.getAttribute("NextRoute")==null || "Y".equals(request.getParameter("Default")))
        formBufferPath=AppTasks.getFormPath(request,appConf.getM_hINIHashMap().get("DefaultForm"),false);  
    String userName=IFormUtility.escapeHtml4Str(request.getParameter("username"));
    String redirectUrl = "/" +AppTasks.getValueFromINI("ApplicationName", request) + "/components/viewer/viewform.jsp";    
    if(request.getParameter("callFrom") != null){
        redirectUrl += "?callFrom="+request.getParameter("callFrom");
    }

    %>
    <html>
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body onload="submitForm();">
        <form name="iform" id="iform" action="<%=redirectUrl%>" method="post" target="_self">
    <script>
    function submitForm()
    {
    var attributeFrom = window.document.forms["iform"];
    attributeFrom.submit();
    }
    </script>
    <input type="hidden" name="processInstanceId" id="processInstanceId" value="Emp001"/>
    <input type="hidden" name="CabinetName" id="CabinetName" value="<%=cabinetName%>"/>
    <input type="hidden" name="workItemId" id="workItemId" value="1"/>
    <input type="hidden" name="pid" id="pid" value="Emp001"/>
    <input type="hidden" name="wid" id="wid" value="1"/>
    <input type="hidden" name="ProcessDefId"  id="ProcessDefId" value=""/>
    <input type="hidden" name="SessionId"  id="SessionId" value="<%=sessionId%>"/>
    <input type="hidden" name="ApplicationName"  id="ApplicationName" value="<%=AppTasks.getValueFromINI("ApplicationName", request)%>"/>
    <input type="hidden" name="AttributeData" id="AttributeData" value=""/>
    <input type="hidden" name="DateFormat" id="DateFormat" value="dd/MM/yyyy"/>
    <input type="hidden" name="ProcessDataDir" id="ProcessDataDir" value=""/>
    <input type="hidden" name="FormDir" id="FormDir" value="<%=formBufferPath%>"/>
    <input type="hidden" name="ReadOnly" id="ReadOnly" value="N"/>
    <input type="hidden" name="generaldata" id="generaldata" value=""/>
    <input type="hidden" name="fid" id="fid" value="Form"/>
    <input type="hidden" name="username" id="username" value="<%=userName%>"/>
    <input type="hidden" name="additionalParams" id="additionalParams" value="<AdditionalParams></AdditionalParams>"/>
    <input type="hidden" name="filterValue" id="filterValue" value="<%=filterVal%>"/>
    <input type="hidden" name="isNew" id="isNew" value="<%=isNew%>"/>
    </form>
    </body>
    </html>

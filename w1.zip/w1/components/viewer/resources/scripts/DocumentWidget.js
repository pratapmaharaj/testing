


function getIcon(type){
    if( type )
 type= type.toLowerCase();

 switch(type){

  case "pdf":
    return "resources/images/Icons/Group 7.png";
  case "png":
    return  "resources/images/Icons/Group 5.png";
  case "jpeg":
  case "jpg":
    return "resources/images/Icons/Group 6.png";
  case "doc":
    return "resources/images/Icons/Group 7 Copy 2.png"
  default:
    return "resources/images/Icons/Group 7 Copy 3.png"      
 }

}

function uploadFileToOD(file,ctrid,doctype, callback){
    
    var reader = new FileReader();
    
    reader.onloadend = function() {
    	var params={
    		pid:pid,
    		wid:wid,
    		tid:tid,
                fid:fid,
    		fileName:file.name,
    		fileData:reader.result,
                ctrId:ctrid,
                docType:doctype,
    		fileType:file.type.split('/')[1]

    	};
    	$.post("../../DocumentUpload", $.param(params), function(response) {
            if (response) {
                callback(response.DocId);
            }else{
            	alert("Error in uploading attachment please try again.")
            }
        });
    }
    
    reader.readAsDataURL(file); 	
}




 /* $(document).on('click','.doc-unit-name', function(event){

    var docID = $(event.target).parent().attr("data-docID");
    //"/omnidocs/integration/foldView/viewFoldList.jsp
    var url = "/omnidocs/integration/foldView/viewDocsMain.jsp?Application=DocView&cabinetName="+cabinetName+"&sessionIndexSet=false&DocId="+docID+"&Userdbid="+sessionId;
    //window.open('dowloadAttachment.jsp?docID='+ docID +'&Userdbid='+ sessionId);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var windowH=450;
    var windowW=950;
    var WindowHeight=windowH-100;
    var WindowWidth=windowW;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2)-50;
    var wiWindowRef = window.open(url, 'DocView', 'scrollbars=yes,left='+WindowLeft+',top='+WindowTop+',height='+windowH+',width='+windowW+',resizable=yes')

    
  });

  $(document).off().on('click','.delete-item', function(event){

    var itemToDelete = $(event.target).parent().parent();
    if(itemToDelete.siblings().length === 0){
      
      var unitBodyDiv = $(itemToDelete).parent().parent();    
      $(itemToDelete).remove();
      $(unitBodyDiv).children(':visible').remove();
      $(unitBodyDiv).children(".no-doc-div").show();
    
    }else{

      $(itemToDelete).remove();      
    }
     
  });


   $(document).off().on('change','.unit-attach-file',function(event){
    var id = $(event.target).attr("id");
    var x = document.getElementById(id);// element id
    //var docUnitDiv = $("[data-id='"+ id +"']");
    var docUnitDiv = $(this).closest(".doc-unit-header").siblings(".doc-unit-body");
    var emptyUnit = true, docUnitDetails="";
    if(docUnitDiv.find(".doc-unit-detail").length>0){
      emptyUnit = false;
    }
    if ('files' in x) {
      if (x.files.length == 0) {
        alert("Please select a file."); // alert for no file selected
      } else {
        
          var file = x.files[0];
          var controlid = jQuery(jQuery(x).parents(".doc-list-body")[0]).attr("id");
          var doctype = jQuery(x).parents(".doc-unit-header").children()[0].childNodes[1].id;
          // $("#spinnerdiv").show();
           uploadFileToOD(file,controlid,doctype, function(docID){
            
            $("#spinnerdiv").hide();
            if ('name' in file) {
            var fileName = file.name; 
            }
            if ('size' in file) {

                var fileSize = file.size;
                if((file.size/1024) < 1024)
                  fileSize = (file.size/1024).toFixed(4) + "KB";
                else
                  fileSize = ((file.size/1024)/1024).toFixed(4) + "MB"; 
            }
            if('type' in file){
                var type = file.type.split('/')[1];
                var icon= getIcon(type);
            }
            docUnitDetails += "           <div class=\"col-md-12 doc-unit-detail\">\n" +
                              "             <div class=\"doc-unit-name\"data-docID=\""+ docID +"\">\n" +
                                "               <img src=\""+ icon +"\"> <p>"+ fileName +"</p>\n" +
                                "             </div>\n" +
                                "             <div class=\"doc-unit-size\">\n" +
                                "               <p>"+ fileSize +"</p>\n" +
                                "             </div>\n" +
                                "             <div class=\"doc-unit-delete\">\n" +
                                "               <i class=\"far fa-trash-alt delete-item\"></i>\n" +
                                "             </div>\n" +
                              "           </div>";
            docUnitDetails += "\n";                  
        

            if(emptyUnit){
              var docUnitHtml = "          <div class=\"col-md-8 doc-detail-wrapper\">\n" +
                                  docUnitDetails + 
                                  "          </div>\n" +
                                  "          <div class=\"col-md-4 doc-unit-comment\">\n" +
                                  "            <textarea placeholder=\"write comments....\"></textarea>\n" +
                                    "          </div>"
            docUnitDiv.children(".no-doc-div").hide();
            docUnitDiv.append(docUnitHtml);                  
        
            }else{

              var docDetailWrapper = docUnitDiv.find(".doc-detail-wrapper");
              docDetailWrapper.append(docUnitDetails);
            }         
           });

      }
    } 
    else { // handling cases when files property isnt supported
      if (x.value == "") {
         alert("Please select a file.");
      } else {
        alert("The files property is not supported by your browser!");
      }
    }
  });


  $(document).off().on('click','.unit-attach-drop',function(event){
    $(this).parent().parent().siblings(".unit-attach-dropdown").toggle();
  });
      
  $(document).off().on('click','.unit-attach-option',function(event){
    $(this).parent(".unit-attach-dropdown").children(".unit-attach-option").children(".hollow-star").show();
    $(this).parent(".unit-attach-dropdown").children(".unit-attach-option").children(".solid-star").hide();
    $(this).children(".solid-star").show();
    $(this).children(".hollow-star").hide();
    $(this).parent(".unit-attach-dropdown").hide();
  });  */



function getIcon(type){
 if( type )
    type= type.toLowerCase();

 switch(type){

  case "pdf":
    return "resources/images/Icons/Group 7.png";
  case "png":
    return  "resources/images/Icons/Group 5.png";
  case "jpeg":
  case "jpg":
    return "resources/images/Icons/Group 6.png";
  case "doc":
    return "resources/images/Icons/Group 7 Copy 2.png"
  default:
    return "resources/images/Icons/Group 7 Copy 3.png"      
 }

}

function uploadFileToOD(file,ctrid,doctype, callback){
    
    var reader = new FileReader();
    
    reader.onloadend = function() {
    	var params={
    		pid:pid,
    		wid:wid,
    		tid:tid,
                fid:fid,
    		fileName:file.name,
    		fileData:reader.result,
                ctrId:ctrid,
                docType:doctype,
    		fileType:file.type.split('/')[1]

    	};
    	$.post("../../DocumentUpload", $.param(params), function(response) {
            if (response) {
                callback(response.DocId);
            }else{
            	alert("Error in uploading attachment please try again.")
            }
        });
    }
    
    reader.readAsDataURL(file); 	
}




 /* $(document).on('click','.doc-unit-name', function(event){

    var docID = $(event.target).parent().attr("data-docID");
    //"/omnidocs/integration/foldView/viewFoldList.jsp
    var url = "/omnidocs/integration/foldView/viewDocsMain.jsp?Application=DocView&cabinetName="+cabinetName+"&sessionIndexSet=false&DocId="+docID+"&Userdbid="+sessionId;
    //window.open('dowloadAttachment.jsp?docID='+ docID +'&Userdbid='+ sessionId);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var windowH=450;
    var windowW=950;
    var WindowHeight=windowH-100;
    var WindowWidth=windowW;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2)-50;
    var wiWindowRef = window.open(url, 'DocView', 'scrollbars=yes,left='+WindowLeft+',top='+WindowTop+',height='+windowH+',width='+windowW+',resizable=yes')

    
  });

  $(document).off().on('click','.delete-item', function(event){

    var itemToDelete = $(event.target).parent().parent();
    if(itemToDelete.siblings().length === 0){
      
      var unitBodyDiv = $(itemToDelete).parent().parent();    
      $(itemToDelete).remove();
      $(unitBodyDiv).children(':visible').remove();
      $(unitBodyDiv).children(".no-doc-div").show();
    
    }else{

      $(itemToDelete).remove();      
    }
     
  });


   $(document).off().on('change','.unit-attach-file',function(event){
    var id = $(event.target).attr("id");
    var x = document.getElementById(id);// element id
    //var docUnitDiv = $("[data-id='"+ id +"']");
    var docUnitDiv = $(this).closest(".doc-unit-header").siblings(".doc-unit-body");
    var emptyUnit = true, docUnitDetails="";
    if(docUnitDiv.find(".doc-unit-detail").length>0){
      emptyUnit = false;
    }
    if ('files' in x) {
      if (x.files.length == 0) {
        alert("Please select a file."); // alert for no file selected
      } else {
        
          var file = x.files[0];
          var controlid = jQuery(jQuery(x).parents(".doc-list-body")[0]).attr("id");
          var doctype = jQuery(x).parents(".doc-unit-header").children()[0].childNodes[1].id;
          // $("#spinnerdiv").show();
           uploadFileToOD(file,controlid,doctype, function(docID){
            
            $("#spinnerdiv").hide();
            if ('name' in file) {
            var fileName = file.name; 
            }
            if ('size' in file) {

                var fileSize = file.size;
                if((file.size/1024) < 1024)
                  fileSize = (file.size/1024).toFixed(4) + "KB";
                else
                  fileSize = ((file.size/1024)/1024).toFixed(4) + "MB"; 
            }
            if('type' in file){
                var type = file.type.split('/')[1];
                var icon= getIcon(type);
            }
            docUnitDetails += "           <div class=\"col-md-12 doc-unit-detail\">\n" +
                              "             <div class=\"doc-unit-name\"data-docID=\""+ docID +"\">\n" +
                                "               <img src=\""+ icon +"\"> <p>"+ fileName +"</p>\n" +
                                "             </div>\n" +
                                "             <div class=\"doc-unit-size\">\n" +
                                "               <p>"+ fileSize +"</p>\n" +
                                "             </div>\n" +
                                "             <div class=\"doc-unit-delete\">\n" +
                                "               <i class=\"far fa-trash-alt delete-item\"></i>\n" +
                                "             </div>\n" +
                              "           </div>";
            docUnitDetails += "\n";                  
        

            if(emptyUnit){
              var docUnitHtml = "          <div class=\"col-md-8 doc-detail-wrapper\">\n" +
                                  docUnitDetails + 
                                  "          </div>\n" +
                                  "          <div class=\"col-md-4 doc-unit-comment\">\n" +
                                  "            <textarea placeholder=\"write comments....\"></textarea>\n" +
                                    "          </div>"
            docUnitDiv.children(".no-doc-div").hide();
            docUnitDiv.append(docUnitHtml);                  
        
            }else{

              var docDetailWrapper = docUnitDiv.find(".doc-detail-wrapper");
              docDetailWrapper.append(docUnitDetails);
            }         
           });

      }
    } 
    else { // handling cases when files property isnt supported
      if (x.value == "") {
         alert("Please select a file.");
      } else {
        alert("The files property is not supported by your browser!");
      }
    }
  });


  $(document).off().on('click','.unit-attach-drop',function(event){
    $(this).parent().parent().siblings(".unit-attach-dropdown").toggle();
  });
      
  $(document).off().on('click','.unit-attach-option',function(event){
    $(this).parent(".unit-attach-dropdown").children(".unit-attach-option").children(".hollow-star").show();
    $(this).parent(".unit-attach-dropdown").children(".unit-attach-option").children(".solid-star").hide();
    $(this).children(".solid-star").show();
    $(this).children(".hollow-star").hide();
    $(this).parent(".unit-attach-dropdown").hide();
  });  */


function docUnitName(event){
    var docID = $(event.target).parent().attr("data-docID");
    var fileName = $(event.target).parent().find("p").get(0).title;
    var url = "../../docDownload?pid=" + pid + "&wid=" + wid + "&tid=" + tid + "&fid=" + fid + "&cabinetName=" + cabinetName + "&DocId=" + docID + "&DocName=" + fileName + "&Userdbid=" + sessionId;
    var iframess = document.getElementById("docDownloadhi");
    if (iframess === null) {
        iframess = document.createElement("iframe");
        iframess.id = "docDownloadhi";
        iframess.style.display = "none";
        document.getElementById("oforms_iform").appendChild(iframess);
    }
    iframess.src = url;
    
}

function deleteItem(event){
    var itemToDelete = $(event.target).parent().parent();   
    var docid =  itemToDelete.find(".doc-unit-name").attr("data-docid");
    var ctrid = jQuery(itemToDelete.parents(".doc-list-body")[0]).attr("id");
    deletedoc(ctrid,docid);
      var unitBodyDiv = $(itemToDelete).parent().parent();   
      $(itemToDelete).parent().next().remove();
      $(itemToDelete).parent().remove();
      if(unitBodyDiv.children().length === 1)
      $(unitBodyDiv).children(".no-doc-div").show();
    
    
}

function attachmentDropdownToggle(event){
    var dropdown = $(event.target).parent().parent().siblings(".unit-attach-dropdown");
    if(dropdown.is(":visible")){
        dropdown.hide();
    }else{
        dropdown.show();
    }
    //$(event.target).parent().parent().siblings(".unit-attach-dropdown").toggle();
}

function attachmentOptionToggle(event){
    var that = $(event.target);
    that.parent(".unit-attach-dropdown").children(".unit-attach-option").children(".hollow-star").show();
    that.parent(".unit-attach-dropdown").children(".unit-attach-option").children(".solid-star").hide();
    that.children(".solid-star").show();
    that.children(".hollow-star").hide();
    that.parent(".unit-attach-dropdown").hide();
}

function pickDocumentListFiles(event){
    var id = $(event.target).attr("id");
    var x = document.getElementById(id);// element id
    //var docUnitDiv = $("[data-id='"+ id +"']");
    var docUnitDiv = $(event.target).closest(".doc-unit-header").siblings(".doc-unit-body");
    var emptyUnit = true, docUnitDetails="";
    if(docUnitDiv.find(".doc-unit-detail").length>0){
      emptyUnit = false;
    }
    if ('files' in x) {
      if (x.files.length == 0) {
        alert("Please select a file."); // alert for no file selected
      } else {
        
          var file = x.files[0];
          var controlid = jQuery(jQuery(x).parents(".doc-list-body")[0]).attr("id");
          var doctype = jQuery(x).parents(".doc-unit-header").children()[0].childNodes[1].id;
          // $("#spinnerdiv").show();
           uploadFileToOD(file,controlid,doctype, function(docID){
            
            $("#spinnerdiv").hide();
            if ('name' in file) {
            var fileName = file.name; 
            }
            if ('size' in file) {

                var fileSize = file.size;
                fileSize = (file.size/1024).toFixed(4) + " (KB)";
                
            }
            if('type' in file){
                var type = file.type.split('/')[1];
                var icon= getIcon(type);
            }
            docUnitDetails += "           <div class=\"col-md-12 col-sm-12 col-xs-12 doc-unit-detail\">\n" +
                              "             <div class=\"doc-unit-name\"data-docID=\""+ docID +"\" onclick=\"docUnitName(event)\">\n" +
                                "               <img src=\""+ icon +"\"> <p title=\""+fileName+"\">"+ fileName +"</p>\n" +
                                "             </div>\n" +
                                "             <div class=\"doc-unit-size\">\n" +
                                "               <p>"+ fileSize +"</p>\n" +
                                "             </div>\n" +
                                "             <div class=\"doc-unit-delete\">\n" +
                                "               <i class=\"fa fa-trash delete-item\" onclick=\"deleteItem(event)\"></i>\n" +
                                "             </div>\n" +
                                
                              "           </div>";
            docUnitDetails += "\n";                  
        

            
              var docUnitHtml = "          <div class=\"col-md-8 col-sm-8 col-xs-8 doc-detail-wrapper\">\n" + docUnitDetails + 
                                "           </div>\n"+
                                "          <div class=\"col-md-4 col-sm-4 col-xs-4 doc-unit-comment\">\n" +
                                "           <textarea onchange = \"updateDocComment(this)\" placeholder=\"write comments....\"></textarea>\n" +
                                "          </div>";
                                  
            docUnitDiv.children(".no-doc-div").hide();
            docUnitDiv.append(docUnitHtml);                  
        
                 
           });

      }
    } 
    else { // handling cases when files property isnt supported
      if (x.value == "") {
         alert("Please select a file.");
      } else {
        alert("The files property is not supported by your browser!");
      }
    }
}


function triggerLabelClick(event){
    $(event.target).next("input").trigger("click");
}
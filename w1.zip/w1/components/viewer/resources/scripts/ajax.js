/* 
     * To change this template, choose Tools | Templates
     * and open the template in the editor.
     * 20/06/2019   Gaurav              Bug 85361 - data not saving in table when task is opened with case form
     * 07/11/2019   Rohit Kumar         Bug 87917 - No Logout message on session expire
     * 23/01/2020   Karishma Rastogi    Bug 89941 - On Published Application if session expired than proper message should be display
     * 16/02/2020   Karishma Rastogi    Bug 89941 - On Published Application if session expired than proper message should be display
*/
if( !iforms )
var iforms = {};

if(!iforms.ajax)
{
    iforms.ajax =
    {        
        strResponse:null,
        url : null, 
        processRequest:function(pParam,pUrl)
        {   
            var rid = null;
            iforms.ajax.url = pUrl;
            var sid = jQuery("#sid").val();
            if(pUrl === "action.jsp"){
               rid = jQuery("#rid_Action").val();
            } else if (pUrl === "action_API.jsp")  {
               rid = jQuery("#rid_ActionAPI").val();
            } else if (pUrl === "ifhandler.jsp") {
               rid = jQuery("#rid_IfHandler").val();
            } else if (pUrl === "listViewModal.jsp") {
               rid = jQuery("#rid_listviewmodal").val();
            } else if (pUrl === "advancedListViewModal.jsp") {
               rid = jQuery("#rid_advancelistviewmodal").val();
            } else if (pUrl === "picklistview.jsp") {
               rid = jQuery("#rid_picklistview").val();
            } else if (pUrl === "texteditor.jsp") {
               rid = jQuery("#rid_texteditor").val();
            } else if (pUrl === "webservice.jsp") {
               rid = jQuery("#rid_webservice").val();
            }else if (pUrl === "portal/appTask.jsp") {
               rid = jQuery("#rid_appTask").val();
            }
            if(rid != null){
               if(pUrl.indexOf('?') == -1) 
                    pUrl += "?WD_SID=" + sid + "&WD_RID="+rid;
               else
                    pUrl += "&WD_SID=" + sid + "&WD_RID="+rid;
            }
            this.strResponse = null;
            if( pUrl != undefined && pUrl != "undefined")
                this.sendRequest(pUrl, pParam);            
            else
                this.sendRequest("../action/actionhandler", pParam);            
            return this.strResponse;
        },
        createXMLHttpRequest:function()
        {
            try
            {
                return new ActiveXObject("Msxml2.XMLHTTP");
            } 
            catch(e)
            {}
            try
            {
                return new ActiveXObject("Microsoft.XMLHTTP");
            }
            catch(e)
            {}
            try
            {
                return new XMLHttpRequest();
            } 
            catch(e)
            {}
            alert("XMLHttpRequest not supported");
            return null;
        },

        sendRequest:function(pUrl,pData)
        {
            if(pUrl.indexOf("?")>0) 
            {
                pUrl=pUrl + "&sid="+ Math.random();
            }
            else 
            {
                pUrl=pUrl + "?sid="+ Math.random();
            }
            if(pUrl.indexOf("&fid")<0)
                pUrl+="&fid="+fid;
            if(pUrl.indexOf("&pid")<0)//Bug 85361 Start
                pUrl+="&pid="+pid;
            if(pUrl.indexOf("&wid")<0)
                pUrl+="&wid="+wid;
            if(pUrl.indexOf("&tid")<0)
                pUrl+="&tid="+tid;//Bug 85361 End
            iforms.ajax.strResponse = "";
            objReq = this.createXMLHttpRequest();
            objReq.open("POST", pUrl, false);
            objReq.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset=UTF-8"); 
            objReq.onreadystatechange = this.onResponse;
            objReq.send(pData);
        },

        onResponse:function()
        { 
            try 
            {            
                    if (objReq.readyState==4) 
                    {   
                        if (objReq.status==200)
                        {
//                            if( objReq.getResponseHeader("InvalidSession") === "Y" || objReq.getResponseHeader("Error")=="7006"){   //Bug 87917 
//                                if(processName!="")
//                                    redirectToApplication();//Bug 89941
//                            }
                            var rid = objReq.getResponseHeader("WD_RID");
                            if(iforms.ajax.url == "action.jsp"){
                              jQuery("#rid_Action").val(rid);
                            } else if (iforms.ajax.url == "action_API.jsp")  {
                              jQuery("#rid_ActionAPI").val(rid);
                            } else if (iforms.ajax.url == "ifhandler.jsp") {
                              jQuery("#rid_IfHandler").val(rid);
                            } else if (iforms.ajax.url == "listViewModal.jsp") {
                              jQuery("#rid_listviewmodal").val(rid);
                            } else if (iforms.ajax.url == "advancedListViewModal.jsp") {
                              jQuery("#rid_advancelistviewmodal").val(rid);
                            } else if (iforms.ajax.url == "picklistview.jsp") {
                              jQuery("#rid_picklistview").val(rid);
                            } else if (iforms.ajax.url == "texteditor.jsp") {
                              jQuery("#rid_texteditor").val(rid);
                            } else if (iforms.ajax.url == "webservice.jsp") {
                              jQuery("#rid_webservice").val(rid);
                            }else if (iforms.ajax.url == "portal/appTask.jsp") {
                                jQuery("#rid_appTask").val(rid);
                            }
                            
                            iforms.ajax.strResponse = objReq.responseText;                            
                        }
                        else if ( objReq.status==12029) //Bugzilla – Bug 53510
                        {
                            alert("Unable to connect to server");
                            return;
                        }
                    }
                }
            catch(e)
            {
                alert("Error fetching data.");
            }
        }
    }
}
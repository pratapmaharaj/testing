/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/* 16/05/2019       Aman Khan           Bug 84694 - Need an option to disable calendar values conditionally in Iform .
 * 28/05/2019       Gaurav              Bug 84949 - mandatory validation is not removed if data is set using API
 * 28/05/2019       Abhishek            Bug 84964 - Custom alert on cross icon of grid 
 * 03/06/2019       Abhishek            Bug 85055 - Kindly provide a call to get mandatory field list. 
 * 08/06/2019       Gaurav              Bug 85154 - fixed tab header not working for style4 and in ie not working for any of the tab style
 * 13/06/2019       Gaurav              Bug 85226 - Give API to attach zone on any field
 * 05/07/2019       Gaurav              Bug 85533 - Need API for setting date range in table
 * 24/07/2019       Aman Khan           Bug 85733 - Need option to reload the entire tab/sheet.
 * 26/07/2019       Aman Khan           Bug 85761 - Not able to fetch the value of dropdown
 * 29/07/2019       Aman Khan           Bug 85780 - Grid overlaps with tab section.
 * 29/07/2019       Aman Khan           Bug 85781 - listview alignment issue
 * 30/07/2019       Gaurav              Bug 85784 - Need server API to delete rows in grid
 * 10/09/2019       Aman Khan           Bug 86443 - Auto Increment functionality not working on Batching (Table and Listview Control)
 * 01/10/2019       Abhishek            Bug 87092 - previously set date do not gets deleted from html so it doesn't get set to another datepicker with updated value
 * 07/10/2019       Abhishek            Bug 87167 - Datepicker not getting saved
 * 07/11/2019       Rohit Kumar         Bug 87917 - No Logout message on session expire
 * 13/12/2019       Aman Khan           Bug 89069 - Require Advance Search Drop down in Table.
 * 13/12/2019       Aman Khan           Bug 89082 - refreshFrame API is not syncronous
 * 09/01/2020       Abhishek            Bug 89907 - Datepicker value do not get destroyed even after clearing from setvalues 
 * 23/01/2020       Karishma Rastogi    Bug 89941 - On Published Application if session expired than proper message should be display
 * 23/01/2020       Karishma Rastogi    Bug 90043 - Published Application submitted than Finish Button Should be disable
 * 12/02/2020       Abhishek            Bug 90591 - On Published application unable to login on IE(11.0.9600) browser only loading shown .
 * 15/02/2020       Karishma Rastogi    Bug 88657 - Navigate Application to the end after that click on Back button Next button should be display instead of Finish button
 * 16/02/2020       Karishma Rastogi    Bug 89941 - On Published Application if session expired than proper message should be display
 * 09/03/2020       Abhishek            Bug 91220 - datepicker turning into datetimepicker after using clearValues 
 **/

function refreshFrame(frameId, syncFlag) {
    var url = "action_API.jsp";
    requestString = "frameId=" + frameId + "&frameState=collapsed&pid=" + encode_utf8(pid) + "&wid=" + encode_utf8(wid) + "&tid=" + encode_utf8(tid) + "&fid=" + encode_utf8(fid);
    if (jQuery(jQuery("#" + frameId).children()[0]).attr("painted") != undefined) {
        if (jQuery(jQuery("#" + frameId).children()[0]).attr("state") == "collapsed")
            requestString += "&refreshCollapsed=true";
        if (syncFlag == true) {
            var frameHTML = iforms.ajax.processRequest(requestString, url);
            refreshFrameHelper(frameId, frameHTML)
        }
        else{
            new net.ContentLoader(url, refreshFrameResponseHandler, frameErrorHandler, "POST", requestString, true);
        }
        }
    else if(document.getElementById(frameId).childNodes.length === 1){
        if (syncFlag == true) {
            var frameHTML = iforms.ajax.processRequest(requestString, url);
            refreshFrameHelper(frameId, frameHTML)
        }
        else{
            new net.ContentLoader(url, refreshFrameResponseHandler, frameErrorHandler, "POST", requestString, true);
        }
    }
}

function refreshFrameResponseHandler() {

    var framehtml = this.req.responseText.trim();
    var frameid = getQueryVariable(this.params, "frameId");
    refreshFrameHelper(frameid, framehtml);
}

function refreshFrameHelper(frameid, framehtml) {
    $(".iform-table").floatThead('reflow');
    var parentNode = document.getElementById(frameid).parentNode;
    parentNode.innerHTML = "";
    jQuery(parentNode).html(framehtml);
    doInit();
    executeLoadEvents('4', frameid);
    if (window.onLoadSection)
        window.onLoadSection(frameid);
}

function setDateRange(controlId, minDate, maxDate) {
    var dateControl = document.getElementById(controlId);
    var el = dateControl.cloneNode(true);
    var par = dateControl.parentNode;
    par.removeChild(dateControl);
    par.appendChild(el);

    if (maxDate != undefined && maxDate != '')
        el.setAttribute("maxdate", maxDate);
    if (minDate != undefined && minDate != '')
        el.setAttribute("mindate", minDate);
    attachDatePicker();
    $(el).on('dp.change', function (e) {
        ctrOnchangeHandler(this, 1);
        var customMethodName = el.getAttribute("method");
        if (customMethodName != null && customMethodName != undefined)
            parseJSON(customMethodName + "()");
    });


}

//Bug 84949 Start
function checkFieldMandatoryCondition(thisRef) {
    var validateMapKey = thisRef.id;//Bug 83970 Start
    if (thisRef.name != null && thisRef.name != undefined && thisRef.name != "")
        validateMapKey = thisRef.name;
    var value = getControlValue(thisRef);
    if (value != "" && jQuery(thisRef).attr("required") != undefined)
    {
        var msgRef = document.getElementById(thisRef.id + "_msg");
        var patternRef = document.getElementById(thisRef.id + "_patternMsg");
        jQuery(msgRef).css("display", "none");
        jQuery(patternRef).css("display", "none");
        toggleErrorTooltip(thisRef, msgRef, patternRef, true, 0);
        // jQuery("#"+thisRef.id+"_msg").css("display","none");
        //  jQuery("#"+thisRef.id+"_patternMsg").css("display","none");
        if (jQuery(jQuery(thisRef)[0]).parent().parent().parent().hasClass("floating-label-form-group"))
            jQuery(jQuery(thisRef)[0]).parent().parent().parent().removeClass("mandatory");
        else
            jQuery(jQuery(thisRef)[0]).removeClass("mandatory");
        if (validateMapKey in ComponentValidatedMap)
            delete ComponentValidatedMap[validateMapKey];
    }
}//Bug 84949 End

function showConfirm(msg)
{
    var btns = {
        confirm: {
            label: YES,
            className: 'btn-success'
        },
        cancel: {
            label: NO,
            className: 'btn-danger'
        }
    }
    var callback = function (result) {
        if (result) {
            var control = document.getElementById("listViewModal");
            var controlAdvance = document.getElementById("advancedListViewModal");
            if (control.style.display == 'block' && controlAdvance.style.display == 'block')
                $('#listViewModal').modal('hide')
            else
                $('.modal.in').modal('hide')
        }
    }
    showConfirmDialog(msg, btns, callback);
}

function listViewOverlay(controlId)
{
    var boolMsgTobeDisplay = false;
    if (window.msgOnCloseOverLay)
    {
        var msg = msgOnCloseOverLay(controlId);
        if (!("" == msg)) {
            boolMsgTobeDisplay = true;
        }
    }
    if (boolMsgTobeDisplay)
        showConfirm(msg);
    else
    {
        var control = document.getElementById("listViewModal");
        var controlAdvance = document.getElementById("advancedListViewModal");
        if (control.style.display == 'block' && controlAdvance.style.display == 'block')
        {
            $('#listViewModal').modal('hide')
            }
            else
            $('.modal.in').modal('hide');
    }

}

function getMandatoryFieldList(controlId, index)
{
    var tab = document.getElementById(controlId);
    if (tab != null && tab != undefined)
    {
        if (index == undefined)
            var controls = $('#' + controlId + " .control-class");
        else
        {
            var sheet = tab.getElementsByClassName("tab-pane fade")[index];
            var controls = sheet.getElementsByClassName("control-class");
        }
        var mandatoryJsonArray = [];
        for (var i = 0; i < controls.length; i++)
        {
            var boolValidate = false;
            if (controls[i].getAttribute("required") != undefined)
            {
                var mandatoryJson = {};
                if (getValue(controls[i].id))
                    boolValidate = true;
                mandatoryJson["ControlId"] = controls[i].id;
                mandatoryJson["Validate"] = boolValidate;
                mandatoryJsonArray.push(mandatoryJson);
            }
        }
        return mandatoryJsonArray;
    }
}
//Bug 85154 Start
function moveScroller() {
    var anchor = $(".iformTabControl")[0];
    var scrollerButtons = null, scroller = null;
    var isTabStyle4 = false;
    if ($('.iformTabUL.fixed-tabmenu.tabtheme4')[0] != null) {
        isTabStyle4 = true;
        if ($('.tabButtonsDiv')[0] != null)
            scrollerButtons = $('.tabButtonsDiv')[0];
        scroller = $('.scrtabs-tab-container')[0];

        }
        else
        scroller = $('.iformTabUL.fixed-tabmenu')[0];


    var move = function () {
        var offset = 0;
        if (document.getElementById("headerDiv") != null)
            offset = $($("#headerDiv")[0]).outerHeight() + $($("#headerDiv")[0]).offset().top - 5;
        var st = $(window).scrollTop();
        var ot = $(anchor).offset().top - offset;
        if (st > ot) {
            $(scroller).css({
                position: "fixed",
                top: offset + "px",
                zIndex: 990
            });
            if (isTabStyle4)
                $(scroller).css({
                    "background": "inherit"
                });
            if (scrollerButtons != null) {
                var buttonLeft = $(scroller).offset().left + $(scroller).outerWidth();
                var buttonHeight = $(scroller).outerHeight();
                $(scrollerButtons).css({
                    position: "fixed",
                    top: offset + "px",
                    zIndex: 990,
                    left: buttonLeft,
                    height: buttonHeight,
                    "background": "inherit"
                });
            }
        } else {
            $(scroller).css({
                position: "relative",
                top: "",
                zIndex: "",
                "background": ""
            });
            if (scrollerButtons != null) {
                $(scrollerButtons).css({
                    position: "relative",
                    top: "",
                    left: "",
                    zIndex: "",
                    height: "",
                    "background": ""
                });
            }
        }
    };
    if (scroller != null) {
        document.addEventListener(
                'scroll',
                function (event) {
                    jQuery('.myjquerydatepicker').datetimepicker('hide');
                    jQuery('.myjquerydatetimepicker').datetimepicker('hide');
                    move();
                },
                true
                );
        move();
        }
        else{
        document.addEventListener(
                'scroll',
                function (event) {
                    jQuery('.myjquerydatepicker').datetimepicker('hide');
                    jQuery('.myjquerydatetimepicker').datetimepicker('hide');
                },
                true
                );
    }
}
//Bug 85154 End
//Bug 85226 Start
function addZone(zoneName, top, left, width, height, controlId) {
    var control = document.getElementById(controlId);
    if (control != null) {
        var onFocusData = control.getAttribute("onfocus");
        if (onFocusData == null)
            onFocusData = "";
        if (onFocusData.indexOf("attachZoneBehaviour", 0) != -1) {
            var attachZoneIndex = onFocusData.indexOf("attachZoneBehaviour", 0);
            var attachZonelastIndex = onFocusData.indexOf(";", attachZoneIndex);
            onFocusData = onFocusData.substring(0, attachZoneIndex) + onFocusData.substr(attachZonelastIndex + 1);
        }
        onFocusData += "attachZoneBehaviour(this,'" + zoneName + "','" + left + "','" + top + "','" + width + "','" + height + "');";
        control.setAttribute("onfocus", onFocusData);

    }
}
//Bug 85226 End
function setValue(controlName, controlValue) {
    var objComp = document.getElementById(controlName);
    if (objComp == null || objComp.classList.contains("iform-radio"))
    {
        objComp = document.getElementsByName(controlName)[0];
    }

    if (objComp != null) {
        //Bug 84373 Start
        if (objComp.type == 'date' || objComp.type == 'datetime-local')
            objComp.value = controlValue;
        //Bug 84373 End

        //Bug 76737 Start
        if (objComp.type == 'text' || objComp.type == "textarea") {
            if ($(objComp).hasClass("editableCombo")) {//Bug 83221 Start
                var ul = objComp.parentNode.childNodes[2];
                for (var i = ul.childNodes.length - 1; i >= 0; i--) {
                    if (ul.childNodes[i].getAttribute("value") == controlValue) {
                        $(objComp).val(ul.childNodes[i].innerText); //85761
                        $(objComp).editableSelect("filter");
                        return controlValue;
                    }
                }
                $(objComp).val("Select");
                $(objComp).editableSelect("filter");
                return "";
            }//Bug 83221 End
            if (objComp.maxLength > -1) {
                if (objComp.maxLength < controlValue.length)
                    controlValue = controlValue.substr(0, objComp.maxLength);
            }
            if (objComp.getAttribute("datatype") == "date")
            {
                objComp.value = controlValue;
                var el = objComp.cloneNode(true);
                var par = objComp.parentNode;
                par.removeChild(objComp);
                el.removeAttribute("xd");
                par.appendChild(el);
                attachDatePicker();
                $(el).on('dp.change', function (e) {
                    ctrOnchangeHandler(this, 1);
                    var customMethodName = el.getAttribute("method");
                    if (customMethodName != null && customMethodName != undefined)
                        parseJSON(customMethodName + "()");
                });
            }
            objComp.value = controlValue;
            if (objComp.getAttribute("maskingPattern") != null && objComp.getAttribute("maskingPattern") != 'undefined') {
                if (objComp.getAttribute("maskingPattern").toString() != 'nomasking' && objComp.getAttribute("maskingPattern").toString() != '')//Bug 81232
                    controlValue = applyMaskingValue(objComp, controlValue);//Bug 81232
            }
            if (objComp.type == 'text' && objComp.classList.contains("form-input") && controlValue != '') {
                objComp.classList.add("input-focus");
                document.getElementById(controlName + "_label").classList.add("input-focus-label");
            }
            if (objComp.type == "textarea" && objComp.classList.contains("form-textarea") && controlValue != '') {
                objComp.classList.add("input-focus");
                objComp.classList.add("textarea-focus");
                document.getElementById(controlName + "_label").classList.add("input-focus-label");
                document.getElementById(controlName + "_label").classList.add("textarea-focus-label");
            }

        }//Bug 76737 End
        if (objComp.type == 'select-one' || objComp.type == 'ComboBox')
        {
            objComp.value = controlValue;
        }
        if (objComp.type == 'select-multiple')
        {
            //jQuery(objComp).val(controlValue);   
            for (var i = 0; i < objComp.options.length; i++) {
                objComp.options[i].selected = false;
            }
            for (var i = 0; i < objComp.options.length; i++) {
                for (var j = 0; j < controlValue.length; j++) {
                    if (controlValue[j] == objComp.options[i].value)
                        objComp.options[i].selected = true;
                }
            }
            reloadListBoxLayout(controlName);
        }
        else if(objComp.tagName=='LABEL'||objComp.tagName=='A')
        {
            objComp.innerHTML = controlValue;
        }
        else if(objComp.type=='radio')
        {
            var options = document.getElementsByName(controlName);
            for (var i = 0; i < options.length; i++) {
                options[i].removeAttribute("checked");
            }
            $("#" + controlName).children(".active").removeClass("active");
            $("#" + controlName).find("input[value=" + controlValue + "]").parent().addClass("active");

            jQuery("input[name='" + controlName + "'][value='" + controlValue + "']").attr('checked', 'checked');
        }
        else if(objComp.type=='checkbox')
        {
            if (controlValue.toLowerCase() == "true")
            {
                objComp.checked = true;
            }
            else
            {
                objComp.checked = false;
            }
        }
        checkFieldMandatoryCondition(objComp);//Bug 84949
    }
    return controlValue;//Bug 81232
}
//Bug 85533 Start
function setTableCellDateRange(tableId, rowIndex, colIndex, minDate, maxDate) {
    var dateControl = getCellControl(tableId, rowIndex, colIndex);
    if (maxDate != undefined && maxDate != '')
        dateControl.setAttribute("maxdate", maxDate);
    if (minDate != undefined && minDate != '')
        dateControl.setAttribute("mindate", minDate);
}
//Bug 85533 End
function escapeStringForHTML(data) {
    if (typeof data == "string")
        return data.replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    else
        return data;
}

function getQueryVariable(queryString, variable) {
    var vars = queryString.split('&');
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split('=');
        if (decodeURIComponent(pair[0]) == variable) {
            return decodeURIComponent(pair[1]);
        }
    }
}

//Bug 85784 Start
function deleteRowsFromGridAction(tableControlId, rowIndices, altRowColor, batchCounter) {
    for (var i = rowIndices.split(",").length - 1; i >= 0; i--) {
        var rowIndex = rowIndices.split(",")[i];
        if (rowIndex != "") {
            document.getElementById(tableControlId).tBodies[0].deleteRow(rowIndex);
        }
    }
    var rows = document.getElementById(tableControlId).tBodies[0].getElementsByTagName("tr");
    var visibleRows = [];
    for (var j = 0; j < rows.length; j++) {
        if (rows[j].style.display != "none")
            visibleRows.push(rows[j]);
    }
    if (altRowColor != undefined && altRowColor != null) {
        for (var m = 0; m < visibleRows.length; m++) {
            if (m % 2 == 1)
                visibleRows[m].style.backgroundColor = "#" + altRowColor;
            else
                visibleRows[m].style.backgroundColor = "#fff";
        }
    }
    $("#" + tableControlId).floatThead('reflow');
    checkTableHeight(tableControlId);
    reshuffleIndices(tableControlId, "", batchCounter);

    if (window.deleteRowPostHook)
    {
        deleteRowPostHook(tableControlId, rowIndices);
    }
    document.getElementById("delete_"+tableControlId).disabled = true;
    if(document.getElementById("delete_"+tableControlId).childNodes[0].childElementCount > 0)
            document.getElementById("delete_"+tableControlId).childNodes[0].childNodes[0].setAttribute("src","./resources/images/DeleteIconDisabled.png");
        
}
//Bug 85784 End

//Bug 85784 Start
function calculateTotalForGrid(tableId) {
    var totalValueElements = document.getElementById('totallabel_' + tableId).innerHTML.split(",!,");
    for (var i = 0; i < totalValueElements.length; i++) {
        if (totalValueElements[i] != '') {
            $(document.getElementsByClassName(totalValueElements[i].replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&amp;/g, '&'))).each(function () {
                var typeofvalue = typeof this.getAttribute("typeofvalue") == 'undefined' ? '' : this.getAttribute("typeofvalue");
                if ((this.getAttribute("maskingpattern") != "nomasking" && this.getAttribute("maskingpattern") != "")
                        || (typeofvalue == 'Float' && this.getAttribute("maskingpattern") == "nomasking"))
                {
                    maskfield(this, 'label');
                }
            });
        }
        showTotal('', totalValueElements[i]);
    }
}
//Bug 85784 End

function refreshIndexes(xml) {
    var url = "ifhandler.jsp";
    var requestString = "pid=" + encode_utf8(pid) + "&wid=" + encode_utf8(wid) + "&tid=" + encode_utf8(tid) + "&fid=" + encode_utf8(fid) + "&op=5&AttribXML=" + encode_utf8(xml.trim());
    return iforms.ajax.processRequest(requestString, url);
}
if (!String.prototype.endsWith) {
    String.prototype.endsWith = function (search, this_len) {
        if (this_len === undefined || this_len > this.length) {
            this_len = this.length;
        }
        return this.substring(this_len - search.length, this_len) === search;
    };
}

var footerFrameName = "";
function sectionAsFooter(frameName) {
    if (frameName !== "") {
        var sectionEle = document.getElementById(frameName);
        if (sectionEle !== null) {
            footerFrameName = frameName;
            var parentElem = sectionEle.parentNode.parentNode;
            var heightOfSection = jQuery(parentElem).height();
            var browWidth = getBrowserScrollSize().width;
            jQuery("#oforms_iform").css("height", "auto");
            jQuery("#oforms_iform").css("height", parseInt(jQuery("#oforms_iform").visibleHeight()) - parseInt(heightOfSection) - 8);
            if (parentElem.parentNode.parentNode.id === "oforms_iform") {
                document.body.style.overflow = "hidden";
                document.getElementById("oforms_iform").style.overflow = "auto";
                var container = document.createElement("div");
                container.className = "container-fluid";
                parentElem.style.position = "fixed";
                parentElem.style.bottom = "0px";
                parentElem.style.width = "100%";
                container.appendChild(parentElem);
                document.body.appendChild(container);
            }
            jQuery(parentElem).width(parseInt(jQuery("#oforms_iform").width()) - 8);
        }
    }
}

$.fn.visibleHeight = function () {
    var elBottom, elTop, scrollBot, scrollTop, visibleBottom, visibleTop;
    scrollTop = $(window).scrollTop();
    scrollBot = scrollTop + $(window).height();
    elTop = this.offset().top;
    elBottom = elTop + this.outerHeight();
    visibleTop = elTop < scrollTop ? scrollTop : elTop;
    visibleBottom = elBottom > scrollBot ? scrollBot : elBottom;
    return visibleBottom - visibleTop;
}

function showAlertDialog(msg, isClose)
{
    msg="<div class='typeSuccess' style='color:#268844;margin-bottom: 10px;'><span style='font-size:35px;padding-right: 10px;' class='glyphicon glyphicon-ok-sign'></span><span style='font-size:16px;'>Success</span></div>"+msg;
    var box = bootbox.dialog({
        message: msg,
        closeButton: isClose,
        size: "small"
    });

    setTimeout(function () {
        box.modal('hide');
    }, 3000);
}
function changeSectionCaption(frameName, captionName) {
    var imgNode = document.getElementById(frameName).childNodes[0].childNodes[1];
    document.getElementById(frameName).childNodes[0].innerText = captionName;
    document.getElementById(frameName).childNodes[0].appendChild(imgNode);
}
//Bug 87917
function redirectToOmniApp() {
    var msgId = '-8002';
    var headingId = '8002';
//    if(redirectCode == '-8003')
//    {
//        headingId = '8003';
//    }
    var redirectCode = msgId;
    var url = '/omniapp/pages/error/errorpage.app?u_sc=iform&msgID=' + redirectCode + "&HeadingID=" + headingId;

    var listParam = new Array();
    var WindowHeight = 150;
    var WindowWidth = 400;
    var WindowLeft = 0;
    var WindowTop = 0;
    window.close();
    var wFeatures = 'height=' + WindowHeight + ',width=' + WindowWidth + ',resizable=0,status=1,scrollbars=auto,top=' + WindowTop + ',left=' + WindowLeft;
    var win = window.open(url, 'oapwebmain', wFeatures, false);
    win.focus();
}
//Bug 89941
function redirectToApplication()
{
    var url = window.location.toString().split('/')[0] + "//" + window.location.toString().split('/')[2] + "/" + window.location.toString().split('/')[3];
    window.location.href = url;
}

function tableCellKeyPress(tableId, cellRef, evtObj) {
    var rowIndex = $(cellRef).closest('tr').index();
    var colIndex = parseInt($(cellRef).closest('td').index()) - 1;
    var json = {};
    json["tableId"] = tableId;
    json["rowIndex"] = rowIndex;
    json["colIndex"] = colIndex;
    if (window.onTableCellKeyPress) {
        if (onTableCellKeyPress(tableId, colIndex, evtObj)) {
            executeServerEvent("", "PicklistOnTableCell", JSON.stringify(json), true);
            cancelBubble(evtObj);
        }
    }

}

function reloadTabSheet(tabId, sheetIndex) {
    var tabRef = document.getElementById(tabId);
    if (tabRef != null && tabRef != undefined) {
        var sheetLIElems = tabRef.getElementsByClassName("tabSheetLink");
        if (sheetLIElems[sheetIndex] != null && sheetLIElems[sheetIndex] != undefined) {
            var sheetId = sheetLIElems[parseInt(sheetIndex)].getAttribute("href").split('#')[1];
            LoadTab(sheetLIElems[sheetIndex], tabId, sheetId, sheetIndex, "Y");
        }
    }
}

function navigationSelection(ref) {
    var requestString = "pid=" + encode_utf8(pid) + "&wid=" + encode_utf8(wid) + "&tid=" + encode_utf8(tid) + "&fid=" + encode_utf8(fid) + "&controlId=" + ref.id;
    var url = "portal/appTask.jsp?oper=NavigationSelection";
    CreateIndicator("application");
    new net.ContentLoader(url, navigSelector, generalErrorHandler, "POST", requestString, true);
}

function routeToNavigation(ref, parameters) {
    var requestString = "pid=" + encode_utf8(pid) + "&wid=" + encode_utf8(wid) + "&tid=" + encode_utf8(tid) + "&fid=" + encode_utf8(fid) + "&controlId=" + ref.id + "&parameters=" + encode_utf8(JSON.stringify(parameters));
    var url = "portal/appTask.jsp?oper=NavigationRoute";
    CreateIndicator("application");
    new net.ContentLoader(url, navigHandler, generalErrorHandler, "POST", requestString, true);
}


function navigSelector() {
    RemoveIndicator("application");
    var responseText = this.req.responseText.trim();
    if (responseText != '') {
        var json = JSON.parse(responseText);
        if (json["status"] == "1") {
            window.location.href = "portal/initializePortal.jsp"
        }
        else{  
            showMessage("", json["message"], "error");
        }
    }
}

function navigHandler() {
    RemoveIndicator("application");
    var responseText = this.req.responseText.trim();
    if (responseText != '') {
        var json = JSON.parse(responseText);
        if (json["status"] == "1") {
            window.location.href = "portal/initializePortal.jsp"
        }
        else{ 
            showMessage("", json["message"], "error");
        }
    }
}

function routeToNextForm(ref, parameters) {
    var userNameVal = document.getElementById(parameters.UserName).value;
    var passWordVal = document.getElementById(parameters.Password).value;
    parameters["userNameVal"] = userNameVal;
    parameters["passWordVal"] = passWordVal;
    if (userNameVal == "" || userNameVal == undefined || userNameVal == null) {
        showMessage(parameters.UserName, AUTH_UNSUCCESSFUL, "error",false);
    } else if (passWordVal == "" || passWordVal == undefined || passWordVal == null) {
        showMessage(parameters.Password, BLANK_PASSWORD, "error",false);
    } else {
        var requestString = "pid=" + encode_utf8(pid) + "&wid=" + encode_utf8(wid) + "&tid=" + encode_utf8(tid) + "&fid=" + encode_utf8(fid) + "&controlId=" + ref.id + "&parameters=" + encode_utf8(JSON.stringify(parameters));
        var url = "portal/appTask.jsp?oper=Authorization";
        CreateIndicator("application");
        new net.ContentLoader(url, routingHandler, generalErrorHandler, "POST", requestString, true);
    }
}

function getTileGrpError(tileGroupId)
{
    var requestString = "pid=" + encode_utf8(pid) + "&wid=" + encode_utf8(wid) + "&tid=" + encode_utf8(tid) + "&fid=" + encode_utf8(fid) + "&tileGroupId=" + tileGroupId;
    var url = "portal/appTask.jsp?oper=getTileGrpError";
    CreateIndicator("application");
    new net.ContentLoader(url, showTileMandatoryMsg, generalErrorHandler, "POST", requestString, true);
}

function showTileMandatoryMsg()
{
    RemoveIndicator("application");
    showMessage(" ",this.req.getResponseHeader("errorMessage"), "warning",false);
}

function generalErrorHandler() {
    RemoveIndicator("application");
    if (this.req.getHeader("InvalidSession") == "Y")
        showAlertDialog("<b>" + INVALID_SESSION + "</b>", false);
    else
        showConfirm("There is some Error in Processing Request.Please try again.")
}

function routingHandler() {
    RemoveIndicator("application");
    var responseText = this.req.responseText.trim();
    if (responseText != '') {
        var json = JSON.parse(responseText);
        var userName = json["UserName"];
        if (json["status"] == "1") {
            window.location.href = "portal/initializePortal.jsp"
        }
        else if(json["status"]=="0"){  
            if (userName == null || userName == undefined) {
                document.getElementById(json.un).value = "";
                document.getElementById(json.pw).value = "";
                showMessage(json.un, json["message"], "error");
            } else {
                document.getElementById(json.un).value = userName;
                document.getElementById(json.pw).value = "";
                showMessage(json.pw, json["message"], "error");
            }
        }
    }
}

function generateSequenceForApp() {
    var seqNo = "";
    if (window.customSequenceForApp) {
        seqNo = window.customSequenceForApp();
    }

    var url = "portal/appTask.jsp";
    var queryString = "oper=UpdateUniqueNo&pid=" + encode_utf8(pid) + "&wid=" + encode_utf8(wid) + "&tid=" + encode_utf8(tid) + "&fid=" + encode_utf8(fid) + "&seqNo=" + encode_utf8(seqNo);
    var responseText = iforms.ajax.processRequest(queryString, url);
    if (responseText.trim() !== "0") {
        showMessage("", "Error in Generating Sequence..", "error");
    }
}

function loadFragment(ref, parentIndex, childIndex) {
    var validate = true;
    if (window.validateForm) {
        var stepName = $($('.navigationProgressBar')[0]).find('li.active').find(".menuLabel").html()
        validate = window.validateForm(stepName);
    }
    if (!validate)
        return false;
	try{
    if (!validateMandatoryFields())
        return false;
    saveForm("SF", true);
	}
	catch(ex){}
    var queryString = "loadFragment=Y&parentIndex=" + parentIndex + "&pid=" + encode_utf8(pid) + "&wid=" + encode_utf8(wid) + "&tid=" + encode_utf8(tid) + "&fid=" + encode_utf8(fid) + "&filterValue=" + filterValue;
    if (ref.getAttribute("type") != undefined)
        queryString += "&type=" + ref.getAttribute("type");
    if (parentIndex == '0' && (childIndex == 0 || childIndex == undefined)) {
        jQuery('#navigationBackBtn').css('pointer-events', 'none');
        jQuery('#navigationBackBtn').css('cursor', 'auto');
        jQuery('#navigationBackBtn').css('opacity', '0.50');
        jQuery('#navigationBackBtn').css('box-shadow', 'none');
    } else {
        jQuery('#navigationBackBtn').css('pointer-events', 'all');
        jQuery('#navigationBackBtn').css('cursor', 'pointer');
        jQuery('#navigationBackBtn').css('opacity', '6');
    }
    if (typeof childIndex != "undefined") {
        queryString += "&childIndex=" + childIndex;
    }
    setNavigationStyle(ref);
    var url = "action_API.jsp";
    new net.ContentLoader(url, loadFragmentHandler, generalErrorHandler, "POST", queryString, true);


}

function checkForExistingApplication() {
    if (typeof (filterValue) !== 'undefined' && filterValue === "") {
        var url = "portal/appTask.jsp";
        var queryString = "oper=CheckExisting&pid=" + encode_utf8(pid) + "&wid=" + encode_utf8(wid) + "&tid=" + encode_utf8(tid) + "&fid=" + encode_utf8(fid);
        CreateIndicator("application");
        new net.ContentLoader(url, checkHandler, checkErrorHandler, "POST", queryString, true);
    }
}

function updateDocComment(ref) {
    var comment = ref.value;
    var docId = jQuery(ref).parent().prev().find(".doc-unit-name").attr("data-docid");
    ref = jQuery(ref).parent().parent();
    var ctrId = jQuery(ref.parents(".doc-list-body")[0]).attr("id");
    var url = "portal/appTask.jsp";
    var queryString = "oper=UpdateDocComment&pid=" + encode_utf8(pid) + "&wid=" + encode_utf8(wid) + "&tid=" + encode_utf8(tid) + "&fid=" + encode_utf8(fid) + "&ctrId=" + ctrId + "&docId=" + docId + "&comment=" + encode_utf8(comment);
    //CreateIndicator("application");
    iforms.ajax.processRequest(queryString, url);
//    new net.ContentLoader(url, checkHandler, checkErrorHandler, "POST", queryString, false);
}

function deletedoc(ctrId, docId) {
    var url = "portal/appTask.jsp";
    var queryString = "oper=DeleteDoc&pid=" + encode_utf8(pid) + "&wid=" + encode_utf8(wid) + "&tid=" + encode_utf8(tid) + "&fid=" + encode_utf8(fid) + "&ctrId=" + ctrId + "&docId=" + docId;
    CreateIndicator("application");
    new net.ContentLoader(url, checkHandler, checkErrorHandler, "POST", queryString, true);
}

function showAlertDialog(msg, isClose)
{
    var box = bootbox.dialog({
        message: msg,
        closeButton: isClose,
        size: "small"
    });

    setTimeout(function () {
        box.modal('hide');
    }, 3000);
}

function checkHandler() {
    RemoveIndicator("application");
    var resp = this.req.responseText.trim();
    if (resp !== "") {
        var btns = {
            confirm: {
                label: 'Open existing Application',
                className: 'btn-success'
            },
            cancel: {
                label: 'Create New',
                className: 'btn btn-primary'
            }
        }

        var userAction = function (result) {
            var jsonobj = JSON.parse(decode_utf8(resp));
            var filterval = jsonobj.txnid;
            var stage = jsonobj.currentstage;
            var redirectURL = "portal/initializePortal.jsp?FilterValue=" + filterval;
            if (result === true) {
                window.location.href = redirectURL + "&AppStage=" + stage;
            }
            else if(result === false){
                window.location.href = redirectURL + "&new=Y";
            }
        }
        showConfirmDialog("<b>You have one already registered Application.<br>Do you want to load the existing Application or create a new one? <b>", btns, userAction);
    }
}

function checkErrorHandler() {
    RemoveIndicator("application");
}

function loadFragmentHandler() {
    var parentIndex = getQueryVariable(this.params, "parentIndex");
    var childIndex = getQueryVariable(this.params, "childIndex");

    var responseText = this.req.responseText.trim();
    if (typeof childIndex != "undefined") {
        var fragmentContainer = document.getElementById("fragmentContainer");
        fragmentContainer.innerHTML = "";
        jQuery(fragmentContainer).html(responseText);
    }
    else{
        var verNavFragParent = document.getElementById("verNavFragParent");
        if (verNavFragParent != null) {
            verNavFragParent.innerHTML = "";
            jQuery(verNavFragParent).html(responseText);
        }
        else{
            var fragmentContainer = document.getElementById("fragmentContainer");
            fragmentContainer.innerHTML = "";
            jQuery(fragmentContainer).html(responseText);
        }
    }
    var isFirst = "Y" === this.req.getResponseHeader("FirstStep");
    if (isFirst) {
        jQuery('#navigationBackBtn').css('pointer-events', 'none');
        jQuery('#navigationBackBtn').css('cursor', 'auto');
        jQuery('#navigationBackBtn').css('opacity', '0.50');
        jQuery('#navigationBackBtn').css('box-shadow', 'none');
    } else {
        jQuery('#navigationBackBtn').css('pointer-events', 'all');
        jQuery('#navigationBackBtn').css('cursor', 'pointer');
        jQuery('#navigationBackBtn').css('opacity', '6');
    }



    var isLast = "Y" === this.req.getResponseHeader("LastStep")
    if (isLast) {
        document.getElementById("finalSubmitBtn").style.display = "";
        document.getElementById("navigationNextBtn").style.display = "none";
    }
    else
    {
        document.getElementById("finalSubmitBtn").style.display = "none";
        document.getElementById("navigationNextBtn").style.display = "";
    }
    var type = getQueryVariable(this.params, "type");
    if (type === "5")
    {
        var subStepParent = document.getElementsByClassName("verticalNavigationContainer")[0].childNodes[0];
        if (subStepParent.childNodes.length != 0)
        {
            var lastIndex = subStepParent.childNodes.length - 1;
            var b = $("[type=5]").length;
            for (var i = 0; i < b; i++)
            {
                $($("[type=5]")[0]).removeAttr('type');
            }
            //Clicking the last substep.
            subStepParent.childNodes[lastIndex].click();
        }
    }
    setProgressBar();
    alignNavigationContainerStyle();
    doInit('fragment');
    executeLoadEvents("7");
}

function setNavigationStyle(ref) {
    if ($(ref).hasClass("verticalNavigationProgressBar-item")) {
        $($(ref).closest('ul')[0]).find('li').each(function () {
            $(this).removeClass("current");
            $(this).removeClass("completed");
            $(this).removeClass("over50");
        });
        $(ref).prevAll().each(function () {
            $(this).addClass("completed");
        });
        $(ref).addClass("current");
        $(ref).addClass("over50");
    }
    else if($(ref).hasClass("sideMenuItem")){
        $($(ref).closest('ul')[0]).find('.sideMenuItem').each(function () {
            $(this).removeClass("active");
        });
        $(ref).addClass("active");
        $($(ref).find(".sideMenuChildNavigationBar")[0]).find('li').each(function () {
            $(this).removeClass("active");
        });
        $($($(ref).find(".sideMenuChildNavigationBar")[0]).find('li')[0]).addClass("active");
    }
    else{
        $($(ref).closest('ul')[0]).find('li').each(function () {
            $(this).removeClass("active");
            $(this).removeClass("completed");
        });
        $(ref).prevAll().each(function () {
            $(this).addClass("completed");
        });
        $(ref).addClass("active");
    }
}

function alignNavigationContainerStyle() {
    var headerframe = document.getElementsByClassName('headerframe');
    var headerHeight = 0;
    //if the length of headerframe is 1 that means we have no headerframe outside of widget and no need to substract its height
//    if (headerframe !== null && headerframe.length > 0 )
//    {
//        headerHeight = $(headerframe[0].childNodes[0]).outerHeight();
//    }
    if ($('.stepNavigationContainerParent')[0] != null) {
        var windowHeight = $(window).height();
        if(document.getElementById("verticalNavigationContainerParent")!=null){
            var stepNavigationTopBarHeight = $($('.stepNavigationContainerParent')[0]).outerHeight();
            var containerHeight = windowHeight - stepNavigationTopBarHeight - 20;
            containerHeight -= $('#portalicon').outerHeight();
            $($(".verticalNavigationContainerParent")[0]).outerHeight(containerHeight + 43 - headerHeight);
            $($(".fragmentContainerParent")[0]).outerHeight(containerHeight + 43 - headerHeight);
        }
        else
        {
            var containerHeight = windowHeight - 20;
            $($(".verticalNavigationContainerParent")[0]).outerHeight(containerHeight - headerHeight);
            $($(".fragmentContainerParent")[0]).outerHeight(containerHeight - headerHeight);
        }
    }
    else if($('.sideMenuNavigationBarParent')[0]!=null){
        var windowHeight = $(window).height();
        var containerHeight = windowHeight - 20;
        $($(".sideMenuNavigationBarParent")[0]).outerHeight(containerHeight - headerHeight);
        $($(".fragmentContainerParent")[0]).outerHeight(containerHeight - headerHeight);
    }
}

function navigationBackClick(ref) {
    var validate = true;
    if (window.validateForm) {
        var stepName = $($('.navigationProgressBar')[0]).find('li.active').find(".menuLabel").html()
        validate = window.validateForm(stepName);
    }
    if (!validate)
        return false;
    saveForm("SF", true);
    if ($('.stepNavigationContainerParent')[0] != null) {
        var currentElement = $($('.navigationProgressBar')[0]).find('li.active')[0];
        var parentIndex = $($($('.navigationProgressBar')[0]).find('li.active')[0]).index();
        if ($($('.verticalNavigationProgressBar')[0]).find('li')[0] != null) {
            var childCurrentElement = $($('.verticalNavigationProgressBar')[0]).find('li.current')[0];
            var childIndex = $($($('.verticalNavigationProgressBar')[0]).find('li.current')[0]).index();
            if (childIndex == 0) {
                if (parentIndex != 0) {
                    currentElement.previousSibling.setAttribute("type", "5");
                    currentElement.previousSibling.click();
                }
            }
            else{
                childCurrentElement.previousSibling.click();
                $("#verticalNavigationContainerParent").animate({
                    scrollTop: $("#verticalNavigationContainerParent").scrollTop() - 50
                });
            }
        }
        else{
            if (parentIndex != 0) {
                currentElement.previousSibling.setAttribute("type", "5");
                currentElement.previousSibling.click();
            }
        }
    }
    else if($('.sideMenuNavigationBarParent')[0]!=null){
        var currentElement = $($('.sideMenuNavigationBar')[0]).find('li.active.sideMenuItem')[0];
        var parentIndex = $(currentElement).index();
        if ($(currentElement).find('.sideMenuChildNavigationBar')[0] != null) {
            var childCurrentElement = $($(currentElement).find('.sideMenuChildNavigationBar')[0]).find('li.active')[0];
            var childIndex = $($($(currentElement).find('.sideMenuChildNavigationBar')[0]).find('li.active')[0]).index();
            if (childIndex == 0) {
                if (parentIndex != 0) {
                    currentElement.previousSibling.click();
                }
            }
            else{
                childCurrentElement.previousSibling.click();
                $("#sideMenuNavigationBarParent").animate({
                    scrollTop: $("#sideMenuNavigationBarParent").scrollTop() - 50
                });
            }
        }
        else{
            if (parentIndex != 0) {
                currentElement.previousSibling.click();
            }
        }

    }
    executeLoadEvents("5");
}

function SubmitData(ref) {
    if (!validateMandatoryFields())
        return false;
    saveForm("SF", true);



    var btns = {
        confirm: {
            label: 'Yes',
            className: 'btn-success'
        },
        cancel: {
            label: 'No',
            className: 'btn btn-primary'
        }
    }

    var userAction = function (result) {
        if (result === true) {
            document.getElementById('finalSubmitBtn').disabled = 'disabled';
            var url = "portal/appTask.jsp";
            var queryString = "oper=Introduce&pid=" + encode_utf8(pid) + "&wid=" + encode_utf8(wid) + "&tid=" + encode_utf8(tid) + "&fid=" + encode_utf8(fid);
            CreateIndicator("application");
            new net.ContentLoader(url, introHandler, introErrorHandler, "POST", queryString, true);
            }
            else if(result === false){                
            showAlertDialog("Please close the window.", false);
        }
    }
    showConfirmDialog("Do you want to submit the Application.?", btns, userAction,false);
}

function cleanPortalSession() {
    var url = "cleanSession.jsp";
    var requestString = "pid=" + pid + "&wid=" + wid + "&taskid=" + tid + "&fid=" + fid;
    requestString += "&ps=Y";
    new net.ContentLoader(url, sessionClearHandler, formErrorHandler, "POST", requestString, false);
}

function sessionClearHandler() {
    redirectToApplication();
}

function introHandler() {
    RemoveIndicator("application");
    if(window.showSuccessMessageInApplication){
        if(this.req.getResponseHeader("ResponseFromCall")!=null){
          window.showSuccessMessageInApplication(this.req.getResponseHeader("ResponseFromCall"));
        } else{
            showAlertDialog("Your Application has been submitted.", false);
            cleanPortalSession();
        }
    } else {
        showAlertDialog("Your Application has been submitted.", false);
        cleanPortalSession();
    }  
}

function introErrorHandler() {
    RemoveIndicator("application");
}

function navigationNextClick(ref) {
    var validate = true;
    if (window.validateForm) {
        var stepName = $($('.navigationProgressBar')[0]).find('li.active').find(".menuLabel").html()
        validate = window.validateForm(stepName);
    }
    if (!validate)
        return false;
    var tileCtrls=$("[groupname]");
    var grpname="";
    var isGroupSelected=false;
    for(var i=0;i<tileCtrls.length;i++)
    {
        if($(tileCtrls[i]).attr('mandatory')==="true"&&$(tileCtrls[i]).attr('groupname')!==grpname)
        {
            grpname=$(tileCtrls[i]).attr('groupname');
            isGroupSelected=false;
            var tempCtrls=$("[groupname="+grpname+"]");
            for(var j=0;j<tempCtrls.length;j++)
            {
                if($(tempCtrls[j]).css('display')==='none')
                {
                    isGroupSelected=true;
                    break;
                }
            }
        }
        else if($(tileCtrls[i]).attr('groupname')==="")
            isGroupSelected=true;
        if(!isGroupSelected)
        {
            break;
        }
    }
    if(!isGroupSelected&&tileCtrls.length!=0)
    {
        getTileGrpError(grpname);
        return false;
    }
    
    if (!validateMandatoryFields())
        return false;
    saveForm("SF", true);
    if ($('.stepNavigationContainerParent')[0] != null) {
        var currentElement = $($('.navigationProgressBar')[0]).find('li.active')[0];
        var parentIndex = $($($('.navigationProgressBar')[0]).find('li.active')[0]).index();
        var totalParentElements = $($('.navigationProgressBar')[0]).children().length;
        if ($($('.verticalNavigationProgressBar')[0]).find('li')[0] != null) {
            var childCurrentElement = $($('.verticalNavigationProgressBar')[0]).find('li.current')[0];
            var totalChildElements = $($('.verticalNavigationProgressBar')[0]).children().length;
            var childIndex = $($($('.verticalNavigationProgressBar')[0]).find('li.current')[0]).index();
            if (childIndex == totalChildElements - 1) {
                if (parentIndex != totalParentElements - 1) {
                    currentElement.nextSibling.click();
                }
            }
            else{
                childCurrentElement.nextSibling.click();
                $("#verticalNavigationContainerParent").animate({
                    scrollTop: 50 * (childIndex + 1)
                });
            }
        }
        else{
            if (parentIndex != totalParentElements - 1) {
                currentElement.nextSibling.click();
            }
        }
    }
    else if($('.sideMenuNavigationBarParent')[0]!=null){
        var currentElement = $($('.sideMenuNavigationBar')[0]).find('li.active.sideMenuItem')[0];
        var parentIndex = $(currentElement).index();
        var totalParentElements = $($('.sideMenuNavigationBar')[0]).children().length;
        if ($(currentElement).find('.sideMenuChildNavigationBar')[0] != null) {
            var childCurrentElement = $($(currentElement).find('.sideMenuChildNavigationBar')[0]).find('li.active')[0];
            var totalChildElements = $($(currentElement).find('.sideMenuChildNavigationBar')[0]).children().length;
            var childIndex = $($($(currentElement).find('.sideMenuChildNavigationBar')[0]).find('li.active')[0]).index();
            if (childIndex == totalChildElements - 1) {
                if (parentIndex != totalParentElements - 1) {
                    currentElement.nextSibling.click();
                }
            }
            else{
                childCurrentElement.nextSibling.click();
                $("#sideMenuNavigationBarParent").animate({
                    scrollTop: 50 * (childIndex + 1)
                });
            }
        }
        else{
            if (parentIndex != totalParentElements - 1) {
                currentElement.nextSibling.click();
            }
        }
    }
    executeLoadEvents("6");
}

function setProgressBar() {
    if ($('.stepNavigationContainerParent')[0] != null) {
        var currentElement = $($('.navigationProgressBar')[0]).find('li.active')[0];
        var parentIndex = $($($('.navigationProgressBar')[0]).find('li.active')[0]).index();
        var totalParentElements = $($('.navigationProgressBar')[0]).children().length;
        if ($($('.verticalNavigationProgressBar')[0]).find('li')[0] != null) {
            var childCurrentElement = $($('.verticalNavigationProgressBar')[0]).find('li.current')[0];
            var totalChildElements = $($('.verticalNavigationProgressBar')[0]).children().length;
            var childIndex = $($($('.verticalNavigationProgressBar')[0]).find('li.current')[0]).index();
            var percentage = (childIndex) * 1.0 / (totalChildElements);
            var degrees = percentage * 360;
            if (percentage > 0.5)
                $(currentElement).addClass("over50");
            else
                $(currentElement).removeClass("over50");
            $(currentElement).find('.completedProgressSegmentValueBar').css("transform", "rotate(" + degrees + "deg)");
        }
        else{
            $(currentElement).removeClass("over50");
            $(currentElement).find('.completedProgressSegmentValueBar').css("transform", "rotate(0deg)");
        }
    }
}

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/*-------------------------------------------custom_dropdown.js-----------------------------------------------------*/


var phone_codeJson = {"BD": "880", "BE": "32", "BF": "226", "BG": "359", "BA": "387", "BB": "+1-246", "WF": "681", "BL": "590", "BM": "+1-441", "BN": "673", "BO": "591", "BH": "973", "BI": "257", "BJ": "229", "BT": "975", "JM": "+1-876", "BV": "", "BW": "267", "WS": "685", "BQ": "599", "BR": "55", "BS": "+1-242", "JE": "+44-1534", "BY": "375", "BZ": "501", "RU": "7", "RW": "250", "RS": "381", "TL": "670", "RE": "262", "TM": "993", "TJ": "992", "RO": "40", "TK": "690", "GW": "245", "GU": "+1-671", "GT": "502", "GS": "", "GR": "30", "GQ": "240", "GP": "590", "JP": "81", "GY": "592", "GG": "+44-1481", "GF": "594", "GE": "995", "GD": "+1-473", "GB": "44", "GA": "241", "SV": "503", "GN": "224", "GM": "220", "GL": "299", "GI": "350", "GH": "233", "OM": "968", "TN": "216", "JO": "962", "HR": "385", "HT": "509", "HU": "36", "HK": "852", "HN": "504", "HM": " ", "VE": "58", "PR": "+1-787 and 1-939", "PS": "970", "PW": "680", "PT": "351", "SJ": "47", "PY": "595", "IQ": "964", "PA": "507", "PF": "689", "PG": "675", "PE": "51", "PK": "92", "PH": "63", "PN": "870", "PL": "48", "PM": "508", "ZM": "260", "EH": "212", "EE": "372", "EG": "20", "ZA": "27", "EC": "593", "IT": "39", "VN": "84", "SB": "677", "ET": "251", "SO": "252", "ZW": "263", "SA": "966", "ES": "34", "ER": "291", "ME": "382", "MD": "373", "MG": "261", "MF": "590", "MA": "212", "MC": "377", "UZ": "998", "MM": "95", "ML": "223", "MO": "853", "MN": "976", "MH": "692", "MK": "389", "MU": "230", "MT": "356", "MW": "265", "MV": "960", "MQ": "596", "MP": "+1-670", "MS": "+1-664", "MR": "222", "IM": "+44-1624", "UG": "256", "TZ": "255", "MY": "60", "MX": "52", "IL": "972", "FR": "33", "IO": "246", "SH": "290", "FI": "358", "FJ": "679", "FK": "500", "FM": "691", "FO": "298", "NI": "505", "NL": "31", "NO": "47", "NA": "264", "VU": "678", "NC": "687", "NE": "227", "NF": "672", "NG": "234", "NZ": "64", "NP": "977", "NR": "674", "NU": "683", "CK": "682", "XK": "", "CI": "225", "CH": "41", "CO": "57", "CN": "86", "CM": "237", "CL": "56", "CC": "61", "CA": "1", "CG": "242", "CF": "236", "CD": "243", "CZ": "420", "CY": "357", "CX": "61", "CR": "506", "CW": "599", "CV": "238", "CU": "53", "SZ": "268", "SY": "963", "SX": "599", "KG": "996", "KE": "254", "SS": "211", "SR": "597", "KI": "686", "KH": "855", "KN": "+1-869", "KM": "269", "ST": "239", "SK": "421", "KR": "82", "SI": "386", "KP": "850", "KW": "965", "SN": "221", "SM": "378", "SL": "232", "SC": "248", "KZ": "7", "KY": "+1-345", "SG": "65", "SE": "46", "SD": "249", "DO": "+1-809 and 1-829", "DM": "+1-767", "DJ": "253", "DK": "45", "VG": "+1-284", "DE": "49", "YE": "967", "DZ": "213", "US": "1", "UY": "598", "YT": "262", "UM": "1", "LB": "961", "LC": "+1-758", "LA": "856", "TV": "688", "TW": "886", "TT": "+1-868", "TR": "90", "LK": "94", "LI": "423", "LV": "371", "TO": "676", "LT": "370", "LU": "352", "LR": "231", "LS": "266", "TH": "66", "TF": "", "TG": "228", "TD": "235", "TC": "+1-649", "LY": "218", "VA": "379", "VC": "+1-784", "AE": "971", "AD": "376", "AG": "+1-268", "AF": "93", "AI": "+1-264", "VI": "+1-340", "IS": "354", "IR": "98", "AM": "374", "AL": "355", "AO": "244", "AQ": "", "AS": "+1-684", "AR": "54", "AU": "61", "AT": "43", "AW": "297", "IN": "91", "AX": "+358-18", "AZ": "994", "IE": "353", "ID": "62", "UA": "380", "QA": "974", "MZ": "258"}

var country_codeJson = {"BD": "Bangladesh", "BE": "Belgium", "BF": "Burkina Faso", "BG": "Bulgaria", "BA": "Bosnia and Herzegovina", "BB": "Barbados", "WF": "Wallis and Futuna", "BL": "Saint Barthelemy", "BM": "Bermuda", "BN": "Brunei", "BO": "Bolivia", "BH": "Bahrain", "BI": "Burundi", "BJ": "Benin", "BT": "Bhutan", "JM": "Jamaica", "BV": "Bouvet Island", "BW": "Botswana", "WS": "Samoa", "BQ": "Bonaire, Saint Eustatius and Saba ", "BR": "Brazil", "BS": "Bahamas", "JE": "Jersey", "BY": "Belarus", "BZ": "Belize", "RU": "Russia", "RW": "Rwanda", "RS": "Serbia", "TL": "East Timor", "RE": "Reunion", "TM": "Turkmenistan", "TJ": "Tajikistan", "RO": "Romania", "TK": "Tokelau", "GW": "Guinea-Bissau", "GU": "Guam", "GT": "Guatemala", "GS": "South Georgia and the South Sandwich Islands", "GR": "Greece", "GQ": "Equatorial Guinea", "GP": "Guadeloupe", "JP": "Japan", "GY": "Guyana", "GG": "Guernsey", "GF": "French Guiana", "GE": "Georgia", "GD": "Grenada", "GB": "United Kingdom", "GA": "Gabon", "SV": "El Salvador", "GN": "Guinea", "GM": "Gambia", "GL": "Greenland", "GI": "Gibraltar", "GH": "Ghana", "OM": "Oman", "TN": "Tunisia", "JO": "Jordan", "HR": "Croatia", "HT": "Haiti", "HU": "Hungary", "HK": "Hong Kong", "HN": "Honduras", "HM": "Heard Island and McDonald Islands", "VE": "Venezuela", "PR": "Puerto Rico", "PS": "Palestinian Territory", "PW": "Palau", "PT": "Portugal", "SJ": "Svalbard and Jan Mayen", "PY": "Paraguay", "IQ": "Iraq", "PA": "Panama", "PF": "French Polynesia", "PG": "Papua New Guinea", "PE": "Peru", "PK": "Pakistan", "PH": "Philippines", "PN": "Pitcairn", "PL": "Poland", "PM": "Saint Pierre and Miquelon", "ZM": "Zambia", "EH": "Western Sahara", "EE": "Estonia", "EG": "Egypt", "ZA": "South Africa", "EC": "Ecuador", "IT": "Italy", "VN": "Vietnam", "SB": "Solomon Islands", "ET": "Ethiopia", "SO": "Somalia", "ZW": "Zimbabwe", "SA": "Saudi Arabia", "ES": "Spain", "ER": "Eritrea", "ME": "Montenegro", "MD": "Moldova", "MG": "Madagascar", "MF": "Saint Martin", "MA": "Morocco", "MC": "Monaco", "UZ": "Uzbekistan", "MM": "Myanmar", "ML": "Mali", "MO": "Macao", "MN": "Mongolia", "MH": "Marshall Islands", "MK": "Macedonia", "MU": "Mauritius", "MT": "Malta", "MW": "Malawi", "MV": "Maldives", "MQ": "Martinique", "MP": "Northern Mariana Islands", "MS": "Montserrat", "MR": "Mauritania", "IM": "Isle of Man", "UG": "Uganda", "TZ": "Tanzania", "MY": "Malaysia", "MX": "Mexico", "IL": "Israel", "FR": "France", "IO": "British Indian Ocean Territory", "SH": "Saint Helena", "FI": "Finland", "FJ": "Fiji", "FK": "Falkland Islands", "FM": "Micronesia", "FO": "Faroe Islands", "NI": "Nicaragua", "NL": "Netherlands", "NO": "Norway", "NA": "Namibia", "VU": "Vanuatu", "NC": "New Caledonia", "NE": "Niger", "NF": "Norfolk Island", "NG": "Nigeria", "NZ": "New Zealand", "NP": "Nepal", "NR": "Nauru", "NU": "Niue", "CK": "Cook Islands", "XK": "Kosovo", "CI": "Ivory Coast", "CH": "Switzerland", "CO": "Colombia", "CN": "China", "CM": "Cameroon", "CL": "Chile", "CC": "Cocos Islands", "CA": "Canada", "CG": "Republic of the Congo", "CF": "Central African Republic", "CD": "Democratic Republic of the Congo", "CZ": "Czech Republic", "CY": "Cyprus", "CX": "Christmas Island", "CR": "Costa Rica", "CW": "Curacao", "CV": "Cape Verde", "CU": "Cuba", "SZ": "Swaziland", "SY": "Syria", "SX": "Sint Maarten", "KG": "Kyrgyzstan", "KE": "Kenya", "SS": "South Sudan", "SR": "Suriname", "KI": "Kiribati", "KH": "Cambodia", "KN": "Saint Kitts and Nevis", "KM": "Comoros", "ST": "Sao Tome and Principe", "SK": "Slovakia", "KR": "South Korea", "SI": "Slovenia", "KP": "North Korea", "KW": "Kuwait", "SN": "Senegal", "SM": "San Marino", "SL": "Sierra Leone", "SC": "Seychelles", "KZ": "Kazakhstan", "KY": "Cayman Islands", "SG": "Singapore", "SE": "Sweden", "SD": "Sudan", "DO": "Dominican Republic", "DM": "Dominica", "DJ": "Djibouti", "DK": "Denmark", "VG": "British Virgin Islands", "DE": "Germany", "YE": "Yemen", "DZ": "Algeria", "US": "United States", "UY": "Uruguay", "YT": "Mayotte", "UM": "United States Minor Outlying Islands", "LB": "Lebanon", "LC": "Saint Lucia", "LA": "Laos", "TV": "Tuvalu", "TW": "Taiwan", "TT": "Trinidad and Tobago", "TR": "Turkey", "LK": "Sri Lanka", "LI": "Liechtenstein", "LV": "Latvia", "TO": "Tonga", "LT": "Lithuania", "LU": "Luxembourg", "LR": "Liberia", "LS": "Lesotho", "TH": "Thailand", "TF": "French Southern Territories", "TG": "Togo", "TD": "Chad", "TC": "Turks and Caicos Islands", "LY": "Libya", "VA": "Vatican", "VC": "Saint Vincent and the Grenadines", "AE": "United Arab Emirates", "AD": "Andorra", "AG": "Antigua and Barbuda", "AF": "Afghanistan", "AI": "Anguilla", "VI": "U.S. Virgin Islands", "IS": "Iceland", "IR": "Iran", "AM": "Armenia", "AL": "Albania", "AO": "Angola", "AQ": "Antarctica", "AS": "American Samoa", "AR": "Argentina", "AU": "Australia", "AT": "Austria", "AW": "Aruba", "IN": "India", "AX": "Aland Islands", "AZ": "Azerbaijan", "IE": "Ireland", "ID": "Indonesia", "UA": "Ukraine", "QA": "Qatar", "MZ": "Mozambique"}



$(document).ready(function () {

    try {
        for (var i = 0; i < Object.keys(phone_codeJson).length; i++) {
            $(".compund-dropdown2").append('<option value="' + Object.keys(phone_codeJson)[i] + '">' + getObjectValues(phone_codeJson)[i] + '</option>');
            $(".compund-input2").append('<option value="' + Object.keys(country_codeJson)[i] + '">' + getObjectValues(country_codeJson)[i] + '</option>');
        }

        $(document).on('change', '.compund-dropdown2', function () {
            $(this).next(".compund-input2").val($(this).val());
        });
        $(document).on('change', '.compund-input2', function () {
            $(this).prev(".compund-dropdown2").val($(this).val());
        });


        initialiseSlider(0, '');
    }
      catch(ex){}
});


function getObjectValues(obj) {
    var vals = Object.keys(obj).map(function (key) {
    return obj[key];})

    return vals;
}

/*-------------------------------------------custom_slider.js-----------------------------------------------------*/

function initialiseSlider(val, id) {
    $("input[type='range']").each(function (index) {
        var sliderMax = $(".slider2").eq(index).attr("max");
        var sliderMin = $(".slider2").eq(index).attr("min");
//        var sliderUnit = $(".slider2").eq(index).attr("unit");
        //var secondRangeVal = Math.floor((sliderMax-sliderMin+1)/4);
        //var thirdRangeVal = Math.floor((sliderMax-sliderMin+1)/2);
        //var fourthRangeVal = Math.floor(3*(sliderMax-sliderMin+1)/4);

        $(".leftRange p").eq(index).text(sliderMin);
        //$(".secondRange p").eq(index).text(secondRangeVal+" $");
        //$(".thirdRange p").eq(index).text(thirdRangeVal+" $");
        //$(".fourthRange p").eq(index).text(fourthRangeVal+" $");
        $(".rightRange p").eq(index).text(sliderMax);
    });
    if (val != 0)
    {
        var customSlider = $(document.getElementById("range" + id));
        var colorRange = $(document.getElementById(id));
        var value = document.getElementById("range" + id).getAttribute("value");
        var max = document.getElementById("range" + id).getAttribute("max");
        var min = document.getElementById("range" + id).getAttribute("min");
        var width = customSlider.width();
        var percentage = (value - min) / (max - min);
        colorRange.width(width * percentage);
    }


    var sliderClass = document.getElementsByClassName("slider2");
    for (var i = 0; i < sliderClass.length; i++) {
        sliderClass[i].addEventListener('change', updateSlider, false);
    }

    $(document).on('change', '.slider2', function () {
        $(this).prev(".textRange").children(".textRangeValue").val($(this).val());
    });

   $(document).on('change', '.textRangeValue', function () {
        if(parseFloat($(this).val())>parseFloat($(this).attr('max'))&&$(this).val()!="")
        {
            showAlertDialog("Cant enter more than max "+parseFloat($(this).attr('max')), false);
            while(parseFloat($(this).val())>parseFloat($(this).attr('max')))
            {
                $(this).val("");
            }
        }
        else
        {
            if(parseFloat($(this).val())<parseFloat($(this).attr('min'))&&$(this).val()!="")
            {
                showAlertDialog("Cant enter less than min "+parseFloat($(this).attr('min')), false);
                $(this).val("");
                $(this).parent().next("input").val($(this).attr('min'));
            }
            else
            {
                if($(this).val()==="")
                    $(this).parent().next("input").val($(this).attr('min'));
                else    
                    $(this).parent().next("input").val($(this).val());
            }
        }
        updateSlider();
    });


    //$(document).on('change','.textRangeValue',function(){ $(".colorRange").width(0); });

    $(document).on('mouseenter', '.slider2', function () {
        var titleVal = $(this).val();
        $(this).attr('title', titleVal);
    });

}


var width = $(window).width();
$(window).on('resize', function () {
    if ($(this).width() != width) {
        width = $(this).width();
        updateSlider();
    }
});
    

function updateSlider(e) {
    var customSlider = $(".slider2");
    for (var i = 0; i < customSlider.length; i++) {
        var slider = jQuery(customSlider[i]);
        var fill = jQuery($(".colorRange")[i]);
        var val = slider.val();
        var max = slider.attr("max");
        var min = slider.attr("min");
        var width = slider.width();
        var percentage = (val - min) / (max - min);
        jQuery($(".colorRange")[i]).width(width * percentage);
    }
    if (e != undefined)
    {
        e.target.setAttribute("value", parseFloat(e.target.value));
        var jsonobj = {};
        var id=e.target.id;
        jsonobj[id]=e.target.value;
        setValues(jsonobj,true);
        //ctrOnchangeHandler(e.target, 1);
    }
}





function saveToggleData(ref)
{
    ref.setAttribute("value", ref.checked);
    ctrOnchangeHandler(ref, 1);
}
function openNavigationForm(opt, ref) {
    var tileName = ref.parentNode.parentNode.parentNode.id;
    if (window.setNavigationForm)
        setNavigationForm(opt, tileName);
}
/*-------------------------------------------tile.js-----------------------------------------------------*/

$(document).on('click', '.tile-button-select', function (event) {
    var current_btn = $(event.currentTarget);
    var grpname = current_btn.attr('groupname');
    var mode = current_btn.attr('mode');
    var buttons = document.querySelectorAll('[groupname="' + grpname + '"]');
    if (mode == 'Single')
    {
        for (var i = 0; i < buttons.length; i++)
        {
            if (!(buttons[i].id == current_btn.attr('id')))
            {
                document.getElementById(buttons[i].id.split('-')[0] + '-false').click();
            }
        }
    }
    if (current_btn.attr('tileStyle') === 'Style2' || current_btn.attr('tileStyle') === 'Style3')
    {
        $(current_btn).parent().parent().parent().parent().css({"box-shadow": "0 3px 9px 0 rgba(0,0,0,0.14)"});
        $(current_btn).parent().parent().parent().parent().css('top',0);
        $(current_btn).parent().parent().parent().parent().addClass('tileborder');
        $(current_btn).parent().parent().parent().parent().parent().find(".tile-selected").show();
    }
    else 
    {
        $(current_btn).parent().parent().parent().css({"box-shadow": "0 3px 9px 0 rgba(0,0,0,0.14)"});
        $(current_btn).parent().parent().parent().css('top',0);
        $(current_btn).parent().parent().parent().addClass('tileborder');
        $(current_btn).parent().parent().parent().parent().find(".tile-selected").show();
    }

    
    $(current_btn).hide();
    $(current_btn).siblings().show();
});

$(document).on('click', '.tile-button-remove', function (event) {

    var current_btn = $(event.currentTarget);
    if (current_btn.attr('tileStyle') === 'Style2' || current_btn.attr('tileStyle') === 'Style3')
    {
        $(current_btn).parent().parent().parent().parent().css("box-shadow" , "none" );
        $(current_btn).parent().parent().parent().parent().css('top',22);
        $(current_btn).parent().parent().parent().parent().removeClass('tileborder');
        $(current_btn).parent().parent().parent().parent().parent().find(".tile-selected").hide();
    }
    else 
    {
        $(current_btn).parent().parent().parent().css("box-shadow" , "none" );
        $(current_btn).parent().parent().parent().css('top',22);
        $(current_btn).parent().parent().parent().removeClass('tileborder');
        $(current_btn).parent().parent().parent().parent().find(".tile-selected").hide();
    }

    $(current_btn).siblings().show();
    $(current_btn).hide();
});

/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
if(!customMsgJSON){
    var customMsgJSON = {
        
    };
}
/*
 *19/02/2018              Bug 75573 - JbossEAP+SQL+IBPS4.0+Arabic:Validation message should be shown in Arabic. 
 */

var MSG_ONLY="فقط "
var MSG_ARE_ALLOWED=" مسموح بها !"
var MSG_ALPHABETS=" حروف ابجدية"
var MSG_NUMBERS=" ارقام"
var MSG_SPACES=" مسافات"
var MSG_CUSTOM_PATTERN=" قيم مطابقة النمط"
var NO_CHAR_ALLOWED="غير مسموح بالحروف !"
var ENTER_VALUE_BETWEEN = " يرجي ادخال قيمة بين"
var FLOAT_RANGE = '-2147483648 و 2147483647'
var INTEGER_RANGE = '-32768 و 32767'
var ENTER_CORRECT_VALUE = " يرجي ادخال القيمة الصحيحة"
var ENTER_CORRECT_VALUE_FOR= "أدخل القيمة الصحيحة ل ";
var PRECISION_VALUE="الاحكام ينبغي يكون في نطاق من 0 إلى";
var CORRECT_VALUE="القيمة ليست في النطاق";
var FLOAT_LENGTH="الحد الأقصى للطول هو 15";
var INVALID_EMAIL="يرجى إدخال معرف البريد الإلكتروني صالح."
var BATCH_MSG="هل تريد حفظ البيانات الحالية؟";
var INVALID_PHONE="الرجاء إدخال رقم هاتف صحيح"
var MINMAXVALUEMSG="يجب أن تكون القيمة بين";
var MSG_AND=" و ";
var ONPASTE_MSG=" يمكن لصق الأحرف في هذا الحقل نظرًا لأنه يحتوي على عدد أحرف يبلغ ";
var ONLY_FIRST="فقط الأول ";
var YES="نعم";
var NO="لا";
var SPACE_NOT_ALLOWED="المسافات غير مسموح بها أثناء اللصق";
var NUMBER_NOT_ALLOWED="الأرقام غير مسموح بها أثناء اللصق";
var ALPHABET_NOT_ALLOWED="الحروف الهجائية غير مسموح بها أثناء اللصق";
var NOT_ALLOWED="غير مسموح به أثناء اللصق ";
var INVALID_SESSION="جلسة غير صالحة";
var SELECT="تحديد";
var AUTH_UNSUCCESSFUL="معلومات تسجيل الدخول غير صالحة";
var BLANK_PASSWORD="من فضلك أدخل رقمك السري";
var NOT_ALLOWED="غير مسموح به أثناء اللصق ";
var IS_NOT_ALLOWED = "غير مسموح";
var INVALID_POSITION = "موضع غير صالح لـ";
var CANNOT_USE ="لا يمكن استخدام";
var MIN_VALUE_ERROR="الحد الأدنى لقيمة التحكم هو";
var MAX_VALUE_ERROR="الحد الأقصى لقيمة التحكم هو";
var SELECT_ALL="اختر الكل";
var NONE_SELECTED="لم يتم تحديد شيء";
var SELECTED_TEXT="المحدد";
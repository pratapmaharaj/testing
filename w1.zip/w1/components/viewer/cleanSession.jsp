<%@page import="com.newgen.iforms.util.IFormUtility"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%-- 
    Document   : cleanSession
    Created on : Nov 14, 2018, 5:13:11 PM
    Author     : g.sharma
--%>


<%
HttpSession session1=request.getSession(false);
String pid=IFormUtility.escapeHtml4(request.getParameter("pid"));
String wid=IFormUtility.escapeHtml4(request.getParameter("wid"));
String taskid=IFormUtility.escapeHtml4(request.getParameter("taskid"));
if (session1 != null) {
    if("Y".equals(IFormUtility.escapeHtml4(request.getParameter("ps")))){
        session1.invalidate();
    }
    else{
        String tempFid="_"+pid+"_"+wid;
        if(taskid!=null && !taskid.isEmpty())
            tempFid+="_"+taskid;
        session1.removeAttribute("iForm"+tempFid+"Session");
        session1.removeAttribute("iTemplateTaskForm"+tempFid+"Session");
        session1.removeAttribute("iDataTemplateTaskForm"+tempFid+"Session");
        session1.removeAttribute("objForm"+tempFid+"Viewer");
        session1.removeAttribute("objTemplateTaskForm"+tempFid+"Viewer");
        session1.removeAttribute("objDataTemplateTaskForm"+tempFid+"Viewer");
    }
} 

%>

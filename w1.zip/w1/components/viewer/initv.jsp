<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%-- 
    Document   : initv
    Created on : Nov 20, 2015, 4:18:01 PM
    Author     : puneet.pahuja
--%>
<%@page import="com.newgen.iforms.util.IFormUtility"%>
<%@page import="java.io.PrintWriter"%>
<%@page import="com.newgen.mvcbeans.controller.workdesk.WDWorkitems"%>
<%@page import="com.newgen.commonlogger.NGUtil"%>
<%@page import="com.newgen.iforms.controls.util.IFormConstants"%>
<%@page import="java.io.IOException"%>
<%@page import="com.newgen.iforms.xmlapi.IFormXmlResponse"%>
<%@page import="java.util.Locale"%>
<%@page import="com.newgen.iforms.session.IFormSession"%>

<%
     response.setHeader("Cache-Control", "no-store"); //HTTP 1.1
     response.setHeader("Pragma", "no-cache"); //HTTP 1.0
     response.setDateHeader("Expires", -1); //prevents caching at the proxy server
        
    String returnResult = "failure";
    try {
        IFormSession formsession = new IFormSession(request);
        WDWorkitems wisessionbean = new WDWorkitems();

        session.setAttribute(IFormUtility.getIFormSessionUID(request), formsession);
        session.setAttribute("wDWorkitems", wisessionbean);
        
        returnResult = "success";
    } catch (Exception ex) {
        returnResult = "failure";
    }

    String callBack = IFormUtility.escapeHtml4(request.getParameter("callback"));
    String finalResult = callBack + "(" + returnResult + ");";
    PrintWriter outObject = response.getWriter();
    outObject.println(finalResult);
%>